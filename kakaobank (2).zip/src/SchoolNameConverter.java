import java.util.Map;
import java.util.stream.Stream;

public class SchoolNameConverter {

    public static void checkCandidateByPriorCandidate(Map<String, Long> schoolCountMap, String priorCandidate, String candidate) {
        if(priorCandidate.equals(candidate)) {
            setSchoolNameCount(schoolCountMap, priorCandidate);
        } else if(candidate.contains(priorCandidate)) {
            candidate = candidate.replaceAll(priorCandidate, priorCandidate+",");
            String[] candidates = candidate.split(",");
            long count = Stream.of(candidates).filter(k -> k.contains(priorCandidate)).count();
            setSchoolNameCount(schoolCountMap, priorCandidate, count);
        } else if(priorCandidate.contains(candidate)) {
            setSchoolNameCount(schoolCountMap, priorCandidate);
        }

        if(Validation.isSameSchoolName(priorCandidate, candidate)) {
            setSchoolNameCount(schoolCountMap, priorCandidate);
        }
    }

    private static void setSchoolNameCount(Map<String, Long> schoolCountMap, String key) {
        setSchoolNameCount(schoolCountMap, key, null);
    }

    private static void setSchoolNameCount(Map<String, Long> schoolCountMap,String key, Long count) {
        if (schoolCountMap.containsKey(key)) {
            Long originCount = schoolCountMap.get(key);
            schoolCountMap.put(key, count == null ? ++originCount : originCount + count);
        } else {
            schoolCountMap.put(key, count == null ? 1L : count);
        }
    }

}
