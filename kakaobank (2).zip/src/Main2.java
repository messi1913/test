import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main2 {

    private static Map<String, Long> schoolCountMap;

    public static void main(String[] args) {
        schoolCountMap = new HashMap<>();
        //1. 파일 일기.
        Charset utf8 = Charset.forName("UTF-8");
        try {
            // Double Quotation 기준으로 한 댓글 씩List 에 담기.
            String allContents = Files.readString(Path.of(SchoolConstants.FILE_PATH), utf8);
            List<String> collect = Stream.of(allContents.split("\""))
                    .filter(s -> !s.equals("") && !s.equals("\n"))
                    .collect(Collectors.toList());

            // 형태소 분석.
            collect.forEach(Main2::findSchoolName);
//            String a = "?경북 경산, 하양여자중학교?\n" +
//                    "\n" +
//                    "이 글 보시는 하양여중 학생 분들, 공감되시는 분은\n" +
//                    "저희 학교";
//            findSchoolName(a);
            schoolCountMap.forEach((k, v) -> System.err.println(k + " : " + v));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void findSchoolName(String comment) {

        String priorCandidate = null;
        String candidate = null;
        System.out.println("================");
        System.out.println(comment);
        System.out.println("================");

        // 특수 문자 제거.
        String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\s]";
        comment = comment.replaceAll(match, " ");
        comment = comment.replaceAll(System.getProperty("line.separator"), " ");
        comment = comment.replaceAll("\n", " ");

        String[] words = comment.split(" ");

        for (int i = 0; i < words.length; i++) {
            String value = words[i];
            String tempCandidate;
            if(Validation.isFullNameSuffix(value)) {
                tempCandidate = getFullSchoolName(words, i, value);
                if(priorCandidate == null) {
                    priorCandidate = tempCandidate;
                }
            } else {
                tempCandidate = Validation.getCandidate(value);
            }

            if (tempCandidate.equals("")) continue;

            String schoolName = tempCandidate;
            if(priorCandidate != null) {
                SchoolNameConverter.checkCandidateByPriorCandidate(schoolCountMap, priorCandidate, schoolName);
                continue;
            }


            if (candidate != null) {
                if (schoolName.equals(candidate)) {
                    setSchoolNameCount(schoolName);
                    System.out.println(schoolName);
                    continue;
                }

                if (schoolName.contains(candidate)) {
                    schoolName = schoolName.replaceAll(candidate, candidate + ",");
                    String[] split = schoolName.split(",");
                    final String _candidate = candidate;
                    long count = Stream.of(split).filter(k -> k.contains(_candidate)).count();
                    setSchoolNameCount(candidate, count);
                    System.out.println(candidate + " -> " + count);
                    continue;
                } else if (candidate.contains(schoolName)) {
                    setSchoolNameCount(candidate);
                    System.out.println(candidate + " ==> " + schoolName);
                    continue;
                }

                if (Validation.isSameSchoolName(candidate, schoolName)) {
                    setSchoolNameCount(candidate);
                    System.out.println(candidate + " : " + schoolName);
                    continue;
                }

            } else {
                if(value.indexOf(schoolName, value.indexOf(schoolName) + 1) > 0) {
                    value = value.replaceAll(schoolName, schoolName + ",");
                    String[] split = value.split(",");
                    final String _schoolName = schoolName;
                    long count = Stream.of(split).filter(k -> k.contains(_schoolName)).count();
                    setSchoolNameCount(schoolName, count);
                    System.out.println(schoolName + " -> " + count);
                } else {
                    setSchoolNameCount(schoolName);
                    System.out.println(schoolName);
                }
            }

            if (candidate == null)
                candidate = schoolName;
        } //  end comment
        if(priorCandidate != null && candidate != null) {
            if(priorCandidate.contains(candidate)) {
                Long priorCount = schoolCountMap.get(priorCandidate);
                Long candidateCount = schoolCountMap.get(candidate);
                schoolCountMap.put(priorCandidate, priorCount+candidateCount);
            }
            schoolCountMap.remove(candidate);
        }

    }

    private static String getFullSchoolName(String[] words, int index, String name) {
        int startIndex = 1;
        while (index - startIndex >= 0) {
            String preValue = words[index - startIndex];
            if (Validation.containsGender(preValue) || preValue.length() == 1) {
                name = preValue.concat(name);
                startIndex++;
            } else {
                name = preValue.concat(name);
                break;
            }
        }
        return name;
    }

    private static void setSchoolNameCount(String key) {
        setSchoolNameCount(key, null);
    }

    private static void setSchoolNameCount(String key, Long count) {
        if (schoolCountMap.containsKey(key)) {
            Long originCount = schoolCountMap.get(key);
            schoolCountMap.put(key, count == null ? ++originCount : originCount + count);
        } else {
            schoolCountMap.put(key, count == null ? 1L : count);
        }
    }
}
