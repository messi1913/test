import java.util.List;
 class SchoolConstants {

    static final String FILE_PATH = "src/resources/comments.csv";
    static final List<String> SCHOOL_NAME_SUFFIX = List.of("초등학교","중학교","고등학교", "대학교", "여중", "남중", "여고", "남고", "초", "대");
    static final List<String> ABBREVIATION_LIST = List.of("초","중","고", "대");
    static final List<String> FULL_GENDER_NAME_LIST = List.of("여자", "남자");
    static final List<String> ABBR_GENDER_NAME_LIST = List.of("여", "남");
    static final String NOUN = "Noun";
    static final List<String> SUFFIX = List.of("초등학교","중학교","고등학교","대학교", "초","중","고", "대");
    static final List<String> FULL_NAME_SUFFIX = List.of("초등학교","중학교","고등학교","대학교", "학교");


}
