import java.util.Optional;

public class Validation {

    static boolean isSameSchoolName(String origin, String target) {
        if(origin.equals(target)) {
            return true;
        }
        // Gender 가 포함되어 있는 경우 .
        String originGender = getGender(origin);
        String targetGender = getGender(target);
        if(!originGender.equals("") && !targetGender.equals("")) {
            return origin.substring(0, origin.indexOf(originGender)).equals(target.substring(0, target.indexOf(targetGender)));
        }

        // Gender 가 포함 안되어 있는경우
        Optional<String> originOptional = SchoolConstants.SUFFIX.stream().filter(origin::endsWith).map(s -> origin.substring(0, origin.indexOf(s))).findFirst();
        Optional<String> targetOptional = SchoolConstants.SUFFIX.stream().filter(target::endsWith).map(s -> target.substring(0, target.indexOf(s))).findFirst();
        if(originOptional.isEmpty() || targetOptional.isEmpty()) {
            return false;
        }

        return originOptional.get().equals(targetOptional.get());

    }

    public static String getCandidate(String value) {
        Optional<String> suffixOptional = SchoolConstants.SUFFIX.stream().filter(value::contains).findFirst();
        if(suffixOptional.isEmpty())
            return "";

        String suffix = suffixOptional.get();
        int lastIndex = value.lastIndexOf(suffix);
        if(lastIndex ==0)
            return "";

        int startIndex = 0;
        String restValue = value.substring(startIndex, lastIndex);
        if(restValue.indexOf(suffix) > 1) {
            startIndex = restValue.lastIndexOf(suffix)+suffix.length();
        }

        return value.substring(startIndex, lastIndex)+suffix;
    }

    public static boolean isCandidate(String value) {
        return SchoolConstants.ABBREVIATION_LIST.stream().anyMatch(value::contains);
    }

    static boolean validLastName(String value) {
        return SchoolConstants.SUFFIX.stream().anyMatch(value::endsWith);
    }

    public static boolean isCandidate(String type, String value) {
        // 명사 아닌 경우 후보군 제외
        if(!SchoolConstants.NOUN.equals(type)) {
            return false;
        }
        // 초, 중, 고 포함 안되어 있는경우.
        Optional<String> abbrValueOption = SchoolConstants.ABBREVIATION_LIST.stream().filter(value::contains).findFirst();
        if(abbrValueOption.isEmpty()) {
            return false;
        }

        // 초,중,고 가 마지막 이고 앞에 두글자 이상이 아닌경우 후보군 제외.
//        return !value.endsWith(abbrValueOption.get()) || value.length() > 2;
        if(!value.endsWith(abbrValueOption.get()) && SchoolConstants.SCHOOL_NAME_SUFFIX.stream().filter(value::contains).findFirst().isEmpty()) {
            return false;
        }
        return true;
    }

    public static boolean isFullName(String value) {
        return SchoolConstants.SCHOOL_NAME_SUFFIX.stream().anyMatch(value::endsWith);
    }

    static boolean containsGender(String value) {
        if(SchoolConstants.FULL_GENDER_NAME_LIST.stream().anyMatch(value::contains))
            return true;

        Optional<String> first = SchoolConstants.ABBR_GENDER_NAME_LIST.stream().filter(value::contains).findFirst();
        if(first.isEmpty())
            return false;

        String gender = first.get();
        int index = value.indexOf(gender);
        return index >= 2;

    }

    static String getGender(String value) {
        Optional<String> fullNameOptional = SchoolConstants.FULL_GENDER_NAME_LIST.stream().filter(value::contains).findFirst();
        if(fullNameOptional.isPresent())
            return fullNameOptional.get();

        Optional<String> first = SchoolConstants.ABBR_GENDER_NAME_LIST.stream().filter(value::contains).findFirst();
        if(first.isEmpty())
            return "";

        String gender = first.get();
        int index = value.indexOf(gender);
        return index >= 2 ? gender : "";

    }

    static boolean validCandidate(String value) {
        return SchoolConstants.SUFFIX.stream().anyMatch(value::endsWith);
    }

    static boolean isSuffux(String value) {
        return SchoolConstants.SUFFIX.stream().anyMatch(value::equals);
    }

    static boolean isFullNameSuffix(String value) {
        return SchoolConstants.FULL_NAME_SUFFIX.stream().anyMatch(value::endsWith);
    }
}
