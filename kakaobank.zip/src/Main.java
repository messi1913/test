import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

    private static Map<String, Long> schoolCountMap;

    public static void main(String[] args) {
        schoolCountMap = new HashMap<>();
        StringBuilder result = new StringBuilder();
        //1. 파일 일기.
        Charset utf8 = Charset.forName("UTF-8");
        try {
            //2. Double Quotation 기준으로 한 댓글 씩List 에 담기.
            String allContents = Files.readString(Path.of(SchoolConstants.FILE_PATH), utf8);
            List<String> collect = Stream.of(allContents.split("\""))
                    .filter(s -> !s.equals("") && !s.equals("\n"))
                    .collect(Collectors.toList());

            //3. 단어 별로 학교 이름 추출.
            collect.forEach(Main::findSchoolName);
            schoolCountMap.forEach((key, value) ->
                result.append(key).append("\t").append(value).append(System.getProperty("line.separator")));

            //4. 파일 작성.
            Files.write(Path.of(SchoolConstants.FILE_RESULT_PATH), result.toString().getBytes(),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println(result.toString());

//            findSchoolName("진짜동두천여자중학교저희는급식을먹기위해이학교를등교합니다제발저희자장면좀주세요제발요저흰급식을먹을때면전쟁터가되요종치자마자넘어지건말건레알로다튀어나가요급식을먹기위해서에요제발저희주세요");
//            schoolCountMap.forEach((k, v) -> System.out.println(k + ":" + v));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void findSchoolName(String comment) {
        String priorCandidate = null;
        List<String> candidateList = new ArrayList<>();
        String candidate = null;

        // 특수 문자 제거.
        String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\s]";
        comment = comment.replaceAll(match, " ");
        comment = comment.replaceAll(System.getProperty("line.separator"), " ");
        comment = comment.replaceAll("\n", " ");

        String[] words = comment.split(" ");

        StringBuilder complexWords = null;

        for (int i = 0; i < words.length; i++) {
            String value = words[i];

            if(value.length() == 1) {
                if (complexWords == null) complexWords = new StringBuilder();
                complexWords.append(value);
            } else {
                complexWords = null;
            }

            value = complexWords != null ? complexWords.toString() : value;

            String tempCandidate = Validation.getCandidate(value);

            if (tempCandidate.equals("")) {
                continue;
            }

            complexWords = null;

            if (Validation.isFullNameSuffix(tempCandidate) || Validation.containsLocation(words, i)) {
                tempCandidate = SchoolNameConverter.getFullSchoolName(words, i, tempCandidate);
                if (tempCandidate.equals("")) {
                    continue;
                }
                String duplicatedCandidate = SchoolNameConverter.getDuplicatedCandidate(schoolCountMap, tempCandidate);
                if (duplicatedCandidate != null) {
                    priorCandidate = duplicatedCandidate;
                    continue;
                }

                if(Validation.startWithMiddleName(tempCandidate)) {
                    continue;
                }


                if (priorCandidate == null) {
                    priorCandidate = tempCandidate;
                }
            }
            String schoolName = tempCandidate;

            if (!Validation.isValidSchoolName(schoolName))
                continue;


            if (priorCandidate != null) {
                SchoolNameConverter.setSchoolNameCountByCandidate(schoolCountMap, priorCandidate, schoolName);
                continue;
            }

            if (candidateList.contains(schoolName)) {
                schoolCountMap.putIfAbsent(schoolName, 1L);
                SchoolNameConverter.setSchoolNameCountByCandidate(schoolCountMap, candidate, schoolName);
                continue;
            }
            candidate = schoolName;
            candidateList.add(candidate);
        }


        if (priorCandidate != null) {
            for (String candi : candidateList) {
                if (priorCandidate.contains(candi)) {
                    Long candidateCount = schoolCountMap.get(candi) == null ? 1L : schoolCountMap.get(candi);
                    SchoolNameConverter.setSchoolNameCount(schoolCountMap, priorCandidate, candidateCount);
                } else if (candi.contains(SchoolNameConverter.getAbbrSchoolName(priorCandidate))) {
                    Long candidateCount = schoolCountMap.get(candi) == null ? 1L : schoolCountMap.get(candi);
                    SchoolNameConverter.setSchoolNameCount(schoolCountMap, priorCandidate, candidateCount);
                }
                schoolCountMap.remove(candi);
            }
        } else if (candidateList.size() > 0) {
            String priorCandi = candidateList.get(0);

            if(!Validation.isFullNameSuffix(priorCandi) && Stream.of(words).anyMatch(priorCandi::startsWith)){
                return;
            }
            Long originCount = schoolCountMap.get(priorCandi);
            SchoolNameConverter.setSchoolNameCount(schoolCountMap, priorCandi, originCount == null ? 1L : originCount + 1L);
            for (int i = 1; i < candidateList.size(); i++) {
                String minorCandi = candidateList.get(i);
                if (priorCandi.contains(minorCandi)) {
                    SchoolNameConverter.setSchoolNameCount(schoolCountMap, priorCandi);
                } else if (minorCandi.contains(priorCandi)) {
                    SchoolNameConverter.setSchoolNameCount(schoolCountMap, priorCandi);
                }
            }
        }
    }
}
