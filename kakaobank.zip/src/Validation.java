import java.util.Optional;

class Validation {

    static boolean isSameSchoolName(String origin, String target) {
        if(origin.equals(target)) {
            return true;
        }
        // Gender 가 포함되어 있는 경우 .
        String originGender = getGender(origin);
        String targetGender = getGender(target);
        if(!originGender.equals("") && !targetGender.equals("")) {
            return origin.substring(0, origin.indexOf(originGender)).equals(target.substring(0, target.indexOf(targetGender)));
        }

        // Gender 가 포함 안되어 있는경우
        Optional<String> originOptional = SchoolConstants.SUFFIX.stream().filter(origin::endsWith).map(s -> origin.substring(0, origin.indexOf(s))).findFirst();
        Optional<String> targetOptional = SchoolConstants.SUFFIX.stream().filter(target::endsWith).map(s -> target.substring(0, target.indexOf(s))).findFirst();
        if(originOptional.isEmpty() || targetOptional.isEmpty()) {
            return false;
        }

        return originOptional.get().equals(targetOptional.get());

    }

    static String getCandidate(String value) {
        Optional<String> suffixOptional = SchoolConstants.SUFFIX.stream().filter(value::contains).findFirst();
        if(suffixOptional.isEmpty())
            return "";

        String suffix = suffixOptional.get();
        int lastIndex = value.lastIndexOf(suffix);

        int startIndex = 0;
        String restValue = value.substring(startIndex, lastIndex);
        if(restValue.indexOf(suffix) > 1) {
            startIndex = restValue.lastIndexOf(suffix)+suffix.length();
        }

        return value.substring(startIndex, lastIndex)+suffix;
    }


    static boolean containsGender(String value) {
        if(SchoolConstants.FULL_GENDER_NAME_LIST.stream().anyMatch(value::contains))
            return true;

        Optional<String> first = SchoolConstants.ABBR_GENDER_NAME_LIST.stream().filter(value::contains).findFirst();
        if(first.isEmpty())
            return false;

        String gender = first.get();
        int index = value.indexOf(gender);
        return index >= 2;

    }

    private static String getGender(String value) {
        Optional<String> fullNameOptional = SchoolConstants.FULL_GENDER_NAME_LIST.stream().filter(value::contains).findFirst();
        if(fullNameOptional.isPresent())
            return fullNameOptional.get();

        Optional<String> first = SchoolConstants.ABBR_GENDER_NAME_LIST.stream().filter(value::contains).findFirst();
        if(first.isEmpty())
            return "";

        String gender = first.get();
        int index = value.indexOf(gender);
        return index >= 2 ? gender : "";

    }


    static boolean isSuffix(String value) {
        return SchoolConstants.SUFFIX.stream().anyMatch(value::equals);
    }

    static boolean isFullNameSuffix(String value) {
        return SchoolConstants.FULL_NAME_SUFFIX.stream().anyMatch(value::endsWith);
    }

    static boolean isValidSchoolName(String value) {
        if(value.length() ==1) return false;
        if(value.endsWith(SchoolConstants.REPRESENT_NAME)){
            Optional<String> middleName = SchoolConstants.MIDDLE_NAME.stream().filter(value::contains).findFirst();
            if(middleName.isEmpty()) return false;

            return !value.startsWith(middleName.get());
        }
        return true;
    }

    static boolean containsLocation(String[] words, int index) {
        if(index == 0) return false;

        String preValue = words[index-1];
        return  SchoolConstants.POSSIBLE_LOCATION.stream().anyMatch(preValue::endsWith);
    }

    static boolean startWithMiddleName(String schoolName) {
        return SchoolConstants.MIDDLE_NAME.stream().anyMatch(schoolName::startsWith);
    }
}
