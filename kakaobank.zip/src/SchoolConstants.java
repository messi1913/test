import java.util.List;

class SchoolConstants {

    static final String FILE_PATH = "src/resources/comments.csv";
    static final String FILE_RESULT_PATH = "src/result.txt";
    static final String REPRESENT_NAME = "학교";
    static final List<String> FULL_GENDER_NAME_LIST = List.of("여자", "남자");
    static final List<String> ABBR_GENDER_NAME_LIST = List.of("여", "남");
    static final List<String> SUFFIX = List.of("초등학교","중학교","고등학교","대학교", "초","중","고", "대", "학교");
    static final List<String> FULL_NAME_SUFFIX = List.of("초등학교","중학교","고등학교","대학교", "학교");
    static final List<String> MIDDLE_NAME = List.of("초등","중", "고등", "대");
    static final List<String> POSSIBLE_LOCATION = List.of("시", "동", "구");
}
