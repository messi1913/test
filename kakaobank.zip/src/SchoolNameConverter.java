import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

class SchoolNameConverter {

    static String getFullSchoolName(String[] words, int index, String name) {
        if(!Validation.isSuffix(name) && !Validation.containsGender(name)) return name;

        int startIndex = 1;
        while (index - startIndex >= 0) {
            String preValue = words[index - startIndex];

            if(name.equals("학교")) {
                if(SchoolConstants.MIDDLE_NAME.stream().noneMatch(preValue::endsWith)) {
                    return "";
                }
            }

            if (Validation.containsGender(preValue) || preValue.length() == 1) {
                name = preValue.concat(name);
                startIndex++;
            } else {
                name = preValue.concat(name);
                break;
            }
        }
        return name;
    }

    static void setSchoolNameCountByCandidate(Map<String, Long> schoolCountMap, String candidate, String value) {
        if(schoolCountMap.containsKey(candidate)) {
            setSchoolNameCount(schoolCountMap, candidate);
            return;
        }

        Set<String> keySet = schoolCountMap.keySet();
        Optional<String> first = keySet.stream().filter(candidate::contains).findFirst();
        if(first.isPresent()) {
            setSchoolNameCount(schoolCountMap, first.get());
            return;
        }

        if(candidate.equals(value)) {
            setSchoolNameCount(schoolCountMap, candidate);
        } else if(value.contains(candidate)) {
            value = value.replaceAll(candidate, candidate+",");
            String[] candidates = value.split(",");
            long count = Stream.of(candidates).filter(k -> k.contains(candidate)).count();
            setSchoolNameCount(schoolCountMap, candidate, count);
        } else if(candidate.contains(value)) {
            setSchoolNameCount(schoolCountMap, candidate);
        } else if(Validation.isSameSchoolName(candidate, value)) {
            setSchoolNameCount(schoolCountMap, candidate);
        }
    }

    static String getDuplicatedCandidate(Map<String, Long> schoolCountMap, String canidate) {
        Optional<String> duplicatedCandidateOptional = SchoolConstants.FULL_NAME_SUFFIX.stream().filter(canidate::endsWith).findFirst();
        if(duplicatedCandidateOptional.isEmpty())
            return null;

        String suffix = duplicatedCandidateOptional.get();
        String originCandidate = canidate.substring(0, canidate.indexOf(suffix))+suffix;
        if(canidate.indexOf(originCandidate, canidate.indexOf(originCandidate)+1) > 0 ) {
            canidate = canidate.replaceAll(originCandidate, originCandidate+",");
            long candidateCount = Stream.of(canidate.split(",")).filter(k -> k.contains(originCandidate)).count();
            setSchoolNameCount(schoolCountMap, originCandidate, candidateCount);
            return originCandidate;
        }
        return null;
    }

    static String getAbbrSchoolName(String schoolName) {
        if(schoolName.lastIndexOf("등학교") > 0) {
            return schoolName.replaceAll("등학교", "");
        } else if(schoolName.lastIndexOf("학교") > 0) {
            return schoolName.replaceAll("학교", "");
        } else {
            return schoolName;
        }
    }

    static void setSchoolNameCount(Map<String, Long> schoolCountMap, String key) {
        setSchoolNameCount(schoolCountMap, key, null);
    }

    static void setSchoolNameCount(Map<String, Long> schoolCountMap,String key, Long count) {
        if (schoolCountMap.containsKey(key)) {
            Long originCount = schoolCountMap.get(key);
            schoolCountMap.put(key, count == null ? ++originCount : originCount + count);
        } else {
            schoolCountMap.put(key, count == null ? 1L : count);
        }
    }
}
