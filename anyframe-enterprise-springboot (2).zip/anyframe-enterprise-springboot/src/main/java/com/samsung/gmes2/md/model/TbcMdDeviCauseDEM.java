package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEVI_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeviCauseDEM extends AbstractDAO {


/**
* insertTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return int
*/
	@LocalName("insertTbcMdDeviCause")
	public int insertTbcMdDeviCause (final TbcMdDeviCauseDVO tbcMdDeviCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.insertTbcMdDeviCause.001*/  \n");
			sql.append(" TBC_MD_DEVI_CAUSE (   \n");
			sql.append("        DEVI_CAUSE_CODE , \n");
			sql.append("        DEVI_CAUSE_DESC , \n");
			sql.append("        DEVI_CLSF_CODE , \n");
			sql.append("        QUAL_DEVI_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseDesc());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviClsfCode());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getQualDeviYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeviCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeviCause Method")
	public int[][] updateBatchAllTbcMdDeviCause (final List  tbcMdDeviCauseDVOList) {
		
		ArrayList updatetbcMdDeviCauseDVOList = new ArrayList();
		ArrayList insertttbcMdDeviCauseDVOList = new ArrayList();
		ArrayList deletetbcMdDeviCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeviCauseDVOList.size() ; i++) {
		  TbcMdDeviCauseDVO tbcMdDeviCauseDVO = (TbcMdDeviCauseDVO) tbcMdDeviCauseDVOList.get(i);
		  
		  if (tbcMdDeviCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdDeviCauseDVOList.add(tbcMdDeviCauseDVO);
		  else if (tbcMdDeviCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdDeviCauseDVOList.add(tbcMdDeviCauseDVO);
		  else if (tbcMdDeviCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdDeviCauseDVOList.add(tbcMdDeviCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeviCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeviCause(insertttbcMdDeviCauseDVOList);
          
      if (updatetbcMdDeviCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeviCause(updatetbcMdDeviCauseDVOList);
      
      if (deletetbcMdDeviCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeviCause(deletetbcMdDeviCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return int
*/
	@LocalName("updateTbcMdDeviCause")
	public int updateTbcMdDeviCause (final TbcMdDeviCauseDVO tbcMdDeviCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.updateTbcMdDeviCause.001*/  \n");
			sql.append(" TBC_MD_DEVI_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        DEVI_CAUSE_DESC = ? , \n");
			sql.append("        DEVI_CLSF_CODE = ? , \n");
			sql.append("        QUAL_DEVI_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEVI_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseDesc());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviClsfCode());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getQualDeviYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdDeviCause")
	public int deleteTbcMdDeviCause (final TbcMdDeviCauseDVO tbcMdDeviCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.deleteTbcMdDeviCause.001*/  \n");
			sql.append(" TBC_MD_DEVI_CAUSE \n");
			sql.append("  WHERE DEVI_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return TbcMdDeviCauseDVO 
*/
	@LocalName("selectTbcMdDeviCause")
	public TbcMdDeviCauseDVO selectTbcMdDeviCause (final TbcMdDeviCauseDVO tbcMdDeviCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.selectTbcMdDeviCause.001*/  \n");
			sql.append("        DEVI_CAUSE_CODE , \n");
			sql.append("        DEVI_CAUSE_DESC , \n");
			sql.append("        DEVI_CLSF_CODE , \n");
			sql.append("        QUAL_DEVI_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEVI_CAUSE \n");
			sql.append("  WHERE DEVI_CAUSE_CODE = ? \n");

		return (TbcMdDeviCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeviCauseDVO returnTbcMdDeviCauseDVO = new TbcMdDeviCauseDVO();
									returnTbcMdDeviCauseDVO.setDeviCauseCode(resultSet.getString("DEVI_CAUSE_CODE"));
									returnTbcMdDeviCauseDVO.setDeviCauseDesc(resultSet.getString("DEVI_CAUSE_DESC"));
									returnTbcMdDeviCauseDVO.setDeviClsfCode(resultSet.getString("DEVI_CLSF_CODE"));
									returnTbcMdDeviCauseDVO.setQualDeviYn(resultSet.getString("QUAL_DEVI_YN"));
									returnTbcMdDeviCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeviCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeviCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeviCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeviCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeviCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeviCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeviCause Method")
	public int mergeTbcMdDeviCause (final TbcMdDeviCauseDVO tbcMdDeviCauseDVO) {
		
		if ( selectTbcMdDeviCause (tbcMdDeviCauseDVO) == null) {
			return insertTbcMdDeviCause(tbcMdDeviCauseDVO);
		} else {
			return selectUpdateTbcMdDeviCause (tbcMdDeviCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeviCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeviCause Method")
	public int selectUpdateTbcMdDeviCause (final TbcMdDeviCauseDVO tbcMdDeviCauseDVO) {
		
		TbcMdDeviCauseDVO tmpTbcMdDeviCauseDVO =  selectTbcMdDeviCause (tbcMdDeviCauseDVO);
		if ( tbcMdDeviCauseDVO.getDeviCauseCode() != null && !"".equals(tbcMdDeviCauseDVO.getDeviCauseCode()) ) {
			tmpTbcMdDeviCauseDVO.setDeviCauseCode(tbcMdDeviCauseDVO.getDeviCauseCode());
		}		
		if ( tbcMdDeviCauseDVO.getDeviCauseDesc() != null && !"".equals(tbcMdDeviCauseDVO.getDeviCauseDesc()) ) {
			tmpTbcMdDeviCauseDVO.setDeviCauseDesc(tbcMdDeviCauseDVO.getDeviCauseDesc());
		}		
		if ( tbcMdDeviCauseDVO.getDeviClsfCode() != null && !"".equals(tbcMdDeviCauseDVO.getDeviClsfCode()) ) {
			tmpTbcMdDeviCauseDVO.setDeviClsfCode(tbcMdDeviCauseDVO.getDeviClsfCode());
		}		
		if ( tbcMdDeviCauseDVO.getQualDeviYn() != null && !"".equals(tbcMdDeviCauseDVO.getQualDeviYn()) ) {
			tmpTbcMdDeviCauseDVO.setQualDeviYn(tbcMdDeviCauseDVO.getQualDeviYn());
		}		
		if ( tbcMdDeviCauseDVO.getUseYn() != null && !"".equals(tbcMdDeviCauseDVO.getUseYn()) ) {
			tmpTbcMdDeviCauseDVO.setUseYn(tbcMdDeviCauseDVO.getUseYn());
		}		
		if ( tbcMdDeviCauseDVO.getFstRegDt() != null && !"".equals(tbcMdDeviCauseDVO.getFstRegDt()) ) {
			tmpTbcMdDeviCauseDVO.setFstRegDt(tbcMdDeviCauseDVO.getFstRegDt());
		}		
		if ( tbcMdDeviCauseDVO.getFstRegerId() != null && !"".equals(tbcMdDeviCauseDVO.getFstRegerId()) ) {
			tmpTbcMdDeviCauseDVO.setFstRegerId(tbcMdDeviCauseDVO.getFstRegerId());
		}		
		if ( tbcMdDeviCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeviCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeviCauseDVO.setFnlUpdDt(tbcMdDeviCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeviCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdDeviCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdDeviCauseDVO.setFnlUpderId(tbcMdDeviCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdDeviCause (tmpTbcMdDeviCauseDVO);
	}

/**
* insertBatchTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeviCause")
	public int[] insertBatchTbcMdDeviCause (final List tbcMdDeviCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.insertBatchTbcMdDeviCause.001*/  \n");
			sql.append(" TBC_MD_DEVI_CAUSE (   \n");
			sql.append("        DEVI_CAUSE_CODE , \n");
			sql.append("        DEVI_CAUSE_DESC , \n");
			sql.append("        DEVI_CLSF_CODE , \n");
			sql.append("        QUAL_DEVI_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeviCauseDVO tbcMdDeviCauseDVO = (TbcMdDeviCauseDVO)tbcMdDeviCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseDesc());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviClsfCode());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getQualDeviYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeviCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeviCause")
	public int[] updateBatchTbcMdDeviCause (final List tbcMdDeviCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.updateBatchTbcMdDeviCause.001*/  \n");
			sql.append(" TBC_MD_DEVI_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        DEVI_CAUSE_DESC = ? , \n");
			sql.append("        DEVI_CLSF_CODE = ? , \n");
			sql.append("        QUAL_DEVI_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEVI_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeviCauseDVO tbcMdDeviCauseDVO = (TbcMdDeviCauseDVO)tbcMdDeviCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseDesc());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviClsfCode());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getQualDeviYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
						}
							public int getBatchSize() {
									return tbcMdDeviCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeviCause Method
* 
* @ref_table TBC_MD_DEVI_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeviCause")
	public int[] deleteBatchTbcMdDeviCause (final List tbcMdDeviCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeviCauseDEM.deleteBatchTbcMdDeviCause.001*/  \n");
			sql.append(" TBC_MD_DEVI_CAUSE \n");
			sql.append("  WHERE DEVI_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeviCauseDVO tbcMdDeviCauseDVO = (TbcMdDeviCauseDVO)tbcMdDeviCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeviCauseDVO.getDeviCauseCode());
						}
							public int getBatchSize() {
									return tbcMdDeviCauseDVOList.size();
							}
					}
		);			
	}

	
}