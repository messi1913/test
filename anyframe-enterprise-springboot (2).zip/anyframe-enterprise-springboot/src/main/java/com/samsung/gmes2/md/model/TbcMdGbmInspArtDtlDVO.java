package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author hkw
 */
public class TbcMdGbmInspArtDtlDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String gbmCode;

	@Length(30) @NotNull
	private String inspArtDtlCode;

	@Length(30) @NotNull
	private String inspArtCode;

	@Length(30) 
	private String procOutGubunCode;

	@Length(500) 
	private String inspArtDtlNm;

	@Length(1) 
	private String useYn;

	@Length(14) @NotNull
	private String fstRegDt;

	@Length(50) @NotNull
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGbmCode() {
		this.gbmCode = super.getValue("gbmCode");
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue("gbmCode", gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getInspArtDtlCode() {
		this.inspArtDtlCode = super.getValue("inspArtDtlCode");
		return this.inspArtDtlCode;
	}

	public void setInspArtDtlCode(String inspArtDtlCode) {
        super.setValue("inspArtDtlCode", inspArtDtlCode);
		this.inspArtDtlCode = inspArtDtlCode;
	}
	
	public String getInspArtCode() {
		this.inspArtCode = super.getValue("inspArtCode");
		return this.inspArtCode;
	}

	public void setInspArtCode(String inspArtCode) {
        super.setValue("inspArtCode", inspArtCode);
		this.inspArtCode = inspArtCode;
	}
	
	public String getProcOutGubunCode() {
		this.procOutGubunCode = super.getValue("procOutGubunCode");
		return this.procOutGubunCode;
	}

	public void setProcOutGubunCode(String procOutGubunCode) {
        super.setValue("procOutGubunCode", procOutGubunCode);
		this.procOutGubunCode = procOutGubunCode;
	}
	
	public String getInspArtDtlNm() {
		this.inspArtDtlNm = super.getValue("inspArtDtlNm");
		return this.inspArtDtlNm;
	}

	public void setInspArtDtlNm(String inspArtDtlNm) {
        super.setValue("inspArtDtlNm", inspArtDtlNm);
		this.inspArtDtlNm = inspArtDtlNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}