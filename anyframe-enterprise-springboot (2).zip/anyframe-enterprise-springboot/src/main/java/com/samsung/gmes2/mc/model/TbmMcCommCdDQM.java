package com.samsung.gmes2.mc.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;


/**
* 
*
* @ref_table  
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcCommCdDQM extends AbstractDAO {


/**
* 
*
* SELECT <*com.samsung.gmes2.mc.mcu611m00.TbmMcCommCdDEM.selectModelCode.001*>  *
* FROM TBM_MC_COMM_CD
* WHERE 1=1
* #if($cateId)
* AND CATE_ID = :cateId
* #end
* 
* @ref_table 
* @return List
*
*/
	public List dListTbmMcCommCd (final Map inputMap) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT /*com.samsung.gmes2.mc.mcu611m00.TbmMcCommCdDEM.selectModelCode.001*/  * \n");
			sql.append(" FROM TBM_MC_COMM_CD \n");
			sql.append(" WHERE 1=1 \n");
			sql.append(" #if($cateId) \n");
			sql.append(" AND CATE_ID = :cateId \n");
			sql.append(" #end \n");
		sql.append(" /* com.samsung.gmes2.mc.mcu611m00.TbmMcCommCd_DQM.dListTbmMcCommCd.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "cateId"});
			if (inputSize > 0) {
				if (inputMap.get("cateId") != null && !"".equals(inputMap.get("cateId"))) {	
					data.put("cateId", inputMap.get("cateId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMcCommCdDVO returnTbmMcCommCdDVO = new TbmMcCommCdDVO();
									returnTbmMcCommCdDVO.setComCode(resultSet.getString("COM_CODE"));
									returnTbmMcCommCdDVO.setCateId(resultSet.getString("CATE_ID"));
									returnTbmMcCommCdDVO.setCodeNm(resultSet.getString("CODE_NM"));
									returnTbmMcCommCdDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMcCommCdDVO.setRemark(resultSet.getString("REMARK"));
									return returnTbmMcCommCdDVO;
					    	}
					    	
					   }
 		);
	}



}