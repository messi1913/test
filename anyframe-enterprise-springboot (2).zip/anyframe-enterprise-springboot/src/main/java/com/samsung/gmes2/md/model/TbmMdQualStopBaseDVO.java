package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
public class TbmMdQualStopBaseDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String gbmCode;

	@Length(30) @NotNull
	private String corpCode;

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String mfgPartCode;

	@Length(30) @NotNull
	private String lineCode;

	@Length(30) @NotNull
	private String unitProcCode;

	@Length(30) @NotNull
	private String deftSympClsfCode;

	@Length(10) @Scale(3) 
	private BigDecimal baseHmsSsop;

	@Length(11) @Scale(5) 
	private BigDecimal aplyQty;

	@Length(11) @Scale(5) 
	private BigDecimal baseDeftRate;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGbmCode() {
		this.gbmCode = super.getValue("gbmCode");
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue("gbmCode", gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getCorpCode() {
		this.corpCode = super.getValue("corpCode");
		return this.corpCode;
	}

	public void setCorpCode(String corpCode) {
        super.setValue("corpCode", corpCode);
		this.corpCode = corpCode;
	}
	
	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getMfgPartCode() {
		this.mfgPartCode = super.getValue("mfgPartCode");
		return this.mfgPartCode;
	}

	public void setMfgPartCode(String mfgPartCode) {
        super.setValue("mfgPartCode", mfgPartCode);
		this.mfgPartCode = mfgPartCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue("lineCode");
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue("lineCode", lineCode);
		this.lineCode = lineCode;
	}
	
	public String getUnitProcCode() {
		this.unitProcCode = super.getValue("unitProcCode");
		return this.unitProcCode;
	}

	public void setUnitProcCode(String unitProcCode) {
        super.setValue("unitProcCode", unitProcCode);
		this.unitProcCode = unitProcCode;
	}
	
	public String getDeftSympClsfCode() {
		this.deftSympClsfCode = super.getValue("deftSympClsfCode");
		return this.deftSympClsfCode;
	}

	public void setDeftSympClsfCode(String deftSympClsfCode) {
        super.setValue("deftSympClsfCode", deftSympClsfCode);
		this.deftSympClsfCode = deftSympClsfCode;
	}
	
	public BigDecimal getBaseHmsSsop() {
		this.baseHmsSsop = super.getValue("baseHmsSsop");
		return this.baseHmsSsop;
	}

	public void setBaseHmsSsop(BigDecimal baseHmsSsop) {
        super.setValue("baseHmsSsop", baseHmsSsop);
		this.baseHmsSsop = baseHmsSsop;
	}
	
	public BigDecimal getAplyQty() {
		this.aplyQty = super.getValue("aplyQty");
		return this.aplyQty;
	}

	public void setAplyQty(BigDecimal aplyQty) {
        super.setValue("aplyQty", aplyQty);
		this.aplyQty = aplyQty;
	}
	
	public BigDecimal getBaseDeftRate() {
		this.baseDeftRate = super.getValue("baseDeftRate");
		return this.baseDeftRate;
	}

	public void setBaseDeftRate(BigDecimal baseDeftRate) {
        super.setValue("baseDeftRate", baseDeftRate);
		this.baseDeftRate = baseDeftRate;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}