package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbpMcLblIsuPreisuDVO extends AbstractVo {

	@Length(50) 
	private String nmgId;

	@Length(15) 
	private BigDecimal nmgSeq;

	@Length(14) 
	private String prtDt;

	@Length(20) 
	private String plantCode;

	@Length(20) 
	private String modelCode;

	@Length(50) 
	private String labelId;

	@Length(50) 
	private String prterId;

	@Length(1) 
	private String rePrtYn;

	@Length(1000) 
	private String rePrtRsn;


	public String getNmgId() {
		this.nmgId = super.getValue(0);
		return this.nmgId;
	}

	public void setNmgId(String nmgId) {
        super.setValue(0, nmgId);
		this.nmgId = nmgId;
	}
	
	public BigDecimal getNmgSeq() {
		this.nmgSeq = super.getValue(1);
		return this.nmgSeq;
	}

	public void setNmgSeq(BigDecimal nmgSeq) {
        super.setValue(1, nmgSeq);
		this.nmgSeq = nmgSeq;
	}
	
	public String getPrtDt() {
		this.prtDt = super.getValue(2);
		return this.prtDt;
	}

	public void setPrtDt(String prtDt) {
        super.setValue(2, prtDt);
		this.prtDt = prtDt;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(3);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(3, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(4);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(4, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue(5);
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue(5, labelId);
		this.labelId = labelId;
	}
	
	public String getPrterId() {
		this.prterId = super.getValue(6);
		return this.prterId;
	}

	public void setPrterId(String prterId) {
        super.setValue(6, prterId);
		this.prterId = prterId;
	}
	
	public String getRePrtYn() {
		this.rePrtYn = super.getValue(7);
		return this.rePrtYn;
	}

	public void setRePrtYn(String rePrtYn) {
        super.setValue(7, rePrtYn);
		this.rePrtYn = rePrtYn;
	}
	
	public String getRePrtRsn() {
		this.rePrtRsn = super.getValue(8);
		return this.rePrtRsn;
	}

	public void setRePrtRsn(String rePrtRsn) {
        super.setValue(8, rePrtRsn);
		this.rePrtRsn = rePrtRsn;
	}
	
}