package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_LOSS_TYPE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdLossTypeDEM extends AbstractDAO {


/**
* insertTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return int
*/
	@LocalName("insertTbcMdLossType")
	public int insertTbcMdLossType (final TbcMdLossTypeDVO tbcMdLossTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.insertTbcMdLossType.001*/  \n");
			sql.append(" TBC_MD_LOSS_TYPE (   \n");
			sql.append("        LOSS_TYPE_CODE , \n");
			sql.append("        LOSS_TYPE_DESC , \n");
			sql.append("        LOSS_POSBLT_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeDesc());
							ps.setString(psCount++, tbcMdLossTypeDVO.getLossPosbltYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdLossType Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdLossType Method")
	public int[][] updateBatchAllTbcMdLossType (final List  tbcMdLossTypeDVOList) {
		
		ArrayList updatetbcMdLossTypeDVOList = new ArrayList();
		ArrayList insertttbcMdLossTypeDVOList = new ArrayList();
		ArrayList deletetbcMdLossTypeDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdLossTypeDVOList.size() ; i++) {
		  TbcMdLossTypeDVO tbcMdLossTypeDVO = (TbcMdLossTypeDVO) tbcMdLossTypeDVOList.get(i);
		  
		  if (tbcMdLossTypeDVO.getSqlAction().equals("C"))
		      insertttbcMdLossTypeDVOList.add(tbcMdLossTypeDVO);
		  else if (tbcMdLossTypeDVO.getSqlAction().equals("U"))
		      updatetbcMdLossTypeDVOList.add(tbcMdLossTypeDVO);
		  else if (tbcMdLossTypeDVO.getSqlAction().equals("D"))
		      deletetbcMdLossTypeDVOList.add(tbcMdLossTypeDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdLossTypeDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdLossType(insertttbcMdLossTypeDVOList);
          
      if (updatetbcMdLossTypeDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdLossType(updatetbcMdLossTypeDVOList);
      
      if (deletetbcMdLossTypeDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdLossType(deletetbcMdLossTypeDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return int
*/
	@LocalName("updateTbcMdLossType")
	public int updateTbcMdLossType (final TbcMdLossTypeDVO tbcMdLossTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.updateTbcMdLossType.001*/  \n");
			sql.append(" TBC_MD_LOSS_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_TYPE_DESC = ? , \n");
			sql.append("        LOSS_POSBLT_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LOSS_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeDesc());
							ps.setString(psCount++, tbcMdLossTypeDVO.getLossPosbltYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
						}
					}
		);			
	}

/**
* deleteTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return int
*/
	@LocalName("deleteTbcMdLossType")
	public int deleteTbcMdLossType (final TbcMdLossTypeDVO tbcMdLossTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.deleteTbcMdLossType.001*/  \n");
			sql.append(" TBC_MD_LOSS_TYPE \n");
			sql.append("  WHERE LOSS_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
						}
					}
		);			
	}

/**
* selectTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return TbcMdLossTypeDVO 
*/
	@LocalName("selectTbcMdLossType")
	public TbcMdLossTypeDVO selectTbcMdLossType (final TbcMdLossTypeDVO tbcMdLossTypeDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.selectTbcMdLossType.001*/  \n");
			sql.append("        LOSS_TYPE_CODE , \n");
			sql.append("        LOSS_TYPE_DESC , \n");
			sql.append("        LOSS_POSBLT_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_LOSS_TYPE \n");
			sql.append("  WHERE LOSS_TYPE_CODE = ? \n");

		return (TbcMdLossTypeDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdLossTypeDVO returnTbcMdLossTypeDVO = new TbcMdLossTypeDVO();
									returnTbcMdLossTypeDVO.setLossTypeCode(resultSet.getString("LOSS_TYPE_CODE"));
									returnTbcMdLossTypeDVO.setLossTypeDesc(resultSet.getString("LOSS_TYPE_DESC"));
									returnTbcMdLossTypeDVO.setLossPosbltYn(resultSet.getString("LOSS_POSBLT_YN"));
									returnTbcMdLossTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdLossTypeDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdLossTypeDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdLossTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdLossTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdLossTypeDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdLossType Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdLossType Method")
	public int mergeTbcMdLossType (final TbcMdLossTypeDVO tbcMdLossTypeDVO) {
		
		if ( selectTbcMdLossType (tbcMdLossTypeDVO) == null) {
			return insertTbcMdLossType(tbcMdLossTypeDVO);
		} else {
			return selectUpdateTbcMdLossType (tbcMdLossTypeDVO);
		}
	}

	/**
	 * selectUpdateTbcMdLossType Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdLossType Method")
	public int selectUpdateTbcMdLossType (final TbcMdLossTypeDVO tbcMdLossTypeDVO) {
		
		TbcMdLossTypeDVO tmpTbcMdLossTypeDVO =  selectTbcMdLossType (tbcMdLossTypeDVO);
		if ( tbcMdLossTypeDVO.getLossTypeCode() != null && !"".equals(tbcMdLossTypeDVO.getLossTypeCode()) ) {
			tmpTbcMdLossTypeDVO.setLossTypeCode(tbcMdLossTypeDVO.getLossTypeCode());
		}		
		if ( tbcMdLossTypeDVO.getLossTypeDesc() != null && !"".equals(tbcMdLossTypeDVO.getLossTypeDesc()) ) {
			tmpTbcMdLossTypeDVO.setLossTypeDesc(tbcMdLossTypeDVO.getLossTypeDesc());
		}		
		if ( tbcMdLossTypeDVO.getLossPosbltYn() != null && !"".equals(tbcMdLossTypeDVO.getLossPosbltYn()) ) {
			tmpTbcMdLossTypeDVO.setLossPosbltYn(tbcMdLossTypeDVO.getLossPosbltYn());
		}		
		if ( tbcMdLossTypeDVO.getUseYn() != null && !"".equals(tbcMdLossTypeDVO.getUseYn()) ) {
			tmpTbcMdLossTypeDVO.setUseYn(tbcMdLossTypeDVO.getUseYn());
		}		
		if ( tbcMdLossTypeDVO.getFstRegDt() != null && !"".equals(tbcMdLossTypeDVO.getFstRegDt()) ) {
			tmpTbcMdLossTypeDVO.setFstRegDt(tbcMdLossTypeDVO.getFstRegDt());
		}		
		if ( tbcMdLossTypeDVO.getFstRegerId() != null && !"".equals(tbcMdLossTypeDVO.getFstRegerId()) ) {
			tmpTbcMdLossTypeDVO.setFstRegerId(tbcMdLossTypeDVO.getFstRegerId());
		}		
		if ( tbcMdLossTypeDVO.getFnlUpdDt() != null && !"".equals(tbcMdLossTypeDVO.getFnlUpdDt()) ) {
			tmpTbcMdLossTypeDVO.setFnlUpdDt(tbcMdLossTypeDVO.getFnlUpdDt());
		}		
		if ( tbcMdLossTypeDVO.getFnlUpderId() != null && !"".equals(tbcMdLossTypeDVO.getFnlUpderId()) ) {
			tmpTbcMdLossTypeDVO.setFnlUpderId(tbcMdLossTypeDVO.getFnlUpderId());
		}		
		return updateTbcMdLossType (tmpTbcMdLossTypeDVO);
	}

/**
* insertBatchTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return int[]
*/
	@LocalName("insertBatchTbcMdLossType")
	public int[] insertBatchTbcMdLossType (final List tbcMdLossTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.insertBatchTbcMdLossType.001*/  \n");
			sql.append(" TBC_MD_LOSS_TYPE (   \n");
			sql.append("        LOSS_TYPE_CODE , \n");
			sql.append("        LOSS_TYPE_DESC , \n");
			sql.append("        LOSS_POSBLT_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossTypeDVO tbcMdLossTypeDVO = (TbcMdLossTypeDVO)tbcMdLossTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeDesc());
							ps.setString(psCount++, tbcMdLossTypeDVO.getLossPosbltYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdLossTypeDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return int[]
*/
	@LocalName("updateBatchTbcMdLossType")
	public int[] updateBatchTbcMdLossType (final List tbcMdLossTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.updateBatchTbcMdLossType.001*/  \n");
			sql.append(" TBC_MD_LOSS_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_TYPE_DESC = ? , \n");
			sql.append("        LOSS_POSBLT_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LOSS_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossTypeDVO tbcMdLossTypeDVO = (TbcMdLossTypeDVO)tbcMdLossTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeDesc());
							ps.setString(psCount++, tbcMdLossTypeDVO.getLossPosbltYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
						}
							public int getBatchSize() {
									return tbcMdLossTypeDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdLossType Method
* 
* @ref_table TBC_MD_LOSS_TYPE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdLossType")
	public int[] deleteBatchTbcMdLossType (final List tbcMdLossTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdLossTypeDEM.deleteBatchTbcMdLossType.001*/  \n");
			sql.append(" TBC_MD_LOSS_TYPE \n");
			sql.append("  WHERE LOSS_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossTypeDVO tbcMdLossTypeDVO = (TbcMdLossTypeDVO)tbcMdLossTypeDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossTypeDVO.getLossTypeCode());
						}
							public int getBatchSize() {
									return tbcMdLossTypeDVOList.size();
							}
					}
		);			
	}

	
}