package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbhMdMatrDVO extends AbstractVo {

	@Length(30) 
	private String matrCode;

	@Length(17) 
	private String histTsp;

	@Length(2000) 
	private String matrDesc;

	@Length(2000) 
	private String matrSpecCont;

	@Length(30) 
	private String purcGradeCode;

	@Length(30) 
	private String qualGradeCode;

	@Length(30) 
	private String unitCode;

	@Length(1) 
	private String lfYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;

	@Length(50) 
	private String evtNm;


	public String getMatrCode() {
		this.matrCode = super.getValue(0);
		return this.matrCode;
	}

	public void setMatrCode(String matrCode) {
        super.setValue(0, matrCode);
		this.matrCode = matrCode;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(1);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(1, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getMatrDesc() {
		this.matrDesc = super.getValue(2);
		return this.matrDesc;
	}

	public void setMatrDesc(String matrDesc) {
        super.setValue(2, matrDesc);
		this.matrDesc = matrDesc;
	}
	
	public String getMatrSpecCont() {
		this.matrSpecCont = super.getValue(3);
		return this.matrSpecCont;
	}

	public void setMatrSpecCont(String matrSpecCont) {
        super.setValue(3, matrSpecCont);
		this.matrSpecCont = matrSpecCont;
	}
	
	public String getPurcGradeCode() {
		this.purcGradeCode = super.getValue(4);
		return this.purcGradeCode;
	}

	public void setPurcGradeCode(String purcGradeCode) {
        super.setValue(4, purcGradeCode);
		this.purcGradeCode = purcGradeCode;
	}
	
	public String getQualGradeCode() {
		this.qualGradeCode = super.getValue(5);
		return this.qualGradeCode;
	}

	public void setQualGradeCode(String qualGradeCode) {
        super.setValue(5, qualGradeCode);
		this.qualGradeCode = qualGradeCode;
	}
	
	public String getUnitCode() {
		this.unitCode = super.getValue(6);
		return this.unitCode;
	}

	public void setUnitCode(String unitCode) {
        super.setValue(6, unitCode);
		this.unitCode = unitCode;
	}
	
	public String getLfYn() {
		this.lfYn = super.getValue(7);
		return this.lfYn;
	}

	public void setLfYn(String lfYn) {
        super.setValue(7, lfYn);
		this.lfYn = lfYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(8);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(8, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(9);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(9, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(10);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(10, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(11);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(11, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(12);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(12, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
	public String getEvtNm() {
		this.evtNm = super.getValue(13);
		return this.evtNm;
	}

	public void setEvtNm(String evtNm) {
        super.setValue(13, evtNm);
		this.evtNm = evtNm;
	}
	
}