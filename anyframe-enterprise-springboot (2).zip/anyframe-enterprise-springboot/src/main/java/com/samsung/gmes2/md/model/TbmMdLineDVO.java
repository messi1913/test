package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbmMdLineDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String lineCode;

	@Length(500) 
	private String lineNm;

	@Length(30) 
	private String mfgPartCode;

	@Length(30) 
	private String procGubunCode;

	@Length(30) 
	private String lineFormCode;

	@Length(2000) 
	private String lineLocDesc;

	@Length(1) 
	private String outsYn;

	@Length(30) 
	private String tbGubunCode;

	@Length(30) 
	private String rprsCellTypeCode;

	@Length(1) 
	private String planManualCreYn;

	@Length(1) 
	private String mainPackLineInlineYn;

	@Length(1) 
	private String catvUseYn;

	@Length(1) 
	private String boardUseYn;

	@Length(6) 
	private String workStartHms;

	@Length(30) 
	private String labelWrtCode;

	@Length(1) 
	private String ttCalcYn;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue("lineCode");
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue("lineCode", lineCode);
		this.lineCode = lineCode;
	}
	
	public String getLineNm() {
		this.lineNm = super.getValue("lineNm");
		return this.lineNm;
	}

	public void setLineNm(String lineNm) {
        super.setValue("lineNm", lineNm);
		this.lineNm = lineNm;
	}
	
	public String getMfgPartCode() {
		this.mfgPartCode = super.getValue("mfgPartCode");
		return this.mfgPartCode;
	}

	public void setMfgPartCode(String mfgPartCode) {
        super.setValue("mfgPartCode", mfgPartCode);
		this.mfgPartCode = mfgPartCode;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue("procGubunCode");
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue("procGubunCode", procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getLineFormCode() {
		this.lineFormCode = super.getValue("lineFormCode");
		return this.lineFormCode;
	}

	public void setLineFormCode(String lineFormCode) {
        super.setValue("lineFormCode", lineFormCode);
		this.lineFormCode = lineFormCode;
	}
	
	public String getLineLocDesc() {
		this.lineLocDesc = super.getValue("lineLocDesc");
		return this.lineLocDesc;
	}

	public void setLineLocDesc(String lineLocDesc) {
        super.setValue("lineLocDesc", lineLocDesc);
		this.lineLocDesc = lineLocDesc;
	}
	
	public String getOutsYn() {
		this.outsYn = super.getValue("outsYn");
		return this.outsYn;
	}

	public void setOutsYn(String outsYn) {
        super.setValue("outsYn", outsYn);
		this.outsYn = outsYn;
	}
	
	public String getTbGubunCode() {
		this.tbGubunCode = super.getValue("tbGubunCode");
		return this.tbGubunCode;
	}

	public void setTbGubunCode(String tbGubunCode) {
        super.setValue("tbGubunCode", tbGubunCode);
		this.tbGubunCode = tbGubunCode;
	}
	
	public String getRprsCellTypeCode() {
		this.rprsCellTypeCode = super.getValue("rprsCellTypeCode");
		return this.rprsCellTypeCode;
	}

	public void setRprsCellTypeCode(String rprsCellTypeCode) {
        super.setValue("rprsCellTypeCode", rprsCellTypeCode);
		this.rprsCellTypeCode = rprsCellTypeCode;
	}
	
	public String getPlanManualCreYn() {
		this.planManualCreYn = super.getValue("planManualCreYn");
		return this.planManualCreYn;
	}

	public void setPlanManualCreYn(String planManualCreYn) {
        super.setValue("planManualCreYn", planManualCreYn);
		this.planManualCreYn = planManualCreYn;
	}
	
	public String getMainPackLineInlineYn() {
		this.mainPackLineInlineYn = super.getValue("mainPackLineInlineYn");
		return this.mainPackLineInlineYn;
	}

	public void setMainPackLineInlineYn(String mainPackLineInlineYn) {
        super.setValue("mainPackLineInlineYn", mainPackLineInlineYn);
		this.mainPackLineInlineYn = mainPackLineInlineYn;
	}
	
	public String getCatvUseYn() {
		this.catvUseYn = super.getValue("catvUseYn");
		return this.catvUseYn;
	}

	public void setCatvUseYn(String catvUseYn) {
        super.setValue("catvUseYn", catvUseYn);
		this.catvUseYn = catvUseYn;
	}
	
	public String getBoardUseYn() {
		this.boardUseYn = super.getValue("boardUseYn");
		return this.boardUseYn;
	}

	public void setBoardUseYn(String boardUseYn) {
        super.setValue("boardUseYn", boardUseYn);
		this.boardUseYn = boardUseYn;
	}
	
	public String getWorkStartHms() {
		this.workStartHms = super.getValue("workStartHms");
		return this.workStartHms;
	}

	public void setWorkStartHms(String workStartHms) {
        super.setValue("workStartHms", workStartHms);
		this.workStartHms = workStartHms;
	}
	
	public String getLabelWrtCode() {
		this.labelWrtCode = super.getValue("labelWrtCode");
		return this.labelWrtCode;
	}

	public void setLabelWrtCode(String labelWrtCode) {
        super.setValue("labelWrtCode", labelWrtCode);
		this.labelWrtCode = labelWrtCode;
	}
	
	public String getTtCalcYn() {
		this.ttCalcYn = super.getValue("ttCalcYn");
		return this.ttCalcYn;
	}

	public void setTtCalcYn(String ttCalcYn) {
        super.setValue("ttCalcYn", ttCalcYn);
		this.ttCalcYn = ttCalcYn;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue("fnlAcrsReflYn");
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue("fnlAcrsReflYn", fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}