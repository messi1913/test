package com.samsung.gmes2.md.logi.biz;

public class MdManageMagBiz {

	/**
	 * 매거진 목록 조회
	 */
	public void listMag(){}

	/**
	 * 매거진 목록 저장
	 */
	public void saveMsg(){}

}
