package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_LBL_NMG_ART
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcLblNmgArtDEM extends AbstractDAO {


/**
* insertTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return int
*/
	@LocalName("insertTbmMcLblNmgArt")
	public int insertTbmMcLblNmgArt (final TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.insertTbmMcLblNmgArt.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_ART (   \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        ART_TYPE_CODE , \n");
			sql.append("        NMG_RNG_MIN_VALUE , \n");
			sql.append("        NMG_RNG_MAX_VALUE , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PRT_TYPE_CODE , \n");
			sql.append("        NMG_RULE_DESC , \n");
			sql.append("        HQ_LABEL_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getArtTypeCode());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMaxValue());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getPrtTypeCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgRuleDesc());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getHqLabelId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcLblNmgArt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcLblNmgArt Method")
	public int[][] updateBatchAllTbmMcLblNmgArt (final List  tbmMcLblNmgArtDVOList) {
		
		ArrayList updatetbmMcLblNmgArtDVOList = new ArrayList();
		ArrayList insertttbmMcLblNmgArtDVOList = new ArrayList();
		ArrayList deletetbmMcLblNmgArtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcLblNmgArtDVOList.size() ; i++) {
		  TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO = (TbmMcLblNmgArtDVO) tbmMcLblNmgArtDVOList.get(i);
		  
		  if (tbmMcLblNmgArtDVO.getSqlAction().equals("C"))
		      insertttbmMcLblNmgArtDVOList.add(tbmMcLblNmgArtDVO);
		  else if (tbmMcLblNmgArtDVO.getSqlAction().equals("U"))
		      updatetbmMcLblNmgArtDVOList.add(tbmMcLblNmgArtDVO);
		  else if (tbmMcLblNmgArtDVO.getSqlAction().equals("D"))
		      deletetbmMcLblNmgArtDVOList.add(tbmMcLblNmgArtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcLblNmgArtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcLblNmgArt(insertttbmMcLblNmgArtDVOList);
          
      if (updatetbmMcLblNmgArtDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcLblNmgArt(updatetbmMcLblNmgArtDVOList);
      
      if (deletetbmMcLblNmgArtDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcLblNmgArt(deletetbmMcLblNmgArtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return int
*/
	@LocalName("updateTbmMcLblNmgArt")
	public int updateTbmMcLblNmgArt (final TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.updateTbmMcLblNmgArt.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_ART \n");
			sql.append(" SET   \n");
			sql.append("        ART_TYPE_CODE = ? , \n");
			sql.append("        NMG_RNG_MIN_VALUE = ? , \n");
			sql.append("        NMG_RNG_MAX_VALUE = ? , \n");
			sql.append("        DIV_CODE = ? , \n");
			sql.append("        PRT_TYPE_CODE = ? , \n");
			sql.append("        NMG_RULE_DESC = ? , \n");
			sql.append("        HQ_LABEL_ID = ? \n");
			sql.append(" WHERE NMG_ART_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgArtDVO.getArtTypeCode());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMaxValue());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getPrtTypeCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgRuleDesc());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getHqLabelId());

							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
						}
					}
		);			
	}

/**
* deleteTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return int
*/
	@LocalName("deleteTbmMcLblNmgArt")
	public int deleteTbmMcLblNmgArt (final TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.deleteTbmMcLblNmgArt.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_ART \n");
			sql.append("  WHERE NMG_ART_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
						}
					}
		);			
	}

/**
* selectTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return TbmMcLblNmgArtDVO 
*/
	@LocalName("selectTbmMcLblNmgArt")
	public TbmMcLblNmgArtDVO selectTbmMcLblNmgArt (final TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.selectTbmMcLblNmgArt.001*/  \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        ART_TYPE_CODE , \n");
			sql.append("        NMG_RNG_MIN_VALUE , \n");
			sql.append("        NMG_RNG_MAX_VALUE , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PRT_TYPE_CODE , \n");
			sql.append("        NMG_RULE_DESC , \n");
			sql.append("        HQ_LABEL_ID \n");
			sql.append("   FROM TBM_MC_LBL_NMG_ART \n");
			sql.append("  WHERE NMG_ART_ID = ? \n");

		return (TbmMcLblNmgArtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcLblNmgArtDVO returnTbmMcLblNmgArtDVO = new TbmMcLblNmgArtDVO();
									returnTbmMcLblNmgArtDVO.setNmgArtId(resultSet.getString("NMG_ART_ID"));
									returnTbmMcLblNmgArtDVO.setArtTypeCode(resultSet.getString("ART_TYPE_CODE"));
									returnTbmMcLblNmgArtDVO.setNmgRngMinValue(resultSet.getBigDecimal("NMG_RNG_MIN_VALUE"));
									returnTbmMcLblNmgArtDVO.setNmgRngMaxValue(resultSet.getBigDecimal("NMG_RNG_MAX_VALUE"));
									returnTbmMcLblNmgArtDVO.setDivCode(resultSet.getString("DIV_CODE"));
									returnTbmMcLblNmgArtDVO.setPrtTypeCode(resultSet.getString("PRT_TYPE_CODE"));
									returnTbmMcLblNmgArtDVO.setNmgRuleDesc(resultSet.getString("NMG_RULE_DESC"));
									returnTbmMcLblNmgArtDVO.setHqLabelId(resultSet.getString("HQ_LABEL_ID"));
									return returnTbmMcLblNmgArtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcLblNmgArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcLblNmgArt Method")
	public int mergeTbmMcLblNmgArt (final TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO) {
		
		if ( selectTbmMcLblNmgArt (tbmMcLblNmgArtDVO) == null) {
			return insertTbmMcLblNmgArt(tbmMcLblNmgArtDVO);
		} else {
			return selectUpdateTbmMcLblNmgArt (tbmMcLblNmgArtDVO);
		}
	}

	/**
	 * selectUpdateTbmMcLblNmgArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcLblNmgArt Method")
	public int selectUpdateTbmMcLblNmgArt (final TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO) {
		
		TbmMcLblNmgArtDVO tmpTbmMcLblNmgArtDVO =  selectTbmMcLblNmgArt (tbmMcLblNmgArtDVO);
		if ( tbmMcLblNmgArtDVO.getNmgArtId() != null && !"".equals(tbmMcLblNmgArtDVO.getNmgArtId()) ) {
			tmpTbmMcLblNmgArtDVO.setNmgArtId(tbmMcLblNmgArtDVO.getNmgArtId());
		}		
		if ( tbmMcLblNmgArtDVO.getArtTypeCode() != null && !"".equals(tbmMcLblNmgArtDVO.getArtTypeCode()) ) {
			tmpTbmMcLblNmgArtDVO.setArtTypeCode(tbmMcLblNmgArtDVO.getArtTypeCode());
		}		
		if ( tbmMcLblNmgArtDVO.getNmgRngMinValue() != null && !"".equals(tbmMcLblNmgArtDVO.getNmgRngMinValue()) ) {
			tmpTbmMcLblNmgArtDVO.setNmgRngMinValue(tbmMcLblNmgArtDVO.getNmgRngMinValue());
		}		
		if ( tbmMcLblNmgArtDVO.getNmgRngMaxValue() != null && !"".equals(tbmMcLblNmgArtDVO.getNmgRngMaxValue()) ) {
			tmpTbmMcLblNmgArtDVO.setNmgRngMaxValue(tbmMcLblNmgArtDVO.getNmgRngMaxValue());
		}		
		if ( tbmMcLblNmgArtDVO.getDivCode() != null && !"".equals(tbmMcLblNmgArtDVO.getDivCode()) ) {
			tmpTbmMcLblNmgArtDVO.setDivCode(tbmMcLblNmgArtDVO.getDivCode());
		}		
		if ( tbmMcLblNmgArtDVO.getPrtTypeCode() != null && !"".equals(tbmMcLblNmgArtDVO.getPrtTypeCode()) ) {
			tmpTbmMcLblNmgArtDVO.setPrtTypeCode(tbmMcLblNmgArtDVO.getPrtTypeCode());
		}		
		if ( tbmMcLblNmgArtDVO.getNmgRuleDesc() != null && !"".equals(tbmMcLblNmgArtDVO.getNmgRuleDesc()) ) {
			tmpTbmMcLblNmgArtDVO.setNmgRuleDesc(tbmMcLblNmgArtDVO.getNmgRuleDesc());
		}		
		if ( tbmMcLblNmgArtDVO.getHqLabelId() != null && !"".equals(tbmMcLblNmgArtDVO.getHqLabelId()) ) {
			tmpTbmMcLblNmgArtDVO.setHqLabelId(tbmMcLblNmgArtDVO.getHqLabelId());
		}		
		return updateTbmMcLblNmgArt (tmpTbmMcLblNmgArtDVO);
	}

/**
* insertBatchTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return int[]
*/
	@LocalName("insertBatchTbmMcLblNmgArt")
	public int[] insertBatchTbmMcLblNmgArt (final List tbmMcLblNmgArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.insertBatchTbmMcLblNmgArt.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_ART (   \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        ART_TYPE_CODE , \n");
			sql.append("        NMG_RNG_MIN_VALUE , \n");
			sql.append("        NMG_RNG_MAX_VALUE , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PRT_TYPE_CODE , \n");
			sql.append("        NMG_RULE_DESC , \n");
			sql.append("        HQ_LABEL_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO = (TbmMcLblNmgArtDVO)tbmMcLblNmgArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getArtTypeCode());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMaxValue());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getPrtTypeCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgRuleDesc());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getHqLabelId());

						}
							public int getBatchSize() {
									return tbmMcLblNmgArtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return int[]
*/
	@LocalName("updateBatchTbmMcLblNmgArt")
	public int[] updateBatchTbmMcLblNmgArt (final List tbmMcLblNmgArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.updateBatchTbmMcLblNmgArt.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_ART \n");
			sql.append(" SET   \n");
			sql.append("        ART_TYPE_CODE = ? , \n");
			sql.append("        NMG_RNG_MIN_VALUE = ? , \n");
			sql.append("        NMG_RNG_MAX_VALUE = ? , \n");
			sql.append("        DIV_CODE = ? , \n");
			sql.append("        PRT_TYPE_CODE = ? , \n");
			sql.append("        NMG_RULE_DESC = ? , \n");
			sql.append("        HQ_LABEL_ID = ? \n");
			sql.append(" WHERE NMG_ART_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO = (TbmMcLblNmgArtDVO)tbmMcLblNmgArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgArtDVO.getArtTypeCode());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbmMcLblNmgArtDVO.getNmgRngMaxValue());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getPrtTypeCode());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgRuleDesc());
							ps.setString(psCount++, tbmMcLblNmgArtDVO.getHqLabelId());

							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
						}
							public int getBatchSize() {
									return tbmMcLblNmgArtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcLblNmgArt Method
* 
* @ref_table TBM_MC_LBL_NMG_ART
* @return int[]
*/
	@LocalName("deleteBatchTbmMcLblNmgArt")
	public int[] deleteBatchTbmMcLblNmgArt (final List tbmMcLblNmgArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblNmgArtDEM.deleteBatchTbmMcLblNmgArt.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_ART \n");
			sql.append("  WHERE NMG_ART_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgArtDVO tbmMcLblNmgArtDVO = (TbmMcLblNmgArtDVO)tbmMcLblNmgArtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgArtDVO.getNmgArtId());
						}
							public int getBatchSize() {
									return tbmMcLblNmgArtDVOList.size();
							}
					}
		);			
	}

	
}