package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBP_MC_LBL_ISU_PREISU
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbpMcLblIsuPreisuDEM extends AbstractDAO {


/**
* insertTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return int
*/
	@LocalName("insertTbpMcLblIsuPreisu")
	public int insertTbpMcLblIsuPreisu (final TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.insertTbpMcLblIsuPreisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_PREISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtRsn());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbpMcLblIsuPreisu Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbpMcLblIsuPreisu Method")
	public int[][] updateBatchAllTbpMcLblIsuPreisu (final List  tbpMcLblIsuPreisuDVOList) {
		
		ArrayList updatetbpMcLblIsuPreisuDVOList = new ArrayList();
		ArrayList insertttbpMcLblIsuPreisuDVOList = new ArrayList();
		ArrayList deletetbpMcLblIsuPreisuDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbpMcLblIsuPreisuDVOList.size() ; i++) {
		  TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO = (TbpMcLblIsuPreisuDVO) tbpMcLblIsuPreisuDVOList.get(i);
		  
		  if (tbpMcLblIsuPreisuDVO.getSqlAction().equals("C"))
		      insertttbpMcLblIsuPreisuDVOList.add(tbpMcLblIsuPreisuDVO);
		  else if (tbpMcLblIsuPreisuDVO.getSqlAction().equals("U"))
		      updatetbpMcLblIsuPreisuDVOList.add(tbpMcLblIsuPreisuDVO);
		  else if (tbpMcLblIsuPreisuDVO.getSqlAction().equals("D"))
		      deletetbpMcLblIsuPreisuDVOList.add(tbpMcLblIsuPreisuDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbpMcLblIsuPreisuDVOList.size() > 0) 
          resultValues[0] = insertBatchTbpMcLblIsuPreisu(insertttbpMcLblIsuPreisuDVOList);
          
      if (updatetbpMcLblIsuPreisuDVOList.size() >0)
          resultValues[1] = updateBatchTbpMcLblIsuPreisu(updatetbpMcLblIsuPreisuDVOList);
      
      if (deletetbpMcLblIsuPreisuDVOList.size() >0)
          resultValues[2] = deleteBatchTbpMcLblIsuPreisu(deletetbpMcLblIsuPreisuDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return int
*/
	@LocalName("updateTbpMcLblIsuPreisu")
	public int updateTbpMcLblIsuPreisu (final TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.updateTbpMcLblIsuPreisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_PREISU \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND NMG_SEQ = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtRsn());

							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
						}
					}
		);			
	}

/**
* deleteTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return int
*/
	@LocalName("deleteTbpMcLblIsuPreisu")
	public int deleteTbpMcLblIsuPreisu (final TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.deleteTbpMcLblIsuPreisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_PREISU \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
						}
					}
		);			
	}

/**
* selectTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return TbpMcLblIsuPreisuDVO 
*/
	@LocalName("selectTbpMcLblIsuPreisu")
	public TbpMcLblIsuPreisuDVO selectTbpMcLblIsuPreisu (final TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.selectTbpMcLblIsuPreisu.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN \n");
			sql.append("   FROM TBP_MC_LBL_ISU_PREISU \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return (TbpMcLblIsuPreisuDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbpMcLblIsuPreisuDVO returnTbpMcLblIsuPreisuDVO = new TbpMcLblIsuPreisuDVO();
									returnTbpMcLblIsuPreisuDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbpMcLblIsuPreisuDVO.setNmgSeq(resultSet.getBigDecimal("NMG_SEQ"));
									returnTbpMcLblIsuPreisuDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbpMcLblIsuPreisuDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbpMcLblIsuPreisuDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbpMcLblIsuPreisuDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbpMcLblIsuPreisuDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbpMcLblIsuPreisuDVO.setRePrtYn(resultSet.getString("RE_PRT_YN"));
									returnTbpMcLblIsuPreisuDVO.setRePrtRsn(resultSet.getString("RE_PRT_RSN"));
									return returnTbpMcLblIsuPreisuDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbpMcLblIsuPreisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbpMcLblIsuPreisu Method")
	public int mergeTbpMcLblIsuPreisu (final TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO) {
		
		if ( selectTbpMcLblIsuPreisu (tbpMcLblIsuPreisuDVO) == null) {
			return insertTbpMcLblIsuPreisu(tbpMcLblIsuPreisuDVO);
		} else {
			return selectUpdateTbpMcLblIsuPreisu (tbpMcLblIsuPreisuDVO);
		}
	}

	/**
	 * selectUpdateTbpMcLblIsuPreisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbpMcLblIsuPreisu Method")
	public int selectUpdateTbpMcLblIsuPreisu (final TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO) {
		
		TbpMcLblIsuPreisuDVO tmpTbpMcLblIsuPreisuDVO =  selectTbpMcLblIsuPreisu (tbpMcLblIsuPreisuDVO);
		if ( tbpMcLblIsuPreisuDVO.getNmgId() != null && !"".equals(tbpMcLblIsuPreisuDVO.getNmgId()) ) {
			tmpTbpMcLblIsuPreisuDVO.setNmgId(tbpMcLblIsuPreisuDVO.getNmgId());
		}		
		if ( tbpMcLblIsuPreisuDVO.getNmgSeq() != null && !"".equals(tbpMcLblIsuPreisuDVO.getNmgSeq()) ) {
			tmpTbpMcLblIsuPreisuDVO.setNmgSeq(tbpMcLblIsuPreisuDVO.getNmgSeq());
		}		
		if ( tbpMcLblIsuPreisuDVO.getPrtDt() != null && !"".equals(tbpMcLblIsuPreisuDVO.getPrtDt()) ) {
			tmpTbpMcLblIsuPreisuDVO.setPrtDt(tbpMcLblIsuPreisuDVO.getPrtDt());
		}		
		if ( tbpMcLblIsuPreisuDVO.getPlantCode() != null && !"".equals(tbpMcLblIsuPreisuDVO.getPlantCode()) ) {
			tmpTbpMcLblIsuPreisuDVO.setPlantCode(tbpMcLblIsuPreisuDVO.getPlantCode());
		}		
		if ( tbpMcLblIsuPreisuDVO.getModelCode() != null && !"".equals(tbpMcLblIsuPreisuDVO.getModelCode()) ) {
			tmpTbpMcLblIsuPreisuDVO.setModelCode(tbpMcLblIsuPreisuDVO.getModelCode());
		}		
		if ( tbpMcLblIsuPreisuDVO.getLabelId() != null && !"".equals(tbpMcLblIsuPreisuDVO.getLabelId()) ) {
			tmpTbpMcLblIsuPreisuDVO.setLabelId(tbpMcLblIsuPreisuDVO.getLabelId());
		}		
		if ( tbpMcLblIsuPreisuDVO.getPrterId() != null && !"".equals(tbpMcLblIsuPreisuDVO.getPrterId()) ) {
			tmpTbpMcLblIsuPreisuDVO.setPrterId(tbpMcLblIsuPreisuDVO.getPrterId());
		}		
		if ( tbpMcLblIsuPreisuDVO.getRePrtYn() != null && !"".equals(tbpMcLblIsuPreisuDVO.getRePrtYn()) ) {
			tmpTbpMcLblIsuPreisuDVO.setRePrtYn(tbpMcLblIsuPreisuDVO.getRePrtYn());
		}		
		if ( tbpMcLblIsuPreisuDVO.getRePrtRsn() != null && !"".equals(tbpMcLblIsuPreisuDVO.getRePrtRsn()) ) {
			tmpTbpMcLblIsuPreisuDVO.setRePrtRsn(tbpMcLblIsuPreisuDVO.getRePrtRsn());
		}		
		return updateTbpMcLblIsuPreisu (tmpTbpMcLblIsuPreisuDVO);
	}

/**
* insertBatchTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return int[]
*/
	@LocalName("insertBatchTbpMcLblIsuPreisu")
	public int[] insertBatchTbpMcLblIsuPreisu (final List tbpMcLblIsuPreisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.insertBatchTbpMcLblIsuPreisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_PREISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO = (TbpMcLblIsuPreisuDVO)tbpMcLblIsuPreisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtRsn());

						}
							public int getBatchSize() {
									return tbpMcLblIsuPreisuDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return int[]
*/
	@LocalName("updateBatchTbpMcLblIsuPreisu")
	public int[] updateBatchTbpMcLblIsuPreisu (final List tbpMcLblIsuPreisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.updateBatchTbpMcLblIsuPreisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_PREISU \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND NMG_SEQ = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO = (TbpMcLblIsuPreisuDVO)tbpMcLblIsuPreisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getRePrtRsn());

							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLblIsuPreisuDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbpMcLblIsuPreisu Method
* 
* @ref_table TBP_MC_LBL_ISU_PREISU
* @return int[]
*/
	@LocalName("deleteBatchTbpMcLblIsuPreisu")
	public int[] deleteBatchTbpMcLblIsuPreisu (final List tbpMcLblIsuPreisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLblIsuPreisuDEM.deleteBatchTbpMcLblIsuPreisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_PREISU \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuPreisuDVO tbpMcLblIsuPreisuDVO = (TbpMcLblIsuPreisuDVO)tbpMcLblIsuPreisuDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLblIsuPreisuDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLblIsuPreisuDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLblIsuPreisuDVOList.size();
							}
					}
		);			
	}

	
}