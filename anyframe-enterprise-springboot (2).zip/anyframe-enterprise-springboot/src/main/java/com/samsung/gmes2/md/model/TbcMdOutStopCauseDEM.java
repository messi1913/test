package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdOutStopCauseDEM extends AbstractDAO {


/**
* insertTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return int
*/
	@LocalName("insertTbcMdOutStopCause")
	public int insertTbcMdOutStopCause (final TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.insertTbcMdOutStopCause.001*/  \n");
			sql.append(" TBC_MD_OUT_STOP_CAUSE (   \n");
			sql.append("        OUT_STOP_CAUSE_CODE , \n");
			sql.append("        OUT_STOP_CAUSE_NM , \n");
			sql.append("        REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseNm());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdOutStopCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdOutStopCause Method")
	public int[][] updateBatchAllTbcMdOutStopCause (final List  tbcMdOutStopCauseDVOList) {
		
		ArrayList updatetbcMdOutStopCauseDVOList = new ArrayList();
		ArrayList insertttbcMdOutStopCauseDVOList = new ArrayList();
		ArrayList deletetbcMdOutStopCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdOutStopCauseDVOList.size() ; i++) {
		  TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO = (TbcMdOutStopCauseDVO) tbcMdOutStopCauseDVOList.get(i);
		  
		  if (tbcMdOutStopCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdOutStopCauseDVOList.add(tbcMdOutStopCauseDVO);
		  else if (tbcMdOutStopCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdOutStopCauseDVOList.add(tbcMdOutStopCauseDVO);
		  else if (tbcMdOutStopCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdOutStopCauseDVOList.add(tbcMdOutStopCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdOutStopCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdOutStopCause(insertttbcMdOutStopCauseDVOList);
          
      if (updatetbcMdOutStopCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdOutStopCause(updatetbcMdOutStopCauseDVOList);
      
      if (deletetbcMdOutStopCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdOutStopCause(deletetbcMdOutStopCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return int
*/
	@LocalName("updateTbcMdOutStopCause")
	public int updateTbcMdOutStopCause (final TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.updateTbcMdOutStopCause.001*/  \n");
			sql.append(" TBC_MD_OUT_STOP_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        OUT_STOP_CAUSE_NM = ? , \n");
			sql.append("        REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE OUT_STOP_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseNm());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdOutStopCause")
	public int deleteTbcMdOutStopCause (final TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.deleteTbcMdOutStopCause.001*/  \n");
			sql.append(" TBC_MD_OUT_STOP_CAUSE \n");
			sql.append("  WHERE OUT_STOP_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return TbcMdOutStopCauseDVO 
*/
	@LocalName("selectTbcMdOutStopCause")
	public TbcMdOutStopCauseDVO selectTbcMdOutStopCause (final TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.selectTbcMdOutStopCause.001*/  \n");
			sql.append("        OUT_STOP_CAUSE_CODE , \n");
			sql.append("        OUT_STOP_CAUSE_NM , \n");
			sql.append("        REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_OUT_STOP_CAUSE \n");
			sql.append("  WHERE OUT_STOP_CAUSE_CODE = ? \n");

		return (TbcMdOutStopCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdOutStopCauseDVO returnTbcMdOutStopCauseDVO = new TbcMdOutStopCauseDVO();
									returnTbcMdOutStopCauseDVO.setOutStopCauseCode(resultSet.getString("OUT_STOP_CAUSE_CODE"));
									returnTbcMdOutStopCauseDVO.setOutStopCauseNm(resultSet.getString("OUT_STOP_CAUSE_NM"));
									returnTbcMdOutStopCauseDVO.setReflYn(resultSet.getString("REFL_YN"));
									returnTbcMdOutStopCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdOutStopCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdOutStopCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdOutStopCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdOutStopCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdOutStopCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdOutStopCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdOutStopCause Method")
	public int mergeTbcMdOutStopCause (final TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO) {
		
		if ( selectTbcMdOutStopCause (tbcMdOutStopCauseDVO) == null) {
			return insertTbcMdOutStopCause(tbcMdOutStopCauseDVO);
		} else {
			return selectUpdateTbcMdOutStopCause (tbcMdOutStopCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdOutStopCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdOutStopCause Method")
	public int selectUpdateTbcMdOutStopCause (final TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO) {
		
		TbcMdOutStopCauseDVO tmpTbcMdOutStopCauseDVO =  selectTbcMdOutStopCause (tbcMdOutStopCauseDVO);
		if ( tbcMdOutStopCauseDVO.getOutStopCauseCode() != null && !"".equals(tbcMdOutStopCauseDVO.getOutStopCauseCode()) ) {
			tmpTbcMdOutStopCauseDVO.setOutStopCauseCode(tbcMdOutStopCauseDVO.getOutStopCauseCode());
		}		
		if ( tbcMdOutStopCauseDVO.getOutStopCauseNm() != null && !"".equals(tbcMdOutStopCauseDVO.getOutStopCauseNm()) ) {
			tmpTbcMdOutStopCauseDVO.setOutStopCauseNm(tbcMdOutStopCauseDVO.getOutStopCauseNm());
		}		
		if ( tbcMdOutStopCauseDVO.getReflYn() != null && !"".equals(tbcMdOutStopCauseDVO.getReflYn()) ) {
			tmpTbcMdOutStopCauseDVO.setReflYn(tbcMdOutStopCauseDVO.getReflYn());
		}		
		if ( tbcMdOutStopCauseDVO.getUseYn() != null && !"".equals(tbcMdOutStopCauseDVO.getUseYn()) ) {
			tmpTbcMdOutStopCauseDVO.setUseYn(tbcMdOutStopCauseDVO.getUseYn());
		}		
		if ( tbcMdOutStopCauseDVO.getFstRegDt() != null && !"".equals(tbcMdOutStopCauseDVO.getFstRegDt()) ) {
			tmpTbcMdOutStopCauseDVO.setFstRegDt(tbcMdOutStopCauseDVO.getFstRegDt());
		}		
		if ( tbcMdOutStopCauseDVO.getFstRegerId() != null && !"".equals(tbcMdOutStopCauseDVO.getFstRegerId()) ) {
			tmpTbcMdOutStopCauseDVO.setFstRegerId(tbcMdOutStopCauseDVO.getFstRegerId());
		}		
		if ( tbcMdOutStopCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdOutStopCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdOutStopCauseDVO.setFnlUpdDt(tbcMdOutStopCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdOutStopCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdOutStopCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdOutStopCauseDVO.setFnlUpderId(tbcMdOutStopCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdOutStopCause (tmpTbcMdOutStopCauseDVO);
	}

/**
* insertBatchTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdOutStopCause")
	public int[] insertBatchTbcMdOutStopCause (final List tbcMdOutStopCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.insertBatchTbcMdOutStopCause.001*/  \n");
			sql.append(" TBC_MD_OUT_STOP_CAUSE (   \n");
			sql.append("        OUT_STOP_CAUSE_CODE , \n");
			sql.append("        OUT_STOP_CAUSE_NM , \n");
			sql.append("        REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO = (TbcMdOutStopCauseDVO)tbcMdOutStopCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseNm());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdOutStopCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdOutStopCause")
	public int[] updateBatchTbcMdOutStopCause (final List tbcMdOutStopCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.updateBatchTbcMdOutStopCause.001*/  \n");
			sql.append(" TBC_MD_OUT_STOP_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        OUT_STOP_CAUSE_NM = ? , \n");
			sql.append("        REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE OUT_STOP_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO = (TbcMdOutStopCauseDVO)tbcMdOutStopCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseNm());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdOutStopCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
						}
							public int getBatchSize() {
									return tbcMdOutStopCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdOutStopCause Method
* 
* @ref_table TBC_MD_OUT_STOP_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdOutStopCause")
	public int[] deleteBatchTbcMdOutStopCause (final List tbcMdOutStopCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdOutStopCauseDEM.deleteBatchTbcMdOutStopCause.001*/  \n");
			sql.append(" TBC_MD_OUT_STOP_CAUSE \n");
			sql.append("  WHERE OUT_STOP_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdOutStopCauseDVO tbcMdOutStopCauseDVO = (TbcMdOutStopCauseDVO)tbcMdOutStopCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdOutStopCauseDVO.getOutStopCauseCode());
						}
							public int getBatchSize() {
									return tbcMdOutStopCauseDVOList.size();
							}
					}
		);			
	}

	
}