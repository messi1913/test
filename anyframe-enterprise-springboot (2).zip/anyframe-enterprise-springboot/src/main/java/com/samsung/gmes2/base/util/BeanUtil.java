package com.samsung.gmes2.base.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.AbstractRefreshableApplicationContext;
import org.springframework.context.support.GenericApplicationContext;

public class BeanUtil implements ApplicationContextAware
{
    private static final Logger        logger        = LoggerFactory.getLogger( BeanUtil.class );

    private static ApplicationContext  applicationContext;

    private static Map<String, Object> beanByNameMap = Collections.synchronizedMap( new HashMap<String, Object>( ) );

    /**
     * className 에 해당하는 Bean 을 (아직 로딩되지 않았다면) 로딩합니다.
     * 
     * @param <T>
     * @param className
     */
    public static <T> void load( String className )
    {
        // className 에 '.' 이 있을 때에만 로딩.
        if ( !className.contains( "." ) )
            return;
        try
        {
            // className 에 해당하는 Class 조회
            Class<?> clazz = ReflectionUtil.getClass( className );
            // 이미 조회된 적인 있는 Bean 이면 스킵
            if ( beanByClassMap.containsKey( clazz ) )
                return;
            // clazz 유형의 Bean 을 얻어옴으로써 (아직 로딩되지 않은 Bean 인 경우) Bean 로딩
            get( clazz );
        }
        catch ( Exception e )
        {
            logger.warn( e.getMessage( ), e );
        }
    }

    /**
     * Bean 이름이 name 인 Bean 을 requiredType 유형으로 조회합니다.
     * 
     * @param <T>
     * @param name
     * @param requiredType
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> T get( String name, Class<T> requiredType )
    {
        Object obj = get( name );
        if ( requiredType != null && !requiredType.isAssignableFrom( obj.getClass( ) ) )
            throw new BeanNotOfRequiredTypeException( name, requiredType, obj.getClass( ) );
        return (T) obj;
    }

    /**
     * Bean 이름이 name 인 Bean 을 조회합니다.
     * 
     * @param name
     * @return
     */
    public static Object get( String name )
    {
        if ( beanByNameMap.containsKey( name ) )
            return beanByNameMap.get( name );
        synchronized (MonitorUtil.get( name ))
        {
            try
            {
                if ( beanByNameMap.containsKey( name ) )
                    return beanByNameMap.get( name );
                Object bean = applicationContext.getBean( name );
                beanByNameMap.put( name, bean );
                return bean;
            }
            finally
            {
                MonitorUtil.expire( name );
            }
        }
    }

    private static Map<Class<?>, Object> beanByClassMap = Collections.synchronizedMap( new HashMap<Class<?>, Object>( ) );

    @SuppressWarnings("unchecked")
    public static <T> T get( Class<T> clazz )
    {
        if ( beanByClassMap.containsKey( clazz ) )
            return (T) beanByClassMap.get( clazz );
        String className = clazz.getName( );
        synchronized (MonitorUtil.get( className ))
        {
            try
            {
                if ( beanByClassMap.containsKey( clazz ) )
                    return (T) beanByClassMap.get( clazz );

                T bean = null;
                try
                {
                    try
                    {
                        bean = (T) applicationContext.getBean( clazz );
                    }
                    catch ( NoSuchBeanDefinitionException e )
                    {
                        bean = (T) applicationContext.getBean( className );
                    }
                    beanByClassMap.put( clazz, bean );
                }
                catch ( NoSuchBeanDefinitionException e )
                {
                    if ( applicationContext instanceof GenericApplicationContext )
                    {
                        BeanDefinition bd = BeanDefinitionBuilder.genericBeanDefinition( clazz ).getBeanDefinition( );
                        GenericApplicationContext gac = (GenericApplicationContext) applicationContext;
                        gac.registerBeanDefinition( className, bd );
                        bean = applicationContext.getBean( clazz );
                        beanByClassMap.put( clazz, bean );
                    }
                    else if ( applicationContext instanceof AbstractRefreshableApplicationContext )
                    {
                        BeanDefinition bd = BeanDefinitionBuilder.rootBeanDefinition( clazz ).getBeanDefinition( );
                        AbstractRefreshableApplicationContext arac = (AbstractRefreshableApplicationContext) applicationContext;
                        DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) arac.getBeanFactory( );
                        beanFactory.registerBeanDefinition( className, bd );
                        bean = applicationContext.getBean( clazz );
                        beanByClassMap.put( clazz, bean );
                    }
                    else
                    {
                        throw e;
                    }
                }
                return bean;
            }
            finally
            {
                MonitorUtil.expire( className );
            }
        }
    }

    public void setApplicationContext( ApplicationContext applicationContext ) throws BeansException
    {
        BeanUtil.applicationContext = applicationContext;
    }
}
