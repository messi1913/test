/**
 * <PRE>

 * System Name : G-MES 2.0
 * Business Name : 개발템플릿 (MD) – Plant 코드 조회
 * Class Name : MdManageTbcMdPlantBiz.java
 * Description : Plant 코드 에 대한 테이블을 조회하는 Biz 클래스
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------     ---------    ---------------------------
 *    2011.07.25      김상민          최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */

package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.md.model.TbcMdPlantDVO;

/**
 * 한글명 :  Plant 코드 조회
 * 작성일 : 2011.07.25 
 * 작성자 : 김 상 민 
 * 작업상태 : 완료 
 * 개요 :  Plant 코드 조회를 위한 조건들을 검색해 해당 조건에 맞는 정보를 보내준다.
 * 
 * @name_ko  Plant 코드 조회
 */

public class MdManageTbcMdPlantBiz {

	/**
	 * Primary Key, Not Null, Foreign Key 의 Null 체크 및
	 * Foreign Key 의 DATA 유효성을 체크 한다.
	 * @name_ko 모든 필요, 필수 값들을 체크하는 메서드
	 */
	private void checkingAllValidation(TbcMdPlantDVO inputDVO) throws Exception {
		
		/*--------------------------------------------------
		 * @fd_call_start BaseUtil.checkNotEmpty
		 * @fd_id 0001
		 * 필수 값인 Primary Key, Not Null, Foreign key
		 * 체크 후 없으면 Excpetion
		 --------------------------------------------------*/
		
		BaseUtil.checkNotEmpty(inputDVO);
		
		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start BaseUtil.populate 호출
		 * @fd_id 0002
		 * 하나의 DVO 에서 다른 DVO 로 값들을 복사하는 메서드
		 * 값이 들어온 DVO 에 값들중 참조 FK 의 값들을 참조 테이블DVO
		 * 에 복사를 한다.
		 * 복사를 하는 이유는 해당 참조 테이블 DVO 에 값들과 참조 테이블의
		 * 실제 값이 같은 것이 있는지를 알아보기 위해서이다.
		 --------------------------------------------------*/
		TbcMdCommOrgDVO tbcMdCommOrgDVO = new TbcMdCommOrgDVO();
		BaseUtil.populate(inputDVO, tbcMdCommOrgDVO, "fctCode:commOrgCode");
		BaseUtil.checkFound(tbcMdCommOrgDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_call_start BaseUtil.checkFound
		 * @fd_id 0003
		 * 각 테이블에서 참조하는 Foreign Key 값이 유효한 DATA 인지,
		 * 즉 인서트나 업데이트시 들어온 FK DATA 가 참조 TABLE 에 존재
		 * 하는 DATA 인지 확인하는 메서드 
		 * 없을시 Exception 을 날린다.
		 --------------------------------------------------*/

		BaseUtil.populate(inputDVO, tbcMdCommOrgDVO, "gbmCode:commOrgCode");
		BaseUtil.checkFound(tbcMdCommOrgDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0003
		 --------------------------------------------------*/
	}

	public TbcMdPlantDVO createTbcMdPlant(TbcMdPlantDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * 앞에서 한 메서드 를 통해 값들의 validation 을 체크한다.
		 --------------------------------------------------*/

		checkingAllValidation(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.create
		 * @fd_id 0002
		 * Primary Key, not Null, FK 등의 필수 입력값 확인후
		 * 이상이 없을시 insert 하는 메서드
		 * 수정일시는 값이 들어오지 않을시 DB 기준 현재시간을 update 한다.
		 * USE_YN 이 "N" 일 경우 update 되지않고 Exception 을 낸다.
		 --------------------------------------------------*/
		return CrudUtil.create(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/

	}

	public TbcMdPlantDVO updateTbcMdPlant(TbcMdPlantDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * 앞에서 한 메서드 를 통해 값들의 validation 을 체크한다.
		 --------------------------------------------------*/

		checkingAllValidation(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.update
		 * @fd_id 0002
		 * Primary Key, not Null, FK 등의 필수 입력값 확인후
		 * 이상이 없을시 update 하는 메서드
		 * 수정일시는 값이 들어오지 않을시 DB 기준 현재시간을 insert 하고
		 * USE_YN 칼럼은 Y 로 insert 한다.
		 --------------------------------------------------*/
		return CrudUtil.update(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/

	}

	public TbcMdPlantDVO deleteTbcMdPlant(TbcMdPlantDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * Pk 값이 있는 지 없는지를 확인하는 메서드
		 --------------------------------------------------*/

		BaseUtil.checkNotEmpty(inputDVO,"plantCode");

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.delete
		 * @fd_id 0002
		 * Primary Key 필수 입력값 확인후
		 * 이상이 없을시 delete 하는 메서드
		 * 실제적 삭제가 아닌 USE_YN 컬럼을 N 으로 업데이트한다.
		 * 수정 일시는 값이 들어오지 않을시 DB 기준 현재시간을 update 한다.
		 --------------------------------------------------*/

		return CrudUtil.delete(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/

	}

	public TbcMdPlantDVO getTbcMdPlant(TbcMdPlantDVO inputDVO) throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * 앞에서 한 메서드 를 통해 값들의 validation 을 체크한다.
		 --------------------------------------------------*/

		//BaseUtil.checkNotEmpty(inputDVO, "plantCode");

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.get
		 * @fd_id 0002
		 * Primary Key 필수 입력값 확인후
		 * 이상이 없을시 select 하는 메서드
		 * 해당 Primary key 에 대한 Data 를 1Row 로 가져온다.
		 --------------------------------------------------*/
		
		return CrudUtil.get(inputDVO);
		
		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/

	}

	public List<TbcMdPlantDVO> listTbcMdPlant(TbcMdPlantDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.list
		 * @fd_id 0002
		 * Primary Key, not Null, FK 등의 필수 입력값 확인 없이
		 * 해당 컬럼중 찾고자 하는 Data 가 들어오면 그 DATA 에 해당하는
		 * 결과값을 List(배열) 로 SELECT 하는 메서드
		 --------------------------------------------------*/

		return CrudUtil.list0(TbcMdPlantDVO.class, inputDVO, 0, 0);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/

	}

}
