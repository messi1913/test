package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_INSP_CLSF
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdInspClsfDEM extends AbstractDAO {


/**
* insertTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return int
*/
	@LocalName("insertTbcMdInspClsf")
	public int insertTbcMdInspClsf (final TbcMdInspClsfDVO tbcMdInspClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.insertTbcMdInspClsf.001*/  \n");
			sql.append(" TBC_MD_INSP_CLSF (   \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        INSP_CLSF_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        INSP_LAGE_CLSF_CODE , \n");
			sql.append("        INSP_MID_CLSF_CODE , \n");
			sql.append("        USE_YN \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfNm());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspLageClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspMidClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getUseYn());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdInspClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdInspClsf Method")
	public int[][] updateBatchAllTbcMdInspClsf (final List  tbcMdInspClsfDVOList) {
		
		ArrayList updatetbcMdInspClsfDVOList = new ArrayList();
		ArrayList insertttbcMdInspClsfDVOList = new ArrayList();
		ArrayList deletetbcMdInspClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdInspClsfDVOList.size() ; i++) {
		  TbcMdInspClsfDVO tbcMdInspClsfDVO = (TbcMdInspClsfDVO) tbcMdInspClsfDVOList.get(i);
		  
		  if (tbcMdInspClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdInspClsfDVOList.add(tbcMdInspClsfDVO);
		  else if (tbcMdInspClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdInspClsfDVOList.add(tbcMdInspClsfDVO);
		  else if (tbcMdInspClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdInspClsfDVOList.add(tbcMdInspClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdInspClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdInspClsf(insertttbcMdInspClsfDVOList);
          
      if (updatetbcMdInspClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdInspClsf(updatetbcMdInspClsfDVOList);
      
      if (deletetbcMdInspClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdInspClsf(deletetbcMdInspClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return int
*/
	@LocalName("updateTbcMdInspClsf")
	public int updateTbcMdInspClsf (final TbcMdInspClsfDVO tbcMdInspClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.updateTbcMdInspClsf.001*/  \n");
			sql.append(" TBC_MD_INSP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        INSP_CLSF_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        INSP_LAGE_CLSF_CODE = ? , \n");
			sql.append("        INSP_MID_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? \n");
			sql.append(" WHERE INSP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfNm());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspLageClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspMidClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getUseYn());

							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return int
*/
	@LocalName("deleteTbcMdInspClsf")
	public int deleteTbcMdInspClsf (final TbcMdInspClsfDVO tbcMdInspClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.deleteTbcMdInspClsf.001*/  \n");
			sql.append(" TBC_MD_INSP_CLSF \n");
			sql.append("  WHERE INSP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return TbcMdInspClsfDVO 
*/
	@LocalName("selectTbcMdInspClsf")
	public TbcMdInspClsfDVO selectTbcMdInspClsf (final TbcMdInspClsfDVO tbcMdInspClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.selectTbcMdInspClsf.001*/  \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        INSP_CLSF_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        INSP_LAGE_CLSF_CODE , \n");
			sql.append("        INSP_MID_CLSF_CODE , \n");
			sql.append("        USE_YN \n");
			sql.append("   FROM TBC_MD_INSP_CLSF \n");
			sql.append("  WHERE INSP_CLSF_CODE = ? \n");

		return (TbcMdInspClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdInspClsfDVO returnTbcMdInspClsfDVO = new TbcMdInspClsfDVO();
									returnTbcMdInspClsfDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspClsfNm(resultSet.getString("INSP_CLSF_NM"));
									returnTbcMdInspClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbcMdInspClsfDVO.setInspLageClsfCode(resultSet.getString("INSP_LAGE_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspMidClsfCode(resultSet.getString("INSP_MID_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									return returnTbcMdInspClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdInspClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdInspClsf Method")
	public int mergeTbcMdInspClsf (final TbcMdInspClsfDVO tbcMdInspClsfDVO) {
		
		if ( selectTbcMdInspClsf (tbcMdInspClsfDVO) == null) {
			return insertTbcMdInspClsf(tbcMdInspClsfDVO);
		} else {
			return selectUpdateTbcMdInspClsf (tbcMdInspClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdInspClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdInspClsf Method")
	public int selectUpdateTbcMdInspClsf (final TbcMdInspClsfDVO tbcMdInspClsfDVO) {
		
		TbcMdInspClsfDVO tmpTbcMdInspClsfDVO =  selectTbcMdInspClsf (tbcMdInspClsfDVO);
		if ( tbcMdInspClsfDVO.getInspClsfCode() != null && !"".equals(tbcMdInspClsfDVO.getInspClsfCode()) ) {
			tmpTbcMdInspClsfDVO.setInspClsfCode(tbcMdInspClsfDVO.getInspClsfCode());
		}		
		if ( tbcMdInspClsfDVO.getInspClsfNm() != null && !"".equals(tbcMdInspClsfDVO.getInspClsfNm()) ) {
			tmpTbcMdInspClsfDVO.setInspClsfNm(tbcMdInspClsfDVO.getInspClsfNm());
		}		
		if ( tbcMdInspClsfDVO.getFstRegDt() != null && !"".equals(tbcMdInspClsfDVO.getFstRegDt()) ) {
			tmpTbcMdInspClsfDVO.setFstRegDt(tbcMdInspClsfDVO.getFstRegDt());
		}		
		if ( tbcMdInspClsfDVO.getFstRegerId() != null && !"".equals(tbcMdInspClsfDVO.getFstRegerId()) ) {
			tmpTbcMdInspClsfDVO.setFstRegerId(tbcMdInspClsfDVO.getFstRegerId());
		}		
		if ( tbcMdInspClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdInspClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdInspClsfDVO.setFnlUpdDt(tbcMdInspClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdInspClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdInspClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdInspClsfDVO.setFnlUpderId(tbcMdInspClsfDVO.getFnlUpderId());
		}		
		if ( tbcMdInspClsfDVO.getInspLageClsfCode() != null && !"".equals(tbcMdInspClsfDVO.getInspLageClsfCode()) ) {
			tmpTbcMdInspClsfDVO.setInspLageClsfCode(tbcMdInspClsfDVO.getInspLageClsfCode());
		}		
		if ( tbcMdInspClsfDVO.getInspMidClsfCode() != null && !"".equals(tbcMdInspClsfDVO.getInspMidClsfCode()) ) {
			tmpTbcMdInspClsfDVO.setInspMidClsfCode(tbcMdInspClsfDVO.getInspMidClsfCode());
		}		
		if ( tbcMdInspClsfDVO.getUseYn() != null && !"".equals(tbcMdInspClsfDVO.getUseYn()) ) {
			tmpTbcMdInspClsfDVO.setUseYn(tbcMdInspClsfDVO.getUseYn());
		}		
		return updateTbcMdInspClsf (tmpTbcMdInspClsfDVO);
	}

/**
* insertBatchTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdInspClsf")
	public int[] insertBatchTbcMdInspClsf (final List tbcMdInspClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.insertBatchTbcMdInspClsf.001*/  \n");
			sql.append(" TBC_MD_INSP_CLSF (   \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        INSP_CLSF_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        INSP_LAGE_CLSF_CODE , \n");
			sql.append("        INSP_MID_CLSF_CODE , \n");
			sql.append("        USE_YN \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdInspClsfDVO tbcMdInspClsfDVO = (TbcMdInspClsfDVO)tbcMdInspClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfNm());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspLageClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspMidClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getUseYn());

						}
							public int getBatchSize() {
									return tbcMdInspClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdInspClsf")
	public int[] updateBatchTbcMdInspClsf (final List tbcMdInspClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.updateBatchTbcMdInspClsf.001*/  \n");
			sql.append(" TBC_MD_INSP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        INSP_CLSF_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        INSP_LAGE_CLSF_CODE = ? , \n");
			sql.append("        INSP_MID_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? \n");
			sql.append(" WHERE INSP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdInspClsfDVO tbcMdInspClsfDVO = (TbcMdInspClsfDVO)tbcMdInspClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfNm());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspClsfDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspLageClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getInspMidClsfCode());
							ps.setString(psCount++, tbcMdInspClsfDVO.getUseYn());

							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
						}
							public int getBatchSize() {
									return tbcMdInspClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdInspClsf Method
* 
* @ref_table TBC_MD_INSP_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdInspClsf")
	public int[] deleteBatchTbcMdInspClsf (final List tbcMdInspClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdInspClsfDEM.deleteBatchTbcMdInspClsf.001*/  \n");
			sql.append(" TBC_MD_INSP_CLSF \n");
			sql.append("  WHERE INSP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdInspClsfDVO tbcMdInspClsfDVO = (TbcMdInspClsfDVO)tbcMdInspClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdInspClsfDVO.getInspClsfCode());
						}
							public int getBatchSize() {
									return tbcMdInspClsfDVOList.size();
							}
					}
		);			
	}

	
}