/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbcMdCellTypeBiz
 * Description : 테이블 TbcMdCellType 에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.19          김영준          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCellTypeDVO;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.md.model.TbcMdMfgTeamDVO;

public class MdManageTbcMdCellTypeBiz {


	/**
	 * CrudUtil 클래스의 create 메서드 재사용
	 * 
	 * 테이블에 해당하는 기본키가 입력되어있는지 확인합니다.
	 * NotNull이 되지않아야할 컬럼에 데이터가 존재하는지 확인합니다.
	 * 
	 * 만약 기존에 존재하는 데이터가 있으면 Insert되면 안됩니다.
	 * 만약 기존에 데이터가 존재하는데 useYn이 'N' 이면 기존에 데이터를 지우고 새롭게 넣습니다. 전데이터가 리셋
	 * (useYn도 'Y'로 바뀝니다.)
	 * 
	 * 최초데이터 입력시간과 데이터 입력자ID useYn 최근입력시간, 최근입력자 아이뒤는 Insert시 기본적으로 입력됩니다.
	 * 
	 */
	public TbcMdCellTypeDVO createTbcMdCellType(TbcMdCellTypeDVO tbcMdCellTypeDVO)throws Exception {
		return CrudUtil.create(tbcMdCellTypeDVO);
	}

	/**
	 * CrudUtil 클래스의 delete 메서드 재사용
	 * 
	 * Delete전 데이터의 컬럼중 useYn이 'Y'이면 useYn을 'N'으로 변경합니다.
	 * useYn이 'N'일경우 데이터를 또 지우려고 하면 Exception을 발생하고 메세지처리후 종료합니다.
	 * 기본키를 기본조건으로 delete합니다.
	 */
	public void deleteTbcMdCellType(TbcMdCellTypeDVO tbcMdCellTypeDVO)throws Exception {
		CrudUtil.delete(tbcMdCellTypeDVO);
	}

	/**
	 * CrudUtil 클래스의 update 메서드 재사용
	 * 
	 * 미처리 : 데이터 Update시 최초등록시간, 최초등록자 아이디
	 * 
	 * useYn이 'N'일경우 데이터를 Update할 수 없습니다.
	 * useYn이 'Y'일경우만 데이터를 Update할 수 있습니다.
	 * 기본키를 기본조건으로 Update합니다.
	 * 
	 */
	public void updateTbcMdCellType(TbcMdCellTypeDVO tbcMdCellTypeDVO)throws Exception {
		CrudUtil.update(tbcMdCellTypeDVO);
	}
	
	/**
	 * CrudUtil 클래스의 select 메서드 재사용
	 * 
	 * useYn이 'N'일경우 데이터를 Select 할 수 없습니다.
	 * useYn이 'Y'일경우만 데이터를 Select 할 수 있습니다.
	 * 기본키를 기본조건으로 Select 합니다.
	 */
	public TbcMdCellTypeDVO getTbcMdCellType(TbcMdCellTypeDVO tbcMdCellTypeDVO)throws Exception {
		return CrudUtil.get(tbcMdCellTypeDVO);
	}
	
	
	/**
	 * CrudUtil 클래스의 list 메서드 재사용
	 * 
	 * useYn이 'N'일경우 데이터를 Select 할 수 없습니다.
	 * useYn이 'Y'일경우만 데이터를 Select 할 수 있습니다.
	 * 기본키를 기본조건으로 Select 합니다.
	 */
	public List listTbcMdCellType(TbcMdCellTypeDVO tbcMdCellTypeDVO)throws Exception {		 
		return CrudUtil.list0(TbcMdCellTypeDVO.class,tbcMdCellTypeDVO, 0, 0);
	}
	
}
