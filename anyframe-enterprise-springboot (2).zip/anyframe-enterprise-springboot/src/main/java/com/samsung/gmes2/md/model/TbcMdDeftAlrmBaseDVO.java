package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author KYJ
 */
public class TbcMdDeftAlrmBaseDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String deftAlrmBaseCode;

	@Length(11) @Scale(5) 
	private BigDecimal deftOccBaseNum;

	@Length(2000) 
	private String deftOccBaseDesc;

    /**
     * 사용여부(Y/N)
     */
	@LocalName("사용여부") @Length(1) 
	private String useYn;

    /**
     * [일자]시스템속성으로 테이블에 최초등록일시를 나타냄
     */
	@LocalName("최초등록일시") @Length(14) 
	private String fstRegDt;

    /**
     * [ID]시스템속성으로 최초 시스템에 등록한 사용자 ID
     */
	@LocalName("최초등록자ID") @Length(50) 
	private String fstRegerId;

    /**
     * [일시]시스템속성으로 마지막으로 수정한 일시
     */
	@LocalName("최종수정일시") @Length(14) 
	private String fnlUpdDt;

    /**
     * [ID]시스템 속성으로 마지막으로 수정한 사용자 ID
     */
	@LocalName("최종수정자ID") @Length(50) 
	private String fnlUpderId;


	public String getDeftAlrmBaseCode() {
		this.deftAlrmBaseCode = super.getValue("deftAlrmBaseCode");
		return this.deftAlrmBaseCode;
	}

	public void setDeftAlrmBaseCode(String deftAlrmBaseCode) {
        super.setValue("deftAlrmBaseCode", deftAlrmBaseCode);
		this.deftAlrmBaseCode = deftAlrmBaseCode;
	}
	
	public BigDecimal getDeftOccBaseNum() {
		this.deftOccBaseNum = super.getValue("deftOccBaseNum");
		return this.deftOccBaseNum;
	}

	public void setDeftOccBaseNum(BigDecimal deftOccBaseNum) {
        super.setValue("deftOccBaseNum", deftOccBaseNum);
		this.deftOccBaseNum = deftOccBaseNum;
	}
	
	public String getDeftOccBaseDesc() {
		this.deftOccBaseDesc = super.getValue("deftOccBaseDesc");
		return this.deftOccBaseDesc;
	}

	public void setDeftOccBaseDesc(String deftOccBaseDesc) {
        super.setValue("deftOccBaseDesc", deftOccBaseDesc);
		this.deftOccBaseDesc = deftOccBaseDesc;
	}
	
	/**
	 * 사용여부 Getter Method
	 * 
	 * @return 사용여부
	 */
	@LocalName("사용여부 Getter Method")
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	/**
	 * 사용여부 Setter Method
	 * 
	 * @param String 사용여부
	 */
	@LocalName("사용여부 Setter Method")
	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	/**
	 * 최초등록일시 Getter Method
	 * 
	 * @return 최초등록일시
	 */
	@LocalName("최초등록일시 Getter Method")
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	/**
	 * 최초등록일시 Setter Method
	 * 
	 * @param String 최초등록일시
	 */
	@LocalName("최초등록일시 Setter Method")
	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	/**
	 * 최초등록자ID Getter Method
	 * 
	 * @return 최초등록자ID
	 */
	@LocalName("최초등록자ID Getter Method")
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	/**
	 * 최초등록자ID Setter Method
	 * 
	 * @param String 최초등록자ID
	 */
	@LocalName("최초등록자ID Setter Method")
	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	/**
	 * 최종수정일시 Getter Method
	 * 
	 * @return 최종수정일시
	 */
	@LocalName("최종수정일시 Getter Method")
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	/**
	 * 최종수정일시 Setter Method
	 * 
	 * @param String 최종수정일시
	 */
	@LocalName("최종수정일시 Setter Method")
	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	/**
	 * 최종수정자ID Getter Method
	 * 
	 * @return 최종수정자ID
	 */
	@LocalName("최종수정자ID Getter Method")
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	/**
	 * 최종수정자ID Setter Method
	 * 
	 * @param String 최종수정자ID
	 */
	@LocalName("최종수정자ID Setter Method")
	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}