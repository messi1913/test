package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PROC_TYPE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdProcTypeDEM extends AbstractDAO {


/**
* insertTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return int
*/
	@LocalName("insertTbcMdProcType")
	public int insertTbcMdProcType (final TbcMdProcTypeDVO tbcMdProcTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.insertTbcMdProcType.001*/  \n");
			sql.append(" TBC_MD_PROC_TYPE (   \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        PROC_TYPE_NM , \n");
			sql.append("        PROC_TYPE_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeNm());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeDesc());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdProcType Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdProcType Method")
	public int[][] updateBatchAllTbcMdProcType (final List  tbcMdProcTypeDVOList) {
		
		ArrayList updatetbcMdProcTypeDVOList = new ArrayList();
		ArrayList insertttbcMdProcTypeDVOList = new ArrayList();
		ArrayList deletetbcMdProcTypeDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdProcTypeDVOList.size() ; i++) {
		  TbcMdProcTypeDVO tbcMdProcTypeDVO = (TbcMdProcTypeDVO) tbcMdProcTypeDVOList.get(i);
		  
		  if (tbcMdProcTypeDVO.getSqlAction().equals("C"))
		      insertttbcMdProcTypeDVOList.add(tbcMdProcTypeDVO);
		  else if (tbcMdProcTypeDVO.getSqlAction().equals("U"))
		      updatetbcMdProcTypeDVOList.add(tbcMdProcTypeDVO);
		  else if (tbcMdProcTypeDVO.getSqlAction().equals("D"))
		      deletetbcMdProcTypeDVOList.add(tbcMdProcTypeDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdProcTypeDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdProcType(insertttbcMdProcTypeDVOList);
          
      if (updatetbcMdProcTypeDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdProcType(updatetbcMdProcTypeDVOList);
      
      if (deletetbcMdProcTypeDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdProcType(deletetbcMdProcTypeDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return int
*/
	@LocalName("updateTbcMdProcType")
	public int updateTbcMdProcType (final TbcMdProcTypeDVO tbcMdProcTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.updateTbcMdProcType.001*/  \n");
			sql.append(" TBC_MD_PROC_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        PROC_TYPE_NM = ? , \n");
			sql.append("        PROC_TYPE_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROC_GUBUN_CODE = ? \n");
			sql.append("   AND PROC_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeNm());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeDesc());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
						}
					}
		);			
	}

/**
* deleteTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return int
*/
	@LocalName("deleteTbcMdProcType")
	public int deleteTbcMdProcType (final TbcMdProcTypeDVO tbcMdProcTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.deleteTbcMdProcType.001*/  \n");
			sql.append(" TBC_MD_PROC_TYPE \n");
			sql.append("  WHERE PROC_GUBUN_CODE = ? \n");
			sql.append("    AND PROC_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
						}
					}
		);			
	}

/**
* selectTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return TbcMdProcTypeDVO 
*/
	@LocalName("selectTbcMdProcType")
	public TbcMdProcTypeDVO selectTbcMdProcType (final TbcMdProcTypeDVO tbcMdProcTypeDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.selectTbcMdProcType.001*/  \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        PROC_TYPE_NM , \n");
			sql.append("        PROC_TYPE_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PROC_TYPE \n");
			sql.append("  WHERE PROC_GUBUN_CODE = ? \n");
			sql.append("    AND PROC_TYPE_CODE = ? \n");

		return (TbcMdProcTypeDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdProcTypeDVO returnTbcMdProcTypeDVO = new TbcMdProcTypeDVO();
									returnTbcMdProcTypeDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdProcTypeDVO.setProcTypeCode(resultSet.getString("PROC_TYPE_CODE"));
									returnTbcMdProcTypeDVO.setProcTypeNm(resultSet.getString("PROC_TYPE_NM"));
									returnTbcMdProcTypeDVO.setProcTypeDesc(resultSet.getString("PROC_TYPE_DESC"));
									returnTbcMdProcTypeDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProcTypeDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProcTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProcTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProcTypeDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdProcType Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdProcType Method")
	public int mergeTbcMdProcType (final TbcMdProcTypeDVO tbcMdProcTypeDVO) {
		
		if ( selectTbcMdProcType (tbcMdProcTypeDVO) == null) {
			return insertTbcMdProcType(tbcMdProcTypeDVO);
		} else {
			return selectUpdateTbcMdProcType (tbcMdProcTypeDVO);
		}
	}

	/**
	 * selectUpdateTbcMdProcType Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdProcType Method")
	public int selectUpdateTbcMdProcType (final TbcMdProcTypeDVO tbcMdProcTypeDVO) {
		
		TbcMdProcTypeDVO tmpTbcMdProcTypeDVO =  selectTbcMdProcType (tbcMdProcTypeDVO);
		if ( tbcMdProcTypeDVO.getProcGubunCode() != null && !"".equals(tbcMdProcTypeDVO.getProcGubunCode()) ) {
			tmpTbcMdProcTypeDVO.setProcGubunCode(tbcMdProcTypeDVO.getProcGubunCode());
		}		
		if ( tbcMdProcTypeDVO.getProcTypeCode() != null && !"".equals(tbcMdProcTypeDVO.getProcTypeCode()) ) {
			tmpTbcMdProcTypeDVO.setProcTypeCode(tbcMdProcTypeDVO.getProcTypeCode());
		}		
		if ( tbcMdProcTypeDVO.getProcTypeNm() != null && !"".equals(tbcMdProcTypeDVO.getProcTypeNm()) ) {
			tmpTbcMdProcTypeDVO.setProcTypeNm(tbcMdProcTypeDVO.getProcTypeNm());
		}		
		if ( tbcMdProcTypeDVO.getProcTypeDesc() != null && !"".equals(tbcMdProcTypeDVO.getProcTypeDesc()) ) {
			tmpTbcMdProcTypeDVO.setProcTypeDesc(tbcMdProcTypeDVO.getProcTypeDesc());
		}		
		if ( tbcMdProcTypeDVO.getFstRegDt() != null && !"".equals(tbcMdProcTypeDVO.getFstRegDt()) ) {
			tmpTbcMdProcTypeDVO.setFstRegDt(tbcMdProcTypeDVO.getFstRegDt());
		}		
		if ( tbcMdProcTypeDVO.getFstRegerId() != null && !"".equals(tbcMdProcTypeDVO.getFstRegerId()) ) {
			tmpTbcMdProcTypeDVO.setFstRegerId(tbcMdProcTypeDVO.getFstRegerId());
		}		
		if ( tbcMdProcTypeDVO.getFnlUpdDt() != null && !"".equals(tbcMdProcTypeDVO.getFnlUpdDt()) ) {
			tmpTbcMdProcTypeDVO.setFnlUpdDt(tbcMdProcTypeDVO.getFnlUpdDt());
		}		
		if ( tbcMdProcTypeDVO.getFnlUpderId() != null && !"".equals(tbcMdProcTypeDVO.getFnlUpderId()) ) {
			tmpTbcMdProcTypeDVO.setFnlUpderId(tbcMdProcTypeDVO.getFnlUpderId());
		}		
		return updateTbcMdProcType (tmpTbcMdProcTypeDVO);
	}

/**
* insertBatchTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return int[]
*/
	@LocalName("insertBatchTbcMdProcType")
	public int[] insertBatchTbcMdProcType (final List tbcMdProcTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.insertBatchTbcMdProcType.001*/  \n");
			sql.append(" TBC_MD_PROC_TYPE (   \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        PROC_TYPE_NM , \n");
			sql.append("        PROC_TYPE_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProcTypeDVO tbcMdProcTypeDVO = (TbcMdProcTypeDVO)tbcMdProcTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeNm());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeDesc());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdProcTypeDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return int[]
*/
	@LocalName("updateBatchTbcMdProcType")
	public int[] updateBatchTbcMdProcType (final List tbcMdProcTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.updateBatchTbcMdProcType.001*/  \n");
			sql.append(" TBC_MD_PROC_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        PROC_TYPE_NM = ? , \n");
			sql.append("        PROC_TYPE_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROC_GUBUN_CODE = ? \n");
			sql.append("   AND PROC_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProcTypeDVO tbcMdProcTypeDVO = (TbcMdProcTypeDVO)tbcMdProcTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeNm());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeDesc());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
						}
							public int getBatchSize() {
									return tbcMdProcTypeDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdProcType Method
* 
* @ref_table TBC_MD_PROC_TYPE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdProcType")
	public int[] deleteBatchTbcMdProcType (final List tbcMdProcTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProcTypeDEM.deleteBatchTbcMdProcType.001*/  \n");
			sql.append(" TBC_MD_PROC_TYPE \n");
			sql.append("  WHERE PROC_GUBUN_CODE = ? \n");
			sql.append("    AND PROC_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProcTypeDVO tbcMdProcTypeDVO = (TbcMdProcTypeDVO)tbcMdProcTypeDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdProcTypeDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcTypeDVO.getProcTypeCode());
						}
							public int getBatchSize() {
									return tbcMdProcTypeDVOList.size();
							}
					}
		);			
	}

	
}