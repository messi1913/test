package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdMatrDVO extends AbstractVo {

	@Length(30) 
	private String matrCode;

	@Length(2000) 
	private String matrSpecCont;

	@Length(30) 
	private String manmCode;

	@Length(30) 
	private String purcGradeCode;

	@Length(30) 
	private String qualGradeCode;

	@Length(30) 
	private String unitCode;

	@Length(1) 
	private String lfYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getMatrCode() {
		this.matrCode = super.getValue(0);
		return this.matrCode;
	}

	public void setMatrCode(String matrCode) {
        super.setValue(0, matrCode);
		this.matrCode = matrCode;
	}
	
	public String getMatrSpecCont() {
		this.matrSpecCont = super.getValue(1);
		return this.matrSpecCont;
	}

	public void setMatrSpecCont(String matrSpecCont) {
        super.setValue(1, matrSpecCont);
		this.matrSpecCont = matrSpecCont;
	}
	
	public String getManmCode() {
		this.manmCode = super.getValue(2);
		return this.manmCode;
	}

	public void setManmCode(String manmCode) {
        super.setValue(2, manmCode);
		this.manmCode = manmCode;
	}
	
	public String getPurcGradeCode() {
		this.purcGradeCode = super.getValue(3);
		return this.purcGradeCode;
	}

	public void setPurcGradeCode(String purcGradeCode) {
        super.setValue(3, purcGradeCode);
		this.purcGradeCode = purcGradeCode;
	}
	
	public String getQualGradeCode() {
		this.qualGradeCode = super.getValue(4);
		return this.qualGradeCode;
	}

	public void setQualGradeCode(String qualGradeCode) {
        super.setValue(4, qualGradeCode);
		this.qualGradeCode = qualGradeCode;
	}
	
	public String getUnitCode() {
		this.unitCode = super.getValue(5);
		return this.unitCode;
	}

	public void setUnitCode(String unitCode) {
        super.setValue(5, unitCode);
		this.unitCode = unitCode;
	}
	
	public String getLfYn() {
		this.lfYn = super.getValue(6);
		return this.lfYn;
	}

	public void setLfYn(String lfYn) {
        super.setValue(6, lfYn);
		this.lfYn = lfYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(7);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(7, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(8);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(8, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(9);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(9, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(10);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(10, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(11);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(11, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}