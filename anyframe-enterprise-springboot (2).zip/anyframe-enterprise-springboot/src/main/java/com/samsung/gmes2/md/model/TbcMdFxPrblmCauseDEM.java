package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdFxPrblmCauseDEM extends AbstractDAO {


/**
* insertTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return int
*/
	@LocalName("insertTbcMdFxPrblmCause")
	public int insertTbcMdFxPrblmCause (final TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.insertTbcMdFxPrblmCause.001*/  \n");
			sql.append(" TBC_MD_FX_PRBLM_CAUSE (   \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_CODE , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_NM , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_DESC , \n");
			sql.append("        FXTM_FXQTY_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdFxPrblmCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdFxPrblmCause Method")
	public int[][] updateBatchAllTbcMdFxPrblmCause (final List  tbcMdFxPrblmCauseDVOList) {
		
		ArrayList updatetbcMdFxPrblmCauseDVOList = new ArrayList();
		ArrayList insertttbcMdFxPrblmCauseDVOList = new ArrayList();
		ArrayList deletetbcMdFxPrblmCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdFxPrblmCauseDVOList.size() ; i++) {
		  TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO = (TbcMdFxPrblmCauseDVO) tbcMdFxPrblmCauseDVOList.get(i);
		  
		  if (tbcMdFxPrblmCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdFxPrblmCauseDVOList.add(tbcMdFxPrblmCauseDVO);
		  else if (tbcMdFxPrblmCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdFxPrblmCauseDVOList.add(tbcMdFxPrblmCauseDVO);
		  else if (tbcMdFxPrblmCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdFxPrblmCauseDVOList.add(tbcMdFxPrblmCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdFxPrblmCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdFxPrblmCause(insertttbcMdFxPrblmCauseDVOList);
          
      if (updatetbcMdFxPrblmCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdFxPrblmCause(updatetbcMdFxPrblmCauseDVOList);
      
      if (deletetbcMdFxPrblmCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdFxPrblmCause(deletetbcMdFxPrblmCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return int
*/
	@LocalName("updateTbcMdFxPrblmCause")
	public int updateTbcMdFxPrblmCause (final TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.updateTbcMdFxPrblmCause.001*/  \n");
			sql.append(" TBC_MD_FX_PRBLM_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_NM = ? , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_DESC = ? , \n");
			sql.append("        FXTM_FXQTY_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FXTM_FXQTY_PRBLM_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdFxPrblmCause")
	public int deleteTbcMdFxPrblmCause (final TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.deleteTbcMdFxPrblmCause.001*/  \n");
			sql.append(" TBC_MD_FX_PRBLM_CAUSE \n");
			sql.append("  WHERE FXTM_FXQTY_PRBLM_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return TbcMdFxPrblmCauseDVO 
*/
	@LocalName("selectTbcMdFxPrblmCause")
	public TbcMdFxPrblmCauseDVO selectTbcMdFxPrblmCause (final TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.selectTbcMdFxPrblmCause.001*/  \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_CODE , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_NM , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_DESC , \n");
			sql.append("        FXTM_FXQTY_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_FX_PRBLM_CAUSE \n");
			sql.append("  WHERE FXTM_FXQTY_PRBLM_CAUSE_CODE = ? \n");

		return (TbcMdFxPrblmCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdFxPrblmCauseDVO returnTbcMdFxPrblmCauseDVO = new TbcMdFxPrblmCauseDVO();
									returnTbcMdFxPrblmCauseDVO.setFxtmFxqtyPrblmCauseCode(resultSet.getString("FXTM_FXQTY_PRBLM_CAUSE_CODE"));
									returnTbcMdFxPrblmCauseDVO.setFxtmFxqtyPrblmCauseNm(resultSet.getString("FXTM_FXQTY_PRBLM_CAUSE_NM"));
									returnTbcMdFxPrblmCauseDVO.setFxtmFxqtyPrblmCauseDesc(resultSet.getString("FXTM_FXQTY_PRBLM_CAUSE_DESC"));
									returnTbcMdFxPrblmCauseDVO.setFxtmFxqtyGubunCode(resultSet.getString("FXTM_FXQTY_GUBUN_CODE"));
									returnTbcMdFxPrblmCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdFxPrblmCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdFxPrblmCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdFxPrblmCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdFxPrblmCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdFxPrblmCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdFxPrblmCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdFxPrblmCause Method")
	public int mergeTbcMdFxPrblmCause (final TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO) {
		
		if ( selectTbcMdFxPrblmCause (tbcMdFxPrblmCauseDVO) == null) {
			return insertTbcMdFxPrblmCause(tbcMdFxPrblmCauseDVO);
		} else {
			return selectUpdateTbcMdFxPrblmCause (tbcMdFxPrblmCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdFxPrblmCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdFxPrblmCause Method")
	public int selectUpdateTbcMdFxPrblmCause (final TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO) {
		
		TbcMdFxPrblmCauseDVO tmpTbcMdFxPrblmCauseDVO =  selectTbcMdFxPrblmCause (tbcMdFxPrblmCauseDVO);
		if ( tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFxtmFxqtyPrblmCauseCode(tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFxtmFxqtyPrblmCauseNm(tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFxtmFxqtyPrblmCauseDesc(tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFxtmFxqtyGubunCode(tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode());
		}		
		if ( tbcMdFxPrblmCauseDVO.getUseYn() != null && !"".equals(tbcMdFxPrblmCauseDVO.getUseYn()) ) {
			tmpTbcMdFxPrblmCauseDVO.setUseYn(tbcMdFxPrblmCauseDVO.getUseYn());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFstRegDt() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFstRegDt()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFstRegDt(tbcMdFxPrblmCauseDVO.getFstRegDt());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFstRegerId() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFstRegerId()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFstRegerId(tbcMdFxPrblmCauseDVO.getFstRegerId());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFnlUpdDt(tbcMdFxPrblmCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdFxPrblmCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdFxPrblmCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdFxPrblmCauseDVO.setFnlUpderId(tbcMdFxPrblmCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdFxPrblmCause (tmpTbcMdFxPrblmCauseDVO);
	}

/**
* insertBatchTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdFxPrblmCause")
	public int[] insertBatchTbcMdFxPrblmCause (final List tbcMdFxPrblmCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.insertBatchTbcMdFxPrblmCause.001*/  \n");
			sql.append(" TBC_MD_FX_PRBLM_CAUSE (   \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_CODE , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_NM , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_DESC , \n");
			sql.append("        FXTM_FXQTY_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO = (TbcMdFxPrblmCauseDVO)tbcMdFxPrblmCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdFxPrblmCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdFxPrblmCause")
	public int[] updateBatchTbcMdFxPrblmCause (final List tbcMdFxPrblmCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.updateBatchTbcMdFxPrblmCause.001*/  \n");
			sql.append(" TBC_MD_FX_PRBLM_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_NM = ? , \n");
			sql.append("        FXTM_FXQTY_PRBLM_CAUSE_DESC = ? , \n");
			sql.append("        FXTM_FXQTY_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FXTM_FXQTY_PRBLM_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO = (TbcMdFxPrblmCauseDVO)tbcMdFxPrblmCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseNm());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseDesc());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyGubunCode());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
						}
							public int getBatchSize() {
									return tbcMdFxPrblmCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdFxPrblmCause Method
* 
* @ref_table TBC_MD_FX_PRBLM_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdFxPrblmCause")
	public int[] deleteBatchTbcMdFxPrblmCause (final List tbcMdFxPrblmCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdFxPrblmCauseDEM.deleteBatchTbcMdFxPrblmCause.001*/  \n");
			sql.append(" TBC_MD_FX_PRBLM_CAUSE \n");
			sql.append("  WHERE FXTM_FXQTY_PRBLM_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdFxPrblmCauseDVO tbcMdFxPrblmCauseDVO = (TbcMdFxPrblmCauseDVO)tbcMdFxPrblmCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdFxPrblmCauseDVO.getFxtmFxqtyPrblmCauseCode());
						}
							public int getBatchSize() {
									return tbcMdFxPrblmCauseDVOList.size();
							}
					}
		);			
	}

	
}