package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdAuditEstiClsfDVO extends AbstractVo {

	@Length(30) 
	private String gbmCode;

	@Length(30) 
	private String procGubunCode;

	@Length(30) 
	private String estiClsfCode;

	@Length(500) 
	private String estiClsfNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGbmCode() {
		this.gbmCode = super.getValue(0);
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue(0, gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue(1);
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue(1, procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getEstiClsfCode() {
		this.estiClsfCode = super.getValue(2);
		return this.estiClsfCode;
	}

	public void setEstiClsfCode(String estiClsfCode) {
        super.setValue(2, estiClsfCode);
		this.estiClsfCode = estiClsfCode;
	}
	
	public String getEstiClsfNm() {
		this.estiClsfNm = super.getValue(3);
		return this.estiClsfNm;
	}

	public void setEstiClsfNm(String estiClsfNm) {
        super.setValue(3, estiClsfNm);
		this.estiClsfNm = estiClsfNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(4);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(4, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(5);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(5, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(6);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(6, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(7);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(7, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(8);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(8, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}