package com.samsung.gmes2.md.material.biz;

public class MdManageModelCkdMatrBiz {

	/**
	 * CKD기본정보 목록 조회
	 */
	public void listCkdBasic(){}

	public void saveCkdBasic(){}

}
