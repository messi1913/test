package com.samsung.gmes2.md.equipment.biz;

public class MdManageEquipKindBiz {

	/**
	 * 설비종류 목록 조회
	 */
	public void listEquipKind(){}

	/**
	 * 설비종류 목록 저장
	 */
	public void saveEquipKind(){}

}
