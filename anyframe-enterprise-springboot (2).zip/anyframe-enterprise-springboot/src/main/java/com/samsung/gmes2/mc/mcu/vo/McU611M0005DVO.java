package com.samsung.gmes2.mc.mcu.vo;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 한글명 : 모델라벨 조회
 * 작성일 : 2011.06.29
 * 작성자 : 심 재 국
 * 작업상태 : 완료
 * 개요 :
 * TBM_MC_LBL_Reg 의 데이터 조회를하기 위한 DVO
 * @stereotype DAOVO
 * @author shim
 */
@LocalName("Reg 정보 조회")
public class McU611M0005DVO extends AbstractDVO {

	@LocalName("라벨 ID") @Length(20) 
	private String labelId;

	@LocalName("라벨 명") @Length(100) 
	private String labelName;

	@LocalName("라벨 버전") @Length(5) @Scale(2) 
	private BigDecimal labelVer;

	@LocalName("라벨 유형") @Length(30) 
	private String labelTypeCode;


	/**
	 * 라벨 ID Getter Method
	 * 
	 * @return 라벨 ID
	 */
	@LocalName("라벨 ID Getter Method")
	public String getLabelId() {
		this.labelId = super.getValue("labelId");
		return this.labelId;
	}

	/**
	 * 라벨 ID Setter Method
	 * 
	 * @param String 라벨 ID
	 */
	@LocalName("라벨 ID Setter Method")
	public void setLabelId(String labelId) {
        super.setValue("labelId", labelId);
		this.labelId = labelId;
	}
	
	/**
	 * 라벨 명 Getter Method
	 * 
	 * @return 라벨 명
	 */
	@LocalName("라벨 명 Getter Method")
	public String getLabelName() {
		this.labelName = super.getValue("labelName");
		return this.labelName;
	}

	/**
	 * 라벨 명 Setter Method
	 * 
	 * @param String 라벨 명
	 */
	@LocalName("라벨 명 Setter Method")
	public void setLabelName(String labelName) {
        super.setValue("labelName", labelName);
		this.labelName = labelName;
	}
	
	/**
	 * 라벨 버전 Getter Method
	 * 
	 * @return 라벨 버전
	 */
	@LocalName("라벨 버전 Getter Method")
	public BigDecimal getLabelVer() {
		this.labelVer = super.getValue("labelVer");
		return this.labelVer;
	}

	/**
	 * 라벨 버전 Setter Method
	 * 
	 * @param BigDecimal 라벨 버전
	 */
	@LocalName("라벨 버전 Setter Method")
	public void setLabelVer(BigDecimal labelVer) {
        super.setValue("labelVer", labelVer);
		this.labelVer = labelVer;
	}
	
	/**
	 * 라벨 유형 Getter Method
	 * 
	 * @return 라벨 유형
	 */
	@LocalName("라벨 유형 Getter Method")
	public String getLabelTypeCode() {
		this.labelTypeCode = super.getValue("labelTypeCode");
		return this.labelTypeCode;
	}

	/**
	 * 라벨 유형 Setter Method
	 * 
	 * @param String 라벨 유형
	 */
	@LocalName("라벨 유형 Setter Method")
	public void setLabelTypeCode(String labelTypeCode) {
        super.setValue("labelTypeCode", labelTypeCode);
		this.labelTypeCode = labelTypeCode;
	}
	
}