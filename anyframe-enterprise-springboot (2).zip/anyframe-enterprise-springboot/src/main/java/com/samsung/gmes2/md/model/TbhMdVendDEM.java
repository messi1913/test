package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_VEND
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbhMdVendDEM extends AbstractDAO {


/**
* insertTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return int
*/
	@LocalName("insertTbhMdVend")
	public int insertTbhMdVend (final TbhMdVendDVO tbhMdVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdVendDEM.insertTbhMdVend.001*/  \n");
			sql.append(" TBH_MD_VEND (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        VEND_CODE , \n");
			sql.append("        VEND_GUBUN_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        VEND_NM , \n");
			sql.append("        VEND_CTRAC_CODE , \n");
			sql.append("        VEND_ADDR , \n");
			sql.append("        DLGR_NM , \n");
			sql.append("        CONTCT_NO , \n");
			sql.append("        VEND_TYPE_CODE , \n");
			sql.append("        PROD_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
							ps.setString(psCount++, tbhMdVendDVO.getVendNm());
							ps.setString(psCount++, tbhMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbhMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbhMdVendDVO.getContctNo());
							ps.setString(psCount++, tbhMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbhMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getUseYn());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdVendDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdVend Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdVend Method")
	public int[][] updateBatchAllTbhMdVend (final List  tbhMdVendDVOList) {
		
		ArrayList updatetbhMdVendDVOList = new ArrayList();
		ArrayList insertttbhMdVendDVOList = new ArrayList();
		ArrayList deletetbhMdVendDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdVendDVOList.size() ; i++) {
		  TbhMdVendDVO tbhMdVendDVO = (TbhMdVendDVO) tbhMdVendDVOList.get(i);
		  
		  if (tbhMdVendDVO.getSqlAction().equals("C"))
		      insertttbhMdVendDVOList.add(tbhMdVendDVO);
		  else if (tbhMdVendDVO.getSqlAction().equals("U"))
		      updatetbhMdVendDVOList.add(tbhMdVendDVO);
		  else if (tbhMdVendDVO.getSqlAction().equals("D"))
		      deletetbhMdVendDVOList.add(tbhMdVendDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdVendDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdVend(insertttbhMdVendDVOList);
          
      if (updatetbhMdVendDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdVend(updatetbhMdVendDVOList);
      
      if (deletetbhMdVendDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdVend(deletetbhMdVendDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return int
*/
	@LocalName("updateTbhMdVend")
	public int updateTbhMdVend (final TbhMdVendDVO tbhMdVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdVendDEM.updateTbhMdVend.001*/  \n");
			sql.append(" TBH_MD_VEND \n");
			sql.append(" SET   \n");
			sql.append("        VEND_NM = ? , \n");
			sql.append("        VEND_CTRAC_CODE = ? , \n");
			sql.append("        VEND_ADDR = ? , \n");
			sql.append("        DLGR_NM = ? , \n");
			sql.append("        CONTCT_NO = ? , \n");
			sql.append("        VEND_TYPE_CODE = ? , \n");
			sql.append("        PROD_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND VEND_CODE = ? \n");
			sql.append("   AND VEND_GUBUN_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdVendDVO.getVendNm());
							ps.setString(psCount++, tbhMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbhMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbhMdVendDVO.getContctNo());
							ps.setString(psCount++, tbhMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbhMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getUseYn());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdVendDVO.getEvtNm());

							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return int
*/
	@LocalName("deleteTbhMdVend")
	public int deleteTbhMdVend (final TbhMdVendDVO tbhMdVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdVendDEM.deleteTbhMdVend.001*/  \n");
			sql.append(" TBH_MD_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND VEND_CODE = ? \n");
			sql.append("    AND VEND_GUBUN_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return TbhMdVendDVO 
*/
	@LocalName("selectTbhMdVend")
	public TbhMdVendDVO selectTbhMdVend (final TbhMdVendDVO tbhMdVendDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdVendDEM.selectTbhMdVend.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        VEND_CODE , \n");
			sql.append("        VEND_GUBUN_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        VEND_NM , \n");
			sql.append("        VEND_CTRAC_CODE , \n");
			sql.append("        VEND_ADDR , \n");
			sql.append("        DLGR_NM , \n");
			sql.append("        CONTCT_NO , \n");
			sql.append("        VEND_TYPE_CODE , \n");
			sql.append("        PROD_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBH_MD_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND VEND_CODE = ? \n");
			sql.append("    AND VEND_GUBUN_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdVendDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdVendDVO returnTbhMdVendDVO = new TbhMdVendDVO();
									returnTbhMdVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbhMdVendDVO.setVendCode(resultSet.getString("VEND_CODE"));
									returnTbhMdVendDVO.setVendGubunCode(resultSet.getString("VEND_GUBUN_CODE"));
									returnTbhMdVendDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdVendDVO.setVendNm(resultSet.getString("VEND_NM"));
									returnTbhMdVendDVO.setVendCtracCode(resultSet.getString("VEND_CTRAC_CODE"));
									returnTbhMdVendDVO.setVendAddr(resultSet.getString("VEND_ADDR"));
									returnTbhMdVendDVO.setDlgrNm(resultSet.getString("DLGR_NM"));
									returnTbhMdVendDVO.setContctNo(resultSet.getString("CONTCT_NO"));
									returnTbhMdVendDVO.setVendTypeCode(resultSet.getString("VEND_TYPE_CODE"));
									returnTbhMdVendDVO.setProdGubunCode(resultSet.getString("PROD_GUBUN_CODE"));
									returnTbhMdVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbhMdVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbhMdVendDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbhMdVendDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdVend Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdVend Method")
	public int mergeTbhMdVend (final TbhMdVendDVO tbhMdVendDVO) {
		
		if ( selectTbhMdVend (tbhMdVendDVO) == null) {
			return insertTbhMdVend(tbhMdVendDVO);
		} else {
			return selectUpdateTbhMdVend (tbhMdVendDVO);
		}
	}

	/**
	 * selectUpdateTbhMdVend Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdVend Method")
	public int selectUpdateTbhMdVend (final TbhMdVendDVO tbhMdVendDVO) {
		
		TbhMdVendDVO tmpTbhMdVendDVO =  selectTbhMdVend (tbhMdVendDVO);
		if ( tbhMdVendDVO.getPlantCode() != null && !"".equals(tbhMdVendDVO.getPlantCode()) ) {
			tmpTbhMdVendDVO.setPlantCode(tbhMdVendDVO.getPlantCode());
		}		
		if ( tbhMdVendDVO.getVendCode() != null && !"".equals(tbhMdVendDVO.getVendCode()) ) {
			tmpTbhMdVendDVO.setVendCode(tbhMdVendDVO.getVendCode());
		}		
		if ( tbhMdVendDVO.getVendGubunCode() != null && !"".equals(tbhMdVendDVO.getVendGubunCode()) ) {
			tmpTbhMdVendDVO.setVendGubunCode(tbhMdVendDVO.getVendGubunCode());
		}		
		if ( tbhMdVendDVO.getHistTsp() != null && !"".equals(tbhMdVendDVO.getHistTsp()) ) {
			tmpTbhMdVendDVO.setHistTsp(tbhMdVendDVO.getHistTsp());
		}		
		if ( tbhMdVendDVO.getVendNm() != null && !"".equals(tbhMdVendDVO.getVendNm()) ) {
			tmpTbhMdVendDVO.setVendNm(tbhMdVendDVO.getVendNm());
		}		
		if ( tbhMdVendDVO.getVendCtracCode() != null && !"".equals(tbhMdVendDVO.getVendCtracCode()) ) {
			tmpTbhMdVendDVO.setVendCtracCode(tbhMdVendDVO.getVendCtracCode());
		}		
		if ( tbhMdVendDVO.getVendAddr() != null && !"".equals(tbhMdVendDVO.getVendAddr()) ) {
			tmpTbhMdVendDVO.setVendAddr(tbhMdVendDVO.getVendAddr());
		}		
		if ( tbhMdVendDVO.getDlgrNm() != null && !"".equals(tbhMdVendDVO.getDlgrNm()) ) {
			tmpTbhMdVendDVO.setDlgrNm(tbhMdVendDVO.getDlgrNm());
		}		
		if ( tbhMdVendDVO.getContctNo() != null && !"".equals(tbhMdVendDVO.getContctNo()) ) {
			tmpTbhMdVendDVO.setContctNo(tbhMdVendDVO.getContctNo());
		}		
		if ( tbhMdVendDVO.getVendTypeCode() != null && !"".equals(tbhMdVendDVO.getVendTypeCode()) ) {
			tmpTbhMdVendDVO.setVendTypeCode(tbhMdVendDVO.getVendTypeCode());
		}		
		if ( tbhMdVendDVO.getProdGubunCode() != null && !"".equals(tbhMdVendDVO.getProdGubunCode()) ) {
			tmpTbhMdVendDVO.setProdGubunCode(tbhMdVendDVO.getProdGubunCode());
		}		
		if ( tbhMdVendDVO.getUseYn() != null && !"".equals(tbhMdVendDVO.getUseYn()) ) {
			tmpTbhMdVendDVO.setUseYn(tbhMdVendDVO.getUseYn());
		}		
		if ( tbhMdVendDVO.getFstRegDt() != null && !"".equals(tbhMdVendDVO.getFstRegDt()) ) {
			tmpTbhMdVendDVO.setFstRegDt(tbhMdVendDVO.getFstRegDt());
		}		
		if ( tbhMdVendDVO.getFstRegerId() != null && !"".equals(tbhMdVendDVO.getFstRegerId()) ) {
			tmpTbhMdVendDVO.setFstRegerId(tbhMdVendDVO.getFstRegerId());
		}		
		if ( tbhMdVendDVO.getFnlUpdDt() != null && !"".equals(tbhMdVendDVO.getFnlUpdDt()) ) {
			tmpTbhMdVendDVO.setFnlUpdDt(tbhMdVendDVO.getFnlUpdDt());
		}		
		if ( tbhMdVendDVO.getFnlUpderId() != null && !"".equals(tbhMdVendDVO.getFnlUpderId()) ) {
			tmpTbhMdVendDVO.setFnlUpderId(tbhMdVendDVO.getFnlUpderId());
		}		
		if ( tbhMdVendDVO.getEvtNm() != null && !"".equals(tbhMdVendDVO.getEvtNm()) ) {
			tmpTbhMdVendDVO.setEvtNm(tbhMdVendDVO.getEvtNm());
		}		
		return updateTbhMdVend (tmpTbhMdVendDVO);
	}

/**
* insertBatchTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return int[]
*/
	@LocalName("insertBatchTbhMdVend")
	public int[] insertBatchTbhMdVend (final List tbhMdVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdVendDEM.insertBatchTbhMdVend.001*/  \n");
			sql.append(" TBH_MD_VEND (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        VEND_CODE , \n");
			sql.append("        VEND_GUBUN_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        VEND_NM , \n");
			sql.append("        VEND_CTRAC_CODE , \n");
			sql.append("        VEND_ADDR , \n");
			sql.append("        DLGR_NM , \n");
			sql.append("        CONTCT_NO , \n");
			sql.append("        VEND_TYPE_CODE , \n");
			sql.append("        PROD_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdVendDVO tbhMdVendDVO = (TbhMdVendDVO)tbhMdVendDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
							ps.setString(psCount++, tbhMdVendDVO.getVendNm());
							ps.setString(psCount++, tbhMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbhMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbhMdVendDVO.getContctNo());
							ps.setString(psCount++, tbhMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbhMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getUseYn());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdVendDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbhMdVendDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return int[]
*/
	@LocalName("updateBatchTbhMdVend")
	public int[] updateBatchTbhMdVend (final List tbhMdVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdVendDEM.updateBatchTbhMdVend.001*/  \n");
			sql.append(" TBH_MD_VEND \n");
			sql.append(" SET   \n");
			sql.append("        VEND_NM = ? , \n");
			sql.append("        VEND_CTRAC_CODE = ? , \n");
			sql.append("        VEND_ADDR = ? , \n");
			sql.append("        DLGR_NM = ? , \n");
			sql.append("        CONTCT_NO = ? , \n");
			sql.append("        VEND_TYPE_CODE = ? , \n");
			sql.append("        PROD_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND VEND_CODE = ? \n");
			sql.append("   AND VEND_GUBUN_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdVendDVO tbhMdVendDVO = (TbhMdVendDVO)tbhMdVendDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdVendDVO.getVendNm());
							ps.setString(psCount++, tbhMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbhMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbhMdVendDVO.getContctNo());
							ps.setString(psCount++, tbhMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbhMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getUseYn());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdVendDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdVendDVO.getEvtNm());

							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdVendDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdVend Method
* 
* @ref_table TBH_MD_VEND
* @return int[]
*/
	@LocalName("deleteBatchTbhMdVend")
	public int[] deleteBatchTbhMdVend (final List tbhMdVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdVendDEM.deleteBatchTbhMdVend.001*/  \n");
			sql.append(" TBH_MD_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND VEND_CODE = ? \n");
			sql.append("    AND VEND_GUBUN_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdVendDVO tbhMdVendDVO = (TbhMdVendDVO)tbhMdVendDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendCode());
							ps.setString(psCount++, tbhMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbhMdVendDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdVendDVOList.size();
							}
					}
		);			
	}

	
}