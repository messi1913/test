package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbmMcLblNmgPreisuDVO extends AbstractVo {

	@Length(50) 
	private String nmgId;

	@Length(20) 
	private String plantCode;

	@Length(20) 
	private String modelCode;

	@Length(50) 
	private String nmgArtId;

	@Length(30) 
	private String nmgKeyValue;

	@Length(50) 
	private String labelId;

	@Length(3) 
	private String nmgTypeCode;

	@Length(50) 
	private String poNo;

	@Length(30) 
	private String lineCode;

	@Length(50) 
	private String nmgStartNo;

	@Length(50) 
	private String nmgEndNo;

	@Length(11) @Scale(5) 
	private BigDecimal nmgQty;

	@Length(8) 
	private String prodcPlanYmd;

	@Length(8) 
	private String nmgAplyYmd;

	@Length(11) @Scale(5) 
	private BigDecimal prtQty;

	@Length(11) @Scale(5) 
	private BigDecimal rePrtQty;

	@Length(1000) 
	private String nmgDesc;


	public String getNmgId() {
		this.nmgId = super.getValue(0);
		return this.nmgId;
	}

	public void setNmgId(String nmgId) {
        super.setValue(0, nmgId);
		this.nmgId = nmgId;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(1);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(1, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(2);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(2, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getNmgArtId() {
		this.nmgArtId = super.getValue(3);
		return this.nmgArtId;
	}

	public void setNmgArtId(String nmgArtId) {
        super.setValue(3, nmgArtId);
		this.nmgArtId = nmgArtId;
	}
	
	public String getNmgKeyValue() {
		this.nmgKeyValue = super.getValue(4);
		return this.nmgKeyValue;
	}

	public void setNmgKeyValue(String nmgKeyValue) {
        super.setValue(4, nmgKeyValue);
		this.nmgKeyValue = nmgKeyValue;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue(5);
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue(5, labelId);
		this.labelId = labelId;
	}
	
	public String getNmgTypeCode() {
		this.nmgTypeCode = super.getValue(6);
		return this.nmgTypeCode;
	}

	public void setNmgTypeCode(String nmgTypeCode) {
        super.setValue(6, nmgTypeCode);
		this.nmgTypeCode = nmgTypeCode;
	}
	
	public String getPoNo() {
		this.poNo = super.getValue(7);
		return this.poNo;
	}

	public void setPoNo(String poNo) {
        super.setValue(7, poNo);
		this.poNo = poNo;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(8);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(8, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getNmgStartNo() {
		this.nmgStartNo = super.getValue(9);
		return this.nmgStartNo;
	}

	public void setNmgStartNo(String nmgStartNo) {
        super.setValue(9, nmgStartNo);
		this.nmgStartNo = nmgStartNo;
	}
	
	public String getNmgEndNo() {
		this.nmgEndNo = super.getValue(10);
		return this.nmgEndNo;
	}

	public void setNmgEndNo(String nmgEndNo) {
        super.setValue(10, nmgEndNo);
		this.nmgEndNo = nmgEndNo;
	}
	
	public BigDecimal getNmgQty() {
		this.nmgQty = super.getValue(11);
		return this.nmgQty;
	}

	public void setNmgQty(BigDecimal nmgQty) {
        super.setValue(11, nmgQty);
		this.nmgQty = nmgQty;
	}
	
	public String getProdcPlanYmd() {
		this.prodcPlanYmd = super.getValue(12);
		return this.prodcPlanYmd;
	}

	public void setProdcPlanYmd(String prodcPlanYmd) {
        super.setValue(12, prodcPlanYmd);
		this.prodcPlanYmd = prodcPlanYmd;
	}
	
	public String getNmgAplyYmd() {
		this.nmgAplyYmd = super.getValue(13);
		return this.nmgAplyYmd;
	}

	public void setNmgAplyYmd(String nmgAplyYmd) {
        super.setValue(13, nmgAplyYmd);
		this.nmgAplyYmd = nmgAplyYmd;
	}
	
	public BigDecimal getPrtQty() {
		this.prtQty = super.getValue(14);
		return this.prtQty;
	}

	public void setPrtQty(BigDecimal prtQty) {
        super.setValue(14, prtQty);
		this.prtQty = prtQty;
	}
	
	public BigDecimal getRePrtQty() {
		this.rePrtQty = super.getValue(15);
		return this.rePrtQty;
	}

	public void setRePrtQty(BigDecimal rePrtQty) {
        super.setValue(15, rePrtQty);
		this.rePrtQty = rePrtQty;
	}
	
	public String getNmgDesc() {
		this.nmgDesc = super.getValue(16);
		return this.nmgDesc;
	}

	public void setNmgDesc(String nmgDesc) {
        super.setValue(16, nmgDesc);
		this.nmgDesc = nmgDesc;
	}
	
}