package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author hkw
*/
@Stereotype(Stereotype.Dao)
public class TbcMdCommCodeTypeDQM extends AbstractDAO {


/**
* 
*
* SELECT 
* 	TYPE_CODE, 
* 	HRNK_TYPE_CODE, 
* 	TYPE_CODE_NM, 
* 	TYPE_CODE_DESC, 
* 	GRP_CODE, 
* 	CODE_SORT_PRIOR, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_CODE_TYPE 
* WHERE 1=1 
* #if($typeCode) 
* AND TYPE_CODE = :typeCode 
* #end 
* #if($hrnkTypeCode) 
* AND HRNK_TYPE_CODE = :hrnkTypeCode 
* #end 
* #if($typeCodeNm) 
* AND TYPE_CODE_NM = :typeCodeNm 
* #end 
* #if($typeCodeNmLike) 
* AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%' 
* #end 
* #if($typeCodeDesc) 
* AND TYPE_CODE_DESC = :typeCodeDesc 
* #end 
* #if($grpCode) 
* AND GRP_CODE = :grpCode 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	TYPE_CODE,  \n");
			sql.append(" 	HRNK_TYPE_CODE,  \n");
			sql.append(" 	TYPE_CODE_NM,  \n");
			sql.append(" 	TYPE_CODE_DESC,  \n");
			sql.append(" 	GRP_CODE,  \n");
			sql.append(" 	CODE_SORT_PRIOR,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_CODE_TYPE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($typeCode)  \n");
			sql.append(" AND TYPE_CODE = :typeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($hrnkTypeCode)  \n");
			sql.append(" AND HRNK_TYPE_CODE = :hrnkTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNm)  \n");
			sql.append(" AND TYPE_CODE_NM = :typeCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNmLike)  \n");
			sql.append(" AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeDesc)  \n");
			sql.append(" AND TYPE_CODE_DESC = :typeCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpCode)  \n");
			sql.append(" AND GRP_CODE = :grpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcCommCodeTypeDQM.dListPage000.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "typeCode", "hrnkTypeCode", "typeCodeNm", "typeCodeNmLike", "typeCodeDesc", "grpCode", "codeSortPrior", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("typeCode") != null && !"".equals(inputMap.get("typeCode"))) {	
					data.put("typeCode", inputMap.get("typeCode"));
				}
				if (inputMap.get("hrnkTypeCode") != null && !"".equals(inputMap.get("hrnkTypeCode"))) {	
					data.put("hrnkTypeCode", inputMap.get("hrnkTypeCode"));
				}
				if (inputMap.get("typeCodeNm") != null && !"".equals(inputMap.get("typeCodeNm"))) {	
					data.put("typeCodeNm", inputMap.get("typeCodeNm"));
				}
				if (inputMap.get("typeCodeNmLike") != null && !"".equals(inputMap.get("typeCodeNmLike"))) {	
					data.put("typeCodeNmLike", inputMap.get("typeCodeNmLike"));
				}
				if (inputMap.get("typeCodeDesc") != null && !"".equals(inputMap.get("typeCodeDesc"))) {	
					data.put("typeCodeDesc", inputMap.get("typeCodeDesc"));
				}
				if (inputMap.get("grpCode") != null && !"".equals(inputMap.get("grpCode"))) {	
					data.put("grpCode", inputMap.get("grpCode"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommCodeTypeDVO returnTbcMdCommCodeTypeDVO = new TbcMdCommCodeTypeDVO();
									returnTbcMdCommCodeTypeDVO.setTypeCode(resultSet.getString("TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setHrnkTypeCode(resultSet.getString("HRNK_TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeNm(resultSet.getString("TYPE_CODE_NM"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeDesc(resultSet.getString("TYPE_CODE_DESC"));
									returnTbcMdCommCodeTypeDVO.setGrpCode(resultSet.getString("GRP_CODE"));
									returnTbcMdCommCodeTypeDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommCodeTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommCodeTypeDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommCodeTypeDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommCodeTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommCodeTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommCodeTypeDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	TYPE_CODE, 
* 	HRNK_TYPE_CODE, 
* 	TYPE_CODE_NM, 	
* 	GRP_CODE, 
* 	USE_YN, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_CODE_TYPE 
* WHERE 1=1 
* #if($typeCode) 
* AND TYPE_CODE = :typeCode 
* #end 
* #if($hrnkTypeCode) 
* AND HRNK_TYPE_CODE = :hrnkTypeCode 
* #end 
* #if($typeCodeNm) 
* AND TYPE_CODE_NM = :typeCodeNm 
* #end 
* #if($typeCodeNmLike) 
* AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%' 
* #end 
* #if($typeCodeDesc) 
* AND TYPE_CODE_DESC = :typeCodeDesc 
* #end 
* #if($grpCode) 
* AND GRP_CODE = :grpCode 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	TYPE_CODE,  \n");
			sql.append(" 	HRNK_TYPE_CODE,  \n");
			sql.append(" 	TYPE_CODE_NM, 	 \n");
			sql.append(" 	GRP_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_CODE_TYPE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($typeCode)  \n");
			sql.append(" AND TYPE_CODE = :typeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($hrnkTypeCode)  \n");
			sql.append(" AND HRNK_TYPE_CODE = :hrnkTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNm)  \n");
			sql.append(" AND TYPE_CODE_NM = :typeCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNmLike)  \n");
			sql.append(" AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeDesc)  \n");
			sql.append(" AND TYPE_CODE_DESC = :typeCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpCode)  \n");
			sql.append(" AND GRP_CODE = :grpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcCommCodeTypeDQM.dListPage001.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "typeCode", "hrnkTypeCode", "typeCodeNm", "typeCodeNmLike", "typeCodeDesc", "grpCode", "codeSortPrior", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("typeCode") != null && !"".equals(inputMap.get("typeCode"))) {	
					data.put("typeCode", inputMap.get("typeCode"));
				}
				if (inputMap.get("hrnkTypeCode") != null && !"".equals(inputMap.get("hrnkTypeCode"))) {	
					data.put("hrnkTypeCode", inputMap.get("hrnkTypeCode"));
				}
				if (inputMap.get("typeCodeNm") != null && !"".equals(inputMap.get("typeCodeNm"))) {	
					data.put("typeCodeNm", inputMap.get("typeCodeNm"));
				}
				if (inputMap.get("typeCodeNmLike") != null && !"".equals(inputMap.get("typeCodeNmLike"))) {	
					data.put("typeCodeNmLike", inputMap.get("typeCodeNmLike"));
				}
				if (inputMap.get("typeCodeDesc") != null && !"".equals(inputMap.get("typeCodeDesc"))) {	
					data.put("typeCodeDesc", inputMap.get("typeCodeDesc"));
				}
				if (inputMap.get("grpCode") != null && !"".equals(inputMap.get("grpCode"))) {	
					data.put("grpCode", inputMap.get("grpCode"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommCodeTypeDVO returnTbcMdCommCodeTypeDVO = new TbcMdCommCodeTypeDVO();
									returnTbcMdCommCodeTypeDVO.setTypeCode(resultSet.getString("TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setHrnkTypeCode(resultSet.getString("HRNK_TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeNm(resultSet.getString("TYPE_CODE_NM"));
									returnTbcMdCommCodeTypeDVO.setGrpCode(resultSet.getString("GRP_CODE"));
									returnTbcMdCommCodeTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommCodeTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommCodeTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommCodeTypeDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	TYPE_CODE, 
* 	HRNK_TYPE_CODE, 
* 	TYPE_CODE_NM, 
* 	TYPE_CODE_DESC, 
* 	GRP_CODE, 
* 	CODE_SORT_PRIOR, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_CODE_TYPE 
* WHERE 1=1 
* #if($typeCode) 
* AND TYPE_CODE = :typeCode 
* #end 
* #if($hrnkTypeCode) 
* AND HRNK_TYPE_CODE = :hrnkTypeCode 
* #end 
* #if($typeCodeNm) 
* AND TYPE_CODE_NM = :typeCodeNm 
* #end 
* #if($typeCodeNmLike) 
* AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%' 
* #end 
* #if($typeCodeDesc) 
* AND TYPE_CODE_DESC = :typeCodeDesc 
* #end 
* #if($grpCode) 
* AND GRP_CODE = :grpCode 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	TYPE_CODE,  \n");
			sql.append(" 	HRNK_TYPE_CODE,  \n");
			sql.append(" 	TYPE_CODE_NM,  \n");
			sql.append(" 	TYPE_CODE_DESC,  \n");
			sql.append(" 	GRP_CODE,  \n");
			sql.append(" 	CODE_SORT_PRIOR,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_CODE_TYPE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($typeCode)  \n");
			sql.append(" AND TYPE_CODE = :typeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($hrnkTypeCode)  \n");
			sql.append(" AND HRNK_TYPE_CODE = :hrnkTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNm)  \n");
			sql.append(" AND TYPE_CODE_NM = :typeCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNmLike)  \n");
			sql.append(" AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeDesc)  \n");
			sql.append(" AND TYPE_CODE_DESC = :typeCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpCode)  \n");
			sql.append(" AND GRP_CODE = :grpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcCommCodeTypeDQM.dListPageRowCount000.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "typeCode", "hrnkTypeCode", "typeCodeNm", "typeCodeNmLike", "typeCodeDesc", "grpCode", "codeSortPrior", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("typeCode") != null && !"".equals(inputMap.get("typeCode"))) {	
					data.put("typeCode", inputMap.get("typeCode"));
				}
				if (inputMap.get("hrnkTypeCode") != null && !"".equals(inputMap.get("hrnkTypeCode"))) {	
					data.put("hrnkTypeCode", inputMap.get("hrnkTypeCode"));
				}
				if (inputMap.get("typeCodeNm") != null && !"".equals(inputMap.get("typeCodeNm"))) {	
					data.put("typeCodeNm", inputMap.get("typeCodeNm"));
				}
				if (inputMap.get("typeCodeNmLike") != null && !"".equals(inputMap.get("typeCodeNmLike"))) {	
					data.put("typeCodeNmLike", inputMap.get("typeCodeNmLike"));
				}
				if (inputMap.get("typeCodeDesc") != null && !"".equals(inputMap.get("typeCodeDesc"))) {	
					data.put("typeCodeDesc", inputMap.get("typeCodeDesc"));
				}
				if (inputMap.get("grpCode") != null && !"".equals(inputMap.get("grpCode"))) {	
					data.put("grpCode", inputMap.get("grpCode"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommCodeTypeDVO returnTbcMdCommCodeTypeDVO = new TbcMdCommCodeTypeDVO();
									returnTbcMdCommCodeTypeDVO.setTypeCode(resultSet.getString("TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setHrnkTypeCode(resultSet.getString("HRNK_TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeNm(resultSet.getString("TYPE_CODE_NM"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeDesc(resultSet.getString("TYPE_CODE_DESC"));
									returnTbcMdCommCodeTypeDVO.setGrpCode(resultSet.getString("GRP_CODE"));
									returnTbcMdCommCodeTypeDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommCodeTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommCodeTypeDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommCodeTypeDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommCodeTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommCodeTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommCodeTypeDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
* 
*
* SELECT 
* 	TYPE_CODE, 
* 	HRNK_TYPE_CODE, 
* 	TYPE_CODE_NM, 	
* 	GRP_CODE, 
* 	USE_YN, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_CODE_TYPE 
* WHERE 1=1 
* #if($typeCode) 
* AND TYPE_CODE = :typeCode 
* #end 
* #if($hrnkTypeCode) 
* AND HRNK_TYPE_CODE = :hrnkTypeCode 
* #end 
* #if($typeCodeNm) 
* AND TYPE_CODE_NM = :typeCodeNm 
* #end 
* #if($typeCodeNmLike) 
* AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%' 
* #end 
* #if($typeCodeDesc) 
* AND TYPE_CODE_DESC = :typeCodeDesc 
* #end 
* #if($grpCode) 
* AND GRP_CODE = :grpCode 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	TYPE_CODE,  \n");
			sql.append(" 	HRNK_TYPE_CODE,  \n");
			sql.append(" 	TYPE_CODE_NM, 	 \n");
			sql.append(" 	GRP_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_CODE_TYPE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($typeCode)  \n");
			sql.append(" AND TYPE_CODE = :typeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($hrnkTypeCode)  \n");
			sql.append(" AND HRNK_TYPE_CODE = :hrnkTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNm)  \n");
			sql.append(" AND TYPE_CODE_NM = :typeCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeNmLike)  \n");
			sql.append(" AND TYPE_CODE_NM like '%' || :typeCodeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($typeCodeDesc)  \n");
			sql.append(" AND TYPE_CODE_DESC = :typeCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpCode)  \n");
			sql.append(" AND GRP_CODE = :grpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcCommCodeTypeDQM.dListPageRowCount001.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "typeCode", "hrnkTypeCode", "typeCodeNm", "typeCodeNmLike", "typeCodeDesc", "grpCode", "codeSortPrior", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("typeCode") != null && !"".equals(inputMap.get("typeCode"))) {	
					data.put("typeCode", inputMap.get("typeCode"));
				}
				if (inputMap.get("hrnkTypeCode") != null && !"".equals(inputMap.get("hrnkTypeCode"))) {	
					data.put("hrnkTypeCode", inputMap.get("hrnkTypeCode"));
				}
				if (inputMap.get("typeCodeNm") != null && !"".equals(inputMap.get("typeCodeNm"))) {	
					data.put("typeCodeNm", inputMap.get("typeCodeNm"));
				}
				if (inputMap.get("typeCodeNmLike") != null && !"".equals(inputMap.get("typeCodeNmLike"))) {	
					data.put("typeCodeNmLike", inputMap.get("typeCodeNmLike"));
				}
				if (inputMap.get("typeCodeDesc") != null && !"".equals(inputMap.get("typeCodeDesc"))) {	
					data.put("typeCodeDesc", inputMap.get("typeCodeDesc"));
				}
				if (inputMap.get("grpCode") != null && !"".equals(inputMap.get("grpCode"))) {	
					data.put("grpCode", inputMap.get("grpCode"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommCodeTypeDVO returnTbcMdCommCodeTypeDVO = new TbcMdCommCodeTypeDVO();
									returnTbcMdCommCodeTypeDVO.setTypeCode(resultSet.getString("TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setHrnkTypeCode(resultSet.getString("HRNK_TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeNm(resultSet.getString("TYPE_CODE_NM"));
									returnTbcMdCommCodeTypeDVO.setGrpCode(resultSet.getString("GRP_CODE"));
									returnTbcMdCommCodeTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommCodeTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommCodeTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommCodeTypeDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}