package com.samsung.gmes2.md.logi.app;

public class MDU881M01App {

	/**
	 * 라벨분류코드 목록 초기설정
	 */
	public void initLabelClsf(){}

	/**
	 * 라벨분류코드 목록 조회
	 */
	public void listLabelClsf(){}

	/**
	 * 라벨분류코드 목록 엑셀 다운로드
	 */
	public void excelLabelClsf(){}

	/**
	 * 라벨분류코드 목록 저장
	 */
	public void saveLabelClsf(){}

}
