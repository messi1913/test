package com.samsung.gmes2.aop;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;

import com.samsung.gmes2.base.util.CacheUtil;
import com.samsung.gmes2.base.util.ReflectionUtil;
import com.samsung.gmes2.base.util.ThreadPropertyUtil;
import com.samsung.gmes2.base.util.annotation.Cacheable;
import com.samsung.gmes2.exception.Gmes2Exception;
import com.samsung.gmes2.exception.Gmes2ServerException;

public class ServiceAdvice extends AbstractAdvice {
	public Object invoke(ProceedingJoinPoint call) throws Throwable {
		/**
		 * Meta-Info
		 */
		Signature signature = call.getSignature();
		Method method = ReflectionUtil.getMethod(signature);
		Cacheable cacheable = method == null ? null : method.getAnnotation(Cacheable.class);
		
//		Object[] args = call.getArgs();
//		if (!isEmpty(args) && args[0] instanceof AbstractVo) {
//			List<String> notNullFieldList = Reflection.getNotNullFieldNameList(args[0]);
//			if (!isEmpty(notNullFieldList))
//				checkNotEmpty((AbstractVo) args[0], notNullFieldList.toArray(new String[notNullFieldList.size()]));
//		}

		increaseStackCounter();
		try {
			if (cacheable == null) {
				return call.proceed();
			} else {
				CacheUtil.setCacheable(cacheable.value());
				try {
					return call.proceed();
				} finally {
					if (cacheable != null)
						CacheUtil.release();
				}
			}
		} catch (Gmes2Exception e) {
			throw e;
		} catch (Throwable t) {
			if (t instanceof InvocationTargetException)
				t = ((InvocationTargetException) t).getTargetException();
			if (t instanceof Gmes2Exception)
				throw t;
			throw new Gmes2ServerException(t.getMessage( ), t);
		} finally {
			decreaseStackCounter();
			if (isFirstStack()) {
				if (CacheUtil.isCacheable())
					invalidateCache();
				ThreadPropertyUtil.removeAll();
			}
		}
	}
}
