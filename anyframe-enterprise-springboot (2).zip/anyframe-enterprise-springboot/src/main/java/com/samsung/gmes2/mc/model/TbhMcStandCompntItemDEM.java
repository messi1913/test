package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMcStandCompntItemDEM extends AbstractDAO {


/**
* insertTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return int
*/
	@LocalName("insertTbhMcStandCompntItem")
	public int insertTbhMcStandCompntItem (final TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.insertTbhMcStandCompntItem.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT_ITEM (   \n");
			sql.append("        REV_NO , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        ITEM_NO , \n");
			sql.append("        LABEL_CONT , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        ITEM_LENG , \n");
			sql.append("        ITEM_HEIT , \n");
			sql.append("        FONT_NM , \n");
			sql.append("        FONT_VALUE , \n");
			sql.append("        FRCLOR_VALUE , \n");
			sql.append("        BCKCLOR_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getBckclorValue());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMcStandCompntItem Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMcStandCompntItem Method")
	public int[][] updateBatchAllTbhMcStandCompntItem (final List  tbhMcStandCompntItemDVOList) {
		
		ArrayList updatetbhMcStandCompntItemDVOList = new ArrayList();
		ArrayList insertttbhMcStandCompntItemDVOList = new ArrayList();
		ArrayList deletetbhMcStandCompntItemDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMcStandCompntItemDVOList.size() ; i++) {
		  TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO = (TbhMcStandCompntItemDVO) tbhMcStandCompntItemDVOList.get(i);
		  
		  if (tbhMcStandCompntItemDVO.getSqlAction().equals("C"))
		      insertttbhMcStandCompntItemDVOList.add(tbhMcStandCompntItemDVO);
		  else if (tbhMcStandCompntItemDVO.getSqlAction().equals("U"))
		      updatetbhMcStandCompntItemDVOList.add(tbhMcStandCompntItemDVO);
		  else if (tbhMcStandCompntItemDVO.getSqlAction().equals("D"))
		      deletetbhMcStandCompntItemDVOList.add(tbhMcStandCompntItemDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMcStandCompntItemDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMcStandCompntItem(insertttbhMcStandCompntItemDVOList);
          
      if (updatetbhMcStandCompntItemDVOList.size() >0)
          resultValues[1] = updateBatchTbhMcStandCompntItem(updatetbhMcStandCompntItemDVOList);
      
      if (deletetbhMcStandCompntItemDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMcStandCompntItem(deletetbhMcStandCompntItemDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return int
*/
	@LocalName("updateTbhMcStandCompntItem")
	public int updateTbhMcStandCompntItem (final TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.updateTbhMcStandCompntItem.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT_ITEM \n");
			sql.append(" SET   \n");
			sql.append("        LABEL_CONT = ? , \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        ITEM_LENG = ? , \n");
			sql.append("        ITEM_HEIT = ? , \n");
			sql.append("        FONT_NM = ? , \n");
			sql.append("        FONT_VALUE = ? , \n");
			sql.append("        FRCLOR_VALUE = ? , \n");
			sql.append("        BCKCLOR_VALUE = ? \n");
			sql.append(" WHERE REV_NO = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");
			sql.append("   AND ITEM_NO = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getBckclorValue());

							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
						}
					}
		);			
	}

/**
* deleteTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return int
*/
	@LocalName("deleteTbhMcStandCompntItem")
	public int deleteTbhMcStandCompntItem (final TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.deleteTbhMcStandCompntItem.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT_ITEM \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");
			sql.append("    AND ITEM_NO = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
						}
					}
		);			
	}

/**
* selectTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return TbhMcStandCompntItemDVO 
*/
	@LocalName("selectTbhMcStandCompntItem")
	public TbhMcStandCompntItemDVO selectTbhMcStandCompntItem (final TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.selectTbhMcStandCompntItem.001*/  \n");
			sql.append("        REV_NO , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        ITEM_NO , \n");
			sql.append("        LABEL_CONT , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        ITEM_LENG , \n");
			sql.append("        ITEM_HEIT , \n");
			sql.append("        FONT_NM , \n");
			sql.append("        FONT_VALUE , \n");
			sql.append("        FRCLOR_VALUE , \n");
			sql.append("        BCKCLOR_VALUE \n");
			sql.append("   FROM TBH_MC_STAND_COMPNT_ITEM \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");
			sql.append("    AND ITEM_NO = ? \n");

		return (TbhMcStandCompntItemDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMcStandCompntItemDVO returnTbhMcStandCompntItemDVO = new TbhMcStandCompntItemDVO();
									returnTbhMcStandCompntItemDVO.setRevNo(resultSet.getString("REV_NO"));
									returnTbhMcStandCompntItemDVO.setStandCompntCode(resultSet.getString("STAND_COMPNT_CODE"));
									returnTbhMcStandCompntItemDVO.setItemNo(resultSet.getString("ITEM_NO"));
									returnTbhMcStandCompntItemDVO.setLabelCont(resultSet.getString("LABEL_CONT"));
									returnTbhMcStandCompntItemDVO.setxValue(resultSet.getBigDecimal("X_VALUE"));
									returnTbhMcStandCompntItemDVO.setyValue(resultSet.getBigDecimal("Y_VALUE"));
									returnTbhMcStandCompntItemDVO.setItemLeng(resultSet.getBigDecimal("ITEM_LENG"));
									returnTbhMcStandCompntItemDVO.setItemHeit(resultSet.getBigDecimal("ITEM_HEIT"));
									returnTbhMcStandCompntItemDVO.setFontNm(resultSet.getString("FONT_NM"));
									returnTbhMcStandCompntItemDVO.setFontValue(resultSet.getBigDecimal("FONT_VALUE"));
									returnTbhMcStandCompntItemDVO.setFrclorValue(resultSet.getBigDecimal("FRCLOR_VALUE"));
									returnTbhMcStandCompntItemDVO.setBckclorValue(resultSet.getBigDecimal("BCKCLOR_VALUE"));
									return returnTbhMcStandCompntItemDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMcStandCompntItem Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMcStandCompntItem Method")
	public int mergeTbhMcStandCompntItem (final TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO) {
		
		if ( selectTbhMcStandCompntItem (tbhMcStandCompntItemDVO) == null) {
			return insertTbhMcStandCompntItem(tbhMcStandCompntItemDVO);
		} else {
			return selectUpdateTbhMcStandCompntItem (tbhMcStandCompntItemDVO);
		}
	}

	/**
	 * selectUpdateTbhMcStandCompntItem Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMcStandCompntItem Method")
	public int selectUpdateTbhMcStandCompntItem (final TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO) {
		
		TbhMcStandCompntItemDVO tmpTbhMcStandCompntItemDVO =  selectTbhMcStandCompntItem (tbhMcStandCompntItemDVO);
		if ( tbhMcStandCompntItemDVO.getRevNo() != null && !"".equals(tbhMcStandCompntItemDVO.getRevNo()) ) {
			tmpTbhMcStandCompntItemDVO.setRevNo(tbhMcStandCompntItemDVO.getRevNo());
		}		
		if ( tbhMcStandCompntItemDVO.getStandCompntCode() != null && !"".equals(tbhMcStandCompntItemDVO.getStandCompntCode()) ) {
			tmpTbhMcStandCompntItemDVO.setStandCompntCode(tbhMcStandCompntItemDVO.getStandCompntCode());
		}		
		if ( tbhMcStandCompntItemDVO.getItemNo() != null && !"".equals(tbhMcStandCompntItemDVO.getItemNo()) ) {
			tmpTbhMcStandCompntItemDVO.setItemNo(tbhMcStandCompntItemDVO.getItemNo());
		}		
		if ( tbhMcStandCompntItemDVO.getLabelCont() != null && !"".equals(tbhMcStandCompntItemDVO.getLabelCont()) ) {
			tmpTbhMcStandCompntItemDVO.setLabelCont(tbhMcStandCompntItemDVO.getLabelCont());
		}		
		if ( tbhMcStandCompntItemDVO.getxValue() != null && !"".equals(tbhMcStandCompntItemDVO.getxValue()) ) {
			tmpTbhMcStandCompntItemDVO.setxValue(tbhMcStandCompntItemDVO.getxValue());
		}		
		if ( tbhMcStandCompntItemDVO.getyValue() != null && !"".equals(tbhMcStandCompntItemDVO.getyValue()) ) {
			tmpTbhMcStandCompntItemDVO.setyValue(tbhMcStandCompntItemDVO.getyValue());
		}		
		if ( tbhMcStandCompntItemDVO.getItemLeng() != null && !"".equals(tbhMcStandCompntItemDVO.getItemLeng()) ) {
			tmpTbhMcStandCompntItemDVO.setItemLeng(tbhMcStandCompntItemDVO.getItemLeng());
		}		
		if ( tbhMcStandCompntItemDVO.getItemHeit() != null && !"".equals(tbhMcStandCompntItemDVO.getItemHeit()) ) {
			tmpTbhMcStandCompntItemDVO.setItemHeit(tbhMcStandCompntItemDVO.getItemHeit());
		}		
		if ( tbhMcStandCompntItemDVO.getFontNm() != null && !"".equals(tbhMcStandCompntItemDVO.getFontNm()) ) {
			tmpTbhMcStandCompntItemDVO.setFontNm(tbhMcStandCompntItemDVO.getFontNm());
		}		
		if ( tbhMcStandCompntItemDVO.getFontValue() != null && !"".equals(tbhMcStandCompntItemDVO.getFontValue()) ) {
			tmpTbhMcStandCompntItemDVO.setFontValue(tbhMcStandCompntItemDVO.getFontValue());
		}		
		if ( tbhMcStandCompntItemDVO.getFrclorValue() != null && !"".equals(tbhMcStandCompntItemDVO.getFrclorValue()) ) {
			tmpTbhMcStandCompntItemDVO.setFrclorValue(tbhMcStandCompntItemDVO.getFrclorValue());
		}		
		if ( tbhMcStandCompntItemDVO.getBckclorValue() != null && !"".equals(tbhMcStandCompntItemDVO.getBckclorValue()) ) {
			tmpTbhMcStandCompntItemDVO.setBckclorValue(tbhMcStandCompntItemDVO.getBckclorValue());
		}		
		return updateTbhMcStandCompntItem (tmpTbhMcStandCompntItemDVO);
	}

/**
* insertBatchTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return int[]
*/
	@LocalName("insertBatchTbhMcStandCompntItem")
	public int[] insertBatchTbhMcStandCompntItem (final List tbhMcStandCompntItemDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.insertBatchTbhMcStandCompntItem.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT_ITEM (   \n");
			sql.append("        REV_NO , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        ITEM_NO , \n");
			sql.append("        LABEL_CONT , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        ITEM_LENG , \n");
			sql.append("        ITEM_HEIT , \n");
			sql.append("        FONT_NM , \n");
			sql.append("        FONT_VALUE , \n");
			sql.append("        FRCLOR_VALUE , \n");
			sql.append("        BCKCLOR_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO = (TbhMcStandCompntItemDVO)tbhMcStandCompntItemDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getBckclorValue());

						}
							public int getBatchSize() {
									return tbhMcStandCompntItemDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return int[]
*/
	@LocalName("updateBatchTbhMcStandCompntItem")
	public int[] updateBatchTbhMcStandCompntItem (final List tbhMcStandCompntItemDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.updateBatchTbhMcStandCompntItem.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT_ITEM \n");
			sql.append(" SET   \n");
			sql.append("        LABEL_CONT = ? , \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        ITEM_LENG = ? , \n");
			sql.append("        ITEM_HEIT = ? , \n");
			sql.append("        FONT_NM = ? , \n");
			sql.append("        FONT_VALUE = ? , \n");
			sql.append("        FRCLOR_VALUE = ? , \n");
			sql.append("        BCKCLOR_VALUE = ? \n");
			sql.append(" WHERE REV_NO = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");
			sql.append("   AND ITEM_NO = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO = (TbhMcStandCompntItemDVO)tbhMcStandCompntItemDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbhMcStandCompntItemDVO.getBckclorValue());

							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
						}
							public int getBatchSize() {
									return tbhMcStandCompntItemDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMcStandCompntItem Method
* 
* @ref_table TBH_MC_STAND_COMPNT_ITEM
* @return int[]
*/
	@LocalName("deleteBatchTbhMcStandCompntItem")
	public int[] deleteBatchTbhMcStandCompntItem (final List tbhMcStandCompntItemDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcStandCompntItemDEM.deleteBatchTbhMcStandCompntItem.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT_ITEM \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");
			sql.append("    AND ITEM_NO = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcStandCompntItemDVO tbhMcStandCompntItemDVO = (TbhMcStandCompntItemDVO)tbhMcStandCompntItemDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMcStandCompntItemDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntItemDVO.getItemNo());
						}
							public int getBatchSize() {
									return tbhMcStandCompntItemDVOList.size();
							}
					}
		);			
	}

	
}