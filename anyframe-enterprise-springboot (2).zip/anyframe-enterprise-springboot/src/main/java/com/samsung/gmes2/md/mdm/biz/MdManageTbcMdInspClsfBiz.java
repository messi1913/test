/**
 * <PRE>
 * System Name : MD
 * Business Name : MDM
 * Class Name : MdManageTbcMdInspClsfBiz.java
 * Description : 마스터 테이블 TbcMdInspClsf에 대한 CRUD 컴포넌트
 * Modification History
 *          수정일              수정자          수정내용
 *    -----------------------------------------------------
 *    2011.07.21                호건웅           최초 생성    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.text.SimpleDateFormat;
import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.md.model.TbcMdInspClsfDEM;
import com.samsung.gmes2.md.model.TbcMdInspClsfDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;


public class MdManageTbcMdInspClsfBiz {

	/**
	 * 검사 분류 코드를 생성한다
	 * @name_ko 검사 분류 코드 생성 메서드
	 */
	public TbcMdInspClsfDVO createNewTbcMdInspClsfRow( TbcMdInspClsfDVO inputDvo ) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 생성하려는 정보가 참조 무결성을 위반했는지 판단
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		// 참조 무결성을 만족했으면 생성 수행 
		return CrudUtil.create( inputDvo );
	}
	/**
	 * 검사 분류 코드 정보에서 단건 조회를 수행한다
	 * @name_ko 검사 분류 코드에 대한 단건 조회 메서드
	 */
	public TbcMdInspClsfDVO getTbcMdInspClsfRow(TbcMdInspClsfDVO inputDvo) throws Exception{
		return CrudUtil.get( inputDvo );
	}
	/**
	 * 검사 분류 코드 정보를 수정한다
	 * @name_ko 검사 분류 코드 수정 메서드
	 */
	public TbcMdInspClsfDVO updateTbcMdInspClsfRow( TbcMdInspClsfDVO inputDvo ) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 수정하려는 정보가 참조 무결성을 위반했는지 판단
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

		// 참조 무결성을 만족했으면 수정 수행
		return CrudUtil.update( inputDvo );
	}
	/**
	 * 검사 분류 코드 삭제를 수행한다
	 * @name_ko 검사 분류 코드 삭제 메서드
	 */
	public TbcMdInspClsfDVO deleteTbcMdInspClsfRow( TbcMdInspClsfDVO inputDvo ) throws Exception{
		return CrudUtil.delete( inputDvo );
	}
	
	/**
	 * 검사 분류 코드에 대해 다건 조회를 수행한다
	 * @name_ko 검사 분류 코드 다건 조회 메서드
	 */
	public List listTbcMdInspClsf(TbcMdInspClsfDVO inputDvo) throws Exception{
		

		List resultList = CrudUtil.list0(TbcMdInspClsfDVO.class, inputDvo, 0, 0);
		/*--------------------------------------------------
		 * @fd_if 다건 조회 결과가 있다면 조회 결과를 받은 리스트를 리턴 
		 * @fd_id 0001
		 --------------------------------------------------*/
		if( resultList.size() != 0) {
			return resultList;
		}
		// 아니면 null 값을 리턴
		return null;
	}
	
	/**
	 * 수정, 생성 시 참조 무결성 위반 여부를 판단한다
	 * @name_ko 참조 무결성 확인 메서드
	 */
	private void checkIntegrityConstraint( TbcMdInspClsfDVO inputDvo ) throws Exception{
		TbcMdCommCodeDVO tbcMdCommCodeDVOForLageClsfCode = new TbcMdCommCodeDVO();
		TbcMdCommCodeDVO tbcMdCommCodeDVOForMidClsfCode = new TbcMdCommCodeDVO();
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정) 하려는 정보중 대분류 코드는 TBC_MD_COMM_CODE의 commCode에 기등록 되어있어야함
		 * @fd_id 0002
		 --------------------------------------------------*/
		//TODO
		BaseUtil.populate( inputDvo	, tbcMdCommCodeDVOForLageClsfCode
				, "lageClsfCode:commCode" );
		BaseUtil.checkFound( tbcMdCommCodeDVOForLageClsfCode );
		/*--------------------------------------------------
		 * @fd_do_end 0002
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_do_start 등록(수정) 하려는 정보중 중분류 코드는 TBC_MD_COMM_CODE의 commCode에 기등록 되어있어야함
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO		
		BaseUtil.populate( inputDvo	, tbcMdCommCodeDVOForMidClsfCode
								, "midClsfCode:commCode" );
		BaseUtil.checkFound( tbcMdCommCodeDVOForMidClsfCode );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

	}
}
