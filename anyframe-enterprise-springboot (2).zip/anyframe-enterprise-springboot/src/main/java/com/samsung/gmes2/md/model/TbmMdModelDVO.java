package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
public class TbmMdModelDVO extends AbstractDVO {

	@Length(20) @NotNull
	private String modelCode;

	@Length(30) @NotNull
	private String prodCode;

	@Length(30) 
	private String prodTypeCode;

	@Length(30) @NotNull
	private String modelGrpCode;

	@Length(30) @NotNull
	private String pjtCode;

	@Length(30) 
	private String devTaskCode;

	@Length(5) @Scale(2) 
	private BigDecimal revVer;

	@Length(30) 
	private String segCode;

	@Length(30) 
	private String basicModelCode;

	@Length(30) 
	private String salModelCode;

	@Length(30) @NotNull
	private String eanCode;

	@Length(30) @NotNull
	private String upcCode;

	@Length(30) @NotNull
	private String kanCode;

	@Length(30) @NotNull
	private String domExpGubunCode;

	@Length(1) 
	private String oemYn;

	@Length(1) 
	private String disuseYn;

	@Length(500) 
	private String colorNm;

	@Length(11) @Scale(5) 
	private BigDecimal prodTotalWeit;

	@Length(11) @Scale(5) 
	private BigDecimal prodActuWeit;

	@Length(11) @Scale(5) 
	private BigDecimal prodSize;

	@Length(500) 
	private String chassisNm;

	@Length(14)
	private String fstRegDt;

	@Length(50)
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getModelCode() {
		this.modelCode = super.getValue("modelCode");
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue("modelCode", modelCode);
		this.modelCode = modelCode;
	}
	
	public String getProdCode() {
		this.prodCode = super.getValue("prodCode");
		return this.prodCode;
	}

	public void setProdCode(String prodCode) {
        super.setValue("prodCode", prodCode);
		this.prodCode = prodCode;
	}
	
	public String getProdTypeCode() {
		this.prodTypeCode = super.getValue("prodTypeCode");
		return this.prodTypeCode;
	}

	public void setProdTypeCode(String prodTypeCode) {
        super.setValue("prodTypeCode", prodTypeCode);
		this.prodTypeCode = prodTypeCode;
	}
	
	public String getModelGrpCode() {
		this.modelGrpCode = super.getValue("modelGrpCode");
		return this.modelGrpCode;
	}

	public void setModelGrpCode(String modelGrpCode) {
        super.setValue("modelGrpCode", modelGrpCode);
		this.modelGrpCode = modelGrpCode;
	}
	
	public String getPjtCode() {
		this.pjtCode = super.getValue("pjtCode");
		return this.pjtCode;
	}

	public void setPjtCode(String pjtCode) {
        super.setValue("pjtCode", pjtCode);
		this.pjtCode = pjtCode;
	}
	
	public String getDevTaskCode() {
		this.devTaskCode = super.getValue("devTaskCode");
		return this.devTaskCode;
	}

	public void setDevTaskCode(String devTaskCode) {
        super.setValue("devTaskCode", devTaskCode);
		this.devTaskCode = devTaskCode;
	}
	
	public BigDecimal getRevVer() {
		this.revVer = super.getValue("revVer");
		return this.revVer;
	}

	public void setRevVer(BigDecimal revVer) {
        super.setValue("revVer", revVer);
		this.revVer = revVer;
	}
	
	public String getSegCode() {
		this.segCode = super.getValue("segCode");
		return this.segCode;
	}

	public void setSegCode(String segCode) {
        super.setValue("segCode", segCode);
		this.segCode = segCode;
	}
	
	public String getBasicModelCode() {
		this.basicModelCode = super.getValue("basicModelCode");
		return this.basicModelCode;
	}

	public void setBasicModelCode(String basicModelCode) {
        super.setValue("basicModelCode", basicModelCode);
		this.basicModelCode = basicModelCode;
	}
	
	public String getSalModelCode() {
		this.salModelCode = super.getValue("salModelCode");
		return this.salModelCode;
	}

	public void setSalModelCode(String salModelCode) {
        super.setValue("salModelCode", salModelCode);
		this.salModelCode = salModelCode;
	}
	
	public String getEanCode() {
		this.eanCode = super.getValue("eanCode");
		return this.eanCode;
	}

	public void setEanCode(String eanCode) {
        super.setValue("eanCode", eanCode);
		this.eanCode = eanCode;
	}
	
	public String getUpcCode() {
		this.upcCode = super.getValue("upcCode");
		return this.upcCode;
	}

	public void setUpcCode(String upcCode) {
        super.setValue("upcCode", upcCode);
		this.upcCode = upcCode;
	}
	
	public String getKanCode() {
		this.kanCode = super.getValue("kanCode");
		return this.kanCode;
	}

	public void setKanCode(String kanCode) {
        super.setValue("kanCode", kanCode);
		this.kanCode = kanCode;
	}
	
	public String getDomExpGubunCode() {
		this.domExpGubunCode = super.getValue("domExpGubunCode");
		return this.domExpGubunCode;
	}

	public void setDomExpGubunCode(String domExpGubunCode) {
        super.setValue("domExpGubunCode", domExpGubunCode);
		this.domExpGubunCode = domExpGubunCode;
	}
	
	public String getOemYn() {
		this.oemYn = super.getValue("oemYn");
		return this.oemYn;
	}

	public void setOemYn(String oemYn) {
        super.setValue("oemYn", oemYn);
		this.oemYn = oemYn;
	}
	
	public String getDisuseYn() {
		this.disuseYn = super.getValue("disuseYn");
		return this.disuseYn;
	}

	public void setDisuseYn(String disuseYn) {
        super.setValue("disuseYn", disuseYn);
		this.disuseYn = disuseYn;
	}
	
	public String getColorNm() {
		this.colorNm = super.getValue("colorNm");
		return this.colorNm;
	}

	public void setColorNm(String colorNm) {
        super.setValue("colorNm", colorNm);
		this.colorNm = colorNm;
	}
	
	public BigDecimal getProdTotalWeit() {
		this.prodTotalWeit = super.getValue("prodTotalWeit");
		return this.prodTotalWeit;
	}

	public void setProdTotalWeit(BigDecimal prodTotalWeit) {
        super.setValue("prodTotalWeit", prodTotalWeit);
		this.prodTotalWeit = prodTotalWeit;
	}
	
	public BigDecimal getProdActuWeit() {
		this.prodActuWeit = super.getValue("prodActuWeit");
		return this.prodActuWeit;
	}

	public void setProdActuWeit(BigDecimal prodActuWeit) {
        super.setValue("prodActuWeit", prodActuWeit);
		this.prodActuWeit = prodActuWeit;
	}
	
	public BigDecimal getProdSize() {
		this.prodSize = super.getValue("prodSize");
		return this.prodSize;
	}

	public void setProdSize(BigDecimal prodSize) {
        super.setValue("prodSize", prodSize);
		this.prodSize = prodSize;
	}
	
	public String getChassisNm() {
		this.chassisNm = super.getValue("chassisNm");
		return this.chassisNm;
	}

	public void setChassisNm(String chassisNm) {
        super.setValue("chassisNm", chassisNm);
		this.chassisNm = chassisNm;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}