package com.samsung.gmes2.md.loss.biz;

public class MdManageDutyClsfBiz {

	/**
	 * 책임분류코드 목록 조회
	 */
	public void listDutyClsfCode(){}

	/**
	 * 책임분류코드 목록 저장
	 */
	public void saveDutyClsfCode(){}

}
