package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_PROC
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbhMdProcDEM extends AbstractDAO {


/**
* insertTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return int
*/
	@LocalName("insertTbhMdProc")
	public int insertTbhMdProc (final TbhMdProcDVO tbhMdProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdProcDEM.insertTbhMdProc.001*/  \n");
			sql.append(" TBH_MD_PROC (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        PROC_NM , \n");
			sql.append("        BCD_SUMR_YN , \n");
			sql.append("        BCR_ID , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        OPER_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        AUTO_STOP_YN , \n");
			sql.append("        EARLY_ALRM_YN , \n");
			sql.append("        INLINE_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
							ps.setString(psCount++, tbhMdProcDVO.getProcNm());
							ps.setString(psCount++, tbhMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbhMdProcDVO.getBcrId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdProcDVO.getOperYn());
							ps.setString(psCount++, tbhMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbhMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbhMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbhMdProcDVO.getUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdProcDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdProc Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdProc Method")
	public int[][] updateBatchAllTbhMdProc (final List  tbhMdProcDVOList) {
		
		ArrayList updatetbhMdProcDVOList = new ArrayList();
		ArrayList insertttbhMdProcDVOList = new ArrayList();
		ArrayList deletetbhMdProcDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdProcDVOList.size() ; i++) {
		  TbhMdProcDVO tbhMdProcDVO = (TbhMdProcDVO) tbhMdProcDVOList.get(i);
		  
		  if (tbhMdProcDVO.getSqlAction().equals("C"))
		      insertttbhMdProcDVOList.add(tbhMdProcDVO);
		  else if (tbhMdProcDVO.getSqlAction().equals("U"))
		      updatetbhMdProcDVOList.add(tbhMdProcDVO);
		  else if (tbhMdProcDVO.getSqlAction().equals("D"))
		      deletetbhMdProcDVOList.add(tbhMdProcDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdProcDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdProc(insertttbhMdProcDVOList);
          
      if (updatetbhMdProcDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdProc(updatetbhMdProcDVOList);
      
      if (deletetbhMdProcDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdProc(deletetbhMdProcDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return int
*/
	@LocalName("updateTbhMdProc")
	public int updateTbhMdProc (final TbhMdProcDVO tbhMdProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdProcDEM.updateTbhMdProc.001*/  \n");
			sql.append(" TBH_MD_PROC \n");
			sql.append(" SET   \n");
			sql.append("        PROC_NM = ? , \n");
			sql.append("        BCD_SUMR_YN = ? , \n");
			sql.append("        BCR_ID = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        OPER_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        AUTO_STOP_YN = ? , \n");
			sql.append("        EARLY_ALRM_YN = ? , \n");
			sql.append("        INLINE_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdProcDVO.getProcNm());
							ps.setString(psCount++, tbhMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbhMdProcDVO.getBcrId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdProcDVO.getOperYn());
							ps.setString(psCount++, tbhMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbhMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbhMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbhMdProcDVO.getUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdProcDVO.getEvtNm());

							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return int
*/
	@LocalName("deleteTbhMdProc")
	public int deleteTbhMdProc (final TbhMdProcDVO tbhMdProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdProcDEM.deleteTbhMdProc.001*/  \n");
			sql.append(" TBH_MD_PROC \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return TbhMdProcDVO 
*/
	@LocalName("selectTbhMdProc")
	public TbhMdProcDVO selectTbhMdProc (final TbhMdProcDVO tbhMdProcDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdProcDEM.selectTbhMdProc.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        PROC_NM , \n");
			sql.append("        BCD_SUMR_YN , \n");
			sql.append("        BCR_ID , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        OPER_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        AUTO_STOP_YN , \n");
			sql.append("        EARLY_ALRM_YN , \n");
			sql.append("        INLINE_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBH_MD_PROC \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdProcDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdProcDVO returnTbhMdProcDVO = new TbhMdProcDVO();
									returnTbhMdProcDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbhMdProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbhMdProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbhMdProcDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdProcDVO.setProcNm(resultSet.getString("PROC_NM"));
									returnTbhMdProcDVO.setBcdSumrYn(resultSet.getString("BCD_SUMR_YN"));
									returnTbhMdProcDVO.setBcrId(resultSet.getString("BCR_ID"));
									returnTbhMdProcDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbhMdProcDVO.setOperYn(resultSet.getString("OPER_YN"));
									returnTbhMdProcDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbhMdProcDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbhMdProcDVO.setAutoStopYn(resultSet.getString("AUTO_STOP_YN"));
									returnTbhMdProcDVO.setEarlyAlrmYn(resultSet.getString("EARLY_ALRM_YN"));
									returnTbhMdProcDVO.setInlineGubunCode(resultSet.getString("INLINE_GUBUN_CODE"));
									returnTbhMdProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbhMdProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbhMdProcDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbhMdProcDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdProc Method")
	public int mergeTbhMdProc (final TbhMdProcDVO tbhMdProcDVO) {
		
		if ( selectTbhMdProc (tbhMdProcDVO) == null) {
			return insertTbhMdProc(tbhMdProcDVO);
		} else {
			return selectUpdateTbhMdProc (tbhMdProcDVO);
		}
	}

	/**
	 * selectUpdateTbhMdProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdProc Method")
	public int selectUpdateTbhMdProc (final TbhMdProcDVO tbhMdProcDVO) {
		
		TbhMdProcDVO tmpTbhMdProcDVO =  selectTbhMdProc (tbhMdProcDVO);
		if ( tbhMdProcDVO.getFctCode() != null && !"".equals(tbhMdProcDVO.getFctCode()) ) {
			tmpTbhMdProcDVO.setFctCode(tbhMdProcDVO.getFctCode());
		}		
		if ( tbhMdProcDVO.getLineCode() != null && !"".equals(tbhMdProcDVO.getLineCode()) ) {
			tmpTbhMdProcDVO.setLineCode(tbhMdProcDVO.getLineCode());
		}		
		if ( tbhMdProcDVO.getUnitProcCode() != null && !"".equals(tbhMdProcDVO.getUnitProcCode()) ) {
			tmpTbhMdProcDVO.setUnitProcCode(tbhMdProcDVO.getUnitProcCode());
		}		
		if ( tbhMdProcDVO.getHistTsp() != null && !"".equals(tbhMdProcDVO.getHistTsp()) ) {
			tmpTbhMdProcDVO.setHistTsp(tbhMdProcDVO.getHistTsp());
		}		
		if ( tbhMdProcDVO.getProcNm() != null && !"".equals(tbhMdProcDVO.getProcNm()) ) {
			tmpTbhMdProcDVO.setProcNm(tbhMdProcDVO.getProcNm());
		}		
		if ( tbhMdProcDVO.getBcdSumrYn() != null && !"".equals(tbhMdProcDVO.getBcdSumrYn()) ) {
			tmpTbhMdProcDVO.setBcdSumrYn(tbhMdProcDVO.getBcdSumrYn());
		}		
		if ( tbhMdProcDVO.getBcrId() != null && !"".equals(tbhMdProcDVO.getBcrId()) ) {
			tmpTbhMdProcDVO.setBcrId(tbhMdProcDVO.getBcrId());
		}		
		if ( tbhMdProcDVO.getFnlAcrsReflYn() != null && !"".equals(tbhMdProcDVO.getFnlAcrsReflYn()) ) {
			tmpTbhMdProcDVO.setFnlAcrsReflYn(tbhMdProcDVO.getFnlAcrsReflYn());
		}		
		if ( tbhMdProcDVO.getOperYn() != null && !"".equals(tbhMdProcDVO.getOperYn()) ) {
			tmpTbhMdProcDVO.setOperYn(tbhMdProcDVO.getOperYn());
		}		
		if ( tbhMdProcDVO.getCatvUseYn() != null && !"".equals(tbhMdProcDVO.getCatvUseYn()) ) {
			tmpTbhMdProcDVO.setCatvUseYn(tbhMdProcDVO.getCatvUseYn());
		}		
		if ( tbhMdProcDVO.getBoardUseYn() != null && !"".equals(tbhMdProcDVO.getBoardUseYn()) ) {
			tmpTbhMdProcDVO.setBoardUseYn(tbhMdProcDVO.getBoardUseYn());
		}		
		if ( tbhMdProcDVO.getAutoStopYn() != null && !"".equals(tbhMdProcDVO.getAutoStopYn()) ) {
			tmpTbhMdProcDVO.setAutoStopYn(tbhMdProcDVO.getAutoStopYn());
		}		
		if ( tbhMdProcDVO.getEarlyAlrmYn() != null && !"".equals(tbhMdProcDVO.getEarlyAlrmYn()) ) {
			tmpTbhMdProcDVO.setEarlyAlrmYn(tbhMdProcDVO.getEarlyAlrmYn());
		}		
		if ( tbhMdProcDVO.getInlineGubunCode() != null && !"".equals(tbhMdProcDVO.getInlineGubunCode()) ) {
			tmpTbhMdProcDVO.setInlineGubunCode(tbhMdProcDVO.getInlineGubunCode());
		}		
		if ( tbhMdProcDVO.getUseYn() != null && !"".equals(tbhMdProcDVO.getUseYn()) ) {
			tmpTbhMdProcDVO.setUseYn(tbhMdProcDVO.getUseYn());
		}		
		if ( tbhMdProcDVO.getFstRegDt() != null && !"".equals(tbhMdProcDVO.getFstRegDt()) ) {
			tmpTbhMdProcDVO.setFstRegDt(tbhMdProcDVO.getFstRegDt());
		}		
		if ( tbhMdProcDVO.getFstRegerId() != null && !"".equals(tbhMdProcDVO.getFstRegerId()) ) {
			tmpTbhMdProcDVO.setFstRegerId(tbhMdProcDVO.getFstRegerId());
		}		
		if ( tbhMdProcDVO.getFnlUpdDt() != null && !"".equals(tbhMdProcDVO.getFnlUpdDt()) ) {
			tmpTbhMdProcDVO.setFnlUpdDt(tbhMdProcDVO.getFnlUpdDt());
		}		
		if ( tbhMdProcDVO.getFnlUpderId() != null && !"".equals(tbhMdProcDVO.getFnlUpderId()) ) {
			tmpTbhMdProcDVO.setFnlUpderId(tbhMdProcDVO.getFnlUpderId());
		}		
		if ( tbhMdProcDVO.getEvtNm() != null && !"".equals(tbhMdProcDVO.getEvtNm()) ) {
			tmpTbhMdProcDVO.setEvtNm(tbhMdProcDVO.getEvtNm());
		}		
		return updateTbhMdProc (tmpTbhMdProcDVO);
	}

/**
* insertBatchTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return int[]
*/
	@LocalName("insertBatchTbhMdProc")
	public int[] insertBatchTbhMdProc (final List tbhMdProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdProcDEM.insertBatchTbhMdProc.001*/  \n");
			sql.append(" TBH_MD_PROC (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        PROC_NM , \n");
			sql.append("        BCD_SUMR_YN , \n");
			sql.append("        BCR_ID , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        OPER_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        AUTO_STOP_YN , \n");
			sql.append("        EARLY_ALRM_YN , \n");
			sql.append("        INLINE_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdProcDVO tbhMdProcDVO = (TbhMdProcDVO)tbhMdProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
							ps.setString(psCount++, tbhMdProcDVO.getProcNm());
							ps.setString(psCount++, tbhMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbhMdProcDVO.getBcrId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdProcDVO.getOperYn());
							ps.setString(psCount++, tbhMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbhMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbhMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbhMdProcDVO.getUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdProcDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbhMdProcDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return int[]
*/
	@LocalName("updateBatchTbhMdProc")
	public int[] updateBatchTbhMdProc (final List tbhMdProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdProcDEM.updateBatchTbhMdProc.001*/  \n");
			sql.append(" TBH_MD_PROC \n");
			sql.append(" SET   \n");
			sql.append("        PROC_NM = ? , \n");
			sql.append("        BCD_SUMR_YN = ? , \n");
			sql.append("        BCR_ID = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        OPER_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        AUTO_STOP_YN = ? , \n");
			sql.append("        EARLY_ALRM_YN = ? , \n");
			sql.append("        INLINE_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdProcDVO tbhMdProcDVO = (TbhMdProcDVO)tbhMdProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdProcDVO.getProcNm());
							ps.setString(psCount++, tbhMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbhMdProcDVO.getBcrId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdProcDVO.getOperYn());
							ps.setString(psCount++, tbhMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbhMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbhMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbhMdProcDVO.getUseYn());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdProcDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdProcDVO.getEvtNm());

							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdProcDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdProc Method
* 
* @ref_table TBH_MD_PROC
* @return int[]
*/
	@LocalName("deleteBatchTbhMdProc")
	public int[] deleteBatchTbhMdProc (final List tbhMdProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdProcDEM.deleteBatchTbhMdProc.001*/  \n");
			sql.append(" TBH_MD_PROC \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdProcDVO tbhMdProcDVO = (TbhMdProcDVO)tbhMdProcDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdProcDVO.getFctCode());
							ps.setString(psCount++, tbhMdProcDVO.getLineCode());
							ps.setString(psCount++, tbhMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbhMdProcDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdProcDVOList.size();
							}
					}
		);			
	}

	
}