package com.samsung.gmes2.md.material.biz;

public class MdManageUnitIdBiz {

	/**
	 * UNIT ID 목록 조회
	 */
	public void listUnitId(){}

	/**
	 * UNIT ID 목록 저장
	 */
	public void saveUnitId(){}

}
