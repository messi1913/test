package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_QUAL_STOP_BASE
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbmMdQualStopBaseDEM extends AbstractDAO {


/**
* insertTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return int
*/
	@LocalName("insertTbmMdQualStopBase")
	public int insertTbmMdQualStopBase (final TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.insertTbmMdQualStopBase.001*/  \n");
			sql.append(" TBM_MD_QUAL_STOP_BASE (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        BASE_HMS_SSOP , \n");
			sql.append("        APLY_QTY , \n");
			sql.append("        BASE_DEFT_RATE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseHmsSsop());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getAplyQty());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseDeftRate());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdQualStopBase Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdQualStopBase Method")
	public int[][] updateBatchAllTbmMdQualStopBase (final List  tbmMdQualStopBaseDVOList) {
		
		ArrayList updatetbmMdQualStopBaseDVOList = new ArrayList();
		ArrayList insertttbmMdQualStopBaseDVOList = new ArrayList();
		ArrayList deletetbmMdQualStopBaseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdQualStopBaseDVOList.size() ; i++) {
		  TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO = (TbmMdQualStopBaseDVO) tbmMdQualStopBaseDVOList.get(i);
		  
		  if (tbmMdQualStopBaseDVO.getSqlAction().equals("C"))
		      insertttbmMdQualStopBaseDVOList.add(tbmMdQualStopBaseDVO);
		  else if (tbmMdQualStopBaseDVO.getSqlAction().equals("U"))
		      updatetbmMdQualStopBaseDVOList.add(tbmMdQualStopBaseDVO);
		  else if (tbmMdQualStopBaseDVO.getSqlAction().equals("D"))
		      deletetbmMdQualStopBaseDVOList.add(tbmMdQualStopBaseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdQualStopBaseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdQualStopBase(insertttbmMdQualStopBaseDVOList);
          
      if (updatetbmMdQualStopBaseDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdQualStopBase(updatetbmMdQualStopBaseDVOList);
      
      if (deletetbmMdQualStopBaseDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdQualStopBase(deletetbmMdQualStopBaseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return int
*/
	@LocalName("updateTbmMdQualStopBase")
	public int updateTbmMdQualStopBase (final TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.updateTbmMdQualStopBase.001*/  \n");
			sql.append(" TBM_MD_QUAL_STOP_BASE \n");
			sql.append(" SET   \n");
			sql.append("        BASE_HMS_SSOP = ? , \n");
			sql.append("        APLY_QTY = ? , \n");
			sql.append("        BASE_DEFT_RATE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_PART_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND DEFT_SYMP_CLSF_CODE = ? \n");
			sql.append("   AND GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseHmsSsop());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getAplyQty());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseDeftRate());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());
						}
					}
		);			
	}

/**
* deleteTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return int
*/
	@LocalName("deleteTbmMdQualStopBase")
	public int deleteTbmMdQualStopBase (final TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.deleteTbmMdQualStopBase.001*/  \n");
			sql.append(" TBM_MD_QUAL_STOP_BASE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND DEFT_SYMP_CLSF_CODE = ? \n");
			sql.append("    AND GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());
						}
					}
		);			
	}

/**
* selectTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return TbmMdQualStopBaseDVO 
*/
	@LocalName("selectTbmMdQualStopBase")
	public TbmMdQualStopBaseDVO selectTbmMdQualStopBase (final TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.selectTbmMdQualStopBase.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        BASE_HMS_SSOP , \n");
			sql.append("        APLY_QTY , \n");
			sql.append("        BASE_DEFT_RATE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE \n");
			sql.append("   FROM TBM_MD_QUAL_STOP_BASE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND DEFT_SYMP_CLSF_CODE = ? \n");
			sql.append("    AND GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");

		return (TbmMdQualStopBaseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdQualStopBaseDVO returnTbmMdQualStopBaseDVO = new TbmMdQualStopBaseDVO();
									returnTbmMdQualStopBaseDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdQualStopBaseDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdQualStopBaseDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdQualStopBaseDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdQualStopBaseDVO.setDeftSympClsfCode(resultSet.getString("DEFT_SYMP_CLSF_CODE"));
									returnTbmMdQualStopBaseDVO.setBaseHmsSsop(resultSet.getBigDecimal("BASE_HMS_SSOP"));
									returnTbmMdQualStopBaseDVO.setAplyQty(resultSet.getBigDecimal("APLY_QTY"));
									returnTbmMdQualStopBaseDVO.setBaseDeftRate(resultSet.getBigDecimal("BASE_DEFT_RATE"));
									returnTbmMdQualStopBaseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdQualStopBaseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdQualStopBaseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdQualStopBaseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdQualStopBaseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbmMdQualStopBaseDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdQualStopBaseDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									return returnTbmMdQualStopBaseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdQualStopBase Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdQualStopBase Method")
	public int mergeTbmMdQualStopBase (final TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) {
		
		if ( selectTbmMdQualStopBase (tbmMdQualStopBaseDVO) == null) {
			return insertTbmMdQualStopBase(tbmMdQualStopBaseDVO);
		} else {
			return selectUpdateTbmMdQualStopBase (tbmMdQualStopBaseDVO);
		}
	}

	/**
	 * selectUpdateTbmMdQualStopBase Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdQualStopBase Method")
	public int selectUpdateTbmMdQualStopBase (final TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) {
		
		TbmMdQualStopBaseDVO tmpTbmMdQualStopBaseDVO =  selectTbmMdQualStopBase (tbmMdQualStopBaseDVO);
		if ( tbmMdQualStopBaseDVO.getFctCode() != null && !"".equals(tbmMdQualStopBaseDVO.getFctCode()) ) {
			tmpTbmMdQualStopBaseDVO.setFctCode(tbmMdQualStopBaseDVO.getFctCode());
		}		
		if ( tbmMdQualStopBaseDVO.getMfgPartCode() != null && !"".equals(tbmMdQualStopBaseDVO.getMfgPartCode()) ) {
			tmpTbmMdQualStopBaseDVO.setMfgPartCode(tbmMdQualStopBaseDVO.getMfgPartCode());
		}		
		if ( tbmMdQualStopBaseDVO.getLineCode() != null && !"".equals(tbmMdQualStopBaseDVO.getLineCode()) ) {
			tmpTbmMdQualStopBaseDVO.setLineCode(tbmMdQualStopBaseDVO.getLineCode());
		}		
		if ( tbmMdQualStopBaseDVO.getUnitProcCode() != null && !"".equals(tbmMdQualStopBaseDVO.getUnitProcCode()) ) {
			tmpTbmMdQualStopBaseDVO.setUnitProcCode(tbmMdQualStopBaseDVO.getUnitProcCode());
		}		
		if ( tbmMdQualStopBaseDVO.getDeftSympClsfCode() != null && !"".equals(tbmMdQualStopBaseDVO.getDeftSympClsfCode()) ) {
			tmpTbmMdQualStopBaseDVO.setDeftSympClsfCode(tbmMdQualStopBaseDVO.getDeftSympClsfCode());
		}		
		if ( tbmMdQualStopBaseDVO.getBaseHmsSsop() != null && !"".equals(tbmMdQualStopBaseDVO.getBaseHmsSsop()) ) {
			tmpTbmMdQualStopBaseDVO.setBaseHmsSsop(tbmMdQualStopBaseDVO.getBaseHmsSsop());
		}		
		if ( tbmMdQualStopBaseDVO.getAplyQty() != null && !"".equals(tbmMdQualStopBaseDVO.getAplyQty()) ) {
			tmpTbmMdQualStopBaseDVO.setAplyQty(tbmMdQualStopBaseDVO.getAplyQty());
		}		
		if ( tbmMdQualStopBaseDVO.getBaseDeftRate() != null && !"".equals(tbmMdQualStopBaseDVO.getBaseDeftRate()) ) {
			tmpTbmMdQualStopBaseDVO.setBaseDeftRate(tbmMdQualStopBaseDVO.getBaseDeftRate());
		}		
		if ( tbmMdQualStopBaseDVO.getUseYn() != null && !"".equals(tbmMdQualStopBaseDVO.getUseYn()) ) {
			tmpTbmMdQualStopBaseDVO.setUseYn(tbmMdQualStopBaseDVO.getUseYn());
		}		
		if ( tbmMdQualStopBaseDVO.getFstRegDt() != null && !"".equals(tbmMdQualStopBaseDVO.getFstRegDt()) ) {
			tmpTbmMdQualStopBaseDVO.setFstRegDt(tbmMdQualStopBaseDVO.getFstRegDt());
		}		
		if ( tbmMdQualStopBaseDVO.getFstRegerId() != null && !"".equals(tbmMdQualStopBaseDVO.getFstRegerId()) ) {
			tmpTbmMdQualStopBaseDVO.setFstRegerId(tbmMdQualStopBaseDVO.getFstRegerId());
		}		
		if ( tbmMdQualStopBaseDVO.getFnlUpdDt() != null && !"".equals(tbmMdQualStopBaseDVO.getFnlUpdDt()) ) {
			tmpTbmMdQualStopBaseDVO.setFnlUpdDt(tbmMdQualStopBaseDVO.getFnlUpdDt());
		}		
		if ( tbmMdQualStopBaseDVO.getFnlUpderId() != null && !"".equals(tbmMdQualStopBaseDVO.getFnlUpderId()) ) {
			tmpTbmMdQualStopBaseDVO.setFnlUpderId(tbmMdQualStopBaseDVO.getFnlUpderId());
		}		
		if ( tbmMdQualStopBaseDVO.getGbmCode() != null && !"".equals(tbmMdQualStopBaseDVO.getGbmCode()) ) {
			tmpTbmMdQualStopBaseDVO.setGbmCode(tbmMdQualStopBaseDVO.getGbmCode());
		}		
		if ( tbmMdQualStopBaseDVO.getCorpCode() != null && !"".equals(tbmMdQualStopBaseDVO.getCorpCode()) ) {
			tmpTbmMdQualStopBaseDVO.setCorpCode(tbmMdQualStopBaseDVO.getCorpCode());
		}		
		return updateTbmMdQualStopBase (tmpTbmMdQualStopBaseDVO);
	}

/**
* insertBatchTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return int[]
*/
	@LocalName("insertBatchTbmMdQualStopBase")
	public int[] insertBatchTbmMdQualStopBase (final List tbmMdQualStopBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.insertBatchTbmMdQualStopBase.001*/  \n");
			sql.append(" TBM_MD_QUAL_STOP_BASE (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        BASE_HMS_SSOP , \n");
			sql.append("        APLY_QTY , \n");
			sql.append("        BASE_DEFT_RATE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO = (TbmMdQualStopBaseDVO)tbmMdQualStopBaseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseHmsSsop());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getAplyQty());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseDeftRate());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());

						}
							public int getBatchSize() {
									return tbmMdQualStopBaseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return int[]
*/
	@LocalName("updateBatchTbmMdQualStopBase")
	public int[] updateBatchTbmMdQualStopBase (final List tbmMdQualStopBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.updateBatchTbmMdQualStopBase.001*/  \n");
			sql.append(" TBM_MD_QUAL_STOP_BASE \n");
			sql.append(" SET   \n");
			sql.append("        BASE_HMS_SSOP = ? , \n");
			sql.append("        APLY_QTY = ? , \n");
			sql.append("        BASE_DEFT_RATE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_PART_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND DEFT_SYMP_CLSF_CODE = ? \n");
			sql.append("   AND GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO = (TbmMdQualStopBaseDVO)tbmMdQualStopBaseDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseHmsSsop());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getAplyQty());
							ps.setBigDecimal(psCount++, tbmMdQualStopBaseDVO.getBaseDeftRate());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());
						}
							public int getBatchSize() {
									return tbmMdQualStopBaseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdQualStopBase Method
* 
* @ref_table TBM_MD_QUAL_STOP_BASE
* @return int[]
*/
	@LocalName("deleteBatchTbmMdQualStopBase")
	public int[] deleteBatchTbmMdQualStopBase (final List tbmMdQualStopBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdQualStopBaseDEM.deleteBatchTbmMdQualStopBase.001*/  \n");
			sql.append(" TBM_MD_QUAL_STOP_BASE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND DEFT_SYMP_CLSF_CODE = ? \n");
			sql.append("    AND GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO = (TbmMdQualStopBaseDVO)tbmMdQualStopBaseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdQualStopBaseDVO.getFctCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getLineCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdQualStopBaseDVO.getCorpCode());
						}
							public int getBatchSize() {
									return tbmMdQualStopBaseDVOList.size();
							}
					}
		);			
	}

	
}