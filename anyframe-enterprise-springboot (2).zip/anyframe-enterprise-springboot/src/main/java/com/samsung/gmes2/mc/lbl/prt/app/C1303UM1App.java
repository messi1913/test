/**
 * <PRE>
 * System Name : MC
 * Business Name : 라벨발행
 * Class Name : MCU023M01App.java
 * Description : 일반라벨 발행
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------------------------------------------
 *    2011. 7. 26.      kiho   최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.mc.lbl.prt.app;

import java.util.List;

/**
 * 일반라벨 발행 App.
 *
 * @name_ko 일반라벨 발행 App 클래스
 * @author  kiho
 */

public class C1303UM1App
{
    /**
     * 라벨유형코드 목록을 가져온다. (콤보박스 세팅용)
     * @return List<코드VO>   라벨유형코드 목록
     * @name_ko 라벨유형코드 리스트
     */
    public List<Object> listLabelTypeCode(){
        /*--------------------------------------------------
         * @fd_call_start 라벨유형코드 컴포넌트 호출
         * @fd_id 0001
         * 라벨유형코드 호출(베이스 컴포넌트)
         * MCCMLabelCommBiz.listLabelTypeCode()
         --------------------------------------------------*/
        //MCCMLabelCommBiz.listLabelTypeCode();

        /*--------------------------------------------------
         * @fd_call_end 0001
         --------------------------------------------------*/

        return null;
    }

    /**
     * 라벨 디자인 폼의 변수 목록 가져오기
     * @name_ko 라벨 디자인 폼의 변수 목록
     */
    public List<Object> listLabelDsgnVar(){
    	/*--------------------------------------------------
    	 * @fd_call_start 라벨 폼의 변수 목록 호출
    	 * @fd_id 0001
    	 * 변수 목록 가져오는 컴포너트 호출
    	 * MCCMLabelPrtBiz.listLabelPrtVal()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listLabelPrtVal();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }
    
    /**
     * 일반라벨 발행 시 인쇄될 변수 값 가져오기
     * @name_ko 일반라벨 발행 정보
     */
    public List<Object> getLabelGenPrtInfo(){
        /*--------------------------------------------------
         * @fd_call_start 라벨발행 변수 값 목록
         * @fd_id 0001
         * 라벨발행 변수 값 컴포넌트 목록
         * MCCMLabelPrtBiz.listLabelPrtVal()
         --------------------------------------------------*/
        //MCCMLabelPrtBiz.listLabelPrtVal();

        /*--------------------------------------------------
         * @fd_call_end 0001
         --------------------------------------------------*/
        return null;
    }
    
    /**
     * 채번된 라벨항목의 발행상태 업데이트
     * (미발행,발행)
     * @name_ko 라벨 발행상태 업데이트
     */
    public void updateLabelPrtStatus(){
        /*--------------------------------------------------
         * @fd_call_start 라벨 발행 상태 업데이트 호출
         * @fd_id 0001
         * 라벨 발행 상태 업데이트 컴포넌트 호출
         * MCCMLabelPrtBiz.updateLabelPrtStatus()
         --------------------------------------------------*/
        //MCCMLabelPrtBiz.updateLabelPrtStatus();

        /*--------------------------------------------------
         * @fd_call_end 0001
         --------------------------------------------------*/
    }
    
    /**
     * 검색된 일반라벨 발행 이력 가져오기
     * @name_ko 일반라벨 발행 이력 목록
     */
    public List<Object> listLabelGenPrtHist(){
        /*--------------------------------------------------
         * @fd_call_start 일발라벨의 발행 이력 검색
         * @fd_id 0001
         * 일발라벨의 발행 이력 검색 컴포너트 호출
         * MCCMLabelPrtBiz.listLabelGenPrtHist()
         --------------------------------------------------*/
        //MCCMLabelPrtBiz.listLabelGenPrtHist();

        /*--------------------------------------------------
         * @fd_call_end 0001
         --------------------------------------------------*/
        return null;
    }

}
