package com.samsung.gmes2.md.loss.biz;

public class MdManageBrdnActBiz {

	/**
	 * 고장조치코드 목록 조회
	 */
	public void listBrdnActCode(){}

	/**
	 * 고장조치코드 목록 저장
	 */
	public void saveBrdnActCode(){}

}
