package com.samsung.gmes2.base.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MonitorUtil
{
    private static Map<String, Object> monitorCache = new ConcurrentHashMap<String, Object>( );

    /**
     * synchronized 영역을 위한 명명된 모니터 객체를 반환합니다.<br>
     * 아래와 같은 형식으로 사용합니다. <code>
     * <pre>
     * synchronized (getMonitoer(name)) {
     * 	try {
     * 		...
     * 	} finally {
     * 		expireMonitor(name);
     * 	}
     * }
     * </pre>
     * </code>
     * 
     * @param name
     * @return
     */
    public static Object get( String name )
    {
        if ( monitorCache.containsKey( name ) )
            return monitorCache.get( name );
        synchronized (monitorCache)
        {
            if ( monitorCache.containsKey( name ) )
                return monitorCache.get( name );
            Object obj = new Object( );
            monitorCache.put( name, obj );
            return obj;
        }
    }

    /**
     * 명명된 모니터 객체를 파기합니다.
     * 
     * @param name
     */
    public static void expire( String name )
    {
        monitorCache.remove( name );
    }
}
