package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_LBL_NMG_PREISU
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcLblNmgPreisuDEM extends AbstractDAO {


/**
* insertTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return int
*/
	@LocalName("insertTbmMcLblNmgPreisu")
	public int insertTbmMcLblNmgPreisu (final TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.insertTbmMcLblNmgPreisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_PREISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        NMG_TYPE_CODE , \n");
			sql.append("        PO_NO , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        NMG_START_NO , \n");
			sql.append("        NMG_END_NO , \n");
			sql.append("        NMG_QTY , \n");
			sql.append("        PRODC_PLAN_YMD , \n");
			sql.append("        NMG_APLY_YMD , \n");
			sql.append("        PRT_QTY , \n");
			sql.append("        RE_PRT_QTY , \n");
			sql.append("        NMG_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgTypeCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgStartNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgEndNo());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getNmgQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgAplyYmd());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getPrtQty());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getRePrtQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgDesc());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcLblNmgPreisu Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcLblNmgPreisu Method")
	public int[][] updateBatchAllTbmMcLblNmgPreisu (final List  tbmMcLblNmgPreisuDVOList) {
		
		ArrayList updatetbmMcLblNmgPreisuDVOList = new ArrayList();
		ArrayList insertttbmMcLblNmgPreisuDVOList = new ArrayList();
		ArrayList deletetbmMcLblNmgPreisuDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcLblNmgPreisuDVOList.size() ; i++) {
		  TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO = (TbmMcLblNmgPreisuDVO) tbmMcLblNmgPreisuDVOList.get(i);
		  
		  if (tbmMcLblNmgPreisuDVO.getSqlAction().equals("C"))
		      insertttbmMcLblNmgPreisuDVOList.add(tbmMcLblNmgPreisuDVO);
		  else if (tbmMcLblNmgPreisuDVO.getSqlAction().equals("U"))
		      updatetbmMcLblNmgPreisuDVOList.add(tbmMcLblNmgPreisuDVO);
		  else if (tbmMcLblNmgPreisuDVO.getSqlAction().equals("D"))
		      deletetbmMcLblNmgPreisuDVOList.add(tbmMcLblNmgPreisuDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcLblNmgPreisuDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcLblNmgPreisu(insertttbmMcLblNmgPreisuDVOList);
          
      if (updatetbmMcLblNmgPreisuDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcLblNmgPreisu(updatetbmMcLblNmgPreisuDVOList);
      
      if (deletetbmMcLblNmgPreisuDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcLblNmgPreisu(deletetbmMcLblNmgPreisuDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return int
*/
	@LocalName("updateTbmMcLblNmgPreisu")
	public int updateTbmMcLblNmgPreisu (final TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.updateTbmMcLblNmgPreisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_PREISU \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        NMG_ART_ID = ? , \n");
			sql.append("        NMG_KEY_VALUE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        NMG_TYPE_CODE = ? , \n");
			sql.append("        PO_NO = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        NMG_START_NO = ? , \n");
			sql.append("        NMG_END_NO = ? , \n");
			sql.append("        NMG_QTY = ? , \n");
			sql.append("        PRODC_PLAN_YMD = ? , \n");
			sql.append("        NMG_APLY_YMD = ? , \n");
			sql.append("        PRT_QTY = ? , \n");
			sql.append("        RE_PRT_QTY = ? , \n");
			sql.append("        NMG_DESC = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgTypeCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgStartNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgEndNo());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getNmgQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgAplyYmd());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getPrtQty());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getRePrtQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgDesc());

							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
						}
					}
		);			
	}

/**
* deleteTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return int
*/
	@LocalName("deleteTbmMcLblNmgPreisu")
	public int deleteTbmMcLblNmgPreisu (final TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.deleteTbmMcLblNmgPreisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_PREISU \n");
			sql.append("  WHERE NMG_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
						}
					}
		);			
	}

/**
* selectTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return TbmMcLblNmgPreisuDVO 
*/
	@LocalName("selectTbmMcLblNmgPreisu")
	public TbmMcLblNmgPreisuDVO selectTbmMcLblNmgPreisu (final TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.selectTbmMcLblNmgPreisu.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        NMG_TYPE_CODE , \n");
			sql.append("        PO_NO , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        NMG_START_NO , \n");
			sql.append("        NMG_END_NO , \n");
			sql.append("        NMG_QTY , \n");
			sql.append("        PRODC_PLAN_YMD , \n");
			sql.append("        NMG_APLY_YMD , \n");
			sql.append("        PRT_QTY , \n");
			sql.append("        RE_PRT_QTY , \n");
			sql.append("        NMG_DESC \n");
			sql.append("   FROM TBM_MC_LBL_NMG_PREISU \n");
			sql.append("  WHERE NMG_ID = ? \n");

		return (TbmMcLblNmgPreisuDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcLblNmgPreisuDVO returnTbmMcLblNmgPreisuDVO = new TbmMcLblNmgPreisuDVO();
									returnTbmMcLblNmgPreisuDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbmMcLblNmgPreisuDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMcLblNmgPreisuDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMcLblNmgPreisuDVO.setNmgArtId(resultSet.getString("NMG_ART_ID"));
									returnTbmMcLblNmgPreisuDVO.setNmgKeyValue(resultSet.getString("NMG_KEY_VALUE"));
									returnTbmMcLblNmgPreisuDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbmMcLblNmgPreisuDVO.setNmgTypeCode(resultSet.getString("NMG_TYPE_CODE"));
									returnTbmMcLblNmgPreisuDVO.setPoNo(resultSet.getString("PO_NO"));
									returnTbmMcLblNmgPreisuDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMcLblNmgPreisuDVO.setNmgStartNo(resultSet.getString("NMG_START_NO"));
									returnTbmMcLblNmgPreisuDVO.setNmgEndNo(resultSet.getString("NMG_END_NO"));
									returnTbmMcLblNmgPreisuDVO.setNmgQty(resultSet.getBigDecimal("NMG_QTY"));
									returnTbmMcLblNmgPreisuDVO.setProdcPlanYmd(resultSet.getString("PRODC_PLAN_YMD"));
									returnTbmMcLblNmgPreisuDVO.setNmgAplyYmd(resultSet.getString("NMG_APLY_YMD"));
									returnTbmMcLblNmgPreisuDVO.setPrtQty(resultSet.getBigDecimal("PRT_QTY"));
									returnTbmMcLblNmgPreisuDVO.setRePrtQty(resultSet.getBigDecimal("RE_PRT_QTY"));
									returnTbmMcLblNmgPreisuDVO.setNmgDesc(resultSet.getString("NMG_DESC"));
									return returnTbmMcLblNmgPreisuDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcLblNmgPreisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcLblNmgPreisu Method")
	public int mergeTbmMcLblNmgPreisu (final TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO) {
		
		if ( selectTbmMcLblNmgPreisu (tbmMcLblNmgPreisuDVO) == null) {
			return insertTbmMcLblNmgPreisu(tbmMcLblNmgPreisuDVO);
		} else {
			return selectUpdateTbmMcLblNmgPreisu (tbmMcLblNmgPreisuDVO);
		}
	}

	/**
	 * selectUpdateTbmMcLblNmgPreisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcLblNmgPreisu Method")
	public int selectUpdateTbmMcLblNmgPreisu (final TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO) {
		
		TbmMcLblNmgPreisuDVO tmpTbmMcLblNmgPreisuDVO =  selectTbmMcLblNmgPreisu (tbmMcLblNmgPreisuDVO);
		if ( tbmMcLblNmgPreisuDVO.getNmgId() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgId()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgId(tbmMcLblNmgPreisuDVO.getNmgId());
		}		
		if ( tbmMcLblNmgPreisuDVO.getPlantCode() != null && !"".equals(tbmMcLblNmgPreisuDVO.getPlantCode()) ) {
			tmpTbmMcLblNmgPreisuDVO.setPlantCode(tbmMcLblNmgPreisuDVO.getPlantCode());
		}		
		if ( tbmMcLblNmgPreisuDVO.getModelCode() != null && !"".equals(tbmMcLblNmgPreisuDVO.getModelCode()) ) {
			tmpTbmMcLblNmgPreisuDVO.setModelCode(tbmMcLblNmgPreisuDVO.getModelCode());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgArtId() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgArtId()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgArtId(tbmMcLblNmgPreisuDVO.getNmgArtId());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgKeyValue() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgKeyValue()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgKeyValue(tbmMcLblNmgPreisuDVO.getNmgKeyValue());
		}		
		if ( tbmMcLblNmgPreisuDVO.getLabelId() != null && !"".equals(tbmMcLblNmgPreisuDVO.getLabelId()) ) {
			tmpTbmMcLblNmgPreisuDVO.setLabelId(tbmMcLblNmgPreisuDVO.getLabelId());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgTypeCode() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgTypeCode()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgTypeCode(tbmMcLblNmgPreisuDVO.getNmgTypeCode());
		}		
		if ( tbmMcLblNmgPreisuDVO.getPoNo() != null && !"".equals(tbmMcLblNmgPreisuDVO.getPoNo()) ) {
			tmpTbmMcLblNmgPreisuDVO.setPoNo(tbmMcLblNmgPreisuDVO.getPoNo());
		}		
		if ( tbmMcLblNmgPreisuDVO.getLineCode() != null && !"".equals(tbmMcLblNmgPreisuDVO.getLineCode()) ) {
			tmpTbmMcLblNmgPreisuDVO.setLineCode(tbmMcLblNmgPreisuDVO.getLineCode());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgStartNo() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgStartNo()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgStartNo(tbmMcLblNmgPreisuDVO.getNmgStartNo());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgEndNo() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgEndNo()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgEndNo(tbmMcLblNmgPreisuDVO.getNmgEndNo());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgQty() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgQty()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgQty(tbmMcLblNmgPreisuDVO.getNmgQty());
		}		
		if ( tbmMcLblNmgPreisuDVO.getProdcPlanYmd() != null && !"".equals(tbmMcLblNmgPreisuDVO.getProdcPlanYmd()) ) {
			tmpTbmMcLblNmgPreisuDVO.setProdcPlanYmd(tbmMcLblNmgPreisuDVO.getProdcPlanYmd());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgAplyYmd() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgAplyYmd()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgAplyYmd(tbmMcLblNmgPreisuDVO.getNmgAplyYmd());
		}		
		if ( tbmMcLblNmgPreisuDVO.getPrtQty() != null && !"".equals(tbmMcLblNmgPreisuDVO.getPrtQty()) ) {
			tmpTbmMcLblNmgPreisuDVO.setPrtQty(tbmMcLblNmgPreisuDVO.getPrtQty());
		}		
		if ( tbmMcLblNmgPreisuDVO.getRePrtQty() != null && !"".equals(tbmMcLblNmgPreisuDVO.getRePrtQty()) ) {
			tmpTbmMcLblNmgPreisuDVO.setRePrtQty(tbmMcLblNmgPreisuDVO.getRePrtQty());
		}		
		if ( tbmMcLblNmgPreisuDVO.getNmgDesc() != null && !"".equals(tbmMcLblNmgPreisuDVO.getNmgDesc()) ) {
			tmpTbmMcLblNmgPreisuDVO.setNmgDesc(tbmMcLblNmgPreisuDVO.getNmgDesc());
		}		
		return updateTbmMcLblNmgPreisu (tmpTbmMcLblNmgPreisuDVO);
	}

/**
* insertBatchTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return int[]
*/
	@LocalName("insertBatchTbmMcLblNmgPreisu")
	public int[] insertBatchTbmMcLblNmgPreisu (final List tbmMcLblNmgPreisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.insertBatchTbmMcLblNmgPreisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_PREISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        NMG_TYPE_CODE , \n");
			sql.append("        PO_NO , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        NMG_START_NO , \n");
			sql.append("        NMG_END_NO , \n");
			sql.append("        NMG_QTY , \n");
			sql.append("        PRODC_PLAN_YMD , \n");
			sql.append("        NMG_APLY_YMD , \n");
			sql.append("        PRT_QTY , \n");
			sql.append("        RE_PRT_QTY , \n");
			sql.append("        NMG_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO = (TbmMcLblNmgPreisuDVO)tbmMcLblNmgPreisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgTypeCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgStartNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgEndNo());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getNmgQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgAplyYmd());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getPrtQty());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getRePrtQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgDesc());

						}
							public int getBatchSize() {
									return tbmMcLblNmgPreisuDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return int[]
*/
	@LocalName("updateBatchTbmMcLblNmgPreisu")
	public int[] updateBatchTbmMcLblNmgPreisu (final List tbmMcLblNmgPreisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.updateBatchTbmMcLblNmgPreisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_PREISU \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        NMG_ART_ID = ? , \n");
			sql.append("        NMG_KEY_VALUE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        NMG_TYPE_CODE = ? , \n");
			sql.append("        PO_NO = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        NMG_START_NO = ? , \n");
			sql.append("        NMG_END_NO = ? , \n");
			sql.append("        NMG_QTY = ? , \n");
			sql.append("        PRODC_PLAN_YMD = ? , \n");
			sql.append("        NMG_APLY_YMD = ? , \n");
			sql.append("        PRT_QTY = ? , \n");
			sql.append("        RE_PRT_QTY = ? , \n");
			sql.append("        NMG_DESC = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO = (TbmMcLblNmgPreisuDVO)tbmMcLblNmgPreisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgTypeCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgStartNo());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgEndNo());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getNmgQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgAplyYmd());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getPrtQty());
							ps.setBigDecimal(psCount++, tbmMcLblNmgPreisuDVO.getRePrtQty());
							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgDesc());

							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
						}
							public int getBatchSize() {
									return tbmMcLblNmgPreisuDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcLblNmgPreisu Method
* 
* @ref_table TBM_MC_LBL_NMG_PREISU
* @return int[]
*/
	@LocalName("deleteBatchTbmMcLblNmgPreisu")
	public int[] deleteBatchTbmMcLblNmgPreisu (final List tbmMcLblNmgPreisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblNmgPreisuDEM.deleteBatchTbmMcLblNmgPreisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_PREISU \n");
			sql.append("  WHERE NMG_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgPreisuDVO tbmMcLblNmgPreisuDVO = (TbmMcLblNmgPreisuDVO)tbmMcLblNmgPreisuDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgPreisuDVO.getNmgId());
						}
							public int getBatchSize() {
									return tbmMcLblNmgPreisuDVOList.size();
							}
					}
		);			
	}

	
}