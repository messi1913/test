package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdAqlAplyBaseDVO extends AbstractVo {

	@Length(30) 
	private String prodGrpCode;

	@Length(30) 
	private String prodAbbrCode;

	@Length(30) 
	private String inspGubunCode;

	@Length(30) 
	private String smplCharCode;

	@Length(30) 
	private String aqlBaseCode;

	@Length(11) @Scale(5) 
	private BigDecimal smplNum;

	@Length(11) @Scale(5) 
	private BigDecimal passNum;

	@Length(11) @Scale(5) 
	private BigDecimal failNum;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getProdGrpCode() {
		this.prodGrpCode = super.getValue(0);
		return this.prodGrpCode;
	}

	public void setProdGrpCode(String prodGrpCode) {
        super.setValue(0, prodGrpCode);
		this.prodGrpCode = prodGrpCode;
	}
	
	public String getProdAbbrCode() {
		this.prodAbbrCode = super.getValue(1);
		return this.prodAbbrCode;
	}

	public void setProdAbbrCode(String prodAbbrCode) {
        super.setValue(1, prodAbbrCode);
		this.prodAbbrCode = prodAbbrCode;
	}
	
	public String getInspGubunCode() {
		this.inspGubunCode = super.getValue(2);
		return this.inspGubunCode;
	}

	public void setInspGubunCode(String inspGubunCode) {
        super.setValue(2, inspGubunCode);
		this.inspGubunCode = inspGubunCode;
	}
	
	public String getSmplCharCode() {
		this.smplCharCode = super.getValue(3);
		return this.smplCharCode;
	}

	public void setSmplCharCode(String smplCharCode) {
        super.setValue(3, smplCharCode);
		this.smplCharCode = smplCharCode;
	}
	
	public String getAqlBaseCode() {
		this.aqlBaseCode = super.getValue(4);
		return this.aqlBaseCode;
	}

	public void setAqlBaseCode(String aqlBaseCode) {
        super.setValue(4, aqlBaseCode);
		this.aqlBaseCode = aqlBaseCode;
	}
	
	public BigDecimal getSmplNum() {
		this.smplNum = super.getValue(5);
		return this.smplNum;
	}

	public void setSmplNum(BigDecimal smplNum) {
        super.setValue(5, smplNum);
		this.smplNum = smplNum;
	}
	
	public BigDecimal getPassNum() {
		this.passNum = super.getValue(6);
		return this.passNum;
	}

	public void setPassNum(BigDecimal passNum) {
        super.setValue(6, passNum);
		this.passNum = passNum;
	}
	
	public BigDecimal getFailNum() {
		this.failNum = super.getValue(7);
		return this.failNum;
	}

	public void setFailNum(BigDecimal failNum) {
        super.setValue(7, failNum);
		this.failNum = failNum;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(8);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(8, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(9);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(9, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(10);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(10, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(11);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(11, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(12);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(12, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}