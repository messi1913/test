package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdLossDutyPicDEM extends AbstractDAO {


/**
* insertTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return int
*/
	@LocalName("insertTbmMdLossDutyPic")
	public int insertTbmMdLossDutyPic (final TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.insertTbmMdLossDutyPic.001*/  \n");
			sql.append(" TBM_MD_LOSS_DUTY_PIC (   \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LOSS_DUTY_GRP_CODE , \n");
			sql.append("        LOSS_DUTY_PART_CODE , \n");
			sql.append("        PID_EMP_NO , \n");
			sql.append("        LOSS_DUTY_GRP_NM , \n");
			sql.append("        LOSS_DUTY_PART_NM , \n");
			sql.append("        PID_NM , \n");
			sql.append("        LOSS_DUTY_DESC , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyDesc());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getDutyClsfCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getUseYn());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdLossDutyPic Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdLossDutyPic Method")
	public int[][] updateBatchAllTbmMdLossDutyPic (final List  tbmMdLossDutyPicDVOList) {
		
		ArrayList updatetbmMdLossDutyPicDVOList = new ArrayList();
		ArrayList insertttbmMdLossDutyPicDVOList = new ArrayList();
		ArrayList deletetbmMdLossDutyPicDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdLossDutyPicDVOList.size() ; i++) {
		  TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO = (TbmMdLossDutyPicDVO) tbmMdLossDutyPicDVOList.get(i);
		  
		  if (tbmMdLossDutyPicDVO.getSqlAction().equals("C"))
		      insertttbmMdLossDutyPicDVOList.add(tbmMdLossDutyPicDVO);
		  else if (tbmMdLossDutyPicDVO.getSqlAction().equals("U"))
		      updatetbmMdLossDutyPicDVOList.add(tbmMdLossDutyPicDVO);
		  else if (tbmMdLossDutyPicDVO.getSqlAction().equals("D"))
		      deletetbmMdLossDutyPicDVOList.add(tbmMdLossDutyPicDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdLossDutyPicDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdLossDutyPic(insertttbmMdLossDutyPicDVOList);
          
      if (updatetbmMdLossDutyPicDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdLossDutyPic(updatetbmMdLossDutyPicDVOList);
      
      if (deletetbmMdLossDutyPicDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdLossDutyPic(deletetbmMdLossDutyPicDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return int
*/
	@LocalName("updateTbmMdLossDutyPic")
	public int updateTbmMdLossDutyPic (final TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.updateTbmMdLossDutyPic.001*/  \n");
			sql.append(" TBM_MD_LOSS_DUTY_PIC \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_DUTY_GRP_NM = ? , \n");
			sql.append("        LOSS_DUTY_PART_NM = ? , \n");
			sql.append("        PID_NM = ? , \n");
			sql.append("        LOSS_DUTY_DESC = ? , \n");
			sql.append("        DUTY_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE CORP_CODE = ? \n");
			sql.append("   AND FCT_CODE = ? \n");
			sql.append("   AND LOSS_DUTY_GRP_CODE = ? \n");
			sql.append("   AND LOSS_DUTY_PART_CODE = ? \n");
			sql.append("   AND PID_EMP_NO = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyDesc());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getDutyClsfCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getUseYn());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
						}
					}
		);			
	}

/**
* deleteTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return int
*/
	@LocalName("deleteTbmMdLossDutyPic")
	public int deleteTbmMdLossDutyPic (final TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.deleteTbmMdLossDutyPic.001*/  \n");
			sql.append(" TBM_MD_LOSS_DUTY_PIC \n");
			sql.append("  WHERE CORP_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");
			sql.append("    AND LOSS_DUTY_GRP_CODE = ? \n");
			sql.append("    AND LOSS_DUTY_PART_CODE = ? \n");
			sql.append("    AND PID_EMP_NO = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
						}
					}
		);			
	}

/**
* selectTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return TbmMdLossDutyPicDVO 
*/
	@LocalName("selectTbmMdLossDutyPic")
	public TbmMdLossDutyPicDVO selectTbmMdLossDutyPic (final TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.selectTbmMdLossDutyPic.001*/  \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LOSS_DUTY_GRP_CODE , \n");
			sql.append("        LOSS_DUTY_PART_CODE , \n");
			sql.append("        PID_EMP_NO , \n");
			sql.append("        LOSS_DUTY_GRP_NM , \n");
			sql.append("        LOSS_DUTY_PART_NM , \n");
			sql.append("        PID_NM , \n");
			sql.append("        LOSS_DUTY_DESC , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_LOSS_DUTY_PIC \n");
			sql.append("  WHERE CORP_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");
			sql.append("    AND LOSS_DUTY_GRP_CODE = ? \n");
			sql.append("    AND LOSS_DUTY_PART_CODE = ? \n");
			sql.append("    AND PID_EMP_NO = ? \n");

		return (TbmMdLossDutyPicDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdLossDutyPicDVO returnTbmMdLossDutyPicDVO = new TbmMdLossDutyPicDVO();
									returnTbmMdLossDutyPicDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMdLossDutyPicDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdLossDutyPicDVO.setLossDutyGrpCode(resultSet.getString("LOSS_DUTY_GRP_CODE"));
									returnTbmMdLossDutyPicDVO.setLossDutyPartCode(resultSet.getString("LOSS_DUTY_PART_CODE"));
									returnTbmMdLossDutyPicDVO.setPidEmpNo(resultSet.getString("PID_EMP_NO"));
									returnTbmMdLossDutyPicDVO.setLossDutyGrpNm(resultSet.getString("LOSS_DUTY_GRP_NM"));
									returnTbmMdLossDutyPicDVO.setLossDutyPartNm(resultSet.getString("LOSS_DUTY_PART_NM"));
									returnTbmMdLossDutyPicDVO.setPidNm(resultSet.getString("PID_NM"));
									returnTbmMdLossDutyPicDVO.setLossDutyDesc(resultSet.getString("LOSS_DUTY_DESC"));
									returnTbmMdLossDutyPicDVO.setDutyClsfCode(resultSet.getString("DUTY_CLSF_CODE"));
									returnTbmMdLossDutyPicDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdLossDutyPicDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdLossDutyPicDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdLossDutyPicDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdLossDutyPicDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdLossDutyPicDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdLossDutyPic Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdLossDutyPic Method")
	public int mergeTbmMdLossDutyPic (final TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO) {
		
		if ( selectTbmMdLossDutyPic (tbmMdLossDutyPicDVO) == null) {
			return insertTbmMdLossDutyPic(tbmMdLossDutyPicDVO);
		} else {
			return selectUpdateTbmMdLossDutyPic (tbmMdLossDutyPicDVO);
		}
	}

	/**
	 * selectUpdateTbmMdLossDutyPic Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdLossDutyPic Method")
	public int selectUpdateTbmMdLossDutyPic (final TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO) {
		
		TbmMdLossDutyPicDVO tmpTbmMdLossDutyPicDVO =  selectTbmMdLossDutyPic (tbmMdLossDutyPicDVO);
		if ( tbmMdLossDutyPicDVO.getCorpCode() != null && !"".equals(tbmMdLossDutyPicDVO.getCorpCode()) ) {
			tmpTbmMdLossDutyPicDVO.setCorpCode(tbmMdLossDutyPicDVO.getCorpCode());
		}		
		if ( tbmMdLossDutyPicDVO.getFctCode() != null && !"".equals(tbmMdLossDutyPicDVO.getFctCode()) ) {
			tmpTbmMdLossDutyPicDVO.setFctCode(tbmMdLossDutyPicDVO.getFctCode());
		}		
		if ( tbmMdLossDutyPicDVO.getLossDutyGrpCode() != null && !"".equals(tbmMdLossDutyPicDVO.getLossDutyGrpCode()) ) {
			tmpTbmMdLossDutyPicDVO.setLossDutyGrpCode(tbmMdLossDutyPicDVO.getLossDutyGrpCode());
		}		
		if ( tbmMdLossDutyPicDVO.getLossDutyPartCode() != null && !"".equals(tbmMdLossDutyPicDVO.getLossDutyPartCode()) ) {
			tmpTbmMdLossDutyPicDVO.setLossDutyPartCode(tbmMdLossDutyPicDVO.getLossDutyPartCode());
		}		
		if ( tbmMdLossDutyPicDVO.getPidEmpNo() != null && !"".equals(tbmMdLossDutyPicDVO.getPidEmpNo()) ) {
			tmpTbmMdLossDutyPicDVO.setPidEmpNo(tbmMdLossDutyPicDVO.getPidEmpNo());
		}		
		if ( tbmMdLossDutyPicDVO.getLossDutyGrpNm() != null && !"".equals(tbmMdLossDutyPicDVO.getLossDutyGrpNm()) ) {
			tmpTbmMdLossDutyPicDVO.setLossDutyGrpNm(tbmMdLossDutyPicDVO.getLossDutyGrpNm());
		}		
		if ( tbmMdLossDutyPicDVO.getLossDutyPartNm() != null && !"".equals(tbmMdLossDutyPicDVO.getLossDutyPartNm()) ) {
			tmpTbmMdLossDutyPicDVO.setLossDutyPartNm(tbmMdLossDutyPicDVO.getLossDutyPartNm());
		}		
		if ( tbmMdLossDutyPicDVO.getPidNm() != null && !"".equals(tbmMdLossDutyPicDVO.getPidNm()) ) {
			tmpTbmMdLossDutyPicDVO.setPidNm(tbmMdLossDutyPicDVO.getPidNm());
		}		
		if ( tbmMdLossDutyPicDVO.getLossDutyDesc() != null && !"".equals(tbmMdLossDutyPicDVO.getLossDutyDesc()) ) {
			tmpTbmMdLossDutyPicDVO.setLossDutyDesc(tbmMdLossDutyPicDVO.getLossDutyDesc());
		}		
		if ( tbmMdLossDutyPicDVO.getDutyClsfCode() != null && !"".equals(tbmMdLossDutyPicDVO.getDutyClsfCode()) ) {
			tmpTbmMdLossDutyPicDVO.setDutyClsfCode(tbmMdLossDutyPicDVO.getDutyClsfCode());
		}		
		if ( tbmMdLossDutyPicDVO.getUseYn() != null && !"".equals(tbmMdLossDutyPicDVO.getUseYn()) ) {
			tmpTbmMdLossDutyPicDVO.setUseYn(tbmMdLossDutyPicDVO.getUseYn());
		}		
		if ( tbmMdLossDutyPicDVO.getFstRegDt() != null && !"".equals(tbmMdLossDutyPicDVO.getFstRegDt()) ) {
			tmpTbmMdLossDutyPicDVO.setFstRegDt(tbmMdLossDutyPicDVO.getFstRegDt());
		}		
		if ( tbmMdLossDutyPicDVO.getFstRegerId() != null && !"".equals(tbmMdLossDutyPicDVO.getFstRegerId()) ) {
			tmpTbmMdLossDutyPicDVO.setFstRegerId(tbmMdLossDutyPicDVO.getFstRegerId());
		}		
		if ( tbmMdLossDutyPicDVO.getFnlUpdDt() != null && !"".equals(tbmMdLossDutyPicDVO.getFnlUpdDt()) ) {
			tmpTbmMdLossDutyPicDVO.setFnlUpdDt(tbmMdLossDutyPicDVO.getFnlUpdDt());
		}		
		if ( tbmMdLossDutyPicDVO.getFnlUpderId() != null && !"".equals(tbmMdLossDutyPicDVO.getFnlUpderId()) ) {
			tmpTbmMdLossDutyPicDVO.setFnlUpderId(tbmMdLossDutyPicDVO.getFnlUpderId());
		}		
		return updateTbmMdLossDutyPic (tmpTbmMdLossDutyPicDVO);
	}

/**
* insertBatchTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return int[]
*/
	@LocalName("insertBatchTbmMdLossDutyPic")
	public int[] insertBatchTbmMdLossDutyPic (final List tbmMdLossDutyPicDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.insertBatchTbmMdLossDutyPic.001*/  \n");
			sql.append(" TBM_MD_LOSS_DUTY_PIC (   \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LOSS_DUTY_GRP_CODE , \n");
			sql.append("        LOSS_DUTY_PART_CODE , \n");
			sql.append("        PID_EMP_NO , \n");
			sql.append("        LOSS_DUTY_GRP_NM , \n");
			sql.append("        LOSS_DUTY_PART_NM , \n");
			sql.append("        PID_NM , \n");
			sql.append("        LOSS_DUTY_DESC , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO = (TbmMdLossDutyPicDVO)tbmMdLossDutyPicDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyDesc());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getDutyClsfCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getUseYn());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdLossDutyPicDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return int[]
*/
	@LocalName("updateBatchTbmMdLossDutyPic")
	public int[] updateBatchTbmMdLossDutyPic (final List tbmMdLossDutyPicDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.updateBatchTbmMdLossDutyPic.001*/  \n");
			sql.append(" TBM_MD_LOSS_DUTY_PIC \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_DUTY_GRP_NM = ? , \n");
			sql.append("        LOSS_DUTY_PART_NM = ? , \n");
			sql.append("        PID_NM = ? , \n");
			sql.append("        LOSS_DUTY_DESC = ? , \n");
			sql.append("        DUTY_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE CORP_CODE = ? \n");
			sql.append("   AND FCT_CODE = ? \n");
			sql.append("   AND LOSS_DUTY_GRP_CODE = ? \n");
			sql.append("   AND LOSS_DUTY_PART_CODE = ? \n");
			sql.append("   AND PID_EMP_NO = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO = (TbmMdLossDutyPicDVO)tbmMdLossDutyPicDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidNm());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyDesc());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getDutyClsfCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getUseYn());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
						}
							public int getBatchSize() {
									return tbmMdLossDutyPicDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdLossDutyPic Method
* 
* @ref_table TBM_MD_LOSS_DUTY_PIC
* @return int[]
*/
	@LocalName("deleteBatchTbmMdLossDutyPic")
	public int[] deleteBatchTbmMdLossDutyPic (final List tbmMdLossDutyPicDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdLossDutyPicDEM.deleteBatchTbmMdLossDutyPic.001*/  \n");
			sql.append(" TBM_MD_LOSS_DUTY_PIC \n");
			sql.append("  WHERE CORP_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");
			sql.append("    AND LOSS_DUTY_GRP_CODE = ? \n");
			sql.append("    AND LOSS_DUTY_PART_CODE = ? \n");
			sql.append("    AND PID_EMP_NO = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdLossDutyPicDVO tbmMdLossDutyPicDVO = (TbmMdLossDutyPicDVO)tbmMdLossDutyPicDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdLossDutyPicDVO.getCorpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getFctCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyGrpCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getLossDutyPartCode());
							ps.setString(psCount++, tbmMdLossDutyPicDVO.getPidEmpNo());
						}
							public int getBatchSize() {
									return tbmMdLossDutyPicDVOList.size();
							}
					}
		);			
	}

	
}