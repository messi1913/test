package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 모델코드/마스터 조회 DQM
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao) @LocalName("모델코드/마스터 조회 DQM")
public class TbmMdModelDQM extends AbstractDAO {


/**
*
* SELECT 
* 	MODEL_CODE, 
* 	PROD_CODE, 
* 	PROD_TYPE_CODE, 
* 	MODEL_GRP_CODE, 
* 	PJT_CODE, 
* 	DEV_TASK_CODE, 
* 	REV_VER, 
* 	SEG_CODE, 
* 	BASIC_MODEL_CODE, 
* 	SAL_MODEL_CODE, 
* 	EAN_CODE, 
* 	UPC_CODE, 
* 	KAN_CODE, 
* 	DOM_EXP_GUBUN_CODE, 
* 	OEM_YN, 
* 	DISUSE_YN, 
* 	COLOR_NM, 
* 	PROD_TOTAL_WEIT, 
* 	PROD_ACTU_WEIT, 
* 	PROD_SIZE, 
* 	CHASSIS_NM, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_MODEL 
* WHERE 1=1 
* #if($modelCode) 
* AND MODEL_CODE = :modelCode 
* #end 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodTypeCode) 
* AND PROD_TYPE_CODE = :prodTypeCode 
* #end 
* #if($modelGrpCode) 
* AND MODEL_GRP_CODE = :modelGrpCode 
* #end 
* #if($pjtCode) 
* AND PJT_CODE = :pjtCode 
* #end 
* #if($devTaskCode) 
* AND DEV_TASK_CODE = :devTaskCode 
* #end 
* #if($revVer) 
* AND REV_VER = :revVer 
* #end 
* #if($segCode) 
* AND SEG_CODE = :segCode 
* #end 
* #if($basicModelCode) 
* AND BASIC_MODEL_CODE = :basicModelCode 
* #end 
* #if($salModelCode) 
* AND SAL_MODEL_CODE = :salModelCode 
* #end 
* #if($eanCode) 
* AND EAN_CODE = :eanCode 
* #end 
* #if($upcCode) 
* AND UPC_CODE = :upcCode 
* #end 
* #if($kanCode) 
* AND KAN_CODE = :kanCode 
* #end 
* #if($domExpGubunCode) 
* AND DOM_EXP_GUBUN_CODE = :domExpGubunCode 
* #end 
* #if($oemYn) 
* AND OEM_YN = :oemYn 
* #end 
* #if($disuseYn) 
* AND DISUSE_YN = :disuseYn 
* #end 
* #if($colorNm) 
* AND COLOR_NM = :colorNm 
* #end 
* #if($prodTotalWeit) 
* AND PROD_TOTAL_WEIT = :prodTotalWeit 
* #end 
* #if($prodActuWeit) 
* AND PROD_ACTU_WEIT = :prodActuWeit 
* #end 
* #if($prodSize) 
* AND PROD_SIZE = :prodSize 
* #end 
* #if($chassisNm) 
* AND CHASSIS_NM = :chassisNm 
* #end 
* #if($chassisNmLike) 
* AND CHASSIS_NM like '%' || :chassisNmLike || '%' 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	MODEL_CODE,  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_TYPE_CODE,  \n");
			sql.append(" 	MODEL_GRP_CODE,  \n");
			sql.append(" 	PJT_CODE,  \n");
			sql.append(" 	DEV_TASK_CODE,  \n");
			sql.append(" 	REV_VER,  \n");
			sql.append(" 	SEG_CODE,  \n");
			sql.append(" 	BASIC_MODEL_CODE,  \n");
			sql.append(" 	SAL_MODEL_CODE,  \n");
			sql.append(" 	EAN_CODE,  \n");
			sql.append(" 	UPC_CODE,  \n");
			sql.append(" 	KAN_CODE,  \n");
			sql.append(" 	DOM_EXP_GUBUN_CODE,  \n");
			sql.append(" 	OEM_YN,  \n");
			sql.append(" 	DISUSE_YN,  \n");
			sql.append(" 	COLOR_NM,  \n");
			sql.append(" 	PROD_TOTAL_WEIT,  \n");
			sql.append(" 	PROD_ACTU_WEIT,  \n");
			sql.append(" 	PROD_SIZE,  \n");
			sql.append(" 	CHASSIS_NM,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_MODEL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($modelCode)  \n");
			sql.append(" AND MODEL_CODE = :modelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTypeCode)  \n");
			sql.append(" AND PROD_TYPE_CODE = :prodTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($modelGrpCode)  \n");
			sql.append(" AND MODEL_GRP_CODE = :modelGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pjtCode)  \n");
			sql.append(" AND PJT_CODE = :pjtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($devTaskCode)  \n");
			sql.append(" AND DEV_TASK_CODE = :devTaskCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($revVer)  \n");
			sql.append(" AND REV_VER = :revVer  \n");
			sql.append(" #end  \n");
			sql.append(" #if($segCode)  \n");
			sql.append(" AND SEG_CODE = :segCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($basicModelCode)  \n");
			sql.append(" AND BASIC_MODEL_CODE = :basicModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($salModelCode)  \n");
			sql.append(" AND SAL_MODEL_CODE = :salModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($eanCode)  \n");
			sql.append(" AND EAN_CODE = :eanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($upcCode)  \n");
			sql.append(" AND UPC_CODE = :upcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($kanCode)  \n");
			sql.append(" AND KAN_CODE = :kanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($domExpGubunCode)  \n");
			sql.append(" AND DOM_EXP_GUBUN_CODE = :domExpGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($oemYn)  \n");
			sql.append(" AND OEM_YN = :oemYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($disuseYn)  \n");
			sql.append(" AND DISUSE_YN = :disuseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($colorNm)  \n");
			sql.append(" AND COLOR_NM = :colorNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTotalWeit)  \n");
			sql.append(" AND PROD_TOTAL_WEIT = :prodTotalWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodActuWeit)  \n");
			sql.append(" AND PROD_ACTU_WEIT = :prodActuWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodSize)  \n");
			sql.append(" AND PROD_SIZE = :prodSize  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNm)  \n");
			sql.append(" AND CHASSIS_NM = :chassisNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNmLike)  \n");
			sql.append(" AND CHASSIS_NM like '%' || :chassisNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdModelDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdModelDVO returnTbmMdModelDVO = new TbmMdModelDVO();
									returnTbmMdModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbmMdModelDVO.setProdTypeCode(resultSet.getString("PROD_TYPE_CODE"));
									returnTbmMdModelDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbmMdModelDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdModelDVO.setDevTaskCode(resultSet.getString("DEV_TASK_CODE"));
									returnTbmMdModelDVO.setRevVer(resultSet.getBigDecimal("REV_VER"));
									returnTbmMdModelDVO.setSegCode(resultSet.getString("SEG_CODE"));
									returnTbmMdModelDVO.setBasicModelCode(resultSet.getString("BASIC_MODEL_CODE"));
									returnTbmMdModelDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbmMdModelDVO.setEanCode(resultSet.getString("EAN_CODE"));
									returnTbmMdModelDVO.setUpcCode(resultSet.getString("UPC_CODE"));
									returnTbmMdModelDVO.setKanCode(resultSet.getString("KAN_CODE"));
									returnTbmMdModelDVO.setDomExpGubunCode(resultSet.getString("DOM_EXP_GUBUN_CODE"));
									returnTbmMdModelDVO.setOemYn(resultSet.getString("OEM_YN"));
									returnTbmMdModelDVO.setDisuseYn(resultSet.getString("DISUSE_YN"));
									returnTbmMdModelDVO.setColorNm(resultSet.getString("COLOR_NM"));
									returnTbmMdModelDVO.setProdTotalWeit(resultSet.getBigDecimal("PROD_TOTAL_WEIT"));
									returnTbmMdModelDVO.setProdActuWeit(resultSet.getBigDecimal("PROD_ACTU_WEIT"));
									returnTbmMdModelDVO.setProdSize(resultSet.getBigDecimal("PROD_SIZE"));
									returnTbmMdModelDVO.setChassisNm(resultSet.getString("CHASSIS_NM"));
									returnTbmMdModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	MODEL_CODE, 
* 	PROD_CODE, 
* 	PROD_TYPE_CODE, 
* 	MODEL_GRP_CODE, 
* 	PJT_CODE, 
* 	DEV_TASK_CODE, 
* 	REV_VER, 
* 	SEG_CODE, 
* 	BASIC_MODEL_CODE, 
* 	SAL_MODEL_CODE, 
* 	EAN_CODE, 
* 	UPC_CODE, 
* 	KAN_CODE, 
* 	DOM_EXP_GUBUN_CODE, 
* 	OEM_YN, 
* 	DISUSE_YN, 
* 	COLOR_NM, 
* 	PROD_TOTAL_WEIT, 
* 	PROD_ACTU_WEIT, 
* 	PROD_SIZE, 
* 	CHASSIS_NM, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_MODEL 
* WHERE 1=1 
* #if($modelCode) 
* AND MODEL_CODE = :modelCode 
* #end 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodTypeCode) 
* AND PROD_TYPE_CODE = :prodTypeCode 
* #end 
* #if($modelGrpCode) 
* AND MODEL_GRP_CODE = :modelGrpCode 
* #end 
* #if($pjtCode) 
* AND PJT_CODE = :pjtCode 
* #end 
* #if($devTaskCode) 
* AND DEV_TASK_CODE = :devTaskCode 
* #end 
* #if($revVer) 
* AND REV_VER = :revVer 
* #end 
* #if($segCode) 
* AND SEG_CODE = :segCode 
* #end 
* #if($basicModelCode) 
* AND BASIC_MODEL_CODE = :basicModelCode 
* #end 
* #if($salModelCode) 
* AND SAL_MODEL_CODE = :salModelCode 
* #end 
* #if($eanCode) 
* AND EAN_CODE = :eanCode 
* #end 
* #if($upcCode) 
* AND UPC_CODE = :upcCode 
* #end 
* #if($kanCode) 
* AND KAN_CODE = :kanCode 
* #end 
* #if($domExpGubunCode) 
* AND DOM_EXP_GUBUN_CODE = :domExpGubunCode 
* #end 
* #if($oemYn) 
* AND OEM_YN = :oemYn 
* #end 
* #if($disuseYn) 
* AND DISUSE_YN = :disuseYn 
* #end 
* #if($colorNm) 
* AND COLOR_NM = :colorNm 
* #end 
* #if($prodTotalWeit) 
* AND PROD_TOTAL_WEIT = :prodTotalWeit 
* #end 
* #if($prodActuWeit) 
* AND PROD_ACTU_WEIT = :prodActuWeit 
* #end 
* #if($prodSize) 
* AND PROD_SIZE = :prodSize 
* #end 
* #if($chassisNm) 
* AND CHASSIS_NM = :chassisNm 
* #end 
* #if($chassisNmLike) 
* AND CHASSIS_NM like '%' || :chassisNmLike || '%' 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	MODEL_CODE,  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_TYPE_CODE,  \n");
			sql.append(" 	MODEL_GRP_CODE,  \n");
			sql.append(" 	PJT_CODE,  \n");
			sql.append(" 	DEV_TASK_CODE,  \n");
			sql.append(" 	REV_VER,  \n");
			sql.append(" 	SEG_CODE,  \n");
			sql.append(" 	BASIC_MODEL_CODE,  \n");
			sql.append(" 	SAL_MODEL_CODE,  \n");
			sql.append(" 	EAN_CODE,  \n");
			sql.append(" 	UPC_CODE,  \n");
			sql.append(" 	KAN_CODE,  \n");
			sql.append(" 	DOM_EXP_GUBUN_CODE,  \n");
			sql.append(" 	OEM_YN,  \n");
			sql.append(" 	DISUSE_YN,  \n");
			sql.append(" 	COLOR_NM,  \n");
			sql.append(" 	PROD_TOTAL_WEIT,  \n");
			sql.append(" 	PROD_ACTU_WEIT,  \n");
			sql.append(" 	PROD_SIZE,  \n");
			sql.append(" 	CHASSIS_NM,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_MODEL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($modelCode)  \n");
			sql.append(" AND MODEL_CODE = :modelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTypeCode)  \n");
			sql.append(" AND PROD_TYPE_CODE = :prodTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($modelGrpCode)  \n");
			sql.append(" AND MODEL_GRP_CODE = :modelGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pjtCode)  \n");
			sql.append(" AND PJT_CODE = :pjtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($devTaskCode)  \n");
			sql.append(" AND DEV_TASK_CODE = :devTaskCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($revVer)  \n");
			sql.append(" AND REV_VER = :revVer  \n");
			sql.append(" #end  \n");
			sql.append(" #if($segCode)  \n");
			sql.append(" AND SEG_CODE = :segCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($basicModelCode)  \n");
			sql.append(" AND BASIC_MODEL_CODE = :basicModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($salModelCode)  \n");
			sql.append(" AND SAL_MODEL_CODE = :salModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($eanCode)  \n");
			sql.append(" AND EAN_CODE = :eanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($upcCode)  \n");
			sql.append(" AND UPC_CODE = :upcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($kanCode)  \n");
			sql.append(" AND KAN_CODE = :kanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($domExpGubunCode)  \n");
			sql.append(" AND DOM_EXP_GUBUN_CODE = :domExpGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($oemYn)  \n");
			sql.append(" AND OEM_YN = :oemYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($disuseYn)  \n");
			sql.append(" AND DISUSE_YN = :disuseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($colorNm)  \n");
			sql.append(" AND COLOR_NM = :colorNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTotalWeit)  \n");
			sql.append(" AND PROD_TOTAL_WEIT = :prodTotalWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodActuWeit)  \n");
			sql.append(" AND PROD_ACTU_WEIT = :prodActuWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodSize)  \n");
			sql.append(" AND PROD_SIZE = :prodSize  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNm)  \n");
			sql.append(" AND CHASSIS_NM = :chassisNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNmLike)  \n");
			sql.append(" AND CHASSIS_NM like '%' || :chassisNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdModelDQM.dListPage0001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdModelDVO returnTbmMdModelDVO = new TbmMdModelDVO();
									returnTbmMdModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbmMdModelDVO.setProdTypeCode(resultSet.getString("PROD_TYPE_CODE"));
									returnTbmMdModelDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbmMdModelDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdModelDVO.setDevTaskCode(resultSet.getString("DEV_TASK_CODE"));
									returnTbmMdModelDVO.setRevVer(resultSet.getBigDecimal("REV_VER"));
									returnTbmMdModelDVO.setSegCode(resultSet.getString("SEG_CODE"));
									returnTbmMdModelDVO.setBasicModelCode(resultSet.getString("BASIC_MODEL_CODE"));
									returnTbmMdModelDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbmMdModelDVO.setEanCode(resultSet.getString("EAN_CODE"));
									returnTbmMdModelDVO.setUpcCode(resultSet.getString("UPC_CODE"));
									returnTbmMdModelDVO.setKanCode(resultSet.getString("KAN_CODE"));
									returnTbmMdModelDVO.setDomExpGubunCode(resultSet.getString("DOM_EXP_GUBUN_CODE"));
									returnTbmMdModelDVO.setOemYn(resultSet.getString("OEM_YN"));
									returnTbmMdModelDVO.setDisuseYn(resultSet.getString("DISUSE_YN"));
									returnTbmMdModelDVO.setColorNm(resultSet.getString("COLOR_NM"));
									returnTbmMdModelDVO.setProdTotalWeit(resultSet.getBigDecimal("PROD_TOTAL_WEIT"));
									returnTbmMdModelDVO.setProdActuWeit(resultSet.getBigDecimal("PROD_ACTU_WEIT"));
									returnTbmMdModelDVO.setProdSize(resultSet.getBigDecimal("PROD_SIZE"));
									returnTbmMdModelDVO.setChassisNm(resultSet.getString("CHASSIS_NM"));
									returnTbmMdModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	MODEL_CODE, 
* 	PROD_CODE, 
* 	PROD_TYPE_CODE, 
* 	MODEL_GRP_CODE, 
* 	PJT_CODE, 
* 	DEV_TASK_CODE, 
* 	REV_VER, 
* 	SEG_CODE, 
* 	BASIC_MODEL_CODE, 
* 	SAL_MODEL_CODE, 
* 	EAN_CODE, 
* 	UPC_CODE, 
* 	KAN_CODE, 
* 	DOM_EXP_GUBUN_CODE, 
* 	OEM_YN, 
* 	DISUSE_YN, 
* 	COLOR_NM, 
* 	PROD_TOTAL_WEIT, 
* 	PROD_ACTU_WEIT, 
* 	PROD_SIZE, 
* 	CHASSIS_NM, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_MODEL 
* WHERE 1=1 
* #if($modelCode) 
* AND MODEL_CODE = :modelCode 
* #end 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodTypeCode) 
* AND PROD_TYPE_CODE = :prodTypeCode 
* #end 
* #if($modelGrpCode) 
* AND MODEL_GRP_CODE = :modelGrpCode 
* #end 
* #if($pjtCode) 
* AND PJT_CODE = :pjtCode 
* #end 
* #if($devTaskCode) 
* AND DEV_TASK_CODE = :devTaskCode 
* #end 
* #if($revVer) 
* AND REV_VER = :revVer 
* #end 
* #if($segCode) 
* AND SEG_CODE = :segCode 
* #end 
* #if($basicModelCode) 
* AND BASIC_MODEL_CODE = :basicModelCode 
* #end 
* #if($salModelCode) 
* AND SAL_MODEL_CODE = :salModelCode 
* #end 
* #if($eanCode) 
* AND EAN_CODE = :eanCode 
* #end 
* #if($upcCode) 
* AND UPC_CODE = :upcCode 
* #end 
* #if($kanCode) 
* AND KAN_CODE = :kanCode 
* #end 
* #if($domExpGubunCode) 
* AND DOM_EXP_GUBUN_CODE = :domExpGubunCode 
* #end 
* #if($oemYn) 
* AND OEM_YN = :oemYn 
* #end 
* #if($disuseYn) 
* AND DISUSE_YN = :disuseYn 
* #end 
* #if($colorNm) 
* AND COLOR_NM = :colorNm 
* #end 
* #if($prodTotalWeit) 
* AND PROD_TOTAL_WEIT = :prodTotalWeit 
* #end 
* #if($prodActuWeit) 
* AND PROD_ACTU_WEIT = :prodActuWeit 
* #end 
* #if($prodSize) 
* AND PROD_SIZE = :prodSize 
* #end 
* #if($chassisNm) 
* AND CHASSIS_NM = :chassisNm 
* #end 
* #if($chassisNmLike) 
* AND CHASSIS_NM like '%' || :chassisNmLike || '%' 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	MODEL_CODE,  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_TYPE_CODE,  \n");
			sql.append(" 	MODEL_GRP_CODE,  \n");
			sql.append(" 	PJT_CODE,  \n");
			sql.append(" 	DEV_TASK_CODE,  \n");
			sql.append(" 	REV_VER,  \n");
			sql.append(" 	SEG_CODE,  \n");
			sql.append(" 	BASIC_MODEL_CODE,  \n");
			sql.append(" 	SAL_MODEL_CODE,  \n");
			sql.append(" 	EAN_CODE,  \n");
			sql.append(" 	UPC_CODE,  \n");
			sql.append(" 	KAN_CODE,  \n");
			sql.append(" 	DOM_EXP_GUBUN_CODE,  \n");
			sql.append(" 	OEM_YN,  \n");
			sql.append(" 	DISUSE_YN,  \n");
			sql.append(" 	COLOR_NM,  \n");
			sql.append(" 	PROD_TOTAL_WEIT,  \n");
			sql.append(" 	PROD_ACTU_WEIT,  \n");
			sql.append(" 	PROD_SIZE,  \n");
			sql.append(" 	CHASSIS_NM,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_MODEL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($modelCode)  \n");
			sql.append(" AND MODEL_CODE = :modelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTypeCode)  \n");
			sql.append(" AND PROD_TYPE_CODE = :prodTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($modelGrpCode)  \n");
			sql.append(" AND MODEL_GRP_CODE = :modelGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pjtCode)  \n");
			sql.append(" AND PJT_CODE = :pjtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($devTaskCode)  \n");
			sql.append(" AND DEV_TASK_CODE = :devTaskCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($revVer)  \n");
			sql.append(" AND REV_VER = :revVer  \n");
			sql.append(" #end  \n");
			sql.append(" #if($segCode)  \n");
			sql.append(" AND SEG_CODE = :segCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($basicModelCode)  \n");
			sql.append(" AND BASIC_MODEL_CODE = :basicModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($salModelCode)  \n");
			sql.append(" AND SAL_MODEL_CODE = :salModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($eanCode)  \n");
			sql.append(" AND EAN_CODE = :eanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($upcCode)  \n");
			sql.append(" AND UPC_CODE = :upcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($kanCode)  \n");
			sql.append(" AND KAN_CODE = :kanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($domExpGubunCode)  \n");
			sql.append(" AND DOM_EXP_GUBUN_CODE = :domExpGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($oemYn)  \n");
			sql.append(" AND OEM_YN = :oemYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($disuseYn)  \n");
			sql.append(" AND DISUSE_YN = :disuseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($colorNm)  \n");
			sql.append(" AND COLOR_NM = :colorNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTotalWeit)  \n");
			sql.append(" AND PROD_TOTAL_WEIT = :prodTotalWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodActuWeit)  \n");
			sql.append(" AND PROD_ACTU_WEIT = :prodActuWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodSize)  \n");
			sql.append(" AND PROD_SIZE = :prodSize  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNm)  \n");
			sql.append(" AND CHASSIS_NM = :chassisNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNmLike)  \n");
			sql.append(" AND CHASSIS_NM like '%' || :chassisNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdModelDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdModelDVO returnTbmMdModelDVO = new TbmMdModelDVO();
									returnTbmMdModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbmMdModelDVO.setProdTypeCode(resultSet.getString("PROD_TYPE_CODE"));
									returnTbmMdModelDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbmMdModelDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdModelDVO.setDevTaskCode(resultSet.getString("DEV_TASK_CODE"));
									returnTbmMdModelDVO.setRevVer(resultSet.getBigDecimal("REV_VER"));
									returnTbmMdModelDVO.setSegCode(resultSet.getString("SEG_CODE"));
									returnTbmMdModelDVO.setBasicModelCode(resultSet.getString("BASIC_MODEL_CODE"));
									returnTbmMdModelDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbmMdModelDVO.setEanCode(resultSet.getString("EAN_CODE"));
									returnTbmMdModelDVO.setUpcCode(resultSet.getString("UPC_CODE"));
									returnTbmMdModelDVO.setKanCode(resultSet.getString("KAN_CODE"));
									returnTbmMdModelDVO.setDomExpGubunCode(resultSet.getString("DOM_EXP_GUBUN_CODE"));
									returnTbmMdModelDVO.setOemYn(resultSet.getString("OEM_YN"));
									returnTbmMdModelDVO.setDisuseYn(resultSet.getString("DISUSE_YN"));
									returnTbmMdModelDVO.setColorNm(resultSet.getString("COLOR_NM"));
									returnTbmMdModelDVO.setProdTotalWeit(resultSet.getBigDecimal("PROD_TOTAL_WEIT"));
									returnTbmMdModelDVO.setProdActuWeit(resultSet.getBigDecimal("PROD_ACTU_WEIT"));
									returnTbmMdModelDVO.setProdSize(resultSet.getBigDecimal("PROD_SIZE"));
									returnTbmMdModelDVO.setChassisNm(resultSet.getString("CHASSIS_NM"));
									returnTbmMdModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	MODEL_CODE, 
* 	PROD_CODE, 
* 	PROD_TYPE_CODE, 
* 	MODEL_GRP_CODE, 
* 	PJT_CODE, 
* 	DEV_TASK_CODE, 
* 	REV_VER, 
* 	SEG_CODE, 
* 	BASIC_MODEL_CODE, 
* 	SAL_MODEL_CODE, 
* 	EAN_CODE, 
* 	UPC_CODE, 
* 	KAN_CODE, 
* 	DOM_EXP_GUBUN_CODE, 
* 	OEM_YN, 
* 	DISUSE_YN, 
* 	COLOR_NM, 
* 	PROD_TOTAL_WEIT, 
* 	PROD_ACTU_WEIT, 
* 	PROD_SIZE, 
* 	CHASSIS_NM, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_MODEL 
* WHERE 1=1 
* #if($modelCode) 
* AND MODEL_CODE = :modelCode 
* #end 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodTypeCode) 
* AND PROD_TYPE_CODE = :prodTypeCode 
* #end 
* #if($modelGrpCode) 
* AND MODEL_GRP_CODE = :modelGrpCode 
* #end 
* #if($pjtCode) 
* AND PJT_CODE = :pjtCode 
* #end 
* #if($devTaskCode) 
* AND DEV_TASK_CODE = :devTaskCode 
* #end 
* #if($revVer) 
* AND REV_VER = :revVer 
* #end 
* #if($segCode) 
* AND SEG_CODE = :segCode 
* #end 
* #if($basicModelCode) 
* AND BASIC_MODEL_CODE = :basicModelCode 
* #end 
* #if($salModelCode) 
* AND SAL_MODEL_CODE = :salModelCode 
* #end 
* #if($eanCode) 
* AND EAN_CODE = :eanCode 
* #end 
* #if($upcCode) 
* AND UPC_CODE = :upcCode 
* #end 
* #if($kanCode) 
* AND KAN_CODE = :kanCode 
* #end 
* #if($domExpGubunCode) 
* AND DOM_EXP_GUBUN_CODE = :domExpGubunCode 
* #end 
* #if($oemYn) 
* AND OEM_YN = :oemYn 
* #end 
* #if($disuseYn) 
* AND DISUSE_YN = :disuseYn 
* #end 
* #if($colorNm) 
* AND COLOR_NM = :colorNm 
* #end 
* #if($prodTotalWeit) 
* AND PROD_TOTAL_WEIT = :prodTotalWeit 
* #end 
* #if($prodActuWeit) 
* AND PROD_ACTU_WEIT = :prodActuWeit 
* #end 
* #if($prodSize) 
* AND PROD_SIZE = :prodSize 
* #end 
* #if($chassisNm) 
* AND CHASSIS_NM = :chassisNm 
* #end 
* #if($chassisNmLike) 
* AND CHASSIS_NM like '%' || :chassisNmLike || '%' 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	MODEL_CODE,  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_TYPE_CODE,  \n");
			sql.append(" 	MODEL_GRP_CODE,  \n");
			sql.append(" 	PJT_CODE,  \n");
			sql.append(" 	DEV_TASK_CODE,  \n");
			sql.append(" 	REV_VER,  \n");
			sql.append(" 	SEG_CODE,  \n");
			sql.append(" 	BASIC_MODEL_CODE,  \n");
			sql.append(" 	SAL_MODEL_CODE,  \n");
			sql.append(" 	EAN_CODE,  \n");
			sql.append(" 	UPC_CODE,  \n");
			sql.append(" 	KAN_CODE,  \n");
			sql.append(" 	DOM_EXP_GUBUN_CODE,  \n");
			sql.append(" 	OEM_YN,  \n");
			sql.append(" 	DISUSE_YN,  \n");
			sql.append(" 	COLOR_NM,  \n");
			sql.append(" 	PROD_TOTAL_WEIT,  \n");
			sql.append(" 	PROD_ACTU_WEIT,  \n");
			sql.append(" 	PROD_SIZE,  \n");
			sql.append(" 	CHASSIS_NM,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_MODEL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($modelCode)  \n");
			sql.append(" AND MODEL_CODE = :modelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTypeCode)  \n");
			sql.append(" AND PROD_TYPE_CODE = :prodTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($modelGrpCode)  \n");
			sql.append(" AND MODEL_GRP_CODE = :modelGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pjtCode)  \n");
			sql.append(" AND PJT_CODE = :pjtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($devTaskCode)  \n");
			sql.append(" AND DEV_TASK_CODE = :devTaskCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($revVer)  \n");
			sql.append(" AND REV_VER = :revVer  \n");
			sql.append(" #end  \n");
			sql.append(" #if($segCode)  \n");
			sql.append(" AND SEG_CODE = :segCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($basicModelCode)  \n");
			sql.append(" AND BASIC_MODEL_CODE = :basicModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($salModelCode)  \n");
			sql.append(" AND SAL_MODEL_CODE = :salModelCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($eanCode)  \n");
			sql.append(" AND EAN_CODE = :eanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($upcCode)  \n");
			sql.append(" AND UPC_CODE = :upcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($kanCode)  \n");
			sql.append(" AND KAN_CODE = :kanCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($domExpGubunCode)  \n");
			sql.append(" AND DOM_EXP_GUBUN_CODE = :domExpGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($oemYn)  \n");
			sql.append(" AND OEM_YN = :oemYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($disuseYn)  \n");
			sql.append(" AND DISUSE_YN = :disuseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($colorNm)  \n");
			sql.append(" AND COLOR_NM = :colorNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodTotalWeit)  \n");
			sql.append(" AND PROD_TOTAL_WEIT = :prodTotalWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodActuWeit)  \n");
			sql.append(" AND PROD_ACTU_WEIT = :prodActuWeit  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodSize)  \n");
			sql.append(" AND PROD_SIZE = :prodSize  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNm)  \n");
			sql.append(" AND CHASSIS_NM = :chassisNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($chassisNmLike)  \n");
			sql.append(" AND CHASSIS_NM like '%' || :chassisNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdModelDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdModelDVO returnTbmMdModelDVO = new TbmMdModelDVO();
									returnTbmMdModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbmMdModelDVO.setProdTypeCode(resultSet.getString("PROD_TYPE_CODE"));
									returnTbmMdModelDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbmMdModelDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdModelDVO.setDevTaskCode(resultSet.getString("DEV_TASK_CODE"));
									returnTbmMdModelDVO.setRevVer(resultSet.getBigDecimal("REV_VER"));
									returnTbmMdModelDVO.setSegCode(resultSet.getString("SEG_CODE"));
									returnTbmMdModelDVO.setBasicModelCode(resultSet.getString("BASIC_MODEL_CODE"));
									returnTbmMdModelDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbmMdModelDVO.setEanCode(resultSet.getString("EAN_CODE"));
									returnTbmMdModelDVO.setUpcCode(resultSet.getString("UPC_CODE"));
									returnTbmMdModelDVO.setKanCode(resultSet.getString("KAN_CODE"));
									returnTbmMdModelDVO.setDomExpGubunCode(resultSet.getString("DOM_EXP_GUBUN_CODE"));
									returnTbmMdModelDVO.setOemYn(resultSet.getString("OEM_YN"));
									returnTbmMdModelDVO.setDisuseYn(resultSet.getString("DISUSE_YN"));
									returnTbmMdModelDVO.setColorNm(resultSet.getString("COLOR_NM"));
									returnTbmMdModelDVO.setProdTotalWeit(resultSet.getBigDecimal("PROD_TOTAL_WEIT"));
									returnTbmMdModelDVO.setProdActuWeit(resultSet.getBigDecimal("PROD_ACTU_WEIT"));
									returnTbmMdModelDVO.setProdSize(resultSet.getBigDecimal("PROD_SIZE"));
									returnTbmMdModelDVO.setChassisNm(resultSet.getString("CHASSIS_NM"));
									returnTbmMdModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}