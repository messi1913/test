package com.samsung.gmes2.md.logi.biz;

public class MdManageSnNoMstBiz {

	/**
	 * 기본마스터정보 조회
	 */
	public void listSnNoMst(){}

	/**
	 * 기본마스터정보 저장
	 */
	public void saveSnNoMst(){}

}
