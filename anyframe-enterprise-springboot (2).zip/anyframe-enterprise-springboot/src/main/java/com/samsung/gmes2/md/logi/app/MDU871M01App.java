package com.samsung.gmes2.md.logi.app;

public class MDU871M01App {

	/**
	 * 이동지시권한 목록 초기설정
	 */
	public void initMoveInstUser(){}

	/**
	 * 이동지시권한 목록 조회
	 */
	public void listMoveInstUser(){}

	/**
	 * 이동지시권한 목록 엑셀 다운로드
	 */
	public void excelMoveInstUser(){}

	/**
	 * 이동지시권한 목록 저장
	 */
	public void saveMoveInstUser(){}

}
