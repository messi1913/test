package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbmMcLblNmgArtDVO extends AbstractVo {

	@Length(50) 
	private String nmgArtId;

	@Length(30) 
	private String artTypeCode;

	@Length(11) @Scale(5) 
	private BigDecimal nmgRngMinValue;

	@Length(11) @Scale(5) 
	private BigDecimal nmgRngMaxValue;

	@Length(20) 
	private String divCode;

	@Length(3) 
	private String prtTypeCode;

	@Length(1000) 
	private String nmgRuleDesc;

	@Length(50) 
	private String hqLabelId;


	public String getNmgArtId() {
		this.nmgArtId = super.getValue(0);
		return this.nmgArtId;
	}

	public void setNmgArtId(String nmgArtId) {
        super.setValue(0, nmgArtId);
		this.nmgArtId = nmgArtId;
	}
	
	public String getArtTypeCode() {
		this.artTypeCode = super.getValue(1);
		return this.artTypeCode;
	}

	public void setArtTypeCode(String artTypeCode) {
        super.setValue(1, artTypeCode);
		this.artTypeCode = artTypeCode;
	}
	
	public BigDecimal getNmgRngMinValue() {
		this.nmgRngMinValue = super.getValue(2);
		return this.nmgRngMinValue;
	}

	public void setNmgRngMinValue(BigDecimal nmgRngMinValue) {
        super.setValue(2, nmgRngMinValue);
		this.nmgRngMinValue = nmgRngMinValue;
	}
	
	public BigDecimal getNmgRngMaxValue() {
		this.nmgRngMaxValue = super.getValue(3);
		return this.nmgRngMaxValue;
	}

	public void setNmgRngMaxValue(BigDecimal nmgRngMaxValue) {
        super.setValue(3, nmgRngMaxValue);
		this.nmgRngMaxValue = nmgRngMaxValue;
	}
	
	public String getDivCode() {
		this.divCode = super.getValue(4);
		return this.divCode;
	}

	public void setDivCode(String divCode) {
        super.setValue(4, divCode);
		this.divCode = divCode;
	}
	
	public String getPrtTypeCode() {
		this.prtTypeCode = super.getValue(5);
		return this.prtTypeCode;
	}

	public void setPrtTypeCode(String prtTypeCode) {
        super.setValue(5, prtTypeCode);
		this.prtTypeCode = prtTypeCode;
	}
	
	public String getNmgRuleDesc() {
		this.nmgRuleDesc = super.getValue(6);
		return this.nmgRuleDesc;
	}

	public void setNmgRuleDesc(String nmgRuleDesc) {
        super.setValue(6, nmgRuleDesc);
		this.nmgRuleDesc = nmgRuleDesc;
	}
	
	public String getHqLabelId() {
		this.hqLabelId = super.getValue(7);
		return this.hqLabelId;
	}

	public void setHqLabelId(String hqLabelId) {
        super.setValue(7, hqLabelId);
		this.hqLabelId = hqLabelId;
	}
	
}