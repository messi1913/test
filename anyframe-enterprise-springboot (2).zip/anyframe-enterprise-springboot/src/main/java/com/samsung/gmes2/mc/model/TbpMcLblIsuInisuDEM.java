package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBP_MC_LBL_ISU_INISU
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbpMcLblIsuInisuDEM extends AbstractDAO {


/**
* insertTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return int
*/
	@LocalName("insertTbpMcLblIsuInisu")
	public int insertTbpMcLblIsuInisu (final TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.insertTbpMcLblIsuInisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_INISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        PLANT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPlantCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbpMcLblIsuInisu Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbpMcLblIsuInisu Method")
	public int[][] updateBatchAllTbpMcLblIsuInisu (final List  tbpMcLblIsuInisuDVOList) {
		
		ArrayList updatetbpMcLblIsuInisuDVOList = new ArrayList();
		ArrayList insertttbpMcLblIsuInisuDVOList = new ArrayList();
		ArrayList deletetbpMcLblIsuInisuDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbpMcLblIsuInisuDVOList.size() ; i++) {
		  TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO = (TbpMcLblIsuInisuDVO) tbpMcLblIsuInisuDVOList.get(i);
		  
		  if (tbpMcLblIsuInisuDVO.getSqlAction().equals("C"))
		      insertttbpMcLblIsuInisuDVOList.add(tbpMcLblIsuInisuDVO);
		  else if (tbpMcLblIsuInisuDVO.getSqlAction().equals("U"))
		      updatetbpMcLblIsuInisuDVOList.add(tbpMcLblIsuInisuDVO);
		  else if (tbpMcLblIsuInisuDVO.getSqlAction().equals("D"))
		      deletetbpMcLblIsuInisuDVOList.add(tbpMcLblIsuInisuDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbpMcLblIsuInisuDVOList.size() > 0) 
          resultValues[0] = insertBatchTbpMcLblIsuInisu(insertttbpMcLblIsuInisuDVOList);
          
      if (updatetbpMcLblIsuInisuDVOList.size() >0)
          resultValues[1] = updateBatchTbpMcLblIsuInisu(updatetbpMcLblIsuInisuDVOList);
      
      if (deletetbpMcLblIsuInisuDVOList.size() >0)
          resultValues[2] = deleteBatchTbpMcLblIsuInisu(deletetbpMcLblIsuInisuDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return int
*/
	@LocalName("updateTbpMcLblIsuInisu")
	public int updateTbpMcLblIsuInisu (final TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.updateTbpMcLblIsuInisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_INISU \n");
			sql.append(" SET   \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        PLANT_CODE = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPlantCode());

							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
						}
					}
		);			
	}

/**
* deleteTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return int
*/
	@LocalName("deleteTbpMcLblIsuInisu")
	public int deleteTbpMcLblIsuInisu (final TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.deleteTbpMcLblIsuInisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_INISU \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
						}
					}
		);			
	}

/**
* selectTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return TbpMcLblIsuInisuDVO 
*/
	@LocalName("selectTbpMcLblIsuInisu")
	public TbpMcLblIsuInisuDVO selectTbpMcLblIsuInisu (final TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.selectTbpMcLblIsuInisu.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        PLANT_CODE \n");
			sql.append("   FROM TBP_MC_LBL_ISU_INISU \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return (TbpMcLblIsuInisuDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbpMcLblIsuInisuDVO returnTbpMcLblIsuInisuDVO = new TbpMcLblIsuInisuDVO();
									returnTbpMcLblIsuInisuDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbpMcLblIsuInisuDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbpMcLblIsuInisuDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbpMcLblIsuInisuDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbpMcLblIsuInisuDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbpMcLblIsuInisuDVO.setRePrtYn(resultSet.getString("RE_PRT_YN"));
									returnTbpMcLblIsuInisuDVO.setRePrtRsn(resultSet.getString("RE_PRT_RSN"));
									returnTbpMcLblIsuInisuDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									return returnTbpMcLblIsuInisuDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbpMcLblIsuInisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbpMcLblIsuInisu Method")
	public int mergeTbpMcLblIsuInisu (final TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO) {
		
		if ( selectTbpMcLblIsuInisu (tbpMcLblIsuInisuDVO) == null) {
			return insertTbpMcLblIsuInisu(tbpMcLblIsuInisuDVO);
		} else {
			return selectUpdateTbpMcLblIsuInisu (tbpMcLblIsuInisuDVO);
		}
	}

	/**
	 * selectUpdateTbpMcLblIsuInisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbpMcLblIsuInisu Method")
	public int selectUpdateTbpMcLblIsuInisu (final TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO) {
		
		TbpMcLblIsuInisuDVO tmpTbpMcLblIsuInisuDVO =  selectTbpMcLblIsuInisu (tbpMcLblIsuInisuDVO);
		if ( tbpMcLblIsuInisuDVO.getNmgId() != null && !"".equals(tbpMcLblIsuInisuDVO.getNmgId()) ) {
			tmpTbpMcLblIsuInisuDVO.setNmgId(tbpMcLblIsuInisuDVO.getNmgId());
		}		
		if ( tbpMcLblIsuInisuDVO.getPrtDt() != null && !"".equals(tbpMcLblIsuInisuDVO.getPrtDt()) ) {
			tmpTbpMcLblIsuInisuDVO.setPrtDt(tbpMcLblIsuInisuDVO.getPrtDt());
		}		
		if ( tbpMcLblIsuInisuDVO.getModelCode() != null && !"".equals(tbpMcLblIsuInisuDVO.getModelCode()) ) {
			tmpTbpMcLblIsuInisuDVO.setModelCode(tbpMcLblIsuInisuDVO.getModelCode());
		}		
		if ( tbpMcLblIsuInisuDVO.getLabelId() != null && !"".equals(tbpMcLblIsuInisuDVO.getLabelId()) ) {
			tmpTbpMcLblIsuInisuDVO.setLabelId(tbpMcLblIsuInisuDVO.getLabelId());
		}		
		if ( tbpMcLblIsuInisuDVO.getPrterId() != null && !"".equals(tbpMcLblIsuInisuDVO.getPrterId()) ) {
			tmpTbpMcLblIsuInisuDVO.setPrterId(tbpMcLblIsuInisuDVO.getPrterId());
		}		
		if ( tbpMcLblIsuInisuDVO.getRePrtYn() != null && !"".equals(tbpMcLblIsuInisuDVO.getRePrtYn()) ) {
			tmpTbpMcLblIsuInisuDVO.setRePrtYn(tbpMcLblIsuInisuDVO.getRePrtYn());
		}		
		if ( tbpMcLblIsuInisuDVO.getRePrtRsn() != null && !"".equals(tbpMcLblIsuInisuDVO.getRePrtRsn()) ) {
			tmpTbpMcLblIsuInisuDVO.setRePrtRsn(tbpMcLblIsuInisuDVO.getRePrtRsn());
		}		
		if ( tbpMcLblIsuInisuDVO.getPlantCode() != null && !"".equals(tbpMcLblIsuInisuDVO.getPlantCode()) ) {
			tmpTbpMcLblIsuInisuDVO.setPlantCode(tbpMcLblIsuInisuDVO.getPlantCode());
		}		
		return updateTbpMcLblIsuInisu (tmpTbpMcLblIsuInisuDVO);
	}

/**
* insertBatchTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return int[]
*/
	@LocalName("insertBatchTbpMcLblIsuInisu")
	public int[] insertBatchTbpMcLblIsuInisu (final List tbpMcLblIsuInisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.insertBatchTbpMcLblIsuInisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_INISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        PLANT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO = (TbpMcLblIsuInisuDVO)tbpMcLblIsuInisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPlantCode());

						}
							public int getBatchSize() {
									return tbpMcLblIsuInisuDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return int[]
*/
	@LocalName("updateBatchTbpMcLblIsuInisu")
	public int[] updateBatchTbpMcLblIsuInisu (final List tbpMcLblIsuInisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.updateBatchTbpMcLblIsuInisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_INISU \n");
			sql.append(" SET   \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        PLANT_CODE = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO = (TbpMcLblIsuInisuDVO)tbpMcLblIsuInisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPlantCode());

							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLblIsuInisuDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbpMcLblIsuInisu Method
* 
* @ref_table TBP_MC_LBL_ISU_INISU
* @return int[]
*/
	@LocalName("deleteBatchTbpMcLblIsuInisu")
	public int[] deleteBatchTbpMcLblIsuInisu (final List tbpMcLblIsuInisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLblIsuInisuDEM.deleteBatchTbpMcLblIsuInisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_INISU \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuInisuDVO tbpMcLblIsuInisuDVO = (TbpMcLblIsuInisuDVO)tbpMcLblIsuInisuDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getNmgId());
							ps.setString(psCount++, tbpMcLblIsuInisuDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLblIsuInisuDVOList.size();
							}
					}
		);			
	}

	
}