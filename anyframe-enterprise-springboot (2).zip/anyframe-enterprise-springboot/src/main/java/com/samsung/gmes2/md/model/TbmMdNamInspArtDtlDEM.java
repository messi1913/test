package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdNamInspArtDtlDEM extends AbstractDAO {


/**
* insertTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return int
*/
	@LocalName("insertTbmMdNamInspArtDtl")
	public int insertTbmMdNamInspArtDtl (final TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.insertTbmMdNamInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_NAM_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        INSP_ART_DTL_NM , \n");
			sql.append("        WAP_NAM_GUBUN_CODE , \n");
			sql.append("        COMN_MTHD_CODE , \n");
			sql.append("        COMN_SOL_GUBUN_CODE , \n");
			sql.append("        NAM_INSP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getWapNamGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnMthdCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnSolGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getNamInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdNamInspArtDtl Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdNamInspArtDtl Method")
	public int[][] updateBatchAllTbmMdNamInspArtDtl (final List  tbmMdNamInspArtDtlDVOList) {
		
		ArrayList updatetbmMdNamInspArtDtlDVOList = new ArrayList();
		ArrayList insertttbmMdNamInspArtDtlDVOList = new ArrayList();
		ArrayList deletetbmMdNamInspArtDtlDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdNamInspArtDtlDVOList.size() ; i++) {
		  TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO = (TbmMdNamInspArtDtlDVO) tbmMdNamInspArtDtlDVOList.get(i);
		  
		  if (tbmMdNamInspArtDtlDVO.getSqlAction().equals("C"))
		      insertttbmMdNamInspArtDtlDVOList.add(tbmMdNamInspArtDtlDVO);
		  else if (tbmMdNamInspArtDtlDVO.getSqlAction().equals("U"))
		      updatetbmMdNamInspArtDtlDVOList.add(tbmMdNamInspArtDtlDVO);
		  else if (tbmMdNamInspArtDtlDVO.getSqlAction().equals("D"))
		      deletetbmMdNamInspArtDtlDVOList.add(tbmMdNamInspArtDtlDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdNamInspArtDtlDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdNamInspArtDtl(insertttbmMdNamInspArtDtlDVOList);
          
      if (updatetbmMdNamInspArtDtlDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdNamInspArtDtl(updatetbmMdNamInspArtDtlDVOList);
      
      if (deletetbmMdNamInspArtDtlDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdNamInspArtDtl(deletetbmMdNamInspArtDtlDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return int
*/
	@LocalName("updateTbmMdNamInspArtDtl")
	public int updateTbmMdNamInspArtDtl (final TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.updateTbmMdNamInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_NAM_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        INSP_ART_DTL_NM = ? , \n");
			sql.append("        WAP_NAM_GUBUN_CODE = ? , \n");
			sql.append("        COMN_MTHD_CODE = ? , \n");
			sql.append("        COMN_SOL_GUBUN_CODE = ? , \n");
			sql.append("        NAM_INSP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");
			sql.append("   AND INSP_CLSF_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getWapNamGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnMthdCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnSolGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getNamInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
						}
					}
		);			
	}

/**
* deleteTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return int
*/
	@LocalName("deleteTbmMdNamInspArtDtl")
	public int deleteTbmMdNamInspArtDtl (final TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.deleteTbmMdNamInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_NAM_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND INSP_CLSF_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
						}
					}
		);			
	}

/**
* selectTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return TbmMdNamInspArtDtlDVO 
*/
	@LocalName("selectTbmMdNamInspArtDtl")
	public TbmMdNamInspArtDtlDVO selectTbmMdNamInspArtDtl (final TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.selectTbmMdNamInspArtDtl.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        INSP_ART_DTL_NM , \n");
			sql.append("        WAP_NAM_GUBUN_CODE , \n");
			sql.append("        COMN_MTHD_CODE , \n");
			sql.append("        COMN_SOL_GUBUN_CODE , \n");
			sql.append("        NAM_INSP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_NAM_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND INSP_CLSF_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return (TbmMdNamInspArtDtlDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdNamInspArtDtlDVO returnTbmMdNamInspArtDtlDVO = new TbmMdNamInspArtDtlDVO();
									returnTbmMdNamInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdNamInspArtDtlDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMdNamInspArtDtlDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbmMdNamInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbmMdNamInspArtDtlDVO.setInspArtDtlNm(resultSet.getString("INSP_ART_DTL_NM"));
									returnTbmMdNamInspArtDtlDVO.setWapNamGubunCode(resultSet.getString("WAP_NAM_GUBUN_CODE"));
									returnTbmMdNamInspArtDtlDVO.setComnMthdCode(resultSet.getString("COMN_MTHD_CODE"));
									returnTbmMdNamInspArtDtlDVO.setComnSolGubunCode(resultSet.getString("COMN_SOL_GUBUN_CODE"));
									returnTbmMdNamInspArtDtlDVO.setNamInspClsfCode(resultSet.getString("NAM_INSP_CLSF_CODE"));
									returnTbmMdNamInspArtDtlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdNamInspArtDtlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdNamInspArtDtlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdNamInspArtDtlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdNamInspArtDtlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdNamInspArtDtlDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdNamInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdNamInspArtDtl Method")
	public int mergeTbmMdNamInspArtDtl (final TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO) {
		
		if ( selectTbmMdNamInspArtDtl (tbmMdNamInspArtDtlDVO) == null) {
			return insertTbmMdNamInspArtDtl(tbmMdNamInspArtDtlDVO);
		} else {
			return selectUpdateTbmMdNamInspArtDtl (tbmMdNamInspArtDtlDVO);
		}
	}

	/**
	 * selectUpdateTbmMdNamInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdNamInspArtDtl Method")
	public int selectUpdateTbmMdNamInspArtDtl (final TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO) {
		
		TbmMdNamInspArtDtlDVO tmpTbmMdNamInspArtDtlDVO =  selectTbmMdNamInspArtDtl (tbmMdNamInspArtDtlDVO);
		if ( tbmMdNamInspArtDtlDVO.getGbmCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getGbmCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setGbmCode(tbmMdNamInspArtDtlDVO.getGbmCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getCorpCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getCorpCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setCorpCode(tbmMdNamInspArtDtlDVO.getCorpCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getInspClsfCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getInspClsfCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setInspClsfCode(tbmMdNamInspArtDtlDVO.getInspClsfCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getInspArtDtlCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getInspArtDtlCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setInspArtDtlCode(tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getInspArtDtlNm() != null && !"".equals(tbmMdNamInspArtDtlDVO.getInspArtDtlNm()) ) {
			tmpTbmMdNamInspArtDtlDVO.setInspArtDtlNm(tbmMdNamInspArtDtlDVO.getInspArtDtlNm());
		}		
		if ( tbmMdNamInspArtDtlDVO.getWapNamGubunCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getWapNamGubunCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setWapNamGubunCode(tbmMdNamInspArtDtlDVO.getWapNamGubunCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getComnMthdCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getComnMthdCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setComnMthdCode(tbmMdNamInspArtDtlDVO.getComnMthdCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getComnSolGubunCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getComnSolGubunCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setComnSolGubunCode(tbmMdNamInspArtDtlDVO.getComnSolGubunCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getNamInspClsfCode() != null && !"".equals(tbmMdNamInspArtDtlDVO.getNamInspClsfCode()) ) {
			tmpTbmMdNamInspArtDtlDVO.setNamInspClsfCode(tbmMdNamInspArtDtlDVO.getNamInspClsfCode());
		}		
		if ( tbmMdNamInspArtDtlDVO.getUseYn() != null && !"".equals(tbmMdNamInspArtDtlDVO.getUseYn()) ) {
			tmpTbmMdNamInspArtDtlDVO.setUseYn(tbmMdNamInspArtDtlDVO.getUseYn());
		}		
		if ( tbmMdNamInspArtDtlDVO.getFstRegDt() != null && !"".equals(tbmMdNamInspArtDtlDVO.getFstRegDt()) ) {
			tmpTbmMdNamInspArtDtlDVO.setFstRegDt(tbmMdNamInspArtDtlDVO.getFstRegDt());
		}		
		if ( tbmMdNamInspArtDtlDVO.getFstRegerId() != null && !"".equals(tbmMdNamInspArtDtlDVO.getFstRegerId()) ) {
			tmpTbmMdNamInspArtDtlDVO.setFstRegerId(tbmMdNamInspArtDtlDVO.getFstRegerId());
		}		
		if ( tbmMdNamInspArtDtlDVO.getFnlUpdDt() != null && !"".equals(tbmMdNamInspArtDtlDVO.getFnlUpdDt()) ) {
			tmpTbmMdNamInspArtDtlDVO.setFnlUpdDt(tbmMdNamInspArtDtlDVO.getFnlUpdDt());
		}		
		if ( tbmMdNamInspArtDtlDVO.getFnlUpderId() != null && !"".equals(tbmMdNamInspArtDtlDVO.getFnlUpderId()) ) {
			tmpTbmMdNamInspArtDtlDVO.setFnlUpderId(tbmMdNamInspArtDtlDVO.getFnlUpderId());
		}		
		return updateTbmMdNamInspArtDtl (tmpTbmMdNamInspArtDtlDVO);
	}

/**
* insertBatchTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return int[]
*/
	@LocalName("insertBatchTbmMdNamInspArtDtl")
	public int[] insertBatchTbmMdNamInspArtDtl (final List tbmMdNamInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.insertBatchTbmMdNamInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_NAM_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        INSP_ART_DTL_NM , \n");
			sql.append("        WAP_NAM_GUBUN_CODE , \n");
			sql.append("        COMN_MTHD_CODE , \n");
			sql.append("        COMN_SOL_GUBUN_CODE , \n");
			sql.append("        NAM_INSP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO = (TbmMdNamInspArtDtlDVO)tbmMdNamInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getWapNamGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnMthdCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnSolGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getNamInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdNamInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return int[]
*/
	@LocalName("updateBatchTbmMdNamInspArtDtl")
	public int[] updateBatchTbmMdNamInspArtDtl (final List tbmMdNamInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.updateBatchTbmMdNamInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_NAM_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        INSP_ART_DTL_NM = ? , \n");
			sql.append("        WAP_NAM_GUBUN_CODE = ? , \n");
			sql.append("        COMN_MTHD_CODE = ? , \n");
			sql.append("        COMN_SOL_GUBUN_CODE = ? , \n");
			sql.append("        NAM_INSP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");
			sql.append("   AND INSP_CLSF_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO = (TbmMdNamInspArtDtlDVO)tbmMdNamInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getWapNamGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnMthdCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getComnSolGubunCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getNamInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
						}
							public int getBatchSize() {
									return tbmMdNamInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdNamInspArtDtl Method
* 
* @ref_table TBM_MD_NAM_INSP_ART_DTL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdNamInspArtDtl")
	public int[] deleteBatchTbmMdNamInspArtDtl (final List tbmMdNamInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdNamInspArtDtlDEM.deleteBatchTbmMdNamInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_NAM_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND INSP_CLSF_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdNamInspArtDtlDVO tbmMdNamInspArtDtlDVO = (TbmMdNamInspArtDtlDVO)tbmMdNamInspArtDtlDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdNamInspArtDtlDVO.getInspArtDtlCode());
						}
							public int getBatchSize() {
									return tbmMdNamInspArtDtlDVOList.size();
							}
					}
		);			
	}

	
}