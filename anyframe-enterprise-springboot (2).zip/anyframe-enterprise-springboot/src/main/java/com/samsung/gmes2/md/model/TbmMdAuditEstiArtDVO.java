package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdAuditEstiArtDVO extends AbstractVo {

	@Length(30) 
	private String gbmCode;

	@Length(30) 
	private String procGubunCode;

	@Length(30) 
	private String estiClsfCode;

	@Length(30) 
	private String estiArtCode;

	@Length(500) 
	private String estiArtNm;

	@Length(5) 
	private BigDecimal asgnPoint;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGbmCode() {
		this.gbmCode = super.getValue(0);
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue(0, gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue(1);
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue(1, procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getEstiClsfCode() {
		this.estiClsfCode = super.getValue(2);
		return this.estiClsfCode;
	}

	public void setEstiClsfCode(String estiClsfCode) {
        super.setValue(2, estiClsfCode);
		this.estiClsfCode = estiClsfCode;
	}
	
	public String getEstiArtCode() {
		this.estiArtCode = super.getValue(3);
		return this.estiArtCode;
	}

	public void setEstiArtCode(String estiArtCode) {
        super.setValue(3, estiArtCode);
		this.estiArtCode = estiArtCode;
	}
	
	public String getEstiArtNm() {
		this.estiArtNm = super.getValue(4);
		return this.estiArtNm;
	}

	public void setEstiArtNm(String estiArtNm) {
        super.setValue(4, estiArtNm);
		this.estiArtNm = estiArtNm;
	}
	
	public BigDecimal getAsgnPoint() {
		this.asgnPoint = super.getValue(5);
		return this.asgnPoint;
	}

	public void setAsgnPoint(BigDecimal asgnPoint) {
        super.setValue(5, asgnPoint);
		this.asgnPoint = asgnPoint;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(6);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(6, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(7);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(7, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(8);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(8, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(9);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(9, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(10);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(10, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}