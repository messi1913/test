/**
 * <PRE>
 * System Name : MD
 * Business Name : MDM
 * Class Name : MdManageTbmMdGbmInspArtDtlBiz.java
 * Description : 마스터 테이블 TbmMdGbmInspArtDtl에 대한 CRUD 컴포넌트
 * Modification History
 *          수정일              수정자          수정내용
 *    -----------------------------------------------------
 *    2011.07.21                호건웅           최초 생성    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDVO;
import com.samsung.gmes2.md.model.TbcMdInspArtDVO;
import com.samsung.gmes2.md.model.TbcMdProdDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;


public class MdManageTbcMdGbmInspArtDtlBiz {
	
	/**
	 * 검사 항목 상세 코드 생성을 수행한다
	 * @name_ko 검사 항목 상세 코드 생성 메서드
	 */
	public TbcMdGbmInspArtDtlDVO createNewTbmMdGbmInspArtDtlRow(TbcMdGbmInspArtDtlDVO inputDvo) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 등록 하려는 정보가 참조 무결성을 위반했는지 체크
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		return CrudUtil.create( inputDvo );
	}
	/**
	 * 검사 항목 상세 코드 단건 조회를 수행한다
	 * @name_ko 검사 항목 상세 코드 단건 조회 메서드
	 */
	public TbcMdGbmInspArtDtlDVO getTbcMdGbmInspArtDtlRow( TbcMdGbmInspArtDtlDVO inputDvo ) throws Exception{
		
		return CrudUtil.get( inputDvo );
	}
	
	/**
	 * 검사 항목 상세 코드 수정을 수행한다
	 * @name_ko 검사 항목 상세 코드 수정 메서드
	 */
	public TbcMdGbmInspArtDtlDVO updateTbcMdGbmInspArtDtlRow(TbcMdGbmInspArtDtlDVO inputDvo) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 수정하려는 정보가 참조 무결성을 위반했는지 체크
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		return CrudUtil.update( inputDvo );
	}
	/**
	 * 검사 항목 상세 코드 삭제를 수행한다
	 * @name_ko 검사 항목 상세 코드 삭제 메서드
	 */
	public TbcMdGbmInspArtDtlDVO deleteTbcMdGbmInspArtDtlRow(TbcMdGbmInspArtDtlDVO inputDvo) throws Exception{
		return CrudUtil.delete( inputDvo );
	}
	/**
	 * 검사 항목 상세 코드 다건 조회를 수행한다
	 * @name_ko 검사 항목 상세 코드 다건 조회 메서드
	 */
	public List listTbcMdGbmInspArtDtl(TbcMdGbmInspArtDtlDVO inputDvo) throws Exception{
		

		List resultList = CrudUtil.list0(TbcMdGbmInspArtDtlDVO.class, inputDvo, 0, 0);
		/*--------------------------------------------------
		 * @fd_if 다건 조회 결과가 있으면 조회 결과를 받는 리스트를 리턴
		 * @fd_id 0001
		 --------------------------------------------------*/
		if( resultList.size() > 0 ){
			return resultList;
		}
		// 다건 조회 결과가 없으면 null 값을 리턴
		return null;
	}
	/**
	 * 수정, 생성 시 참조 무결성 위반 여부를 판단한다
	 * @name_ko 참조 무결성 확인 메서드
	 */
	private void checkIntegrityConstraint( TbcMdGbmInspArtDtlDVO inputDvo ) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 GBM_CODE 정보는 테이블의 TBC_MD_COMM_ORG의 COMM_CODE 컬럼에 기 등록되있어야한다
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		TbcMdCommOrgDVO tbcMdCommOrgDVO = new TbcMdCommOrgDVO();
		BaseUtil.populate( inputDvo, tbcMdCommOrgDVO, "gbmCode:commCode" );
		BaseUtil.checkFound( tbcMdCommOrgDVO );
		
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 PROC_OUT_GUBUN_CODE 정보는 테이블의 TBC_MD_COMM_ORG의 COMM_CODE 컬럼에 기 등록되있어야한다
		 * @fd_id 0002
		 --------------------------------------------------*/
		//TODO
		TbcMdCommCodeDVO tbcMdCommCodeDVO = new TbcMdCommCodeDVO();
		BaseUtil.populate( inputDvo, tbcMdCommCodeDVO, "procOutGubunCode:commCode" );
		BaseUtil.checkFound( tbcMdCommCodeDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0002
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 PROD_CODE 정보는 테이블의 TBC_MD_PROD의 PROD_CODE 컬럼에 기 등록되있어야한다
		 * @fd_id 0003
		 --------------------------------------------------*/
		//TODO
		TbcMdProdDVO tbcMdProdDVO = new TbcMdProdDVO();
		BaseUtil.populate( inputDvo, tbcMdProdDVO, "prodCode:prodCode" );
		BaseUtil.checkFound( tbcMdProdDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0003
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 INSP_ART_CODE 정보는 테이블의 TBC_MD_INSP_ART의 INSP_ART_CODE 컬럼에 기 등록되있어야한다
		 * @fd_id 0004
		 --------------------------------------------------*/
		//TODO
		TbcMdInspArtDVO tbcMdInspArtDVO = new TbcMdInspArtDVO();
		BaseUtil.populate( inputDvo, tbcMdInspArtDVO, "inspArtCode:inspArtCode" );
		BaseUtil.checkFound( tbcMdInspArtDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0004
		 --------------------------------------------------*/

		
		
		
		
		
		
	}
}
