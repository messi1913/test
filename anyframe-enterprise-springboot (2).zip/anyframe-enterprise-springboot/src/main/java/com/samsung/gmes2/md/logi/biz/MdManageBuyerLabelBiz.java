package com.samsung.gmes2.md.logi.biz;

public class MdManageBuyerLabelBiz {

	/**
	 * Buyer별라벨 목록 조회
	 */
	public void listBuyerLabel(){}

	/**
	 * Buyer별라벨 목록 저장
	 */
	public void saveBuyerLabel(){}

}
