package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBD_MC_OI_FRM
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbdMcOiFrmDEM extends AbstractDAO {


/**
* insertTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return int
*/
	@LocalName("insertTbdMcOiFrm")
	public int insertTbdMcOiFrm (final TbdMcOiFrmDVO tbdMcOiFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.insertTbdMcOiFrm.001*/  \n");
			sql.append(" TBD_MC_OI_FRM (   \n");
			sql.append("        FRM_NO , \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        FRM_LENG , \n");
			sql.append("        FRM_HEIT \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmHeit());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbdMcOiFrm Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbdMcOiFrm Method")
	public int[][] updateBatchAllTbdMcOiFrm (final List  tbdMcOiFrmDVOList) {
		
		ArrayList updatetbdMcOiFrmDVOList = new ArrayList();
		ArrayList insertttbdMcOiFrmDVOList = new ArrayList();
		ArrayList deletetbdMcOiFrmDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbdMcOiFrmDVOList.size() ; i++) {
		  TbdMcOiFrmDVO tbdMcOiFrmDVO = (TbdMcOiFrmDVO) tbdMcOiFrmDVOList.get(i);
		  
		  if (tbdMcOiFrmDVO.getSqlAction().equals("C"))
		      insertttbdMcOiFrmDVOList.add(tbdMcOiFrmDVO);
		  else if (tbdMcOiFrmDVO.getSqlAction().equals("U"))
		      updatetbdMcOiFrmDVOList.add(tbdMcOiFrmDVO);
		  else if (tbdMcOiFrmDVO.getSqlAction().equals("D"))
		      deletetbdMcOiFrmDVOList.add(tbdMcOiFrmDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbdMcOiFrmDVOList.size() > 0) 
          resultValues[0] = insertBatchTbdMcOiFrm(insertttbdMcOiFrmDVOList);
          
      if (updatetbdMcOiFrmDVOList.size() >0)
          resultValues[1] = updateBatchTbdMcOiFrm(updatetbdMcOiFrmDVOList);
      
      if (deletetbdMcOiFrmDVOList.size() >0)
          resultValues[2] = deleteBatchTbdMcOiFrm(deletetbdMcOiFrmDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return int
*/
	@LocalName("updateTbdMcOiFrm")
	public int updateTbdMcOiFrm (final TbdMcOiFrmDVO tbdMcOiFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.updateTbdMcOiFrm.001*/  \n");
			sql.append(" TBD_MC_OI_FRM \n");
			sql.append(" SET   \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        FRM_LENG = ? , \n");
			sql.append("        FRM_HEIT = ? \n");
			sql.append(" WHERE FRM_NO = ? \n");
			sql.append("   AND REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmHeit());

							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
						}
					}
		);			
	}

/**
* deleteTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return int
*/
	@LocalName("deleteTbdMcOiFrm")
	public int deleteTbdMcOiFrm (final TbdMcOiFrmDVO tbdMcOiFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.deleteTbdMcOiFrm.001*/  \n");
			sql.append(" TBD_MC_OI_FRM \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
						}
					}
		);			
	}

/**
* selectTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return TbdMcOiFrmDVO 
*/
	@LocalName("selectTbdMcOiFrm")
	public TbdMcOiFrmDVO selectTbdMcOiFrm (final TbdMcOiFrmDVO tbdMcOiFrmDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.selectTbdMcOiFrm.001*/  \n");
			sql.append("        FRM_NO , \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        FRM_LENG , \n");
			sql.append("        FRM_HEIT \n");
			sql.append("   FROM TBD_MC_OI_FRM \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return (TbdMcOiFrmDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbdMcOiFrmDVO returnTbdMcOiFrmDVO = new TbdMcOiFrmDVO();
									returnTbdMcOiFrmDVO.setFrmNo(resultSet.getString("FRM_NO"));
									returnTbdMcOiFrmDVO.setRevNo(resultSet.getString("REV_NO"));
									returnTbdMcOiFrmDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbdMcOiFrmDVO.setxValue(resultSet.getBigDecimal("X_VALUE"));
									returnTbdMcOiFrmDVO.setyValue(resultSet.getBigDecimal("Y_VALUE"));
									returnTbdMcOiFrmDVO.setFrmLeng(resultSet.getBigDecimal("FRM_LENG"));
									returnTbdMcOiFrmDVO.setFrmHeit(resultSet.getBigDecimal("FRM_HEIT"));
									return returnTbdMcOiFrmDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbdMcOiFrm Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbdMcOiFrm Method")
	public int mergeTbdMcOiFrm (final TbdMcOiFrmDVO tbdMcOiFrmDVO) {
		
		if ( selectTbdMcOiFrm (tbdMcOiFrmDVO) == null) {
			return insertTbdMcOiFrm(tbdMcOiFrmDVO);
		} else {
			return selectUpdateTbdMcOiFrm (tbdMcOiFrmDVO);
		}
	}

	/**
	 * selectUpdateTbdMcOiFrm Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbdMcOiFrm Method")
	public int selectUpdateTbdMcOiFrm (final TbdMcOiFrmDVO tbdMcOiFrmDVO) {
		
		TbdMcOiFrmDVO tmpTbdMcOiFrmDVO =  selectTbdMcOiFrm (tbdMcOiFrmDVO);
		if ( tbdMcOiFrmDVO.getFrmNo() != null && !"".equals(tbdMcOiFrmDVO.getFrmNo()) ) {
			tmpTbdMcOiFrmDVO.setFrmNo(tbdMcOiFrmDVO.getFrmNo());
		}		
		if ( tbdMcOiFrmDVO.getRevNo() != null && !"".equals(tbdMcOiFrmDVO.getRevNo()) ) {
			tmpTbdMcOiFrmDVO.setRevNo(tbdMcOiFrmDVO.getRevNo());
		}		
		if ( tbdMcOiFrmDVO.getPgmCode() != null && !"".equals(tbdMcOiFrmDVO.getPgmCode()) ) {
			tmpTbdMcOiFrmDVO.setPgmCode(tbdMcOiFrmDVO.getPgmCode());
		}		
		if ( tbdMcOiFrmDVO.getxValue() != null && !"".equals(tbdMcOiFrmDVO.getxValue()) ) {
			tmpTbdMcOiFrmDVO.setxValue(tbdMcOiFrmDVO.getxValue());
		}		
		if ( tbdMcOiFrmDVO.getyValue() != null && !"".equals(tbdMcOiFrmDVO.getyValue()) ) {
			tmpTbdMcOiFrmDVO.setyValue(tbdMcOiFrmDVO.getyValue());
		}		
		if ( tbdMcOiFrmDVO.getFrmLeng() != null && !"".equals(tbdMcOiFrmDVO.getFrmLeng()) ) {
			tmpTbdMcOiFrmDVO.setFrmLeng(tbdMcOiFrmDVO.getFrmLeng());
		}		
		if ( tbdMcOiFrmDVO.getFrmHeit() != null && !"".equals(tbdMcOiFrmDVO.getFrmHeit()) ) {
			tmpTbdMcOiFrmDVO.setFrmHeit(tbdMcOiFrmDVO.getFrmHeit());
		}		
		return updateTbdMcOiFrm (tmpTbdMcOiFrmDVO);
	}

/**
* insertBatchTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return int[]
*/
	@LocalName("insertBatchTbdMcOiFrm")
	public int[] insertBatchTbdMcOiFrm (final List tbdMcOiFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.insertBatchTbdMcOiFrm.001*/  \n");
			sql.append(" TBD_MC_OI_FRM (   \n");
			sql.append("        FRM_NO , \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        FRM_LENG , \n");
			sql.append("        FRM_HEIT \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcOiFrmDVO tbdMcOiFrmDVO = (TbdMcOiFrmDVO)tbdMcOiFrmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmHeit());

						}
							public int getBatchSize() {
									return tbdMcOiFrmDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return int[]
*/
	@LocalName("updateBatchTbdMcOiFrm")
	public int[] updateBatchTbdMcOiFrm (final List tbdMcOiFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.updateBatchTbdMcOiFrm.001*/  \n");
			sql.append(" TBD_MC_OI_FRM \n");
			sql.append(" SET   \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        FRM_LENG = ? , \n");
			sql.append("        FRM_HEIT = ? \n");
			sql.append(" WHERE FRM_NO = ? \n");
			sql.append("   AND REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcOiFrmDVO tbdMcOiFrmDVO = (TbdMcOiFrmDVO)tbdMcOiFrmDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcOiFrmDVO.getFrmHeit());

							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbdMcOiFrmDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbdMcOiFrm Method
* 
* @ref_table TBD_MC_OI_FRM
* @return int[]
*/
	@LocalName("deleteBatchTbdMcOiFrm")
	public int[] deleteBatchTbdMcOiFrm (final List tbdMcOiFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcOiFrmDEM.deleteBatchTbdMcOiFrm.001*/  \n");
			sql.append(" TBD_MC_OI_FRM \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcOiFrmDVO tbdMcOiFrmDVO = (TbdMcOiFrmDVO)tbdMcOiFrmDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbdMcOiFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getRevNo());
							ps.setString(psCount++, tbdMcOiFrmDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbdMcOiFrmDVOList.size();
							}
					}
		);			
	}

	
}