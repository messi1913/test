package com.samsung.gmes2.md.equipment.app;

public class MDU553M01App {

	/**
	 * Block정보 목록 초기설정
	 */
	public void initBlockInfo(){}

	/**
	 * Block정보 목록 조회
	 */
	public void listBlockInfo(){}

	/**
	 * Block정보 목록 엑셀 다운로드
	 */
	public void excelBlockInfo(){}

	/**
	 * Block정보 목록 저장
	 */
	public void saveBlockInfo(){}

	/**
	 * Block정보 목록 등록/수정 초기설정
	 */
	public void editBlockInfo(){}

}
