package com.samsung.gmes2.md.material.app;

public class MDU242M01App {

	/**
	 * 제품별 UNIT ID 목록 초기설정
	 */
	public void initProdUnitId(){}

	/**
	 * 제품별 UNIT ID 목록 조회
	 */
	public void listProdUnitId(){}

	/**
	 * 제품별 UNIT ID 목록 엑셀 다운로드
	 */
	public void excelProdUnitId(){}

	/**
	 * 제품별 UNIT ID 목록 등록/수정 초기설정
	 */
	public void editProdUnitId(){}

	/**
	 * 제품별 UNIT ID 목록 저장
	 */
	public void saveProdUnitId(){}

}
