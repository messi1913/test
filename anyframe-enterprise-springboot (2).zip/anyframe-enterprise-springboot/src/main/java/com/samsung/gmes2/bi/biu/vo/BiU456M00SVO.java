package com.samsung.gmes2.bi.biu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.util.List;
import java.util.ArrayList;

/**
 * 
 * @author Chris
 */
@LocalName("수율현황 조회 SVO")
public class BiU456M00SVO extends AbstractVo {

	@LocalName("조회창 화면") 
	private BiU456M0000DVO biU456M0000DVO;

	@LocalName("상세화면") 
	private BiU456M0001DVO biU456M0001DVO;

	@LocalName("상세화면 리스트") 
	private List<BiU456M0001DVO> biU456M0001DVOList;


	/**
	 * 조회창 화면 Getter Method
	 * 
	 * @return 조회창 화면
	 */
	@LocalName("조회창 화면 Getter Method")
	public BiU456M0000DVO getBiU456M0000DVO() {
		this.biU456M0000DVO = super.getValue(0);
		return this.biU456M0000DVO;
	}

	/**
	 * 조회창 화면 Setter Method
	 * 
	 * @param BiU456M0000DVO 조회창 화면
	 */
	@LocalName("조회창 화면 Setter Method")
	public void setBiU456M0000DVO(BiU456M0000DVO biU456M0000DVO) {
        super.setValue(0, biU456M0000DVO);
		this.biU456M0000DVO = biU456M0000DVO;
	}
	
	/**
	 * 상세화면 Getter Method
	 * 
	 * @return 상세화면
	 */
	@LocalName("상세화면 Getter Method")
	public BiU456M0001DVO getBiU456M0001DVO() {
		this.biU456M0001DVO = super.getValue(1);
		return this.biU456M0001DVO;
	}

	/**
	 * 상세화면 Setter Method
	 * 
	 * @param BiU456M0001DVO 상세화면
	 */
	@LocalName("상세화면 Setter Method")
	public void setBiU456M0001DVO(BiU456M0001DVO biU456M0001DVO) {
        super.setValue(1, biU456M0001DVO);
		this.biU456M0001DVO = biU456M0001DVO;
	}
	
	/**
	 * 상세화면 리스트 Getter Method
	 * 
	 * @return 상세화면 리스트
	 */
	@LocalName("상세화면 리스트 Getter Method")
	public List<BiU456M0001DVO> getBiU456M0001DVOList() {
		this.biU456M0001DVOList = super.getValue(2);
		return this.biU456M0001DVOList;
	}

	/**
	 * 상세화면 리스트 Setter Method
	 * 
	 * @param List 상세화면 리스트
	 */
	@LocalName("상세화면 리스트 Setter Method")
	public void setBiU456M0001DVOList(List<BiU456M0001DVO> biU456M0001DVOList) {
	    super.setValue(2, biU456M0001DVOList);
		this.biU456M0001DVOList = biU456M0001DVOList;
	}
	
}