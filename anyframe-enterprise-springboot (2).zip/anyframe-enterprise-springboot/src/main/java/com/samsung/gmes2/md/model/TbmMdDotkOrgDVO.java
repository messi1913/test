package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author KYJ
 */
public class TbmMdDotkOrgDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String dotkCode;

	@Length(8) @NotNull
	private String operStartYmd;

	@Length(8) 
	private String operFinYmd;

	@Length(500) 
	private String dotkNm;

	@Length(50) 
	private String leaderEmpNo;

	@Length(50) 
	private String sleaderEmpNo;

	@Length(2000) 
	private String dotkDesc;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getDotkCode() {
		this.dotkCode = super.getValue("dotkCode");
		return this.dotkCode;
	}

	public void setDotkCode(String dotkCode) {
        super.setValue("dotkCode", dotkCode);
		this.dotkCode = dotkCode;
	}
	
	public String getOperStartYmd() {
		this.operStartYmd = super.getValue("operStartYmd");
		return this.operStartYmd;
	}

	public void setOperStartYmd(String operStartYmd) {
        super.setValue("operStartYmd", operStartYmd);
		this.operStartYmd = operStartYmd;
	}
	
	public String getOperFinYmd() {
		this.operFinYmd = super.getValue("operFinYmd");
		return this.operFinYmd;
	}

	public void setOperFinYmd(String operFinYmd) {
        super.setValue("operFinYmd", operFinYmd);
		this.operFinYmd = operFinYmd;
	}
	
	public String getDotkNm() {
		this.dotkNm = super.getValue("dotkNm");
		return this.dotkNm;
	}

	public void setDotkNm(String dotkNm) {
        super.setValue("dotkNm", dotkNm);
		this.dotkNm = dotkNm;
	}
	
	public String getLeaderEmpNo() {
		this.leaderEmpNo = super.getValue("leaderEmpNo");
		return this.leaderEmpNo;
	}

	public void setLeaderEmpNo(String leaderEmpNo) {
        super.setValue("leaderEmpNo", leaderEmpNo);
		this.leaderEmpNo = leaderEmpNo;
	}
	
	public String getSleaderEmpNo() {
		this.sleaderEmpNo = super.getValue("sleaderEmpNo");
		return this.sleaderEmpNo;
	}

	public void setSleaderEmpNo(String sleaderEmpNo) {
        super.setValue("sleaderEmpNo", sleaderEmpNo);
		this.sleaderEmpNo = sleaderEmpNo;
	}
	
	public String getDotkDesc() {
		this.dotkDesc = super.getValue("dotkDesc");
		return this.dotkDesc;
	}

	public void setDotkDesc(String dotkDesc) {
        super.setValue("dotkDesc", dotkDesc);
		this.dotkDesc = dotkDesc;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}