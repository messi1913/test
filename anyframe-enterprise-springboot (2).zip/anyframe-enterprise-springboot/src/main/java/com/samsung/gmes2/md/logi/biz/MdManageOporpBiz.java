package com.samsung.gmes2.md.logi.biz;

public class MdManageOporpBiz {

	/**
	 * 출항지 목록 조회
	 */
	public void listOport(){}

	/**
	 * 출항지 목록 저장
	 */
	public void saveOport(){}

}
