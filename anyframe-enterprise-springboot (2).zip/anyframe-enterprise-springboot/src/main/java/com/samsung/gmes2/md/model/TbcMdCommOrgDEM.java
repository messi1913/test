package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_COMM_ORG
* @author hkw
*/
@Stereotype(Stereotype.Dao)
public class TbcMdCommOrgDEM extends AbstractDAO {


/**
* insertTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return int
*/
	@LocalName("insertTbcMdCommOrg")
	public int insertTbcMdCommOrg (final TbcMdCommOrgDVO tbcMdCommOrgDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.insertTbcMdCommOrg.001*/  \n");
			sql.append(" TBC_MD_COMM_ORG (   \n");
			sql.append("        COMM_ORG_CODE , \n");
			sql.append("        HRNK_COMM_ORG_CODE , \n");
			sql.append("        COMM_ORG_TYPE_CODE , \n");
			sql.append("        COMM_ORG_CODE_NM , \n");
			sql.append("        COMM_ORG_CODE_DESC , \n");
			sql.append("        CODE_SORT_PRIOR , \n");
			sql.append("        N1_CODE_ATTR_CONT , \n");
			sql.append("        CIS_MAPP_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        N1_LABEL_WRT_CODE , \n");
			sql.append("        N2_LABEL_WRT_CODE , \n");
			sql.append("        N3_LABEL_WRT_CODE , \n");
			sql.append("        N4_LABEL_WRT_CODE , \n");
			sql.append("        N5_LABEL_WRT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getHrnkCommOrgCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgTypeCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeNm());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeDesc());
							ps.setBigDecimal(psCount++, tbcMdCommOrgDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1CodeAttrCont());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCisMappCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN2LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN3LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN4LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN5LabelWrtCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdCommOrg Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdCommOrg Method")
	public int[][] updateBatchAllTbcMdCommOrg (final List  tbcMdCommOrgDVOList) {
		
		ArrayList updatetbcMdCommOrgDVOList = new ArrayList();
		ArrayList insertttbcMdCommOrgDVOList = new ArrayList();
		ArrayList deletetbcMdCommOrgDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdCommOrgDVOList.size() ; i++) {
		  TbcMdCommOrgDVO tbcMdCommOrgDVO = (TbcMdCommOrgDVO) tbcMdCommOrgDVOList.get(i);
		  
		  if (tbcMdCommOrgDVO.getSqlAction().equals("C"))
		      insertttbcMdCommOrgDVOList.add(tbcMdCommOrgDVO);
		  else if (tbcMdCommOrgDVO.getSqlAction().equals("U"))
		      updatetbcMdCommOrgDVOList.add(tbcMdCommOrgDVO);
		  else if (tbcMdCommOrgDVO.getSqlAction().equals("D"))
		      deletetbcMdCommOrgDVOList.add(tbcMdCommOrgDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdCommOrgDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdCommOrg(insertttbcMdCommOrgDVOList);
          
      if (updatetbcMdCommOrgDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdCommOrg(updatetbcMdCommOrgDVOList);
      
      if (deletetbcMdCommOrgDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdCommOrg(deletetbcMdCommOrgDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return int
*/
	@LocalName("updateTbcMdCommOrg")
	public int updateTbcMdCommOrg (final TbcMdCommOrgDVO tbcMdCommOrgDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.updateTbcMdCommOrg.001*/  \n");
			sql.append(" TBC_MD_COMM_ORG \n");
			sql.append(" SET   \n");
			sql.append("        HRNK_COMM_ORG_CODE = ? , \n");
			sql.append("        COMM_ORG_TYPE_CODE = ? , \n");
			sql.append("        COMM_ORG_CODE_NM = ? , \n");
			sql.append("        COMM_ORG_CODE_DESC = ? , \n");
			sql.append("        CODE_SORT_PRIOR = ? , \n");
			sql.append("        N1_CODE_ATTR_CONT = ? , \n");
			sql.append("        CIS_MAPP_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        N1_LABEL_WRT_CODE = ? , \n");
			sql.append("        N2_LABEL_WRT_CODE = ? , \n");
			sql.append("        N3_LABEL_WRT_CODE = ? , \n");
			sql.append("        N4_LABEL_WRT_CODE = ? , \n");
			sql.append("        N5_LABEL_WRT_CODE = ? \n");
			sql.append(" WHERE COMM_ORG_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommOrgDVO.getHrnkCommOrgCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgTypeCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeNm());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeDesc());
							ps.setBigDecimal(psCount++, tbcMdCommOrgDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1CodeAttrCont());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCisMappCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN2LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN3LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN4LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN5LabelWrtCode());

							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
						}
					}
		);			
	}

/**
* deleteTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return int
*/
	@LocalName("deleteTbcMdCommOrg")
	public int deleteTbcMdCommOrg (final TbcMdCommOrgDVO tbcMdCommOrgDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.deleteTbcMdCommOrg.001*/  \n");
			sql.append(" TBC_MD_COMM_ORG \n");
			sql.append("  WHERE COMM_ORG_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
						}
					}
		);			
	}

/**
* selectTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return TbcMdCommOrgDVO 
*/
	@LocalName("selectTbcMdCommOrg")
	public TbcMdCommOrgDVO selectTbcMdCommOrg (final TbcMdCommOrgDVO tbcMdCommOrgDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.selectTbcMdCommOrg.001*/  \n");
			sql.append("        COMM_ORG_CODE , \n");
			sql.append("        HRNK_COMM_ORG_CODE , \n");
			sql.append("        COMM_ORG_TYPE_CODE , \n");
			sql.append("        COMM_ORG_CODE_NM , \n");
			sql.append("        COMM_ORG_CODE_DESC , \n");
			sql.append("        CODE_SORT_PRIOR , \n");
			sql.append("        N1_CODE_ATTR_CONT , \n");
			sql.append("        CIS_MAPP_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        N1_LABEL_WRT_CODE , \n");
			sql.append("        N2_LABEL_WRT_CODE , \n");
			sql.append("        N3_LABEL_WRT_CODE , \n");
			sql.append("        N4_LABEL_WRT_CODE , \n");
			sql.append("        N5_LABEL_WRT_CODE \n");
			sql.append("   FROM TBC_MD_COMM_ORG \n");
			sql.append("  WHERE COMM_ORG_CODE = ? \n");

		return (TbcMdCommOrgDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdCommOrgDVO returnTbcMdCommOrgDVO = new TbcMdCommOrgDVO();
									returnTbcMdCommOrgDVO.setCommOrgCode(resultSet.getString("COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setHrnkCommOrgCode(resultSet.getString("HRNK_COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgTypeCode(resultSet.getString("COMM_ORG_TYPE_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgCodeNm(resultSet.getString("COMM_ORG_CODE_NM"));
									returnTbcMdCommOrgDVO.setCommOrgCodeDesc(resultSet.getString("COMM_ORG_CODE_DESC"));
									returnTbcMdCommOrgDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommOrgDVO.setN1CodeAttrCont(resultSet.getString("N1_CODE_ATTR_CONT"));
									returnTbcMdCommOrgDVO.setCisMappCode(resultSet.getString("CIS_MAPP_CODE"));
									returnTbcMdCommOrgDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbcMdCommOrgDVO.setN1LabelWrtCode(resultSet.getString("N1_LABEL_WRT_CODE"));
									returnTbcMdCommOrgDVO.setN2LabelWrtCode(resultSet.getString("N2_LABEL_WRT_CODE"));
									returnTbcMdCommOrgDVO.setN3LabelWrtCode(resultSet.getString("N3_LABEL_WRT_CODE"));
									returnTbcMdCommOrgDVO.setN4LabelWrtCode(resultSet.getString("N4_LABEL_WRT_CODE"));
									returnTbcMdCommOrgDVO.setN5LabelWrtCode(resultSet.getString("N5_LABEL_WRT_CODE"));
									return returnTbcMdCommOrgDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdCommOrg Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdCommOrg Method")
	public int mergeTbcMdCommOrg (final TbcMdCommOrgDVO tbcMdCommOrgDVO) {
		
		if ( selectTbcMdCommOrg (tbcMdCommOrgDVO) == null) {
			return insertTbcMdCommOrg(tbcMdCommOrgDVO);
		} else {
			return selectUpdateTbcMdCommOrg (tbcMdCommOrgDVO);
		}
	}

	/**
	 * selectUpdateTbcMdCommOrg Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdCommOrg Method")
	public int selectUpdateTbcMdCommOrg (final TbcMdCommOrgDVO tbcMdCommOrgDVO) {
		
		TbcMdCommOrgDVO tmpTbcMdCommOrgDVO =  selectTbcMdCommOrg (tbcMdCommOrgDVO);
		if ( tbcMdCommOrgDVO.getCommOrgCode() != null && !"".equals(tbcMdCommOrgDVO.getCommOrgCode()) ) {
			tmpTbcMdCommOrgDVO.setCommOrgCode(tbcMdCommOrgDVO.getCommOrgCode());
		}		
		if ( tbcMdCommOrgDVO.getHrnkCommOrgCode() != null && !"".equals(tbcMdCommOrgDVO.getHrnkCommOrgCode()) ) {
			tmpTbcMdCommOrgDVO.setHrnkCommOrgCode(tbcMdCommOrgDVO.getHrnkCommOrgCode());
		}		
		if ( tbcMdCommOrgDVO.getCommOrgTypeCode() != null && !"".equals(tbcMdCommOrgDVO.getCommOrgTypeCode()) ) {
			tmpTbcMdCommOrgDVO.setCommOrgTypeCode(tbcMdCommOrgDVO.getCommOrgTypeCode());
		}		
		if ( tbcMdCommOrgDVO.getCommOrgCodeNm() != null && !"".equals(tbcMdCommOrgDVO.getCommOrgCodeNm()) ) {
			tmpTbcMdCommOrgDVO.setCommOrgCodeNm(tbcMdCommOrgDVO.getCommOrgCodeNm());
		}		
		if ( tbcMdCommOrgDVO.getCommOrgCodeDesc() != null && !"".equals(tbcMdCommOrgDVO.getCommOrgCodeDesc()) ) {
			tmpTbcMdCommOrgDVO.setCommOrgCodeDesc(tbcMdCommOrgDVO.getCommOrgCodeDesc());
		}		
		if ( tbcMdCommOrgDVO.getCodeSortPrior() != null && !"".equals(tbcMdCommOrgDVO.getCodeSortPrior()) ) {
			tmpTbcMdCommOrgDVO.setCodeSortPrior(tbcMdCommOrgDVO.getCodeSortPrior());
		}		
		if ( tbcMdCommOrgDVO.getN1CodeAttrCont() != null && !"".equals(tbcMdCommOrgDVO.getN1CodeAttrCont()) ) {
			tmpTbcMdCommOrgDVO.setN1CodeAttrCont(tbcMdCommOrgDVO.getN1CodeAttrCont());
		}		
		if ( tbcMdCommOrgDVO.getCisMappCode() != null && !"".equals(tbcMdCommOrgDVO.getCisMappCode()) ) {
			tmpTbcMdCommOrgDVO.setCisMappCode(tbcMdCommOrgDVO.getCisMappCode());
		}		
		if ( tbcMdCommOrgDVO.getUseYn() != null && !"".equals(tbcMdCommOrgDVO.getUseYn()) ) {
			tmpTbcMdCommOrgDVO.setUseYn(tbcMdCommOrgDVO.getUseYn());
		}		
		if ( tbcMdCommOrgDVO.getFstRegDt() != null && !"".equals(tbcMdCommOrgDVO.getFstRegDt()) ) {
			tmpTbcMdCommOrgDVO.setFstRegDt(tbcMdCommOrgDVO.getFstRegDt());
		}		
		if ( tbcMdCommOrgDVO.getFstRegerId() != null && !"".equals(tbcMdCommOrgDVO.getFstRegerId()) ) {
			tmpTbcMdCommOrgDVO.setFstRegerId(tbcMdCommOrgDVO.getFstRegerId());
		}		
		if ( tbcMdCommOrgDVO.getFnlUpdDt() != null && !"".equals(tbcMdCommOrgDVO.getFnlUpdDt()) ) {
			tmpTbcMdCommOrgDVO.setFnlUpdDt(tbcMdCommOrgDVO.getFnlUpdDt());
		}		
		if ( tbcMdCommOrgDVO.getFnlUpderId() != null && !"".equals(tbcMdCommOrgDVO.getFnlUpderId()) ) {
			tmpTbcMdCommOrgDVO.setFnlUpderId(tbcMdCommOrgDVO.getFnlUpderId());
		}		
		if ( tbcMdCommOrgDVO.getN1LabelWrtCode() != null && !"".equals(tbcMdCommOrgDVO.getN1LabelWrtCode()) ) {
			tmpTbcMdCommOrgDVO.setN1LabelWrtCode(tbcMdCommOrgDVO.getN1LabelWrtCode());
		}		
		if ( tbcMdCommOrgDVO.getN2LabelWrtCode() != null && !"".equals(tbcMdCommOrgDVO.getN2LabelWrtCode()) ) {
			tmpTbcMdCommOrgDVO.setN2LabelWrtCode(tbcMdCommOrgDVO.getN2LabelWrtCode());
		}		
		if ( tbcMdCommOrgDVO.getN3LabelWrtCode() != null && !"".equals(tbcMdCommOrgDVO.getN3LabelWrtCode()) ) {
			tmpTbcMdCommOrgDVO.setN3LabelWrtCode(tbcMdCommOrgDVO.getN3LabelWrtCode());
		}		
		if ( tbcMdCommOrgDVO.getN4LabelWrtCode() != null && !"".equals(tbcMdCommOrgDVO.getN4LabelWrtCode()) ) {
			tmpTbcMdCommOrgDVO.setN4LabelWrtCode(tbcMdCommOrgDVO.getN4LabelWrtCode());
		}		
		if ( tbcMdCommOrgDVO.getN5LabelWrtCode() != null && !"".equals(tbcMdCommOrgDVO.getN5LabelWrtCode()) ) {
			tmpTbcMdCommOrgDVO.setN5LabelWrtCode(tbcMdCommOrgDVO.getN5LabelWrtCode());
		}		
		return updateTbcMdCommOrg (tmpTbcMdCommOrgDVO);
	}

/**
* insertBatchTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return int[]
*/
	@LocalName("insertBatchTbcMdCommOrg")
	public int[] insertBatchTbcMdCommOrg (final List tbcMdCommOrgDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.insertBatchTbcMdCommOrg.001*/  \n");
			sql.append(" TBC_MD_COMM_ORG (   \n");
			sql.append("        COMM_ORG_CODE , \n");
			sql.append("        HRNK_COMM_ORG_CODE , \n");
			sql.append("        COMM_ORG_TYPE_CODE , \n");
			sql.append("        COMM_ORG_CODE_NM , \n");
			sql.append("        COMM_ORG_CODE_DESC , \n");
			sql.append("        CODE_SORT_PRIOR , \n");
			sql.append("        N1_CODE_ATTR_CONT , \n");
			sql.append("        CIS_MAPP_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        N1_LABEL_WRT_CODE , \n");
			sql.append("        N2_LABEL_WRT_CODE , \n");
			sql.append("        N3_LABEL_WRT_CODE , \n");
			sql.append("        N4_LABEL_WRT_CODE , \n");
			sql.append("        N5_LABEL_WRT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCommOrgDVO tbcMdCommOrgDVO = (TbcMdCommOrgDVO)tbcMdCommOrgDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getHrnkCommOrgCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgTypeCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeNm());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeDesc());
							ps.setBigDecimal(psCount++, tbcMdCommOrgDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1CodeAttrCont());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCisMappCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN2LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN3LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN4LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN5LabelWrtCode());

						}
							public int getBatchSize() {
									return tbcMdCommOrgDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return int[]
*/
	@LocalName("updateBatchTbcMdCommOrg")
	public int[] updateBatchTbcMdCommOrg (final List tbcMdCommOrgDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.updateBatchTbcMdCommOrg.001*/  \n");
			sql.append(" TBC_MD_COMM_ORG \n");
			sql.append(" SET   \n");
			sql.append("        HRNK_COMM_ORG_CODE = ? , \n");
			sql.append("        COMM_ORG_TYPE_CODE = ? , \n");
			sql.append("        COMM_ORG_CODE_NM = ? , \n");
			sql.append("        COMM_ORG_CODE_DESC = ? , \n");
			sql.append("        CODE_SORT_PRIOR = ? , \n");
			sql.append("        N1_CODE_ATTR_CONT = ? , \n");
			sql.append("        CIS_MAPP_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        N1_LABEL_WRT_CODE = ? , \n");
			sql.append("        N2_LABEL_WRT_CODE = ? , \n");
			sql.append("        N3_LABEL_WRT_CODE = ? , \n");
			sql.append("        N4_LABEL_WRT_CODE = ? , \n");
			sql.append("        N5_LABEL_WRT_CODE = ? \n");
			sql.append(" WHERE COMM_ORG_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCommOrgDVO tbcMdCommOrgDVO = (TbcMdCommOrgDVO)tbcMdCommOrgDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommOrgDVO.getHrnkCommOrgCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgTypeCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeNm());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCodeDesc());
							ps.setBigDecimal(psCount++, tbcMdCommOrgDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1CodeAttrCont());
							ps.setString(psCount++, tbcMdCommOrgDVO.getCisMappCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommOrgDVO.getFnlUpderId());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN1LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN2LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN3LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN4LabelWrtCode());
							ps.setString(psCount++, tbcMdCommOrgDVO.getN5LabelWrtCode());

							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
						}
							public int getBatchSize() {
									return tbcMdCommOrgDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdCommOrg Method
* 
* @ref_table TBC_MD_COMM_ORG
* @return int[]
*/
	@LocalName("deleteBatchTbcMdCommOrg")
	public int[] deleteBatchTbcMdCommOrg (final List tbcMdCommOrgDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdCommOrgDEM.deleteBatchTbcMdCommOrg.001*/  \n");
			sql.append(" TBC_MD_COMM_ORG \n");
			sql.append("  WHERE COMM_ORG_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCommOrgDVO tbcMdCommOrgDVO = (TbcMdCommOrgDVO)tbcMdCommOrgDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdCommOrgDVO.getCommOrgCode());
						}
							public int getBatchSize() {
									return tbcMdCommOrgDVOList.size();
							}
					}
		);			
	}

	
}