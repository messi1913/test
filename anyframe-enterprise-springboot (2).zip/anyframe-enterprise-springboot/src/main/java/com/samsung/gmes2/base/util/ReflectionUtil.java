package com.samsung.gmes2.base.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;
import javax.validation.constraints.NotNull;

import org.aspectj.lang.Signature;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import com.anyframe.core.vo.AbstractVo;

public class ReflectionUtil
{
	// private static boolean isTable(String name) throws Exception {
	// // TODO boolean isTable(String name)
	// return false;
	// }
	// private static boolean isColumn(String tableName, String columnName)
	// throws Exception {
	// // TODO boolean isColumn(String tableName, String columnName)
	// return false;
	// }
	// private static boolean isColumnValue(String tableName, String columnName,
	// Object value) throws Exception {
	// // TODO boolean isColumn(String tableName, String columnName)
	// return false;
	// }
	public static Object getFieldValue( AbstractVo vo, String name ) throws Exception
	{
		return vo.getProxy( ).getValue( name );
	}
	
	public static Object getAnyFieldValue( AbstractVo vo, String name )
	{
		if (vo.getProxy( ).getVoMeta( ).getNamedMap( ).containsKey( name ))
			return vo.getProxy( ).getValue( name );
		return null;
	}

	public static void setFieldValue( AbstractVo vo, String name, Object value ) throws Exception
	{
		vo.getProxy( ).setValue( name, value );
	}

	private static DataSource			dataSource;

	private static JdbcTemplate	jdbcTemplate;

	private static DataSource getDataSource( )
	{
		if ( dataSource == null )
			dataSource = (DataSource) BeanUtil.get( "businessDataSource" );
		return dataSource;
	}

	private static JdbcTemplate getJdbcTemplate( )
	{
		if ( jdbcTemplate == null )
			jdbcTemplate = new JdbcTemplate( getDataSource( ) );
		return jdbcTemplate;
	}

	private static String						QUERY_PLIST	= new StringBuffer( "SELECT USER_CONS_COLUMNS.COLUMN_NAME FROM USER_CONSTRAINTS, USER_CONS_COLUMNS" )
																																									.append( " WHERE USER_CONSTRAINTS.TABLE_NAME = :tableName" )
																																									.append( " AND USER_CONSTRAINTS.CONSTRAINT_NAME = USER_CONS_COLUMNS.CONSTRAINT_NAME" )
																																									.append( " AND USER_CONSTRAINTS.CONSTRAINT_TYPE = 'P'" )
																																									.toString( );

	private static Map<Class<?>, List<String>>	pkMap		= new ConcurrentHashMap<Class<?>, List<String>>( );

	public static String[ ] getPKFieldNameArray( Object obj )
	{
		return BaseUtil.toStringArray( getPKFieldNameList( obj ) );
	}

	public static List<String> getPKFieldNameList( Object obj )
	{
		if ( obj == null )
			return null;
		Class<?> clazz = obj instanceof Class<?> ? (Class<?>) obj : obj.getClass( );
		if ( pkMap.containsKey( clazz ) )
			return pkMap.get( clazz );
		String tableName = StringUtils.replace( toUnderscoreCase( clazz.getSimpleName( ) ), "_D_V_O", "" );
		synchronized (MonitorUtil.get( tableName ))
		{
			try
			{
				if ( pkMap.containsKey( clazz ) )
					return pkMap.get( clazz );
				List<String> pk = new ArrayList<String>( );
				try
				{
					Map<String, Object> paramMap = new HashMap<String, Object>( );
					paramMap.put( "tableName", tableName );
					List<Map<String, Object>> list = getJdbcTemplate( ).queryForList( QUERY_PLIST, paramMap );
					for ( Map<String, Object> column : list )
						pk.add( toCamelCase( (String) column.get( "COLUMN_NAME" ) ) );
					return pk;
				}
				finally
				{
					pkMap.put( clazz, pk );
				}
			}
			finally
			{
				MonitorUtil.expire( tableName );
			}
		}
	}

	private static Map<Class<?>, List<String>>	notEmptyMap	= new ConcurrentHashMap<Class<?>, List<String>>( );

	public static String[ ] getNotEmptyFieldNameArray( Object obj )
	{
		return BaseUtil.toStringArray( getNotEmptyFieldNameList( obj ) );
	}

	public static List<String> getNotEmptyFieldNameList( Object obj )
	{
		if ( obj == null )
			return null;
		Class<?> clazz = obj instanceof Class<?> ? (Class<?>) obj : obj.getClass( );
		if ( notEmptyMap.containsKey( clazz ) )
			return notEmptyMap.get( clazz );
		String className = clazz.getSimpleName( );
		synchronized (MonitorUtil.get( className ))
		{
			try
			{
				if ( notEmptyMap.containsKey( clazz ) )
					return notEmptyMap.get( clazz );
				List<String> notNull = new ArrayList<String>( );
				try
				{
					for ( Field field : clazz.getDeclaredFields( ) )
					{
						if ( field.getAnnotation( NotNull.class ) == null )
							continue;
						notNull.add( field.getName( ) );
					}
					return notNull;
				}
				finally
				{
					notEmptyMap.put( clazz, notNull );
				}
			}
			finally
			{
				MonitorUtil.expire( className );
			}
		}
	}

	public static String capitalize( String name )
	{
		return StringUtils.capitalize( name );
	}

	public static String toCamelCase( String name )
	{
		if ( BaseUtil.isEmpty( name ) )
			return name;
		String[ ] names = StringUtils.tokenizeToStringArray( name.toLowerCase( ), "_" );
		StringBuffer buf = new StringBuffer( );
		int i = 0;
		for ( String n : names )
			buf.append( i++ == 0 ? n : capitalize( n ) );
		return buf.toString( );
	}

	public static String toUnderscoreCase( String name )
	{
		if ( BaseUtil.isEmpty( name ) )
			return name;
		StringBuffer buf = new StringBuffer( );
		char preC = ' ';
		for ( char c : name.toCharArray( ) )
		{
			if ( c == ' ' )
				continue;
			if ( preC != '_' && preC != ' ' && c < 91 && ( c > '9' || preC > '9' ) )
				buf.append( "_" );
			buf.append( c );
			preC = c;
		}
		name = buf.toString( ).toUpperCase( );
		return name;
	}

	public static Method getMethod( Signature signature )
	{
		try
		{
			Method getMethod = signature.getClass( ).getMethod( "getMethod" );
			if ( getMethod == null )
				return null;
			if ( !getMethod.isAccessible( ) )
				getMethod.setAccessible( true );
			return (Method) getMethod.invoke( signature );
		}
		catch ( Exception e )
		{
		}
		return null;
	}

	private static Map<String, Class<?>>	classMap	= new ConcurrentHashMap<String, Class<?>>( );

	public static Class<?> getClass( String name ) throws ClassNotFoundException
	{
		if ( classMap.containsKey( name ) )
			return classMap.get( name );
		synchronized (MonitorUtil.get( name ))
		{
			try
			{
				if ( classMap.containsKey( name ) )
					return classMap.get( name );
				try
				{
					Class<?> clazz = ClassUtils.forName( name, ClassUtils.getDefaultClassLoader( ) );
					classMap.put( name, clazz );
					return clazz;
				}
				catch ( ClassNotFoundException e )
				{
					throw e;
				}
			}
			finally
			{
				MonitorUtil.expire( name );
			}
		}
	}
}
