package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PJT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdPjtDEM extends AbstractDAO {


/**
* insertTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return int
*/
	@LocalName("insertTbcMdPjt")
	public int insertTbcMdPjt (final TbcMdPjtDVO tbcMdPjtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdPjtDEM.insertTbcMdPjt.001*/  \n");
			sql.append(" TBC_MD_PJT (   \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PJT_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
							ps.setString(psCount++, tbcMdPjtDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdPjtDVO.getPjtNm());
							ps.setString(psCount++, tbcMdPjtDVO.getUseYn());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdPjt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdPjt Method")
	public int[][] updateBatchAllTbcMdPjt (final List  tbcMdPjtDVOList) {
		
		ArrayList updatetbcMdPjtDVOList = new ArrayList();
		ArrayList insertttbcMdPjtDVOList = new ArrayList();
		ArrayList deletetbcMdPjtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdPjtDVOList.size() ; i++) {
		  TbcMdPjtDVO tbcMdPjtDVO = (TbcMdPjtDVO) tbcMdPjtDVOList.get(i);
		  
		  if (tbcMdPjtDVO.getSqlAction().equals("C"))
		      insertttbcMdPjtDVOList.add(tbcMdPjtDVO);
		  else if (tbcMdPjtDVO.getSqlAction().equals("U"))
		      updatetbcMdPjtDVOList.add(tbcMdPjtDVO);
		  else if (tbcMdPjtDVO.getSqlAction().equals("D"))
		      deletetbcMdPjtDVOList.add(tbcMdPjtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdPjtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdPjt(insertttbcMdPjtDVOList);
          
      if (updatetbcMdPjtDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdPjt(updatetbcMdPjtDVOList);
      
      if (deletetbcMdPjtDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdPjt(deletetbcMdPjtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return int
*/
	@LocalName("updateTbcMdPjt")
	public int updateTbcMdPjt (final TbcMdPjtDVO tbcMdPjtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdPjtDEM.updateTbcMdPjt.001*/  \n");
			sql.append(" TBC_MD_PJT \n");
			sql.append(" SET   \n");
			sql.append("        PROD_GRP_CODE = ? , \n");
			sql.append("        PJT_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PJT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdPjtDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdPjtDVO.getPjtNm());
							ps.setString(psCount++, tbcMdPjtDVO.getUseYn());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
						}
					}
		);			
	}

/**
* deleteTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return int
*/
	@LocalName("deleteTbcMdPjt")
	public int deleteTbcMdPjt (final TbcMdPjtDVO tbcMdPjtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdPjtDEM.deleteTbcMdPjt.001*/  \n");
			sql.append(" TBC_MD_PJT \n");
			sql.append("  WHERE PJT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
						}
					}
		);			
	}

/**
* selectTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return TbcMdPjtDVO 
*/
	@LocalName("selectTbcMdPjt")
	public TbcMdPjtDVO selectTbcMdPjt (final TbcMdPjtDVO tbcMdPjtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdPjtDEM.selectTbcMdPjt.001*/  \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PJT_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PJT \n");
			sql.append("  WHERE PJT_CODE = ? \n");

		return (TbcMdPjtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdPjtDVO returnTbcMdPjtDVO = new TbcMdPjtDVO();
									returnTbcMdPjtDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbcMdPjtDVO.setProdGrpCode(resultSet.getString("PROD_GRP_CODE"));
									returnTbcMdPjtDVO.setPjtNm(resultSet.getString("PJT_NM"));
									returnTbcMdPjtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdPjtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdPjtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdPjtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdPjtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdPjtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdPjt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdPjt Method")
	public int mergeTbcMdPjt (final TbcMdPjtDVO tbcMdPjtDVO) {
		
		if ( selectTbcMdPjt (tbcMdPjtDVO) == null) {
			return insertTbcMdPjt(tbcMdPjtDVO);
		} else {
			return selectUpdateTbcMdPjt (tbcMdPjtDVO);
		}
	}

	/**
	 * selectUpdateTbcMdPjt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdPjt Method")
	public int selectUpdateTbcMdPjt (final TbcMdPjtDVO tbcMdPjtDVO) {
		
		TbcMdPjtDVO tmpTbcMdPjtDVO =  selectTbcMdPjt (tbcMdPjtDVO);
		if ( tbcMdPjtDVO.getPjtCode() != null && !"".equals(tbcMdPjtDVO.getPjtCode()) ) {
			tmpTbcMdPjtDVO.setPjtCode(tbcMdPjtDVO.getPjtCode());
		}		
		if ( tbcMdPjtDVO.getProdGrpCode() != null && !"".equals(tbcMdPjtDVO.getProdGrpCode()) ) {
			tmpTbcMdPjtDVO.setProdGrpCode(tbcMdPjtDVO.getProdGrpCode());
		}		
		if ( tbcMdPjtDVO.getPjtNm() != null && !"".equals(tbcMdPjtDVO.getPjtNm()) ) {
			tmpTbcMdPjtDVO.setPjtNm(tbcMdPjtDVO.getPjtNm());
		}		
		if ( tbcMdPjtDVO.getUseYn() != null && !"".equals(tbcMdPjtDVO.getUseYn()) ) {
			tmpTbcMdPjtDVO.setUseYn(tbcMdPjtDVO.getUseYn());
		}		
		if ( tbcMdPjtDVO.getFstRegDt() != null && !"".equals(tbcMdPjtDVO.getFstRegDt()) ) {
			tmpTbcMdPjtDVO.setFstRegDt(tbcMdPjtDVO.getFstRegDt());
		}		
		if ( tbcMdPjtDVO.getFstRegerId() != null && !"".equals(tbcMdPjtDVO.getFstRegerId()) ) {
			tmpTbcMdPjtDVO.setFstRegerId(tbcMdPjtDVO.getFstRegerId());
		}		
		if ( tbcMdPjtDVO.getFnlUpdDt() != null && !"".equals(tbcMdPjtDVO.getFnlUpdDt()) ) {
			tmpTbcMdPjtDVO.setFnlUpdDt(tbcMdPjtDVO.getFnlUpdDt());
		}		
		if ( tbcMdPjtDVO.getFnlUpderId() != null && !"".equals(tbcMdPjtDVO.getFnlUpderId()) ) {
			tmpTbcMdPjtDVO.setFnlUpderId(tbcMdPjtDVO.getFnlUpderId());
		}		
		return updateTbcMdPjt (tmpTbcMdPjtDVO);
	}

/**
* insertBatchTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return int[]
*/
	@LocalName("insertBatchTbcMdPjt")
	public int[] insertBatchTbcMdPjt (final List tbcMdPjtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdPjtDEM.insertBatchTbcMdPjt.001*/  \n");
			sql.append(" TBC_MD_PJT (   \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PJT_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdPjtDVO tbcMdPjtDVO = (TbcMdPjtDVO)tbcMdPjtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
							ps.setString(psCount++, tbcMdPjtDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdPjtDVO.getPjtNm());
							ps.setString(psCount++, tbcMdPjtDVO.getUseYn());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdPjtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return int[]
*/
	@LocalName("updateBatchTbcMdPjt")
	public int[] updateBatchTbcMdPjt (final List tbcMdPjtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdPjtDEM.updateBatchTbcMdPjt.001*/  \n");
			sql.append(" TBC_MD_PJT \n");
			sql.append(" SET   \n");
			sql.append("        PROD_GRP_CODE = ? , \n");
			sql.append("        PJT_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PJT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdPjtDVO tbcMdPjtDVO = (TbcMdPjtDVO)tbcMdPjtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdPjtDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdPjtDVO.getPjtNm());
							ps.setString(psCount++, tbcMdPjtDVO.getUseYn());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPjtDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
						}
							public int getBatchSize() {
									return tbcMdPjtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdPjt Method
* 
* @ref_table TBC_MD_PJT
* @return int[]
*/
	@LocalName("deleteBatchTbcMdPjt")
	public int[] deleteBatchTbcMdPjt (final List tbcMdPjtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdPjtDEM.deleteBatchTbcMdPjt.001*/  \n");
			sql.append(" TBC_MD_PJT \n");
			sql.append("  WHERE PJT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdPjtDVO tbcMdPjtDVO = (TbcMdPjtDVO)tbcMdPjtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdPjtDVO.getPjtCode());
						}
							public int getBatchSize() {
									return tbcMdPjtDVOList.size();
							}
					}
		);			
	}

	
}