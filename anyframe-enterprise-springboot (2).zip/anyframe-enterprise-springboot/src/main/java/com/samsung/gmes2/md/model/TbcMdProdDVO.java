package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
public class TbcMdProdDVO extends AbstractDVO {

	@Length(30) 
	private String prodCode;

	@Length(30) 
	private String prodAbbrCode;

	@Length(500) 
	private String prodNm;

	@Length(500) 
	private String clsTypeNm;

	@Length(1) 
	private String ttCalcYn;

	@Length(1) 
	private String pbaDeftSumrYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getProdCode() {
		this.prodCode = super.getValue("prodCode");
		return this.prodCode;
	}

	public void setProdCode(String prodCode) {
        super.setValue("prodCode", prodCode);
		this.prodCode = prodCode;
	}
	
	public String getProdAbbrCode() {
		this.prodAbbrCode = super.getValue("prodAbbrCode");
		return this.prodAbbrCode;
	}

	public void setProdAbbrCode(String prodAbbrCode) {
        super.setValue("prodAbbrCode", prodAbbrCode);
		this.prodAbbrCode = prodAbbrCode;
	}
	
	public String getProdNm() {
		this.prodNm = super.getValue("prodNm");
		return this.prodNm;
	}

	public void setProdNm(String prodNm) {
        super.setValue("prodNm", prodNm);
		this.prodNm = prodNm;
	}
	
	public String getClsTypeNm() {
		this.clsTypeNm = super.getValue("clsTypeNm");
		return this.clsTypeNm;
	}

	public void setClsTypeNm(String clsTypeNm) {
        super.setValue("clsTypeNm", clsTypeNm);
		this.clsTypeNm = clsTypeNm;
	}
	
	public String getTtCalcYn() {
		this.ttCalcYn = super.getValue("ttCalcYn");
		return this.ttCalcYn;
	}

	public void setTtCalcYn(String ttCalcYn) {
        super.setValue("ttCalcYn", ttCalcYn);
		this.ttCalcYn = ttCalcYn;
	}
	
	public String getPbaDeftSumrYn() {
		this.pbaDeftSumrYn = super.getValue("pbaDeftSumrYn");
		return this.pbaDeftSumrYn;
	}

	public void setPbaDeftSumrYn(String pbaDeftSumrYn) {
        super.setValue("pbaDeftSumrYn", pbaDeftSumrYn);
		this.pbaDeftSumrYn = pbaDeftSumrYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}