package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_CKD_MATR
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelCkdMatrDEM extends AbstractDAO {


/**
* insertTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return int
*/
	@LocalName("insertTbmMdModelCkdMatr")
	public int insertTbmMdModelCkdMatr (final TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.insertTbmMdModelCkdMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_CKD_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelCkdMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelCkdMatr Method")
	public int[][] updateBatchAllTbmMdModelCkdMatr (final List  tbmMdModelCkdMatrDVOList) {
		
		ArrayList updatetbmMdModelCkdMatrDVOList = new ArrayList();
		ArrayList insertttbmMdModelCkdMatrDVOList = new ArrayList();
		ArrayList deletetbmMdModelCkdMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelCkdMatrDVOList.size() ; i++) {
		  TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO = (TbmMdModelCkdMatrDVO) tbmMdModelCkdMatrDVOList.get(i);
		  
		  if (tbmMdModelCkdMatrDVO.getSqlAction().equals("C"))
		      insertttbmMdModelCkdMatrDVOList.add(tbmMdModelCkdMatrDVO);
		  else if (tbmMdModelCkdMatrDVO.getSqlAction().equals("U"))
		      updatetbmMdModelCkdMatrDVOList.add(tbmMdModelCkdMatrDVO);
		  else if (tbmMdModelCkdMatrDVO.getSqlAction().equals("D"))
		      deletetbmMdModelCkdMatrDVOList.add(tbmMdModelCkdMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelCkdMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelCkdMatr(insertttbmMdModelCkdMatrDVOList);
          
      if (updatetbmMdModelCkdMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelCkdMatr(updatetbmMdModelCkdMatrDVOList);
      
      if (deletetbmMdModelCkdMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelCkdMatr(deletetbmMdModelCkdMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return int
*/
	@LocalName("updateTbmMdModelCkdMatr")
	public int updateTbmMdModelCkdMatr (final TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.updateTbmMdModelCkdMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_CKD_MATR \n");
			sql.append(" SET   \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* deleteTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return int
*/
	@LocalName("deleteTbmMdModelCkdMatr")
	public int deleteTbmMdModelCkdMatr (final TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.deleteTbmMdModelCkdMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_CKD_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* selectTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return TbmMdModelCkdMatrDVO 
*/
	@LocalName("selectTbmMdModelCkdMatr")
	public TbmMdModelCkdMatrDVO selectTbmMdModelCkdMatr (final TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.selectTbmMdModelCkdMatr.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_CKD_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return (TbmMdModelCkdMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelCkdMatrDVO returnTbmMdModelCkdMatrDVO = new TbmMdModelCkdMatrDVO();
									returnTbmMdModelCkdMatrDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdModelCkdMatrDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelCkdMatrDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdModelCkdMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdModelCkdMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelCkdMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelCkdMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelCkdMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelCkdMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelCkdMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelCkdMatr Method")
	public int mergeTbmMdModelCkdMatr (final TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO) {
		
		if ( selectTbmMdModelCkdMatr (tbmMdModelCkdMatrDVO) == null) {
			return insertTbmMdModelCkdMatr(tbmMdModelCkdMatrDVO);
		} else {
			return selectUpdateTbmMdModelCkdMatr (tbmMdModelCkdMatrDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelCkdMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelCkdMatr Method")
	public int selectUpdateTbmMdModelCkdMatr (final TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO) {
		
		TbmMdModelCkdMatrDVO tmpTbmMdModelCkdMatrDVO =  selectTbmMdModelCkdMatr (tbmMdModelCkdMatrDVO);
		if ( tbmMdModelCkdMatrDVO.getPlantCode() != null && !"".equals(tbmMdModelCkdMatrDVO.getPlantCode()) ) {
			tmpTbmMdModelCkdMatrDVO.setPlantCode(tbmMdModelCkdMatrDVO.getPlantCode());
		}		
		if ( tbmMdModelCkdMatrDVO.getModelCode() != null && !"".equals(tbmMdModelCkdMatrDVO.getModelCode()) ) {
			tmpTbmMdModelCkdMatrDVO.setModelCode(tbmMdModelCkdMatrDVO.getModelCode());
		}		
		if ( tbmMdModelCkdMatrDVO.getMatrCode() != null && !"".equals(tbmMdModelCkdMatrDVO.getMatrCode()) ) {
			tmpTbmMdModelCkdMatrDVO.setMatrCode(tbmMdModelCkdMatrDVO.getMatrCode());
		}		
		if ( tbmMdModelCkdMatrDVO.getUseYn() != null && !"".equals(tbmMdModelCkdMatrDVO.getUseYn()) ) {
			tmpTbmMdModelCkdMatrDVO.setUseYn(tbmMdModelCkdMatrDVO.getUseYn());
		}		
		if ( tbmMdModelCkdMatrDVO.getFstRegDt() != null && !"".equals(tbmMdModelCkdMatrDVO.getFstRegDt()) ) {
			tmpTbmMdModelCkdMatrDVO.setFstRegDt(tbmMdModelCkdMatrDVO.getFstRegDt());
		}		
		if ( tbmMdModelCkdMatrDVO.getFstRegerId() != null && !"".equals(tbmMdModelCkdMatrDVO.getFstRegerId()) ) {
			tmpTbmMdModelCkdMatrDVO.setFstRegerId(tbmMdModelCkdMatrDVO.getFstRegerId());
		}		
		if ( tbmMdModelCkdMatrDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelCkdMatrDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelCkdMatrDVO.setFnlUpdDt(tbmMdModelCkdMatrDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelCkdMatrDVO.getFnlUpderId() != null && !"".equals(tbmMdModelCkdMatrDVO.getFnlUpderId()) ) {
			tmpTbmMdModelCkdMatrDVO.setFnlUpderId(tbmMdModelCkdMatrDVO.getFnlUpderId());
		}		
		return updateTbmMdModelCkdMatr (tmpTbmMdModelCkdMatrDVO);
	}

/**
* insertBatchTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelCkdMatr")
	public int[] insertBatchTbmMdModelCkdMatr (final List tbmMdModelCkdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.insertBatchTbmMdModelCkdMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_CKD_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO = (TbmMdModelCkdMatrDVO)tbmMdModelCkdMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelCkdMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelCkdMatr")
	public int[] updateBatchTbmMdModelCkdMatr (final List tbmMdModelCkdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.updateBatchTbmMdModelCkdMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_CKD_MATR \n");
			sql.append(" SET   \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO = (TbmMdModelCkdMatrDVO)tbmMdModelCkdMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdModelCkdMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelCkdMatr Method
* 
* @ref_table TBM_MD_MODEL_CKD_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelCkdMatr")
	public int[] deleteBatchTbmMdModelCkdMatr (final List tbmMdModelCkdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelCkdMatrDEM.deleteBatchTbmMdModelCkdMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_CKD_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelCkdMatrDVO tbmMdModelCkdMatrDVO = (TbmMdModelCkdMatrDVO)tbmMdModelCkdMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelCkdMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdModelCkdMatrDVOList.size();
							}
					}
		);			
	}

	
}