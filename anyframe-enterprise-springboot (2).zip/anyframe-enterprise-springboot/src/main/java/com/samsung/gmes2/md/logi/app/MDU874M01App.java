package com.samsung.gmes2.md.logi.app;

public class MDU874M01App {

	/**
	 * Feedback입고제한정보 목록 초기설정
	 */
	public void initFbGrCtrnt(){}

	/**
	 * Feedback입고제한정보 목록 조회
	 */
	public void listFbGrCtrnt(){}

	/**
	 * Feedback입고제한정보 목록 엑셀 다운로드
	 */
	public void excelFbGrCtrnt(){}

	/**
	 * Feedback입고제한정보 목록 저장
	 */
	public void saveFbGrCtrnt(){}

}
