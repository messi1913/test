package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_CELL_TYPE
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbcMdCellTypeDEM extends AbstractDAO {


/**
* insertTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return int
*/
	@LocalName("insertTbcMdCellType")
	public int insertTbcMdCellType (final TbcMdCellTypeDVO tbcMdCellTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.insertTbcMdCellType.001*/  \n");
			sql.append(" TBC_MD_CELL_TYPE (   \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        CELL_TYPE_NM , \n");
			sql.append("        FINZE_TT_APLY_YN , \n");
			sql.append("        LINE_TT_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeNm());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFinzeTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getLineTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdCellType Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdCellType Method")
	public int[][] updateBatchAllTbcMdCellType (final List  tbcMdCellTypeDVOList) {
		
		ArrayList updatetbcMdCellTypeDVOList = new ArrayList();
		ArrayList insertttbcMdCellTypeDVOList = new ArrayList();
		ArrayList deletetbcMdCellTypeDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdCellTypeDVOList.size() ; i++) {
		  TbcMdCellTypeDVO tbcMdCellTypeDVO = (TbcMdCellTypeDVO) tbcMdCellTypeDVOList.get(i);
		  
		  if (tbcMdCellTypeDVO.getSqlAction().equals("C"))
		      insertttbcMdCellTypeDVOList.add(tbcMdCellTypeDVO);
		  else if (tbcMdCellTypeDVO.getSqlAction().equals("U"))
		      updatetbcMdCellTypeDVOList.add(tbcMdCellTypeDVO);
		  else if (tbcMdCellTypeDVO.getSqlAction().equals("D"))
		      deletetbcMdCellTypeDVOList.add(tbcMdCellTypeDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdCellTypeDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdCellType(insertttbcMdCellTypeDVOList);
          
      if (updatetbcMdCellTypeDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdCellType(updatetbcMdCellTypeDVOList);
      
      if (deletetbcMdCellTypeDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdCellType(deletetbcMdCellTypeDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return int
*/
	@LocalName("updateTbcMdCellType")
	public int updateTbcMdCellType (final TbcMdCellTypeDVO tbcMdCellTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.updateTbcMdCellType.001*/  \n");
			sql.append(" TBC_MD_CELL_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        CELL_TYPE_NM = ? , \n");
			sql.append("        FINZE_TT_APLY_YN = ? , \n");
			sql.append("        LINE_TT_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE CELL_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeNm());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFinzeTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getLineTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
						}
					}
		);			
	}

/**
* deleteTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return int
*/
	@LocalName("deleteTbcMdCellType")
	public int deleteTbcMdCellType (final TbcMdCellTypeDVO tbcMdCellTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.deleteTbcMdCellType.001*/  \n");
			sql.append(" TBC_MD_CELL_TYPE \n");
			sql.append("  WHERE CELL_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
						}
					}
		);			
	}

/**
* selectTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return TbcMdCellTypeDVO 
*/
	@LocalName("selectTbcMdCellType")
	public TbcMdCellTypeDVO selectTbcMdCellType (final TbcMdCellTypeDVO tbcMdCellTypeDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.selectTbcMdCellType.001*/  \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        CELL_TYPE_NM , \n");
			sql.append("        FINZE_TT_APLY_YN , \n");
			sql.append("        LINE_TT_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_CELL_TYPE \n");
			sql.append("  WHERE CELL_TYPE_CODE = ? \n");

		return (TbcMdCellTypeDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdCellTypeDVO returnTbcMdCellTypeDVO = new TbcMdCellTypeDVO();
									returnTbcMdCellTypeDVO.setCellTypeCode(resultSet.getString("CELL_TYPE_CODE"));
									returnTbcMdCellTypeDVO.setCellTypeNm(resultSet.getString("CELL_TYPE_NM"));
									returnTbcMdCellTypeDVO.setFinzeTtAplyYn(resultSet.getString("FINZE_TT_APLY_YN"));
									returnTbcMdCellTypeDVO.setLineTtAplyYn(resultSet.getString("LINE_TT_APLY_YN"));
									returnTbcMdCellTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCellTypeDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCellTypeDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCellTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCellTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCellTypeDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdCellType Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdCellType Method")
	public int mergeTbcMdCellType (final TbcMdCellTypeDVO tbcMdCellTypeDVO) {
		
		if ( selectTbcMdCellType (tbcMdCellTypeDVO) == null) {
			return insertTbcMdCellType(tbcMdCellTypeDVO);
		} else {
			return selectUpdateTbcMdCellType (tbcMdCellTypeDVO);
		}
	}

	/**
	 * selectUpdateTbcMdCellType Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdCellType Method")
	public int selectUpdateTbcMdCellType (final TbcMdCellTypeDVO tbcMdCellTypeDVO) {
		
		TbcMdCellTypeDVO tmpTbcMdCellTypeDVO =  selectTbcMdCellType (tbcMdCellTypeDVO);
		if ( tbcMdCellTypeDVO.getCellTypeCode() != null && !"".equals(tbcMdCellTypeDVO.getCellTypeCode()) ) {
			tmpTbcMdCellTypeDVO.setCellTypeCode(tbcMdCellTypeDVO.getCellTypeCode());
		}		
		if ( tbcMdCellTypeDVO.getCellTypeNm() != null && !"".equals(tbcMdCellTypeDVO.getCellTypeNm()) ) {
			tmpTbcMdCellTypeDVO.setCellTypeNm(tbcMdCellTypeDVO.getCellTypeNm());
		}		
		if ( tbcMdCellTypeDVO.getFinzeTtAplyYn() != null && !"".equals(tbcMdCellTypeDVO.getFinzeTtAplyYn()) ) {
			tmpTbcMdCellTypeDVO.setFinzeTtAplyYn(tbcMdCellTypeDVO.getFinzeTtAplyYn());
		}		
		if ( tbcMdCellTypeDVO.getLineTtAplyYn() != null && !"".equals(tbcMdCellTypeDVO.getLineTtAplyYn()) ) {
			tmpTbcMdCellTypeDVO.setLineTtAplyYn(tbcMdCellTypeDVO.getLineTtAplyYn());
		}		
		if ( tbcMdCellTypeDVO.getUseYn() != null && !"".equals(tbcMdCellTypeDVO.getUseYn()) ) {
			tmpTbcMdCellTypeDVO.setUseYn(tbcMdCellTypeDVO.getUseYn());
		}		
		if ( tbcMdCellTypeDVO.getFstRegDt() != null && !"".equals(tbcMdCellTypeDVO.getFstRegDt()) ) {
			tmpTbcMdCellTypeDVO.setFstRegDt(tbcMdCellTypeDVO.getFstRegDt());
		}		
		if ( tbcMdCellTypeDVO.getFstRegerId() != null && !"".equals(tbcMdCellTypeDVO.getFstRegerId()) ) {
			tmpTbcMdCellTypeDVO.setFstRegerId(tbcMdCellTypeDVO.getFstRegerId());
		}		
		if ( tbcMdCellTypeDVO.getFnlUpdDt() != null && !"".equals(tbcMdCellTypeDVO.getFnlUpdDt()) ) {
			tmpTbcMdCellTypeDVO.setFnlUpdDt(tbcMdCellTypeDVO.getFnlUpdDt());
		}		
		if ( tbcMdCellTypeDVO.getFnlUpderId() != null && !"".equals(tbcMdCellTypeDVO.getFnlUpderId()) ) {
			tmpTbcMdCellTypeDVO.setFnlUpderId(tbcMdCellTypeDVO.getFnlUpderId());
		}		
		return updateTbcMdCellType (tmpTbcMdCellTypeDVO);
	}

/**
* insertBatchTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return int[]
*/
	@LocalName("insertBatchTbcMdCellType")
	public int[] insertBatchTbcMdCellType (final List tbcMdCellTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.insertBatchTbcMdCellType.001*/  \n");
			sql.append(" TBC_MD_CELL_TYPE (   \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        CELL_TYPE_NM , \n");
			sql.append("        FINZE_TT_APLY_YN , \n");
			sql.append("        LINE_TT_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCellTypeDVO tbcMdCellTypeDVO = (TbcMdCellTypeDVO)tbcMdCellTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeNm());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFinzeTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getLineTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdCellTypeDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return int[]
*/
	@LocalName("updateBatchTbcMdCellType")
	public int[] updateBatchTbcMdCellType (final List tbcMdCellTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.updateBatchTbcMdCellType.001*/  \n");
			sql.append(" TBC_MD_CELL_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        CELL_TYPE_NM = ? , \n");
			sql.append("        FINZE_TT_APLY_YN = ? , \n");
			sql.append("        LINE_TT_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE CELL_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCellTypeDVO tbcMdCellTypeDVO = (TbcMdCellTypeDVO)tbcMdCellTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeNm());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFinzeTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getLineTtAplyYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCellTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
						}
							public int getBatchSize() {
									return tbcMdCellTypeDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdCellType Method
* 
* @ref_table TBC_MD_CELL_TYPE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdCellType")
	public int[] deleteBatchTbcMdCellType (final List tbcMdCellTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdCellTypeDEM.deleteBatchTbcMdCellType.001*/  \n");
			sql.append(" TBC_MD_CELL_TYPE \n");
			sql.append("  WHERE CELL_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCellTypeDVO tbcMdCellTypeDVO = (TbcMdCellTypeDVO)tbcMdCellTypeDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdCellTypeDVO.getCellTypeCode());
						}
							public int getBatchSize() {
									return tbcMdCellTypeDVOList.size();
							}
					}
		);			
	}

	
}