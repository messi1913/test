package com.samsung.gmes2.exception;

@SuppressWarnings("serial")
public class Gmes2BugException extends Gmes2Exception {
	public static final String CODE_BUG = "SM-E-_BUG";
	public Gmes2BugException() {
		super();
	}
	public Gmes2BugException(String message) {
		super(message);
	}
	public Gmes2BugException(Throwable cause) {
		super(cause);
	}
	public Gmes2BugException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getCode() {
		return CODE_BUG;
	}
}
