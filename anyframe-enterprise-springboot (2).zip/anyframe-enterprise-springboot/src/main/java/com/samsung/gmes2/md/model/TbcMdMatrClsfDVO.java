package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdMatrClsfDVO extends AbstractVo {

	@Length(30) 
	private String manmCode;

	@Length(1000) 
	private String manmDesc;

	@Length(30) 
	private String lageClsfCode;

	@Length(500) 
	private String lageClsfNm;

	@Length(30) 
	private String midClsfCode;

	@Length(500) 
	private String midClsfNm;

	@Length(30) 
	private String smallClsfCode;

	@Length(500) 
	private String smallClsfNm;

	@Length(30) 
	private String macatCode;

	@Length(500) 
	private String macatNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getManmCode() {
		this.manmCode = super.getValue(0);
		return this.manmCode;
	}

	public void setManmCode(String manmCode) {
        super.setValue(0, manmCode);
		this.manmCode = manmCode;
	}
	
	public String getManmDesc() {
		this.manmDesc = super.getValue(1);
		return this.manmDesc;
	}

	public void setManmDesc(String manmDesc) {
        super.setValue(1, manmDesc);
		this.manmDesc = manmDesc;
	}
	
	public String getLageClsfCode() {
		this.lageClsfCode = super.getValue(2);
		return this.lageClsfCode;
	}

	public void setLageClsfCode(String lageClsfCode) {
        super.setValue(2, lageClsfCode);
		this.lageClsfCode = lageClsfCode;
	}
	
	public String getLageClsfNm() {
		this.lageClsfNm = super.getValue(3);
		return this.lageClsfNm;
	}

	public void setLageClsfNm(String lageClsfNm) {
        super.setValue(3, lageClsfNm);
		this.lageClsfNm = lageClsfNm;
	}
	
	public String getMidClsfCode() {
		this.midClsfCode = super.getValue(4);
		return this.midClsfCode;
	}

	public void setMidClsfCode(String midClsfCode) {
        super.setValue(4, midClsfCode);
		this.midClsfCode = midClsfCode;
	}
	
	public String getMidClsfNm() {
		this.midClsfNm = super.getValue(5);
		return this.midClsfNm;
	}

	public void setMidClsfNm(String midClsfNm) {
        super.setValue(5, midClsfNm);
		this.midClsfNm = midClsfNm;
	}
	
	public String getSmallClsfCode() {
		this.smallClsfCode = super.getValue(6);
		return this.smallClsfCode;
	}

	public void setSmallClsfCode(String smallClsfCode) {
        super.setValue(6, smallClsfCode);
		this.smallClsfCode = smallClsfCode;
	}
	
	public String getSmallClsfNm() {
		this.smallClsfNm = super.getValue(7);
		return this.smallClsfNm;
	}

	public void setSmallClsfNm(String smallClsfNm) {
        super.setValue(7, smallClsfNm);
		this.smallClsfNm = smallClsfNm;
	}
	
	public String getMacatCode() {
		this.macatCode = super.getValue(8);
		return this.macatCode;
	}

	public void setMacatCode(String macatCode) {
        super.setValue(8, macatCode);
		this.macatCode = macatCode;
	}
	
	public String getMacatNm() {
		this.macatNm = super.getValue(9);
		return this.macatNm;
	}

	public void setMacatNm(String macatNm) {
        super.setValue(9, macatNm);
		this.macatNm = macatNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(10);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(10, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(11);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(11, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(12);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(12, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(13);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(13, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(14);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(14, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}