package com.samsung.gmes2.md.loss.app;

public class MDU431M01App {

	/**
	 * 책임분류코드 목록 초기설정
	 */
	public void initDutyClsfCode(){}

	/**
	 * 책임분류코드 목록 조회
	 */
	public void listDutyClsfCode(){}

	/**
	 * 책임분류코드 목록 엑셀 다운로드
	 */
	public void excelDutyClsfCode(){}

	/**
	 * 책임분류코드 목록 저장
	 */
	public void saveDutyClsfCode(){}

}
