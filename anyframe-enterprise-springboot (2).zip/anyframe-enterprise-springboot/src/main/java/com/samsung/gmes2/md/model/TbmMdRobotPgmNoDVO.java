package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdRobotPgmNoDVO extends AbstractVo {

	@Length(30) 
	private String fctCode;

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String lineCode;

	@Length(20) 
	private String modelCode;

	@Length(30) 
	private String matrCode;

	@Length(50) 
	private String pgmNo;

	@Length(1) 
	private String macLabelPrtYn;

	@Length(1) 
	private String buyerOutpYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue(0);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(0, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(1);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(1, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(2);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(2, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(3);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(3, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getMatrCode() {
		this.matrCode = super.getValue(4);
		return this.matrCode;
	}

	public void setMatrCode(String matrCode) {
        super.setValue(4, matrCode);
		this.matrCode = matrCode;
	}
	
	public String getPgmNo() {
		this.pgmNo = super.getValue(5);
		return this.pgmNo;
	}

	public void setPgmNo(String pgmNo) {
        super.setValue(5, pgmNo);
		this.pgmNo = pgmNo;
	}
	
	public String getMacLabelPrtYn() {
		this.macLabelPrtYn = super.getValue(6);
		return this.macLabelPrtYn;
	}

	public void setMacLabelPrtYn(String macLabelPrtYn) {
        super.setValue(6, macLabelPrtYn);
		this.macLabelPrtYn = macLabelPrtYn;
	}
	
	public String getBuyerOutpYn() {
		this.buyerOutpYn = super.getValue(7);
		return this.buyerOutpYn;
	}

	public void setBuyerOutpYn(String buyerOutpYn) {
        super.setValue(7, buyerOutpYn);
		this.buyerOutpYn = buyerOutpYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(8);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(8, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(9);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(9, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(10);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(10, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(11);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(11, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(12);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(12, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}