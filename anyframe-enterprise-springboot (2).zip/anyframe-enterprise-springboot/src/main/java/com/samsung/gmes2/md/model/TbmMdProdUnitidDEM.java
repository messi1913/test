package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PROD_UNITID
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdProdUnitidDEM extends AbstractDAO {


/**
* insertTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return int
*/
	@LocalName("insertTbmMdProdUnitid")
	public int insertTbmMdProdUnitid (final TbmMdProdUnitidDVO tbmMdProdUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.insertTbmMdProdUnitid.001*/  \n");
			sql.append(" TBM_MD_PROD_UNITID (   \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        UNITID , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdProdUnitid Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdProdUnitid Method")
	public int[][] updateBatchAllTbmMdProdUnitid (final List  tbmMdProdUnitidDVOList) {
		
		ArrayList updatetbmMdProdUnitidDVOList = new ArrayList();
		ArrayList insertttbmMdProdUnitidDVOList = new ArrayList();
		ArrayList deletetbmMdProdUnitidDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdProdUnitidDVOList.size() ; i++) {
		  TbmMdProdUnitidDVO tbmMdProdUnitidDVO = (TbmMdProdUnitidDVO) tbmMdProdUnitidDVOList.get(i);
		  
		  if (tbmMdProdUnitidDVO.getSqlAction().equals("C"))
		      insertttbmMdProdUnitidDVOList.add(tbmMdProdUnitidDVO);
		  else if (tbmMdProdUnitidDVO.getSqlAction().equals("U"))
		      updatetbmMdProdUnitidDVOList.add(tbmMdProdUnitidDVO);
		  else if (tbmMdProdUnitidDVO.getSqlAction().equals("D"))
		      deletetbmMdProdUnitidDVOList.add(tbmMdProdUnitidDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdProdUnitidDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdProdUnitid(insertttbmMdProdUnitidDVOList);
          
      if (updatetbmMdProdUnitidDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdProdUnitid(updatetbmMdProdUnitidDVOList);
      
      if (deletetbmMdProdUnitidDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdProdUnitid(deletetbmMdProdUnitidDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return int
*/
	@LocalName("updateTbmMdProdUnitid")
	public int updateTbmMdProdUnitid (final TbmMdProdUnitidDVO tbmMdProdUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.updateTbmMdProdUnitid.001*/  \n");
			sql.append(" TBM_MD_PROD_UNITID \n");
			sql.append(" SET   \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_ABBR_CODE = ? \n");
			sql.append("   AND UNITID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdProdUnitidDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
						}
					}
		);			
	}

/**
* deleteTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return int
*/
	@LocalName("deleteTbmMdProdUnitid")
	public int deleteTbmMdProdUnitid (final TbmMdProdUnitidDVO tbmMdProdUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.deleteTbmMdProdUnitid.001*/  \n");
			sql.append(" TBM_MD_PROD_UNITID \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");
			sql.append("    AND UNITID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
						}
					}
		);			
	}

/**
* selectTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return TbmMdProdUnitidDVO 
*/
	@LocalName("selectTbmMdProdUnitid")
	public TbmMdProdUnitidDVO selectTbmMdProdUnitid (final TbmMdProdUnitidDVO tbmMdProdUnitidDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.selectTbmMdProdUnitid.001*/  \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        UNITID , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PROD_UNITID \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");
			sql.append("    AND UNITID = ? \n");

		return (TbmMdProdUnitidDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdProdUnitidDVO returnTbmMdProdUnitidDVO = new TbmMdProdUnitidDVO();
									returnTbmMdProdUnitidDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbmMdProdUnitidDVO.setUnitid(resultSet.getString("UNITID"));
									returnTbmMdProdUnitidDVO.setFprfAplyYn(resultSet.getString("FPRF_APLY_YN"));
									returnTbmMdProdUnitidDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProdUnitidDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProdUnitidDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProdUnitidDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProdUnitidDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdProdUnitidDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdProdUnitid Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdProdUnitid Method")
	public int mergeTbmMdProdUnitid (final TbmMdProdUnitidDVO tbmMdProdUnitidDVO) {
		
		if ( selectTbmMdProdUnitid (tbmMdProdUnitidDVO) == null) {
			return insertTbmMdProdUnitid(tbmMdProdUnitidDVO);
		} else {
			return selectUpdateTbmMdProdUnitid (tbmMdProdUnitidDVO);
		}
	}

	/**
	 * selectUpdateTbmMdProdUnitid Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdProdUnitid Method")
	public int selectUpdateTbmMdProdUnitid (final TbmMdProdUnitidDVO tbmMdProdUnitidDVO) {
		
		TbmMdProdUnitidDVO tmpTbmMdProdUnitidDVO =  selectTbmMdProdUnitid (tbmMdProdUnitidDVO);
		if ( tbmMdProdUnitidDVO.getProdAbbrCode() != null && !"".equals(tbmMdProdUnitidDVO.getProdAbbrCode()) ) {
			tmpTbmMdProdUnitidDVO.setProdAbbrCode(tbmMdProdUnitidDVO.getProdAbbrCode());
		}		
		if ( tbmMdProdUnitidDVO.getUnitid() != null && !"".equals(tbmMdProdUnitidDVO.getUnitid()) ) {
			tmpTbmMdProdUnitidDVO.setUnitid(tbmMdProdUnitidDVO.getUnitid());
		}		
		if ( tbmMdProdUnitidDVO.getFprfAplyYn() != null && !"".equals(tbmMdProdUnitidDVO.getFprfAplyYn()) ) {
			tmpTbmMdProdUnitidDVO.setFprfAplyYn(tbmMdProdUnitidDVO.getFprfAplyYn());
		}		
		if ( tbmMdProdUnitidDVO.getUseYn() != null && !"".equals(tbmMdProdUnitidDVO.getUseYn()) ) {
			tmpTbmMdProdUnitidDVO.setUseYn(tbmMdProdUnitidDVO.getUseYn());
		}		
		if ( tbmMdProdUnitidDVO.getFstRegDt() != null && !"".equals(tbmMdProdUnitidDVO.getFstRegDt()) ) {
			tmpTbmMdProdUnitidDVO.setFstRegDt(tbmMdProdUnitidDVO.getFstRegDt());
		}		
		if ( tbmMdProdUnitidDVO.getFstRegerId() != null && !"".equals(tbmMdProdUnitidDVO.getFstRegerId()) ) {
			tmpTbmMdProdUnitidDVO.setFstRegerId(tbmMdProdUnitidDVO.getFstRegerId());
		}		
		if ( tbmMdProdUnitidDVO.getFnlUpdDt() != null && !"".equals(tbmMdProdUnitidDVO.getFnlUpdDt()) ) {
			tmpTbmMdProdUnitidDVO.setFnlUpdDt(tbmMdProdUnitidDVO.getFnlUpdDt());
		}		
		if ( tbmMdProdUnitidDVO.getFnlUpderId() != null && !"".equals(tbmMdProdUnitidDVO.getFnlUpderId()) ) {
			tmpTbmMdProdUnitidDVO.setFnlUpderId(tbmMdProdUnitidDVO.getFnlUpderId());
		}		
		return updateTbmMdProdUnitid (tmpTbmMdProdUnitidDVO);
	}

/**
* insertBatchTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return int[]
*/
	@LocalName("insertBatchTbmMdProdUnitid")
	public int[] insertBatchTbmMdProdUnitid (final List tbmMdProdUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.insertBatchTbmMdProdUnitid.001*/  \n");
			sql.append(" TBM_MD_PROD_UNITID (   \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        UNITID , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProdUnitidDVO tbmMdProdUnitidDVO = (TbmMdProdUnitidDVO)tbmMdProdUnitidDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdProdUnitidDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return int[]
*/
	@LocalName("updateBatchTbmMdProdUnitid")
	public int[] updateBatchTbmMdProdUnitid (final List tbmMdProdUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.updateBatchTbmMdProdUnitid.001*/  \n");
			sql.append(" TBM_MD_PROD_UNITID \n");
			sql.append(" SET   \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_ABBR_CODE = ? \n");
			sql.append("   AND UNITID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProdUnitidDVO tbmMdProdUnitidDVO = (TbmMdProdUnitidDVO)tbmMdProdUnitidDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdProdUnitidDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
						}
							public int getBatchSize() {
									return tbmMdProdUnitidDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdProdUnitid Method
* 
* @ref_table TBM_MD_PROD_UNITID
* @return int[]
*/
	@LocalName("deleteBatchTbmMdProdUnitid")
	public int[] deleteBatchTbmMdProdUnitid (final List tbmMdProdUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdProdUnitidDEM.deleteBatchTbmMdProdUnitid.001*/  \n");
			sql.append(" TBM_MD_PROD_UNITID \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");
			sql.append("    AND UNITID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProdUnitidDVO tbmMdProdUnitidDVO = (TbmMdProdUnitidDVO)tbmMdProdUnitidDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdProdUnitidDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdProdUnitidDVO.getUnitid());
						}
							public int getBatchSize() {
									return tbmMdProdUnitidDVOList.size();
							}
					}
		);			
	}

	
}