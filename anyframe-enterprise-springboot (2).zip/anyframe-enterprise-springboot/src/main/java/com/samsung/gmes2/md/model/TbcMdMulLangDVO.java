package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdMulLangDVO extends AbstractVo {

	@Length(50) 
	private String tabId;

	@Length(30) 
	private String n1KeyValue;

	@Length(30) 
	private String n2KeyValue;

	@Length(30) 
	private String n3KeyValue;

	@Length(30) 
	private String n4KeyValue;

	@Length(30) 
	private String n5KeyValue;

	@Length(3) 
	private String langCode;

	@Length(500) 
	private String codeNm;

	@Length(2000) 
	private String codeDesc;

	@Length(50) 
	private String n1CulmId;

	@Length(2000) 
	private String n1CulmCont;

	@Length(50) 
	private String n2CulmId;

	@Length(2000) 
	private String n2CulmCont;

	@Length(50) 
	private String n3CulmId;

	@Length(2000) 
	private String n3CulmCont;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getTabId() {
		this.tabId = super.getValue(0);
		return this.tabId;
	}

	public void setTabId(String tabId) {
        super.setValue(0, tabId);
		this.tabId = tabId;
	}
	
	public String getN1KeyValue() {
		this.n1KeyValue = super.getValue(1);
		return this.n1KeyValue;
	}

	public void setN1KeyValue(String n1KeyValue) {
        super.setValue(1, n1KeyValue);
		this.n1KeyValue = n1KeyValue;
	}
	
	public String getN2KeyValue() {
		this.n2KeyValue = super.getValue(2);
		return this.n2KeyValue;
	}

	public void setN2KeyValue(String n2KeyValue) {
        super.setValue(2, n2KeyValue);
		this.n2KeyValue = n2KeyValue;
	}
	
	public String getN3KeyValue() {
		this.n3KeyValue = super.getValue(3);
		return this.n3KeyValue;
	}

	public void setN3KeyValue(String n3KeyValue) {
        super.setValue(3, n3KeyValue);
		this.n3KeyValue = n3KeyValue;
	}
	
	public String getN4KeyValue() {
		this.n4KeyValue = super.getValue(4);
		return this.n4KeyValue;
	}

	public void setN4KeyValue(String n4KeyValue) {
        super.setValue(4, n4KeyValue);
		this.n4KeyValue = n4KeyValue;
	}
	
	public String getN5KeyValue() {
		this.n5KeyValue = super.getValue(5);
		return this.n5KeyValue;
	}

	public void setN5KeyValue(String n5KeyValue) {
        super.setValue(5, n5KeyValue);
		this.n5KeyValue = n5KeyValue;
	}
	
	public String getLangCode() {
		this.langCode = super.getValue(6);
		return this.langCode;
	}

	public void setLangCode(String langCode) {
        super.setValue(6, langCode);
		this.langCode = langCode;
	}
	
	public String getCodeNm() {
		this.codeNm = super.getValue(7);
		return this.codeNm;
	}

	public void setCodeNm(String codeNm) {
        super.setValue(7, codeNm);
		this.codeNm = codeNm;
	}
	
	public String getCodeDesc() {
		this.codeDesc = super.getValue(8);
		return this.codeDesc;
	}

	public void setCodeDesc(String codeDesc) {
        super.setValue(8, codeDesc);
		this.codeDesc = codeDesc;
	}
	
	public String getN1CulmId() {
		this.n1CulmId = super.getValue(9);
		return this.n1CulmId;
	}

	public void setN1CulmId(String n1CulmId) {
        super.setValue(9, n1CulmId);
		this.n1CulmId = n1CulmId;
	}
	
	public String getN1CulmCont() {
		this.n1CulmCont = super.getValue(10);
		return this.n1CulmCont;
	}

	public void setN1CulmCont(String n1CulmCont) {
        super.setValue(10, n1CulmCont);
		this.n1CulmCont = n1CulmCont;
	}
	
	public String getN2CulmId() {
		this.n2CulmId = super.getValue(11);
		return this.n2CulmId;
	}

	public void setN2CulmId(String n2CulmId) {
        super.setValue(11, n2CulmId);
		this.n2CulmId = n2CulmId;
	}
	
	public String getN2CulmCont() {
		this.n2CulmCont = super.getValue(12);
		return this.n2CulmCont;
	}

	public void setN2CulmCont(String n2CulmCont) {
        super.setValue(12, n2CulmCont);
		this.n2CulmCont = n2CulmCont;
	}
	
	public String getN3CulmId() {
		this.n3CulmId = super.getValue(13);
		return this.n3CulmId;
	}

	public void setN3CulmId(String n3CulmId) {
        super.setValue(13, n3CulmId);
		this.n3CulmId = n3CulmId;
	}
	
	public String getN3CulmCont() {
		this.n3CulmCont = super.getValue(14);
		return this.n3CulmCont;
	}

	public void setN3CulmCont(String n3CulmCont) {
        super.setValue(14, n3CulmCont);
		this.n3CulmCont = n3CulmCont;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(15);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(15, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(16);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(16, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(17);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(17, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(18);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(18, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(19);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(19, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}