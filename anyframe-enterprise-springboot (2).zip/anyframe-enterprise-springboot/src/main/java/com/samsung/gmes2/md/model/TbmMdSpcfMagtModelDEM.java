package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdSpcfMagtModelDEM extends AbstractDAO {


/**
* insertTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return int
*/
	@LocalName("insertTbmMdSpcfMagtModel")
	public int insertTbmMdSpcfMagtModel (final TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.insertTbmMdSpcfMagtModel.001*/  \n");
			sql.append(" TBM_MD_SPCF_MAGT_MODEL (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPCF_MAGT_TYPE_CODE , \n");
			sql.append("        SPCF_MAGT_MODEL_YN , \n");
			sql.append("        SPCF_MAGT_MODEL_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdSpcfMagtModel Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdSpcfMagtModel Method")
	public int[][] updateBatchAllTbmMdSpcfMagtModel (final List  tbmMdSpcfMagtModelDVOList) {
		
		ArrayList updatetbmMdSpcfMagtModelDVOList = new ArrayList();
		ArrayList insertttbmMdSpcfMagtModelDVOList = new ArrayList();
		ArrayList deletetbmMdSpcfMagtModelDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdSpcfMagtModelDVOList.size() ; i++) {
		  TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO = (TbmMdSpcfMagtModelDVO) tbmMdSpcfMagtModelDVOList.get(i);
		  
		  if (tbmMdSpcfMagtModelDVO.getSqlAction().equals("C"))
		      insertttbmMdSpcfMagtModelDVOList.add(tbmMdSpcfMagtModelDVO);
		  else if (tbmMdSpcfMagtModelDVO.getSqlAction().equals("U"))
		      updatetbmMdSpcfMagtModelDVOList.add(tbmMdSpcfMagtModelDVO);
		  else if (tbmMdSpcfMagtModelDVO.getSqlAction().equals("D"))
		      deletetbmMdSpcfMagtModelDVOList.add(tbmMdSpcfMagtModelDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdSpcfMagtModelDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdSpcfMagtModel(insertttbmMdSpcfMagtModelDVOList);
          
      if (updatetbmMdSpcfMagtModelDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdSpcfMagtModel(updatetbmMdSpcfMagtModelDVOList);
      
      if (deletetbmMdSpcfMagtModelDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdSpcfMagtModel(deletetbmMdSpcfMagtModelDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return int
*/
	@LocalName("updateTbmMdSpcfMagtModel")
	public int updateTbmMdSpcfMagtModel (final TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.updateTbmMdSpcfMagtModel.001*/  \n");
			sql.append(" TBM_MD_SPCF_MAGT_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        SPCF_MAGT_MODEL_YN = ? , \n");
			sql.append("        SPCF_MAGT_MODEL_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND SPCF_MAGT_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
						}
					}
		);			
	}

/**
* deleteTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return int
*/
	@LocalName("deleteTbmMdSpcfMagtModel")
	public int deleteTbmMdSpcfMagtModel (final TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.deleteTbmMdSpcfMagtModel.001*/  \n");
			sql.append(" TBM_MD_SPCF_MAGT_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND SPCF_MAGT_TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
						}
					}
		);			
	}

/**
* selectTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return TbmMdSpcfMagtModelDVO 
*/
	@LocalName("selectTbmMdSpcfMagtModel")
	public TbmMdSpcfMagtModelDVO selectTbmMdSpcfMagtModel (final TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.selectTbmMdSpcfMagtModel.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPCF_MAGT_TYPE_CODE , \n");
			sql.append("        SPCF_MAGT_MODEL_YN , \n");
			sql.append("        SPCF_MAGT_MODEL_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_SPCF_MAGT_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND SPCF_MAGT_TYPE_CODE = ? \n");

		return (TbmMdSpcfMagtModelDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdSpcfMagtModelDVO returnTbmMdSpcfMagtModelDVO = new TbmMdSpcfMagtModelDVO();
									returnTbmMdSpcfMagtModelDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdSpcfMagtModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdSpcfMagtModelDVO.setSpcfMagtTypeCode(resultSet.getString("SPCF_MAGT_TYPE_CODE"));
									returnTbmMdSpcfMagtModelDVO.setSpcfMagtModelYn(resultSet.getString("SPCF_MAGT_MODEL_YN"));
									returnTbmMdSpcfMagtModelDVO.setSpcfMagtModelDesc(resultSet.getString("SPCF_MAGT_MODEL_DESC"));
									returnTbmMdSpcfMagtModelDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdSpcfMagtModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdSpcfMagtModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdSpcfMagtModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdSpcfMagtModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdSpcfMagtModelDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdSpcfMagtModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdSpcfMagtModel Method")
	public int mergeTbmMdSpcfMagtModel (final TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO) {
		
		if ( selectTbmMdSpcfMagtModel (tbmMdSpcfMagtModelDVO) == null) {
			return insertTbmMdSpcfMagtModel(tbmMdSpcfMagtModelDVO);
		} else {
			return selectUpdateTbmMdSpcfMagtModel (tbmMdSpcfMagtModelDVO);
		}
	}

	/**
	 * selectUpdateTbmMdSpcfMagtModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdSpcfMagtModel Method")
	public int selectUpdateTbmMdSpcfMagtModel (final TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO) {
		
		TbmMdSpcfMagtModelDVO tmpTbmMdSpcfMagtModelDVO =  selectTbmMdSpcfMagtModel (tbmMdSpcfMagtModelDVO);
		if ( tbmMdSpcfMagtModelDVO.getPlantCode() != null && !"".equals(tbmMdSpcfMagtModelDVO.getPlantCode()) ) {
			tmpTbmMdSpcfMagtModelDVO.setPlantCode(tbmMdSpcfMagtModelDVO.getPlantCode());
		}		
		if ( tbmMdSpcfMagtModelDVO.getModelCode() != null && !"".equals(tbmMdSpcfMagtModelDVO.getModelCode()) ) {
			tmpTbmMdSpcfMagtModelDVO.setModelCode(tbmMdSpcfMagtModelDVO.getModelCode());
		}		
		if ( tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode() != null && !"".equals(tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode()) ) {
			tmpTbmMdSpcfMagtModelDVO.setSpcfMagtTypeCode(tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
		}		
		if ( tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn() != null && !"".equals(tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn()) ) {
			tmpTbmMdSpcfMagtModelDVO.setSpcfMagtModelYn(tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn());
		}		
		if ( tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc() != null && !"".equals(tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc()) ) {
			tmpTbmMdSpcfMagtModelDVO.setSpcfMagtModelDesc(tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc());
		}		
		if ( tbmMdSpcfMagtModelDVO.getUseYn() != null && !"".equals(tbmMdSpcfMagtModelDVO.getUseYn()) ) {
			tmpTbmMdSpcfMagtModelDVO.setUseYn(tbmMdSpcfMagtModelDVO.getUseYn());
		}		
		if ( tbmMdSpcfMagtModelDVO.getFstRegDt() != null && !"".equals(tbmMdSpcfMagtModelDVO.getFstRegDt()) ) {
			tmpTbmMdSpcfMagtModelDVO.setFstRegDt(tbmMdSpcfMagtModelDVO.getFstRegDt());
		}		
		if ( tbmMdSpcfMagtModelDVO.getFstRegerId() != null && !"".equals(tbmMdSpcfMagtModelDVO.getFstRegerId()) ) {
			tmpTbmMdSpcfMagtModelDVO.setFstRegerId(tbmMdSpcfMagtModelDVO.getFstRegerId());
		}		
		if ( tbmMdSpcfMagtModelDVO.getFnlUpdDt() != null && !"".equals(tbmMdSpcfMagtModelDVO.getFnlUpdDt()) ) {
			tmpTbmMdSpcfMagtModelDVO.setFnlUpdDt(tbmMdSpcfMagtModelDVO.getFnlUpdDt());
		}		
		if ( tbmMdSpcfMagtModelDVO.getFnlUpderId() != null && !"".equals(tbmMdSpcfMagtModelDVO.getFnlUpderId()) ) {
			tmpTbmMdSpcfMagtModelDVO.setFnlUpderId(tbmMdSpcfMagtModelDVO.getFnlUpderId());
		}		
		return updateTbmMdSpcfMagtModel (tmpTbmMdSpcfMagtModelDVO);
	}

/**
* insertBatchTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return int[]
*/
	@LocalName("insertBatchTbmMdSpcfMagtModel")
	public int[] insertBatchTbmMdSpcfMagtModel (final List tbmMdSpcfMagtModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.insertBatchTbmMdSpcfMagtModel.001*/  \n");
			sql.append(" TBM_MD_SPCF_MAGT_MODEL (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPCF_MAGT_TYPE_CODE , \n");
			sql.append("        SPCF_MAGT_MODEL_YN , \n");
			sql.append("        SPCF_MAGT_MODEL_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO = (TbmMdSpcfMagtModelDVO)tbmMdSpcfMagtModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdSpcfMagtModelDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return int[]
*/
	@LocalName("updateBatchTbmMdSpcfMagtModel")
	public int[] updateBatchTbmMdSpcfMagtModel (final List tbmMdSpcfMagtModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.updateBatchTbmMdSpcfMagtModel.001*/  \n");
			sql.append(" TBM_MD_SPCF_MAGT_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        SPCF_MAGT_MODEL_YN = ? , \n");
			sql.append("        SPCF_MAGT_MODEL_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND SPCF_MAGT_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO = (TbmMdSpcfMagtModelDVO)tbmMdSpcfMagtModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtModelDesc());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
						}
							public int getBatchSize() {
									return tbmMdSpcfMagtModelDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdSpcfMagtModel Method
* 
* @ref_table TBM_MD_SPCF_MAGT_MODEL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdSpcfMagtModel")
	public int[] deleteBatchTbmMdSpcfMagtModel (final List tbmMdSpcfMagtModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdSpcfMagtModelDEM.deleteBatchTbmMdSpcfMagtModel.001*/  \n");
			sql.append(" TBM_MD_SPCF_MAGT_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND SPCF_MAGT_TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdSpcfMagtModelDVO tbmMdSpcfMagtModelDVO = (TbmMdSpcfMagtModelDVO)tbmMdSpcfMagtModelDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdSpcfMagtModelDVO.getSpcfMagtTypeCode());
						}
							public int getBatchSize() {
									return tbmMdSpcfMagtModelDVOList.size();
							}
					}
		);			
	}

	
}