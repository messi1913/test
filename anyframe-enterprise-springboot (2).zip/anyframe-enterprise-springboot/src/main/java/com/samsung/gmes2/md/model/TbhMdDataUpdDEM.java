package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_DATA_UPD
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMdDataUpdDEM extends AbstractDAO {


/**
* insertTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return int
*/
	@LocalName("insertTbhMdDataUpd")
	public int insertTbhMdDataUpd (final TbhMdDataUpdDVO tbhMdDataUpdDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.insertTbhMdDataUpd.001*/  \n");
			sql.append(" TBH_MD_DATA_UPD (   \n");
			sql.append("        TAB_NM , \n");
			sql.append("        CULM_ID , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        N1_KEY_VALUE , \n");
			sql.append("        N2_KEY_VALUE , \n");
			sql.append("        N3_KEY_VALUE , \n");
			sql.append("        N4_KEY_VALUE , \n");
			sql.append("        N5_KEY_VALUE , \n");
			sql.append("        NEW_DATA_CONT , \n");
			sql.append("        PREV_DATA_CONT , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN1KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN2KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN3KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN4KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN5KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getNewDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getPrevDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdDataUpd Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdDataUpd Method")
	public int[][] updateBatchAllTbhMdDataUpd (final List  tbhMdDataUpdDVOList) {
		
		ArrayList updatetbhMdDataUpdDVOList = new ArrayList();
		ArrayList insertttbhMdDataUpdDVOList = new ArrayList();
		ArrayList deletetbhMdDataUpdDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdDataUpdDVOList.size() ; i++) {
		  TbhMdDataUpdDVO tbhMdDataUpdDVO = (TbhMdDataUpdDVO) tbhMdDataUpdDVOList.get(i);
		  
		  if (tbhMdDataUpdDVO.getSqlAction().equals("C"))
		      insertttbhMdDataUpdDVOList.add(tbhMdDataUpdDVO);
		  else if (tbhMdDataUpdDVO.getSqlAction().equals("U"))
		      updatetbhMdDataUpdDVOList.add(tbhMdDataUpdDVO);
		  else if (tbhMdDataUpdDVO.getSqlAction().equals("D"))
		      deletetbhMdDataUpdDVOList.add(tbhMdDataUpdDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdDataUpdDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdDataUpd(insertttbhMdDataUpdDVOList);
          
      if (updatetbhMdDataUpdDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdDataUpd(updatetbhMdDataUpdDVOList);
      
      if (deletetbhMdDataUpdDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdDataUpd(deletetbhMdDataUpdDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return int
*/
	@LocalName("updateTbhMdDataUpd")
	public int updateTbhMdDataUpd (final TbhMdDataUpdDVO tbhMdDataUpdDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.updateTbhMdDataUpd.001*/  \n");
			sql.append(" TBH_MD_DATA_UPD \n");
			sql.append(" SET   \n");
			sql.append("        N1_KEY_VALUE = ? , \n");
			sql.append("        N2_KEY_VALUE = ? , \n");
			sql.append("        N3_KEY_VALUE = ? , \n");
			sql.append("        N4_KEY_VALUE = ? , \n");
			sql.append("        N5_KEY_VALUE = ? , \n");
			sql.append("        NEW_DATA_CONT = ? , \n");
			sql.append("        PREV_DATA_CONT = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TAB_NM = ? \n");
			sql.append("   AND CULM_ID = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdDataUpdDVO.getN1KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN2KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN3KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN4KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN5KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getNewDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getPrevDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpderId());

							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return int
*/
	@LocalName("deleteTbhMdDataUpd")
	public int deleteTbhMdDataUpd (final TbhMdDataUpdDVO tbhMdDataUpdDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.deleteTbhMdDataUpd.001*/  \n");
			sql.append(" TBH_MD_DATA_UPD \n");
			sql.append("  WHERE TAB_NM = ? \n");
			sql.append("    AND CULM_ID = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return TbhMdDataUpdDVO 
*/
	@LocalName("selectTbhMdDataUpd")
	public TbhMdDataUpdDVO selectTbhMdDataUpd (final TbhMdDataUpdDVO tbhMdDataUpdDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.selectTbhMdDataUpd.001*/  \n");
			sql.append("        TAB_NM , \n");
			sql.append("        CULM_ID , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        N1_KEY_VALUE , \n");
			sql.append("        N2_KEY_VALUE , \n");
			sql.append("        N3_KEY_VALUE , \n");
			sql.append("        N4_KEY_VALUE , \n");
			sql.append("        N5_KEY_VALUE , \n");
			sql.append("        NEW_DATA_CONT , \n");
			sql.append("        PREV_DATA_CONT , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBH_MD_DATA_UPD \n");
			sql.append("  WHERE TAB_NM = ? \n");
			sql.append("    AND CULM_ID = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdDataUpdDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdDataUpdDVO returnTbhMdDataUpdDVO = new TbhMdDataUpdDVO();
									returnTbhMdDataUpdDVO.setTabNm(resultSet.getString("TAB_NM"));
									returnTbhMdDataUpdDVO.setCulmId(resultSet.getString("CULM_ID"));
									returnTbhMdDataUpdDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdDataUpdDVO.setN1KeyValue(resultSet.getString("N1_KEY_VALUE"));
									returnTbhMdDataUpdDVO.setN2KeyValue(resultSet.getString("N2_KEY_VALUE"));
									returnTbhMdDataUpdDVO.setN3KeyValue(resultSet.getString("N3_KEY_VALUE"));
									returnTbhMdDataUpdDVO.setN4KeyValue(resultSet.getString("N4_KEY_VALUE"));
									returnTbhMdDataUpdDVO.setN5KeyValue(resultSet.getString("N5_KEY_VALUE"));
									returnTbhMdDataUpdDVO.setNewDataCont(resultSet.getString("NEW_DATA_CONT"));
									returnTbhMdDataUpdDVO.setPrevDataCont(resultSet.getString("PREV_DATA_CONT"));
									returnTbhMdDataUpdDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdDataUpdDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdDataUpdDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdDataUpdDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbhMdDataUpdDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdDataUpd Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdDataUpd Method")
	public int mergeTbhMdDataUpd (final TbhMdDataUpdDVO tbhMdDataUpdDVO) {
		
		if ( selectTbhMdDataUpd (tbhMdDataUpdDVO) == null) {
			return insertTbhMdDataUpd(tbhMdDataUpdDVO);
		} else {
			return selectUpdateTbhMdDataUpd (tbhMdDataUpdDVO);
		}
	}

	/**
	 * selectUpdateTbhMdDataUpd Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdDataUpd Method")
	public int selectUpdateTbhMdDataUpd (final TbhMdDataUpdDVO tbhMdDataUpdDVO) {
		
		TbhMdDataUpdDVO tmpTbhMdDataUpdDVO =  selectTbhMdDataUpd (tbhMdDataUpdDVO);
		if ( tbhMdDataUpdDVO.getTabNm() != null && !"".equals(tbhMdDataUpdDVO.getTabNm()) ) {
			tmpTbhMdDataUpdDVO.setTabNm(tbhMdDataUpdDVO.getTabNm());
		}		
		if ( tbhMdDataUpdDVO.getCulmId() != null && !"".equals(tbhMdDataUpdDVO.getCulmId()) ) {
			tmpTbhMdDataUpdDVO.setCulmId(tbhMdDataUpdDVO.getCulmId());
		}		
		if ( tbhMdDataUpdDVO.getHistTsp() != null && !"".equals(tbhMdDataUpdDVO.getHistTsp()) ) {
			tmpTbhMdDataUpdDVO.setHistTsp(tbhMdDataUpdDVO.getHistTsp());
		}		
		if ( tbhMdDataUpdDVO.getN1KeyValue() != null && !"".equals(tbhMdDataUpdDVO.getN1KeyValue()) ) {
			tmpTbhMdDataUpdDVO.setN1KeyValue(tbhMdDataUpdDVO.getN1KeyValue());
		}		
		if ( tbhMdDataUpdDVO.getN2KeyValue() != null && !"".equals(tbhMdDataUpdDVO.getN2KeyValue()) ) {
			tmpTbhMdDataUpdDVO.setN2KeyValue(tbhMdDataUpdDVO.getN2KeyValue());
		}		
		if ( tbhMdDataUpdDVO.getN3KeyValue() != null && !"".equals(tbhMdDataUpdDVO.getN3KeyValue()) ) {
			tmpTbhMdDataUpdDVO.setN3KeyValue(tbhMdDataUpdDVO.getN3KeyValue());
		}		
		if ( tbhMdDataUpdDVO.getN4KeyValue() != null && !"".equals(tbhMdDataUpdDVO.getN4KeyValue()) ) {
			tmpTbhMdDataUpdDVO.setN4KeyValue(tbhMdDataUpdDVO.getN4KeyValue());
		}		
		if ( tbhMdDataUpdDVO.getN5KeyValue() != null && !"".equals(tbhMdDataUpdDVO.getN5KeyValue()) ) {
			tmpTbhMdDataUpdDVO.setN5KeyValue(tbhMdDataUpdDVO.getN5KeyValue());
		}		
		if ( tbhMdDataUpdDVO.getNewDataCont() != null && !"".equals(tbhMdDataUpdDVO.getNewDataCont()) ) {
			tmpTbhMdDataUpdDVO.setNewDataCont(tbhMdDataUpdDVO.getNewDataCont());
		}		
		if ( tbhMdDataUpdDVO.getPrevDataCont() != null && !"".equals(tbhMdDataUpdDVO.getPrevDataCont()) ) {
			tmpTbhMdDataUpdDVO.setPrevDataCont(tbhMdDataUpdDVO.getPrevDataCont());
		}		
		if ( tbhMdDataUpdDVO.getFstRegDt() != null && !"".equals(tbhMdDataUpdDVO.getFstRegDt()) ) {
			tmpTbhMdDataUpdDVO.setFstRegDt(tbhMdDataUpdDVO.getFstRegDt());
		}		
		if ( tbhMdDataUpdDVO.getFstRegerId() != null && !"".equals(tbhMdDataUpdDVO.getFstRegerId()) ) {
			tmpTbhMdDataUpdDVO.setFstRegerId(tbhMdDataUpdDVO.getFstRegerId());
		}		
		if ( tbhMdDataUpdDVO.getFnlUpdDt() != null && !"".equals(tbhMdDataUpdDVO.getFnlUpdDt()) ) {
			tmpTbhMdDataUpdDVO.setFnlUpdDt(tbhMdDataUpdDVO.getFnlUpdDt());
		}		
		if ( tbhMdDataUpdDVO.getFnlUpderId() != null && !"".equals(tbhMdDataUpdDVO.getFnlUpderId()) ) {
			tmpTbhMdDataUpdDVO.setFnlUpderId(tbhMdDataUpdDVO.getFnlUpderId());
		}		
		return updateTbhMdDataUpd (tmpTbhMdDataUpdDVO);
	}

/**
* insertBatchTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return int[]
*/
	@LocalName("insertBatchTbhMdDataUpd")
	public int[] insertBatchTbhMdDataUpd (final List tbhMdDataUpdDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.insertBatchTbhMdDataUpd.001*/  \n");
			sql.append(" TBH_MD_DATA_UPD (   \n");
			sql.append("        TAB_NM , \n");
			sql.append("        CULM_ID , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        N1_KEY_VALUE , \n");
			sql.append("        N2_KEY_VALUE , \n");
			sql.append("        N3_KEY_VALUE , \n");
			sql.append("        N4_KEY_VALUE , \n");
			sql.append("        N5_KEY_VALUE , \n");
			sql.append("        NEW_DATA_CONT , \n");
			sql.append("        PREV_DATA_CONT , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdDataUpdDVO tbhMdDataUpdDVO = (TbhMdDataUpdDVO)tbhMdDataUpdDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN1KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN2KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN3KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN4KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN5KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getNewDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getPrevDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbhMdDataUpdDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return int[]
*/
	@LocalName("updateBatchTbhMdDataUpd")
	public int[] updateBatchTbhMdDataUpd (final List tbhMdDataUpdDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.updateBatchTbhMdDataUpd.001*/  \n");
			sql.append(" TBH_MD_DATA_UPD \n");
			sql.append(" SET   \n");
			sql.append("        N1_KEY_VALUE = ? , \n");
			sql.append("        N2_KEY_VALUE = ? , \n");
			sql.append("        N3_KEY_VALUE = ? , \n");
			sql.append("        N4_KEY_VALUE = ? , \n");
			sql.append("        N5_KEY_VALUE = ? , \n");
			sql.append("        NEW_DATA_CONT = ? , \n");
			sql.append("        PREV_DATA_CONT = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TAB_NM = ? \n");
			sql.append("   AND CULM_ID = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdDataUpdDVO tbhMdDataUpdDVO = (TbhMdDataUpdDVO)tbhMdDataUpdDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdDataUpdDVO.getN1KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN2KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN3KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN4KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getN5KeyValue());
							ps.setString(psCount++, tbhMdDataUpdDVO.getNewDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getPrevDataCont());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdDataUpdDVO.getFnlUpderId());

							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdDataUpdDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdDataUpd Method
* 
* @ref_table TBH_MD_DATA_UPD
* @return int[]
*/
	@LocalName("deleteBatchTbhMdDataUpd")
	public int[] deleteBatchTbhMdDataUpd (final List tbhMdDataUpdDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdDataUpdDEM.deleteBatchTbhMdDataUpd.001*/  \n");
			sql.append(" TBH_MD_DATA_UPD \n");
			sql.append("  WHERE TAB_NM = ? \n");
			sql.append("    AND CULM_ID = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdDataUpdDVO tbhMdDataUpdDVO = (TbhMdDataUpdDVO)tbhMdDataUpdDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdDataUpdDVO.getTabNm());
							ps.setString(psCount++, tbhMdDataUpdDVO.getCulmId());
							ps.setString(psCount++, tbhMdDataUpdDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdDataUpdDVOList.size();
							}
					}
		);			
	}

	
}