package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbmMcIpOiDVO extends AbstractDVO {

	@Length(18) @NotNull
	private String ip;

	@Length(50) @NotNull
	private String pgmCode;

	@Length(1) 
	private String dfltYn;

	@Length(1000) 
	private String ipOiDesc;


	public String getIp() {
		this.ip = super.getValue("ip");
		return this.ip;
	}

	public void setIp(String ip) {
        super.setValue("ip", ip);
		this.ip = ip;
	}
	
	public String getPgmCode() {
		this.pgmCode = super.getValue("pgmCode");
		return this.pgmCode;
	}

	public void setPgmCode(String pgmCode) {
        super.setValue("pgmCode", pgmCode);
		this.pgmCode = pgmCode;
	}
	
	public String getDfltYn() {
		this.dfltYn = super.getValue("dfltYn");
		return this.dfltYn;
	}

	public void setDfltYn(String dfltYn) {
        super.setValue("dfltYn", dfltYn);
		this.dfltYn = dfltYn;
	}
	
	public String getIpOiDesc() {
		this.ipOiDesc = super.getValue("ipOiDesc");
		return this.ipOiDesc;
	}

	public void setIpOiDesc(String ipOiDesc) {
        super.setValue("ipOiDesc", ipOiDesc);
		this.ipOiDesc = ipOiDesc;
	}
	
}