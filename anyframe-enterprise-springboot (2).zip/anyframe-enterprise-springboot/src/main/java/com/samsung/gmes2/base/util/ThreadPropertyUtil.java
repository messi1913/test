package com.samsung.gmes2.base.util;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ThreadPropertyUtil
{
    /**
     * 쓰레드 속성값을 조회합니다. 이 값은 현재의 쓰레드에서만 유효한 값입니다.
     * 
     * @param key
     * @return
     */
    public static Object get( String key )
    {
        return getThreadPropertyMap( ).get( key );
    }

    /**
     * 쓰레드 속성값을 설정합니다. 이 값은 현재의 쓰레드에서만 유효한 값입니다.
     * 
     * @param key
     * @param value
     */
    public static void put( String key, Object value )
    {
        getThreadPropertyMap( ).put( key, value );
    }

    /**
     * 쓰레드 속성값이 있는지를 확인합니다.
     * 
     * @param key
     * @return
     */
    public static boolean contains( String key )
    {
        return getThreadPropertyMap( ).containsKey( key );
    }

    /**
     * 쓰레드 속성값을 파기합니다.
     * 
     * @param key
     * @return
     */
    public static Object remove( String key )
    {
        return getThreadPropertyMap( ).remove( key );
    }

    /**
     * 쓰레드 속성값 전체를 파기합니다.
     */
    public static void removeAll( )
    {
        threadPropertiesMap.remove( Thread.currentThread( ).getId( ) );
    }

    private static Map<Long, Map<String, Object>> threadPropertiesMap = new ConcurrentHashMap<Long, Map<String, Object>>( );

    private static Map<String, Object> getThreadPropertyMap( )
    {
        Long threadId = Thread.currentThread( ).getId( );
        if ( threadPropertiesMap.containsKey( threadId ) )
            return threadPropertiesMap.get( threadId );
        Map<String, Object> propMap = new HashMap<String, Object>( );
        threadPropertiesMap.put( threadId, propMap );
        return propMap;
    }
}
