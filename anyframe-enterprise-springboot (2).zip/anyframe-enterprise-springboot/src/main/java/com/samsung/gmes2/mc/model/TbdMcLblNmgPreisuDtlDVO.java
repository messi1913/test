package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbdMcLblNmgPreisuDtlDVO extends AbstractVo {

	@Length(50) 
	private String nmgId;

	@Length(15) 
	private BigDecimal nmgSeq;

	@Length(50) 
	private String nmgNo;

	@Length(1) 
	private String prtYn;

	@Length(17) @Scale(5) 
	private BigDecimal prtCnt;

	@Length(50) 
	private String prterId;

	@Length(14) 
	private String prtDt;

	@Length(50) 
	private String lastPrterId;

	@Length(14) 
	private String lastPrtDt;

	@Length(20) 
	private String plantCode;

	@Length(20) 
	private String modelCode;


	public String getNmgId() {
		this.nmgId = super.getValue(0);
		return this.nmgId;
	}

	public void setNmgId(String nmgId) {
        super.setValue(0, nmgId);
		this.nmgId = nmgId;
	}
	
	public BigDecimal getNmgSeq() {
		this.nmgSeq = super.getValue(1);
		return this.nmgSeq;
	}

	public void setNmgSeq(BigDecimal nmgSeq) {
        super.setValue(1, nmgSeq);
		this.nmgSeq = nmgSeq;
	}
	
	public String getNmgNo() {
		this.nmgNo = super.getValue(2);
		return this.nmgNo;
	}

	public void setNmgNo(String nmgNo) {
        super.setValue(2, nmgNo);
		this.nmgNo = nmgNo;
	}
	
	public String getPrtYn() {
		this.prtYn = super.getValue(3);
		return this.prtYn;
	}

	public void setPrtYn(String prtYn) {
        super.setValue(3, prtYn);
		this.prtYn = prtYn;
	}
	
	public BigDecimal getPrtCnt() {
		this.prtCnt = super.getValue(4);
		return this.prtCnt;
	}

	public void setPrtCnt(BigDecimal prtCnt) {
        super.setValue(4, prtCnt);
		this.prtCnt = prtCnt;
	}
	
	public String getPrterId() {
		this.prterId = super.getValue(5);
		return this.prterId;
	}

	public void setPrterId(String prterId) {
        super.setValue(5, prterId);
		this.prterId = prterId;
	}
	
	public String getPrtDt() {
		this.prtDt = super.getValue(6);
		return this.prtDt;
	}

	public void setPrtDt(String prtDt) {
        super.setValue(6, prtDt);
		this.prtDt = prtDt;
	}
	
	public String getLastPrterId() {
		this.lastPrterId = super.getValue(7);
		return this.lastPrterId;
	}

	public void setLastPrterId(String lastPrterId) {
        super.setValue(7, lastPrterId);
		this.lastPrterId = lastPrterId;
	}
	
	public String getLastPrtDt() {
		this.lastPrtDt = super.getValue(8);
		return this.lastPrtDt;
	}

	public void setLastPrtDt(String lastPrtDt) {
        super.setValue(8, lastPrtDt);
		this.lastPrtDt = lastPrtDt;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(9);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(9, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(10);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(10, modelCode);
		this.modelCode = modelCode;
	}
	
}