package com.samsung.gmes2.md.logi.biz;

public class MdManageMoveInstPtnBiz {

	/**
	 * 이동지시패턴 목록 조회
	 */
	public void listMoveInstPtn(){}

	/**
	 * 이동지시패턴 목록 저장
	 */
	public void saveMoveInstPtn(){}

}
