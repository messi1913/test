package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeftAlrmBaseDEM extends AbstractDAO {


/**
* insertTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return int
*/
	@LocalName("insertTbcMdDeftAlrmBase")
	public int insertTbcMdDeftAlrmBase (final TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.insertTbcMdDeftAlrmBase.001*/  \n");
			sql.append(" TBC_MD_DEFT_ALRM_BASE (   \n");
			sql.append("        DEFT_ALRM_BASE_CODE , \n");
			sql.append("        DEFT_OCC_BASE_NUM , \n");
			sql.append("        DEFT_OCC_BASE_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
							ps.setBigDecimal(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeftAlrmBase Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeftAlrmBase Method")
	public int[][] updateBatchAllTbcMdDeftAlrmBase (final List  tbcMdDeftAlrmBaseDVOList) {
		
		ArrayList updatetbcMdDeftAlrmBaseDVOList = new ArrayList();
		ArrayList insertttbcMdDeftAlrmBaseDVOList = new ArrayList();
		ArrayList deletetbcMdDeftAlrmBaseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeftAlrmBaseDVOList.size() ; i++) {
		  TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO = (TbcMdDeftAlrmBaseDVO) tbcMdDeftAlrmBaseDVOList.get(i);
		  
		  if (tbcMdDeftAlrmBaseDVO.getSqlAction().equals("C"))
		      insertttbcMdDeftAlrmBaseDVOList.add(tbcMdDeftAlrmBaseDVO);
		  else if (tbcMdDeftAlrmBaseDVO.getSqlAction().equals("U"))
		      updatetbcMdDeftAlrmBaseDVOList.add(tbcMdDeftAlrmBaseDVO);
		  else if (tbcMdDeftAlrmBaseDVO.getSqlAction().equals("D"))
		      deletetbcMdDeftAlrmBaseDVOList.add(tbcMdDeftAlrmBaseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeftAlrmBaseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeftAlrmBase(insertttbcMdDeftAlrmBaseDVOList);
          
      if (updatetbcMdDeftAlrmBaseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeftAlrmBase(updatetbcMdDeftAlrmBaseDVOList);
      
      if (deletetbcMdDeftAlrmBaseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeftAlrmBase(deletetbcMdDeftAlrmBaseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return int
*/
	@LocalName("updateTbcMdDeftAlrmBase")
	public int updateTbcMdDeftAlrmBase (final TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.updateTbcMdDeftAlrmBase.001*/  \n");
			sql.append(" TBC_MD_DEFT_ALRM_BASE \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_OCC_BASE_NUM = ? , \n");
			sql.append("        DEFT_OCC_BASE_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_ALRM_BASE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return int
*/
	@LocalName("deleteTbcMdDeftAlrmBase")
	public int deleteTbcMdDeftAlrmBase (final TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.deleteTbcMdDeftAlrmBase.001*/  \n");
			sql.append(" TBC_MD_DEFT_ALRM_BASE \n");
			sql.append("  WHERE DEFT_ALRM_BASE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return TbcMdDeftAlrmBaseDVO 
*/
	@LocalName("selectTbcMdDeftAlrmBase")
	public TbcMdDeftAlrmBaseDVO selectTbcMdDeftAlrmBase (final TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.selectTbcMdDeftAlrmBase.001*/  \n");
			sql.append("        DEFT_ALRM_BASE_CODE , \n");
			sql.append("        DEFT_OCC_BASE_NUM , \n");
			sql.append("        DEFT_OCC_BASE_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEFT_ALRM_BASE \n");
			sql.append("  WHERE DEFT_ALRM_BASE_CODE = ? \n");

		return (TbcMdDeftAlrmBaseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeftAlrmBaseDVO returnTbcMdDeftAlrmBaseDVO = new TbcMdDeftAlrmBaseDVO();
									returnTbcMdDeftAlrmBaseDVO.setDeftAlrmBaseCode(resultSet.getString("DEFT_ALRM_BASE_CODE"));
									returnTbcMdDeftAlrmBaseDVO.setDeftOccBaseNum(resultSet.getBigDecimal("DEFT_OCC_BASE_NUM"));
									returnTbcMdDeftAlrmBaseDVO.setDeftOccBaseDesc(resultSet.getString("DEFT_OCC_BASE_DESC"));
									returnTbcMdDeftAlrmBaseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftAlrmBaseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftAlrmBaseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftAlrmBaseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftAlrmBaseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftAlrmBaseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeftAlrmBase Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeftAlrmBase Method")
	public int mergeTbcMdDeftAlrmBase (final TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO) {
		
		if ( selectTbcMdDeftAlrmBase (tbcMdDeftAlrmBaseDVO) == null) {
			return insertTbcMdDeftAlrmBase(tbcMdDeftAlrmBaseDVO);
		} else {
			return selectUpdateTbcMdDeftAlrmBase (tbcMdDeftAlrmBaseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeftAlrmBase Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeftAlrmBase Method")
	public int selectUpdateTbcMdDeftAlrmBase (final TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO) {
		
		TbcMdDeftAlrmBaseDVO tmpTbcMdDeftAlrmBaseDVO =  selectTbcMdDeftAlrmBase (tbcMdDeftAlrmBaseDVO);
		if ( tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setDeftAlrmBaseCode(tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setDeftOccBaseNum(tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setDeftOccBaseDesc(tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getUseYn() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getUseYn()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setUseYn(tbcMdDeftAlrmBaseDVO.getUseYn());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getFstRegDt() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getFstRegDt()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setFstRegDt(tbcMdDeftAlrmBaseDVO.getFstRegDt());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getFstRegerId() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getFstRegerId()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setFstRegerId(tbcMdDeftAlrmBaseDVO.getFstRegerId());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setFnlUpdDt(tbcMdDeftAlrmBaseDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeftAlrmBaseDVO.getFnlUpderId() != null && !"".equals(tbcMdDeftAlrmBaseDVO.getFnlUpderId()) ) {
			tmpTbcMdDeftAlrmBaseDVO.setFnlUpderId(tbcMdDeftAlrmBaseDVO.getFnlUpderId());
		}		
		return updateTbcMdDeftAlrmBase (tmpTbcMdDeftAlrmBaseDVO);
	}

/**
* insertBatchTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeftAlrmBase")
	public int[] insertBatchTbcMdDeftAlrmBase (final List tbcMdDeftAlrmBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.insertBatchTbcMdDeftAlrmBase.001*/  \n");
			sql.append(" TBC_MD_DEFT_ALRM_BASE (   \n");
			sql.append("        DEFT_ALRM_BASE_CODE , \n");
			sql.append("        DEFT_OCC_BASE_NUM , \n");
			sql.append("        DEFT_OCC_BASE_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO = (TbcMdDeftAlrmBaseDVO)tbcMdDeftAlrmBaseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
							ps.setBigDecimal(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeftAlrmBaseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeftAlrmBase")
	public int[] updateBatchTbcMdDeftAlrmBase (final List tbcMdDeftAlrmBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.updateBatchTbcMdDeftAlrmBase.001*/  \n");
			sql.append(" TBC_MD_DEFT_ALRM_BASE \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_OCC_BASE_NUM = ? , \n");
			sql.append("        DEFT_OCC_BASE_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_ALRM_BASE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO = (TbcMdDeftAlrmBaseDVO)tbcMdDeftAlrmBaseDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseNum());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftOccBaseDesc());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
						}
							public int getBatchSize() {
									return tbcMdDeftAlrmBaseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeftAlrmBase Method
* 
* @ref_table TBC_MD_DEFT_ALRM_BASE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeftAlrmBase")
	public int[] deleteBatchTbcMdDeftAlrmBase (final List tbcMdDeftAlrmBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftAlrmBaseDEM.deleteBatchTbcMdDeftAlrmBase.001*/  \n");
			sql.append(" TBC_MD_DEFT_ALRM_BASE \n");
			sql.append("  WHERE DEFT_ALRM_BASE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftAlrmBaseDVO tbcMdDeftAlrmBaseDVO = (TbcMdDeftAlrmBaseDVO)tbcMdDeftAlrmBaseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftAlrmBaseDVO.getDeftAlrmBaseCode());
						}
							public int getBatchSize() {
									return tbcMdDeftAlrmBaseDVOList.size();
							}
					}
		);			
	}

	
}