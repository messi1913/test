package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeftSympClsfDEM extends AbstractDAO {


/**
* insertTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return int
*/
	@LocalName("insertTbcMdDeftSympClsf")
	public int insertTbcMdDeftSympClsf (final TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.insertTbcMdDeftSympClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP_CLSF (   \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        DEFT_SYMP_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfNm());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeftSympClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeftSympClsf Method")
	public int[][] updateBatchAllTbcMdDeftSympClsf (final List  tbcMdDeftSympClsfDVOList) {
		
		ArrayList updatetbcMdDeftSympClsfDVOList = new ArrayList();
		ArrayList insertttbcMdDeftSympClsfDVOList = new ArrayList();
		ArrayList deletetbcMdDeftSympClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeftSympClsfDVOList.size() ; i++) {
		  TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO = (TbcMdDeftSympClsfDVO) tbcMdDeftSympClsfDVOList.get(i);
		  
		  if (tbcMdDeftSympClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdDeftSympClsfDVOList.add(tbcMdDeftSympClsfDVO);
		  else if (tbcMdDeftSympClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdDeftSympClsfDVOList.add(tbcMdDeftSympClsfDVO);
		  else if (tbcMdDeftSympClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdDeftSympClsfDVOList.add(tbcMdDeftSympClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeftSympClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeftSympClsf(insertttbcMdDeftSympClsfDVOList);
          
      if (updatetbcMdDeftSympClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeftSympClsf(updatetbcMdDeftSympClsfDVOList);
      
      if (deletetbcMdDeftSympClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeftSympClsf(deletetbcMdDeftSympClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return int
*/
	@LocalName("updateTbcMdDeftSympClsf")
	public int updateTbcMdDeftSympClsf (final TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.updateTbcMdDeftSympClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_SYMP_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_SYMP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfNm());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return int
*/
	@LocalName("deleteTbcMdDeftSympClsf")
	public int deleteTbcMdDeftSympClsf (final TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.deleteTbcMdDeftSympClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP_CLSF \n");
			sql.append("  WHERE DEFT_SYMP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return TbcMdDeftSympClsfDVO 
*/
	@LocalName("selectTbcMdDeftSympClsf")
	public TbcMdDeftSympClsfDVO selectTbcMdDeftSympClsf (final TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.selectTbcMdDeftSympClsf.001*/  \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        DEFT_SYMP_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEFT_SYMP_CLSF \n");
			sql.append("  WHERE DEFT_SYMP_CLSF_CODE = ? \n");

		return (TbcMdDeftSympClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeftSympClsfDVO returnTbcMdDeftSympClsfDVO = new TbcMdDeftSympClsfDVO();
									returnTbcMdDeftSympClsfDVO.setDeftSympClsfCode(resultSet.getString("DEFT_SYMP_CLSF_CODE"));
									returnTbcMdDeftSympClsfDVO.setDeftSympClsfNm(resultSet.getString("DEFT_SYMP_CLSF_NM"));
									returnTbcMdDeftSympClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftSympClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftSympClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftSympClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftSympClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftSympClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeftSympClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeftSympClsf Method")
	public int mergeTbcMdDeftSympClsf (final TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO) {
		
		if ( selectTbcMdDeftSympClsf (tbcMdDeftSympClsfDVO) == null) {
			return insertTbcMdDeftSympClsf(tbcMdDeftSympClsfDVO);
		} else {
			return selectUpdateTbcMdDeftSympClsf (tbcMdDeftSympClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeftSympClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeftSympClsf Method")
	public int selectUpdateTbcMdDeftSympClsf (final TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO) {
		
		TbcMdDeftSympClsfDVO tmpTbcMdDeftSympClsfDVO =  selectTbcMdDeftSympClsf (tbcMdDeftSympClsfDVO);
		if ( tbcMdDeftSympClsfDVO.getDeftSympClsfCode() != null && !"".equals(tbcMdDeftSympClsfDVO.getDeftSympClsfCode()) ) {
			tmpTbcMdDeftSympClsfDVO.setDeftSympClsfCode(tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
		}		
		if ( tbcMdDeftSympClsfDVO.getDeftSympClsfNm() != null && !"".equals(tbcMdDeftSympClsfDVO.getDeftSympClsfNm()) ) {
			tmpTbcMdDeftSympClsfDVO.setDeftSympClsfNm(tbcMdDeftSympClsfDVO.getDeftSympClsfNm());
		}		
		if ( tbcMdDeftSympClsfDVO.getUseYn() != null && !"".equals(tbcMdDeftSympClsfDVO.getUseYn()) ) {
			tmpTbcMdDeftSympClsfDVO.setUseYn(tbcMdDeftSympClsfDVO.getUseYn());
		}		
		if ( tbcMdDeftSympClsfDVO.getFstRegDt() != null && !"".equals(tbcMdDeftSympClsfDVO.getFstRegDt()) ) {
			tmpTbcMdDeftSympClsfDVO.setFstRegDt(tbcMdDeftSympClsfDVO.getFstRegDt());
		}		
		if ( tbcMdDeftSympClsfDVO.getFstRegerId() != null && !"".equals(tbcMdDeftSympClsfDVO.getFstRegerId()) ) {
			tmpTbcMdDeftSympClsfDVO.setFstRegerId(tbcMdDeftSympClsfDVO.getFstRegerId());
		}		
		if ( tbcMdDeftSympClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeftSympClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeftSympClsfDVO.setFnlUpdDt(tbcMdDeftSympClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeftSympClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdDeftSympClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdDeftSympClsfDVO.setFnlUpderId(tbcMdDeftSympClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdDeftSympClsf (tmpTbcMdDeftSympClsfDVO);
	}

/**
* insertBatchTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeftSympClsf")
	public int[] insertBatchTbcMdDeftSympClsf (final List tbcMdDeftSympClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.insertBatchTbcMdDeftSympClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP_CLSF (   \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        DEFT_SYMP_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO = (TbcMdDeftSympClsfDVO)tbcMdDeftSympClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfNm());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeftSympClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeftSympClsf")
	public int[] updateBatchTbcMdDeftSympClsf (final List tbcMdDeftSympClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.updateBatchTbcMdDeftSympClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_SYMP_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_SYMP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO = (TbcMdDeftSympClsfDVO)tbcMdDeftSympClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfNm());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDeftSympClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeftSympClsf Method
* 
* @ref_table TBC_MD_DEFT_SYMP_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeftSympClsf")
	public int[] deleteBatchTbcMdDeftSympClsf (final List tbcMdDeftSympClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftSympClsfDEM.deleteBatchTbcMdDeftSympClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP_CLSF \n");
			sql.append("  WHERE DEFT_SYMP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftSympClsfDVO tbcMdDeftSympClsfDVO = (TbcMdDeftSympClsfDVO)tbcMdDeftSympClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftSympClsfDVO.getDeftSympClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDeftSympClsfDVOList.size();
							}
					}
		);			
	}

	
}