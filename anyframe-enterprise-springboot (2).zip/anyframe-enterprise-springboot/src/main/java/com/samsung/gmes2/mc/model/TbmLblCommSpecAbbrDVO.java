package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbmLblCommSpecAbbrDVO extends AbstractVo {

	@Length(500) 
	private String specAbbrNm;

	@Length(500) 
	private String specNm;


	public String getSpecAbbrNm() {
		this.specAbbrNm = super.getValue(0);
		return this.specAbbrNm;
	}

	public void setSpecAbbrNm(String specAbbrNm) {
        super.setValue(0, specAbbrNm);
		this.specAbbrNm = specAbbrNm;
	}
	
	public String getSpecNm() {
		this.specNm = super.getValue(1);
		return this.specNm;
	}

	public void setSpecNm(String specNm) {
        super.setValue(1, specNm);
		this.specNm = specNm;
	}
	
}