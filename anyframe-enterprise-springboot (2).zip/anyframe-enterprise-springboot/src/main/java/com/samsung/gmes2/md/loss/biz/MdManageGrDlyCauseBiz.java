package com.samsung.gmes2.md.loss.biz;

public class MdManageGrDlyCauseBiz {

	/**
	 * 입고지연원인코드 목록 조회
	 */
	public void listGrDlyCauseCode(){}

	/**
	 * 입고지연원인코드 목록 저장
	 */
	public void saveGrDlyCauseCode(){}

}
