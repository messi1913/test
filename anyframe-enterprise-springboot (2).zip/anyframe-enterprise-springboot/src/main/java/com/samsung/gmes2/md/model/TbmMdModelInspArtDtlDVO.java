package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdModelInspArtDtlDVO extends AbstractVo {

	@Length(30) 
	private String gbmCode;

	@Length(30) 
	private String corpCode;

	@Length(30) 
	private String prodGrpCode;

	@Length(30) 
	private String prodAbbrCode;

	@Length(30) 
	private String pjtCode;

	@Length(30) 
	private String inspArtDtlCode;

	@Length(20) 
	private String modelCode;

	@Length(30) 
	private String specUlimitValue;

	@Length(11) @Scale(5) 
	private BigDecimal specLlimitValue;

	@Length(11) @Scale(5) 
	private BigDecimal magtUlimitValue;

	@Length(11) @Scale(5) 
	private BigDecimal magtLlimitValue;

	@Length(1) 
	private String fixYn;

	@Length(2000) 
	private String modelInspArtDesc;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGbmCode() {
		this.gbmCode = super.getValue(0);
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue(0, gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getCorpCode() {
		this.corpCode = super.getValue(1);
		return this.corpCode;
	}

	public void setCorpCode(String corpCode) {
        super.setValue(1, corpCode);
		this.corpCode = corpCode;
	}
	
	public String getProdGrpCode() {
		this.prodGrpCode = super.getValue(2);
		return this.prodGrpCode;
	}

	public void setProdGrpCode(String prodGrpCode) {
        super.setValue(2, prodGrpCode);
		this.prodGrpCode = prodGrpCode;
	}
	
	public String getProdAbbrCode() {
		this.prodAbbrCode = super.getValue(3);
		return this.prodAbbrCode;
	}

	public void setProdAbbrCode(String prodAbbrCode) {
        super.setValue(3, prodAbbrCode);
		this.prodAbbrCode = prodAbbrCode;
	}
	
	public String getPjtCode() {
		this.pjtCode = super.getValue(4);
		return this.pjtCode;
	}

	public void setPjtCode(String pjtCode) {
        super.setValue(4, pjtCode);
		this.pjtCode = pjtCode;
	}
	
	public String getInspArtDtlCode() {
		this.inspArtDtlCode = super.getValue(5);
		return this.inspArtDtlCode;
	}

	public void setInspArtDtlCode(String inspArtDtlCode) {
        super.setValue(5, inspArtDtlCode);
		this.inspArtDtlCode = inspArtDtlCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(6);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(6, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getSpecUlimitValue() {
		this.specUlimitValue = super.getValue(7);
		return this.specUlimitValue;
	}

	public void setSpecUlimitValue(String specUlimitValue) {
        super.setValue(7, specUlimitValue);
		this.specUlimitValue = specUlimitValue;
	}
	
	public BigDecimal getSpecLlimitValue() {
		this.specLlimitValue = super.getValue(8);
		return this.specLlimitValue;
	}

	public void setSpecLlimitValue(BigDecimal specLlimitValue) {
        super.setValue(8, specLlimitValue);
		this.specLlimitValue = specLlimitValue;
	}
	
	public BigDecimal getMagtUlimitValue() {
		this.magtUlimitValue = super.getValue(9);
		return this.magtUlimitValue;
	}

	public void setMagtUlimitValue(BigDecimal magtUlimitValue) {
        super.setValue(9, magtUlimitValue);
		this.magtUlimitValue = magtUlimitValue;
	}
	
	public BigDecimal getMagtLlimitValue() {
		this.magtLlimitValue = super.getValue(10);
		return this.magtLlimitValue;
	}

	public void setMagtLlimitValue(BigDecimal magtLlimitValue) {
        super.setValue(10, magtLlimitValue);
		this.magtLlimitValue = magtLlimitValue;
	}
	
	public String getFixYn() {
		this.fixYn = super.getValue(11);
		return this.fixYn;
	}

	public void setFixYn(String fixYn) {
        super.setValue(11, fixYn);
		this.fixYn = fixYn;
	}
	
	public String getModelInspArtDesc() {
		this.modelInspArtDesc = super.getValue(12);
		return this.modelInspArtDesc;
	}

	public void setModelInspArtDesc(String modelInspArtDesc) {
        super.setValue(12, modelInspArtDesc);
		this.modelInspArtDesc = modelInspArtDesc;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(13);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(13, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(14);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(14, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(15);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(15, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(16);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(16, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(17);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(17, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}