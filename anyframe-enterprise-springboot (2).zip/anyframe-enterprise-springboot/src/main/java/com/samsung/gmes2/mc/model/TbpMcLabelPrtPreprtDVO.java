package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbpMcLabelPrtPreprtDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String nmgId;

	@Length(15) @NotNull
	private BigDecimal nmgSeq;

	@Length(14) @NotNull
	private String prtDt;

	@Length(20) 
	private String plantCode;

	@Length(20) @NotNull
	private String modelCode;

	@Length(50) @NotNull
	private String labelId;

	@Length(50) 
	private String prterId;

	@Length(1) @NotNull
	private String rePrtYn;

	@Length(1000) 
	private String rePrtRsn;


	public String getNmgId() {
		this.nmgId = super.getValue("nmgId");
		return this.nmgId;
	}

	public void setNmgId(String nmgId) {
        super.setValue("nmgId", nmgId);
		this.nmgId = nmgId;
	}
	
	public BigDecimal getNmgSeq() {
		this.nmgSeq = super.getValue("nmgSeq");
		return this.nmgSeq;
	}

	public void setNmgSeq(BigDecimal nmgSeq) {
        super.setValue("nmgSeq", nmgSeq);
		this.nmgSeq = nmgSeq;
	}
	
	public String getPrtDt() {
		this.prtDt = super.getValue("prtDt");
		return this.prtDt;
	}

	public void setPrtDt(String prtDt) {
        super.setValue("prtDt", prtDt);
		this.prtDt = prtDt;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue("plantCode");
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue("plantCode", plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue("modelCode");
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue("modelCode", modelCode);
		this.modelCode = modelCode;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue("labelId");
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue("labelId", labelId);
		this.labelId = labelId;
	}
	
	public String getPrterId() {
		this.prterId = super.getValue("prterId");
		return this.prterId;
	}

	public void setPrterId(String prterId) {
        super.setValue("prterId", prterId);
		this.prterId = prterId;
	}
	
	public String getRePrtYn() {
		this.rePrtYn = super.getValue("rePrtYn");
		return this.rePrtYn;
	}

	public void setRePrtYn(String rePrtYn) {
        super.setValue("rePrtYn", rePrtYn);
		this.rePrtYn = rePrtYn;
	}
	
	public String getRePrtRsn() {
		this.rePrtRsn = super.getValue("rePrtRsn");
		return this.rePrtRsn;
	}

	public void setRePrtRsn(String rePrtRsn) {
        super.setValue("rePrtRsn", rePrtRsn);
		this.rePrtRsn = rePrtRsn;
	}
	
}