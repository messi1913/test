package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_GBM_INSP_CLSF
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdGbmInspClsfDEM extends AbstractDAO {


/**
* insertTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return int
*/
	@LocalName("insertTbmMdGbmInspClsf")
	public int insertTbmMdGbmInspClsf (final TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.insertTbmMdGbmInspClsf.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_CLSF (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdGbmInspClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdGbmInspClsf Method")
	public int[][] updateBatchAllTbmMdGbmInspClsf (final List  tbmMdGbmInspClsfDVOList) {
		
		ArrayList updatetbmMdGbmInspClsfDVOList = new ArrayList();
		ArrayList insertttbmMdGbmInspClsfDVOList = new ArrayList();
		ArrayList deletetbmMdGbmInspClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdGbmInspClsfDVOList.size() ; i++) {
		  TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO = (TbmMdGbmInspClsfDVO) tbmMdGbmInspClsfDVOList.get(i);
		  
		  if (tbmMdGbmInspClsfDVO.getSqlAction().equals("C"))
		      insertttbmMdGbmInspClsfDVOList.add(tbmMdGbmInspClsfDVO);
		  else if (tbmMdGbmInspClsfDVO.getSqlAction().equals("U"))
		      updatetbmMdGbmInspClsfDVOList.add(tbmMdGbmInspClsfDVO);
		  else if (tbmMdGbmInspClsfDVO.getSqlAction().equals("D"))
		      deletetbmMdGbmInspClsfDVOList.add(tbmMdGbmInspClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdGbmInspClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdGbmInspClsf(insertttbmMdGbmInspClsfDVOList);
          
      if (updatetbmMdGbmInspClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdGbmInspClsf(updatetbmMdGbmInspClsfDVOList);
      
      if (deletetbmMdGbmInspClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdGbmInspClsf(deletetbmMdGbmInspClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return int
*/
	@LocalName("updateTbmMdGbmInspClsf")
	public int updateTbmMdGbmInspClsf (final TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.updateTbmMdGbmInspClsf.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND INSP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
						}
					}
		);			
	}

/**
* deleteTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return int
*/
	@LocalName("deleteTbmMdGbmInspClsf")
	public int deleteTbmMdGbmInspClsf (final TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.deleteTbmMdGbmInspClsf.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_CLSF \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
						}
					}
		);			
	}

/**
* selectTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return TbmMdGbmInspClsfDVO 
*/
	@LocalName("selectTbmMdGbmInspClsf")
	public TbmMdGbmInspClsfDVO selectTbmMdGbmInspClsf (final TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.selectTbmMdGbmInspClsf.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_GBM_INSP_CLSF \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_CLSF_CODE = ? \n");

		return (TbmMdGbmInspClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdGbmInspClsfDVO returnTbmMdGbmInspClsfDVO = new TbmMdGbmInspClsfDVO();
									returnTbmMdGbmInspClsfDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdGbmInspClsfDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbmMdGbmInspClsfDVO.setIfDt(resultSet.getString("IF_DT"));
									returnTbmMdGbmInspClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdGbmInspClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdGbmInspClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdGbmInspClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdGbmInspClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdGbmInspClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdGbmInspClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdGbmInspClsf Method")
	public int mergeTbmMdGbmInspClsf (final TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO) {
		
		if ( selectTbmMdGbmInspClsf (tbmMdGbmInspClsfDVO) == null) {
			return insertTbmMdGbmInspClsf(tbmMdGbmInspClsfDVO);
		} else {
			return selectUpdateTbmMdGbmInspClsf (tbmMdGbmInspClsfDVO);
		}
	}

	/**
	 * selectUpdateTbmMdGbmInspClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdGbmInspClsf Method")
	public int selectUpdateTbmMdGbmInspClsf (final TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO) {
		
		TbmMdGbmInspClsfDVO tmpTbmMdGbmInspClsfDVO =  selectTbmMdGbmInspClsf (tbmMdGbmInspClsfDVO);
		if ( tbmMdGbmInspClsfDVO.getGbmCode() != null && !"".equals(tbmMdGbmInspClsfDVO.getGbmCode()) ) {
			tmpTbmMdGbmInspClsfDVO.setGbmCode(tbmMdGbmInspClsfDVO.getGbmCode());
		}		
		if ( tbmMdGbmInspClsfDVO.getInspClsfCode() != null && !"".equals(tbmMdGbmInspClsfDVO.getInspClsfCode()) ) {
			tmpTbmMdGbmInspClsfDVO.setInspClsfCode(tbmMdGbmInspClsfDVO.getInspClsfCode());
		}		
		if ( tbmMdGbmInspClsfDVO.getIfDt() != null && !"".equals(tbmMdGbmInspClsfDVO.getIfDt()) ) {
			tmpTbmMdGbmInspClsfDVO.setIfDt(tbmMdGbmInspClsfDVO.getIfDt());
		}		
		if ( tbmMdGbmInspClsfDVO.getUseYn() != null && !"".equals(tbmMdGbmInspClsfDVO.getUseYn()) ) {
			tmpTbmMdGbmInspClsfDVO.setUseYn(tbmMdGbmInspClsfDVO.getUseYn());
		}		
		if ( tbmMdGbmInspClsfDVO.getFstRegDt() != null && !"".equals(tbmMdGbmInspClsfDVO.getFstRegDt()) ) {
			tmpTbmMdGbmInspClsfDVO.setFstRegDt(tbmMdGbmInspClsfDVO.getFstRegDt());
		}		
		if ( tbmMdGbmInspClsfDVO.getFstRegerId() != null && !"".equals(tbmMdGbmInspClsfDVO.getFstRegerId()) ) {
			tmpTbmMdGbmInspClsfDVO.setFstRegerId(tbmMdGbmInspClsfDVO.getFstRegerId());
		}		
		if ( tbmMdGbmInspClsfDVO.getFnlUpdDt() != null && !"".equals(tbmMdGbmInspClsfDVO.getFnlUpdDt()) ) {
			tmpTbmMdGbmInspClsfDVO.setFnlUpdDt(tbmMdGbmInspClsfDVO.getFnlUpdDt());
		}		
		if ( tbmMdGbmInspClsfDVO.getFnlUpderId() != null && !"".equals(tbmMdGbmInspClsfDVO.getFnlUpderId()) ) {
			tmpTbmMdGbmInspClsfDVO.setFnlUpderId(tbmMdGbmInspClsfDVO.getFnlUpderId());
		}		
		return updateTbmMdGbmInspClsf (tmpTbmMdGbmInspClsfDVO);
	}

/**
* insertBatchTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbmMdGbmInspClsf")
	public int[] insertBatchTbmMdGbmInspClsf (final List tbmMdGbmInspClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.insertBatchTbmMdGbmInspClsf.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_CLSF (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO = (TbmMdGbmInspClsfDVO)tbmMdGbmInspClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdGbmInspClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbmMdGbmInspClsf")
	public int[] updateBatchTbmMdGbmInspClsf (final List tbmMdGbmInspClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.updateBatchTbmMdGbmInspClsf.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND INSP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO = (TbmMdGbmInspClsfDVO)tbmMdGbmInspClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
						}
							public int getBatchSize() {
									return tbmMdGbmInspClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdGbmInspClsf Method
* 
* @ref_table TBM_MD_GBM_INSP_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbmMdGbmInspClsf")
	public int[] deleteBatchTbmMdGbmInspClsf (final List tbmMdGbmInspClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmInspClsfDEM.deleteBatchTbmMdGbmInspClsf.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_CLSF \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmInspClsfDVO tbmMdGbmInspClsfDVO = (TbmMdGbmInspClsfDVO)tbmMdGbmInspClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspClsfDVO.getInspClsfCode());
						}
							public int getBatchSize() {
									return tbmMdGbmInspClsfDVOList.size();
							}
					}
		);			
	}

	
}