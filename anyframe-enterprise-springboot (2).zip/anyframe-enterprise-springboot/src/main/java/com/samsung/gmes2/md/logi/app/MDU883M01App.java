package com.samsung.gmes2.md.logi.app;

public class MDU883M01App {

	/**
	 * 기본마스터정보 초기설정
	 */
	public void initSnNoMst(){}

	/**
	 * 기본마스터정보 조회
	 */
	public void listSnNoMst(){}

	/**
	 * 기본마스터정보 엑셀 다운로드
	 */
	public void excelSnNoMst(){}

	/**
	 * 기본마스터정보 저장
	 */
	public void saveSnNoMst(){}

}
