package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MATR_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMatrClsfDEM extends AbstractDAO {


/**
* insertTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return int
*/
	@LocalName("insertTbcMdMatrClsf")
	public int insertTbcMdMatrClsf (final TbcMdMatrClsfDVO tbcMdMatrClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.insertTbcMdMatrClsf.001*/  \n");
			sql.append(" TBC_MD_MATR_CLSF (   \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        MANM_DESC , \n");
			sql.append("        LAGE_CLSF_CODE , \n");
			sql.append("        LAGE_CLSF_NM , \n");
			sql.append("        MID_CLSF_CODE , \n");
			sql.append("        MID_CLSF_NM , \n");
			sql.append("        SMALL_CLSF_CODE , \n");
			sql.append("        SMALL_CLSF_NM , \n");
			sql.append("        MACAT_CODE , \n");
			sql.append("        MACAT_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmDesc());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdMatrClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdMatrClsf Method")
	public int[][] updateBatchAllTbcMdMatrClsf (final List  tbcMdMatrClsfDVOList) {
		
		ArrayList updatetbcMdMatrClsfDVOList = new ArrayList();
		ArrayList insertttbcMdMatrClsfDVOList = new ArrayList();
		ArrayList deletetbcMdMatrClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdMatrClsfDVOList.size() ; i++) {
		  TbcMdMatrClsfDVO tbcMdMatrClsfDVO = (TbcMdMatrClsfDVO) tbcMdMatrClsfDVOList.get(i);
		  
		  if (tbcMdMatrClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdMatrClsfDVOList.add(tbcMdMatrClsfDVO);
		  else if (tbcMdMatrClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdMatrClsfDVOList.add(tbcMdMatrClsfDVO);
		  else if (tbcMdMatrClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdMatrClsfDVOList.add(tbcMdMatrClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdMatrClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdMatrClsf(insertttbcMdMatrClsfDVOList);
          
      if (updatetbcMdMatrClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdMatrClsf(updatetbcMdMatrClsfDVOList);
      
      if (deletetbcMdMatrClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdMatrClsf(deletetbcMdMatrClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return int
*/
	@LocalName("updateTbcMdMatrClsf")
	public int updateTbcMdMatrClsf (final TbcMdMatrClsfDVO tbcMdMatrClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.updateTbcMdMatrClsf.001*/  \n");
			sql.append(" TBC_MD_MATR_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        MANM_DESC = ? , \n");
			sql.append("        LAGE_CLSF_CODE = ? , \n");
			sql.append("        LAGE_CLSF_NM = ? , \n");
			sql.append("        MID_CLSF_CODE = ? , \n");
			sql.append("        MID_CLSF_NM = ? , \n");
			sql.append("        SMALL_CLSF_CODE = ? , \n");
			sql.append("        SMALL_CLSF_NM = ? , \n");
			sql.append("        MACAT_CODE = ? , \n");
			sql.append("        MACAT_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MANM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmDesc());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
						}
					}
		);			
	}

/**
* deleteTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return int
*/
	@LocalName("deleteTbcMdMatrClsf")
	public int deleteTbcMdMatrClsf (final TbcMdMatrClsfDVO tbcMdMatrClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.deleteTbcMdMatrClsf.001*/  \n");
			sql.append(" TBC_MD_MATR_CLSF \n");
			sql.append("  WHERE MANM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
						}
					}
		);			
	}

/**
* selectTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return TbcMdMatrClsfDVO 
*/
	@LocalName("selectTbcMdMatrClsf")
	public TbcMdMatrClsfDVO selectTbcMdMatrClsf (final TbcMdMatrClsfDVO tbcMdMatrClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.selectTbcMdMatrClsf.001*/  \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        MANM_DESC , \n");
			sql.append("        LAGE_CLSF_CODE , \n");
			sql.append("        LAGE_CLSF_NM , \n");
			sql.append("        MID_CLSF_CODE , \n");
			sql.append("        MID_CLSF_NM , \n");
			sql.append("        SMALL_CLSF_CODE , \n");
			sql.append("        SMALL_CLSF_NM , \n");
			sql.append("        MACAT_CODE , \n");
			sql.append("        MACAT_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MATR_CLSF \n");
			sql.append("  WHERE MANM_CODE = ? \n");

		return (TbcMdMatrClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdMatrClsfDVO returnTbcMdMatrClsfDVO = new TbcMdMatrClsfDVO();
									returnTbcMdMatrClsfDVO.setManmCode(resultSet.getString("MANM_CODE"));
									returnTbcMdMatrClsfDVO.setManmDesc(resultSet.getString("MANM_DESC"));
									returnTbcMdMatrClsfDVO.setLageClsfCode(resultSet.getString("LAGE_CLSF_CODE"));
									returnTbcMdMatrClsfDVO.setLageClsfNm(resultSet.getString("LAGE_CLSF_NM"));
									returnTbcMdMatrClsfDVO.setMidClsfCode(resultSet.getString("MID_CLSF_CODE"));
									returnTbcMdMatrClsfDVO.setMidClsfNm(resultSet.getString("MID_CLSF_NM"));
									returnTbcMdMatrClsfDVO.setSmallClsfCode(resultSet.getString("SMALL_CLSF_CODE"));
									returnTbcMdMatrClsfDVO.setSmallClsfNm(resultSet.getString("SMALL_CLSF_NM"));
									returnTbcMdMatrClsfDVO.setMacatCode(resultSet.getString("MACAT_CODE"));
									returnTbcMdMatrClsfDVO.setMacatNm(resultSet.getString("MACAT_NM"));
									returnTbcMdMatrClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMatrClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMatrClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMatrClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMatrClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMatrClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdMatrClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdMatrClsf Method")
	public int mergeTbcMdMatrClsf (final TbcMdMatrClsfDVO tbcMdMatrClsfDVO) {
		
		if ( selectTbcMdMatrClsf (tbcMdMatrClsfDVO) == null) {
			return insertTbcMdMatrClsf(tbcMdMatrClsfDVO);
		} else {
			return selectUpdateTbcMdMatrClsf (tbcMdMatrClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdMatrClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdMatrClsf Method")
	public int selectUpdateTbcMdMatrClsf (final TbcMdMatrClsfDVO tbcMdMatrClsfDVO) {
		
		TbcMdMatrClsfDVO tmpTbcMdMatrClsfDVO =  selectTbcMdMatrClsf (tbcMdMatrClsfDVO);
		if ( tbcMdMatrClsfDVO.getManmCode() != null && !"".equals(tbcMdMatrClsfDVO.getManmCode()) ) {
			tmpTbcMdMatrClsfDVO.setManmCode(tbcMdMatrClsfDVO.getManmCode());
		}		
		if ( tbcMdMatrClsfDVO.getManmDesc() != null && !"".equals(tbcMdMatrClsfDVO.getManmDesc()) ) {
			tmpTbcMdMatrClsfDVO.setManmDesc(tbcMdMatrClsfDVO.getManmDesc());
		}		
		if ( tbcMdMatrClsfDVO.getLageClsfCode() != null && !"".equals(tbcMdMatrClsfDVO.getLageClsfCode()) ) {
			tmpTbcMdMatrClsfDVO.setLageClsfCode(tbcMdMatrClsfDVO.getLageClsfCode());
		}		
		if ( tbcMdMatrClsfDVO.getLageClsfNm() != null && !"".equals(tbcMdMatrClsfDVO.getLageClsfNm()) ) {
			tmpTbcMdMatrClsfDVO.setLageClsfNm(tbcMdMatrClsfDVO.getLageClsfNm());
		}		
		if ( tbcMdMatrClsfDVO.getMidClsfCode() != null && !"".equals(tbcMdMatrClsfDVO.getMidClsfCode()) ) {
			tmpTbcMdMatrClsfDVO.setMidClsfCode(tbcMdMatrClsfDVO.getMidClsfCode());
		}		
		if ( tbcMdMatrClsfDVO.getMidClsfNm() != null && !"".equals(tbcMdMatrClsfDVO.getMidClsfNm()) ) {
			tmpTbcMdMatrClsfDVO.setMidClsfNm(tbcMdMatrClsfDVO.getMidClsfNm());
		}		
		if ( tbcMdMatrClsfDVO.getSmallClsfCode() != null && !"".equals(tbcMdMatrClsfDVO.getSmallClsfCode()) ) {
			tmpTbcMdMatrClsfDVO.setSmallClsfCode(tbcMdMatrClsfDVO.getSmallClsfCode());
		}		
		if ( tbcMdMatrClsfDVO.getSmallClsfNm() != null && !"".equals(tbcMdMatrClsfDVO.getSmallClsfNm()) ) {
			tmpTbcMdMatrClsfDVO.setSmallClsfNm(tbcMdMatrClsfDVO.getSmallClsfNm());
		}		
		if ( tbcMdMatrClsfDVO.getMacatCode() != null && !"".equals(tbcMdMatrClsfDVO.getMacatCode()) ) {
			tmpTbcMdMatrClsfDVO.setMacatCode(tbcMdMatrClsfDVO.getMacatCode());
		}		
		if ( tbcMdMatrClsfDVO.getMacatNm() != null && !"".equals(tbcMdMatrClsfDVO.getMacatNm()) ) {
			tmpTbcMdMatrClsfDVO.setMacatNm(tbcMdMatrClsfDVO.getMacatNm());
		}		
		if ( tbcMdMatrClsfDVO.getUseYn() != null && !"".equals(tbcMdMatrClsfDVO.getUseYn()) ) {
			tmpTbcMdMatrClsfDVO.setUseYn(tbcMdMatrClsfDVO.getUseYn());
		}		
		if ( tbcMdMatrClsfDVO.getFstRegDt() != null && !"".equals(tbcMdMatrClsfDVO.getFstRegDt()) ) {
			tmpTbcMdMatrClsfDVO.setFstRegDt(tbcMdMatrClsfDVO.getFstRegDt());
		}		
		if ( tbcMdMatrClsfDVO.getFstRegerId() != null && !"".equals(tbcMdMatrClsfDVO.getFstRegerId()) ) {
			tmpTbcMdMatrClsfDVO.setFstRegerId(tbcMdMatrClsfDVO.getFstRegerId());
		}		
		if ( tbcMdMatrClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdMatrClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdMatrClsfDVO.setFnlUpdDt(tbcMdMatrClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdMatrClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdMatrClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdMatrClsfDVO.setFnlUpderId(tbcMdMatrClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdMatrClsf (tmpTbcMdMatrClsfDVO);
	}

/**
* insertBatchTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdMatrClsf")
	public int[] insertBatchTbcMdMatrClsf (final List tbcMdMatrClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.insertBatchTbcMdMatrClsf.001*/  \n");
			sql.append(" TBC_MD_MATR_CLSF (   \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        MANM_DESC , \n");
			sql.append("        LAGE_CLSF_CODE , \n");
			sql.append("        LAGE_CLSF_NM , \n");
			sql.append("        MID_CLSF_CODE , \n");
			sql.append("        MID_CLSF_NM , \n");
			sql.append("        SMALL_CLSF_CODE , \n");
			sql.append("        SMALL_CLSF_NM , \n");
			sql.append("        MACAT_CODE , \n");
			sql.append("        MACAT_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMatrClsfDVO tbcMdMatrClsfDVO = (TbcMdMatrClsfDVO)tbcMdMatrClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmDesc());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdMatrClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdMatrClsf")
	public int[] updateBatchTbcMdMatrClsf (final List tbcMdMatrClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.updateBatchTbcMdMatrClsf.001*/  \n");
			sql.append(" TBC_MD_MATR_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        MANM_DESC = ? , \n");
			sql.append("        LAGE_CLSF_CODE = ? , \n");
			sql.append("        LAGE_CLSF_NM = ? , \n");
			sql.append("        MID_CLSF_CODE = ? , \n");
			sql.append("        MID_CLSF_NM = ? , \n");
			sql.append("        SMALL_CLSF_CODE = ? , \n");
			sql.append("        SMALL_CLSF_NM = ? , \n");
			sql.append("        MACAT_CODE = ? , \n");
			sql.append("        MACAT_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MANM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMatrClsfDVO tbcMdMatrClsfDVO = (TbcMdMatrClsfDVO)tbcMdMatrClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmDesc());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getLageClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMidClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getSmallClsfNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatCode());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getMacatNm());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMatrClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
						}
							public int getBatchSize() {
									return tbcMdMatrClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdMatrClsf Method
* 
* @ref_table TBC_MD_MATR_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdMatrClsf")
	public int[] deleteBatchTbcMdMatrClsf (final List tbcMdMatrClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMatrClsfDEM.deleteBatchTbcMdMatrClsf.001*/  \n");
			sql.append(" TBC_MD_MATR_CLSF \n");
			sql.append("  WHERE MANM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMatrClsfDVO tbcMdMatrClsfDVO = (TbcMdMatrClsfDVO)tbcMdMatrClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdMatrClsfDVO.getManmCode());
						}
							public int getBatchSize() {
									return tbcMdMatrClsfDVOList.size();
							}
					}
		);			
	}

	
}