package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PROD
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdProdDEM extends AbstractDAO {


/**
* insertTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return int
*/
	@LocalName("insertTbcMdProd")
	public int insertTbcMdProd (final TbcMdProdDVO tbcMdProdDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProdDEM.insertTbcMdProd.001*/  \n");
			sql.append(" TBC_MD_PROD (   \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PROD_NM , \n");
			sql.append("        CLS_TYPE_NM , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        PBA_DEFT_SUMR_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
							ps.setString(psCount++, tbcMdProdDVO.getProdAbbrCode());
							ps.setString(psCount++, tbcMdProdDVO.getProdNm());
							ps.setString(psCount++, tbcMdProdDVO.getClsTypeNm());
							ps.setString(psCount++, tbcMdProdDVO.getTtCalcYn());
							ps.setString(psCount++, tbcMdProdDVO.getPbaDeftSumrYn());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdProd Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdProd Method")
	public int[][] updateBatchAllTbcMdProd (final List  tbcMdProdDVOList) {
		
		ArrayList updatetbcMdProdDVOList = new ArrayList();
		ArrayList insertttbcMdProdDVOList = new ArrayList();
		ArrayList deletetbcMdProdDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdProdDVOList.size() ; i++) {
		  TbcMdProdDVO tbcMdProdDVO = (TbcMdProdDVO) tbcMdProdDVOList.get(i);
		  
		  if (tbcMdProdDVO.getSqlAction().equals("C"))
		      insertttbcMdProdDVOList.add(tbcMdProdDVO);
		  else if (tbcMdProdDVO.getSqlAction().equals("U"))
		      updatetbcMdProdDVOList.add(tbcMdProdDVO);
		  else if (tbcMdProdDVO.getSqlAction().equals("D"))
		      deletetbcMdProdDVOList.add(tbcMdProdDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdProdDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdProd(insertttbcMdProdDVOList);
          
      if (updatetbcMdProdDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdProd(updatetbcMdProdDVOList);
      
      if (deletetbcMdProdDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdProd(deletetbcMdProdDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return int
*/
	@LocalName("updateTbcMdProd")
	public int updateTbcMdProd (final TbcMdProdDVO tbcMdProdDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProdDEM.updateTbcMdProd.001*/  \n");
			sql.append(" TBC_MD_PROD \n");
			sql.append(" SET   \n");
			sql.append("        PROD_ABBR_CODE = ? , \n");
			sql.append("        PROD_NM = ? , \n");
			sql.append("        CLS_TYPE_NM = ? , \n");
			sql.append("        TT_CALC_YN = ? , \n");
			sql.append("        PBA_DEFT_SUMR_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdDVO.getProdAbbrCode());
							ps.setString(psCount++, tbcMdProdDVO.getProdNm());
							ps.setString(psCount++, tbcMdProdDVO.getClsTypeNm());
							ps.setString(psCount++, tbcMdProdDVO.getTtCalcYn());
							ps.setString(psCount++, tbcMdProdDVO.getPbaDeftSumrYn());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
						}
					}
		);			
	}

/**
* deleteTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return int
*/
	@LocalName("deleteTbcMdProd")
	public int deleteTbcMdProd (final TbcMdProdDVO tbcMdProdDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProdDEM.deleteTbcMdProd.001*/  \n");
			sql.append(" TBC_MD_PROD \n");
			sql.append("  WHERE PROD_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
						}
					}
		);			
	}

/**
* selectTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return TbcMdProdDVO 
*/
	@LocalName("selectTbcMdProd")
	public TbcMdProdDVO selectTbcMdProd (final TbcMdProdDVO tbcMdProdDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdProdDEM.selectTbcMdProd.001*/  \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PROD_NM , \n");
			sql.append("        CLS_TYPE_NM , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        PBA_DEFT_SUMR_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PROD \n");
			sql.append("  WHERE PROD_CODE = ? \n");

		return (TbcMdProdDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdProdDVO returnTbcMdProdDVO = new TbcMdProdDVO();
									returnTbcMdProdDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbcMdProdDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbcMdProdDVO.setProdNm(resultSet.getString("PROD_NM"));
									returnTbcMdProdDVO.setClsTypeNm(resultSet.getString("CLS_TYPE_NM"));
									returnTbcMdProdDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbcMdProdDVO.setPbaDeftSumrYn(resultSet.getString("PBA_DEFT_SUMR_YN"));
									returnTbcMdProdDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdProd Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdProd Method")
	public int mergeTbcMdProd (final TbcMdProdDVO tbcMdProdDVO) {
		
		if ( selectTbcMdProd (tbcMdProdDVO) == null) {
			return insertTbcMdProd(tbcMdProdDVO);
		} else {
			return selectUpdateTbcMdProd (tbcMdProdDVO);
		}
	}

	/**
	 * selectUpdateTbcMdProd Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdProd Method")
	public int selectUpdateTbcMdProd (final TbcMdProdDVO tbcMdProdDVO) {
		
		TbcMdProdDVO tmpTbcMdProdDVO =  selectTbcMdProd (tbcMdProdDVO);
		if ( tbcMdProdDVO.getProdCode() != null && !"".equals(tbcMdProdDVO.getProdCode()) ) {
			tmpTbcMdProdDVO.setProdCode(tbcMdProdDVO.getProdCode());
		}		
		if ( tbcMdProdDVO.getProdAbbrCode() != null && !"".equals(tbcMdProdDVO.getProdAbbrCode()) ) {
			tmpTbcMdProdDVO.setProdAbbrCode(tbcMdProdDVO.getProdAbbrCode());
		}		
		if ( tbcMdProdDVO.getProdNm() != null && !"".equals(tbcMdProdDVO.getProdNm()) ) {
			tmpTbcMdProdDVO.setProdNm(tbcMdProdDVO.getProdNm());
		}		
		if ( tbcMdProdDVO.getClsTypeNm() != null && !"".equals(tbcMdProdDVO.getClsTypeNm()) ) {
			tmpTbcMdProdDVO.setClsTypeNm(tbcMdProdDVO.getClsTypeNm());
		}		
		if ( tbcMdProdDVO.getTtCalcYn() != null && !"".equals(tbcMdProdDVO.getTtCalcYn()) ) {
			tmpTbcMdProdDVO.setTtCalcYn(tbcMdProdDVO.getTtCalcYn());
		}		
		if ( tbcMdProdDVO.getPbaDeftSumrYn() != null && !"".equals(tbcMdProdDVO.getPbaDeftSumrYn()) ) {
			tmpTbcMdProdDVO.setPbaDeftSumrYn(tbcMdProdDVO.getPbaDeftSumrYn());
		}		
		if ( tbcMdProdDVO.getFstRegDt() != null && !"".equals(tbcMdProdDVO.getFstRegDt()) ) {
			tmpTbcMdProdDVO.setFstRegDt(tbcMdProdDVO.getFstRegDt());
		}		
		if ( tbcMdProdDVO.getFstRegerId() != null && !"".equals(tbcMdProdDVO.getFstRegerId()) ) {
			tmpTbcMdProdDVO.setFstRegerId(tbcMdProdDVO.getFstRegerId());
		}		
		if ( tbcMdProdDVO.getFnlUpdDt() != null && !"".equals(tbcMdProdDVO.getFnlUpdDt()) ) {
			tmpTbcMdProdDVO.setFnlUpdDt(tbcMdProdDVO.getFnlUpdDt());
		}		
		if ( tbcMdProdDVO.getFnlUpderId() != null && !"".equals(tbcMdProdDVO.getFnlUpderId()) ) {
			tmpTbcMdProdDVO.setFnlUpderId(tbcMdProdDVO.getFnlUpderId());
		}		
		return updateTbcMdProd (tmpTbcMdProdDVO);
	}

/**
* insertBatchTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return int[]
*/
	@LocalName("insertBatchTbcMdProd")
	public int[] insertBatchTbcMdProd (final List tbcMdProdDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProdDEM.insertBatchTbcMdProd.001*/  \n");
			sql.append(" TBC_MD_PROD (   \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PROD_NM , \n");
			sql.append("        CLS_TYPE_NM , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        PBA_DEFT_SUMR_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdDVO tbcMdProdDVO = (TbcMdProdDVO)tbcMdProdDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
							ps.setString(psCount++, tbcMdProdDVO.getProdAbbrCode());
							ps.setString(psCount++, tbcMdProdDVO.getProdNm());
							ps.setString(psCount++, tbcMdProdDVO.getClsTypeNm());
							ps.setString(psCount++, tbcMdProdDVO.getTtCalcYn());
							ps.setString(psCount++, tbcMdProdDVO.getPbaDeftSumrYn());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdProdDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return int[]
*/
	@LocalName("updateBatchTbcMdProd")
	public int[] updateBatchTbcMdProd (final List tbcMdProdDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProdDEM.updateBatchTbcMdProd.001*/  \n");
			sql.append(" TBC_MD_PROD \n");
			sql.append(" SET   \n");
			sql.append("        PROD_ABBR_CODE = ? , \n");
			sql.append("        PROD_NM = ? , \n");
			sql.append("        CLS_TYPE_NM = ? , \n");
			sql.append("        TT_CALC_YN = ? , \n");
			sql.append("        PBA_DEFT_SUMR_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdDVO tbcMdProdDVO = (TbcMdProdDVO)tbcMdProdDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdDVO.getProdAbbrCode());
							ps.setString(psCount++, tbcMdProdDVO.getProdNm());
							ps.setString(psCount++, tbcMdProdDVO.getClsTypeNm());
							ps.setString(psCount++, tbcMdProdDVO.getTtCalcYn());
							ps.setString(psCount++, tbcMdProdDVO.getPbaDeftSumrYn());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
						}
							public int getBatchSize() {
									return tbcMdProdDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdProd Method
* 
* @ref_table TBC_MD_PROD
* @return int[]
*/
	@LocalName("deleteBatchTbcMdProd")
	public int[] deleteBatchTbcMdProd (final List tbcMdProdDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProdDEM.deleteBatchTbcMdProd.001*/  \n");
			sql.append(" TBC_MD_PROD \n");
			sql.append("  WHERE PROD_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdDVO tbcMdProdDVO = (TbcMdProdDVO)tbcMdProdDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdDVO.getProdCode());
						}
							public int getBatchSize() {
									return tbcMdProdDVOList.size();
							}
					}
		);			
	}

	
}