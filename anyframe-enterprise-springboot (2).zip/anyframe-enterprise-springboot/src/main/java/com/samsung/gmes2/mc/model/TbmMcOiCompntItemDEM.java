package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcOiCompntItemDEM extends AbstractDAO {


/**
* insertTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return int
*/
	@LocalName("insertTbmMcOiCompntItem")
	public int insertTbmMcOiCompntItem (final TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.insertTbmMcOiCompntItem.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT_ITEM (   \n");
			sql.append("        ITEM_REV_NO , \n");
			sql.append("        FRM_NO , \n");
			sql.append("        PGM_REV_NO , \n");
			sql.append("        COMPNT_REV_NO , \n");
			sql.append("        ITEM_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        LABEL_CONT , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        ITEM_LENG , \n");
			sql.append("        ITEM_HEIT , \n");
			sql.append("        FONT_NM , \n");
			sql.append("        FONT_VALUE , \n");
			sql.append("        FRCLOR_VALUE , \n");
			sql.append("        BCKCLOR_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getBckclorValue());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcOiCompntItem Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcOiCompntItem Method")
	public int[][] updateBatchAllTbmMcOiCompntItem (final List  tbmMcOiCompntItemDVOList) {
		
		ArrayList updatetbmMcOiCompntItemDVOList = new ArrayList();
		ArrayList insertttbmMcOiCompntItemDVOList = new ArrayList();
		ArrayList deletetbmMcOiCompntItemDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcOiCompntItemDVOList.size() ; i++) {
		  TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO = (TbmMcOiCompntItemDVO) tbmMcOiCompntItemDVOList.get(i);
		  
		  if (tbmMcOiCompntItemDVO.getSqlAction().equals("C"))
		      insertttbmMcOiCompntItemDVOList.add(tbmMcOiCompntItemDVO);
		  else if (tbmMcOiCompntItemDVO.getSqlAction().equals("U"))
		      updatetbmMcOiCompntItemDVOList.add(tbmMcOiCompntItemDVO);
		  else if (tbmMcOiCompntItemDVO.getSqlAction().equals("D"))
		      deletetbmMcOiCompntItemDVOList.add(tbmMcOiCompntItemDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcOiCompntItemDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcOiCompntItem(insertttbmMcOiCompntItemDVOList);
          
      if (updatetbmMcOiCompntItemDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcOiCompntItem(updatetbmMcOiCompntItemDVOList);
      
      if (deletetbmMcOiCompntItemDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcOiCompntItem(deletetbmMcOiCompntItemDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return int
*/
	@LocalName("updateTbmMcOiCompntItem")
	public int updateTbmMcOiCompntItem (final TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.updateTbmMcOiCompntItem.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT_ITEM \n");
			sql.append(" SET   \n");
			sql.append("        LABEL_CONT = ? , \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        ITEM_LENG = ? , \n");
			sql.append("        ITEM_HEIT = ? , \n");
			sql.append("        FONT_NM = ? , \n");
			sql.append("        FONT_VALUE = ? , \n");
			sql.append("        FRCLOR_VALUE = ? , \n");
			sql.append("        BCKCLOR_VALUE = ? \n");
			sql.append(" WHERE ITEM_REV_NO = ? \n");
			sql.append("   AND FRM_NO = ? \n");
			sql.append("   AND PGM_REV_NO = ? \n");
			sql.append("   AND COMPNT_REV_NO = ? \n");
			sql.append("   AND ITEM_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcOiCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getBckclorValue());

							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
						}
					}
		);			
	}

/**
* deleteTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return int
*/
	@LocalName("deleteTbmMcOiCompntItem")
	public int deleteTbmMcOiCompntItem (final TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.deleteTbmMcOiCompntItem.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT_ITEM \n");
			sql.append("  WHERE ITEM_REV_NO = ? \n");
			sql.append("    AND FRM_NO = ? \n");
			sql.append("    AND PGM_REV_NO = ? \n");
			sql.append("    AND COMPNT_REV_NO = ? \n");
			sql.append("    AND ITEM_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
						}
					}
		);			
	}

/**
* selectTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return TbmMcOiCompntItemDVO 
*/
	@LocalName("selectTbmMcOiCompntItem")
	public TbmMcOiCompntItemDVO selectTbmMcOiCompntItem (final TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.selectTbmMcOiCompntItem.001*/  \n");
			sql.append("        ITEM_REV_NO , \n");
			sql.append("        FRM_NO , \n");
			sql.append("        PGM_REV_NO , \n");
			sql.append("        COMPNT_REV_NO , \n");
			sql.append("        ITEM_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        LABEL_CONT , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        ITEM_LENG , \n");
			sql.append("        ITEM_HEIT , \n");
			sql.append("        FONT_NM , \n");
			sql.append("        FONT_VALUE , \n");
			sql.append("        FRCLOR_VALUE , \n");
			sql.append("        BCKCLOR_VALUE \n");
			sql.append("   FROM TBM_MC_OI_COMPNT_ITEM \n");
			sql.append("  WHERE ITEM_REV_NO = ? \n");
			sql.append("    AND FRM_NO = ? \n");
			sql.append("    AND PGM_REV_NO = ? \n");
			sql.append("    AND COMPNT_REV_NO = ? \n");
			sql.append("    AND ITEM_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return (TbmMcOiCompntItemDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcOiCompntItemDVO returnTbmMcOiCompntItemDVO = new TbmMcOiCompntItemDVO();
									returnTbmMcOiCompntItemDVO.setItemRevNo(resultSet.getString("ITEM_REV_NO"));
									returnTbmMcOiCompntItemDVO.setFrmNo(resultSet.getString("FRM_NO"));
									returnTbmMcOiCompntItemDVO.setPgmRevNo(resultSet.getString("PGM_REV_NO"));
									returnTbmMcOiCompntItemDVO.setCompntRevNo(resultSet.getString("COMPNT_REV_NO"));
									returnTbmMcOiCompntItemDVO.setItemNo(resultSet.getString("ITEM_NO"));
									returnTbmMcOiCompntItemDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbmMcOiCompntItemDVO.setStandCompntCode(resultSet.getString("STAND_COMPNT_CODE"));
									returnTbmMcOiCompntItemDVO.setLabelCont(resultSet.getString("LABEL_CONT"));
									returnTbmMcOiCompntItemDVO.setxValue(resultSet.getBigDecimal("X_VALUE"));
									returnTbmMcOiCompntItemDVO.setyValue(resultSet.getBigDecimal("Y_VALUE"));
									returnTbmMcOiCompntItemDVO.setItemLeng(resultSet.getBigDecimal("ITEM_LENG"));
									returnTbmMcOiCompntItemDVO.setItemHeit(resultSet.getBigDecimal("ITEM_HEIT"));
									returnTbmMcOiCompntItemDVO.setFontNm(resultSet.getString("FONT_NM"));
									returnTbmMcOiCompntItemDVO.setFontValue(resultSet.getBigDecimal("FONT_VALUE"));
									returnTbmMcOiCompntItemDVO.setFrclorValue(resultSet.getBigDecimal("FRCLOR_VALUE"));
									returnTbmMcOiCompntItemDVO.setBckclorValue(resultSet.getBigDecimal("BCKCLOR_VALUE"));
									return returnTbmMcOiCompntItemDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcOiCompntItem Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcOiCompntItem Method")
	public int mergeTbmMcOiCompntItem (final TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO) {
		
		if ( selectTbmMcOiCompntItem (tbmMcOiCompntItemDVO) == null) {
			return insertTbmMcOiCompntItem(tbmMcOiCompntItemDVO);
		} else {
			return selectUpdateTbmMcOiCompntItem (tbmMcOiCompntItemDVO);
		}
	}

	/**
	 * selectUpdateTbmMcOiCompntItem Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcOiCompntItem Method")
	public int selectUpdateTbmMcOiCompntItem (final TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO) {
		
		TbmMcOiCompntItemDVO tmpTbmMcOiCompntItemDVO =  selectTbmMcOiCompntItem (tbmMcOiCompntItemDVO);
		if ( tbmMcOiCompntItemDVO.getItemRevNo() != null && !"".equals(tbmMcOiCompntItemDVO.getItemRevNo()) ) {
			tmpTbmMcOiCompntItemDVO.setItemRevNo(tbmMcOiCompntItemDVO.getItemRevNo());
		}		
		if ( tbmMcOiCompntItemDVO.getFrmNo() != null && !"".equals(tbmMcOiCompntItemDVO.getFrmNo()) ) {
			tmpTbmMcOiCompntItemDVO.setFrmNo(tbmMcOiCompntItemDVO.getFrmNo());
		}		
		if ( tbmMcOiCompntItemDVO.getPgmRevNo() != null && !"".equals(tbmMcOiCompntItemDVO.getPgmRevNo()) ) {
			tmpTbmMcOiCompntItemDVO.setPgmRevNo(tbmMcOiCompntItemDVO.getPgmRevNo());
		}		
		if ( tbmMcOiCompntItemDVO.getCompntRevNo() != null && !"".equals(tbmMcOiCompntItemDVO.getCompntRevNo()) ) {
			tmpTbmMcOiCompntItemDVO.setCompntRevNo(tbmMcOiCompntItemDVO.getCompntRevNo());
		}		
		if ( tbmMcOiCompntItemDVO.getItemNo() != null && !"".equals(tbmMcOiCompntItemDVO.getItemNo()) ) {
			tmpTbmMcOiCompntItemDVO.setItemNo(tbmMcOiCompntItemDVO.getItemNo());
		}		
		if ( tbmMcOiCompntItemDVO.getPgmCode() != null && !"".equals(tbmMcOiCompntItemDVO.getPgmCode()) ) {
			tmpTbmMcOiCompntItemDVO.setPgmCode(tbmMcOiCompntItemDVO.getPgmCode());
		}		
		if ( tbmMcOiCompntItemDVO.getStandCompntCode() != null && !"".equals(tbmMcOiCompntItemDVO.getStandCompntCode()) ) {
			tmpTbmMcOiCompntItemDVO.setStandCompntCode(tbmMcOiCompntItemDVO.getStandCompntCode());
		}		
		if ( tbmMcOiCompntItemDVO.getLabelCont() != null && !"".equals(tbmMcOiCompntItemDVO.getLabelCont()) ) {
			tmpTbmMcOiCompntItemDVO.setLabelCont(tbmMcOiCompntItemDVO.getLabelCont());
		}		
		if ( tbmMcOiCompntItemDVO.getxValue() != null && !"".equals(tbmMcOiCompntItemDVO.getxValue()) ) {
			tmpTbmMcOiCompntItemDVO.setxValue(tbmMcOiCompntItemDVO.getxValue());
		}		
		if ( tbmMcOiCompntItemDVO.getyValue() != null && !"".equals(tbmMcOiCompntItemDVO.getyValue()) ) {
			tmpTbmMcOiCompntItemDVO.setyValue(tbmMcOiCompntItemDVO.getyValue());
		}		
		if ( tbmMcOiCompntItemDVO.getItemLeng() != null && !"".equals(tbmMcOiCompntItemDVO.getItemLeng()) ) {
			tmpTbmMcOiCompntItemDVO.setItemLeng(tbmMcOiCompntItemDVO.getItemLeng());
		}		
		if ( tbmMcOiCompntItemDVO.getItemHeit() != null && !"".equals(tbmMcOiCompntItemDVO.getItemHeit()) ) {
			tmpTbmMcOiCompntItemDVO.setItemHeit(tbmMcOiCompntItemDVO.getItemHeit());
		}		
		if ( tbmMcOiCompntItemDVO.getFontNm() != null && !"".equals(tbmMcOiCompntItemDVO.getFontNm()) ) {
			tmpTbmMcOiCompntItemDVO.setFontNm(tbmMcOiCompntItemDVO.getFontNm());
		}		
		if ( tbmMcOiCompntItemDVO.getFontValue() != null && !"".equals(tbmMcOiCompntItemDVO.getFontValue()) ) {
			tmpTbmMcOiCompntItemDVO.setFontValue(tbmMcOiCompntItemDVO.getFontValue());
		}		
		if ( tbmMcOiCompntItemDVO.getFrclorValue() != null && !"".equals(tbmMcOiCompntItemDVO.getFrclorValue()) ) {
			tmpTbmMcOiCompntItemDVO.setFrclorValue(tbmMcOiCompntItemDVO.getFrclorValue());
		}		
		if ( tbmMcOiCompntItemDVO.getBckclorValue() != null && !"".equals(tbmMcOiCompntItemDVO.getBckclorValue()) ) {
			tmpTbmMcOiCompntItemDVO.setBckclorValue(tbmMcOiCompntItemDVO.getBckclorValue());
		}		
		return updateTbmMcOiCompntItem (tmpTbmMcOiCompntItemDVO);
	}

/**
* insertBatchTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return int[]
*/
	@LocalName("insertBatchTbmMcOiCompntItem")
	public int[] insertBatchTbmMcOiCompntItem (final List tbmMcOiCompntItemDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.insertBatchTbmMcOiCompntItem.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT_ITEM (   \n");
			sql.append("        ITEM_REV_NO , \n");
			sql.append("        FRM_NO , \n");
			sql.append("        PGM_REV_NO , \n");
			sql.append("        COMPNT_REV_NO , \n");
			sql.append("        ITEM_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        LABEL_CONT , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        ITEM_LENG , \n");
			sql.append("        ITEM_HEIT , \n");
			sql.append("        FONT_NM , \n");
			sql.append("        FONT_VALUE , \n");
			sql.append("        FRCLOR_VALUE , \n");
			sql.append("        BCKCLOR_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO = (TbmMcOiCompntItemDVO)tbmMcOiCompntItemDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getBckclorValue());

						}
							public int getBatchSize() {
									return tbmMcOiCompntItemDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return int[]
*/
	@LocalName("updateBatchTbmMcOiCompntItem")
	public int[] updateBatchTbmMcOiCompntItem (final List tbmMcOiCompntItemDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.updateBatchTbmMcOiCompntItem.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT_ITEM \n");
			sql.append(" SET   \n");
			sql.append("        LABEL_CONT = ? , \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        ITEM_LENG = ? , \n");
			sql.append("        ITEM_HEIT = ? , \n");
			sql.append("        FONT_NM = ? , \n");
			sql.append("        FONT_VALUE = ? , \n");
			sql.append("        FRCLOR_VALUE = ? , \n");
			sql.append("        BCKCLOR_VALUE = ? \n");
			sql.append(" WHERE ITEM_REV_NO = ? \n");
			sql.append("   AND FRM_NO = ? \n");
			sql.append("   AND PGM_REV_NO = ? \n");
			sql.append("   AND COMPNT_REV_NO = ? \n");
			sql.append("   AND ITEM_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO = (TbmMcOiCompntItemDVO)tbmMcOiCompntItemDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcOiCompntItemDVO.getLabelCont());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemLeng());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getItemHeit());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFontNm());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFontValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getFrclorValue());
							ps.setBigDecimal(psCount++, tbmMcOiCompntItemDVO.getBckclorValue());

							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
						}
							public int getBatchSize() {
									return tbmMcOiCompntItemDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcOiCompntItem Method
* 
* @ref_table TBM_MC_OI_COMPNT_ITEM
* @return int[]
*/
	@LocalName("deleteBatchTbmMcOiCompntItem")
	public int[] deleteBatchTbmMcOiCompntItem (final List tbmMcOiCompntItemDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcOiCompntItemDEM.deleteBatchTbmMcOiCompntItem.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT_ITEM \n");
			sql.append("  WHERE ITEM_REV_NO = ? \n");
			sql.append("    AND FRM_NO = ? \n");
			sql.append("    AND PGM_REV_NO = ? \n");
			sql.append("    AND COMPNT_REV_NO = ? \n");
			sql.append("    AND ITEM_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcOiCompntItemDVO tbmMcOiCompntItemDVO = (TbmMcOiCompntItemDVO)tbmMcOiCompntItemDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getItemNo());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntItemDVO.getStandCompntCode());
						}
							public int getBatchSize() {
									return tbmMcOiCompntItemDVOList.size();
							}
					}
		);			
	}

	
}