package com.samsung.gmes2.base.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 클래스 설명.
 * @stereotype DAOVO
 * @author myjung
 */
@LocalName("xxx 클래스")
public class StringDVO extends AbstractDVO {

	
	private String value;


	public String getValue() {
		this.value = super.getValue("value");
		return this.value;
	}

	public void setValue(String value) {
        super.setValue("value", value);
		this.value = value;
	}
	
}