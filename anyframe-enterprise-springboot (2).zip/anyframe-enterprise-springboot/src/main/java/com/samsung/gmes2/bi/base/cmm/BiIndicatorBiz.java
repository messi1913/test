/**
 * <PRE>
 * System Name : G-MES 2.0
 * Business Name : 지표 조회 Biz
 * Class Name : BiIndicatorBiz.java
 * Description : KPI 및 현황 세부 내역 조회 - mBI 조회 공통
 * Modification History
 * 			수정일			수정자          			수정내용
 * 		-------------     ---------    ---------------------------
 * 		2011.07.13			이은미          			최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.bi.base.cmm;

public class BiIndicatorBiz {

	/**
	 * @name_ko 지표 조회
	 */
	public void getIndicator() {
	}

	/** 
	 * @name_ko 지표 상세 조회
	 */
	public void listIndicator() {
	}

	/**
	 * @name_ko 조회쿼리 생성
	 */
	public void createMethod() {
	}

}