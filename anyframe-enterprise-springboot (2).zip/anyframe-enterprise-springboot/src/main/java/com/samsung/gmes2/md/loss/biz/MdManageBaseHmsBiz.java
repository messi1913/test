package com.samsung.gmes2.md.loss.biz;

public class MdManageBaseHmsBiz {

	/**
	 * 기준시간 목록 조회
	 */
	public void listBaseHmsInfo(){}

	/**
	 * 기준시간 목록 저장
	 */
	public void saveBaseHmsInfo(){}

}
