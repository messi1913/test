package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_GBM_MANM
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdGbmManmDEM extends AbstractDAO {


/**
* insertTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return int
*/
	@LocalName("insertTbmMdGbmManm")
	public int insertTbmMdGbmManm (final TbmMdGbmManmDVO tbmMdGbmManmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.insertTbmMdGbmManm.001*/  \n");
			sql.append(" TBM_MD_GBM_MANM (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdGbmManm Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdGbmManm Method")
	public int[][] updateBatchAllTbmMdGbmManm (final List  tbmMdGbmManmDVOList) {
		
		ArrayList updatetbmMdGbmManmDVOList = new ArrayList();
		ArrayList insertttbmMdGbmManmDVOList = new ArrayList();
		ArrayList deletetbmMdGbmManmDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdGbmManmDVOList.size() ; i++) {
		  TbmMdGbmManmDVO tbmMdGbmManmDVO = (TbmMdGbmManmDVO) tbmMdGbmManmDVOList.get(i);
		  
		  if (tbmMdGbmManmDVO.getSqlAction().equals("C"))
		      insertttbmMdGbmManmDVOList.add(tbmMdGbmManmDVO);
		  else if (tbmMdGbmManmDVO.getSqlAction().equals("U"))
		      updatetbmMdGbmManmDVOList.add(tbmMdGbmManmDVO);
		  else if (tbmMdGbmManmDVO.getSqlAction().equals("D"))
		      deletetbmMdGbmManmDVOList.add(tbmMdGbmManmDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdGbmManmDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdGbmManm(insertttbmMdGbmManmDVOList);
          
      if (updatetbmMdGbmManmDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdGbmManm(updatetbmMdGbmManmDVOList);
      
      if (deletetbmMdGbmManmDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdGbmManm(deletetbmMdGbmManmDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return int
*/
	@LocalName("updateTbmMdGbmManm")
	public int updateTbmMdGbmManm (final TbmMdGbmManmDVO tbmMdGbmManmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.updateTbmMdGbmManm.001*/  \n");
			sql.append(" TBM_MD_GBM_MANM \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND MANM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmManmDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
						}
					}
		);			
	}

/**
* deleteTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return int
*/
	@LocalName("deleteTbmMdGbmManm")
	public int deleteTbmMdGbmManm (final TbmMdGbmManmDVO tbmMdGbmManmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.deleteTbmMdGbmManm.001*/  \n");
			sql.append(" TBM_MD_GBM_MANM \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND MANM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
						}
					}
		);			
	}

/**
* selectTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return TbmMdGbmManmDVO 
*/
	@LocalName("selectTbmMdGbmManm")
	public TbmMdGbmManmDVO selectTbmMdGbmManm (final TbmMdGbmManmDVO tbmMdGbmManmDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.selectTbmMdGbmManm.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_GBM_MANM \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND MANM_CODE = ? \n");

		return (TbmMdGbmManmDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdGbmManmDVO returnTbmMdGbmManmDVO = new TbmMdGbmManmDVO();
									returnTbmMdGbmManmDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdGbmManmDVO.setManmCode(resultSet.getString("MANM_CODE"));
									returnTbmMdGbmManmDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdGbmManmDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdGbmManmDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdGbmManmDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdGbmManmDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdGbmManmDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdGbmManmDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdGbmManm Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdGbmManm Method")
	public int mergeTbmMdGbmManm (final TbmMdGbmManmDVO tbmMdGbmManmDVO) {
		
		if ( selectTbmMdGbmManm (tbmMdGbmManmDVO) == null) {
			return insertTbmMdGbmManm(tbmMdGbmManmDVO);
		} else {
			return selectUpdateTbmMdGbmManm (tbmMdGbmManmDVO);
		}
	}

	/**
	 * selectUpdateTbmMdGbmManm Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdGbmManm Method")
	public int selectUpdateTbmMdGbmManm (final TbmMdGbmManmDVO tbmMdGbmManmDVO) {
		
		TbmMdGbmManmDVO tmpTbmMdGbmManmDVO =  selectTbmMdGbmManm (tbmMdGbmManmDVO);
		if ( tbmMdGbmManmDVO.getGbmCode() != null && !"".equals(tbmMdGbmManmDVO.getGbmCode()) ) {
			tmpTbmMdGbmManmDVO.setGbmCode(tbmMdGbmManmDVO.getGbmCode());
		}		
		if ( tbmMdGbmManmDVO.getManmCode() != null && !"".equals(tbmMdGbmManmDVO.getManmCode()) ) {
			tmpTbmMdGbmManmDVO.setManmCode(tbmMdGbmManmDVO.getManmCode());
		}		
		if ( tbmMdGbmManmDVO.getProcGubunCode() != null && !"".equals(tbmMdGbmManmDVO.getProcGubunCode()) ) {
			tmpTbmMdGbmManmDVO.setProcGubunCode(tbmMdGbmManmDVO.getProcGubunCode());
		}		
		if ( tbmMdGbmManmDVO.getUseYn() != null && !"".equals(tbmMdGbmManmDVO.getUseYn()) ) {
			tmpTbmMdGbmManmDVO.setUseYn(tbmMdGbmManmDVO.getUseYn());
		}		
		if ( tbmMdGbmManmDVO.getFstRegDt() != null && !"".equals(tbmMdGbmManmDVO.getFstRegDt()) ) {
			tmpTbmMdGbmManmDVO.setFstRegDt(tbmMdGbmManmDVO.getFstRegDt());
		}		
		if ( tbmMdGbmManmDVO.getFstRegerId() != null && !"".equals(tbmMdGbmManmDVO.getFstRegerId()) ) {
			tmpTbmMdGbmManmDVO.setFstRegerId(tbmMdGbmManmDVO.getFstRegerId());
		}		
		if ( tbmMdGbmManmDVO.getFnlUpdDt() != null && !"".equals(tbmMdGbmManmDVO.getFnlUpdDt()) ) {
			tmpTbmMdGbmManmDVO.setFnlUpdDt(tbmMdGbmManmDVO.getFnlUpdDt());
		}		
		if ( tbmMdGbmManmDVO.getFnlUpderId() != null && !"".equals(tbmMdGbmManmDVO.getFnlUpderId()) ) {
			tmpTbmMdGbmManmDVO.setFnlUpderId(tbmMdGbmManmDVO.getFnlUpderId());
		}		
		return updateTbmMdGbmManm (tmpTbmMdGbmManmDVO);
	}

/**
* insertBatchTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return int[]
*/
	@LocalName("insertBatchTbmMdGbmManm")
	public int[] insertBatchTbmMdGbmManm (final List tbmMdGbmManmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.insertBatchTbmMdGbmManm.001*/  \n");
			sql.append(" TBM_MD_GBM_MANM (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmManmDVO tbmMdGbmManmDVO = (TbmMdGbmManmDVO)tbmMdGbmManmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdGbmManmDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return int[]
*/
	@LocalName("updateBatchTbmMdGbmManm")
	public int[] updateBatchTbmMdGbmManm (final List tbmMdGbmManmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.updateBatchTbmMdGbmManm.001*/  \n");
			sql.append(" TBM_MD_GBM_MANM \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND MANM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmManmDVO tbmMdGbmManmDVO = (TbmMdGbmManmDVO)tbmMdGbmManmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmManmDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmManmDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
						}
							public int getBatchSize() {
									return tbmMdGbmManmDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdGbmManm Method
* 
* @ref_table TBM_MD_GBM_MANM
* @return int[]
*/
	@LocalName("deleteBatchTbmMdGbmManm")
	public int[] deleteBatchTbmMdGbmManm (final List tbmMdGbmManmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmManmDEM.deleteBatchTbmMdGbmManm.001*/  \n");
			sql.append(" TBM_MD_GBM_MANM \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND MANM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmManmDVO tbmMdGbmManmDVO = (TbmMdGbmManmDVO)tbmMdGbmManmDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmManmDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmManmDVO.getManmCode());
						}
							public int getBatchSize() {
									return tbmMdGbmManmDVOList.size();
							}
					}
		);			
	}

	
}