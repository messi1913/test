package com.samsung.gmes2.md.equipment.app;

public class MDU511M01App {

	/**
	 * 설비마스터 목록 초기설정
	 */
	public void initEquipMaster(){}

	/**
	 * 설비마스터 목록 조회
	 */
	public void listEquipMaster(){}

	/**
	 * 설비마스터 목록 엑셀 다운로드
	 */
	public void excelEquipMaster(){}

}
