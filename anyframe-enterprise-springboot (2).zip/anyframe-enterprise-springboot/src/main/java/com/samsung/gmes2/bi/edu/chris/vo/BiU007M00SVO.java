package com.samsung.gmes2.bi.edu.chris.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractSVO;
import java.util.List;
import java.util.ArrayList;

/**
 * 
 * @stereotype SVO
 * @author Chris
 */
@LocalName("교육용SVO")
public class BiU007M00SVO extends AbstractSVO {

    /**
     * 교육용 추후 삭제요청
     */
	@LocalName("직원정보DVO") 
	private List<EmpInfoDVO> empInfoDVOList;

    /**
     * ...
     */
	@LocalName("부서정보DVO") 
	private DeptInfoDVO deptInfoDVO;

    /**
     * ...l
     */
	@LocalName("직원나이DVO") 
	private EmpAgeDVO empAgeDVO;


	/**
	 * 직원정보DVO Getter Method
	 * 
	 * @return 직원정보DVO
	 */
	@LocalName("직원정보DVO Getter Method")
	public List<EmpInfoDVO> getEmpInfoDVOList() {
		this.empInfoDVOList = super.getValue("empInfoDVOList");
		return this.empInfoDVOList;
	}

	/**
	 * 직원정보DVO Setter Method
	 * 
	 * @param List 직원정보DVO
	 */
	@LocalName("직원정보DVO Setter Method")
	public void setEmpInfoDVOList(List<EmpInfoDVO> empInfoDVOList) {
	    super.setValue("empInfoDVOList", empInfoDVOList);
		this.empInfoDVOList = empInfoDVOList;
	}
	
	/**
	 * 부서정보DVO Getter Method
	 * 
	 * @return 부서정보DVO
	 */
	@LocalName("부서정보DVO Getter Method")
	public DeptInfoDVO getDeptInfoDVO() {
		this.deptInfoDVO = super.getValue("deptInfoDVO");
		return this.deptInfoDVO;
	}

	/**
	 * 부서정보DVO Setter Method
	 * 
	 * @param DeptInfoDVO 부서정보DVO
	 */
	@LocalName("부서정보DVO Setter Method")
	public void setDeptInfoDVO(DeptInfoDVO deptInfoDVO) {
        super.setValue("deptInfoDVO", deptInfoDVO);
		this.deptInfoDVO = deptInfoDVO;
	}
	
	/**
	 * 직원나이DVO Getter Method
	 * 
	 * @return 직원나이DVO
	 */
	@LocalName("직원나이DVO Getter Method")
	public EmpAgeDVO getEmpAgeDVO() {
		this.empAgeDVO = super.getValue("empAgeDVO");
		return this.empAgeDVO;
	}

	/**
	 * 직원나이DVO Setter Method
	 * 
	 * @param EmpAgeDVO 직원나이DVO
	 */
	@LocalName("직원나이DVO Setter Method")
	public void setEmpAgeDVO(EmpAgeDVO empAgeDVO) {
        super.setValue("empAgeDVO", empAgeDVO);
		this.empAgeDVO = empAgeDVO;
	}
	
}