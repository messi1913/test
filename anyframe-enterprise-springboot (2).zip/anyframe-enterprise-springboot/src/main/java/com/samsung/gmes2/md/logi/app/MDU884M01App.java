package com.samsung.gmes2.md.logi.app;

public class MDU884M01App {

	/**
	 * 특수형태정보 목록 초기설정
	 */
	public void initSpclForm(){}

	/**
	 * 특수형태정보 목록 조회
	 */
	public void listSpclForm(){}

	/**
	 * 특수형태정보 목록 엑셀 다운로드
	 */
	public void excelSpclForm(){}

	/**
	 * 특수형태정보 목록 저장
	 */
	public void saveSpclForm(){}

}
