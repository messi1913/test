package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
public class TbmMdProcDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String lineCode;

	@Length(30) @NotNull
	private String unitProcCode;

	@Length(500) 
	private String procNm;

	@Length(1) 
	private String bcdSumrYn;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String operYn;

	@Length(1) 
	private String catvUseYn;

	@Length(1) 
	private String boardUseYn;

	@Length(1) 
	private String autoStopYn;

	@Length(1) 
	private String earlyAlrmYn;

	@Length(30) 
	private String inlineGubunCode;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue("lineCode");
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue("lineCode", lineCode);
		this.lineCode = lineCode;
	}
	
	public String getUnitProcCode() {
		this.unitProcCode = super.getValue("unitProcCode");
		return this.unitProcCode;
	}

	public void setUnitProcCode(String unitProcCode) {
        super.setValue("unitProcCode", unitProcCode);
		this.unitProcCode = unitProcCode;
	}
	
	public String getProcNm() {
		this.procNm = super.getValue("procNm");
		return this.procNm;
	}

	public void setProcNm(String procNm) {
        super.setValue("procNm", procNm);
		this.procNm = procNm;
	}
	
	public String getBcdSumrYn() {
		this.bcdSumrYn = super.getValue("bcdSumrYn");
		return this.bcdSumrYn;
	}

	public void setBcdSumrYn(String bcdSumrYn) {
        super.setValue("bcdSumrYn", bcdSumrYn);
		this.bcdSumrYn = bcdSumrYn;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue("fnlAcrsReflYn");
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue("fnlAcrsReflYn", fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getOperYn() {
		this.operYn = super.getValue("operYn");
		return this.operYn;
	}

	public void setOperYn(String operYn) {
        super.setValue("operYn", operYn);
		this.operYn = operYn;
	}
	
	public String getCatvUseYn() {
		this.catvUseYn = super.getValue("catvUseYn");
		return this.catvUseYn;
	}

	public void setCatvUseYn(String catvUseYn) {
        super.setValue("catvUseYn", catvUseYn);
		this.catvUseYn = catvUseYn;
	}
	
	public String getBoardUseYn() {
		this.boardUseYn = super.getValue("boardUseYn");
		return this.boardUseYn;
	}

	public void setBoardUseYn(String boardUseYn) {
        super.setValue("boardUseYn", boardUseYn);
		this.boardUseYn = boardUseYn;
	}
	
	public String getAutoStopYn() {
		this.autoStopYn = super.getValue("autoStopYn");
		return this.autoStopYn;
	}

	public void setAutoStopYn(String autoStopYn) {
        super.setValue("autoStopYn", autoStopYn);
		this.autoStopYn = autoStopYn;
	}
	
	public String getEarlyAlrmYn() {
		this.earlyAlrmYn = super.getValue("earlyAlrmYn");
		return this.earlyAlrmYn;
	}

	public void setEarlyAlrmYn(String earlyAlrmYn) {
        super.setValue("earlyAlrmYn", earlyAlrmYn);
		this.earlyAlrmYn = earlyAlrmYn;
	}
	
	public String getInlineGubunCode() {
		this.inlineGubunCode = super.getValue("inlineGubunCode");
		return this.inlineGubunCode;
	}

	public void setInlineGubunCode(String inlineGubunCode) {
        super.setValue("inlineGubunCode", inlineGubunCode);
		this.inlineGubunCode = inlineGubunCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}