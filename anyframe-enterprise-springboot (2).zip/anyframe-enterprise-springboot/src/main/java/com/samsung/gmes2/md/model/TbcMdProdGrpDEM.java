package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PROD_GRP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdProdGrpDEM extends AbstractDAO {


/**
* insertTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return int
*/
	@LocalName("insertTbcMdProdGrp")
	public int insertTbcMdProdGrp (final TbcMdProdGrpDVO tbcMdProdGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.insertTbcMdProdGrp.001*/  \n");
			sql.append(" TBC_MD_PROD_GRP (   \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROD_GRP_ABBR_NM , \n");
			sql.append("        PROD_GRP_NM , \n");
			sql.append("        PROD_GRP_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdProdGrpDVO.getGbmCode());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpAbbrNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpDesc());
							ps.setString(psCount++, tbcMdProdGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdProdGrp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdProdGrp Method")
	public int[][] updateBatchAllTbcMdProdGrp (final List  tbcMdProdGrpDVOList) {
		
		ArrayList updatetbcMdProdGrpDVOList = new ArrayList();
		ArrayList insertttbcMdProdGrpDVOList = new ArrayList();
		ArrayList deletetbcMdProdGrpDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdProdGrpDVOList.size() ; i++) {
		  TbcMdProdGrpDVO tbcMdProdGrpDVO = (TbcMdProdGrpDVO) tbcMdProdGrpDVOList.get(i);
		  
		  if (tbcMdProdGrpDVO.getSqlAction().equals("C"))
		      insertttbcMdProdGrpDVOList.add(tbcMdProdGrpDVO);
		  else if (tbcMdProdGrpDVO.getSqlAction().equals("U"))
		      updatetbcMdProdGrpDVOList.add(tbcMdProdGrpDVO);
		  else if (tbcMdProdGrpDVO.getSqlAction().equals("D"))
		      deletetbcMdProdGrpDVOList.add(tbcMdProdGrpDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdProdGrpDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdProdGrp(insertttbcMdProdGrpDVOList);
          
      if (updatetbcMdProdGrpDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdProdGrp(updatetbcMdProdGrpDVOList);
      
      if (deletetbcMdProdGrpDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdProdGrp(deletetbcMdProdGrpDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return int
*/
	@LocalName("updateTbcMdProdGrp")
	public int updateTbcMdProdGrp (final TbcMdProdGrpDVO tbcMdProdGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.updateTbcMdProdGrp.001*/  \n");
			sql.append(" TBC_MD_PROD_GRP \n");
			sql.append(" SET   \n");
			sql.append("        GBM_CODE = ? , \n");
			sql.append("        PROD_GRP_ABBR_NM = ? , \n");
			sql.append("        PROD_GRP_NM = ? , \n");
			sql.append("        PROD_GRP_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_GRP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdGrpDVO.getGbmCode());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpAbbrNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpDesc());
							ps.setString(psCount++, tbcMdProdGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
						}
					}
		);			
	}

/**
* deleteTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return int
*/
	@LocalName("deleteTbcMdProdGrp")
	public int deleteTbcMdProdGrp (final TbcMdProdGrpDVO tbcMdProdGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.deleteTbcMdProdGrp.001*/  \n");
			sql.append(" TBC_MD_PROD_GRP \n");
			sql.append("  WHERE PROD_GRP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
						}
					}
		);			
	}

/**
* selectTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return TbcMdProdGrpDVO 
*/
	@LocalName("selectTbcMdProdGrp")
	public TbcMdProdGrpDVO selectTbcMdProdGrp (final TbcMdProdGrpDVO tbcMdProdGrpDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.selectTbcMdProdGrp.001*/  \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROD_GRP_ABBR_NM , \n");
			sql.append("        PROD_GRP_NM , \n");
			sql.append("        PROD_GRP_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PROD_GRP \n");
			sql.append("  WHERE PROD_GRP_CODE = ? \n");

		return (TbcMdProdGrpDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdProdGrpDVO returnTbcMdProdGrpDVO = new TbcMdProdGrpDVO();
									returnTbcMdProdGrpDVO.setProdGrpCode(resultSet.getString("PROD_GRP_CODE"));
									returnTbcMdProdGrpDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdProdGrpDVO.setProdGrpAbbrNm(resultSet.getString("PROD_GRP_ABBR_NM"));
									returnTbcMdProdGrpDVO.setProdGrpNm(resultSet.getString("PROD_GRP_NM"));
									returnTbcMdProdGrpDVO.setProdGrpDesc(resultSet.getString("PROD_GRP_DESC"));
									returnTbcMdProdGrpDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdProdGrpDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdGrpDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdGrpDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdGrpDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdGrpDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdProdGrp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdProdGrp Method")
	public int mergeTbcMdProdGrp (final TbcMdProdGrpDVO tbcMdProdGrpDVO) {
		
		if ( selectTbcMdProdGrp (tbcMdProdGrpDVO) == null) {
			return insertTbcMdProdGrp(tbcMdProdGrpDVO);
		} else {
			return selectUpdateTbcMdProdGrp (tbcMdProdGrpDVO);
		}
	}

	/**
	 * selectUpdateTbcMdProdGrp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdProdGrp Method")
	public int selectUpdateTbcMdProdGrp (final TbcMdProdGrpDVO tbcMdProdGrpDVO) {
		
		TbcMdProdGrpDVO tmpTbcMdProdGrpDVO =  selectTbcMdProdGrp (tbcMdProdGrpDVO);
		if ( tbcMdProdGrpDVO.getProdGrpCode() != null && !"".equals(tbcMdProdGrpDVO.getProdGrpCode()) ) {
			tmpTbcMdProdGrpDVO.setProdGrpCode(tbcMdProdGrpDVO.getProdGrpCode());
		}		
		if ( tbcMdProdGrpDVO.getGbmCode() != null && !"".equals(tbcMdProdGrpDVO.getGbmCode()) ) {
			tmpTbcMdProdGrpDVO.setGbmCode(tbcMdProdGrpDVO.getGbmCode());
		}		
		if ( tbcMdProdGrpDVO.getProdGrpAbbrNm() != null && !"".equals(tbcMdProdGrpDVO.getProdGrpAbbrNm()) ) {
			tmpTbcMdProdGrpDVO.setProdGrpAbbrNm(tbcMdProdGrpDVO.getProdGrpAbbrNm());
		}		
		if ( tbcMdProdGrpDVO.getProdGrpNm() != null && !"".equals(tbcMdProdGrpDVO.getProdGrpNm()) ) {
			tmpTbcMdProdGrpDVO.setProdGrpNm(tbcMdProdGrpDVO.getProdGrpNm());
		}		
		if ( tbcMdProdGrpDVO.getProdGrpDesc() != null && !"".equals(tbcMdProdGrpDVO.getProdGrpDesc()) ) {
			tmpTbcMdProdGrpDVO.setProdGrpDesc(tbcMdProdGrpDVO.getProdGrpDesc());
		}		
		if ( tbcMdProdGrpDVO.getUseYn() != null && !"".equals(tbcMdProdGrpDVO.getUseYn()) ) {
			tmpTbcMdProdGrpDVO.setUseYn(tbcMdProdGrpDVO.getUseYn());
		}		
		if ( tbcMdProdGrpDVO.getFstRegDt() != null && !"".equals(tbcMdProdGrpDVO.getFstRegDt()) ) {
			tmpTbcMdProdGrpDVO.setFstRegDt(tbcMdProdGrpDVO.getFstRegDt());
		}		
		if ( tbcMdProdGrpDVO.getFstRegerId() != null && !"".equals(tbcMdProdGrpDVO.getFstRegerId()) ) {
			tmpTbcMdProdGrpDVO.setFstRegerId(tbcMdProdGrpDVO.getFstRegerId());
		}		
		if ( tbcMdProdGrpDVO.getFnlUpdDt() != null && !"".equals(tbcMdProdGrpDVO.getFnlUpdDt()) ) {
			tmpTbcMdProdGrpDVO.setFnlUpdDt(tbcMdProdGrpDVO.getFnlUpdDt());
		}		
		if ( tbcMdProdGrpDVO.getFnlUpderId() != null && !"".equals(tbcMdProdGrpDVO.getFnlUpderId()) ) {
			tmpTbcMdProdGrpDVO.setFnlUpderId(tbcMdProdGrpDVO.getFnlUpderId());
		}		
		return updateTbcMdProdGrp (tmpTbcMdProdGrpDVO);
	}

/**
* insertBatchTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return int[]
*/
	@LocalName("insertBatchTbcMdProdGrp")
	public int[] insertBatchTbcMdProdGrp (final List tbcMdProdGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.insertBatchTbcMdProdGrp.001*/  \n");
			sql.append(" TBC_MD_PROD_GRP (   \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROD_GRP_ABBR_NM , \n");
			sql.append("        PROD_GRP_NM , \n");
			sql.append("        PROD_GRP_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdGrpDVO tbcMdProdGrpDVO = (TbcMdProdGrpDVO)tbcMdProdGrpDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdProdGrpDVO.getGbmCode());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpAbbrNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpDesc());
							ps.setString(psCount++, tbcMdProdGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdProdGrpDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return int[]
*/
	@LocalName("updateBatchTbcMdProdGrp")
	public int[] updateBatchTbcMdProdGrp (final List tbcMdProdGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.updateBatchTbcMdProdGrp.001*/  \n");
			sql.append(" TBC_MD_PROD_GRP \n");
			sql.append(" SET   \n");
			sql.append("        GBM_CODE = ? , \n");
			sql.append("        PROD_GRP_ABBR_NM = ? , \n");
			sql.append("        PROD_GRP_NM = ? , \n");
			sql.append("        PROD_GRP_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_GRP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdGrpDVO tbcMdProdGrpDVO = (TbcMdProdGrpDVO)tbcMdProdGrpDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdGrpDVO.getGbmCode());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpAbbrNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpNm());
							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpDesc());
							ps.setString(psCount++, tbcMdProdGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdGrpDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
						}
							public int getBatchSize() {
									return tbcMdProdGrpDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdProdGrp Method
* 
* @ref_table TBC_MD_PROD_GRP
* @return int[]
*/
	@LocalName("deleteBatchTbcMdProdGrp")
	public int[] deleteBatchTbcMdProdGrp (final List tbcMdProdGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProdGrpDEM.deleteBatchTbcMdProdGrp.001*/  \n");
			sql.append(" TBC_MD_PROD_GRP \n");
			sql.append("  WHERE PROD_GRP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdGrpDVO tbcMdProdGrpDVO = (TbcMdProdGrpDVO)tbcMdProdGrpDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdGrpDVO.getProdGrpCode());
						}
							public int getBatchSize() {
									return tbcMdProdGrpDVOList.size();
							}
					}
		);			
	}

	
}