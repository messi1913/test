/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbcMdMfgGrpBiz.java
 * Description : 테이블 TbcMdMfgGrp에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.19          심재국          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdMfgGrpDVO;
import com.samsung.gmes2.md.model.TbcMdMfgTeamDVO;

public class MdManageTbcMdMfgGrpBiz {
	
	public void common(TbcMdMfgGrpDVO tbcMdMfgGrpDVO) throws Exception{
		BaseUtil.checkNotEmpty(tbcMdMfgGrpDVO);
		TbcMdMfgTeamDVO tbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
		
		BaseUtil.populate(tbcMdMfgGrpDVO, tbcMdMfgTeamDVO, "fctCode","mfgTeamCode");
		BaseUtil.checkFound(tbcMdMfgTeamDVO);
	}

	/**
	 * TbcMdMfgGrp 등록을 하기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdMfgGrpDVO 값을 넣어준다
	 */
	public TbcMdMfgGrpDVO createTbcMdMfgGrp(TbcMdMfgGrpDVO tbcMdMfgGrpDVO)
			throws Exception {
		common(tbcMdMfgGrpDVO);
		return CrudUtil.create(tbcMdMfgGrpDVO);
	}

	/**
	 * TbcMdMfgGrp 삭제를 하기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdMfgGrpDVO 값을 넣어준다
	 */
	public TbcMdMfgGrpDVO deleteTbcMdMfgGrp(TbcMdMfgGrpDVO tbcMdMfgGrpDVO)
			throws Exception {
		common(tbcMdMfgGrpDVO);
		return CrudUtil.delete(tbcMdMfgGrpDVO);
	}

	/**
	 * TbcMdMfgGrp 수정을 하기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdMfgGrpDVO 값을 넣어준다
	 */
	public TbcMdMfgGrpDVO updateTbcMdMfgGrp(TbcMdMfgGrpDVO tbcMdMfgGrpDVO)
			throws Exception {
		common(tbcMdMfgGrpDVO);
		return CrudUtil.update(tbcMdMfgGrpDVO);
	}

	/**
	 * TbcMdMfgGrp 정보를 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdMfgGrpDVO 값을 넣어준다
	 * 단건 조회
	 */
	public TbcMdMfgGrpDVO getTbcMdMfgGrp(TbcMdMfgGrpDVO tbcMdMfgGrpDVO)
			throws Exception {
		//BaseUtil.checkNotEmpty(tbcMdMfgGrpDVO);
		return CrudUtil.get(tbcMdMfgGrpDVO);
	}

	/**
	 * TbcMdMfgGrp 정보를List 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdMfgGrpDVO 값을 넣어준다
	 * 다건 조회
	 */
	public List<TbcMdMfgGrpDVO> listTbcMdMfgGrp(TbcMdMfgGrpDVO tbcMdMfgGrpDVO)
			throws Exception {
		return CrudUtil.list0(TbcMdMfgGrpDVO.class, tbcMdMfgGrpDVO, 0, 0);
	}

}
