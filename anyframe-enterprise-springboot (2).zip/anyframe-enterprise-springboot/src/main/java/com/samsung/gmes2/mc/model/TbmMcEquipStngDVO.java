package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbmMcEquipStngDVO extends AbstractDVO {

	@Length(18) @NotNull
	private String ip;

	@Length(50) @NotNull
	private String pgmCode;

	@Length(50) @NotNull
	private String equipNo;

	@Length(50) 
	private String equipCtgrCode;

	@Length(30) 
	private String prtmcCtgrCode;

	@Length(50) 
	private String prtmcPortNo;

	@Length(11) @Scale(5) 
	private BigDecimal xValue;

	@Length(11) @Scale(5) 
	private BigDecimal yValue;

	@Length(11) @Scale(5) 
	private BigDecimal darknessValue;

	@Length(11) @Scale(5) 
	private BigDecimal troffposValue;

	@Length(11) @Scale(5) 
	private BigDecimal topposValue;

	@Length(11) @Scale(5) 
	private BigDecimal prtmcSpeed;

	@Length(50) 
	private String scnnrPortNo;

	@Length(11) @Scale(5) 
	private BigDecimal comnSpeed;

	@Length(11) @Scale(5) 
	private BigDecimal prtbitValue;

	@Length(11) @Scale(5) 
	private BigDecimal datbitValue;

	@Length(11) @Scale(5) 
	private BigDecimal stopbitValue;


	public String getIp() {
		this.ip = super.getValue("ip");
		return this.ip;
	}

	public void setIp(String ip) {
        super.setValue("ip", ip);
		this.ip = ip;
	}
	
	public String getPgmCode() {
		this.pgmCode = super.getValue("pgmCode");
		return this.pgmCode;
	}

	public void setPgmCode(String pgmCode) {
        super.setValue("pgmCode", pgmCode);
		this.pgmCode = pgmCode;
	}
	
	public String getEquipNo() {
		this.equipNo = super.getValue("equipNo");
		return this.equipNo;
	}

	public void setEquipNo(String equipNo) {
        super.setValue("equipNo", equipNo);
		this.equipNo = equipNo;
	}
	
	public String getEquipCtgrCode() {
		this.equipCtgrCode = super.getValue("equipCtgrCode");
		return this.equipCtgrCode;
	}

	public void setEquipCtgrCode(String equipCtgrCode) {
        super.setValue("equipCtgrCode", equipCtgrCode);
		this.equipCtgrCode = equipCtgrCode;
	}
	
	public String getPrtmcCtgrCode() {
		this.prtmcCtgrCode = super.getValue("prtmcCtgrCode");
		return this.prtmcCtgrCode;
	}

	public void setPrtmcCtgrCode(String prtmcCtgrCode) {
        super.setValue("prtmcCtgrCode", prtmcCtgrCode);
		this.prtmcCtgrCode = prtmcCtgrCode;
	}
	
	public String getPrtmcPortNo() {
		this.prtmcPortNo = super.getValue("prtmcPortNo");
		return this.prtmcPortNo;
	}

	public void setPrtmcPortNo(String prtmcPortNo) {
        super.setValue("prtmcPortNo", prtmcPortNo);
		this.prtmcPortNo = prtmcPortNo;
	}
	
	public BigDecimal getxValue() {
		this.xValue = super.getValue("xValue");
		return this.xValue;
	}

	public void setxValue(BigDecimal xValue) {
        super.setValue("xValue", xValue);
		this.xValue = xValue;
	}
	
	public BigDecimal getyValue() {
		this.yValue = super.getValue("yValue");
		return this.yValue;
	}

	public void setyValue(BigDecimal yValue) {
        super.setValue("yValue", yValue);
		this.yValue = yValue;
	}
	
	public BigDecimal getDarknessValue() {
		this.darknessValue = super.getValue("darknessValue");
		return this.darknessValue;
	}

	public void setDarknessValue(BigDecimal darknessValue) {
        super.setValue("darknessValue", darknessValue);
		this.darknessValue = darknessValue;
	}
	
	public BigDecimal getTroffposValue() {
		this.troffposValue = super.getValue("troffposValue");
		return this.troffposValue;
	}

	public void setTroffposValue(BigDecimal troffposValue) {
        super.setValue("troffposValue", troffposValue);
		this.troffposValue = troffposValue;
	}
	
	public BigDecimal getTopposValue() {
		this.topposValue = super.getValue("topposValue");
		return this.topposValue;
	}

	public void setTopposValue(BigDecimal topposValue) {
        super.setValue("topposValue", topposValue);
		this.topposValue = topposValue;
	}
	
	public BigDecimal getPrtmcSpeed() {
		this.prtmcSpeed = super.getValue("prtmcSpeed");
		return this.prtmcSpeed;
	}

	public void setPrtmcSpeed(BigDecimal prtmcSpeed) {
        super.setValue("prtmcSpeed", prtmcSpeed);
		this.prtmcSpeed = prtmcSpeed;
	}
	
	public String getScnnrPortNo() {
		this.scnnrPortNo = super.getValue("scnnrPortNo");
		return this.scnnrPortNo;
	}

	public void setScnnrPortNo(String scnnrPortNo) {
        super.setValue("scnnrPortNo", scnnrPortNo);
		this.scnnrPortNo = scnnrPortNo;
	}
	
	public BigDecimal getComnSpeed() {
		this.comnSpeed = super.getValue("comnSpeed");
		return this.comnSpeed;
	}

	public void setComnSpeed(BigDecimal comnSpeed) {
        super.setValue("comnSpeed", comnSpeed);
		this.comnSpeed = comnSpeed;
	}
	
	public BigDecimal getPrtbitValue() {
		this.prtbitValue = super.getValue("prtbitValue");
		return this.prtbitValue;
	}

	public void setPrtbitValue(BigDecimal prtbitValue) {
        super.setValue("prtbitValue", prtbitValue);
		this.prtbitValue = prtbitValue;
	}
	
	public BigDecimal getDatbitValue() {
		this.datbitValue = super.getValue("datbitValue");
		return this.datbitValue;
	}

	public void setDatbitValue(BigDecimal datbitValue) {
        super.setValue("datbitValue", datbitValue);
		this.datbitValue = datbitValue;
	}
	
	public BigDecimal getStopbitValue() {
		this.stopbitValue = super.getValue("stopbitValue");
		return this.stopbitValue;
	}

	public void setStopbitValue(BigDecimal stopbitValue) {
        super.setValue("stopbitValue", stopbitValue);
		this.stopbitValue = stopbitValue;
	}
	
}