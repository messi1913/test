package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdVendDQM extends AbstractDAO {


/**
*
* SELECT 
* 	PLANT_CODE, 
* 	VEND_CODE, 
* 	VEND_GUBUN_CODE, 
* 	VEND_NM, 
* 	VEND_CTRAC_CODE, 
* 	VEND_ADDR, 
* 	DLGR_NM, 
* 	CONTCT_NO, 
* 	VEND_TYPE_CODE, 
* 	PROD_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_VEND 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($vendCode) 
* AND VEND_CODE = :vendCode 
* #end 
* #if($vendGubunCode) 
* AND VEND_GUBUN_CODE = :vendGubunCode 
* #end 
* #if($vendNm) 
* AND VEND_NM = :vendNm 
* #end 
* #if($vendCtracCode) 
* AND VEND_CTRAC_CODE = :vendCtracCode 
* #end 
* #if($vendAddr) 
* AND VEND_ADDR = :vendAddr 
* #end 
* #if($dlgrNm) 
* AND DLGR_NM = :dlgrNm 
* #end 
* #if($contctNo) 
* AND CONTCT_NO = :contctNo 
* #end 
* #if($vendTypeCode) 
* AND VEND_TYPE_CODE = :vendTypeCode 
* #end 
* #if($prodGubunCode) 
* AND PROD_GUBUN_CODE = :prodGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	VEND_CODE,  \n");
			sql.append(" 	VEND_GUBUN_CODE,  \n");
			sql.append(" 	VEND_NM,  \n");
			sql.append(" 	VEND_CTRAC_CODE,  \n");
			sql.append(" 	VEND_ADDR,  \n");
			sql.append(" 	DLGR_NM,  \n");
			sql.append(" 	CONTCT_NO,  \n");
			sql.append(" 	VEND_TYPE_CODE,  \n");
			sql.append(" 	PROD_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_VEND  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCode)  \n");
			sql.append(" AND VEND_CODE = :vendCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendGubunCode)  \n");
			sql.append(" AND VEND_GUBUN_CODE = :vendGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendNm)  \n");
			sql.append(" AND VEND_NM = :vendNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCtracCode)  \n");
			sql.append(" AND VEND_CTRAC_CODE = :vendCtracCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendAddr)  \n");
			sql.append(" AND VEND_ADDR = :vendAddr  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dlgrNm)  \n");
			sql.append(" AND DLGR_NM = :dlgrNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($contctNo)  \n");
			sql.append(" AND CONTCT_NO = :contctNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendTypeCode)  \n");
			sql.append(" AND VEND_TYPE_CODE = :vendTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodGubunCode)  \n");
			sql.append(" AND PROD_GUBUN_CODE = :prodGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdVendDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdVendDVO returnTbmMdVendDVO = new TbmMdVendDVO();
									returnTbmMdVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdVendDVO.setVendCode(resultSet.getString("VEND_CODE"));
									returnTbmMdVendDVO.setVendGubunCode(resultSet.getString("VEND_GUBUN_CODE"));
									returnTbmMdVendDVO.setVendNm(resultSet.getString("VEND_NM"));
									returnTbmMdVendDVO.setVendCtracCode(resultSet.getString("VEND_CTRAC_CODE"));
									returnTbmMdVendDVO.setVendAddr(resultSet.getString("VEND_ADDR"));
									returnTbmMdVendDVO.setDlgrNm(resultSet.getString("DLGR_NM"));
									returnTbmMdVendDVO.setContctNo(resultSet.getString("CONTCT_NO"));
									returnTbmMdVendDVO.setVendTypeCode(resultSet.getString("VEND_TYPE_CODE"));
									returnTbmMdVendDVO.setProdGubunCode(resultSet.getString("PROD_GUBUN_CODE"));
									returnTbmMdVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdVendDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	PLANT_CODE, 
* 	VEND_CODE, 
* 	VEND_GUBUN_CODE, 
* 	VEND_NM, 
* 	VEND_CTRAC_CODE, 
* 	VEND_ADDR, 
* 	DLGR_NM, 
* 	CONTCT_NO, 
* 	VEND_TYPE_CODE, 
* 	PROD_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_VEND 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($vendCode) 
* AND VEND_CODE = :vendCode 
* #end 
* #if($vendGubunCode) 
* AND VEND_GUBUN_CODE = :vendGubunCode 
* #end 
* #if($vendNm) 
* AND VEND_NM = :vendNm 
* #end 
* #if($vendCtracCode) 
* AND VEND_CTRAC_CODE = :vendCtracCode 
* #end 
* #if($vendAddr) 
* AND VEND_ADDR = :vendAddr 
* #end 
* #if($dlgrNm) 
* AND DLGR_NM = :dlgrNm 
* #end 
* #if($contctNo) 
* AND CONTCT_NO = :contctNo 
* #end 
* #if($vendTypeCode) 
* AND VEND_TYPE_CODE = :vendTypeCode 
* #end 
* #if($prodGubunCode) 
* AND PROD_GUBUN_CODE = :prodGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	VEND_CODE,  \n");
			sql.append(" 	VEND_GUBUN_CODE,  \n");
			sql.append(" 	VEND_NM,  \n");
			sql.append(" 	VEND_CTRAC_CODE,  \n");
			sql.append(" 	VEND_ADDR,  \n");
			sql.append(" 	DLGR_NM,  \n");
			sql.append(" 	CONTCT_NO,  \n");
			sql.append(" 	VEND_TYPE_CODE,  \n");
			sql.append(" 	PROD_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_VEND  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCode)  \n");
			sql.append(" AND VEND_CODE = :vendCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendGubunCode)  \n");
			sql.append(" AND VEND_GUBUN_CODE = :vendGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendNm)  \n");
			sql.append(" AND VEND_NM = :vendNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCtracCode)  \n");
			sql.append(" AND VEND_CTRAC_CODE = :vendCtracCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendAddr)  \n");
			sql.append(" AND VEND_ADDR = :vendAddr  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dlgrNm)  \n");
			sql.append(" AND DLGR_NM = :dlgrNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($contctNo)  \n");
			sql.append(" AND CONTCT_NO = :contctNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendTypeCode)  \n");
			sql.append(" AND VEND_TYPE_CODE = :vendTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodGubunCode)  \n");
			sql.append(" AND PROD_GUBUN_CODE = :prodGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdVendDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdVendDVO returnTbmMdVendDVO = new TbmMdVendDVO();
									returnTbmMdVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdVendDVO.setVendCode(resultSet.getString("VEND_CODE"));
									returnTbmMdVendDVO.setVendGubunCode(resultSet.getString("VEND_GUBUN_CODE"));
									returnTbmMdVendDVO.setVendNm(resultSet.getString("VEND_NM"));
									returnTbmMdVendDVO.setVendCtracCode(resultSet.getString("VEND_CTRAC_CODE"));
									returnTbmMdVendDVO.setVendAddr(resultSet.getString("VEND_ADDR"));
									returnTbmMdVendDVO.setDlgrNm(resultSet.getString("DLGR_NM"));
									returnTbmMdVendDVO.setContctNo(resultSet.getString("CONTCT_NO"));
									returnTbmMdVendDVO.setVendTypeCode(resultSet.getString("VEND_TYPE_CODE"));
									returnTbmMdVendDVO.setProdGubunCode(resultSet.getString("PROD_GUBUN_CODE"));
									returnTbmMdVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdVendDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	PLANT_CODE, 
* 	VEND_CODE, 
* 	VEND_GUBUN_CODE, 
* 	VEND_NM, 
* 	VEND_CTRAC_CODE, 
* 	VEND_ADDR, 
* 	DLGR_NM, 
* 	CONTCT_NO, 
* 	VEND_TYPE_CODE, 
* 	PROD_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_VEND 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($vendCode) 
* AND VEND_CODE = :vendCode 
* #end 
* #if($vendGubunCode) 
* AND VEND_GUBUN_CODE = :vendGubunCode 
* #end 
* #if($vendNm) 
* AND VEND_NM = :vendNm 
* #end 
* #if($vendCtracCode) 
* AND VEND_CTRAC_CODE = :vendCtracCode 
* #end 
* #if($vendAddr) 
* AND VEND_ADDR = :vendAddr 
* #end 
* #if($dlgrNm) 
* AND DLGR_NM = :dlgrNm 
* #end 
* #if($contctNo) 
* AND CONTCT_NO = :contctNo 
* #end 
* #if($vendTypeCode) 
* AND VEND_TYPE_CODE = :vendTypeCode 
* #end 
* #if($prodGubunCode) 
* AND PROD_GUBUN_CODE = :prodGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	VEND_CODE,  \n");
			sql.append(" 	VEND_GUBUN_CODE,  \n");
			sql.append(" 	VEND_NM,  \n");
			sql.append(" 	VEND_CTRAC_CODE,  \n");
			sql.append(" 	VEND_ADDR,  \n");
			sql.append(" 	DLGR_NM,  \n");
			sql.append(" 	CONTCT_NO,  \n");
			sql.append(" 	VEND_TYPE_CODE,  \n");
			sql.append(" 	PROD_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_VEND  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCode)  \n");
			sql.append(" AND VEND_CODE = :vendCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendGubunCode)  \n");
			sql.append(" AND VEND_GUBUN_CODE = :vendGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendNm)  \n");
			sql.append(" AND VEND_NM = :vendNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCtracCode)  \n");
			sql.append(" AND VEND_CTRAC_CODE = :vendCtracCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendAddr)  \n");
			sql.append(" AND VEND_ADDR = :vendAddr  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dlgrNm)  \n");
			sql.append(" AND DLGR_NM = :dlgrNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($contctNo)  \n");
			sql.append(" AND CONTCT_NO = :contctNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendTypeCode)  \n");
			sql.append(" AND VEND_TYPE_CODE = :vendTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodGubunCode)  \n");
			sql.append(" AND PROD_GUBUN_CODE = :prodGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdVendDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdVendDVO returnTbmMdVendDVO = new TbmMdVendDVO();
									returnTbmMdVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdVendDVO.setVendCode(resultSet.getString("VEND_CODE"));
									returnTbmMdVendDVO.setVendGubunCode(resultSet.getString("VEND_GUBUN_CODE"));
									returnTbmMdVendDVO.setVendNm(resultSet.getString("VEND_NM"));
									returnTbmMdVendDVO.setVendCtracCode(resultSet.getString("VEND_CTRAC_CODE"));
									returnTbmMdVendDVO.setVendAddr(resultSet.getString("VEND_ADDR"));
									returnTbmMdVendDVO.setDlgrNm(resultSet.getString("DLGR_NM"));
									returnTbmMdVendDVO.setContctNo(resultSet.getString("CONTCT_NO"));
									returnTbmMdVendDVO.setVendTypeCode(resultSet.getString("VEND_TYPE_CODE"));
									returnTbmMdVendDVO.setProdGubunCode(resultSet.getString("PROD_GUBUN_CODE"));
									returnTbmMdVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdVendDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	PLANT_CODE, 
* 	VEND_CODE, 
* 	VEND_GUBUN_CODE, 
* 	VEND_NM, 
* 	VEND_CTRAC_CODE, 
* 	VEND_ADDR, 
* 	DLGR_NM, 
* 	CONTCT_NO, 
* 	VEND_TYPE_CODE, 
* 	PROD_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_VEND 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($vendCode) 
* AND VEND_CODE = :vendCode 
* #end 
* #if($vendGubunCode) 
* AND VEND_GUBUN_CODE = :vendGubunCode 
* #end 
* #if($vendNm) 
* AND VEND_NM = :vendNm 
* #end 
* #if($vendCtracCode) 
* AND VEND_CTRAC_CODE = :vendCtracCode 
* #end 
* #if($vendAddr) 
* AND VEND_ADDR = :vendAddr 
* #end 
* #if($dlgrNm) 
* AND DLGR_NM = :dlgrNm 
* #end 
* #if($contctNo) 
* AND CONTCT_NO = :contctNo 
* #end 
* #if($vendTypeCode) 
* AND VEND_TYPE_CODE = :vendTypeCode 
* #end 
* #if($prodGubunCode) 
* AND PROD_GUBUN_CODE = :prodGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	VEND_CODE,  \n");
			sql.append(" 	VEND_GUBUN_CODE,  \n");
			sql.append(" 	VEND_NM,  \n");
			sql.append(" 	VEND_CTRAC_CODE,  \n");
			sql.append(" 	VEND_ADDR,  \n");
			sql.append(" 	DLGR_NM,  \n");
			sql.append(" 	CONTCT_NO,  \n");
			sql.append(" 	VEND_TYPE_CODE,  \n");
			sql.append(" 	PROD_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_VEND  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCode)  \n");
			sql.append(" AND VEND_CODE = :vendCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendGubunCode)  \n");
			sql.append(" AND VEND_GUBUN_CODE = :vendGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendNm)  \n");
			sql.append(" AND VEND_NM = :vendNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendCtracCode)  \n");
			sql.append(" AND VEND_CTRAC_CODE = :vendCtracCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendAddr)  \n");
			sql.append(" AND VEND_ADDR = :vendAddr  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dlgrNm)  \n");
			sql.append(" AND DLGR_NM = :dlgrNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($contctNo)  \n");
			sql.append(" AND CONTCT_NO = :contctNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($vendTypeCode)  \n");
			sql.append(" AND VEND_TYPE_CODE = :vendTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodGubunCode)  \n");
			sql.append(" AND PROD_GUBUN_CODE = :prodGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdVendDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdVendDVO returnTbmMdVendDVO = new TbmMdVendDVO();
									returnTbmMdVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdVendDVO.setVendCode(resultSet.getString("VEND_CODE"));
									returnTbmMdVendDVO.setVendGubunCode(resultSet.getString("VEND_GUBUN_CODE"));
									returnTbmMdVendDVO.setVendNm(resultSet.getString("VEND_NM"));
									returnTbmMdVendDVO.setVendCtracCode(resultSet.getString("VEND_CTRAC_CODE"));
									returnTbmMdVendDVO.setVendAddr(resultSet.getString("VEND_ADDR"));
									returnTbmMdVendDVO.setDlgrNm(resultSet.getString("DLGR_NM"));
									returnTbmMdVendDVO.setContctNo(resultSet.getString("CONTCT_NO"));
									returnTbmMdVendDVO.setVendTypeCode(resultSet.getString("VEND_TYPE_CODE"));
									returnTbmMdVendDVO.setProdGubunCode(resultSet.getString("PROD_GUBUN_CODE"));
									returnTbmMdVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdVendDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}