package com.samsung.gmes2.md.logi.biz;

public class MdManageMoveInstUserBiz {

	/**
	 * 이동지시권한 목록 조회
	 */
	public void listMoveInstUser(){}

	/**
	 * 이동지시권한 목록 저장
	 */
	public void saveMoveInstUser(){}

}
