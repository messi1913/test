package com.samsung.gmes2.md.equipment.app;

public class MDU541M01App {

	/**
	 * 계측기정보 목록 초기설정
	 */
	public void initMinstInfo(){}

	/**
	 * 계측기정보 목록 조회
	 */
	public void listMinstInfo(){}

	/**
	 * 계측기정보 목록 엑셀 다운로드
	 */
	public void excelMinstInfo(){}

}
