package com.samsung.gmes2.mc.mcu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 한글명 : 모델라벨, labelType, Status 조회
 * 작성일 : 2011.06.29
 * 작성자 : 심 재 국
 * 작업상태 : 완료
 * 개요 :
 * 모델 코드의 값을 List 가진 DVO
 * @stereotype DAOVO
 * @author shim
 */
@LocalName("공통모드코드")
public class McU611M0001DVO extends AbstractDVO {

	@Length(30) 
	private String cate1Type;

	@Length(30) 
	private String cate2Type;

	@Length(30) 
	private String cate3Type;


	public String getCate1Type() {
		this.cate1Type = super.getValue("cate1Type");
		return this.cate1Type;
	}

	public void setCate1Type(String cate1Type) {
        super.setValue("cate1Type", cate1Type);
		this.cate1Type = cate1Type;
	}
	
	public String getCate2Type() {
		this.cate2Type = super.getValue("cate2Type");
		return this.cate2Type;
	}

	public void setCate2Type(String cate2Type) {
        super.setValue("cate2Type", cate2Type);
		this.cate2Type = cate2Type;
	}
	
	public String getCate3Type() {
		this.cate3Type = super.getValue("cate3Type");
		return this.cate3Type;
	}

	public void setCate3Type(String cate3Type) {
        super.setValue("cate3Type", cate3Type);
		this.cate3Type = cate3Type;
	}
	
}