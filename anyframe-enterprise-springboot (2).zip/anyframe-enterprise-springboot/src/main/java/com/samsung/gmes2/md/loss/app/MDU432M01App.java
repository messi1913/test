package com.samsung.gmes2.md.loss.app;

public class MDU432M01App {

	/**
	 * 책임부서 목록 초기설정
	 */
	public void initLossDutyPic(){}

	/**
	 * 책임부서 목록 조회
	 */
	public void listLossDutyPic(){}

	/**
	 * 책임부서 목록 엑셀 다운로드
	 */
	public void excelLossDutyPic(){}

	/**
	 * 책임자 정보 조회(팝업)
	 */
	public void getDutyUser(){}

	/**
	 * 책임부서 목록 저장
	 */
	public void saveLossDutyPic(){}

	/**
	 * 유실책임그룹별 유실책임파트 리스트 조회
	 */
	public void relationLossDutyGrp(){}

}
