package com.samsung.gmes2.md.loss.app;

public class MDU412M01App {

	/**
	 * 이탈원인코드 목록 초기설정
	 */
	public void initDeviCauseCode(){}

	/**
	 * 이탈원인코드 목록 조회
	 */
	public void listDeviCauseCode(){}

	/**
	 * 이탈원인코드 목록 엑셀 다운로드
	 */
	public void excelDeviCauseCode(){}

	/**
	 * 이탈원인코드 목록 저장
	 */
	public void saveDeviCauseCode(){}

}
