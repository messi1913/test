package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @author hkw
*/
@Stereotype(Stereotype.Dao)
public class TbcMdGbmInspArtDtlDEM extends AbstractDAO {


/**
* insertTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return int
*/
	@LocalName("insertTbcMdGbmInspArtDtl")
	public int insertTbcMdGbmInspArtDtl (final TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.insertTbcMdGbmInspArtDtl.001*/  \n");
			sql.append(" TBC_MD_GBM_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        INSP_ART_DTL_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdGbmInspArtDtl Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdGbmInspArtDtl Method")
	public int[][] updateBatchAllTbcMdGbmInspArtDtl (final List  tbcMdGbmInspArtDtlDVOList) {
		
		ArrayList updatetbcMdGbmInspArtDtlDVOList = new ArrayList();
		ArrayList insertttbcMdGbmInspArtDtlDVOList = new ArrayList();
		ArrayList deletetbcMdGbmInspArtDtlDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdGbmInspArtDtlDVOList.size() ; i++) {
		  TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO = (TbcMdGbmInspArtDtlDVO) tbcMdGbmInspArtDtlDVOList.get(i);
		  
		  if (tbcMdGbmInspArtDtlDVO.getSqlAction().equals("C"))
		      insertttbcMdGbmInspArtDtlDVOList.add(tbcMdGbmInspArtDtlDVO);
		  else if (tbcMdGbmInspArtDtlDVO.getSqlAction().equals("U"))
		      updatetbcMdGbmInspArtDtlDVOList.add(tbcMdGbmInspArtDtlDVO);
		  else if (tbcMdGbmInspArtDtlDVO.getSqlAction().equals("D"))
		      deletetbcMdGbmInspArtDtlDVOList.add(tbcMdGbmInspArtDtlDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdGbmInspArtDtlDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdGbmInspArtDtl(insertttbcMdGbmInspArtDtlDVOList);
          
      if (updatetbcMdGbmInspArtDtlDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdGbmInspArtDtl(updatetbcMdGbmInspArtDtlDVOList);
      
      if (deletetbcMdGbmInspArtDtlDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdGbmInspArtDtl(deletetbcMdGbmInspArtDtlDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return int
*/
	@LocalName("updateTbcMdGbmInspArtDtl")
	public int updateTbcMdGbmInspArtDtl (final TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.updateTbcMdGbmInspArtDtl.001*/  \n");
			sql.append(" TBC_MD_GBM_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        INSP_ART_CODE = ? , \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        INSP_ART_DTL_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
						}
					}
		);			
	}

/**
* deleteTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return int
*/
	@LocalName("deleteTbcMdGbmInspArtDtl")
	public int deleteTbcMdGbmInspArtDtl (final TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.deleteTbcMdGbmInspArtDtl.001*/  \n");
			sql.append(" TBC_MD_GBM_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
						}
					}
		);			
	}

/**
* selectTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return TbcMdGbmInspArtDtlDVO 
*/
	@LocalName("selectTbcMdGbmInspArtDtl")
	public TbcMdGbmInspArtDtlDVO selectTbcMdGbmInspArtDtl (final TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.selectTbcMdGbmInspArtDtl.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        INSP_ART_DTL_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_GBM_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return (TbcMdGbmInspArtDtlDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdGbmInspArtDtlDVO returnTbcMdGbmInspArtDtlDVO = new TbcMdGbmInspArtDtlDVO();
									returnTbcMdGbmInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlNm(resultSet.getString("INSP_ART_DTL_NM"));
									returnTbcMdGbmInspArtDtlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdGbmInspArtDtlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdGbmInspArtDtlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdGbmInspArtDtlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdGbmInspArtDtlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdGbmInspArtDtlDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdGbmInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdGbmInspArtDtl Method")
	public int mergeTbcMdGbmInspArtDtl (final TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO) {
		
		if ( selectTbcMdGbmInspArtDtl (tbcMdGbmInspArtDtlDVO) == null) {
			return insertTbcMdGbmInspArtDtl(tbcMdGbmInspArtDtlDVO);
		} else {
			return selectUpdateTbcMdGbmInspArtDtl (tbcMdGbmInspArtDtlDVO);
		}
	}

	/**
	 * selectUpdateTbcMdGbmInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdGbmInspArtDtl Method")
	public int selectUpdateTbcMdGbmInspArtDtl (final TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO) {
		
		TbcMdGbmInspArtDtlDVO tmpTbcMdGbmInspArtDtlDVO =  selectTbcMdGbmInspArtDtl (tbcMdGbmInspArtDtlDVO);
		if ( tbcMdGbmInspArtDtlDVO.getGbmCode() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getGbmCode()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setGbmCode(tbcMdGbmInspArtDtlDVO.getGbmCode());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getInspArtDtlCode() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getInspArtDtlCode()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setInspArtDtlCode(tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getInspArtCode() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getInspArtCode()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setInspArtCode(tbcMdGbmInspArtDtlDVO.getInspArtCode());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getProcOutGubunCode() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getProcOutGubunCode()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setProcOutGubunCode(tbcMdGbmInspArtDtlDVO.getProcOutGubunCode());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getInspArtDtlNm() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getInspArtDtlNm()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setInspArtDtlNm(tbcMdGbmInspArtDtlDVO.getInspArtDtlNm());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getUseYn() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getUseYn()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setUseYn(tbcMdGbmInspArtDtlDVO.getUseYn());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getFstRegDt() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getFstRegDt()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setFstRegDt(tbcMdGbmInspArtDtlDVO.getFstRegDt());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getFstRegerId() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getFstRegerId()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setFstRegerId(tbcMdGbmInspArtDtlDVO.getFstRegerId());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getFnlUpdDt() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getFnlUpdDt()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setFnlUpdDt(tbcMdGbmInspArtDtlDVO.getFnlUpdDt());
		}		
		if ( tbcMdGbmInspArtDtlDVO.getFnlUpderId() != null && !"".equals(tbcMdGbmInspArtDtlDVO.getFnlUpderId()) ) {
			tmpTbcMdGbmInspArtDtlDVO.setFnlUpderId(tbcMdGbmInspArtDtlDVO.getFnlUpderId());
		}		
		return updateTbcMdGbmInspArtDtl (tmpTbcMdGbmInspArtDtlDVO);
	}

/**
* insertBatchTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return int[]
*/
	@LocalName("insertBatchTbcMdGbmInspArtDtl")
	public int[] insertBatchTbcMdGbmInspArtDtl (final List tbcMdGbmInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.insertBatchTbcMdGbmInspArtDtl.001*/  \n");
			sql.append(" TBC_MD_GBM_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        INSP_ART_DTL_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO = (TbcMdGbmInspArtDtlDVO)tbcMdGbmInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdGbmInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return int[]
*/
	@LocalName("updateBatchTbcMdGbmInspArtDtl")
	public int[] updateBatchTbcMdGbmInspArtDtl (final List tbcMdGbmInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.updateBatchTbcMdGbmInspArtDtl.001*/  \n");
			sql.append(" TBC_MD_GBM_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        INSP_ART_CODE = ? , \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        INSP_ART_DTL_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO = (TbcMdGbmInspArtDtlDVO)tbcMdGbmInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlNm());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
						}
							public int getBatchSize() {
									return tbcMdGbmInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdGbmInspArtDtl Method
* 
* @ref_table TBC_MD_GBM_INSP_ART_DTL
* @return int[]
*/
	@LocalName("deleteBatchTbcMdGbmInspArtDtl")
	public int[] deleteBatchTbcMdGbmInspArtDtl (final List tbcMdGbmInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDEM.deleteBatchTbcMdGbmInspArtDtl.001*/  \n");
			sql.append(" TBC_MD_GBM_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdGbmInspArtDtlDVO tbcMdGbmInspArtDtlDVO = (TbcMdGbmInspArtDtlDVO)tbcMdGbmInspArtDtlDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbcMdGbmInspArtDtlDVO.getInspArtDtlCode());
						}
							public int getBatchSize() {
									return tbcMdGbmInspArtDtlDVOList.size();
							}
					}
		);			
	}

	
}