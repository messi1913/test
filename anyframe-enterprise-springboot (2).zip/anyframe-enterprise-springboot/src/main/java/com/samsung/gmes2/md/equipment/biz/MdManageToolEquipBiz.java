package com.samsung.gmes2.md.equipment.biz;

public class MdManageToolEquipBiz {

	/**
	 * 툴 목록 조회
	 */
	public void listToolEquip(){}

	/**
	 * 툴 목록 저장
	 */
	public void saveToolEquip(){}

}
