package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PLANT_LINE
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPlantLineDEM extends AbstractDAO {


/**
* insertTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return int
*/
	@LocalName("insertTbmMdPlantLine")
	public int insertTbmMdPlantLine (final TbmMdPlantLineDVO tbmMdPlantLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.insertTbmMdPlantLine.001*/  \n");
			sql.append(" TBM_MD_PLANT_LINE (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        GSCM_RSC_CODE , \n");
			sql.append("        ERP_WC_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getGscmRscCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getErpWcCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPlantLine Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPlantLine Method")
	public int[][] updateBatchAllTbmMdPlantLine (final List  tbmMdPlantLineDVOList) {
		
		ArrayList updatetbmMdPlantLineDVOList = new ArrayList();
		ArrayList insertttbmMdPlantLineDVOList = new ArrayList();
		ArrayList deletetbmMdPlantLineDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPlantLineDVOList.size() ; i++) {
		  TbmMdPlantLineDVO tbmMdPlantLineDVO = (TbmMdPlantLineDVO) tbmMdPlantLineDVOList.get(i);
		  
		  if (tbmMdPlantLineDVO.getSqlAction().equals("C"))
		      insertttbmMdPlantLineDVOList.add(tbmMdPlantLineDVO);
		  else if (tbmMdPlantLineDVO.getSqlAction().equals("U"))
		      updatetbmMdPlantLineDVOList.add(tbmMdPlantLineDVO);
		  else if (tbmMdPlantLineDVO.getSqlAction().equals("D"))
		      deletetbmMdPlantLineDVOList.add(tbmMdPlantLineDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPlantLineDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPlantLine(insertttbmMdPlantLineDVOList);
          
      if (updatetbmMdPlantLineDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPlantLine(updatetbmMdPlantLineDVOList);
      
      if (deletetbmMdPlantLineDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPlantLine(deletetbmMdPlantLineDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return int
*/
	@LocalName("updateTbmMdPlantLine")
	public int updateTbmMdPlantLine (final TbmMdPlantLineDVO tbmMdPlantLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.updateTbmMdPlantLine.001*/  \n");
			sql.append(" TBM_MD_PLANT_LINE \n");
			sql.append(" SET   \n");
			sql.append("        GSCM_RSC_CODE = ? , \n");
			sql.append("        ERP_WC_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantLineDVO.getGscmRscCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getErpWcCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
						}
					}
		);			
	}

/**
* deleteTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return int
*/
	@LocalName("deleteTbmMdPlantLine")
	public int deleteTbmMdPlantLine (final TbmMdPlantLineDVO tbmMdPlantLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.deleteTbmMdPlantLine.001*/  \n");
			sql.append(" TBM_MD_PLANT_LINE \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
						}
					}
		);			
	}

/**
* selectTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return TbmMdPlantLineDVO 
*/
	@LocalName("selectTbmMdPlantLine")
	public TbmMdPlantLineDVO selectTbmMdPlantLine (final TbmMdPlantLineDVO tbmMdPlantLineDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.selectTbmMdPlantLine.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        GSCM_RSC_CODE , \n");
			sql.append("        ERP_WC_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PLANT_LINE \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");

		return (TbmMdPlantLineDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPlantLineDVO returnTbmMdPlantLineDVO = new TbmMdPlantLineDVO();
									returnTbmMdPlantLineDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPlantLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdPlantLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdPlantLineDVO.setGscmRscCode(resultSet.getString("GSCM_RSC_CODE"));
									returnTbmMdPlantLineDVO.setErpWcCode(resultSet.getString("ERP_WC_CODE"));
									returnTbmMdPlantLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdPlantLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPlantLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPlantLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPlantLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPlantLineDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPlantLine Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPlantLine Method")
	public int mergeTbmMdPlantLine (final TbmMdPlantLineDVO tbmMdPlantLineDVO) {
		
		if ( selectTbmMdPlantLine (tbmMdPlantLineDVO) == null) {
			return insertTbmMdPlantLine(tbmMdPlantLineDVO);
		} else {
			return selectUpdateTbmMdPlantLine (tbmMdPlantLineDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPlantLine Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPlantLine Method")
	public int selectUpdateTbmMdPlantLine (final TbmMdPlantLineDVO tbmMdPlantLineDVO) {
		
		TbmMdPlantLineDVO tmpTbmMdPlantLineDVO =  selectTbmMdPlantLine (tbmMdPlantLineDVO);
		if ( tbmMdPlantLineDVO.getPlantCode() != null && !"".equals(tbmMdPlantLineDVO.getPlantCode()) ) {
			tmpTbmMdPlantLineDVO.setPlantCode(tbmMdPlantLineDVO.getPlantCode());
		}		
		if ( tbmMdPlantLineDVO.getFctCode() != null && !"".equals(tbmMdPlantLineDVO.getFctCode()) ) {
			tmpTbmMdPlantLineDVO.setFctCode(tbmMdPlantLineDVO.getFctCode());
		}		
		if ( tbmMdPlantLineDVO.getLineCode() != null && !"".equals(tbmMdPlantLineDVO.getLineCode()) ) {
			tmpTbmMdPlantLineDVO.setLineCode(tbmMdPlantLineDVO.getLineCode());
		}		
		if ( tbmMdPlantLineDVO.getGscmRscCode() != null && !"".equals(tbmMdPlantLineDVO.getGscmRscCode()) ) {
			tmpTbmMdPlantLineDVO.setGscmRscCode(tbmMdPlantLineDVO.getGscmRscCode());
		}		
		if ( tbmMdPlantLineDVO.getErpWcCode() != null && !"".equals(tbmMdPlantLineDVO.getErpWcCode()) ) {
			tmpTbmMdPlantLineDVO.setErpWcCode(tbmMdPlantLineDVO.getErpWcCode());
		}		
		if ( tbmMdPlantLineDVO.getUseYn() != null && !"".equals(tbmMdPlantLineDVO.getUseYn()) ) {
			tmpTbmMdPlantLineDVO.setUseYn(tbmMdPlantLineDVO.getUseYn());
		}		
		if ( tbmMdPlantLineDVO.getFstRegDt() != null && !"".equals(tbmMdPlantLineDVO.getFstRegDt()) ) {
			tmpTbmMdPlantLineDVO.setFstRegDt(tbmMdPlantLineDVO.getFstRegDt());
		}		
		if ( tbmMdPlantLineDVO.getFstRegerId() != null && !"".equals(tbmMdPlantLineDVO.getFstRegerId()) ) {
			tmpTbmMdPlantLineDVO.setFstRegerId(tbmMdPlantLineDVO.getFstRegerId());
		}		
		if ( tbmMdPlantLineDVO.getFnlUpdDt() != null && !"".equals(tbmMdPlantLineDVO.getFnlUpdDt()) ) {
			tmpTbmMdPlantLineDVO.setFnlUpdDt(tbmMdPlantLineDVO.getFnlUpdDt());
		}		
		if ( tbmMdPlantLineDVO.getFnlUpderId() != null && !"".equals(tbmMdPlantLineDVO.getFnlUpderId()) ) {
			tmpTbmMdPlantLineDVO.setFnlUpderId(tbmMdPlantLineDVO.getFnlUpderId());
		}		
		return updateTbmMdPlantLine (tmpTbmMdPlantLineDVO);
	}

/**
* insertBatchTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return int[]
*/
	@LocalName("insertBatchTbmMdPlantLine")
	public int[] insertBatchTbmMdPlantLine (final List tbmMdPlantLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.insertBatchTbmMdPlantLine.001*/  \n");
			sql.append(" TBM_MD_PLANT_LINE (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        GSCM_RSC_CODE , \n");
			sql.append("        ERP_WC_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantLineDVO tbmMdPlantLineDVO = (TbmMdPlantLineDVO)tbmMdPlantLineDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getGscmRscCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getErpWcCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPlantLineDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return int[]
*/
	@LocalName("updateBatchTbmMdPlantLine")
	public int[] updateBatchTbmMdPlantLine (final List tbmMdPlantLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.updateBatchTbmMdPlantLine.001*/  \n");
			sql.append(" TBM_MD_PLANT_LINE \n");
			sql.append(" SET   \n");
			sql.append("        GSCM_RSC_CODE = ? , \n");
			sql.append("        ERP_WC_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantLineDVO tbmMdPlantLineDVO = (TbmMdPlantLineDVO)tbmMdPlantLineDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantLineDVO.getGscmRscCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getErpWcCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
						}
							public int getBatchSize() {
									return tbmMdPlantLineDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPlantLine Method
* 
* @ref_table TBM_MD_PLANT_LINE
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPlantLine")
	public int[] deleteBatchTbmMdPlantLine (final List tbmMdPlantLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantLineDEM.deleteBatchTbmMdPlantLine.001*/  \n");
			sql.append(" TBM_MD_PLANT_LINE \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantLineDVO tbmMdPlantLineDVO = (TbmMdPlantLineDVO)tbmMdPlantLineDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantLineDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdPlantLineDVO.getLineCode());
						}
							public int getBatchSize() {
									return tbmMdPlantLineDVOList.size();
							}
					}
		);			
	}

	
}