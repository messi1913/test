package com.samsung.gmes2.bi.edu.chris.app;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.bi.edu.chris.vo.BiU007M00SVO;

@Service
public class BiU007M00App {

	public BiU007M00SVO getEmpInfoList(BiU007M00SVO biU007M00SVO){
		
		
		String empAge = biU007M00SVO.getEmpAgeDVO().getEmpAge();
		Map inputMap = new HashMap();
		inputMap.put("empAge", empAge);
		List dList000 = BaseUtil.getBean(BiU007M00DQM.class).dList000(inputMap);
		
		biU007M00SVO.setEmpInfoDVOList(dList000);
		
		return biU007M00SVO;
		
	}
}
