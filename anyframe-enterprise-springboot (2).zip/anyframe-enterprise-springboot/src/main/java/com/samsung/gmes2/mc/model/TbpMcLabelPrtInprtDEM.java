package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbpMcLabelPrtInprtDEM extends AbstractDAO {


/**
* insertTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return int
*/
	@LocalName("insertTbpMcLabelPrtInprt")
	public int insertTbpMcLabelPrtInprt (final TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.insertTbpMcLabelPrtInprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_INPRT (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        PLANT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPlantCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbpMcLabelPrtInprt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbpMcLabelPrtInprt Method")
	public int[][] updateBatchAllTbpMcLabelPrtInprt (final List  tbpMcLabelPrtInprtDVOList) {
		
		ArrayList updatetbpMcLabelPrtInprtDVOList = new ArrayList();
		ArrayList insertttbpMcLabelPrtInprtDVOList = new ArrayList();
		ArrayList deletetbpMcLabelPrtInprtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbpMcLabelPrtInprtDVOList.size() ; i++) {
		  TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO = (TbpMcLabelPrtInprtDVO) tbpMcLabelPrtInprtDVOList.get(i);
		  
		  if (tbpMcLabelPrtInprtDVO.getSqlAction().equals("C"))
		      insertttbpMcLabelPrtInprtDVOList.add(tbpMcLabelPrtInprtDVO);
		  else if (tbpMcLabelPrtInprtDVO.getSqlAction().equals("U"))
		      updatetbpMcLabelPrtInprtDVOList.add(tbpMcLabelPrtInprtDVO);
		  else if (tbpMcLabelPrtInprtDVO.getSqlAction().equals("D"))
		      deletetbpMcLabelPrtInprtDVOList.add(tbpMcLabelPrtInprtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbpMcLabelPrtInprtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbpMcLabelPrtInprt(insertttbpMcLabelPrtInprtDVOList);
          
      if (updatetbpMcLabelPrtInprtDVOList.size() >0)
          resultValues[1] = updateBatchTbpMcLabelPrtInprt(updatetbpMcLabelPrtInprtDVOList);
      
      if (deletetbpMcLabelPrtInprtDVOList.size() >0)
          resultValues[2] = deleteBatchTbpMcLabelPrtInprt(deletetbpMcLabelPrtInprtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return int
*/
	@LocalName("updateTbpMcLabelPrtInprt")
	public int updateTbpMcLabelPrtInprt (final TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.updateTbpMcLabelPrtInprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_INPRT \n");
			sql.append(" SET   \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        PLANT_CODE = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPlantCode());

							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
						}
					}
		);			
	}

/**
* deleteTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return int
*/
	@LocalName("deleteTbpMcLabelPrtInprt")
	public int deleteTbpMcLabelPrtInprt (final TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.deleteTbpMcLabelPrtInprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_INPRT \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
						}
					}
		);			
	}

/**
* selectTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return TbpMcLabelPrtInprtDVO 
*/
	@LocalName("selectTbpMcLabelPrtInprt")
	public TbpMcLabelPrtInprtDVO selectTbpMcLabelPrtInprt (final TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.selectTbpMcLabelPrtInprt.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        PLANT_CODE \n");
			sql.append("   FROM TBP_MC_LABEL_PRT_INPRT \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return (TbpMcLabelPrtInprtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbpMcLabelPrtInprtDVO returnTbpMcLabelPrtInprtDVO = new TbpMcLabelPrtInprtDVO();
									returnTbpMcLabelPrtInprtDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbpMcLabelPrtInprtDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbpMcLabelPrtInprtDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbpMcLabelPrtInprtDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbpMcLabelPrtInprtDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbpMcLabelPrtInprtDVO.setRePrtYn(resultSet.getString("RE_PRT_YN"));
									returnTbpMcLabelPrtInprtDVO.setRePrtRsn(resultSet.getString("RE_PRT_RSN"));
									returnTbpMcLabelPrtInprtDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									return returnTbpMcLabelPrtInprtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbpMcLabelPrtInprt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbpMcLabelPrtInprt Method")
	public int mergeTbpMcLabelPrtInprt (final TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO) {
		
		if ( selectTbpMcLabelPrtInprt (tbpMcLabelPrtInprtDVO) == null) {
			return insertTbpMcLabelPrtInprt(tbpMcLabelPrtInprtDVO);
		} else {
			return selectUpdateTbpMcLabelPrtInprt (tbpMcLabelPrtInprtDVO);
		}
	}

	/**
	 * selectUpdateTbpMcLabelPrtInprt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbpMcLabelPrtInprt Method")
	public int selectUpdateTbpMcLabelPrtInprt (final TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO) {
		
		TbpMcLabelPrtInprtDVO tmpTbpMcLabelPrtInprtDVO =  selectTbpMcLabelPrtInprt (tbpMcLabelPrtInprtDVO);
		if ( tbpMcLabelPrtInprtDVO.getNmgId() != null && !"".equals(tbpMcLabelPrtInprtDVO.getNmgId()) ) {
			tmpTbpMcLabelPrtInprtDVO.setNmgId(tbpMcLabelPrtInprtDVO.getNmgId());
		}		
		if ( tbpMcLabelPrtInprtDVO.getPrtDt() != null && !"".equals(tbpMcLabelPrtInprtDVO.getPrtDt()) ) {
			tmpTbpMcLabelPrtInprtDVO.setPrtDt(tbpMcLabelPrtInprtDVO.getPrtDt());
		}		
		if ( tbpMcLabelPrtInprtDVO.getModelCode() != null && !"".equals(tbpMcLabelPrtInprtDVO.getModelCode()) ) {
			tmpTbpMcLabelPrtInprtDVO.setModelCode(tbpMcLabelPrtInprtDVO.getModelCode());
		}		
		if ( tbpMcLabelPrtInprtDVO.getLabelId() != null && !"".equals(tbpMcLabelPrtInprtDVO.getLabelId()) ) {
			tmpTbpMcLabelPrtInprtDVO.setLabelId(tbpMcLabelPrtInprtDVO.getLabelId());
		}		
		if ( tbpMcLabelPrtInprtDVO.getPrterId() != null && !"".equals(tbpMcLabelPrtInprtDVO.getPrterId()) ) {
			tmpTbpMcLabelPrtInprtDVO.setPrterId(tbpMcLabelPrtInprtDVO.getPrterId());
		}		
		if ( tbpMcLabelPrtInprtDVO.getRePrtYn() != null && !"".equals(tbpMcLabelPrtInprtDVO.getRePrtYn()) ) {
			tmpTbpMcLabelPrtInprtDVO.setRePrtYn(tbpMcLabelPrtInprtDVO.getRePrtYn());
		}		
		if ( tbpMcLabelPrtInprtDVO.getRePrtRsn() != null && !"".equals(tbpMcLabelPrtInprtDVO.getRePrtRsn()) ) {
			tmpTbpMcLabelPrtInprtDVO.setRePrtRsn(tbpMcLabelPrtInprtDVO.getRePrtRsn());
		}		
		if ( tbpMcLabelPrtInprtDVO.getPlantCode() != null && !"".equals(tbpMcLabelPrtInprtDVO.getPlantCode()) ) {
			tmpTbpMcLabelPrtInprtDVO.setPlantCode(tbpMcLabelPrtInprtDVO.getPlantCode());
		}		
		return updateTbpMcLabelPrtInprt (tmpTbpMcLabelPrtInprtDVO);
	}

/**
* insertBatchTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return int[]
*/
	@LocalName("insertBatchTbpMcLabelPrtInprt")
	public int[] insertBatchTbpMcLabelPrtInprt (final List tbpMcLabelPrtInprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.insertBatchTbpMcLabelPrtInprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_INPRT (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        PLANT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO = (TbpMcLabelPrtInprtDVO)tbpMcLabelPrtInprtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPlantCode());

						}
							public int getBatchSize() {
									return tbpMcLabelPrtInprtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return int[]
*/
	@LocalName("updateBatchTbpMcLabelPrtInprt")
	public int[] updateBatchTbpMcLabelPrtInprt (final List tbpMcLabelPrtInprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.updateBatchTbpMcLabelPrtInprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_INPRT \n");
			sql.append(" SET   \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        PLANT_CODE = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO = (TbpMcLabelPrtInprtDVO)tbpMcLabelPrtInprtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPlantCode());

							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLabelPrtInprtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbpMcLabelPrtInprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_INPRT
* @return int[]
*/
	@LocalName("deleteBatchTbpMcLabelPrtInprt")
	public int[] deleteBatchTbpMcLabelPrtInprt (final List tbpMcLabelPrtInprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLabelPrtInprtDEM.deleteBatchTbpMcLabelPrtInprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_INPRT \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtInprtDVO tbpMcLabelPrtInprtDVO = (TbpMcLabelPrtInprtDVO)tbpMcLabelPrtInprtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getNmgId());
							ps.setString(psCount++, tbpMcLabelPrtInprtDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLabelPrtInprtDVOList.size();
							}
					}
		);			
	}

	
}