package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbhMdVendDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String vendCode;

	@Length(30) 
	private String vendGubunCode;

	@Length(17) 
	private String histTsp;

	@Length(500) 
	private String vendNm;

	@Length(30) 
	private String vendCtracCode;

	@Length(1000) 
	private String vendAddr;

	@Length(500) 
	private String dlgrNm;

	@Length(50) 
	private String contctNo;

	@Length(30) 
	private String vendTypeCode;

	@Length(30) 
	private String prodGubunCode;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;

	@Length(50) 
	private String evtNm;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getVendCode() {
		this.vendCode = super.getValue(1);
		return this.vendCode;
	}

	public void setVendCode(String vendCode) {
        super.setValue(1, vendCode);
		this.vendCode = vendCode;
	}
	
	public String getVendGubunCode() {
		this.vendGubunCode = super.getValue(2);
		return this.vendGubunCode;
	}

	public void setVendGubunCode(String vendGubunCode) {
        super.setValue(2, vendGubunCode);
		this.vendGubunCode = vendGubunCode;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(3);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(3, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getVendNm() {
		this.vendNm = super.getValue(4);
		return this.vendNm;
	}

	public void setVendNm(String vendNm) {
        super.setValue(4, vendNm);
		this.vendNm = vendNm;
	}
	
	public String getVendCtracCode() {
		this.vendCtracCode = super.getValue(5);
		return this.vendCtracCode;
	}

	public void setVendCtracCode(String vendCtracCode) {
        super.setValue(5, vendCtracCode);
		this.vendCtracCode = vendCtracCode;
	}
	
	public String getVendAddr() {
		this.vendAddr = super.getValue(6);
		return this.vendAddr;
	}

	public void setVendAddr(String vendAddr) {
        super.setValue(6, vendAddr);
		this.vendAddr = vendAddr;
	}
	
	public String getDlgrNm() {
		this.dlgrNm = super.getValue(7);
		return this.dlgrNm;
	}

	public void setDlgrNm(String dlgrNm) {
        super.setValue(7, dlgrNm);
		this.dlgrNm = dlgrNm;
	}
	
	public String getContctNo() {
		this.contctNo = super.getValue(8);
		return this.contctNo;
	}

	public void setContctNo(String contctNo) {
        super.setValue(8, contctNo);
		this.contctNo = contctNo;
	}
	
	public String getVendTypeCode() {
		this.vendTypeCode = super.getValue(9);
		return this.vendTypeCode;
	}

	public void setVendTypeCode(String vendTypeCode) {
        super.setValue(9, vendTypeCode);
		this.vendTypeCode = vendTypeCode;
	}
	
	public String getProdGubunCode() {
		this.prodGubunCode = super.getValue(10);
		return this.prodGubunCode;
	}

	public void setProdGubunCode(String prodGubunCode) {
        super.setValue(10, prodGubunCode);
		this.prodGubunCode = prodGubunCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(11);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(11, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(12);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(12, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(13);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(13, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(14);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(14, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(15);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(15, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
	public String getEvtNm() {
		this.evtNm = super.getValue(16);
		return this.evtNm;
	}

	public void setEvtNm(String evtNm) {
        super.setValue(16, evtNm);
		this.evtNm = evtNm;
	}
	
}