package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbhMdLineDVO extends AbstractVo {

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String lineCode;

	@Length(17) 
	private String histTsp;

	@Length(500) 
	private String lineNm;

	@Length(30) 
	private String mfgPartCode;

	@Length(30) 
	private String procGubunCode;

	@Length(30) 
	private String lineFormCode;

	@Length(2000) 
	private String lineLocDesc;

	@Length(1) 
	private String outsYn;

	@Length(30) 
	private String tbGubunCode;

	@Length(30) 
	private String cellTypeCode;

	@Length(1) 
	private String planManualCreYn;

	@Length(1) 
	private String mainPackLineInlineYn;

	@Length(1) 
	private String catvUseYn;

	@Length(1) 
	private String boardUseYn;

	@Length(6) 
	private String workStartHms;

	@Length(30) 
	private String labelWrtCode;

	@Length(1) 
	private String ttCalcYn;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;

	@Length(50) 
	private String evtNm;


	public String getFctCode() {
		this.fctCode = super.getValue(0);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(0, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(1);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(1, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(2);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(2, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getLineNm() {
		this.lineNm = super.getValue(3);
		return this.lineNm;
	}

	public void setLineNm(String lineNm) {
        super.setValue(3, lineNm);
		this.lineNm = lineNm;
	}
	
	public String getMfgPartCode() {
		this.mfgPartCode = super.getValue(4);
		return this.mfgPartCode;
	}

	public void setMfgPartCode(String mfgPartCode) {
        super.setValue(4, mfgPartCode);
		this.mfgPartCode = mfgPartCode;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue(5);
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue(5, procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getLineFormCode() {
		this.lineFormCode = super.getValue(6);
		return this.lineFormCode;
	}

	public void setLineFormCode(String lineFormCode) {
        super.setValue(6, lineFormCode);
		this.lineFormCode = lineFormCode;
	}
	
	public String getLineLocDesc() {
		this.lineLocDesc = super.getValue(7);
		return this.lineLocDesc;
	}

	public void setLineLocDesc(String lineLocDesc) {
        super.setValue(7, lineLocDesc);
		this.lineLocDesc = lineLocDesc;
	}
	
	public String getOutsYn() {
		this.outsYn = super.getValue(8);
		return this.outsYn;
	}

	public void setOutsYn(String outsYn) {
        super.setValue(8, outsYn);
		this.outsYn = outsYn;
	}
	
	public String getTbGubunCode() {
		this.tbGubunCode = super.getValue(9);
		return this.tbGubunCode;
	}

	public void setTbGubunCode(String tbGubunCode) {
        super.setValue(9, tbGubunCode);
		this.tbGubunCode = tbGubunCode;
	}
	
	public String getCellTypeCode() {
		this.cellTypeCode = super.getValue(10);
		return this.cellTypeCode;
	}

	public void setCellTypeCode(String cellTypeCode) {
        super.setValue(10, cellTypeCode);
		this.cellTypeCode = cellTypeCode;
	}
	
	public String getPlanManualCreYn() {
		this.planManualCreYn = super.getValue(11);
		return this.planManualCreYn;
	}

	public void setPlanManualCreYn(String planManualCreYn) {
        super.setValue(11, planManualCreYn);
		this.planManualCreYn = planManualCreYn;
	}
	
	public String getMainPackLineInlineYn() {
		this.mainPackLineInlineYn = super.getValue(12);
		return this.mainPackLineInlineYn;
	}

	public void setMainPackLineInlineYn(String mainPackLineInlineYn) {
        super.setValue(12, mainPackLineInlineYn);
		this.mainPackLineInlineYn = mainPackLineInlineYn;
	}
	
	public String getCatvUseYn() {
		this.catvUseYn = super.getValue(13);
		return this.catvUseYn;
	}

	public void setCatvUseYn(String catvUseYn) {
        super.setValue(13, catvUseYn);
		this.catvUseYn = catvUseYn;
	}
	
	public String getBoardUseYn() {
		this.boardUseYn = super.getValue(14);
		return this.boardUseYn;
	}

	public void setBoardUseYn(String boardUseYn) {
        super.setValue(14, boardUseYn);
		this.boardUseYn = boardUseYn;
	}
	
	public String getWorkStartHms() {
		this.workStartHms = super.getValue(15);
		return this.workStartHms;
	}

	public void setWorkStartHms(String workStartHms) {
        super.setValue(15, workStartHms);
		this.workStartHms = workStartHms;
	}
	
	public String getLabelWrtCode() {
		this.labelWrtCode = super.getValue(16);
		return this.labelWrtCode;
	}

	public void setLabelWrtCode(String labelWrtCode) {
        super.setValue(16, labelWrtCode);
		this.labelWrtCode = labelWrtCode;
	}
	
	public String getTtCalcYn() {
		this.ttCalcYn = super.getValue(17);
		return this.ttCalcYn;
	}

	public void setTtCalcYn(String ttCalcYn) {
        super.setValue(17, ttCalcYn);
		this.ttCalcYn = ttCalcYn;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue(18);
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue(18, fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(19);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(19, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(20);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(20, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(21);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(21, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(22);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(22, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(23);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(23, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
	public String getEvtNm() {
		this.evtNm = super.getValue(24);
		return this.evtNm;
	}

	public void setEvtNm(String evtNm) {
        super.setValue(24, evtNm);
		this.evtNm = evtNm;
	}
	
}