package com.samsung.gmes2.bi.edu.chris.vo;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 교육용 추후 삭제요청
 * @stereotype DAOVO
 * @author Chris
 */
@LocalName("직원정보DVO")
public class EmpInfoDVO extends AbstractDVO {

	@Length(6) @NotNull
	private String empNo;

	@Length(20) 
	private String empName;

	@Length(3) 
	private BigDecimal empAge;

	@Length(2) 
	private String deptCode;

	@Length(2) 
	private String titleCode;

	@Length(100) 
	private String mailAddr;


	public String getEmpNo() {
		this.empNo = super.getValue("empNo");
		return this.empNo;
	}

	public void setEmpNo(String empNo) {
        super.setValue("empNo", empNo);
		this.empNo = empNo;
	}
	
	public String getEmpName() {
		this.empName = super.getValue("empName");
		return this.empName;
	}

	public void setEmpName(String empName) {
        super.setValue("empName", empName);
		this.empName = empName;
	}
	
	public BigDecimal getEmpAge() {
		this.empAge = super.getValue("empAge");
		return this.empAge;
	}

	public void setEmpAge(BigDecimal empAge) {
        super.setValue("empAge", empAge);
		this.empAge = empAge;
	}
	
	public String getDeptCode() {
		this.deptCode = super.getValue("deptCode");
		return this.deptCode;
	}

	public void setDeptCode(String deptCode) {
        super.setValue("deptCode", deptCode);
		this.deptCode = deptCode;
	}
	
	public String getTitleCode() {
		this.titleCode = super.getValue("titleCode");
		return this.titleCode;
	}

	public void setTitleCode(String titleCode) {
        super.setValue("titleCode", titleCode);
		this.titleCode = titleCode;
	}
	
	public String getMailAddr() {
		this.mailAddr = super.getValue("mailAddr");
		return this.mailAddr;
	}

	public void setMailAddr(String mailAddr) {
        super.setValue("mailAddr", mailAddr);
		this.mailAddr = mailAddr;
	}
	
}