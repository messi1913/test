package com.samsung.gmes2.mc.mcu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 한글명 : 모델라벨 조회
 * 작성일 : 2011.06.29
 * 작성자 : 심 재 국
 * 작업상태 : 완료
 * 개요 :
 * 모델 코드만을 받기위한 DVO
 * @stereotype DAOVO
 * @author shim
 */
@LocalName("모델 코드")
public class McU611M0007DVO extends AbstractDVO {

	@LocalName("모델 코드") @Length(30) 
	private String comCode;


	/**
	 * 모델 코드 Getter Method
	 * 
	 * @return 모델 코드
	 */
	@LocalName("모델 코드 Getter Method")
	public String getComCode() {
		this.comCode = super.getValue("comCode");
		return this.comCode;
	}

	/**
	 * 모델 코드 Setter Method
	 * 
	 * @param String 모델 코드
	 */
	@LocalName("모델 코드 Setter Method")
	public void setComCode(String comCode) {
        super.setValue("comCode", comCode);
		this.comCode = comCode;
	}
	
}