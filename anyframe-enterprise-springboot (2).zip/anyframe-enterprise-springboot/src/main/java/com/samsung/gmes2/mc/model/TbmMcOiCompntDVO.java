package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbmMcOiCompntDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String frmNo;

	@Length(50) @NotNull
	private String pgmRevNo;

	@Length(50) @NotNull
	private String compntRevNo;

	@Length(50) @NotNull
	private String pgmCode;

	@Length(50) @NotNull
	private String standCompntCode;


	public String getFrmNo() {
		this.frmNo = super.getValue("frmNo");
		return this.frmNo;
	}

	public void setFrmNo(String frmNo) {
        super.setValue("frmNo", frmNo);
		this.frmNo = frmNo;
	}
	
	public String getPgmRevNo() {
		this.pgmRevNo = super.getValue("pgmRevNo");
		return this.pgmRevNo;
	}

	public void setPgmRevNo(String pgmRevNo) {
        super.setValue("pgmRevNo", pgmRevNo);
		this.pgmRevNo = pgmRevNo;
	}
	
	public String getCompntRevNo() {
		this.compntRevNo = super.getValue("compntRevNo");
		return this.compntRevNo;
	}

	public void setCompntRevNo(String compntRevNo) {
        super.setValue("compntRevNo", compntRevNo);
		this.compntRevNo = compntRevNo;
	}
	
	public String getPgmCode() {
		this.pgmCode = super.getValue("pgmCode");
		return this.pgmCode;
	}

	public void setPgmCode(String pgmCode) {
        super.setValue("pgmCode", pgmCode);
		this.pgmCode = pgmCode;
	}
	
	public String getStandCompntCode() {
		this.standCompntCode = super.getValue("standCompntCode");
		return this.standCompntCode;
	}

	public void setStandCompntCode(String standCompntCode) {
        super.setValue("standCompntCode", standCompntCode);
		this.standCompntCode = standCompntCode;
	}
	
}