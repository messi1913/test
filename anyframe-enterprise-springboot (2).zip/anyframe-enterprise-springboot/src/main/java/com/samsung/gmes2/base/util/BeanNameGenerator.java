package com.samsung.gmes2.base.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.stereotype.Service;

public class BeanNameGenerator implements org.springframework.beans.factory.support.BeanNameGenerator
{
    private static final Logger logger = LoggerFactory.getLogger( BeanNameGenerator.class );

    @Override
    public String generateBeanName( BeanDefinition definition, BeanDefinitionRegistry registry )
    {
        try
        {
            Class<?> clazz = Class.forName( definition.getBeanClassName( ) );
            Service svc = clazz.getAnnotation( Service.class );
            return svc == null || BaseUtil.isEmpty( svc.value( ) ) ? clazz.getName( ) : svc.value( );

        }
        catch ( ClassNotFoundException e )
        {
            logger.error( e.getMessage( ), e );
        }
        return definition.getBeanClassName( );
    }

}
