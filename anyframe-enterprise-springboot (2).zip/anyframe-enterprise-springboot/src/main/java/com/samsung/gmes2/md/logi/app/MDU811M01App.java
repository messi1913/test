package com.samsung.gmes2.md.logi.app;

public class MDU811M01App {

	/**
	 * BCR Port 목록 초기설정
	 */
	public void initBcrPortInfo(){}

	/**
	 * BCR Port 목록 조회
	 */
	public void listBcrPortInfo(){}

	/**
	 * BCR Port 목록 엑셀 다운로드
	 */
	public void excelBcrPortInfo(){}

	/**
	 * BCR Port 목록 등록/수정 초기설정
	 */
	public void editBcrPortInfo(){}

	/**
	 * BCR Port 목록 저장
	 */
	public void saveBcrPortInfo(){}

}
