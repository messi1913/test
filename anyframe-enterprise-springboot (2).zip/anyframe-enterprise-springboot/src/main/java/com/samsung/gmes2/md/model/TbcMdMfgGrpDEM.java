package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MFG_GRP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMfgGrpDEM extends AbstractDAO {


/**
* insertTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return int
*/
	@LocalName("insertTbcMdMfgGrp")
	public int insertTbcMdMfgGrp (final TbcMdMfgGrpDVO tbcMdMfgGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.insertTbcMdMfgGrp.001*/  \n");
			sql.append(" TBC_MD_MFG_GRP (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_GRP_CODE , \n");
			sql.append("        MFG_GRP_NM , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        GRP_RPRS_EMP_NO , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpNm());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getGrpRprsEmpNo());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getOutsYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdMfgGrp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdMfgGrp Method")
	public int[][] updateBatchAllTbcMdMfgGrp (final List  tbcMdMfgGrpDVOList) {
		
		ArrayList updatetbcMdMfgGrpDVOList = new ArrayList();
		ArrayList insertttbcMdMfgGrpDVOList = new ArrayList();
		ArrayList deletetbcMdMfgGrpDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdMfgGrpDVOList.size() ; i++) {
		  TbcMdMfgGrpDVO tbcMdMfgGrpDVO = (TbcMdMfgGrpDVO) tbcMdMfgGrpDVOList.get(i);
		  
		  if (tbcMdMfgGrpDVO.getSqlAction().equals("C"))
		      insertttbcMdMfgGrpDVOList.add(tbcMdMfgGrpDVO);
		  else if (tbcMdMfgGrpDVO.getSqlAction().equals("U"))
		      updatetbcMdMfgGrpDVOList.add(tbcMdMfgGrpDVO);
		  else if (tbcMdMfgGrpDVO.getSqlAction().equals("D"))
		      deletetbcMdMfgGrpDVOList.add(tbcMdMfgGrpDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdMfgGrpDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdMfgGrp(insertttbcMdMfgGrpDVOList);
          
      if (updatetbcMdMfgGrpDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdMfgGrp(updatetbcMdMfgGrpDVOList);
      
      if (deletetbcMdMfgGrpDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdMfgGrp(deletetbcMdMfgGrpDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return int
*/
	@LocalName("updateTbcMdMfgGrp")
	public int updateTbcMdMfgGrp (final TbcMdMfgGrpDVO tbcMdMfgGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.updateTbcMdMfgGrp.001*/  \n");
			sql.append(" TBC_MD_MFG_GRP \n");
			sql.append(" SET   \n");
			sql.append("        MFG_GRP_NM = ? , \n");
			sql.append("        MFG_TEAM_CODE = ? , \n");
			sql.append("        GRP_RPRS_EMP_NO = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_GRP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpNm());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getGrpRprsEmpNo());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getOutsYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
						}
					}
		);			
	}

/**
* deleteTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return int
*/
	@LocalName("deleteTbcMdMfgGrp")
	public int deleteTbcMdMfgGrp (final TbcMdMfgGrpDVO tbcMdMfgGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.deleteTbcMdMfgGrp.001*/  \n");
			sql.append(" TBC_MD_MFG_GRP \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_GRP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
						}
					}
		);			
	}

/**
* selectTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return TbcMdMfgGrpDVO 
*/
	@LocalName("selectTbcMdMfgGrp")
	public TbcMdMfgGrpDVO selectTbcMdMfgGrp (final TbcMdMfgGrpDVO tbcMdMfgGrpDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.selectTbcMdMfgGrp.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_GRP_CODE , \n");
			sql.append("        MFG_GRP_NM , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        GRP_RPRS_EMP_NO , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MFG_GRP \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_GRP_CODE = ? \n");

		return (TbcMdMfgGrpDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdMfgGrpDVO returnTbcMdMfgGrpDVO = new TbcMdMfgGrpDVO();
									returnTbcMdMfgGrpDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpNm(resultSet.getString("MFG_GRP_NM"));
									returnTbcMdMfgGrpDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgGrpDVO.setGrpRprsEmpNo(resultSet.getString("GRP_RPRS_EMP_NO"));
									returnTbcMdMfgGrpDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdMfgGrpDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgGrpDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgGrpDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgGrpDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgGrpDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgGrpDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgGrpDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdMfgGrp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdMfgGrp Method")
	public int mergeTbcMdMfgGrp (final TbcMdMfgGrpDVO tbcMdMfgGrpDVO) {
		
		if ( selectTbcMdMfgGrp (tbcMdMfgGrpDVO) == null) {
			return insertTbcMdMfgGrp(tbcMdMfgGrpDVO);
		} else {
			return selectUpdateTbcMdMfgGrp (tbcMdMfgGrpDVO);
		}
	}

	/**
	 * selectUpdateTbcMdMfgGrp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdMfgGrp Method")
	public int selectUpdateTbcMdMfgGrp (final TbcMdMfgGrpDVO tbcMdMfgGrpDVO) {
		
		TbcMdMfgGrpDVO tmpTbcMdMfgGrpDVO =  selectTbcMdMfgGrp (tbcMdMfgGrpDVO);
		if ( tbcMdMfgGrpDVO.getFctCode() != null && !"".equals(tbcMdMfgGrpDVO.getFctCode()) ) {
			tmpTbcMdMfgGrpDVO.setFctCode(tbcMdMfgGrpDVO.getFctCode());
		}		
		if ( tbcMdMfgGrpDVO.getMfgGrpCode() != null && !"".equals(tbcMdMfgGrpDVO.getMfgGrpCode()) ) {
			tmpTbcMdMfgGrpDVO.setMfgGrpCode(tbcMdMfgGrpDVO.getMfgGrpCode());
		}		
		if ( tbcMdMfgGrpDVO.getMfgGrpNm() != null && !"".equals(tbcMdMfgGrpDVO.getMfgGrpNm()) ) {
			tmpTbcMdMfgGrpDVO.setMfgGrpNm(tbcMdMfgGrpDVO.getMfgGrpNm());
		}		
		if ( tbcMdMfgGrpDVO.getMfgTeamCode() != null && !"".equals(tbcMdMfgGrpDVO.getMfgTeamCode()) ) {
			tmpTbcMdMfgGrpDVO.setMfgTeamCode(tbcMdMfgGrpDVO.getMfgTeamCode());
		}		
		if ( tbcMdMfgGrpDVO.getGrpRprsEmpNo() != null && !"".equals(tbcMdMfgGrpDVO.getGrpRprsEmpNo()) ) {
			tmpTbcMdMfgGrpDVO.setGrpRprsEmpNo(tbcMdMfgGrpDVO.getGrpRprsEmpNo());
		}		
		if ( tbcMdMfgGrpDVO.getOutsYn() != null && !"".equals(tbcMdMfgGrpDVO.getOutsYn()) ) {
			tmpTbcMdMfgGrpDVO.setOutsYn(tbcMdMfgGrpDVO.getOutsYn());
		}		
		if ( tbcMdMfgGrpDVO.getFnlAcrsReflYn() != null && !"".equals(tbcMdMfgGrpDVO.getFnlAcrsReflYn()) ) {
			tmpTbcMdMfgGrpDVO.setFnlAcrsReflYn(tbcMdMfgGrpDVO.getFnlAcrsReflYn());
		}		
		if ( tbcMdMfgGrpDVO.getUseYn() != null && !"".equals(tbcMdMfgGrpDVO.getUseYn()) ) {
			tmpTbcMdMfgGrpDVO.setUseYn(tbcMdMfgGrpDVO.getUseYn());
		}		
		if ( tbcMdMfgGrpDVO.getFstRegDt() != null && !"".equals(tbcMdMfgGrpDVO.getFstRegDt()) ) {
			tmpTbcMdMfgGrpDVO.setFstRegDt(tbcMdMfgGrpDVO.getFstRegDt());
		}		
		if ( tbcMdMfgGrpDVO.getFstRegerId() != null && !"".equals(tbcMdMfgGrpDVO.getFstRegerId()) ) {
			tmpTbcMdMfgGrpDVO.setFstRegerId(tbcMdMfgGrpDVO.getFstRegerId());
		}		
		if ( tbcMdMfgGrpDVO.getFnlUpdDt() != null && !"".equals(tbcMdMfgGrpDVO.getFnlUpdDt()) ) {
			tmpTbcMdMfgGrpDVO.setFnlUpdDt(tbcMdMfgGrpDVO.getFnlUpdDt());
		}		
		if ( tbcMdMfgGrpDVO.getFnlUpderId() != null && !"".equals(tbcMdMfgGrpDVO.getFnlUpderId()) ) {
			tmpTbcMdMfgGrpDVO.setFnlUpderId(tbcMdMfgGrpDVO.getFnlUpderId());
		}		
		return updateTbcMdMfgGrp (tmpTbcMdMfgGrpDVO);
	}

/**
* insertBatchTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return int[]
*/
	@LocalName("insertBatchTbcMdMfgGrp")
	public int[] insertBatchTbcMdMfgGrp (final List tbcMdMfgGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.insertBatchTbcMdMfgGrp.001*/  \n");
			sql.append(" TBC_MD_MFG_GRP (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_GRP_CODE , \n");
			sql.append("        MFG_GRP_NM , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        GRP_RPRS_EMP_NO , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgGrpDVO tbcMdMfgGrpDVO = (TbcMdMfgGrpDVO)tbcMdMfgGrpDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpNm());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getGrpRprsEmpNo());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getOutsYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdMfgGrpDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return int[]
*/
	@LocalName("updateBatchTbcMdMfgGrp")
	public int[] updateBatchTbcMdMfgGrp (final List tbcMdMfgGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.updateBatchTbcMdMfgGrp.001*/  \n");
			sql.append(" TBC_MD_MFG_GRP \n");
			sql.append(" SET   \n");
			sql.append("        MFG_GRP_NM = ? , \n");
			sql.append("        MFG_TEAM_CODE = ? , \n");
			sql.append("        GRP_RPRS_EMP_NO = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_GRP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgGrpDVO tbcMdMfgGrpDVO = (TbcMdMfgGrpDVO)tbcMdMfgGrpDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpNm());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getGrpRprsEmpNo());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getOutsYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
						}
							public int getBatchSize() {
									return tbcMdMfgGrpDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdMfgGrp Method
* 
* @ref_table TBC_MD_MFG_GRP
* @return int[]
*/
	@LocalName("deleteBatchTbcMdMfgGrp")
	public int[] deleteBatchTbcMdMfgGrp (final List tbcMdMfgGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMfgGrpDEM.deleteBatchTbcMdMfgGrp.001*/  \n");
			sql.append(" TBC_MD_MFG_GRP \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_GRP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgGrpDVO tbcMdMfgGrpDVO = (TbcMdMfgGrpDVO)tbcMdMfgGrpDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgGrpDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgGrpDVO.getMfgGrpCode());
						}
							public int getBatchSize() {
									return tbcMdMfgGrpDVOList.size();
							}
					}
		);			
	}

	
}