package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbsMcLblNmgStateDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String nmgKeyValue;

	@Length(11) @Scale(5) 
	private BigDecimal nmgRngMinValue;

	@Length(11) @Scale(5) 
	private BigDecimal nmgRngMaxValue;

	@Length(11) @Scale(5) 
	private BigDecimal nmgFnlValue;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getNmgKeyValue() {
		this.nmgKeyValue = super.getValue(1);
		return this.nmgKeyValue;
	}

	public void setNmgKeyValue(String nmgKeyValue) {
        super.setValue(1, nmgKeyValue);
		this.nmgKeyValue = nmgKeyValue;
	}
	
	public BigDecimal getNmgRngMinValue() {
		this.nmgRngMinValue = super.getValue(2);
		return this.nmgRngMinValue;
	}

	public void setNmgRngMinValue(BigDecimal nmgRngMinValue) {
        super.setValue(2, nmgRngMinValue);
		this.nmgRngMinValue = nmgRngMinValue;
	}
	
	public BigDecimal getNmgRngMaxValue() {
		this.nmgRngMaxValue = super.getValue(3);
		return this.nmgRngMaxValue;
	}

	public void setNmgRngMaxValue(BigDecimal nmgRngMaxValue) {
        super.setValue(3, nmgRngMaxValue);
		this.nmgRngMaxValue = nmgRngMaxValue;
	}
	
	public BigDecimal getNmgFnlValue() {
		this.nmgFnlValue = super.getValue(4);
		return this.nmgFnlValue;
	}

	public void setNmgFnlValue(BigDecimal nmgFnlValue) {
        super.setValue(4, nmgFnlValue);
		this.nmgFnlValue = nmgFnlValue;
	}
	
}