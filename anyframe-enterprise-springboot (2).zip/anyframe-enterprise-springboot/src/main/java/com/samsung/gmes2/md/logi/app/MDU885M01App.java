package com.samsung.gmes2.md.logi.app;

public class MDU885M01App {

	/**
	 * Buyer별라벨 목록 초기설정
	 */
	public void initBuyerLabel(){}

	/**
	 * Buyer별라벨 목록 조회
	 */
	public void listBuyerLabel(){}

	/**
	 * Buyer별라벨 목록 엑셀 다운로드
	 */
	public void excelBuyerLabel(){}

	/**
	 * Buyer별라벨 목록 저장
	 */
	public void saveBuyerLabel(){}

}
