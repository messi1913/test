package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdFprfOperDVO extends AbstractVo {

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String lineCode;

	@Length(50) 
	private String unitProcCode;

	@Length(50) 
	private String bcrPortValue;

	@Length(2000) 
	private String fprfPortDesc;

	@Length(30) 
	private String corpCode;

	@Length(30) 
	private String fprfAplyArtCode;

	@Length(30) 
	private String aplyLocCode;

	@Length(1) 
	private String inpAcrsSumrYn;

	@Length(1) 
	private String outAcrsSumrYn;

	@Length(1) 
	private String fprfAplyYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue(0);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(0, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(1);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(1, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getUnitProcCode() {
		this.unitProcCode = super.getValue(2);
		return this.unitProcCode;
	}

	public void setUnitProcCode(String unitProcCode) {
        super.setValue(2, unitProcCode);
		this.unitProcCode = unitProcCode;
	}
	
	public String getBcrPortValue() {
		this.bcrPortValue = super.getValue(3);
		return this.bcrPortValue;
	}

	public void setBcrPortValue(String bcrPortValue) {
        super.setValue(3, bcrPortValue);
		this.bcrPortValue = bcrPortValue;
	}
	
	public String getFprfPortDesc() {
		this.fprfPortDesc = super.getValue(4);
		return this.fprfPortDesc;
	}

	public void setFprfPortDesc(String fprfPortDesc) {
        super.setValue(4, fprfPortDesc);
		this.fprfPortDesc = fprfPortDesc;
	}
	
	public String getCorpCode() {
		this.corpCode = super.getValue(5);
		return this.corpCode;
	}

	public void setCorpCode(String corpCode) {
        super.setValue(5, corpCode);
		this.corpCode = corpCode;
	}
	
	public String getFprfAplyArtCode() {
		this.fprfAplyArtCode = super.getValue(6);
		return this.fprfAplyArtCode;
	}

	public void setFprfAplyArtCode(String fprfAplyArtCode) {
        super.setValue(6, fprfAplyArtCode);
		this.fprfAplyArtCode = fprfAplyArtCode;
	}
	
	public String getAplyLocCode() {
		this.aplyLocCode = super.getValue(7);
		return this.aplyLocCode;
	}

	public void setAplyLocCode(String aplyLocCode) {
        super.setValue(7, aplyLocCode);
		this.aplyLocCode = aplyLocCode;
	}
	
	public String getInpAcrsSumrYn() {
		this.inpAcrsSumrYn = super.getValue(8);
		return this.inpAcrsSumrYn;
	}

	public void setInpAcrsSumrYn(String inpAcrsSumrYn) {
        super.setValue(8, inpAcrsSumrYn);
		this.inpAcrsSumrYn = inpAcrsSumrYn;
	}
	
	public String getOutAcrsSumrYn() {
		this.outAcrsSumrYn = super.getValue(9);
		return this.outAcrsSumrYn;
	}

	public void setOutAcrsSumrYn(String outAcrsSumrYn) {
        super.setValue(9, outAcrsSumrYn);
		this.outAcrsSumrYn = outAcrsSumrYn;
	}
	
	public String getFprfAplyYn() {
		this.fprfAplyYn = super.getValue(10);
		return this.fprfAplyYn;
	}

	public void setFprfAplyYn(String fprfAplyYn) {
        super.setValue(10, fprfAplyYn);
		this.fprfAplyYn = fprfAplyYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(11);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(11, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(12);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(12, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(13);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(13, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(14);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(14, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(15);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(15, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}