package com.samsung.gmes2.mc.lbl.reg.app;

/**
 * 경로: 라벨 폼 디자인 및 등록 > 라벨디자인 목록 > 라벨디자인 변수조회
 * 개요: 라벨 디자인에 포함된 변수 목록을 조회
 * 작성일: 2011.06.28
 * 수정일:
 * @name_ko 라벨디자인 변수조회 App
 * @author 이기호 (kiho72.lee)
 */
public class C1101UP2App {

	public void listLabelDsgnVar(){}

}
