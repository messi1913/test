package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbmMdLineDQM extends AbstractDAO {


/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	LINE_NM, 
* 	MFG_PART_CODE, 
* 	PROC_GUBUN_CODE, 
* 	LINE_FORM_CODE, 
* 	LINE_LOC_DESC, 
* 	OUTS_YN, 
* 	TB_GUBUN_CODE, 
* 	RPRS_CELL_TYPE_CODE, 
* 	PLAN_MANUAL_CRE_YN, 
* 	MAIN_PACK_LINE_INLINE_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	WORK_START_HMS, 
* 	LABEL_WRT_CODE, 
* 	TT_CALC_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_LINE 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($lineNm) 
* AND LINE_NM = :lineNm 
* #end 
* #if($lineNmLike) 
* AND LINE_NM like '%' || :lineNmLike || '%' 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($lineFormCode) 
* AND LINE_FORM_CODE = :lineFormCode 
* #end 
* #if($lineLocDesc) 
* AND LINE_LOC_DESC = :lineLocDesc 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($tbGubunCode) 
* AND TB_GUBUN_CODE = :tbGubunCode 
* #end 
* #if($rprsCellTypeCode) 
* AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode 
* #end 
* #if($planManualCreYn) 
* AND PLAN_MANUAL_CRE_YN = :planManualCreYn 
* #end 
* #if($mainPackLineInlineYn) 
* AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($workStartHms) 
* AND WORK_START_HMS = :workStartHms 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	LINE_NM,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	LINE_FORM_CODE,  \n");
			sql.append(" 	LINE_LOC_DESC,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	TB_GUBUN_CODE,  \n");
			sql.append(" 	RPRS_CELL_TYPE_CODE,  \n");
			sql.append(" 	PLAN_MANUAL_CRE_YN,  \n");
			sql.append(" 	MAIN_PACK_LINE_INLINE_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	WORK_START_HMS,  \n");
			sql.append(" 	LABEL_WRT_CODE,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_LINE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNm)  \n");
			sql.append(" AND LINE_NM = :lineNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNmLike)  \n");
			sql.append(" AND LINE_NM like '%' || :lineNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineFormCode)  \n");
			sql.append(" AND LINE_FORM_CODE = :lineFormCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineLocDesc)  \n");
			sql.append(" AND LINE_LOC_DESC = :lineLocDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($tbGubunCode)  \n");
			sql.append(" AND TB_GUBUN_CODE = :tbGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($rprsCellTypeCode)  \n");
			sql.append(" AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($planManualCreYn)  \n");
			sql.append(" AND PLAN_MANUAL_CRE_YN = :planManualCreYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mainPackLineInlineYn)  \n");
			sql.append(" AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($workStartHms)  \n");
			sql.append(" AND WORK_START_HMS = :workStartHms  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdLineDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdLineDVO returnTbmMdLineDVO = new TbmMdLineDVO();
									returnTbmMdLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdLineDVO.setLineNm(resultSet.getString("LINE_NM"));
									returnTbmMdLineDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdLineDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdLineDVO.setLineFormCode(resultSet.getString("LINE_FORM_CODE"));
									returnTbmMdLineDVO.setLineLocDesc(resultSet.getString("LINE_LOC_DESC"));
									returnTbmMdLineDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbmMdLineDVO.setTbGubunCode(resultSet.getString("TB_GUBUN_CODE"));
									returnTbmMdLineDVO.setRprsCellTypeCode(resultSet.getString("RPRS_CELL_TYPE_CODE"));
									returnTbmMdLineDVO.setPlanManualCreYn(resultSet.getString("PLAN_MANUAL_CRE_YN"));
									returnTbmMdLineDVO.setMainPackLineInlineYn(resultSet.getString("MAIN_PACK_LINE_INLINE_YN"));
									returnTbmMdLineDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdLineDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdLineDVO.setWorkStartHms(resultSet.getString("WORK_START_HMS"));
									returnTbmMdLineDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbmMdLineDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbmMdLineDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdLineDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	LINE_NM, 
* 	MFG_PART_CODE, 
* 	PROC_GUBUN_CODE, 
* 	LINE_FORM_CODE, 
* 	LINE_LOC_DESC, 
* 	OUTS_YN, 
* 	TB_GUBUN_CODE, 
* 	RPRS_CELL_TYPE_CODE, 
* 	PLAN_MANUAL_CRE_YN, 
* 	MAIN_PACK_LINE_INLINE_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	WORK_START_HMS, 
* 	LABEL_WRT_CODE, 
* 	TT_CALC_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_LINE 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($lineNm) 
* AND LINE_NM = :lineNm 
* #end 
* #if($lineNmLike) 
* AND LINE_NM like '%' || :lineNmLike || '%' 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($lineFormCode) 
* AND LINE_FORM_CODE = :lineFormCode 
* #end 
* #if($lineLocDesc) 
* AND LINE_LOC_DESC = :lineLocDesc 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($tbGubunCode) 
* AND TB_GUBUN_CODE = :tbGubunCode 
* #end 
* #if($rprsCellTypeCode) 
* AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode 
* #end 
* #if($planManualCreYn) 
* AND PLAN_MANUAL_CRE_YN = :planManualCreYn 
* #end 
* #if($mainPackLineInlineYn) 
* AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($workStartHms) 
* AND WORK_START_HMS = :workStartHms 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	LINE_NM,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	LINE_FORM_CODE,  \n");
			sql.append(" 	LINE_LOC_DESC,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	TB_GUBUN_CODE,  \n");
			sql.append(" 	RPRS_CELL_TYPE_CODE,  \n");
			sql.append(" 	PLAN_MANUAL_CRE_YN,  \n");
			sql.append(" 	MAIN_PACK_LINE_INLINE_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	WORK_START_HMS,  \n");
			sql.append(" 	LABEL_WRT_CODE,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_LINE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNm)  \n");
			sql.append(" AND LINE_NM = :lineNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNmLike)  \n");
			sql.append(" AND LINE_NM like '%' || :lineNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineFormCode)  \n");
			sql.append(" AND LINE_FORM_CODE = :lineFormCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineLocDesc)  \n");
			sql.append(" AND LINE_LOC_DESC = :lineLocDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($tbGubunCode)  \n");
			sql.append(" AND TB_GUBUN_CODE = :tbGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($rprsCellTypeCode)  \n");
			sql.append(" AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($planManualCreYn)  \n");
			sql.append(" AND PLAN_MANUAL_CRE_YN = :planManualCreYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mainPackLineInlineYn)  \n");
			sql.append(" AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($workStartHms)  \n");
			sql.append(" AND WORK_START_HMS = :workStartHms  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdLineDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdLineDVO returnTbmMdLineDVO = new TbmMdLineDVO();
									returnTbmMdLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdLineDVO.setLineNm(resultSet.getString("LINE_NM"));
									returnTbmMdLineDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdLineDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdLineDVO.setLineFormCode(resultSet.getString("LINE_FORM_CODE"));
									returnTbmMdLineDVO.setLineLocDesc(resultSet.getString("LINE_LOC_DESC"));
									returnTbmMdLineDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbmMdLineDVO.setTbGubunCode(resultSet.getString("TB_GUBUN_CODE"));
									returnTbmMdLineDVO.setRprsCellTypeCode(resultSet.getString("RPRS_CELL_TYPE_CODE"));
									returnTbmMdLineDVO.setPlanManualCreYn(resultSet.getString("PLAN_MANUAL_CRE_YN"));
									returnTbmMdLineDVO.setMainPackLineInlineYn(resultSet.getString("MAIN_PACK_LINE_INLINE_YN"));
									returnTbmMdLineDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdLineDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdLineDVO.setWorkStartHms(resultSet.getString("WORK_START_HMS"));
									returnTbmMdLineDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbmMdLineDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbmMdLineDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdLineDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	LINE_NM, 
* 	MFG_PART_CODE, 
* 	PROC_GUBUN_CODE, 
* 	LINE_FORM_CODE, 
* 	LINE_LOC_DESC, 
* 	OUTS_YN, 
* 	TB_GUBUN_CODE, 
* 	RPRS_CELL_TYPE_CODE, 
* 	PLAN_MANUAL_CRE_YN, 
* 	MAIN_PACK_LINE_INLINE_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	WORK_START_HMS, 
* 	LABEL_WRT_CODE, 
* 	TT_CALC_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_LINE 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($lineNm) 
* AND LINE_NM = :lineNm 
* #end 
* #if($lineNmLike) 
* AND LINE_NM like '%' || :lineNmLike || '%' 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($lineFormCode) 
* AND LINE_FORM_CODE = :lineFormCode 
* #end 
* #if($lineLocDesc) 
* AND LINE_LOC_DESC = :lineLocDesc 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($tbGubunCode) 
* AND TB_GUBUN_CODE = :tbGubunCode 
* #end 
* #if($rprsCellTypeCode) 
* AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode 
* #end 
* #if($planManualCreYn) 
* AND PLAN_MANUAL_CRE_YN = :planManualCreYn 
* #end 
* #if($mainPackLineInlineYn) 
* AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($workStartHms) 
* AND WORK_START_HMS = :workStartHms 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	LINE_NM,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	LINE_FORM_CODE,  \n");
			sql.append(" 	LINE_LOC_DESC,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	TB_GUBUN_CODE,  \n");
			sql.append(" 	RPRS_CELL_TYPE_CODE,  \n");
			sql.append(" 	PLAN_MANUAL_CRE_YN,  \n");
			sql.append(" 	MAIN_PACK_LINE_INLINE_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	WORK_START_HMS,  \n");
			sql.append(" 	LABEL_WRT_CODE,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_LINE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNm)  \n");
			sql.append(" AND LINE_NM = :lineNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNmLike)  \n");
			sql.append(" AND LINE_NM like '%' || :lineNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineFormCode)  \n");
			sql.append(" AND LINE_FORM_CODE = :lineFormCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineLocDesc)  \n");
			sql.append(" AND LINE_LOC_DESC = :lineLocDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($tbGubunCode)  \n");
			sql.append(" AND TB_GUBUN_CODE = :tbGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($rprsCellTypeCode)  \n");
			sql.append(" AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($planManualCreYn)  \n");
			sql.append(" AND PLAN_MANUAL_CRE_YN = :planManualCreYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mainPackLineInlineYn)  \n");
			sql.append(" AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($workStartHms)  \n");
			sql.append(" AND WORK_START_HMS = :workStartHms  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdLineDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdLineDVO returnTbmMdLineDVO = new TbmMdLineDVO();
									returnTbmMdLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdLineDVO.setLineNm(resultSet.getString("LINE_NM"));
									returnTbmMdLineDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdLineDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdLineDVO.setLineFormCode(resultSet.getString("LINE_FORM_CODE"));
									returnTbmMdLineDVO.setLineLocDesc(resultSet.getString("LINE_LOC_DESC"));
									returnTbmMdLineDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbmMdLineDVO.setTbGubunCode(resultSet.getString("TB_GUBUN_CODE"));
									returnTbmMdLineDVO.setRprsCellTypeCode(resultSet.getString("RPRS_CELL_TYPE_CODE"));
									returnTbmMdLineDVO.setPlanManualCreYn(resultSet.getString("PLAN_MANUAL_CRE_YN"));
									returnTbmMdLineDVO.setMainPackLineInlineYn(resultSet.getString("MAIN_PACK_LINE_INLINE_YN"));
									returnTbmMdLineDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdLineDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdLineDVO.setWorkStartHms(resultSet.getString("WORK_START_HMS"));
									returnTbmMdLineDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbmMdLineDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbmMdLineDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdLineDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	LINE_NM, 
* 	MFG_PART_CODE, 
* 	PROC_GUBUN_CODE, 
* 	LINE_FORM_CODE, 
* 	LINE_LOC_DESC, 
* 	OUTS_YN, 
* 	TB_GUBUN_CODE, 
* 	RPRS_CELL_TYPE_CODE, 
* 	PLAN_MANUAL_CRE_YN, 
* 	MAIN_PACK_LINE_INLINE_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	WORK_START_HMS, 
* 	LABEL_WRT_CODE, 
* 	TT_CALC_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_LINE 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($lineNm) 
* AND LINE_NM = :lineNm 
* #end 
* #if($lineNmLike) 
* AND LINE_NM like '%' || :lineNmLike || '%' 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($lineFormCode) 
* AND LINE_FORM_CODE = :lineFormCode 
* #end 
* #if($lineLocDesc) 
* AND LINE_LOC_DESC = :lineLocDesc 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($tbGubunCode) 
* AND TB_GUBUN_CODE = :tbGubunCode 
* #end 
* #if($rprsCellTypeCode) 
* AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode 
* #end 
* #if($planManualCreYn) 
* AND PLAN_MANUAL_CRE_YN = :planManualCreYn 
* #end 
* #if($mainPackLineInlineYn) 
* AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($workStartHms) 
* AND WORK_START_HMS = :workStartHms 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	LINE_NM,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	LINE_FORM_CODE,  \n");
			sql.append(" 	LINE_LOC_DESC,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	TB_GUBUN_CODE,  \n");
			sql.append(" 	RPRS_CELL_TYPE_CODE,  \n");
			sql.append(" 	PLAN_MANUAL_CRE_YN,  \n");
			sql.append(" 	MAIN_PACK_LINE_INLINE_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	WORK_START_HMS,  \n");
			sql.append(" 	LABEL_WRT_CODE,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_LINE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNm)  \n");
			sql.append(" AND LINE_NM = :lineNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineNmLike)  \n");
			sql.append(" AND LINE_NM like '%' || :lineNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineFormCode)  \n");
			sql.append(" AND LINE_FORM_CODE = :lineFormCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineLocDesc)  \n");
			sql.append(" AND LINE_LOC_DESC = :lineLocDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($tbGubunCode)  \n");
			sql.append(" AND TB_GUBUN_CODE = :tbGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($rprsCellTypeCode)  \n");
			sql.append(" AND RPRS_CELL_TYPE_CODE = :rprsCellTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($planManualCreYn)  \n");
			sql.append(" AND PLAN_MANUAL_CRE_YN = :planManualCreYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mainPackLineInlineYn)  \n");
			sql.append(" AND MAIN_PACK_LINE_INLINE_YN = :mainPackLineInlineYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($workStartHms)  \n");
			sql.append(" AND WORK_START_HMS = :workStartHms  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdLineDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdLineDVO returnTbmMdLineDVO = new TbmMdLineDVO();
									returnTbmMdLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdLineDVO.setLineNm(resultSet.getString("LINE_NM"));
									returnTbmMdLineDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdLineDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdLineDVO.setLineFormCode(resultSet.getString("LINE_FORM_CODE"));
									returnTbmMdLineDVO.setLineLocDesc(resultSet.getString("LINE_LOC_DESC"));
									returnTbmMdLineDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbmMdLineDVO.setTbGubunCode(resultSet.getString("TB_GUBUN_CODE"));
									returnTbmMdLineDVO.setRprsCellTypeCode(resultSet.getString("RPRS_CELL_TYPE_CODE"));
									returnTbmMdLineDVO.setPlanManualCreYn(resultSet.getString("PLAN_MANUAL_CRE_YN"));
									returnTbmMdLineDVO.setMainPackLineInlineYn(resultSet.getString("MAIN_PACK_LINE_INLINE_YN"));
									returnTbmMdLineDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdLineDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdLineDVO.setWorkStartHms(resultSet.getString("WORK_START_HMS"));
									returnTbmMdLineDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbmMdLineDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbmMdLineDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdLineDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}