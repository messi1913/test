package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDaiDiffCauseDEM extends AbstractDAO {


/**
* insertTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return int
*/
	@LocalName("insertTbcMdDaiDiffCause")
	public int insertTbcMdDaiDiffCause (final TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.insertTbcMdDaiDiffCause.001*/  \n");
			sql.append(" TBC_MD_DAI_DIFF_CAUSE (   \n");
			sql.append("        DAI_DIFF_CAUSE_CODE , \n");
			sql.append("        DAI_DIFF_CAUSE_NM , \n");
			sql.append("        DAI_DIFF_CAUSE_DESC , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDaiDiffCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDaiDiffCause Method")
	public int[][] updateBatchAllTbcMdDaiDiffCause (final List  tbcMdDaiDiffCauseDVOList) {
		
		ArrayList updatetbcMdDaiDiffCauseDVOList = new ArrayList();
		ArrayList insertttbcMdDaiDiffCauseDVOList = new ArrayList();
		ArrayList deletetbcMdDaiDiffCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDaiDiffCauseDVOList.size() ; i++) {
		  TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO = (TbcMdDaiDiffCauseDVO) tbcMdDaiDiffCauseDVOList.get(i);
		  
		  if (tbcMdDaiDiffCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdDaiDiffCauseDVOList.add(tbcMdDaiDiffCauseDVO);
		  else if (tbcMdDaiDiffCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdDaiDiffCauseDVOList.add(tbcMdDaiDiffCauseDVO);
		  else if (tbcMdDaiDiffCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdDaiDiffCauseDVOList.add(tbcMdDaiDiffCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDaiDiffCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDaiDiffCause(insertttbcMdDaiDiffCauseDVOList);
          
      if (updatetbcMdDaiDiffCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDaiDiffCause(updatetbcMdDaiDiffCauseDVOList);
      
      if (deletetbcMdDaiDiffCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDaiDiffCause(deletetbcMdDaiDiffCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return int
*/
	@LocalName("updateTbcMdDaiDiffCause")
	public int updateTbcMdDaiDiffCause (final TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.updateTbcMdDaiDiffCause.001*/  \n");
			sql.append(" TBC_MD_DAI_DIFF_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        DAI_DIFF_CAUSE_NM = ? , \n");
			sql.append("        DAI_DIFF_CAUSE_DESC = ? , \n");
			sql.append("        PRTY_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DAI_DIFF_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdDaiDiffCause")
	public int deleteTbcMdDaiDiffCause (final TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.deleteTbcMdDaiDiffCause.001*/  \n");
			sql.append(" TBC_MD_DAI_DIFF_CAUSE \n");
			sql.append("  WHERE DAI_DIFF_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return TbcMdDaiDiffCauseDVO 
*/
	@LocalName("selectTbcMdDaiDiffCause")
	public TbcMdDaiDiffCauseDVO selectTbcMdDaiDiffCause (final TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.selectTbcMdDaiDiffCause.001*/  \n");
			sql.append("        DAI_DIFF_CAUSE_CODE , \n");
			sql.append("        DAI_DIFF_CAUSE_NM , \n");
			sql.append("        DAI_DIFF_CAUSE_DESC , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DAI_DIFF_CAUSE \n");
			sql.append("  WHERE DAI_DIFF_CAUSE_CODE = ? \n");

		return (TbcMdDaiDiffCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDaiDiffCauseDVO returnTbcMdDaiDiffCauseDVO = new TbcMdDaiDiffCauseDVO();
									returnTbcMdDaiDiffCauseDVO.setDaiDiffCauseCode(resultSet.getString("DAI_DIFF_CAUSE_CODE"));
									returnTbcMdDaiDiffCauseDVO.setDaiDiffCauseNm(resultSet.getString("DAI_DIFF_CAUSE_NM"));
									returnTbcMdDaiDiffCauseDVO.setDaiDiffCauseDesc(resultSet.getString("DAI_DIFF_CAUSE_DESC"));
									returnTbcMdDaiDiffCauseDVO.setPrtyReflYn(resultSet.getString("PRTY_REFL_YN"));
									returnTbcMdDaiDiffCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDaiDiffCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDaiDiffCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDaiDiffCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDaiDiffCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDaiDiffCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDaiDiffCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDaiDiffCause Method")
	public int mergeTbcMdDaiDiffCause (final TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO) {
		
		if ( selectTbcMdDaiDiffCause (tbcMdDaiDiffCauseDVO) == null) {
			return insertTbcMdDaiDiffCause(tbcMdDaiDiffCauseDVO);
		} else {
			return selectUpdateTbcMdDaiDiffCause (tbcMdDaiDiffCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDaiDiffCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDaiDiffCause Method")
	public int selectUpdateTbcMdDaiDiffCause (final TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO) {
		
		TbcMdDaiDiffCauseDVO tmpTbcMdDaiDiffCauseDVO =  selectTbcMdDaiDiffCause (tbcMdDaiDiffCauseDVO);
		if ( tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode() != null && !"".equals(tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode()) ) {
			tmpTbcMdDaiDiffCauseDVO.setDaiDiffCauseCode(tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
		}		
		if ( tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm() != null && !"".equals(tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm()) ) {
			tmpTbcMdDaiDiffCauseDVO.setDaiDiffCauseNm(tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm());
		}		
		if ( tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc() != null && !"".equals(tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc()) ) {
			tmpTbcMdDaiDiffCauseDVO.setDaiDiffCauseDesc(tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc());
		}		
		if ( tbcMdDaiDiffCauseDVO.getPrtyReflYn() != null && !"".equals(tbcMdDaiDiffCauseDVO.getPrtyReflYn()) ) {
			tmpTbcMdDaiDiffCauseDVO.setPrtyReflYn(tbcMdDaiDiffCauseDVO.getPrtyReflYn());
		}		
		if ( tbcMdDaiDiffCauseDVO.getUseYn() != null && !"".equals(tbcMdDaiDiffCauseDVO.getUseYn()) ) {
			tmpTbcMdDaiDiffCauseDVO.setUseYn(tbcMdDaiDiffCauseDVO.getUseYn());
		}		
		if ( tbcMdDaiDiffCauseDVO.getFstRegDt() != null && !"".equals(tbcMdDaiDiffCauseDVO.getFstRegDt()) ) {
			tmpTbcMdDaiDiffCauseDVO.setFstRegDt(tbcMdDaiDiffCauseDVO.getFstRegDt());
		}		
		if ( tbcMdDaiDiffCauseDVO.getFstRegerId() != null && !"".equals(tbcMdDaiDiffCauseDVO.getFstRegerId()) ) {
			tmpTbcMdDaiDiffCauseDVO.setFstRegerId(tbcMdDaiDiffCauseDVO.getFstRegerId());
		}		
		if ( tbcMdDaiDiffCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdDaiDiffCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdDaiDiffCauseDVO.setFnlUpdDt(tbcMdDaiDiffCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdDaiDiffCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdDaiDiffCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdDaiDiffCauseDVO.setFnlUpderId(tbcMdDaiDiffCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdDaiDiffCause (tmpTbcMdDaiDiffCauseDVO);
	}

/**
* insertBatchTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdDaiDiffCause")
	public int[] insertBatchTbcMdDaiDiffCause (final List tbcMdDaiDiffCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.insertBatchTbcMdDaiDiffCause.001*/  \n");
			sql.append(" TBC_MD_DAI_DIFF_CAUSE (   \n");
			sql.append("        DAI_DIFF_CAUSE_CODE , \n");
			sql.append("        DAI_DIFF_CAUSE_NM , \n");
			sql.append("        DAI_DIFF_CAUSE_DESC , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO = (TbcMdDaiDiffCauseDVO)tbcMdDaiDiffCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDaiDiffCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdDaiDiffCause")
	public int[] updateBatchTbcMdDaiDiffCause (final List tbcMdDaiDiffCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.updateBatchTbcMdDaiDiffCause.001*/  \n");
			sql.append(" TBC_MD_DAI_DIFF_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        DAI_DIFF_CAUSE_NM = ? , \n");
			sql.append("        DAI_DIFF_CAUSE_DESC = ? , \n");
			sql.append("        PRTY_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DAI_DIFF_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO = (TbcMdDaiDiffCauseDVO)tbcMdDaiDiffCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseNm());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseDesc());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
						}
							public int getBatchSize() {
									return tbcMdDaiDiffCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDaiDiffCause Method
* 
* @ref_table TBC_MD_DAI_DIFF_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDaiDiffCause")
	public int[] deleteBatchTbcMdDaiDiffCause (final List tbcMdDaiDiffCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDaiDiffCauseDEM.deleteBatchTbcMdDaiDiffCause.001*/  \n");
			sql.append(" TBC_MD_DAI_DIFF_CAUSE \n");
			sql.append("  WHERE DAI_DIFF_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDaiDiffCauseDVO tbcMdDaiDiffCauseDVO = (TbcMdDaiDiffCauseDVO)tbcMdDaiDiffCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDaiDiffCauseDVO.getDaiDiffCauseCode());
						}
							public int getBatchSize() {
									return tbcMdDaiDiffCauseDVOList.size();
							}
					}
		);			
	}

	
}