package com.samsung.gmes2.md.loss.app;

public class MDU452M01App {

	/**
	 * 고장증상코드 목록 초기설정
	 */
	public void initBrdnSympCode(){}

	/**
	 * 고장증상코드 목록 조회
	 */
	public void listBrdnSympCode(){}

	/**
	 * 고장증상코드 목록 엑셀 다운로드
	 */
	public void excelBrdnSympCode(){}

	/**
	 * 고장증상코드 목록 저장
	 */
	public void saveBrdnSympCode(){}

}
