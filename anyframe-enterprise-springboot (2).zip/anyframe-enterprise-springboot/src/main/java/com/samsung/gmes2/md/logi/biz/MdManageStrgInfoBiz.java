package com.samsung.gmes2.md.logi.biz;

public class MdManageStrgInfoBiz {

	/**
	 * Storage 목록 조회
	 */
	public void listStrgInfo(){}

	/**
	 * Storage 목록 저장
	 */
	public void saveStrgInfo(){}

}
