package com.samsung.gmes2.md.logi.biz;

public class MdManageSorInfoBiz {

	/**
	 * 선사 목록 조회
	 */
	public void listSorInfo(){}

	/**
	 * 선사 목록 저장
	 */
	public void saveSorInfo(){}

}
