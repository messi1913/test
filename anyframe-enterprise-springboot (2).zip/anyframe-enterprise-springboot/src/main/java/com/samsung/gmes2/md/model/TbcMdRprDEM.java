package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_RPR
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdRprDEM extends AbstractDAO {


/**
* insertTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return int
*/
	@LocalName("insertTbcMdRpr")
	public int insertTbcMdRpr (final TbcMdRprDVO tbcMdRprDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdRprDEM.insertTbcMdRpr.001*/  \n");
			sql.append(" TBC_MD_RPR (   \n");
			sql.append("        RPR_CODE , \n");
			sql.append("        RPR_CONT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
							ps.setString(psCount++, tbcMdRprDVO.getRprCont());
							ps.setString(psCount++, tbcMdRprDVO.getUseYn());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdRpr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdRpr Method")
	public int[][] updateBatchAllTbcMdRpr (final List  tbcMdRprDVOList) {
		
		ArrayList updatetbcMdRprDVOList = new ArrayList();
		ArrayList insertttbcMdRprDVOList = new ArrayList();
		ArrayList deletetbcMdRprDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdRprDVOList.size() ; i++) {
		  TbcMdRprDVO tbcMdRprDVO = (TbcMdRprDVO) tbcMdRprDVOList.get(i);
		  
		  if (tbcMdRprDVO.getSqlAction().equals("C"))
		      insertttbcMdRprDVOList.add(tbcMdRprDVO);
		  else if (tbcMdRprDVO.getSqlAction().equals("U"))
		      updatetbcMdRprDVOList.add(tbcMdRprDVO);
		  else if (tbcMdRprDVO.getSqlAction().equals("D"))
		      deletetbcMdRprDVOList.add(tbcMdRprDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdRprDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdRpr(insertttbcMdRprDVOList);
          
      if (updatetbcMdRprDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdRpr(updatetbcMdRprDVOList);
      
      if (deletetbcMdRprDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdRpr(deletetbcMdRprDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return int
*/
	@LocalName("updateTbcMdRpr")
	public int updateTbcMdRpr (final TbcMdRprDVO tbcMdRprDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdRprDEM.updateTbcMdRpr.001*/  \n");
			sql.append(" TBC_MD_RPR \n");
			sql.append(" SET   \n");
			sql.append("        RPR_CONT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE RPR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdRprDVO.getRprCont());
							ps.setString(psCount++, tbcMdRprDVO.getUseYn());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
						}
					}
		);			
	}

/**
* deleteTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return int
*/
	@LocalName("deleteTbcMdRpr")
	public int deleteTbcMdRpr (final TbcMdRprDVO tbcMdRprDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdRprDEM.deleteTbcMdRpr.001*/  \n");
			sql.append(" TBC_MD_RPR \n");
			sql.append("  WHERE RPR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
						}
					}
		);			
	}

/**
* selectTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return TbcMdRprDVO 
*/
	@LocalName("selectTbcMdRpr")
	public TbcMdRprDVO selectTbcMdRpr (final TbcMdRprDVO tbcMdRprDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdRprDEM.selectTbcMdRpr.001*/  \n");
			sql.append("        RPR_CODE , \n");
			sql.append("        RPR_CONT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_RPR \n");
			sql.append("  WHERE RPR_CODE = ? \n");

		return (TbcMdRprDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdRprDVO returnTbcMdRprDVO = new TbcMdRprDVO();
									returnTbcMdRprDVO.setRprCode(resultSet.getString("RPR_CODE"));
									returnTbcMdRprDVO.setRprCont(resultSet.getString("RPR_CONT"));
									returnTbcMdRprDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdRprDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdRprDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdRprDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdRprDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdRprDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdRpr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdRpr Method")
	public int mergeTbcMdRpr (final TbcMdRprDVO tbcMdRprDVO) {
		
		if ( selectTbcMdRpr (tbcMdRprDVO) == null) {
			return insertTbcMdRpr(tbcMdRprDVO);
		} else {
			return selectUpdateTbcMdRpr (tbcMdRprDVO);
		}
	}

	/**
	 * selectUpdateTbcMdRpr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdRpr Method")
	public int selectUpdateTbcMdRpr (final TbcMdRprDVO tbcMdRprDVO) {
		
		TbcMdRprDVO tmpTbcMdRprDVO =  selectTbcMdRpr (tbcMdRprDVO);
		if ( tbcMdRprDVO.getRprCode() != null && !"".equals(tbcMdRprDVO.getRprCode()) ) {
			tmpTbcMdRprDVO.setRprCode(tbcMdRprDVO.getRprCode());
		}		
		if ( tbcMdRprDVO.getRprCont() != null && !"".equals(tbcMdRprDVO.getRprCont()) ) {
			tmpTbcMdRprDVO.setRprCont(tbcMdRprDVO.getRprCont());
		}		
		if ( tbcMdRprDVO.getUseYn() != null && !"".equals(tbcMdRprDVO.getUseYn()) ) {
			tmpTbcMdRprDVO.setUseYn(tbcMdRprDVO.getUseYn());
		}		
		if ( tbcMdRprDVO.getFstRegDt() != null && !"".equals(tbcMdRprDVO.getFstRegDt()) ) {
			tmpTbcMdRprDVO.setFstRegDt(tbcMdRprDVO.getFstRegDt());
		}		
		if ( tbcMdRprDVO.getFstRegerId() != null && !"".equals(tbcMdRprDVO.getFstRegerId()) ) {
			tmpTbcMdRprDVO.setFstRegerId(tbcMdRprDVO.getFstRegerId());
		}		
		if ( tbcMdRprDVO.getFnlUpdDt() != null && !"".equals(tbcMdRprDVO.getFnlUpdDt()) ) {
			tmpTbcMdRprDVO.setFnlUpdDt(tbcMdRprDVO.getFnlUpdDt());
		}		
		if ( tbcMdRprDVO.getFnlUpderId() != null && !"".equals(tbcMdRprDVO.getFnlUpderId()) ) {
			tmpTbcMdRprDVO.setFnlUpderId(tbcMdRprDVO.getFnlUpderId());
		}		
		return updateTbcMdRpr (tmpTbcMdRprDVO);
	}

/**
* insertBatchTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return int[]
*/
	@LocalName("insertBatchTbcMdRpr")
	public int[] insertBatchTbcMdRpr (final List tbcMdRprDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdRprDEM.insertBatchTbcMdRpr.001*/  \n");
			sql.append(" TBC_MD_RPR (   \n");
			sql.append("        RPR_CODE , \n");
			sql.append("        RPR_CONT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdRprDVO tbcMdRprDVO = (TbcMdRprDVO)tbcMdRprDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
							ps.setString(psCount++, tbcMdRprDVO.getRprCont());
							ps.setString(psCount++, tbcMdRprDVO.getUseYn());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdRprDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return int[]
*/
	@LocalName("updateBatchTbcMdRpr")
	public int[] updateBatchTbcMdRpr (final List tbcMdRprDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdRprDEM.updateBatchTbcMdRpr.001*/  \n");
			sql.append(" TBC_MD_RPR \n");
			sql.append(" SET   \n");
			sql.append("        RPR_CONT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE RPR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdRprDVO tbcMdRprDVO = (TbcMdRprDVO)tbcMdRprDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdRprDVO.getRprCont());
							ps.setString(psCount++, tbcMdRprDVO.getUseYn());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdRprDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdRprDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
						}
							public int getBatchSize() {
									return tbcMdRprDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdRpr Method
* 
* @ref_table TBC_MD_RPR
* @return int[]
*/
	@LocalName("deleteBatchTbcMdRpr")
	public int[] deleteBatchTbcMdRpr (final List tbcMdRprDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdRprDEM.deleteBatchTbcMdRpr.001*/  \n");
			sql.append(" TBC_MD_RPR \n");
			sql.append("  WHERE RPR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdRprDVO tbcMdRprDVO = (TbcMdRprDVO)tbcMdRprDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdRprDVO.getRprCode());
						}
							public int getBatchSize() {
									return tbcMdRprDVOList.size();
							}
					}
		);			
	}

	
}