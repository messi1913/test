package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEFT_SYMP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeftSympDEM extends AbstractDAO {


/**
* insertTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return int
*/
	@LocalName("insertTbcMdDeftSymp")
	public int insertTbcMdDeftSymp (final TbcMdDeftSympDVO tbcMdDeftSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.insertTbcMdDeftSymp.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP (   \n");
			sql.append("        DEFT_SYMP_CODE , \n");
			sql.append("        DEFT_SYMP_NM , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympNm());
							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbcMdDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeftSymp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeftSymp Method")
	public int[][] updateBatchAllTbcMdDeftSymp (final List  tbcMdDeftSympDVOList) {
		
		ArrayList updatetbcMdDeftSympDVOList = new ArrayList();
		ArrayList insertttbcMdDeftSympDVOList = new ArrayList();
		ArrayList deletetbcMdDeftSympDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeftSympDVOList.size() ; i++) {
		  TbcMdDeftSympDVO tbcMdDeftSympDVO = (TbcMdDeftSympDVO) tbcMdDeftSympDVOList.get(i);
		  
		  if (tbcMdDeftSympDVO.getSqlAction().equals("C"))
		      insertttbcMdDeftSympDVOList.add(tbcMdDeftSympDVO);
		  else if (tbcMdDeftSympDVO.getSqlAction().equals("U"))
		      updatetbcMdDeftSympDVOList.add(tbcMdDeftSympDVO);
		  else if (tbcMdDeftSympDVO.getSqlAction().equals("D"))
		      deletetbcMdDeftSympDVOList.add(tbcMdDeftSympDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeftSympDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeftSymp(insertttbcMdDeftSympDVOList);
          
      if (updatetbcMdDeftSympDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeftSymp(updatetbcMdDeftSympDVOList);
      
      if (deletetbcMdDeftSympDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeftSymp(deletetbcMdDeftSympDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return int
*/
	@LocalName("updateTbcMdDeftSymp")
	public int updateTbcMdDeftSymp (final TbcMdDeftSympDVO tbcMdDeftSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.updateTbcMdDeftSymp.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_SYMP_NM = ? , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_SYMP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympNm());
							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbcMdDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return int
*/
	@LocalName("deleteTbcMdDeftSymp")
	public int deleteTbcMdDeftSymp (final TbcMdDeftSympDVO tbcMdDeftSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.deleteTbcMdDeftSymp.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP \n");
			sql.append("  WHERE DEFT_SYMP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return TbcMdDeftSympDVO 
*/
	@LocalName("selectTbcMdDeftSymp")
	public TbcMdDeftSympDVO selectTbcMdDeftSymp (final TbcMdDeftSympDVO tbcMdDeftSympDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.selectTbcMdDeftSymp.001*/  \n");
			sql.append("        DEFT_SYMP_CODE , \n");
			sql.append("        DEFT_SYMP_NM , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEFT_SYMP \n");
			sql.append("  WHERE DEFT_SYMP_CODE = ? \n");

		return (TbcMdDeftSympDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeftSympDVO returnTbcMdDeftSympDVO = new TbcMdDeftSympDVO();
									returnTbcMdDeftSympDVO.setDeftSympCode(resultSet.getString("DEFT_SYMP_CODE"));
									returnTbcMdDeftSympDVO.setDeftSympNm(resultSet.getString("DEFT_SYMP_NM"));
									returnTbcMdDeftSympDVO.setDeftSympClsfCode(resultSet.getString("DEFT_SYMP_CLSF_CODE"));
									returnTbcMdDeftSympDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftSympDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftSympDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftSympDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftSympDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftSympDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeftSymp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeftSymp Method")
	public int mergeTbcMdDeftSymp (final TbcMdDeftSympDVO tbcMdDeftSympDVO) {
		
		if ( selectTbcMdDeftSymp (tbcMdDeftSympDVO) == null) {
			return insertTbcMdDeftSymp(tbcMdDeftSympDVO);
		} else {
			return selectUpdateTbcMdDeftSymp (tbcMdDeftSympDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeftSymp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeftSymp Method")
	public int selectUpdateTbcMdDeftSymp (final TbcMdDeftSympDVO tbcMdDeftSympDVO) {
		
		TbcMdDeftSympDVO tmpTbcMdDeftSympDVO =  selectTbcMdDeftSymp (tbcMdDeftSympDVO);
		if ( tbcMdDeftSympDVO.getDeftSympCode() != null && !"".equals(tbcMdDeftSympDVO.getDeftSympCode()) ) {
			tmpTbcMdDeftSympDVO.setDeftSympCode(tbcMdDeftSympDVO.getDeftSympCode());
		}		
		if ( tbcMdDeftSympDVO.getDeftSympNm() != null && !"".equals(tbcMdDeftSympDVO.getDeftSympNm()) ) {
			tmpTbcMdDeftSympDVO.setDeftSympNm(tbcMdDeftSympDVO.getDeftSympNm());
		}		
		if ( tbcMdDeftSympDVO.getDeftSympClsfCode() != null && !"".equals(tbcMdDeftSympDVO.getDeftSympClsfCode()) ) {
			tmpTbcMdDeftSympDVO.setDeftSympClsfCode(tbcMdDeftSympDVO.getDeftSympClsfCode());
		}		
		if ( tbcMdDeftSympDVO.getUseYn() != null && !"".equals(tbcMdDeftSympDVO.getUseYn()) ) {
			tmpTbcMdDeftSympDVO.setUseYn(tbcMdDeftSympDVO.getUseYn());
		}		
		if ( tbcMdDeftSympDVO.getFstRegDt() != null && !"".equals(tbcMdDeftSympDVO.getFstRegDt()) ) {
			tmpTbcMdDeftSympDVO.setFstRegDt(tbcMdDeftSympDVO.getFstRegDt());
		}		
		if ( tbcMdDeftSympDVO.getFstRegerId() != null && !"".equals(tbcMdDeftSympDVO.getFstRegerId()) ) {
			tmpTbcMdDeftSympDVO.setFstRegerId(tbcMdDeftSympDVO.getFstRegerId());
		}		
		if ( tbcMdDeftSympDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeftSympDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeftSympDVO.setFnlUpdDt(tbcMdDeftSympDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeftSympDVO.getFnlUpderId() != null && !"".equals(tbcMdDeftSympDVO.getFnlUpderId()) ) {
			tmpTbcMdDeftSympDVO.setFnlUpderId(tbcMdDeftSympDVO.getFnlUpderId());
		}		
		return updateTbcMdDeftSymp (tmpTbcMdDeftSympDVO);
	}

/**
* insertBatchTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeftSymp")
	public int[] insertBatchTbcMdDeftSymp (final List tbcMdDeftSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.insertBatchTbcMdDeftSymp.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP (   \n");
			sql.append("        DEFT_SYMP_CODE , \n");
			sql.append("        DEFT_SYMP_NM , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftSympDVO tbcMdDeftSympDVO = (TbcMdDeftSympDVO)tbcMdDeftSympDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympNm());
							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbcMdDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeftSympDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeftSymp")
	public int[] updateBatchTbcMdDeftSymp (final List tbcMdDeftSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.updateBatchTbcMdDeftSymp.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_SYMP_NM = ? , \n");
			sql.append("        DEFT_SYMP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_SYMP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftSympDVO tbcMdDeftSympDVO = (TbcMdDeftSympDVO)tbcMdDeftSympDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympNm());
							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympClsfCode());
							ps.setString(psCount++, tbcMdDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftSympDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
						}
							public int getBatchSize() {
									return tbcMdDeftSympDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeftSymp Method
* 
* @ref_table TBC_MD_DEFT_SYMP
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeftSymp")
	public int[] deleteBatchTbcMdDeftSymp (final List tbcMdDeftSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftSympDEM.deleteBatchTbcMdDeftSymp.001*/  \n");
			sql.append(" TBC_MD_DEFT_SYMP \n");
			sql.append("  WHERE DEFT_SYMP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftSympDVO tbcMdDeftSympDVO = (TbcMdDeftSympDVO)tbcMdDeftSympDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftSympDVO.getDeftSympCode());
						}
							public int getBatchSize() {
									return tbcMdDeftSympDVOList.size();
							}
					}
		);			
	}

	
}