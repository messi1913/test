package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdLossCauseDVO extends AbstractVo {

	@Length(30) 
	private String lossCauseCode;

	@Length(500) 
	private String lossNm;

	@Length(2000) 
	private String lossCauseDesc;

	@Length(30) 
	private String lossArtCode;

	@Length(30) 
	private String dutyClsfCode;

	@Length(1) 
	private String prtyReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getLossCauseCode() {
		this.lossCauseCode = super.getValue(0);
		return this.lossCauseCode;
	}

	public void setLossCauseCode(String lossCauseCode) {
        super.setValue(0, lossCauseCode);
		this.lossCauseCode = lossCauseCode;
	}
	
	public String getLossNm() {
		this.lossNm = super.getValue(1);
		return this.lossNm;
	}

	public void setLossNm(String lossNm) {
        super.setValue(1, lossNm);
		this.lossNm = lossNm;
	}
	
	public String getLossCauseDesc() {
		this.lossCauseDesc = super.getValue(2);
		return this.lossCauseDesc;
	}

	public void setLossCauseDesc(String lossCauseDesc) {
        super.setValue(2, lossCauseDesc);
		this.lossCauseDesc = lossCauseDesc;
	}
	
	public String getLossArtCode() {
		this.lossArtCode = super.getValue(3);
		return this.lossArtCode;
	}

	public void setLossArtCode(String lossArtCode) {
        super.setValue(3, lossArtCode);
		this.lossArtCode = lossArtCode;
	}
	
	public String getDutyClsfCode() {
		this.dutyClsfCode = super.getValue(4);
		return this.dutyClsfCode;
	}

	public void setDutyClsfCode(String dutyClsfCode) {
        super.setValue(4, dutyClsfCode);
		this.dutyClsfCode = dutyClsfCode;
	}
	
	public String getPrtyReflYn() {
		this.prtyReflYn = super.getValue(5);
		return this.prtyReflYn;
	}

	public void setPrtyReflYn(String prtyReflYn) {
        super.setValue(5, prtyReflYn);
		this.prtyReflYn = prtyReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(6);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(6, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(7);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(7, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(8);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(8, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(9);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(9, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(10);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(10, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}