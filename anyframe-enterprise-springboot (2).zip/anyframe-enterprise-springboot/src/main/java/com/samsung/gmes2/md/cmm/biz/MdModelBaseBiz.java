package com.samsung.gmes2.md.cmm.biz;

public class MdModelBaseBiz {

	/**
	 * 제품그룹 리스트
	 */
	public void listProdGrpBase(){}

	/**
	 * 제품약어 리스트
	 */
	public void listProdAbbtBase(){}

	/**
	 * 프로젝트 리스트
	 */
	public void listProjectBase(){}

	/**
	 * 모델그룹 리스트
	 */
	public void listModelGrpBase(){}

	/**
	 * 모델 리스트
	 */
	public void listModelBase(){}

	/**
	 * 제품코드 목록
	 */
	public void listProdBase(){}

}
