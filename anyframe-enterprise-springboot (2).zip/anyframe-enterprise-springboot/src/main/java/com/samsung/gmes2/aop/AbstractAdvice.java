package com.samsung.gmes2.aop;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anyframe.core.vo.AbstractVo;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CacheUtil;
import com.samsung.gmes2.base.util.ReflectionUtil;
import com.samsung.gmes2.base.util.ThreadPropertyUtil;

public abstract class AbstractAdvice extends BaseUtil {
	private static Logger logger = LoggerFactory.getLogger(AbstractAdvice.class);
	
	private static final String PROP_STACKCOUNTER = "stackCounter";
	public static boolean isFirstStack() {
		return ThreadPropertyUtil.get(PROP_STACKCOUNTER) == null;
	}
	private static int getStackCounter() {
		return toInteger(ThreadPropertyUtil.get(PROP_STACKCOUNTER), 0);
	}
	public static void increaseStackCounter() {
		int stackCounter = getStackCounter();
		ThreadPropertyUtil.put(PROP_STACKCOUNTER, stackCounter + 1);
	}
	public static void decreaseStackCounter() {
		int stackCounter = getStackCounter();
		ThreadPropertyUtil.put(PROP_STACKCOUNTER, stackCounter <= 1 ? null : stackCounter - 1);
	}
	/**
	 * obj 객체 에 대한 cache 가 사용가능한지 확인합니다.
	 * @param obj
	 * @return
	 */
	private static boolean isCacheable(Object obj) {
		if (obj == null || !CacheUtil.isCacheable())
			return false;
		String name = obj instanceof Class<?> ? ((Class<?>) obj).getSimpleName() : obj.getClass().getSimpleName();
		return CacheUtil.getManager().cacheExists(name);
	}
	public static AbstractVo getCache(AbstractVo obj) throws Exception {
		if (obj == null || !isCacheable(obj))
			return null;
		String key = getCacheKey(obj);
		if (isEmpty(key) || isCacheToInvalidate(obj.getClass(), key))
			return null;
		AbstractVo vo = (AbstractVo) CacheUtil.get(obj.getClass().getSimpleName(), key);
		if (vo == null)
			return null;
		return populate(vo, obj.getClass().newInstance());
	}
	/**
	 * obj 객체를 cache 합니다.
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static Object putCache(AbstractVo obj) throws Exception {
		if (obj == null || !isCacheable(obj))
			return null;
		String key = getCacheKey(obj);
		if (isEmpty(key) || isCacheToInvalidate(obj.getClass(), key))
			return null;
		CacheUtil.put(obj.getClass().getSimpleName(), key, populate(obj, obj.getClass().newInstance()));
		return obj;
	}
	/**
	 * obj 객체에 대한 cache 를 제거합니다.
	 * @param obj
	 * @throws Exception
	 */
	public static void removeCache(AbstractVo obj) throws Exception {
		if (obj == null || !isCacheable(obj))
			return;
		CacheUtil.remove(obj.getClass().getSimpleName(), getCacheKey(obj));
	}
	
	private static String getCacheKey(AbstractVo obj) {
		List<String> pk = ReflectionUtil.getPKFieldNameList(obj);
		if (isEmpty(pk))
			return null;
		StringBuffer buf = new StringBuffer();
		int i = 0;
		for (String k : pk)
			buf.append(i++ == 0 ? "" : ",").append(obj.getValue(k));
		return buf.toString();
	}
	private static final String PROP_CACHETOINVALIDATE = "cacheToInvalidate";
	private static boolean isCacheToInvalidate(Class<? extends AbstractVo> clazz, String key) {
		if (clazz == null || key == null)
			return false;
		@SuppressWarnings("unchecked")
		List<AbstractVo> list = (List<AbstractVo>) ThreadPropertyUtil.get(PROP_CACHETOINVALIDATE);
		if (isEmpty(list))
			return false;
		for (AbstractVo vo : list) {
			if (vo.getClass() != clazz)
				continue;
			if (getCacheKey(vo).equals(key))
				return true;
		}
		return false;
	}
	@SuppressWarnings("unchecked")
	public static void addCacheToInvalidate(Object obj) {
		if (BaseUtil.isEmpty(obj))
			return;
		boolean listFlag = obj instanceof List;
		if (listFlag && !isCacheable(((List<?>) obj).get(0)))
			return;
		else if (!isCacheable(obj))
			return;
		
		List<AbstractVo> list = (List<AbstractVo>) ThreadPropertyUtil.get(PROP_CACHETOINVALIDATE);
		if (list == null) {
			list = new ArrayList<AbstractVo>();
			ThreadPropertyUtil.put(PROP_CACHETOINVALIDATE, list);
		}
		
		if (listFlag)
			list.addAll((List<AbstractVo>) obj);
		else if (obj instanceof AbstractVo)
			list.add((AbstractVo) obj);
	}
	public static void invalidateCache() {
		if (!ThreadPropertyUtil.contains(PROP_CACHETOINVALIDATE))
			return;
		@SuppressWarnings("unchecked")
		List<AbstractVo> list = (List<AbstractVo>) ThreadPropertyUtil.remove(PROP_CACHETOINVALIDATE);
		if (isEmpty(list))
			return;
		for (AbstractVo obj : list) {
			try {
				removeCache(obj);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
		}
	}
}
