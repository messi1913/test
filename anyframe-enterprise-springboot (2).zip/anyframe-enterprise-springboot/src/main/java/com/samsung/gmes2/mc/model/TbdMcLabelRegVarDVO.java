package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbdMcLabelRegVarDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String labelId;

	@Length(5) @Scale(2) @NotNull
	private BigDecimal labelVer;

	@Length(500) @NotNull
	private String varNm;

	@Length(50) 
	private String propId;

	@Length(3) 
	private String varValueTypeCode;


	public String getLabelId() {
		this.labelId = super.getValue("labelId");
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue("labelId", labelId);
		this.labelId = labelId;
	}
	
	public BigDecimal getLabelVer() {
		this.labelVer = super.getValue("labelVer");
		return this.labelVer;
	}

	public void setLabelVer(BigDecimal labelVer) {
        super.setValue("labelVer", labelVer);
		this.labelVer = labelVer;
	}
	
	public String getVarNm() {
		this.varNm = super.getValue("varNm");
		return this.varNm;
	}

	public void setVarNm(String varNm) {
        super.setValue("varNm", varNm);
		this.varNm = varNm;
	}
	
	public String getPropId() {
		this.propId = super.getValue("propId");
		return this.propId;
	}

	public void setPropId(String propId) {
        super.setValue("propId", propId);
		this.propId = propId;
	}
	
	public String getVarValueTypeCode() {
		this.varValueTypeCode = super.getValue("varValueTypeCode");
		return this.varValueTypeCode;
	}

	public void setVarValueTypeCode(String varValueTypeCode) {
        super.setValue("varValueTypeCode", varValueTypeCode);
		this.varValueTypeCode = varValueTypeCode;
	}
	
}