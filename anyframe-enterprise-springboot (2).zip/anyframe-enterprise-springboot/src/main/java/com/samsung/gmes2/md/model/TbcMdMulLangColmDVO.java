package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdMulLangColmDVO extends AbstractVo {

	@Length(50) 
	private String tabId;

	@Length(3) 
	private String langCode;

	@Length(500) 
	private String n1CulmNm;

	@Length(500) 
	private String n2CulmNm;

	@Length(500) 
	private String n3CulmNm;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getTabId() {
		this.tabId = super.getValue(0);
		return this.tabId;
	}

	public void setTabId(String tabId) {
        super.setValue(0, tabId);
		this.tabId = tabId;
	}
	
	public String getLangCode() {
		this.langCode = super.getValue(1);
		return this.langCode;
	}

	public void setLangCode(String langCode) {
        super.setValue(1, langCode);
		this.langCode = langCode;
	}
	
	public String getN1CulmNm() {
		this.n1CulmNm = super.getValue(2);
		return this.n1CulmNm;
	}

	public void setN1CulmNm(String n1CulmNm) {
        super.setValue(2, n1CulmNm);
		this.n1CulmNm = n1CulmNm;
	}
	
	public String getN2CulmNm() {
		this.n2CulmNm = super.getValue(3);
		return this.n2CulmNm;
	}

	public void setN2CulmNm(String n2CulmNm) {
        super.setValue(3, n2CulmNm);
		this.n2CulmNm = n2CulmNm;
	}
	
	public String getN3CulmNm() {
		this.n3CulmNm = super.getValue(4);
		return this.n3CulmNm;
	}

	public void setN3CulmNm(String n3CulmNm) {
        super.setValue(4, n3CulmNm);
		this.n3CulmNm = n3CulmNm;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(5);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(5, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(6);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(6, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(7);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(7, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(8);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(8, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}