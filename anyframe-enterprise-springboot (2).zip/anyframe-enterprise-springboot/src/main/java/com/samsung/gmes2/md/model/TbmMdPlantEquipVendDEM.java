package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPlantEquipVendDEM extends AbstractDAO {


/**
* insertTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return int
*/
	@LocalName("insertTbmMdPlantEquipVend")
	public int insertTbmMdPlantEquipVend (final TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.insertTbmMdPlantEquipVend.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP_VEND (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        EQUIP_VEND_CODE , \n");
			sql.append("        EQUIP_MODEL_NO , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipModelNo());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPlantEquipVend Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPlantEquipVend Method")
	public int[][] updateBatchAllTbmMdPlantEquipVend (final List  tbmMdPlantEquipVendDVOList) {
		
		ArrayList updatetbmMdPlantEquipVendDVOList = new ArrayList();
		ArrayList insertttbmMdPlantEquipVendDVOList = new ArrayList();
		ArrayList deletetbmMdPlantEquipVendDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPlantEquipVendDVOList.size() ; i++) {
		  TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO = (TbmMdPlantEquipVendDVO) tbmMdPlantEquipVendDVOList.get(i);
		  
		  if (tbmMdPlantEquipVendDVO.getSqlAction().equals("C"))
		      insertttbmMdPlantEquipVendDVOList.add(tbmMdPlantEquipVendDVO);
		  else if (tbmMdPlantEquipVendDVO.getSqlAction().equals("U"))
		      updatetbmMdPlantEquipVendDVOList.add(tbmMdPlantEquipVendDVO);
		  else if (tbmMdPlantEquipVendDVO.getSqlAction().equals("D"))
		      deletetbmMdPlantEquipVendDVOList.add(tbmMdPlantEquipVendDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPlantEquipVendDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPlantEquipVend(insertttbmMdPlantEquipVendDVOList);
          
      if (updatetbmMdPlantEquipVendDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPlantEquipVend(updatetbmMdPlantEquipVendDVOList);
      
      if (deletetbmMdPlantEquipVendDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPlantEquipVend(deletetbmMdPlantEquipVendDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return int
*/
	@LocalName("updateTbmMdPlantEquipVend")
	public int updateTbmMdPlantEquipVend (final TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.updateTbmMdPlantEquipVend.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP_VEND \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_MODEL_NO = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND EQUIP_CODE = ? \n");
			sql.append("   AND EQUIP_VEND_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipModelNo());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
						}
					}
		);			
	}

/**
* deleteTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return int
*/
	@LocalName("deleteTbmMdPlantEquipVend")
	public int deleteTbmMdPlantEquipVend (final TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.deleteTbmMdPlantEquipVend.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND EQUIP_CODE = ? \n");
			sql.append("    AND EQUIP_VEND_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
						}
					}
		);			
	}

/**
* selectTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return TbmMdPlantEquipVendDVO 
*/
	@LocalName("selectTbmMdPlantEquipVend")
	public TbmMdPlantEquipVendDVO selectTbmMdPlantEquipVend (final TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.selectTbmMdPlantEquipVend.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        EQUIP_VEND_CODE , \n");
			sql.append("        EQUIP_MODEL_NO , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PLANT_EQUIP_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND EQUIP_CODE = ? \n");
			sql.append("    AND EQUIP_VEND_CODE = ? \n");

		return (TbmMdPlantEquipVendDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPlantEquipVendDVO returnTbmMdPlantEquipVendDVO = new TbmMdPlantEquipVendDVO();
									returnTbmMdPlantEquipVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPlantEquipVendDVO.setEquipCode(resultSet.getString("EQUIP_CODE"));
									returnTbmMdPlantEquipVendDVO.setEquipVendCode(resultSet.getString("EQUIP_VEND_CODE"));
									returnTbmMdPlantEquipVendDVO.setEquipModelNo(resultSet.getString("EQUIP_MODEL_NO"));
									returnTbmMdPlantEquipVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdPlantEquipVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPlantEquipVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPlantEquipVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPlantEquipVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPlantEquipVendDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPlantEquipVend Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPlantEquipVend Method")
	public int mergeTbmMdPlantEquipVend (final TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO) {
		
		if ( selectTbmMdPlantEquipVend (tbmMdPlantEquipVendDVO) == null) {
			return insertTbmMdPlantEquipVend(tbmMdPlantEquipVendDVO);
		} else {
			return selectUpdateTbmMdPlantEquipVend (tbmMdPlantEquipVendDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPlantEquipVend Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPlantEquipVend Method")
	public int selectUpdateTbmMdPlantEquipVend (final TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO) {
		
		TbmMdPlantEquipVendDVO tmpTbmMdPlantEquipVendDVO =  selectTbmMdPlantEquipVend (tbmMdPlantEquipVendDVO);
		if ( tbmMdPlantEquipVendDVO.getPlantCode() != null && !"".equals(tbmMdPlantEquipVendDVO.getPlantCode()) ) {
			tmpTbmMdPlantEquipVendDVO.setPlantCode(tbmMdPlantEquipVendDVO.getPlantCode());
		}		
		if ( tbmMdPlantEquipVendDVO.getEquipCode() != null && !"".equals(tbmMdPlantEquipVendDVO.getEquipCode()) ) {
			tmpTbmMdPlantEquipVendDVO.setEquipCode(tbmMdPlantEquipVendDVO.getEquipCode());
		}		
		if ( tbmMdPlantEquipVendDVO.getEquipVendCode() != null && !"".equals(tbmMdPlantEquipVendDVO.getEquipVendCode()) ) {
			tmpTbmMdPlantEquipVendDVO.setEquipVendCode(tbmMdPlantEquipVendDVO.getEquipVendCode());
		}		
		if ( tbmMdPlantEquipVendDVO.getEquipModelNo() != null && !"".equals(tbmMdPlantEquipVendDVO.getEquipModelNo()) ) {
			tmpTbmMdPlantEquipVendDVO.setEquipModelNo(tbmMdPlantEquipVendDVO.getEquipModelNo());
		}		
		if ( tbmMdPlantEquipVendDVO.getUseYn() != null && !"".equals(tbmMdPlantEquipVendDVO.getUseYn()) ) {
			tmpTbmMdPlantEquipVendDVO.setUseYn(tbmMdPlantEquipVendDVO.getUseYn());
		}		
		if ( tbmMdPlantEquipVendDVO.getFstRegDt() != null && !"".equals(tbmMdPlantEquipVendDVO.getFstRegDt()) ) {
			tmpTbmMdPlantEquipVendDVO.setFstRegDt(tbmMdPlantEquipVendDVO.getFstRegDt());
		}		
		if ( tbmMdPlantEquipVendDVO.getFstRegerId() != null && !"".equals(tbmMdPlantEquipVendDVO.getFstRegerId()) ) {
			tmpTbmMdPlantEquipVendDVO.setFstRegerId(tbmMdPlantEquipVendDVO.getFstRegerId());
		}		
		if ( tbmMdPlantEquipVendDVO.getFnlUpdDt() != null && !"".equals(tbmMdPlantEquipVendDVO.getFnlUpdDt()) ) {
			tmpTbmMdPlantEquipVendDVO.setFnlUpdDt(tbmMdPlantEquipVendDVO.getFnlUpdDt());
		}		
		if ( tbmMdPlantEquipVendDVO.getFnlUpderId() != null && !"".equals(tbmMdPlantEquipVendDVO.getFnlUpderId()) ) {
			tmpTbmMdPlantEquipVendDVO.setFnlUpderId(tbmMdPlantEquipVendDVO.getFnlUpderId());
		}		
		return updateTbmMdPlantEquipVend (tmpTbmMdPlantEquipVendDVO);
	}

/**
* insertBatchTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return int[]
*/
	@LocalName("insertBatchTbmMdPlantEquipVend")
	public int[] insertBatchTbmMdPlantEquipVend (final List tbmMdPlantEquipVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.insertBatchTbmMdPlantEquipVend.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP_VEND (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        EQUIP_VEND_CODE , \n");
			sql.append("        EQUIP_MODEL_NO , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO = (TbmMdPlantEquipVendDVO)tbmMdPlantEquipVendDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipModelNo());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPlantEquipVendDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return int[]
*/
	@LocalName("updateBatchTbmMdPlantEquipVend")
	public int[] updateBatchTbmMdPlantEquipVend (final List tbmMdPlantEquipVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.updateBatchTbmMdPlantEquipVend.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP_VEND \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_MODEL_NO = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND EQUIP_CODE = ? \n");
			sql.append("   AND EQUIP_VEND_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO = (TbmMdPlantEquipVendDVO)tbmMdPlantEquipVendDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipModelNo());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
						}
							public int getBatchSize() {
									return tbmMdPlantEquipVendDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPlantEquipVend Method
* 
* @ref_table TBM_MD_PLANT_EQUIP_VEND
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPlantEquipVend")
	public int[] deleteBatchTbmMdPlantEquipVend (final List tbmMdPlantEquipVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantEquipVendDEM.deleteBatchTbmMdPlantEquipVend.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND EQUIP_CODE = ? \n");
			sql.append("    AND EQUIP_VEND_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantEquipVendDVO tbmMdPlantEquipVendDVO = (TbmMdPlantEquipVendDVO)tbmMdPlantEquipVendDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipVendDVO.getEquipVendCode());
						}
							public int getBatchSize() {
									return tbmMdPlantEquipVendDVOList.size();
							}
					}
		);			
	}

	
}