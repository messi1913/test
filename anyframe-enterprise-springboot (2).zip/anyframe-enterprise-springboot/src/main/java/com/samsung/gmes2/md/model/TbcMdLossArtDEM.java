package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_LOSS_ART
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdLossArtDEM extends AbstractDAO {


/**
* insertTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return int
*/
	@LocalName("insertTbcMdLossArt")
	public int insertTbcMdLossArt (final TbcMdLossArtDVO tbcMdLossArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.insertTbcMdLossArt.001*/  \n");
			sql.append(" TBC_MD_LOSS_ART (   \n");
			sql.append("        LOSS_ART_CODE , \n");
			sql.append("        LOSS_ART_DESC , \n");
			sql.append("        LOSS_TYPE_CODE , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtDesc());
							ps.setString(psCount++, tbcMdLossArtDVO.getLossTypeCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdLossArt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdLossArt Method")
	public int[][] updateBatchAllTbcMdLossArt (final List  tbcMdLossArtDVOList) {
		
		ArrayList updatetbcMdLossArtDVOList = new ArrayList();
		ArrayList insertttbcMdLossArtDVOList = new ArrayList();
		ArrayList deletetbcMdLossArtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdLossArtDVOList.size() ; i++) {
		  TbcMdLossArtDVO tbcMdLossArtDVO = (TbcMdLossArtDVO) tbcMdLossArtDVOList.get(i);
		  
		  if (tbcMdLossArtDVO.getSqlAction().equals("C"))
		      insertttbcMdLossArtDVOList.add(tbcMdLossArtDVO);
		  else if (tbcMdLossArtDVO.getSqlAction().equals("U"))
		      updatetbcMdLossArtDVOList.add(tbcMdLossArtDVO);
		  else if (tbcMdLossArtDVO.getSqlAction().equals("D"))
		      deletetbcMdLossArtDVOList.add(tbcMdLossArtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdLossArtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdLossArt(insertttbcMdLossArtDVOList);
          
      if (updatetbcMdLossArtDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdLossArt(updatetbcMdLossArtDVOList);
      
      if (deletetbcMdLossArtDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdLossArt(deletetbcMdLossArtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return int
*/
	@LocalName("updateTbcMdLossArt")
	public int updateTbcMdLossArt (final TbcMdLossArtDVO tbcMdLossArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.updateTbcMdLossArt.001*/  \n");
			sql.append(" TBC_MD_LOSS_ART \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_ART_DESC = ? , \n");
			sql.append("        LOSS_TYPE_CODE = ? , \n");
			sql.append("        DUTY_CLSF_CODE = ? , \n");
			sql.append("        PRTY_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LOSS_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtDesc());
							ps.setString(psCount++, tbcMdLossArtDVO.getLossTypeCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
						}
					}
		);			
	}

/**
* deleteTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return int
*/
	@LocalName("deleteTbcMdLossArt")
	public int deleteTbcMdLossArt (final TbcMdLossArtDVO tbcMdLossArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.deleteTbcMdLossArt.001*/  \n");
			sql.append(" TBC_MD_LOSS_ART \n");
			sql.append("  WHERE LOSS_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
						}
					}
		);			
	}

/**
* selectTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return TbcMdLossArtDVO 
*/
	@LocalName("selectTbcMdLossArt")
	public TbcMdLossArtDVO selectTbcMdLossArt (final TbcMdLossArtDVO tbcMdLossArtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.selectTbcMdLossArt.001*/  \n");
			sql.append("        LOSS_ART_CODE , \n");
			sql.append("        LOSS_ART_DESC , \n");
			sql.append("        LOSS_TYPE_CODE , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_LOSS_ART \n");
			sql.append("  WHERE LOSS_ART_CODE = ? \n");

		return (TbcMdLossArtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdLossArtDVO returnTbcMdLossArtDVO = new TbcMdLossArtDVO();
									returnTbcMdLossArtDVO.setLossArtCode(resultSet.getString("LOSS_ART_CODE"));
									returnTbcMdLossArtDVO.setLossArtDesc(resultSet.getString("LOSS_ART_DESC"));
									returnTbcMdLossArtDVO.setLossTypeCode(resultSet.getString("LOSS_TYPE_CODE"));
									returnTbcMdLossArtDVO.setDutyClsfCode(resultSet.getString("DUTY_CLSF_CODE"));
									returnTbcMdLossArtDVO.setPrtyReflYn(resultSet.getString("PRTY_REFL_YN"));
									returnTbcMdLossArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdLossArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdLossArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdLossArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdLossArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdLossArtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdLossArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdLossArt Method")
	public int mergeTbcMdLossArt (final TbcMdLossArtDVO tbcMdLossArtDVO) {
		
		if ( selectTbcMdLossArt (tbcMdLossArtDVO) == null) {
			return insertTbcMdLossArt(tbcMdLossArtDVO);
		} else {
			return selectUpdateTbcMdLossArt (tbcMdLossArtDVO);
		}
	}

	/**
	 * selectUpdateTbcMdLossArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdLossArt Method")
	public int selectUpdateTbcMdLossArt (final TbcMdLossArtDVO tbcMdLossArtDVO) {
		
		TbcMdLossArtDVO tmpTbcMdLossArtDVO =  selectTbcMdLossArt (tbcMdLossArtDVO);
		if ( tbcMdLossArtDVO.getLossArtCode() != null && !"".equals(tbcMdLossArtDVO.getLossArtCode()) ) {
			tmpTbcMdLossArtDVO.setLossArtCode(tbcMdLossArtDVO.getLossArtCode());
		}		
		if ( tbcMdLossArtDVO.getLossArtDesc() != null && !"".equals(tbcMdLossArtDVO.getLossArtDesc()) ) {
			tmpTbcMdLossArtDVO.setLossArtDesc(tbcMdLossArtDVO.getLossArtDesc());
		}		
		if ( tbcMdLossArtDVO.getLossTypeCode() != null && !"".equals(tbcMdLossArtDVO.getLossTypeCode()) ) {
			tmpTbcMdLossArtDVO.setLossTypeCode(tbcMdLossArtDVO.getLossTypeCode());
		}		
		if ( tbcMdLossArtDVO.getDutyClsfCode() != null && !"".equals(tbcMdLossArtDVO.getDutyClsfCode()) ) {
			tmpTbcMdLossArtDVO.setDutyClsfCode(tbcMdLossArtDVO.getDutyClsfCode());
		}		
		if ( tbcMdLossArtDVO.getPrtyReflYn() != null && !"".equals(tbcMdLossArtDVO.getPrtyReflYn()) ) {
			tmpTbcMdLossArtDVO.setPrtyReflYn(tbcMdLossArtDVO.getPrtyReflYn());
		}		
		if ( tbcMdLossArtDVO.getUseYn() != null && !"".equals(tbcMdLossArtDVO.getUseYn()) ) {
			tmpTbcMdLossArtDVO.setUseYn(tbcMdLossArtDVO.getUseYn());
		}		
		if ( tbcMdLossArtDVO.getFstRegDt() != null && !"".equals(tbcMdLossArtDVO.getFstRegDt()) ) {
			tmpTbcMdLossArtDVO.setFstRegDt(tbcMdLossArtDVO.getFstRegDt());
		}		
		if ( tbcMdLossArtDVO.getFstRegerId() != null && !"".equals(tbcMdLossArtDVO.getFstRegerId()) ) {
			tmpTbcMdLossArtDVO.setFstRegerId(tbcMdLossArtDVO.getFstRegerId());
		}		
		if ( tbcMdLossArtDVO.getFnlUpdDt() != null && !"".equals(tbcMdLossArtDVO.getFnlUpdDt()) ) {
			tmpTbcMdLossArtDVO.setFnlUpdDt(tbcMdLossArtDVO.getFnlUpdDt());
		}		
		if ( tbcMdLossArtDVO.getFnlUpderId() != null && !"".equals(tbcMdLossArtDVO.getFnlUpderId()) ) {
			tmpTbcMdLossArtDVO.setFnlUpderId(tbcMdLossArtDVO.getFnlUpderId());
		}		
		return updateTbcMdLossArt (tmpTbcMdLossArtDVO);
	}

/**
* insertBatchTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return int[]
*/
	@LocalName("insertBatchTbcMdLossArt")
	public int[] insertBatchTbcMdLossArt (final List tbcMdLossArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.insertBatchTbcMdLossArt.001*/  \n");
			sql.append(" TBC_MD_LOSS_ART (   \n");
			sql.append("        LOSS_ART_CODE , \n");
			sql.append("        LOSS_ART_DESC , \n");
			sql.append("        LOSS_TYPE_CODE , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossArtDVO tbcMdLossArtDVO = (TbcMdLossArtDVO)tbcMdLossArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtDesc());
							ps.setString(psCount++, tbcMdLossArtDVO.getLossTypeCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdLossArtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return int[]
*/
	@LocalName("updateBatchTbcMdLossArt")
	public int[] updateBatchTbcMdLossArt (final List tbcMdLossArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.updateBatchTbcMdLossArt.001*/  \n");
			sql.append(" TBC_MD_LOSS_ART \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_ART_DESC = ? , \n");
			sql.append("        LOSS_TYPE_CODE = ? , \n");
			sql.append("        DUTY_CLSF_CODE = ? , \n");
			sql.append("        PRTY_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LOSS_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossArtDVO tbcMdLossArtDVO = (TbcMdLossArtDVO)tbcMdLossArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtDesc());
							ps.setString(psCount++, tbcMdLossArtDVO.getLossTypeCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossArtDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
						}
							public int getBatchSize() {
									return tbcMdLossArtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdLossArt Method
* 
* @ref_table TBC_MD_LOSS_ART
* @return int[]
*/
	@LocalName("deleteBatchTbcMdLossArt")
	public int[] deleteBatchTbcMdLossArt (final List tbcMdLossArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdLossArtDEM.deleteBatchTbcMdLossArt.001*/  \n");
			sql.append(" TBC_MD_LOSS_ART \n");
			sql.append("  WHERE LOSS_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossArtDVO tbcMdLossArtDVO = (TbcMdLossArtDVO)tbcMdLossArtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossArtDVO.getLossArtCode());
						}
							public int getBatchSize() {
									return tbcMdLossArtDVOList.size();
							}
					}
		);			
	}

	
}