package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdBuyerDVO extends AbstractVo {

	@Length(30) 
	private String buyerCode;

	@Length(500) 
	private String buyerNm;

	@Length(500) 
	private String brndNm;

	@Length(500) 
	private String brndTypeNm;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getBuyerCode() {
		this.buyerCode = super.getValue(0);
		return this.buyerCode;
	}

	public void setBuyerCode(String buyerCode) {
        super.setValue(0, buyerCode);
		this.buyerCode = buyerCode;
	}
	
	public String getBuyerNm() {
		this.buyerNm = super.getValue(1);
		return this.buyerNm;
	}

	public void setBuyerNm(String buyerNm) {
        super.setValue(1, buyerNm);
		this.buyerNm = buyerNm;
	}
	
	public String getBrndNm() {
		this.brndNm = super.getValue(2);
		return this.brndNm;
	}

	public void setBrndNm(String brndNm) {
        super.setValue(2, brndNm);
		this.brndNm = brndNm;
	}
	
	public String getBrndTypeNm() {
		this.brndTypeNm = super.getValue(3);
		return this.brndTypeNm;
	}

	public void setBrndTypeNm(String brndTypeNm) {
        super.setValue(3, brndTypeNm);
		this.brndTypeNm = brndTypeNm;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(4);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(4, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(5);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(5, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(6);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(6, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(7);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(7, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}