package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_EQUIP_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdEquipClsfDEM extends AbstractDAO {


/**
* insertTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return int
*/
	@LocalName("insertTbcMdEquipClsf")
	public int insertTbcMdEquipClsf (final TbcMdEquipClsfDVO tbcMdEquipClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.insertTbcMdEquipClsf.001*/  \n");
			sql.append(" TBC_MD_EQUIP_CLSF (   \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        EQUIP_CLSF_NM , \n");
			sql.append("        EQUIP_CLSF_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfNm());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfDesc());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdEquipClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdEquipClsf Method")
	public int[][] updateBatchAllTbcMdEquipClsf (final List  tbcMdEquipClsfDVOList) {
		
		ArrayList updatetbcMdEquipClsfDVOList = new ArrayList();
		ArrayList insertttbcMdEquipClsfDVOList = new ArrayList();
		ArrayList deletetbcMdEquipClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdEquipClsfDVOList.size() ; i++) {
		  TbcMdEquipClsfDVO tbcMdEquipClsfDVO = (TbcMdEquipClsfDVO) tbcMdEquipClsfDVOList.get(i);
		  
		  if (tbcMdEquipClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdEquipClsfDVOList.add(tbcMdEquipClsfDVO);
		  else if (tbcMdEquipClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdEquipClsfDVOList.add(tbcMdEquipClsfDVO);
		  else if (tbcMdEquipClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdEquipClsfDVOList.add(tbcMdEquipClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdEquipClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdEquipClsf(insertttbcMdEquipClsfDVOList);
          
      if (updatetbcMdEquipClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdEquipClsf(updatetbcMdEquipClsfDVOList);
      
      if (deletetbcMdEquipClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdEquipClsf(deletetbcMdEquipClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return int
*/
	@LocalName("updateTbcMdEquipClsf")
	public int updateTbcMdEquipClsf (final TbcMdEquipClsfDVO tbcMdEquipClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.updateTbcMdEquipClsf.001*/  \n");
			sql.append(" TBC_MD_EQUIP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_CLSF_NM = ? , \n");
			sql.append("        EQUIP_CLSF_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE EQUIP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfNm());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfDesc());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return int
*/
	@LocalName("deleteTbcMdEquipClsf")
	public int deleteTbcMdEquipClsf (final TbcMdEquipClsfDVO tbcMdEquipClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.deleteTbcMdEquipClsf.001*/  \n");
			sql.append(" TBC_MD_EQUIP_CLSF \n");
			sql.append("  WHERE EQUIP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return TbcMdEquipClsfDVO 
*/
	@LocalName("selectTbcMdEquipClsf")
	public TbcMdEquipClsfDVO selectTbcMdEquipClsf (final TbcMdEquipClsfDVO tbcMdEquipClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.selectTbcMdEquipClsf.001*/  \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        EQUIP_CLSF_NM , \n");
			sql.append("        EQUIP_CLSF_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_EQUIP_CLSF \n");
			sql.append("  WHERE EQUIP_CLSF_CODE = ? \n");

		return (TbcMdEquipClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdEquipClsfDVO returnTbcMdEquipClsfDVO = new TbcMdEquipClsfDVO();
									returnTbcMdEquipClsfDVO.setEquipClsfCode(resultSet.getString("EQUIP_CLSF_CODE"));
									returnTbcMdEquipClsfDVO.setEquipClsfNm(resultSet.getString("EQUIP_CLSF_NM"));
									returnTbcMdEquipClsfDVO.setEquipClsfDesc(resultSet.getString("EQUIP_CLSF_DESC"));
									returnTbcMdEquipClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdEquipClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdEquipClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdEquipClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdEquipClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdEquipClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdEquipClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdEquipClsf Method")
	public int mergeTbcMdEquipClsf (final TbcMdEquipClsfDVO tbcMdEquipClsfDVO) {
		
		if ( selectTbcMdEquipClsf (tbcMdEquipClsfDVO) == null) {
			return insertTbcMdEquipClsf(tbcMdEquipClsfDVO);
		} else {
			return selectUpdateTbcMdEquipClsf (tbcMdEquipClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdEquipClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdEquipClsf Method")
	public int selectUpdateTbcMdEquipClsf (final TbcMdEquipClsfDVO tbcMdEquipClsfDVO) {
		
		TbcMdEquipClsfDVO tmpTbcMdEquipClsfDVO =  selectTbcMdEquipClsf (tbcMdEquipClsfDVO);
		if ( tbcMdEquipClsfDVO.getEquipClsfCode() != null && !"".equals(tbcMdEquipClsfDVO.getEquipClsfCode()) ) {
			tmpTbcMdEquipClsfDVO.setEquipClsfCode(tbcMdEquipClsfDVO.getEquipClsfCode());
		}		
		if ( tbcMdEquipClsfDVO.getEquipClsfNm() != null && !"".equals(tbcMdEquipClsfDVO.getEquipClsfNm()) ) {
			tmpTbcMdEquipClsfDVO.setEquipClsfNm(tbcMdEquipClsfDVO.getEquipClsfNm());
		}		
		if ( tbcMdEquipClsfDVO.getEquipClsfDesc() != null && !"".equals(tbcMdEquipClsfDVO.getEquipClsfDesc()) ) {
			tmpTbcMdEquipClsfDVO.setEquipClsfDesc(tbcMdEquipClsfDVO.getEquipClsfDesc());
		}		
		if ( tbcMdEquipClsfDVO.getUseYn() != null && !"".equals(tbcMdEquipClsfDVO.getUseYn()) ) {
			tmpTbcMdEquipClsfDVO.setUseYn(tbcMdEquipClsfDVO.getUseYn());
		}		
		if ( tbcMdEquipClsfDVO.getFstRegDt() != null && !"".equals(tbcMdEquipClsfDVO.getFstRegDt()) ) {
			tmpTbcMdEquipClsfDVO.setFstRegDt(tbcMdEquipClsfDVO.getFstRegDt());
		}		
		if ( tbcMdEquipClsfDVO.getFstRegerId() != null && !"".equals(tbcMdEquipClsfDVO.getFstRegerId()) ) {
			tmpTbcMdEquipClsfDVO.setFstRegerId(tbcMdEquipClsfDVO.getFstRegerId());
		}		
		if ( tbcMdEquipClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdEquipClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdEquipClsfDVO.setFnlUpdDt(tbcMdEquipClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdEquipClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdEquipClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdEquipClsfDVO.setFnlUpderId(tbcMdEquipClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdEquipClsf (tmpTbcMdEquipClsfDVO);
	}

/**
* insertBatchTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdEquipClsf")
	public int[] insertBatchTbcMdEquipClsf (final List tbcMdEquipClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.insertBatchTbcMdEquipClsf.001*/  \n");
			sql.append(" TBC_MD_EQUIP_CLSF (   \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        EQUIP_CLSF_NM , \n");
			sql.append("        EQUIP_CLSF_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdEquipClsfDVO tbcMdEquipClsfDVO = (TbcMdEquipClsfDVO)tbcMdEquipClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfNm());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfDesc());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdEquipClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdEquipClsf")
	public int[] updateBatchTbcMdEquipClsf (final List tbcMdEquipClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.updateBatchTbcMdEquipClsf.001*/  \n");
			sql.append(" TBC_MD_EQUIP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_CLSF_NM = ? , \n");
			sql.append("        EQUIP_CLSF_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE EQUIP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdEquipClsfDVO tbcMdEquipClsfDVO = (TbcMdEquipClsfDVO)tbcMdEquipClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfNm());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfDesc());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
						}
							public int getBatchSize() {
									return tbcMdEquipClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdEquipClsf Method
* 
* @ref_table TBC_MD_EQUIP_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdEquipClsf")
	public int[] deleteBatchTbcMdEquipClsf (final List tbcMdEquipClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdEquipClsfDEM.deleteBatchTbcMdEquipClsf.001*/  \n");
			sql.append(" TBC_MD_EQUIP_CLSF \n");
			sql.append("  WHERE EQUIP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdEquipClsfDVO tbcMdEquipClsfDVO = (TbcMdEquipClsfDVO)tbcMdEquipClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdEquipClsfDVO.getEquipClsfCode());
						}
							public int getBatchSize() {
									return tbcMdEquipClsfDVOList.size();
							}
					}
		);			
	}

	
}