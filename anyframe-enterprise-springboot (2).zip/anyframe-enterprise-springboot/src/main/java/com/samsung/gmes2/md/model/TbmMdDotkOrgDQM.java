package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdDotkOrgDQM extends AbstractDAO {


/**
*
* SELECT 
* 	FCT_CODE, 
* 	DOTK_CODE, 
* 	OPER_START_YMD, 
* 	OPER_FIN_YMD, 
* 	DOTK_NM, 
* 	LEADER_EMP_NO, 
* 	SLEADER_EMP_NO, 
* 	DOTK_DESC, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_DOTK_ORG 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($dotkCode) 
* AND DOTK_CODE = :dotkCode 
* #end 
* #if($operStartYmd) 
* AND OPER_START_YMD = :operStartYmd 
* #end 
* #if($operFinYmd) 
* AND OPER_FIN_YMD = :operFinYmd 
* #end 
* #if($dotkNm) 
* AND DOTK_NM = :dotkNm 
* #end 
* #if($leaderEmpNo) 
* AND LEADER_EMP_NO = :leaderEmpNo 
* #end 
* #if($sleaderEmpNo) 
* AND SLEADER_EMP_NO = :sleaderEmpNo 
* #end 
* #if($dotkDesc) 
* AND DOTK_DESC = :dotkDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	DOTK_CODE,  \n");
			sql.append(" 	OPER_START_YMD,  \n");
			sql.append(" 	OPER_FIN_YMD,  \n");
			sql.append(" 	DOTK_NM,  \n");
			sql.append(" 	LEADER_EMP_NO,  \n");
			sql.append(" 	SLEADER_EMP_NO,  \n");
			sql.append(" 	DOTK_DESC,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_DOTK_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkCode)  \n");
			sql.append(" AND DOTK_CODE = :dotkCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operStartYmd)  \n");
			sql.append(" AND OPER_START_YMD = :operStartYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operFinYmd)  \n");
			sql.append(" AND OPER_FIN_YMD = :operFinYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkNm)  \n");
			sql.append(" AND DOTK_NM = :dotkNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($leaderEmpNo)  \n");
			sql.append(" AND LEADER_EMP_NO = :leaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($sleaderEmpNo)  \n");
			sql.append(" AND SLEADER_EMP_NO = :sleaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkDesc)  \n");
			sql.append(" AND DOTK_DESC = :dotkDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdDotkOrgDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdDotkOrgDVO returnTbmMdDotkOrgDVO = new TbmMdDotkOrgDVO();
									returnTbmMdDotkOrgDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdDotkOrgDVO.setDotkCode(resultSet.getString("DOTK_CODE"));
									returnTbmMdDotkOrgDVO.setOperStartYmd(resultSet.getString("OPER_START_YMD"));
									returnTbmMdDotkOrgDVO.setOperFinYmd(resultSet.getString("OPER_FIN_YMD"));
									returnTbmMdDotkOrgDVO.setDotkNm(resultSet.getString("DOTK_NM"));
									returnTbmMdDotkOrgDVO.setLeaderEmpNo(resultSet.getString("LEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setSleaderEmpNo(resultSet.getString("SLEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setDotkDesc(resultSet.getString("DOTK_DESC"));
									returnTbmMdDotkOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdDotkOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdDotkOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdDotkOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdDotkOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	DOTK_CODE, 
* 	OPER_START_YMD, 
* 	OPER_FIN_YMD, 
* 	DOTK_NM, 
* 	LEADER_EMP_NO, 
* 	SLEADER_EMP_NO, 
* 	DOTK_DESC, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_DOTK_ORG 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($dotkCode) 
* AND DOTK_CODE = :dotkCode 
* #end 
* #if($operStartYmd) 
* AND OPER_START_YMD = :operStartYmd 
* #end 
* #if($operFinYmd) 
* AND OPER_FIN_YMD = :operFinYmd 
* #end 
* #if($dotkNm) 
* AND DOTK_NM = :dotkNm 
* #end 
* #if($leaderEmpNo) 
* AND LEADER_EMP_NO = :leaderEmpNo 
* #end 
* #if($sleaderEmpNo) 
* AND SLEADER_EMP_NO = :sleaderEmpNo 
* #end 
* #if($dotkDesc) 
* AND DOTK_DESC = :dotkDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	DOTK_CODE,  \n");
			sql.append(" 	OPER_START_YMD,  \n");
			sql.append(" 	OPER_FIN_YMD,  \n");
			sql.append(" 	DOTK_NM,  \n");
			sql.append(" 	LEADER_EMP_NO,  \n");
			sql.append(" 	SLEADER_EMP_NO,  \n");
			sql.append(" 	DOTK_DESC,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_DOTK_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkCode)  \n");
			sql.append(" AND DOTK_CODE = :dotkCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operStartYmd)  \n");
			sql.append(" AND OPER_START_YMD = :operStartYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operFinYmd)  \n");
			sql.append(" AND OPER_FIN_YMD = :operFinYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkNm)  \n");
			sql.append(" AND DOTK_NM = :dotkNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($leaderEmpNo)  \n");
			sql.append(" AND LEADER_EMP_NO = :leaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($sleaderEmpNo)  \n");
			sql.append(" AND SLEADER_EMP_NO = :sleaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkDesc)  \n");
			sql.append(" AND DOTK_DESC = :dotkDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdDotkOrgDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdDotkOrgDVO returnTbmMdDotkOrgDVO = new TbmMdDotkOrgDVO();
									returnTbmMdDotkOrgDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdDotkOrgDVO.setDotkCode(resultSet.getString("DOTK_CODE"));
									returnTbmMdDotkOrgDVO.setOperStartYmd(resultSet.getString("OPER_START_YMD"));
									returnTbmMdDotkOrgDVO.setOperFinYmd(resultSet.getString("OPER_FIN_YMD"));
									returnTbmMdDotkOrgDVO.setDotkNm(resultSet.getString("DOTK_NM"));
									returnTbmMdDotkOrgDVO.setLeaderEmpNo(resultSet.getString("LEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setSleaderEmpNo(resultSet.getString("SLEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setDotkDesc(resultSet.getString("DOTK_DESC"));
									returnTbmMdDotkOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdDotkOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdDotkOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdDotkOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdDotkOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	DOTK_CODE, 
* 	OPER_START_YMD, 
* 	OPER_FIN_YMD, 
* 	DOTK_NM, 
* 	LEADER_EMP_NO, 
* 	SLEADER_EMP_NO, 
* 	DOTK_DESC, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_DOTK_ORG 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($dotkCode) 
* AND DOTK_CODE = :dotkCode 
* #end 
* #if($operStartYmd) 
* AND OPER_START_YMD = :operStartYmd 
* #end 
* #if($operFinYmd) 
* AND OPER_FIN_YMD = :operFinYmd 
* #end 
* #if($dotkNm) 
* AND DOTK_NM = :dotkNm 
* #end 
* #if($leaderEmpNo) 
* AND LEADER_EMP_NO = :leaderEmpNo 
* #end 
* #if($sleaderEmpNo) 
* AND SLEADER_EMP_NO = :sleaderEmpNo 
* #end 
* #if($dotkDesc) 
* AND DOTK_DESC = :dotkDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	DOTK_CODE,  \n");
			sql.append(" 	OPER_START_YMD,  \n");
			sql.append(" 	OPER_FIN_YMD,  \n");
			sql.append(" 	DOTK_NM,  \n");
			sql.append(" 	LEADER_EMP_NO,  \n");
			sql.append(" 	SLEADER_EMP_NO,  \n");
			sql.append(" 	DOTK_DESC,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_DOTK_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkCode)  \n");
			sql.append(" AND DOTK_CODE = :dotkCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operStartYmd)  \n");
			sql.append(" AND OPER_START_YMD = :operStartYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operFinYmd)  \n");
			sql.append(" AND OPER_FIN_YMD = :operFinYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkNm)  \n");
			sql.append(" AND DOTK_NM = :dotkNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($leaderEmpNo)  \n");
			sql.append(" AND LEADER_EMP_NO = :leaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($sleaderEmpNo)  \n");
			sql.append(" AND SLEADER_EMP_NO = :sleaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkDesc)  \n");
			sql.append(" AND DOTK_DESC = :dotkDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdDotkOrgDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdDotkOrgDVO returnTbmMdDotkOrgDVO = new TbmMdDotkOrgDVO();
									returnTbmMdDotkOrgDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdDotkOrgDVO.setDotkCode(resultSet.getString("DOTK_CODE"));
									returnTbmMdDotkOrgDVO.setOperStartYmd(resultSet.getString("OPER_START_YMD"));
									returnTbmMdDotkOrgDVO.setOperFinYmd(resultSet.getString("OPER_FIN_YMD"));
									returnTbmMdDotkOrgDVO.setDotkNm(resultSet.getString("DOTK_NM"));
									returnTbmMdDotkOrgDVO.setLeaderEmpNo(resultSet.getString("LEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setSleaderEmpNo(resultSet.getString("SLEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setDotkDesc(resultSet.getString("DOTK_DESC"));
									returnTbmMdDotkOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdDotkOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdDotkOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdDotkOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdDotkOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	FCT_CODE, 
* 	DOTK_CODE, 
* 	OPER_START_YMD, 
* 	OPER_FIN_YMD, 
* 	DOTK_NM, 
* 	LEADER_EMP_NO, 
* 	SLEADER_EMP_NO, 
* 	DOTK_DESC, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_DOTK_ORG 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($dotkCode) 
* AND DOTK_CODE = :dotkCode 
* #end 
* #if($operStartYmd) 
* AND OPER_START_YMD = :operStartYmd 
* #end 
* #if($operFinYmd) 
* AND OPER_FIN_YMD = :operFinYmd 
* #end 
* #if($dotkNm) 
* AND DOTK_NM = :dotkNm 
* #end 
* #if($leaderEmpNo) 
* AND LEADER_EMP_NO = :leaderEmpNo 
* #end 
* #if($sleaderEmpNo) 
* AND SLEADER_EMP_NO = :sleaderEmpNo 
* #end 
* #if($dotkDesc) 
* AND DOTK_DESC = :dotkDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	DOTK_CODE,  \n");
			sql.append(" 	OPER_START_YMD,  \n");
			sql.append(" 	OPER_FIN_YMD,  \n");
			sql.append(" 	DOTK_NM,  \n");
			sql.append(" 	LEADER_EMP_NO,  \n");
			sql.append(" 	SLEADER_EMP_NO,  \n");
			sql.append(" 	DOTK_DESC,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_DOTK_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkCode)  \n");
			sql.append(" AND DOTK_CODE = :dotkCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operStartYmd)  \n");
			sql.append(" AND OPER_START_YMD = :operStartYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operFinYmd)  \n");
			sql.append(" AND OPER_FIN_YMD = :operFinYmd  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkNm)  \n");
			sql.append(" AND DOTK_NM = :dotkNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($leaderEmpNo)  \n");
			sql.append(" AND LEADER_EMP_NO = :leaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($sleaderEmpNo)  \n");
			sql.append(" AND SLEADER_EMP_NO = :sleaderEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dotkDesc)  \n");
			sql.append(" AND DOTK_DESC = :dotkDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdDotkOrgDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdDotkOrgDVO returnTbmMdDotkOrgDVO = new TbmMdDotkOrgDVO();
									returnTbmMdDotkOrgDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdDotkOrgDVO.setDotkCode(resultSet.getString("DOTK_CODE"));
									returnTbmMdDotkOrgDVO.setOperStartYmd(resultSet.getString("OPER_START_YMD"));
									returnTbmMdDotkOrgDVO.setOperFinYmd(resultSet.getString("OPER_FIN_YMD"));
									returnTbmMdDotkOrgDVO.setDotkNm(resultSet.getString("DOTK_NM"));
									returnTbmMdDotkOrgDVO.setLeaderEmpNo(resultSet.getString("LEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setSleaderEmpNo(resultSet.getString("SLEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setDotkDesc(resultSet.getString("DOTK_DESC"));
									returnTbmMdDotkOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdDotkOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdDotkOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdDotkOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdDotkOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}