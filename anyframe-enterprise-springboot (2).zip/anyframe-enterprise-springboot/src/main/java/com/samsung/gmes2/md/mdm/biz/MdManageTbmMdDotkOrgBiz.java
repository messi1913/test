/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbmMdDotkOrgBiz
 * Description : 테이블 TbmMdDotkOrg 에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.19          김영준          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.cmm.util.MdMdmBaseUtil;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDVO;
import com.samsung.gmes2.md.model.TbmMdDotkOrgDVO;

public class MdManageTbmMdDotkOrgBiz {
	/**
	 * CrudUtil 클래스의 create 메서드 재사용
	 * 
	 * Insert하기전에 Insert에 해당하는 FK가 존재하는지 확인합니다.
	 * 테이블에 해당하는 기본키가 입력되어있는지 확인합니다.
	 * NotNull이 되지않아야할 컬럼에 데이터가 존재하는지 확인합니다.
	 * 
	 * 
	 */
	public TbmMdDotkOrgDVO createTbmMdDotkOrg(
			TbmMdDotkOrgDVO tbmMdDotkOrgDVO) throws Exception {
		/*
		 * 외래키 추가
		 * LEADER_EMP_NO	조장사원번호 * mBI의 인사정보테이블을 활용할 계획
		 * SLEADER_EMP_NO	부조장사원번호 * mBI의 인사정보테이블을 활용할 계획
		 */
		MdMdmBaseUtil.checkFkData(tbmMdDotkOrgDVO, new TbcMdCommOrgDVO(), "fctCode:commOrgCode");
		return CrudUtil.create(tbmMdDotkOrgDVO);
	}

	/**
	 * CrudUtil 클래스의 delete 메서드 재사용
	 * 기본키를 기본조건으로 delete합니다.
	 * 해당 테이블은 useYn이 존재하지 않기때문에 데이터 컬럼이 삭제
	 */
	public TbmMdDotkOrgDVO deleteTbmMdDotkOrg(
			TbmMdDotkOrgDVO tbmMdDotkOrgDVO) throws Exception {
		return CrudUtil.delete(tbmMdDotkOrgDVO);
	}

	/**
	 * CrudUtil 클래스의 update 메서드 재사용
	 * 
	 * 미처리 : 데이터 Update시 최초등록시간, 최초등록자 아이디
	 * 
	 * useYn이 'N'일경우 데이터를 Update할 수 없습니다.
	 * useYn이 'Y'일경우만 데이터를 Update할 수 있습니다.
	 * 기본키를 기본조건으로 Update합니다.
	 * 
	 */
	public TbmMdDotkOrgDVO updateTbmMdDotkOrg(
			TbmMdDotkOrgDVO tbmMdDotkOrgDVO) throws Exception {
		MdMdmBaseUtil.checkFkData(tbmMdDotkOrgDVO, new TbcMdCommOrgDVO(), "fctCode:commOrgCode");
		return CrudUtil.update(tbmMdDotkOrgDVO);
	}
	
	/**
	 * CrudUtil 클래스의 select 메서드 재사용
	 * 
	 * 기본키를 기본조건으로 Select 합니다.
	 */
	public TbmMdDotkOrgDVO getTbmMdDotkOrg(
			TbmMdDotkOrgDVO tbmMdDotkOrgDVO) throws Exception {
		return CrudUtil.get(tbmMdDotkOrgDVO);
	}
	
	/**
	 * CrudUtil 클래스의 list 메서드 재사용
	 * 기본키를 기본조건으로 Select 합니다.
	 */
	public List<?> listTbmMdDotkOrg(
			TbmMdDotkOrgDVO tbmMdDotkOrgDVO) throws Exception {
		return CrudUtil.list0(TbmMdDotkOrgDVO.class,
				tbmMdDotkOrgDVO, 0, 0);
	}

}
