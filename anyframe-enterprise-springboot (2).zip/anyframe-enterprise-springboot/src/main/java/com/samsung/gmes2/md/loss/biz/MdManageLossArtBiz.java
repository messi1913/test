package com.samsung.gmes2.md.loss.biz;

public class MdManageLossArtBiz {

	/**
	 * 유실항목코드 목록 조회
	 */
	public void listLossArtCode(){}

	/**
	 * 유실항목코드 목록 저장
	 */
	public void saveLossArtCode(){}

}
