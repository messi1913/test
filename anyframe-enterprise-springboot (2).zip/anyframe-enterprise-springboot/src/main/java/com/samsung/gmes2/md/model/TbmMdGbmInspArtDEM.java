package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_GBM_INSP_ART
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdGbmInspArtDEM extends AbstractDAO {


/**
* insertTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return int
*/
	@LocalName("insertTbmMdGbmInspArt")
	public int insertTbmMdGbmInspArt (final TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.insertTbmMdGbmInspArt.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_ART (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        MFG_GUBUN_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getMfgGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdGbmInspArt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdGbmInspArt Method")
	public int[][] updateBatchAllTbmMdGbmInspArt (final List  tbmMdGbmInspArtDVOList) {
		
		ArrayList updatetbmMdGbmInspArtDVOList = new ArrayList();
		ArrayList insertttbmMdGbmInspArtDVOList = new ArrayList();
		ArrayList deletetbmMdGbmInspArtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdGbmInspArtDVOList.size() ; i++) {
		  TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO = (TbmMdGbmInspArtDVO) tbmMdGbmInspArtDVOList.get(i);
		  
		  if (tbmMdGbmInspArtDVO.getSqlAction().equals("C"))
		      insertttbmMdGbmInspArtDVOList.add(tbmMdGbmInspArtDVO);
		  else if (tbmMdGbmInspArtDVO.getSqlAction().equals("U"))
		      updatetbmMdGbmInspArtDVOList.add(tbmMdGbmInspArtDVO);
		  else if (tbmMdGbmInspArtDVO.getSqlAction().equals("D"))
		      deletetbmMdGbmInspArtDVOList.add(tbmMdGbmInspArtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdGbmInspArtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdGbmInspArt(insertttbmMdGbmInspArtDVOList);
          
      if (updatetbmMdGbmInspArtDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdGbmInspArt(updatetbmMdGbmInspArtDVOList);
      
      if (deletetbmMdGbmInspArtDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdGbmInspArt(deletetbmMdGbmInspArtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return int
*/
	@LocalName("updateTbmMdGbmInspArt")
	public int updateTbmMdGbmInspArt (final TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.updateTbmMdGbmInspArt.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_ART \n");
			sql.append(" SET   \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        MFG_GUBUN_CODE = ? , \n");
			sql.append("        PROD_ABBR_CODE = ? , \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND INSP_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getMfgGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
						}
					}
		);			
	}

/**
* deleteTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return int
*/
	@LocalName("deleteTbmMdGbmInspArt")
	public int deleteTbmMdGbmInspArt (final TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.deleteTbmMdGbmInspArt.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_ART \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
						}
					}
		);			
	}

/**
* selectTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return TbmMdGbmInspArtDVO 
*/
	@LocalName("selectTbmMdGbmInspArt")
	public TbmMdGbmInspArtDVO selectTbmMdGbmInspArt (final TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.selectTbmMdGbmInspArt.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        MFG_GUBUN_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_GBM_INSP_ART \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_ART_CODE = ? \n");

		return (TbmMdGbmInspArtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdGbmInspArtDVO returnTbmMdGbmInspArtDVO = new TbmMdGbmInspArtDVO();
									returnTbmMdGbmInspArtDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdGbmInspArtDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbmMdGbmInspArtDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbmMdGbmInspArtDVO.setMfgGubunCode(resultSet.getString("MFG_GUBUN_CODE"));
									returnTbmMdGbmInspArtDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbmMdGbmInspArtDVO.setIfDt(resultSet.getString("IF_DT"));
									returnTbmMdGbmInspArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdGbmInspArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdGbmInspArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdGbmInspArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdGbmInspArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdGbmInspArtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdGbmInspArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdGbmInspArt Method")
	public int mergeTbmMdGbmInspArt (final TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO) {
		
		if ( selectTbmMdGbmInspArt (tbmMdGbmInspArtDVO) == null) {
			return insertTbmMdGbmInspArt(tbmMdGbmInspArtDVO);
		} else {
			return selectUpdateTbmMdGbmInspArt (tbmMdGbmInspArtDVO);
		}
	}

	/**
	 * selectUpdateTbmMdGbmInspArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdGbmInspArt Method")
	public int selectUpdateTbmMdGbmInspArt (final TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO) {
		
		TbmMdGbmInspArtDVO tmpTbmMdGbmInspArtDVO =  selectTbmMdGbmInspArt (tbmMdGbmInspArtDVO);
		if ( tbmMdGbmInspArtDVO.getGbmCode() != null && !"".equals(tbmMdGbmInspArtDVO.getGbmCode()) ) {
			tmpTbmMdGbmInspArtDVO.setGbmCode(tbmMdGbmInspArtDVO.getGbmCode());
		}		
		if ( tbmMdGbmInspArtDVO.getInspArtCode() != null && !"".equals(tbmMdGbmInspArtDVO.getInspArtCode()) ) {
			tmpTbmMdGbmInspArtDVO.setInspArtCode(tbmMdGbmInspArtDVO.getInspArtCode());
		}		
		if ( tbmMdGbmInspArtDVO.getProcOutGubunCode() != null && !"".equals(tbmMdGbmInspArtDVO.getProcOutGubunCode()) ) {
			tmpTbmMdGbmInspArtDVO.setProcOutGubunCode(tbmMdGbmInspArtDVO.getProcOutGubunCode());
		}		
		if ( tbmMdGbmInspArtDVO.getMfgGubunCode() != null && !"".equals(tbmMdGbmInspArtDVO.getMfgGubunCode()) ) {
			tmpTbmMdGbmInspArtDVO.setMfgGubunCode(tbmMdGbmInspArtDVO.getMfgGubunCode());
		}		
		if ( tbmMdGbmInspArtDVO.getProdAbbrCode() != null && !"".equals(tbmMdGbmInspArtDVO.getProdAbbrCode()) ) {
			tmpTbmMdGbmInspArtDVO.setProdAbbrCode(tbmMdGbmInspArtDVO.getProdAbbrCode());
		}		
		if ( tbmMdGbmInspArtDVO.getIfDt() != null && !"".equals(tbmMdGbmInspArtDVO.getIfDt()) ) {
			tmpTbmMdGbmInspArtDVO.setIfDt(tbmMdGbmInspArtDVO.getIfDt());
		}		
		if ( tbmMdGbmInspArtDVO.getUseYn() != null && !"".equals(tbmMdGbmInspArtDVO.getUseYn()) ) {
			tmpTbmMdGbmInspArtDVO.setUseYn(tbmMdGbmInspArtDVO.getUseYn());
		}		
		if ( tbmMdGbmInspArtDVO.getFstRegDt() != null && !"".equals(tbmMdGbmInspArtDVO.getFstRegDt()) ) {
			tmpTbmMdGbmInspArtDVO.setFstRegDt(tbmMdGbmInspArtDVO.getFstRegDt());
		}		
		if ( tbmMdGbmInspArtDVO.getFstRegerId() != null && !"".equals(tbmMdGbmInspArtDVO.getFstRegerId()) ) {
			tmpTbmMdGbmInspArtDVO.setFstRegerId(tbmMdGbmInspArtDVO.getFstRegerId());
		}		
		if ( tbmMdGbmInspArtDVO.getFnlUpdDt() != null && !"".equals(tbmMdGbmInspArtDVO.getFnlUpdDt()) ) {
			tmpTbmMdGbmInspArtDVO.setFnlUpdDt(tbmMdGbmInspArtDVO.getFnlUpdDt());
		}		
		if ( tbmMdGbmInspArtDVO.getFnlUpderId() != null && !"".equals(tbmMdGbmInspArtDVO.getFnlUpderId()) ) {
			tmpTbmMdGbmInspArtDVO.setFnlUpderId(tbmMdGbmInspArtDVO.getFnlUpderId());
		}		
		return updateTbmMdGbmInspArt (tmpTbmMdGbmInspArtDVO);
	}

/**
* insertBatchTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return int[]
*/
	@LocalName("insertBatchTbmMdGbmInspArt")
	public int[] insertBatchTbmMdGbmInspArt (final List tbmMdGbmInspArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.insertBatchTbmMdGbmInspArt.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_ART (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        MFG_GUBUN_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO = (TbmMdGbmInspArtDVO)tbmMdGbmInspArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getMfgGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdGbmInspArtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return int[]
*/
	@LocalName("updateBatchTbmMdGbmInspArt")
	public int[] updateBatchTbmMdGbmInspArt (final List tbmMdGbmInspArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.updateBatchTbmMdGbmInspArt.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_ART \n");
			sql.append(" SET   \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        MFG_GUBUN_CODE = ? , \n");
			sql.append("        PROD_ABBR_CODE = ? , \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND INSP_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO = (TbmMdGbmInspArtDVO)tbmMdGbmInspArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getMfgGubunCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getIfDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
						}
							public int getBatchSize() {
									return tbmMdGbmInspArtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdGbmInspArt Method
* 
* @ref_table TBM_MD_GBM_INSP_ART
* @return int[]
*/
	@LocalName("deleteBatchTbmMdGbmInspArt")
	public int[] deleteBatchTbmMdGbmInspArt (final List tbmMdGbmInspArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmInspArtDEM.deleteBatchTbmMdGbmInspArt.001*/  \n");
			sql.append(" TBM_MD_GBM_INSP_ART \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND INSP_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmInspArtDVO tbmMdGbmInspArtDVO = (TbmMdGbmInspArtDVO)tbmMdGbmInspArtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmInspArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmInspArtDVO.getInspArtCode());
						}
							public int getBatchSize() {
									return tbmMdGbmInspArtDVOList.size();
							}
					}
		);			
	}

	
}