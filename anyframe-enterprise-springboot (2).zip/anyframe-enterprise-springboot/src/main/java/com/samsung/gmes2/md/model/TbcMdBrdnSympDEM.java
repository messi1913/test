package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_BRDN_SYMP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdBrdnSympDEM extends AbstractDAO {


/**
* insertTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return int
*/
	@LocalName("insertTbcMdBrdnSymp")
	public int insertTbcMdBrdnSymp (final TbcMdBrdnSympDVO tbcMdBrdnSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.insertTbcMdBrdnSymp.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP (   \n");
			sql.append("        BRDN_SYMP_CODE , \n");
			sql.append("        BRDN_SYMP_CLSF_CODE , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        BRDN_SYMP_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympNm());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdBrdnSymp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdBrdnSymp Method")
	public int[][] updateBatchAllTbcMdBrdnSymp (final List  tbcMdBrdnSympDVOList) {
		
		ArrayList updatetbcMdBrdnSympDVOList = new ArrayList();
		ArrayList insertttbcMdBrdnSympDVOList = new ArrayList();
		ArrayList deletetbcMdBrdnSympDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdBrdnSympDVOList.size() ; i++) {
		  TbcMdBrdnSympDVO tbcMdBrdnSympDVO = (TbcMdBrdnSympDVO) tbcMdBrdnSympDVOList.get(i);
		  
		  if (tbcMdBrdnSympDVO.getSqlAction().equals("C"))
		      insertttbcMdBrdnSympDVOList.add(tbcMdBrdnSympDVO);
		  else if (tbcMdBrdnSympDVO.getSqlAction().equals("U"))
		      updatetbcMdBrdnSympDVOList.add(tbcMdBrdnSympDVO);
		  else if (tbcMdBrdnSympDVO.getSqlAction().equals("D"))
		      deletetbcMdBrdnSympDVOList.add(tbcMdBrdnSympDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdBrdnSympDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdBrdnSymp(insertttbcMdBrdnSympDVOList);
          
      if (updatetbcMdBrdnSympDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdBrdnSymp(updatetbcMdBrdnSympDVOList);
      
      if (deletetbcMdBrdnSympDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdBrdnSymp(deletetbcMdBrdnSympDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return int
*/
	@LocalName("updateTbcMdBrdnSymp")
	public int updateTbcMdBrdnSymp (final TbcMdBrdnSympDVO tbcMdBrdnSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.updateTbcMdBrdnSymp.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP \n");
			sql.append(" SET   \n");
			sql.append("        BRDN_SYMP_CLSF_CODE = ? , \n");
			sql.append("        EQUIP_CLSF_CODE = ? , \n");
			sql.append("        BRDN_SYMP_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_SYMP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympNm());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
						}
					}
		);			
	}

/**
* deleteTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return int
*/
	@LocalName("deleteTbcMdBrdnSymp")
	public int deleteTbcMdBrdnSymp (final TbcMdBrdnSympDVO tbcMdBrdnSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.deleteTbcMdBrdnSymp.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP \n");
			sql.append("  WHERE BRDN_SYMP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
						}
					}
		);			
	}

/**
* selectTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return TbcMdBrdnSympDVO 
*/
	@LocalName("selectTbcMdBrdnSymp")
	public TbcMdBrdnSympDVO selectTbcMdBrdnSymp (final TbcMdBrdnSympDVO tbcMdBrdnSympDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.selectTbcMdBrdnSymp.001*/  \n");
			sql.append("        BRDN_SYMP_CODE , \n");
			sql.append("        BRDN_SYMP_CLSF_CODE , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        BRDN_SYMP_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_BRDN_SYMP \n");
			sql.append("  WHERE BRDN_SYMP_CODE = ? \n");

		return (TbcMdBrdnSympDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdBrdnSympDVO returnTbcMdBrdnSympDVO = new TbcMdBrdnSympDVO();
									returnTbcMdBrdnSympDVO.setBrdnSympCode(resultSet.getString("BRDN_SYMP_CODE"));
									returnTbcMdBrdnSympDVO.setBrdnSympClsfCode(resultSet.getString("BRDN_SYMP_CLSF_CODE"));
									returnTbcMdBrdnSympDVO.setEquipClsfCode(resultSet.getString("EQUIP_CLSF_CODE"));
									returnTbcMdBrdnSympDVO.setBrdnSympNm(resultSet.getString("BRDN_SYMP_NM"));
									returnTbcMdBrdnSympDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdBrdnSympDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdBrdnSympDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdBrdnSympDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdBrdnSympDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdBrdnSympDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdBrdnSymp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdBrdnSymp Method")
	public int mergeTbcMdBrdnSymp (final TbcMdBrdnSympDVO tbcMdBrdnSympDVO) {
		
		if ( selectTbcMdBrdnSymp (tbcMdBrdnSympDVO) == null) {
			return insertTbcMdBrdnSymp(tbcMdBrdnSympDVO);
		} else {
			return selectUpdateTbcMdBrdnSymp (tbcMdBrdnSympDVO);
		}
	}

	/**
	 * selectUpdateTbcMdBrdnSymp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdBrdnSymp Method")
	public int selectUpdateTbcMdBrdnSymp (final TbcMdBrdnSympDVO tbcMdBrdnSympDVO) {
		
		TbcMdBrdnSympDVO tmpTbcMdBrdnSympDVO =  selectTbcMdBrdnSymp (tbcMdBrdnSympDVO);
		if ( tbcMdBrdnSympDVO.getBrdnSympCode() != null && !"".equals(tbcMdBrdnSympDVO.getBrdnSympCode()) ) {
			tmpTbcMdBrdnSympDVO.setBrdnSympCode(tbcMdBrdnSympDVO.getBrdnSympCode());
		}		
		if ( tbcMdBrdnSympDVO.getBrdnSympClsfCode() != null && !"".equals(tbcMdBrdnSympDVO.getBrdnSympClsfCode()) ) {
			tmpTbcMdBrdnSympDVO.setBrdnSympClsfCode(tbcMdBrdnSympDVO.getBrdnSympClsfCode());
		}		
		if ( tbcMdBrdnSympDVO.getEquipClsfCode() != null && !"".equals(tbcMdBrdnSympDVO.getEquipClsfCode()) ) {
			tmpTbcMdBrdnSympDVO.setEquipClsfCode(tbcMdBrdnSympDVO.getEquipClsfCode());
		}		
		if ( tbcMdBrdnSympDVO.getBrdnSympNm() != null && !"".equals(tbcMdBrdnSympDVO.getBrdnSympNm()) ) {
			tmpTbcMdBrdnSympDVO.setBrdnSympNm(tbcMdBrdnSympDVO.getBrdnSympNm());
		}		
		if ( tbcMdBrdnSympDVO.getUseYn() != null && !"".equals(tbcMdBrdnSympDVO.getUseYn()) ) {
			tmpTbcMdBrdnSympDVO.setUseYn(tbcMdBrdnSympDVO.getUseYn());
		}		
		if ( tbcMdBrdnSympDVO.getFstRegDt() != null && !"".equals(tbcMdBrdnSympDVO.getFstRegDt()) ) {
			tmpTbcMdBrdnSympDVO.setFstRegDt(tbcMdBrdnSympDVO.getFstRegDt());
		}		
		if ( tbcMdBrdnSympDVO.getFstRegerId() != null && !"".equals(tbcMdBrdnSympDVO.getFstRegerId()) ) {
			tmpTbcMdBrdnSympDVO.setFstRegerId(tbcMdBrdnSympDVO.getFstRegerId());
		}		
		if ( tbcMdBrdnSympDVO.getFnlUpdDt() != null && !"".equals(tbcMdBrdnSympDVO.getFnlUpdDt()) ) {
			tmpTbcMdBrdnSympDVO.setFnlUpdDt(tbcMdBrdnSympDVO.getFnlUpdDt());
		}		
		if ( tbcMdBrdnSympDVO.getFnlUpderId() != null && !"".equals(tbcMdBrdnSympDVO.getFnlUpderId()) ) {
			tmpTbcMdBrdnSympDVO.setFnlUpderId(tbcMdBrdnSympDVO.getFnlUpderId());
		}		
		return updateTbcMdBrdnSymp (tmpTbcMdBrdnSympDVO);
	}

/**
* insertBatchTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return int[]
*/
	@LocalName("insertBatchTbcMdBrdnSymp")
	public int[] insertBatchTbcMdBrdnSymp (final List tbcMdBrdnSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.insertBatchTbcMdBrdnSymp.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP (   \n");
			sql.append("        BRDN_SYMP_CODE , \n");
			sql.append("        BRDN_SYMP_CLSF_CODE , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        BRDN_SYMP_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnSympDVO tbcMdBrdnSympDVO = (TbcMdBrdnSympDVO)tbcMdBrdnSympDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympNm());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdBrdnSympDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return int[]
*/
	@LocalName("updateBatchTbcMdBrdnSymp")
	public int[] updateBatchTbcMdBrdnSymp (final List tbcMdBrdnSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.updateBatchTbcMdBrdnSymp.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP \n");
			sql.append(" SET   \n");
			sql.append("        BRDN_SYMP_CLSF_CODE = ? , \n");
			sql.append("        EQUIP_CLSF_CODE = ? , \n");
			sql.append("        BRDN_SYMP_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_SYMP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnSympDVO tbcMdBrdnSympDVO = (TbcMdBrdnSympDVO)tbcMdBrdnSympDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympNm());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnSympDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdBrdnSymp Method
* 
* @ref_table TBC_MD_BRDN_SYMP
* @return int[]
*/
	@LocalName("deleteBatchTbcMdBrdnSymp")
	public int[] deleteBatchTbcMdBrdnSymp (final List tbcMdBrdnSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnSympDEM.deleteBatchTbcMdBrdnSymp.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP \n");
			sql.append("  WHERE BRDN_SYMP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnSympDVO tbcMdBrdnSympDVO = (TbcMdBrdnSympDVO)tbcMdBrdnSympDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnSympDVO.getBrdnSympCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnSympDVOList.size();
							}
					}
		);			
	}

	
}