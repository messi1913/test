package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbhMcOiDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String revNo;

	@Length(50) @NotNull
	private String pgmCode;

	@Length(50) @NotNull
	private String standFrmCode;

	@Length(50) 
	private String oiCtgrCode;


	public String getRevNo() {
		this.revNo = super.getValue("revNo");
		return this.revNo;
	}

	public void setRevNo(String revNo) {
        super.setValue("revNo", revNo);
		this.revNo = revNo;
	}
	
	public String getPgmCode() {
		this.pgmCode = super.getValue("pgmCode");
		return this.pgmCode;
	}

	public void setPgmCode(String pgmCode) {
        super.setValue("pgmCode", pgmCode);
		this.pgmCode = pgmCode;
	}
	
	public String getStandFrmCode() {
		this.standFrmCode = super.getValue("standFrmCode");
		return this.standFrmCode;
	}

	public void setStandFrmCode(String standFrmCode) {
        super.setValue("standFrmCode", standFrmCode);
		this.standFrmCode = standFrmCode;
	}
	
	public String getOiCtgrCode() {
		this.oiCtgrCode = super.getValue("oiCtgrCode");
		return this.oiCtgrCode;
	}

	public void setOiCtgrCode(String oiCtgrCode) {
        super.setValue("oiCtgrCode", oiCtgrCode);
		this.oiCtgrCode = oiCtgrCode;
	}
	
}