package com.samsung.gmes2.md.equipment.app;

public class MDU521M01App {

	/**
	 * 설비그룹 목록 초기설정
	 */
	public void initEquipGrp(){}

	/**
	 * 설비그룹 목록 조회
	 */
	public void listEquipGrp(){}

	/**
	 * 설비그룹 목록 엑셀 다운로드
	 */
	public void excelEquipGrp(){}

}
