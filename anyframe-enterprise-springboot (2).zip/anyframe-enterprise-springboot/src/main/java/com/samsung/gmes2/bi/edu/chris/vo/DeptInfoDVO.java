package com.samsung.gmes2.bi.edu.chris.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * ...
 * @stereotype DAOVO
 * @author Chris
 */
@LocalName("부서정보DVO")
public class DeptInfoDVO extends AbstractDVO {

	@LocalName("부서코드") @Length(10) 
	private String deptCode;

	@LocalName("부서명") @Length(50) 
	private String deptName;


	/**
	 * 부서코드 Getter Method
	 * 
	 * @return 부서코드
	 */
	@LocalName("부서코드 Getter Method")
	public String getDeptCode() {
		this.deptCode = super.getValue("deptCode");
		return this.deptCode;
	}

	/**
	 * 부서코드 Setter Method
	 * 
	 * @param String 부서코드
	 */
	@LocalName("부서코드 Setter Method")
	public void setDeptCode(String deptCode) {
        super.setValue("deptCode", deptCode);
		this.deptCode = deptCode;
	}
	
	/**
	 * 부서명 Getter Method
	 * 
	 * @return 부서명
	 */
	@LocalName("부서명 Getter Method")
	public String getDeptName() {
		this.deptName = super.getValue("deptName");
		return this.deptName;
	}

	/**
	 * 부서명 Setter Method
	 * 
	 * @param String 부서명
	 */
	@LocalName("부서명 Setter Method")
	public void setDeptName(String deptName) {
        super.setValue("deptName", deptName);
		this.deptName = deptName;
	}
	
}