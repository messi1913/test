package com.samsung.gmes2.md.loss.app;

public class MDU454M01App {

	/**
	 * 고장조치코드 목록 초기설정
	 */
	public void initBrdnActCode(){}

	/**
	 * 고장조치코드 목록 조회
	 */
	public void listBrdnActCode(){}

	/**
	 * 고장조치코드 목록 엑셀 다운로드
	 */
	public void excelBrdnActCode(){}

	/**
	 * 고장조치코드 목록 저장
	 */
	public void saveBrdnActCode(){}

}
