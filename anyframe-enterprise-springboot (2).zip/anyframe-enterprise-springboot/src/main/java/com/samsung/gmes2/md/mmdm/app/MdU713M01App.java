package com.samsung.gmes2.md.mmdm.app;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.md.cmm.MdConstants;
import com.samsung.gmes2.md.mdm.biz.MdManageTbcMdCommOrgBiz;
import com.samsung.gmes2.md.mmdm.vo.MdU713M01DQM;
import com.samsung.gmes2.md.mmdm.vo.MdU713M01SVO;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;

/**
 * 법인코드
 * 
 * @author sjlee
 */
@Service
public class MdU713M01App
{
    private MdManageTbcMdCommOrgBiz mdManageTbcMdCommOrgBiz;

    public MdManageTbcMdCommOrgBiz getMdManageTbcMdCommOrgBiz( )
    {
        if ( mdManageTbcMdCommOrgBiz == null )
            mdManageTbcMdCommOrgBiz = BaseUtil.getBean( MdManageTbcMdCommOrgBiz.class );
        return mdManageTbcMdCommOrgBiz;
    }

    public void setMdManageTbcMdCommOrgBiz( MdManageTbcMdCommOrgBiz mdManageTbcMdCommOrgBiz )
    {
        this.mdManageTbcMdCommOrgBiz = mdManageTbcMdCommOrgBiz;
    }

    /**
     * 법인코드 리스트를 조회한다.
     * 
     * @name_ko 법인코드 조회
     */
    public MdU713M01SVO listCorporationCode( MdU713M01SVO vo ) throws Exception
    {
        TbcMdCommOrgDVO dvo = vo.getTbcMdCommOrgDVO( );

        if ( dvo != null )
        {
            dvo.setCommOrgTypeCode( MdConstants.REGION_CODE );
        }

        Map<String, Object> map = BaseUtil.toMap( dvo );
        List<TbcMdCommOrgDVO> dvoList = BaseUtil.getBean( MdU713M01DQM.class ).dListCorporationCode( map, 1, 3000 );

        if ( dvoList.size( ) > 0 )
        {
            vo.setTbcMdCommOrgDVOList( dvoList );
            return vo;
        }

        return null;
    }

    /**
     * 법인코드를 등록한다.
     * 
     * @name_ko 법인코드 등록
     */
    public MdU713M01SVO createCorporationCode( MdU713M01SVO vo ) throws Exception
    {
        TbcMdCommOrgDVO dvo = vo.getTbcMdCommOrgDVO( );
        vo.setTbcMdCommOrgDVO( this.getMdManageTbcMdCommOrgBiz( ).createNewCorpCodeData( dvo ) );

        return vo;
    }

    /**
     * 법인코드 리스트를 수정한다.
     * 
     * @name_ko 법인코드 수정
     */
    public MdU713M01SVO updateCorporationCode( MdU713M01SVO vo ) throws Exception
    {
        List<TbcMdCommOrgDVO> dvoList = vo.getTbcMdCommOrgDVOList( );
        for ( int i = 0; i < dvoList.size( ); i++ )
        {
            TbcMdCommOrgDVO dvo = new TbcMdCommOrgDVO( );
            vo.setTbcMdCommOrgDVO( this.getMdManageTbcMdCommOrgBiz( ).updateTbcMdCommOrgRow( BaseUtil.populate( dvoList.get( i ), dvo ) ) );
        }

        return vo;
    }
}
