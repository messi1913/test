/**
 * <PRE>
 * System Name : MD
 * Business Name : MDM
 * Class Name : MdManageTbcMdCommCodeBiz.java
 * Description : 마스터 테이블 TbcMdCommCode에 대한 CRUD 컴포넌트
 * Modification History
 *          수정일              수정자          수정내용
 *    -----------------------------------------------------
 *    2011.07.21                호건웅           최초 생성    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */


package com.samsung.gmes2.md.mdm.biz;

import java.text.SimpleDateFormat;
import java.util.List;

import com.anyframe.core.vo.VoUtil;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.md.model.TbcMdCommCodeTypeDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDEM;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDQM;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;

public class MdManageTbcMdCommCodeBiz {
	/**
	 * 테이블 TbcMdCommCode에대한 삽입 연산을 수행
	 * @name_ko TbcMdCommCode 삽입 연산 메서드
	 */
	public TbcMdCommCodeDVO createNewTbcMdCommCodeRow(TbcMdCommCodeDVO inputDvo) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 참조 무결성 위반 여부 판단
		 * @fd_id 0001
		 * 참조 무결성 위반 여부 판단
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

		
		return CrudUtil.create( inputDvo );
	}
	/**
	 * 테이블 TbcMdCommCode에 대해 수정 연산을 수행하는 메서드
	 * @name_ko TbcMdCommCode 수정 연산 메서드
	 */
	public TbcMdCommCodeDVO updateTbcMdCommCodeRow(TbcMdCommCodeDVO inputDvo) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 참조 무결성 위반 여부 판단
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

		return CrudUtil.update( inputDvo );
	}
	/**
	 * 테이블 TbcMdCommCode 한 개 튜플을 조회하는 메서드
	 * @name_ko TbcMdCommCode 한 개 튜플 조회 메서드
	 */
	public TbcMdCommCodeDVO getTbcMdCommCodeRow(TbcMdCommCodeDVO inputDvo) throws Exception{
		return CrudUtil.get( inputDvo );
	}
	/**
	 * 테이블 TbcMdCommCode에 대해 삭제 연산을 수행하는 메서드
	 * @throws Exception 
	 * @name_ko TbcMdCommCode 삭제 연산 메서드
	 */
	public TbcMdCommCodeDVO deleteTbcMdCommCodeRow( TbcMdCommCodeDVO inputDvo ) throws Exception{
		return CrudUtil.delete( inputDvo );
	}
	/**
	 * 테이블 TbcMdCommCode의 전체 내용을 조회하는 메서드
	 * @throws Exception 
	 * @name_ko TbcMdCommCode 리스트 메서드
	 */
	public List listTbcMdCommCode( TbcMdCommCodeDVO inputDvo ) throws Exception{
		
		

		List resultList = CrudUtil.list0( TbcMdCommCodeDVO.class, inputDvo, 0, 0 );
		/*--------------------------------------------------
		 * @fd_if 조회 결과가 없으면 널을, 아니면 조회결과를 받은 리스트를 리턴
		 * @fd_id 0001
		 --------------------------------------------------*/
		if( resultList.size() > 0 ){
			return resultList;
		}
		return null;
	}
	
	
	/**
	 * 참조무결성 위반 여부 판단 메서드
	 * @name_ko 참조무결성 위반 여부 판단 메서드
	 */
	private void checkIntegrityConstraint( TbcMdCommCodeDVO inputDvo ) throws Exception{
		TbcMdCommCodeTypeDVO referencedTable = new TbcMdCommCodeTypeDVO();
		BaseUtil.populate( inputDvo, referencedTable );
		CrudUtil.checkFound( referencedTable );
	}
}
