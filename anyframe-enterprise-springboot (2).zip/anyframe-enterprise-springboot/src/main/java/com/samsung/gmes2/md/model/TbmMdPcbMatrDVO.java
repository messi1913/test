package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdPcbMatrDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String matrCode;

	@Length(11) @Scale(5) 
	private BigDecimal pcbArrayValue;

	@Length(500) 
	private String n1ProcNm;

	@Length(500) 
	private String n2ProcNm;

	@Length(500) 
	private String n3ProcNm;

	@Length(2000) 
	private String pcbDtlDesc;

	@Length(50) 
	private String rcgpntNo;

	@Length(11) @Scale(5) 
	private BigDecimal xRcgpntValue;

	@Length(11) @Scale(5) 
	private BigDecimal yRcgpntValue;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getMatrCode() {
		this.matrCode = super.getValue(1);
		return this.matrCode;
	}

	public void setMatrCode(String matrCode) {
        super.setValue(1, matrCode);
		this.matrCode = matrCode;
	}
	
	public BigDecimal getPcbArrayValue() {
		this.pcbArrayValue = super.getValue(2);
		return this.pcbArrayValue;
	}

	public void setPcbArrayValue(BigDecimal pcbArrayValue) {
        super.setValue(2, pcbArrayValue);
		this.pcbArrayValue = pcbArrayValue;
	}
	
	public String getN1ProcNm() {
		this.n1ProcNm = super.getValue(3);
		return this.n1ProcNm;
	}

	public void setN1ProcNm(String n1ProcNm) {
        super.setValue(3, n1ProcNm);
		this.n1ProcNm = n1ProcNm;
	}
	
	public String getN2ProcNm() {
		this.n2ProcNm = super.getValue(4);
		return this.n2ProcNm;
	}

	public void setN2ProcNm(String n2ProcNm) {
        super.setValue(4, n2ProcNm);
		this.n2ProcNm = n2ProcNm;
	}
	
	public String getN3ProcNm() {
		this.n3ProcNm = super.getValue(5);
		return this.n3ProcNm;
	}

	public void setN3ProcNm(String n3ProcNm) {
        super.setValue(5, n3ProcNm);
		this.n3ProcNm = n3ProcNm;
	}
	
	public String getPcbDtlDesc() {
		this.pcbDtlDesc = super.getValue(6);
		return this.pcbDtlDesc;
	}

	public void setPcbDtlDesc(String pcbDtlDesc) {
        super.setValue(6, pcbDtlDesc);
		this.pcbDtlDesc = pcbDtlDesc;
	}
	
	public String getRcgpntNo() {
		this.rcgpntNo = super.getValue(7);
		return this.rcgpntNo;
	}

	public void setRcgpntNo(String rcgpntNo) {
        super.setValue(7, rcgpntNo);
		this.rcgpntNo = rcgpntNo;
	}
	
	public BigDecimal getxRcgpntValue() {
		this.xRcgpntValue = super.getValue(8);
		return this.xRcgpntValue;
	}

	public void setxRcgpntValue(BigDecimal xRcgpntValue) {
        super.setValue(8, xRcgpntValue);
		this.xRcgpntValue = xRcgpntValue;
	}
	
	public BigDecimal getyRcgpntValue() {
		this.yRcgpntValue = super.getValue(9);
		return this.yRcgpntValue;
	}

	public void setyRcgpntValue(BigDecimal yRcgpntValue) {
        super.setValue(9, yRcgpntValue);
		this.yRcgpntValue = yRcgpntValue;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(10);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(10, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(11);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(11, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(12);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(12, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(13);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(13, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(14);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(14, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}