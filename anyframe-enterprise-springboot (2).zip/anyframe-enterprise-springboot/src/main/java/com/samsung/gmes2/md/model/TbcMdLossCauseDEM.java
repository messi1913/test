package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_LOSS_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdLossCauseDEM extends AbstractDAO {


/**
* insertTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return int
*/
	@LocalName("insertTbcMdLossCause")
	public int insertTbcMdLossCause (final TbcMdLossCauseDVO tbcMdLossCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.insertTbcMdLossCause.001*/  \n");
			sql.append(" TBC_MD_LOSS_CAUSE (   \n");
			sql.append("        LOSS_CAUSE_CODE , \n");
			sql.append("        LOSS_NM , \n");
			sql.append("        LOSS_CAUSE_DESC , \n");
			sql.append("        LOSS_ART_CODE , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossNm());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseDesc());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossArtCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdLossCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdLossCause Method")
	public int[][] updateBatchAllTbcMdLossCause (final List  tbcMdLossCauseDVOList) {
		
		ArrayList updatetbcMdLossCauseDVOList = new ArrayList();
		ArrayList insertttbcMdLossCauseDVOList = new ArrayList();
		ArrayList deletetbcMdLossCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdLossCauseDVOList.size() ; i++) {
		  TbcMdLossCauseDVO tbcMdLossCauseDVO = (TbcMdLossCauseDVO) tbcMdLossCauseDVOList.get(i);
		  
		  if (tbcMdLossCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdLossCauseDVOList.add(tbcMdLossCauseDVO);
		  else if (tbcMdLossCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdLossCauseDVOList.add(tbcMdLossCauseDVO);
		  else if (tbcMdLossCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdLossCauseDVOList.add(tbcMdLossCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdLossCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdLossCause(insertttbcMdLossCauseDVOList);
          
      if (updatetbcMdLossCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdLossCause(updatetbcMdLossCauseDVOList);
      
      if (deletetbcMdLossCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdLossCause(deletetbcMdLossCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return int
*/
	@LocalName("updateTbcMdLossCause")
	public int updateTbcMdLossCause (final TbcMdLossCauseDVO tbcMdLossCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.updateTbcMdLossCause.001*/  \n");
			sql.append(" TBC_MD_LOSS_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_NM = ? , \n");
			sql.append("        LOSS_CAUSE_DESC = ? , \n");
			sql.append("        LOSS_ART_CODE = ? , \n");
			sql.append("        DUTY_CLSF_CODE = ? , \n");
			sql.append("        PRTY_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LOSS_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossCauseDVO.getLossNm());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseDesc());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossArtCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdLossCause")
	public int deleteTbcMdLossCause (final TbcMdLossCauseDVO tbcMdLossCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.deleteTbcMdLossCause.001*/  \n");
			sql.append(" TBC_MD_LOSS_CAUSE \n");
			sql.append("  WHERE LOSS_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return TbcMdLossCauseDVO 
*/
	@LocalName("selectTbcMdLossCause")
	public TbcMdLossCauseDVO selectTbcMdLossCause (final TbcMdLossCauseDVO tbcMdLossCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.selectTbcMdLossCause.001*/  \n");
			sql.append("        LOSS_CAUSE_CODE , \n");
			sql.append("        LOSS_NM , \n");
			sql.append("        LOSS_CAUSE_DESC , \n");
			sql.append("        LOSS_ART_CODE , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_LOSS_CAUSE \n");
			sql.append("  WHERE LOSS_CAUSE_CODE = ? \n");

		return (TbcMdLossCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdLossCauseDVO returnTbcMdLossCauseDVO = new TbcMdLossCauseDVO();
									returnTbcMdLossCauseDVO.setLossCauseCode(resultSet.getString("LOSS_CAUSE_CODE"));
									returnTbcMdLossCauseDVO.setLossNm(resultSet.getString("LOSS_NM"));
									returnTbcMdLossCauseDVO.setLossCauseDesc(resultSet.getString("LOSS_CAUSE_DESC"));
									returnTbcMdLossCauseDVO.setLossArtCode(resultSet.getString("LOSS_ART_CODE"));
									returnTbcMdLossCauseDVO.setDutyClsfCode(resultSet.getString("DUTY_CLSF_CODE"));
									returnTbcMdLossCauseDVO.setPrtyReflYn(resultSet.getString("PRTY_REFL_YN"));
									returnTbcMdLossCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdLossCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdLossCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdLossCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdLossCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdLossCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdLossCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdLossCause Method")
	public int mergeTbcMdLossCause (final TbcMdLossCauseDVO tbcMdLossCauseDVO) {
		
		if ( selectTbcMdLossCause (tbcMdLossCauseDVO) == null) {
			return insertTbcMdLossCause(tbcMdLossCauseDVO);
		} else {
			return selectUpdateTbcMdLossCause (tbcMdLossCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdLossCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdLossCause Method")
	public int selectUpdateTbcMdLossCause (final TbcMdLossCauseDVO tbcMdLossCauseDVO) {
		
		TbcMdLossCauseDVO tmpTbcMdLossCauseDVO =  selectTbcMdLossCause (tbcMdLossCauseDVO);
		if ( tbcMdLossCauseDVO.getLossCauseCode() != null && !"".equals(tbcMdLossCauseDVO.getLossCauseCode()) ) {
			tmpTbcMdLossCauseDVO.setLossCauseCode(tbcMdLossCauseDVO.getLossCauseCode());
		}		
		if ( tbcMdLossCauseDVO.getLossNm() != null && !"".equals(tbcMdLossCauseDVO.getLossNm()) ) {
			tmpTbcMdLossCauseDVO.setLossNm(tbcMdLossCauseDVO.getLossNm());
		}		
		if ( tbcMdLossCauseDVO.getLossCauseDesc() != null && !"".equals(tbcMdLossCauseDVO.getLossCauseDesc()) ) {
			tmpTbcMdLossCauseDVO.setLossCauseDesc(tbcMdLossCauseDVO.getLossCauseDesc());
		}		
		if ( tbcMdLossCauseDVO.getLossArtCode() != null && !"".equals(tbcMdLossCauseDVO.getLossArtCode()) ) {
			tmpTbcMdLossCauseDVO.setLossArtCode(tbcMdLossCauseDVO.getLossArtCode());
		}		
		if ( tbcMdLossCauseDVO.getDutyClsfCode() != null && !"".equals(tbcMdLossCauseDVO.getDutyClsfCode()) ) {
			tmpTbcMdLossCauseDVO.setDutyClsfCode(tbcMdLossCauseDVO.getDutyClsfCode());
		}		
		if ( tbcMdLossCauseDVO.getPrtyReflYn() != null && !"".equals(tbcMdLossCauseDVO.getPrtyReflYn()) ) {
			tmpTbcMdLossCauseDVO.setPrtyReflYn(tbcMdLossCauseDVO.getPrtyReflYn());
		}		
		if ( tbcMdLossCauseDVO.getUseYn() != null && !"".equals(tbcMdLossCauseDVO.getUseYn()) ) {
			tmpTbcMdLossCauseDVO.setUseYn(tbcMdLossCauseDVO.getUseYn());
		}		
		if ( tbcMdLossCauseDVO.getFstRegDt() != null && !"".equals(tbcMdLossCauseDVO.getFstRegDt()) ) {
			tmpTbcMdLossCauseDVO.setFstRegDt(tbcMdLossCauseDVO.getFstRegDt());
		}		
		if ( tbcMdLossCauseDVO.getFstRegerId() != null && !"".equals(tbcMdLossCauseDVO.getFstRegerId()) ) {
			tmpTbcMdLossCauseDVO.setFstRegerId(tbcMdLossCauseDVO.getFstRegerId());
		}		
		if ( tbcMdLossCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdLossCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdLossCauseDVO.setFnlUpdDt(tbcMdLossCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdLossCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdLossCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdLossCauseDVO.setFnlUpderId(tbcMdLossCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdLossCause (tmpTbcMdLossCauseDVO);
	}

/**
* insertBatchTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdLossCause")
	public int[] insertBatchTbcMdLossCause (final List tbcMdLossCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.insertBatchTbcMdLossCause.001*/  \n");
			sql.append(" TBC_MD_LOSS_CAUSE (   \n");
			sql.append("        LOSS_CAUSE_CODE , \n");
			sql.append("        LOSS_NM , \n");
			sql.append("        LOSS_CAUSE_DESC , \n");
			sql.append("        LOSS_ART_CODE , \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        PRTY_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossCauseDVO tbcMdLossCauseDVO = (TbcMdLossCauseDVO)tbcMdLossCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossNm());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseDesc());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossArtCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdLossCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdLossCause")
	public int[] updateBatchTbcMdLossCause (final List tbcMdLossCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.updateBatchTbcMdLossCause.001*/  \n");
			sql.append(" TBC_MD_LOSS_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        LOSS_NM = ? , \n");
			sql.append("        LOSS_CAUSE_DESC = ? , \n");
			sql.append("        LOSS_ART_CODE = ? , \n");
			sql.append("        DUTY_CLSF_CODE = ? , \n");
			sql.append("        PRTY_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LOSS_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossCauseDVO tbcMdLossCauseDVO = (TbcMdLossCauseDVO)tbcMdLossCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdLossCauseDVO.getLossNm());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseDesc());
							ps.setString(psCount++, tbcMdLossCauseDVO.getLossArtCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdLossCauseDVO.getPrtyReflYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdLossCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
						}
							public int getBatchSize() {
									return tbcMdLossCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdLossCause Method
* 
* @ref_table TBC_MD_LOSS_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdLossCause")
	public int[] deleteBatchTbcMdLossCause (final List tbcMdLossCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdLossCauseDEM.deleteBatchTbcMdLossCause.001*/  \n");
			sql.append(" TBC_MD_LOSS_CAUSE \n");
			sql.append("  WHERE LOSS_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdLossCauseDVO tbcMdLossCauseDVO = (TbcMdLossCauseDVO)tbcMdLossCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdLossCauseDVO.getLossCauseCode());
						}
							public int getBatchSize() {
									return tbcMdLossCauseDVOList.size();
							}
					}
		);			
	}

	
}