package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdPlantLineDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String lineCode;

	@Length(30) 
	private String gscmRscCode;

	@Length(30) 
	private String erpWcCode;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getFctCode() {
		this.fctCode = super.getValue(1);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(1, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(2);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(2, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getGscmRscCode() {
		this.gscmRscCode = super.getValue(3);
		return this.gscmRscCode;
	}

	public void setGscmRscCode(String gscmRscCode) {
        super.setValue(3, gscmRscCode);
		this.gscmRscCode = gscmRscCode;
	}
	
	public String getErpWcCode() {
		this.erpWcCode = super.getValue(4);
		return this.erpWcCode;
	}

	public void setErpWcCode(String erpWcCode) {
        super.setValue(4, erpWcCode);
		this.erpWcCode = erpWcCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(5);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(5, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(6);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(6, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(7);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(7, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(8);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(8, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(9);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(9, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}