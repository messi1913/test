package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMfgTeamDQM extends AbstractDAO {


/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_TEAM_CODE, 
* 	PID_EMP_NO, 
* 	MFG_TEAM_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_TEAM 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($pidEmpNo) 
* AND PID_EMP_NO = :pidEmpNo 
* #end 
* #if($mfgTeamNm) 
* AND MFG_TEAM_NM = :mfgTeamNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	PID_EMP_NO,  \n");
			sql.append(" 	MFG_TEAM_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_TEAM  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pidEmpNo)  \n");
			sql.append(" AND PID_EMP_NO = :pidEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamNm)  \n");
			sql.append(" AND MFG_TEAM_NM = :mfgTeamNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgTeamDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgTeamDVO returnTbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
									returnTbcMdMfgTeamDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgTeamDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgTeamDVO.setPidEmpNo(resultSet.getString("PID_EMP_NO"));
									returnTbcMdMfgTeamDVO.setMfgTeamNm(resultSet.getString("MFG_TEAM_NM"));
									returnTbcMdMfgTeamDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgTeamDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgTeamDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgTeamDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgTeamDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgTeamDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgTeamDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_TEAM_CODE, 
* 	PID_EMP_NO, 
* 	MFG_TEAM_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_TEAM 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($pidEmpNo) 
* AND PID_EMP_NO = :pidEmpNo 
* #end 
* #if($mfgTeamNm) 
* AND MFG_TEAM_NM = :mfgTeamNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	PID_EMP_NO,  \n");
			sql.append(" 	MFG_TEAM_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_TEAM  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pidEmpNo)  \n");
			sql.append(" AND PID_EMP_NO = :pidEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamNm)  \n");
			sql.append(" AND MFG_TEAM_NM = :mfgTeamNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgTeamDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgTeamDVO returnTbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
									returnTbcMdMfgTeamDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgTeamDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgTeamDVO.setPidEmpNo(resultSet.getString("PID_EMP_NO"));
									returnTbcMdMfgTeamDVO.setMfgTeamNm(resultSet.getString("MFG_TEAM_NM"));
									returnTbcMdMfgTeamDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgTeamDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgTeamDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgTeamDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgTeamDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgTeamDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgTeamDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_TEAM_CODE, 
* 	PID_EMP_NO, 
* 	MFG_TEAM_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_TEAM 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($pidEmpNo) 
* AND PID_EMP_NO = :pidEmpNo 
* #end 
* #if($mfgTeamNm) 
* AND MFG_TEAM_NM = :mfgTeamNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	PID_EMP_NO,  \n");
			sql.append(" 	MFG_TEAM_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_TEAM  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pidEmpNo)  \n");
			sql.append(" AND PID_EMP_NO = :pidEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamNm)  \n");
			sql.append(" AND MFG_TEAM_NM = :mfgTeamNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgTeamDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgTeamDVO returnTbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
									returnTbcMdMfgTeamDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgTeamDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgTeamDVO.setPidEmpNo(resultSet.getString("PID_EMP_NO"));
									returnTbcMdMfgTeamDVO.setMfgTeamNm(resultSet.getString("MFG_TEAM_NM"));
									returnTbcMdMfgTeamDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgTeamDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgTeamDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgTeamDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgTeamDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgTeamDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgTeamDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_TEAM_CODE, 
* 	PID_EMP_NO, 
* 	MFG_TEAM_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_TEAM 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($pidEmpNo) 
* AND PID_EMP_NO = :pidEmpNo 
* #end 
* #if($mfgTeamNm) 
* AND MFG_TEAM_NM = :mfgTeamNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	PID_EMP_NO,  \n");
			sql.append(" 	MFG_TEAM_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_TEAM  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pidEmpNo)  \n");
			sql.append(" AND PID_EMP_NO = :pidEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamNm)  \n");
			sql.append(" AND MFG_TEAM_NM = :mfgTeamNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgTeamDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgTeamDVO returnTbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
									returnTbcMdMfgTeamDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgTeamDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgTeamDVO.setPidEmpNo(resultSet.getString("PID_EMP_NO"));
									returnTbcMdMfgTeamDVO.setMfgTeamNm(resultSet.getString("MFG_TEAM_NM"));
									returnTbcMdMfgTeamDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgTeamDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgTeamDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgTeamDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgTeamDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgTeamDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgTeamDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}