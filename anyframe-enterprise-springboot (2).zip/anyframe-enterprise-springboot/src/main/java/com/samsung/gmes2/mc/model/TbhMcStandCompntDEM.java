package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MC_STAND_COMPNT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMcStandCompntDEM extends AbstractDAO {


/**
* insertTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return int
*/
	@LocalName("insertTbhMcStandCompnt")
	public int insertTbhMcStandCompnt (final TbhMcStandCompntDVO tbhMcStandCompntDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.insertTbhMcStandCompnt.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT (   \n");
			sql.append("        REV_NO , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        COMPNT_NM , \n");
			sql.append("        COMPNT_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntNm());
							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntDesc());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMcStandCompnt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMcStandCompnt Method")
	public int[][] updateBatchAllTbhMcStandCompnt (final List  tbhMcStandCompntDVOList) {
		
		ArrayList updatetbhMcStandCompntDVOList = new ArrayList();
		ArrayList insertttbhMcStandCompntDVOList = new ArrayList();
		ArrayList deletetbhMcStandCompntDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMcStandCompntDVOList.size() ; i++) {
		  TbhMcStandCompntDVO tbhMcStandCompntDVO = (TbhMcStandCompntDVO) tbhMcStandCompntDVOList.get(i);
		  
		  if (tbhMcStandCompntDVO.getSqlAction().equals("C"))
		      insertttbhMcStandCompntDVOList.add(tbhMcStandCompntDVO);
		  else if (tbhMcStandCompntDVO.getSqlAction().equals("U"))
		      updatetbhMcStandCompntDVOList.add(tbhMcStandCompntDVO);
		  else if (tbhMcStandCompntDVO.getSqlAction().equals("D"))
		      deletetbhMcStandCompntDVOList.add(tbhMcStandCompntDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMcStandCompntDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMcStandCompnt(insertttbhMcStandCompntDVOList);
          
      if (updatetbhMcStandCompntDVOList.size() >0)
          resultValues[1] = updateBatchTbhMcStandCompnt(updatetbhMcStandCompntDVOList);
      
      if (deletetbhMcStandCompntDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMcStandCompnt(deletetbhMcStandCompntDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return int
*/
	@LocalName("updateTbhMcStandCompnt")
	public int updateTbhMcStandCompnt (final TbhMcStandCompntDVO tbhMcStandCompntDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.updateTbhMcStandCompnt.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT \n");
			sql.append(" SET   \n");
			sql.append("        COMPNT_NM = ? , \n");
			sql.append("        COMPNT_DESC = ? \n");
			sql.append(" WHERE REV_NO = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntNm());
							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntDesc());

							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
						}
					}
		);			
	}

/**
* deleteTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return int
*/
	@LocalName("deleteTbhMcStandCompnt")
	public int deleteTbhMcStandCompnt (final TbhMcStandCompntDVO tbhMcStandCompntDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.deleteTbhMcStandCompnt.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
						}
					}
		);			
	}

/**
* selectTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return TbhMcStandCompntDVO 
*/
	@LocalName("selectTbhMcStandCompnt")
	public TbhMcStandCompntDVO selectTbhMcStandCompnt (final TbhMcStandCompntDVO tbhMcStandCompntDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.selectTbhMcStandCompnt.001*/  \n");
			sql.append("        REV_NO , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        COMPNT_NM , \n");
			sql.append("        COMPNT_DESC \n");
			sql.append("   FROM TBH_MC_STAND_COMPNT \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return (TbhMcStandCompntDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMcStandCompntDVO returnTbhMcStandCompntDVO = new TbhMcStandCompntDVO();
									returnTbhMcStandCompntDVO.setRevNo(resultSet.getString("REV_NO"));
									returnTbhMcStandCompntDVO.setStandCompntCode(resultSet.getString("STAND_COMPNT_CODE"));
									returnTbhMcStandCompntDVO.setCompntNm(resultSet.getString("COMPNT_NM"));
									returnTbhMcStandCompntDVO.setCompntDesc(resultSet.getString("COMPNT_DESC"));
									return returnTbhMcStandCompntDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMcStandCompnt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMcStandCompnt Method")
	public int mergeTbhMcStandCompnt (final TbhMcStandCompntDVO tbhMcStandCompntDVO) {
		
		if ( selectTbhMcStandCompnt (tbhMcStandCompntDVO) == null) {
			return insertTbhMcStandCompnt(tbhMcStandCompntDVO);
		} else {
			return selectUpdateTbhMcStandCompnt (tbhMcStandCompntDVO);
		}
	}

	/**
	 * selectUpdateTbhMcStandCompnt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMcStandCompnt Method")
	public int selectUpdateTbhMcStandCompnt (final TbhMcStandCompntDVO tbhMcStandCompntDVO) {
		
		TbhMcStandCompntDVO tmpTbhMcStandCompntDVO =  selectTbhMcStandCompnt (tbhMcStandCompntDVO);
		if ( tbhMcStandCompntDVO.getRevNo() != null && !"".equals(tbhMcStandCompntDVO.getRevNo()) ) {
			tmpTbhMcStandCompntDVO.setRevNo(tbhMcStandCompntDVO.getRevNo());
		}		
		if ( tbhMcStandCompntDVO.getStandCompntCode() != null && !"".equals(tbhMcStandCompntDVO.getStandCompntCode()) ) {
			tmpTbhMcStandCompntDVO.setStandCompntCode(tbhMcStandCompntDVO.getStandCompntCode());
		}		
		if ( tbhMcStandCompntDVO.getCompntNm() != null && !"".equals(tbhMcStandCompntDVO.getCompntNm()) ) {
			tmpTbhMcStandCompntDVO.setCompntNm(tbhMcStandCompntDVO.getCompntNm());
		}		
		if ( tbhMcStandCompntDVO.getCompntDesc() != null && !"".equals(tbhMcStandCompntDVO.getCompntDesc()) ) {
			tmpTbhMcStandCompntDVO.setCompntDesc(tbhMcStandCompntDVO.getCompntDesc());
		}		
		return updateTbhMcStandCompnt (tmpTbhMcStandCompntDVO);
	}

/**
* insertBatchTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return int[]
*/
	@LocalName("insertBatchTbhMcStandCompnt")
	public int[] insertBatchTbhMcStandCompnt (final List tbhMcStandCompntDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.insertBatchTbhMcStandCompnt.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT (   \n");
			sql.append("        REV_NO , \n");
			sql.append("        STAND_COMPNT_CODE , \n");
			sql.append("        COMPNT_NM , \n");
			sql.append("        COMPNT_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcStandCompntDVO tbhMcStandCompntDVO = (TbhMcStandCompntDVO)tbhMcStandCompntDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntNm());
							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntDesc());

						}
							public int getBatchSize() {
									return tbhMcStandCompntDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return int[]
*/
	@LocalName("updateBatchTbhMcStandCompnt")
	public int[] updateBatchTbhMcStandCompnt (final List tbhMcStandCompntDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.updateBatchTbhMcStandCompnt.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT \n");
			sql.append(" SET   \n");
			sql.append("        COMPNT_NM = ? , \n");
			sql.append("        COMPNT_DESC = ? \n");
			sql.append(" WHERE REV_NO = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcStandCompntDVO tbhMcStandCompntDVO = (TbhMcStandCompntDVO)tbhMcStandCompntDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntNm());
							ps.setString(psCount++, tbhMcStandCompntDVO.getCompntDesc());

							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
						}
							public int getBatchSize() {
									return tbhMcStandCompntDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMcStandCompnt Method
* 
* @ref_table TBH_MC_STAND_COMPNT
* @return int[]
*/
	@LocalName("deleteBatchTbhMcStandCompnt")
	public int[] deleteBatchTbhMcStandCompnt (final List tbhMcStandCompntDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcStandCompntDEM.deleteBatchTbhMcStandCompnt.001*/  \n");
			sql.append(" TBH_MC_STAND_COMPNT \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcStandCompntDVO tbhMcStandCompntDVO = (TbhMcStandCompntDVO)tbhMcStandCompntDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMcStandCompntDVO.getRevNo());
							ps.setString(psCount++, tbhMcStandCompntDVO.getStandCompntCode());
						}
							public int getBatchSize() {
									return tbhMcStandCompntDVOList.size();
							}
					}
		);			
	}

	
}