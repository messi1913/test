package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelDEM extends AbstractDAO {


/**
* insertTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return int
*/
	@LocalName("insertTbmMdModel")
	public int insertTbmMdModel (final TbmMdModelDVO tbmMdModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelDEM.insertTbmMdModel.001*/  \n");
			sql.append(" TBM_MD_MODEL (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_TYPE_CODE , \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        DEV_TASK_CODE , \n");
			sql.append("        REV_VER , \n");
			sql.append("        SEG_CODE , \n");
			sql.append("        BASIC_MODEL_CODE , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        EAN_CODE , \n");
			sql.append("        UPC_CODE , \n");
			sql.append("        KAN_CODE , \n");
			sql.append("        DOM_EXP_GUBUN_CODE , \n");
			sql.append("        OEM_YN , \n");
			sql.append("        DISUSE_YN , \n");
			sql.append("        COLOR_NM , \n");
			sql.append("        PROD_TOTAL_WEIT , \n");
			sql.append("        PROD_ACTU_WEIT , \n");
			sql.append("        PROD_SIZE , \n");
			sql.append("        CHASSIS_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getProdCode());
							ps.setString(psCount++, tbmMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbmMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbmMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getRevVer());
							ps.setString(psCount++, tbmMdModelDVO.getSegCode());
							ps.setString(psCount++, tbmMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getEanCode());
							ps.setString(psCount++, tbmMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbmMdModelDVO.getKanCode());
							ps.setString(psCount++, tbmMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbmMdModelDVO.getOemYn());
							ps.setString(psCount++, tbmMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbmMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdSize());
							ps.setString(psCount++, tbmMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModel Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModel Method")
	public int[][] updateBatchAllTbmMdModel (final List  tbmMdModelDVOList) {
		
		ArrayList updatetbmMdModelDVOList = new ArrayList();
		ArrayList insertttbmMdModelDVOList = new ArrayList();
		ArrayList deletetbmMdModelDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelDVOList.size() ; i++) {
		  TbmMdModelDVO tbmMdModelDVO = (TbmMdModelDVO) tbmMdModelDVOList.get(i);
		  
		  if (tbmMdModelDVO.getSqlAction().equals("C"))
		      insertttbmMdModelDVOList.add(tbmMdModelDVO);
		  else if (tbmMdModelDVO.getSqlAction().equals("U"))
		      updatetbmMdModelDVOList.add(tbmMdModelDVO);
		  else if (tbmMdModelDVO.getSqlAction().equals("D"))
		      deletetbmMdModelDVOList.add(tbmMdModelDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModel(insertttbmMdModelDVOList);
          
      if (updatetbmMdModelDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModel(updatetbmMdModelDVOList);
      
      if (deletetbmMdModelDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModel(deletetbmMdModelDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return int
*/
	@LocalName("updateTbmMdModel")
	public int updateTbmMdModel (final TbmMdModelDVO tbmMdModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelDEM.updateTbmMdModel.001*/  \n");
			sql.append(" TBM_MD_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        PROD_CODE = ? , \n");
			sql.append("        PROD_TYPE_CODE = ? , \n");
			sql.append("        MODEL_GRP_CODE = ? , \n");
			sql.append("        PJT_CODE = ? , \n");
			sql.append("        DEV_TASK_CODE = ? , \n");
			sql.append("        REV_VER = ? , \n");
			sql.append("        SEG_CODE = ? , \n");
			sql.append("        BASIC_MODEL_CODE = ? , \n");
			sql.append("        SAL_MODEL_CODE = ? , \n");
			sql.append("        EAN_CODE = ? , \n");
			sql.append("        UPC_CODE = ? , \n");
			sql.append("        KAN_CODE = ? , \n");
			sql.append("        DOM_EXP_GUBUN_CODE = ? , \n");
			sql.append("        OEM_YN = ? , \n");
			sql.append("        DISUSE_YN = ? , \n");
			sql.append("        COLOR_NM = ? , \n");
			sql.append("        PROD_TOTAL_WEIT = ? , \n");
			sql.append("        PROD_ACTU_WEIT = ? , \n");
			sql.append("        PROD_SIZE = ? , \n");
			sql.append("        CHASSIS_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelDVO.getProdCode());
							ps.setString(psCount++, tbmMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbmMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbmMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getRevVer());
							ps.setString(psCount++, tbmMdModelDVO.getSegCode());
							ps.setString(psCount++, tbmMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getEanCode());
							ps.setString(psCount++, tbmMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbmMdModelDVO.getKanCode());
							ps.setString(psCount++, tbmMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbmMdModelDVO.getOemYn());
							ps.setString(psCount++, tbmMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbmMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdSize());
							ps.setString(psCount++, tbmMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
						}
					}
		);			
	}

/**
* deleteTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return int
*/
	@LocalName("deleteTbmMdModel")
	public int deleteTbmMdModel (final TbmMdModelDVO tbmMdModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelDEM.deleteTbmMdModel.001*/  \n");
			sql.append(" TBM_MD_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
						}
					}
		);			
	}

/**
* selectTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return TbmMdModelDVO 
*/
	@LocalName("selectTbmMdModel")
	public TbmMdModelDVO selectTbmMdModel (final TbmMdModelDVO tbmMdModelDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelDEM.selectTbmMdModel.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_TYPE_CODE , \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        DEV_TASK_CODE , \n");
			sql.append("        REV_VER , \n");
			sql.append("        SEG_CODE , \n");
			sql.append("        BASIC_MODEL_CODE , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        EAN_CODE , \n");
			sql.append("        UPC_CODE , \n");
			sql.append("        KAN_CODE , \n");
			sql.append("        DOM_EXP_GUBUN_CODE , \n");
			sql.append("        OEM_YN , \n");
			sql.append("        DISUSE_YN , \n");
			sql.append("        COLOR_NM , \n");
			sql.append("        PROD_TOTAL_WEIT , \n");
			sql.append("        PROD_ACTU_WEIT , \n");
			sql.append("        PROD_SIZE , \n");
			sql.append("        CHASSIS_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");

		return (TbmMdModelDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelDVO returnTbmMdModelDVO = new TbmMdModelDVO();
									returnTbmMdModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbmMdModelDVO.setProdTypeCode(resultSet.getString("PROD_TYPE_CODE"));
									returnTbmMdModelDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbmMdModelDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdModelDVO.setDevTaskCode(resultSet.getString("DEV_TASK_CODE"));
									returnTbmMdModelDVO.setRevVer(resultSet.getBigDecimal("REV_VER"));
									returnTbmMdModelDVO.setSegCode(resultSet.getString("SEG_CODE"));
									returnTbmMdModelDVO.setBasicModelCode(resultSet.getString("BASIC_MODEL_CODE"));
									returnTbmMdModelDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbmMdModelDVO.setEanCode(resultSet.getString("EAN_CODE"));
									returnTbmMdModelDVO.setUpcCode(resultSet.getString("UPC_CODE"));
									returnTbmMdModelDVO.setKanCode(resultSet.getString("KAN_CODE"));
									returnTbmMdModelDVO.setDomExpGubunCode(resultSet.getString("DOM_EXP_GUBUN_CODE"));
									returnTbmMdModelDVO.setOemYn(resultSet.getString("OEM_YN"));
									returnTbmMdModelDVO.setDisuseYn(resultSet.getString("DISUSE_YN"));
									returnTbmMdModelDVO.setColorNm(resultSet.getString("COLOR_NM"));
									returnTbmMdModelDVO.setProdTotalWeit(resultSet.getBigDecimal("PROD_TOTAL_WEIT"));
									returnTbmMdModelDVO.setProdActuWeit(resultSet.getBigDecimal("PROD_ACTU_WEIT"));
									returnTbmMdModelDVO.setProdSize(resultSet.getBigDecimal("PROD_SIZE"));
									returnTbmMdModelDVO.setChassisNm(resultSet.getString("CHASSIS_NM"));
									returnTbmMdModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModel Method")
	public int mergeTbmMdModel (final TbmMdModelDVO tbmMdModelDVO) {
		
		if ( selectTbmMdModel (tbmMdModelDVO) == null) {
			return insertTbmMdModel(tbmMdModelDVO);
		} else {
			return selectUpdateTbmMdModel (tbmMdModelDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModel Method")
	public int selectUpdateTbmMdModel (final TbmMdModelDVO tbmMdModelDVO) {
		
		TbmMdModelDVO tmpTbmMdModelDVO =  selectTbmMdModel (tbmMdModelDVO);
		if ( tbmMdModelDVO.getModelCode() != null && !"".equals(tbmMdModelDVO.getModelCode()) ) {
			tmpTbmMdModelDVO.setModelCode(tbmMdModelDVO.getModelCode());
		}		
		if ( tbmMdModelDVO.getProdCode() != null && !"".equals(tbmMdModelDVO.getProdCode()) ) {
			tmpTbmMdModelDVO.setProdCode(tbmMdModelDVO.getProdCode());
		}		
		if ( tbmMdModelDVO.getProdTypeCode() != null && !"".equals(tbmMdModelDVO.getProdTypeCode()) ) {
			tmpTbmMdModelDVO.setProdTypeCode(tbmMdModelDVO.getProdTypeCode());
		}		
		if ( tbmMdModelDVO.getModelGrpCode() != null && !"".equals(tbmMdModelDVO.getModelGrpCode()) ) {
			tmpTbmMdModelDVO.setModelGrpCode(tbmMdModelDVO.getModelGrpCode());
		}		
		if ( tbmMdModelDVO.getPjtCode() != null && !"".equals(tbmMdModelDVO.getPjtCode()) ) {
			tmpTbmMdModelDVO.setPjtCode(tbmMdModelDVO.getPjtCode());
		}		
		if ( tbmMdModelDVO.getDevTaskCode() != null && !"".equals(tbmMdModelDVO.getDevTaskCode()) ) {
			tmpTbmMdModelDVO.setDevTaskCode(tbmMdModelDVO.getDevTaskCode());
		}		
		if ( tbmMdModelDVO.getRevVer() != null && !"".equals(tbmMdModelDVO.getRevVer()) ) {
			tmpTbmMdModelDVO.setRevVer(tbmMdModelDVO.getRevVer());
		}		
		if ( tbmMdModelDVO.getSegCode() != null && !"".equals(tbmMdModelDVO.getSegCode()) ) {
			tmpTbmMdModelDVO.setSegCode(tbmMdModelDVO.getSegCode());
		}		
		if ( tbmMdModelDVO.getBasicModelCode() != null && !"".equals(tbmMdModelDVO.getBasicModelCode()) ) {
			tmpTbmMdModelDVO.setBasicModelCode(tbmMdModelDVO.getBasicModelCode());
		}		
		if ( tbmMdModelDVO.getSalModelCode() != null && !"".equals(tbmMdModelDVO.getSalModelCode()) ) {
			tmpTbmMdModelDVO.setSalModelCode(tbmMdModelDVO.getSalModelCode());
		}		
		if ( tbmMdModelDVO.getEanCode() != null && !"".equals(tbmMdModelDVO.getEanCode()) ) {
			tmpTbmMdModelDVO.setEanCode(tbmMdModelDVO.getEanCode());
		}		
		if ( tbmMdModelDVO.getUpcCode() != null && !"".equals(tbmMdModelDVO.getUpcCode()) ) {
			tmpTbmMdModelDVO.setUpcCode(tbmMdModelDVO.getUpcCode());
		}		
		if ( tbmMdModelDVO.getKanCode() != null && !"".equals(tbmMdModelDVO.getKanCode()) ) {
			tmpTbmMdModelDVO.setKanCode(tbmMdModelDVO.getKanCode());
		}		
		if ( tbmMdModelDVO.getDomExpGubunCode() != null && !"".equals(tbmMdModelDVO.getDomExpGubunCode()) ) {
			tmpTbmMdModelDVO.setDomExpGubunCode(tbmMdModelDVO.getDomExpGubunCode());
		}		
		if ( tbmMdModelDVO.getOemYn() != null && !"".equals(tbmMdModelDVO.getOemYn()) ) {
			tmpTbmMdModelDVO.setOemYn(tbmMdModelDVO.getOemYn());
		}		
		if ( tbmMdModelDVO.getDisuseYn() != null && !"".equals(tbmMdModelDVO.getDisuseYn()) ) {
			tmpTbmMdModelDVO.setDisuseYn(tbmMdModelDVO.getDisuseYn());
		}		
		if ( tbmMdModelDVO.getColorNm() != null && !"".equals(tbmMdModelDVO.getColorNm()) ) {
			tmpTbmMdModelDVO.setColorNm(tbmMdModelDVO.getColorNm());
		}		
		if ( tbmMdModelDVO.getProdTotalWeit() != null && !"".equals(tbmMdModelDVO.getProdTotalWeit()) ) {
			tmpTbmMdModelDVO.setProdTotalWeit(tbmMdModelDVO.getProdTotalWeit());
		}		
		if ( tbmMdModelDVO.getProdActuWeit() != null && !"".equals(tbmMdModelDVO.getProdActuWeit()) ) {
			tmpTbmMdModelDVO.setProdActuWeit(tbmMdModelDVO.getProdActuWeit());
		}		
		if ( tbmMdModelDVO.getProdSize() != null && !"".equals(tbmMdModelDVO.getProdSize()) ) {
			tmpTbmMdModelDVO.setProdSize(tbmMdModelDVO.getProdSize());
		}		
		if ( tbmMdModelDVO.getChassisNm() != null && !"".equals(tbmMdModelDVO.getChassisNm()) ) {
			tmpTbmMdModelDVO.setChassisNm(tbmMdModelDVO.getChassisNm());
		}		
		if ( tbmMdModelDVO.getFstRegDt() != null && !"".equals(tbmMdModelDVO.getFstRegDt()) ) {
			tmpTbmMdModelDVO.setFstRegDt(tbmMdModelDVO.getFstRegDt());
		}		
		if ( tbmMdModelDVO.getFstRegerId() != null && !"".equals(tbmMdModelDVO.getFstRegerId()) ) {
			tmpTbmMdModelDVO.setFstRegerId(tbmMdModelDVO.getFstRegerId());
		}		
		if ( tbmMdModelDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelDVO.setFnlUpdDt(tbmMdModelDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelDVO.getFnlUpderId() != null && !"".equals(tbmMdModelDVO.getFnlUpderId()) ) {
			tmpTbmMdModelDVO.setFnlUpderId(tbmMdModelDVO.getFnlUpderId());
		}		
		return updateTbmMdModel (tmpTbmMdModelDVO);
	}

/**
* insertBatchTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return int[]
*/
	@LocalName("insertBatchTbmMdModel")
	public int[] insertBatchTbmMdModel (final List tbmMdModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelDEM.insertBatchTbmMdModel.001*/  \n");
			sql.append(" TBM_MD_MODEL (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_TYPE_CODE , \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        DEV_TASK_CODE , \n");
			sql.append("        REV_VER , \n");
			sql.append("        SEG_CODE , \n");
			sql.append("        BASIC_MODEL_CODE , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        EAN_CODE , \n");
			sql.append("        UPC_CODE , \n");
			sql.append("        KAN_CODE , \n");
			sql.append("        DOM_EXP_GUBUN_CODE , \n");
			sql.append("        OEM_YN , \n");
			sql.append("        DISUSE_YN , \n");
			sql.append("        COLOR_NM , \n");
			sql.append("        PROD_TOTAL_WEIT , \n");
			sql.append("        PROD_ACTU_WEIT , \n");
			sql.append("        PROD_SIZE , \n");
			sql.append("        CHASSIS_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelDVO tbmMdModelDVO = (TbmMdModelDVO)tbmMdModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getProdCode());
							ps.setString(psCount++, tbmMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbmMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbmMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getRevVer());
							ps.setString(psCount++, tbmMdModelDVO.getSegCode());
							ps.setString(psCount++, tbmMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getEanCode());
							ps.setString(psCount++, tbmMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbmMdModelDVO.getKanCode());
							ps.setString(psCount++, tbmMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbmMdModelDVO.getOemYn());
							ps.setString(psCount++, tbmMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbmMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdSize());
							ps.setString(psCount++, tbmMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return int[]
*/
	@LocalName("updateBatchTbmMdModel")
	public int[] updateBatchTbmMdModel (final List tbmMdModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelDEM.updateBatchTbmMdModel.001*/  \n");
			sql.append(" TBM_MD_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        PROD_CODE = ? , \n");
			sql.append("        PROD_TYPE_CODE = ? , \n");
			sql.append("        MODEL_GRP_CODE = ? , \n");
			sql.append("        PJT_CODE = ? , \n");
			sql.append("        DEV_TASK_CODE = ? , \n");
			sql.append("        REV_VER = ? , \n");
			sql.append("        SEG_CODE = ? , \n");
			sql.append("        BASIC_MODEL_CODE = ? , \n");
			sql.append("        SAL_MODEL_CODE = ? , \n");
			sql.append("        EAN_CODE = ? , \n");
			sql.append("        UPC_CODE = ? , \n");
			sql.append("        KAN_CODE = ? , \n");
			sql.append("        DOM_EXP_GUBUN_CODE = ? , \n");
			sql.append("        OEM_YN = ? , \n");
			sql.append("        DISUSE_YN = ? , \n");
			sql.append("        COLOR_NM = ? , \n");
			sql.append("        PROD_TOTAL_WEIT = ? , \n");
			sql.append("        PROD_ACTU_WEIT = ? , \n");
			sql.append("        PROD_SIZE = ? , \n");
			sql.append("        CHASSIS_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelDVO tbmMdModelDVO = (TbmMdModelDVO)tbmMdModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelDVO.getProdCode());
							ps.setString(psCount++, tbmMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbmMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbmMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getRevVer());
							ps.setString(psCount++, tbmMdModelDVO.getSegCode());
							ps.setString(psCount++, tbmMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdModelDVO.getEanCode());
							ps.setString(psCount++, tbmMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbmMdModelDVO.getKanCode());
							ps.setString(psCount++, tbmMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbmMdModelDVO.getOemYn());
							ps.setString(psCount++, tbmMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbmMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbmMdModelDVO.getProdSize());
							ps.setString(psCount++, tbmMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdModelDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModel Method
* 
* @ref_table TBM_MD_MODEL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModel")
	public int[] deleteBatchTbmMdModel (final List tbmMdModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelDEM.deleteBatchTbmMdModel.001*/  \n");
			sql.append(" TBM_MD_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelDVO tbmMdModelDVO = (TbmMdModelDVO)tbmMdModelDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdModelDVOList.size();
							}
					}
		);			
	}

	
}