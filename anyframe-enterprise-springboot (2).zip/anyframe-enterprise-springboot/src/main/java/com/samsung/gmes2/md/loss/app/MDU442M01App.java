package com.samsung.gmes2.md.loss.app;

public class MDU442M01App {

	/**
	 * 입고지연원인코드 목록 초기설정
	 */
	public void initGrDlyCauseCode(){}

	/**
	 * 입고지연원인코드 목록 조회
	 */
	public void listGrDlyCauseCode(){}

	/**
	 * 입고지연원인코드 목록 엑셀 다운로드
	 */
	public void excelGrDlyCauseCode(){}

	/**
	 * 입고지연원인코드 목록 저장
	 */
	public void saveGrDlyCauseCode(){}

}
