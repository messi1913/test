package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MATR
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdMatrDEM extends AbstractDAO {


/**
* insertTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return int
*/
	@LocalName("insertTbmMdMatr")
	public int insertTbmMdMatr (final TbmMdMatrDVO tbmMdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdMatrDEM.insertTbmMdMatr.001*/  \n");
			sql.append(" TBM_MD_MATR (   \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        MATR_SPEC_CONT , \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        PURC_GRADE_CODE , \n");
			sql.append("        QUAL_GRADE_CODE , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        LF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbmMdMatrDVO.getManmCode());
							ps.setString(psCount++, tbmMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbmMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbmMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdMatr Method")
	public int[][] updateBatchAllTbmMdMatr (final List  tbmMdMatrDVOList) {
		
		ArrayList updatetbmMdMatrDVOList = new ArrayList();
		ArrayList insertttbmMdMatrDVOList = new ArrayList();
		ArrayList deletetbmMdMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdMatrDVOList.size() ; i++) {
		  TbmMdMatrDVO tbmMdMatrDVO = (TbmMdMatrDVO) tbmMdMatrDVOList.get(i);
		  
		  if (tbmMdMatrDVO.getSqlAction().equals("C"))
		      insertttbmMdMatrDVOList.add(tbmMdMatrDVO);
		  else if (tbmMdMatrDVO.getSqlAction().equals("U"))
		      updatetbmMdMatrDVOList.add(tbmMdMatrDVO);
		  else if (tbmMdMatrDVO.getSqlAction().equals("D"))
		      deletetbmMdMatrDVOList.add(tbmMdMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdMatr(insertttbmMdMatrDVOList);
          
      if (updatetbmMdMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdMatr(updatetbmMdMatrDVOList);
      
      if (deletetbmMdMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdMatr(deletetbmMdMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return int
*/
	@LocalName("updateTbmMdMatr")
	public int updateTbmMdMatr (final TbmMdMatrDVO tbmMdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdMatrDEM.updateTbmMdMatr.001*/  \n");
			sql.append(" TBM_MD_MATR \n");
			sql.append(" SET   \n");
			sql.append("        MATR_SPEC_CONT = ? , \n");
			sql.append("        MANM_CODE = ? , \n");
			sql.append("        PURC_GRADE_CODE = ? , \n");
			sql.append("        QUAL_GRADE_CODE = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        LF_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbmMdMatrDVO.getManmCode());
							ps.setString(psCount++, tbmMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbmMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbmMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* deleteTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return int
*/
	@LocalName("deleteTbmMdMatr")
	public int deleteTbmMdMatr (final TbmMdMatrDVO tbmMdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdMatrDEM.deleteTbmMdMatr.001*/  \n");
			sql.append(" TBM_MD_MATR \n");
			sql.append("  WHERE MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* selectTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return TbmMdMatrDVO 
*/
	@LocalName("selectTbmMdMatr")
	public TbmMdMatrDVO selectTbmMdMatr (final TbmMdMatrDVO tbmMdMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdMatrDEM.selectTbmMdMatr.001*/  \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        MATR_SPEC_CONT , \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        PURC_GRADE_CODE , \n");
			sql.append("        QUAL_GRADE_CODE , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        LF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MATR \n");
			sql.append("  WHERE MATR_CODE = ? \n");

		return (TbmMdMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdMatrDVO returnTbmMdMatrDVO = new TbmMdMatrDVO();
									returnTbmMdMatrDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdMatrDVO.setMatrSpecCont(resultSet.getString("MATR_SPEC_CONT"));
									returnTbmMdMatrDVO.setManmCode(resultSet.getString("MANM_CODE"));
									returnTbmMdMatrDVO.setPurcGradeCode(resultSet.getString("PURC_GRADE_CODE"));
									returnTbmMdMatrDVO.setQualGradeCode(resultSet.getString("QUAL_GRADE_CODE"));
									returnTbmMdMatrDVO.setUnitCode(resultSet.getString("UNIT_CODE"));
									returnTbmMdMatrDVO.setLfYn(resultSet.getString("LF_YN"));
									returnTbmMdMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdMatr Method")
	public int mergeTbmMdMatr (final TbmMdMatrDVO tbmMdMatrDVO) {
		
		if ( selectTbmMdMatr (tbmMdMatrDVO) == null) {
			return insertTbmMdMatr(tbmMdMatrDVO);
		} else {
			return selectUpdateTbmMdMatr (tbmMdMatrDVO);
		}
	}

	/**
	 * selectUpdateTbmMdMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdMatr Method")
	public int selectUpdateTbmMdMatr (final TbmMdMatrDVO tbmMdMatrDVO) {
		
		TbmMdMatrDVO tmpTbmMdMatrDVO =  selectTbmMdMatr (tbmMdMatrDVO);
		if ( tbmMdMatrDVO.getMatrCode() != null && !"".equals(tbmMdMatrDVO.getMatrCode()) ) {
			tmpTbmMdMatrDVO.setMatrCode(tbmMdMatrDVO.getMatrCode());
		}		
		if ( tbmMdMatrDVO.getMatrSpecCont() != null && !"".equals(tbmMdMatrDVO.getMatrSpecCont()) ) {
			tmpTbmMdMatrDVO.setMatrSpecCont(tbmMdMatrDVO.getMatrSpecCont());
		}		
		if ( tbmMdMatrDVO.getManmCode() != null && !"".equals(tbmMdMatrDVO.getManmCode()) ) {
			tmpTbmMdMatrDVO.setManmCode(tbmMdMatrDVO.getManmCode());
		}		
		if ( tbmMdMatrDVO.getPurcGradeCode() != null && !"".equals(tbmMdMatrDVO.getPurcGradeCode()) ) {
			tmpTbmMdMatrDVO.setPurcGradeCode(tbmMdMatrDVO.getPurcGradeCode());
		}		
		if ( tbmMdMatrDVO.getQualGradeCode() != null && !"".equals(tbmMdMatrDVO.getQualGradeCode()) ) {
			tmpTbmMdMatrDVO.setQualGradeCode(tbmMdMatrDVO.getQualGradeCode());
		}		
		if ( tbmMdMatrDVO.getUnitCode() != null && !"".equals(tbmMdMatrDVO.getUnitCode()) ) {
			tmpTbmMdMatrDVO.setUnitCode(tbmMdMatrDVO.getUnitCode());
		}		
		if ( tbmMdMatrDVO.getLfYn() != null && !"".equals(tbmMdMatrDVO.getLfYn()) ) {
			tmpTbmMdMatrDVO.setLfYn(tbmMdMatrDVO.getLfYn());
		}		
		if ( tbmMdMatrDVO.getUseYn() != null && !"".equals(tbmMdMatrDVO.getUseYn()) ) {
			tmpTbmMdMatrDVO.setUseYn(tbmMdMatrDVO.getUseYn());
		}		
		if ( tbmMdMatrDVO.getFstRegDt() != null && !"".equals(tbmMdMatrDVO.getFstRegDt()) ) {
			tmpTbmMdMatrDVO.setFstRegDt(tbmMdMatrDVO.getFstRegDt());
		}		
		if ( tbmMdMatrDVO.getFstRegerId() != null && !"".equals(tbmMdMatrDVO.getFstRegerId()) ) {
			tmpTbmMdMatrDVO.setFstRegerId(tbmMdMatrDVO.getFstRegerId());
		}		
		if ( tbmMdMatrDVO.getFnlUpdDt() != null && !"".equals(tbmMdMatrDVO.getFnlUpdDt()) ) {
			tmpTbmMdMatrDVO.setFnlUpdDt(tbmMdMatrDVO.getFnlUpdDt());
		}		
		if ( tbmMdMatrDVO.getFnlUpderId() != null && !"".equals(tbmMdMatrDVO.getFnlUpderId()) ) {
			tmpTbmMdMatrDVO.setFnlUpderId(tbmMdMatrDVO.getFnlUpderId());
		}		
		return updateTbmMdMatr (tmpTbmMdMatrDVO);
	}

/**
* insertBatchTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return int[]
*/
	@LocalName("insertBatchTbmMdMatr")
	public int[] insertBatchTbmMdMatr (final List tbmMdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdMatrDEM.insertBatchTbmMdMatr.001*/  \n");
			sql.append(" TBM_MD_MATR (   \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        MATR_SPEC_CONT , \n");
			sql.append("        MANM_CODE , \n");
			sql.append("        PURC_GRADE_CODE , \n");
			sql.append("        QUAL_GRADE_CODE , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        LF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdMatrDVO tbmMdMatrDVO = (TbmMdMatrDVO)tbmMdMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbmMdMatrDVO.getManmCode());
							ps.setString(psCount++, tbmMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbmMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbmMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return int[]
*/
	@LocalName("updateBatchTbmMdMatr")
	public int[] updateBatchTbmMdMatr (final List tbmMdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdMatrDEM.updateBatchTbmMdMatr.001*/  \n");
			sql.append(" TBM_MD_MATR \n");
			sql.append(" SET   \n");
			sql.append("        MATR_SPEC_CONT = ? , \n");
			sql.append("        MANM_CODE = ? , \n");
			sql.append("        PURC_GRADE_CODE = ? , \n");
			sql.append("        QUAL_GRADE_CODE = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        LF_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdMatrDVO tbmMdMatrDVO = (TbmMdMatrDVO)tbmMdMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbmMdMatrDVO.getManmCode());
							ps.setString(psCount++, tbmMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbmMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbmMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbmMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdMatr Method
* 
* @ref_table TBM_MD_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbmMdMatr")
	public int[] deleteBatchTbmMdMatr (final List tbmMdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdMatrDEM.deleteBatchTbmMdMatr.001*/  \n");
			sql.append(" TBM_MD_MATR \n");
			sql.append("  WHERE MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdMatrDVO tbmMdMatrDVO = (TbmMdMatrDVO)tbmMdMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdMatrDVOList.size();
							}
					}
		);			
	}

	
}