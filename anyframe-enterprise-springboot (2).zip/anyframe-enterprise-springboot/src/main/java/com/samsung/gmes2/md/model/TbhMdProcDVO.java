package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbhMdProcDVO extends AbstractVo {

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String lineCode;

	@Length(50) 
	private String unitProcCode;

	@Length(17) 
	private String histTsp;

	@Length(500) 
	private String procNm;

	@Length(1) 
	private String bcdSumrYn;

	@Length(50) 
	private String bcrId;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String operYn;

	@Length(1) 
	private String catvUseYn;

	@Length(1) 
	private String boardUseYn;

	@Length(1) 
	private String autoStopYn;

	@Length(1) 
	private String earlyAlrmYn;

	@Length(30) 
	private String inlineGubunCode;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;

	@Length(50) 
	private String evtNm;


	public String getFctCode() {
		this.fctCode = super.getValue(0);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(0, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(1);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(1, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getUnitProcCode() {
		this.unitProcCode = super.getValue(2);
		return this.unitProcCode;
	}

	public void setUnitProcCode(String unitProcCode) {
        super.setValue(2, unitProcCode);
		this.unitProcCode = unitProcCode;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(3);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(3, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getProcNm() {
		this.procNm = super.getValue(4);
		return this.procNm;
	}

	public void setProcNm(String procNm) {
        super.setValue(4, procNm);
		this.procNm = procNm;
	}
	
	public String getBcdSumrYn() {
		this.bcdSumrYn = super.getValue(5);
		return this.bcdSumrYn;
	}

	public void setBcdSumrYn(String bcdSumrYn) {
        super.setValue(5, bcdSumrYn);
		this.bcdSumrYn = bcdSumrYn;
	}
	
	public String getBcrId() {
		this.bcrId = super.getValue(6);
		return this.bcrId;
	}

	public void setBcrId(String bcrId) {
        super.setValue(6, bcrId);
		this.bcrId = bcrId;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue(7);
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue(7, fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getOperYn() {
		this.operYn = super.getValue(8);
		return this.operYn;
	}

	public void setOperYn(String operYn) {
        super.setValue(8, operYn);
		this.operYn = operYn;
	}
	
	public String getCatvUseYn() {
		this.catvUseYn = super.getValue(9);
		return this.catvUseYn;
	}

	public void setCatvUseYn(String catvUseYn) {
        super.setValue(9, catvUseYn);
		this.catvUseYn = catvUseYn;
	}
	
	public String getBoardUseYn() {
		this.boardUseYn = super.getValue(10);
		return this.boardUseYn;
	}

	public void setBoardUseYn(String boardUseYn) {
        super.setValue(10, boardUseYn);
		this.boardUseYn = boardUseYn;
	}
	
	public String getAutoStopYn() {
		this.autoStopYn = super.getValue(11);
		return this.autoStopYn;
	}

	public void setAutoStopYn(String autoStopYn) {
        super.setValue(11, autoStopYn);
		this.autoStopYn = autoStopYn;
	}
	
	public String getEarlyAlrmYn() {
		this.earlyAlrmYn = super.getValue(12);
		return this.earlyAlrmYn;
	}

	public void setEarlyAlrmYn(String earlyAlrmYn) {
        super.setValue(12, earlyAlrmYn);
		this.earlyAlrmYn = earlyAlrmYn;
	}
	
	public String getInlineGubunCode() {
		this.inlineGubunCode = super.getValue(13);
		return this.inlineGubunCode;
	}

	public void setInlineGubunCode(String inlineGubunCode) {
        super.setValue(13, inlineGubunCode);
		this.inlineGubunCode = inlineGubunCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(14);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(14, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(15);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(15, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(16);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(16, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(17);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(17, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(18);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(18, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
	public String getEvtNm() {
		this.evtNm = super.getValue(19);
		return this.evtNm;
	}

	public void setEvtNm(String evtNm) {
        super.setValue(19, evtNm);
		this.evtNm = evtNm;
	}
	
}