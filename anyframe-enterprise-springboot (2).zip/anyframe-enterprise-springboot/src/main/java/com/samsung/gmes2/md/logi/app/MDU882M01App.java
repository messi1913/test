package com.samsung.gmes2.md.logi.app;

public class MDU882M01App {

	/**
	 * 시리얼형태 목록 초기설정
	 */
	public void initSnNoForm(){}

	/**
	 * 시리얼형태 목록 조회
	 */
	public void listSnNoForm(){}

	/**
	 * 시리얼형태 목록 엑셀 다운로드
	 */
	public void excelSnNoForm(){}

	/**
	 * 시리얼형태 목록 저장
	 */
	public void saveSnNoForm(){}

}
