package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MFG_PART
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMfgPartDEM extends AbstractDAO {


/**
* insertTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return int
*/
	@LocalName("insertTbcMdMfgPart")
	public int insertTbcMdMfgPart (final TbcMdMfgPartDVO tbcMdMfgPartDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.insertTbcMdMfgPart.001*/  \n");
			sql.append(" TBC_MD_MFG_PART (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        MFG_GRP_CODE , \n");
			sql.append("        MFG_PART_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgGrpCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartNm());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getLabelWrtCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdMfgPart Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdMfgPart Method")
	public int[][] updateBatchAllTbcMdMfgPart (final List  tbcMdMfgPartDVOList) {
		
		ArrayList updatetbcMdMfgPartDVOList = new ArrayList();
		ArrayList insertttbcMdMfgPartDVOList = new ArrayList();
		ArrayList deletetbcMdMfgPartDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdMfgPartDVOList.size() ; i++) {
		  TbcMdMfgPartDVO tbcMdMfgPartDVO = (TbcMdMfgPartDVO) tbcMdMfgPartDVOList.get(i);
		  
		  if (tbcMdMfgPartDVO.getSqlAction().equals("C"))
		      insertttbcMdMfgPartDVOList.add(tbcMdMfgPartDVO);
		  else if (tbcMdMfgPartDVO.getSqlAction().equals("U"))
		      updatetbcMdMfgPartDVOList.add(tbcMdMfgPartDVO);
		  else if (tbcMdMfgPartDVO.getSqlAction().equals("D"))
		      deletetbcMdMfgPartDVOList.add(tbcMdMfgPartDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdMfgPartDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdMfgPart(insertttbcMdMfgPartDVOList);
          
      if (updatetbcMdMfgPartDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdMfgPart(updatetbcMdMfgPartDVOList);
      
      if (deletetbcMdMfgPartDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdMfgPart(deletetbcMdMfgPartDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return int
*/
	@LocalName("updateTbcMdMfgPart")
	public int updateTbcMdMfgPart (final TbcMdMfgPartDVO tbcMdMfgPartDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.updateTbcMdMfgPart.001*/  \n");
			sql.append(" TBC_MD_MFG_PART \n");
			sql.append(" SET   \n");
			sql.append("        MFG_TEAM_CODE = ? , \n");
			sql.append("        MFG_GRP_CODE = ? , \n");
			sql.append("        MFG_PART_NM = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        PROC_TYPE_CODE = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_PART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgGrpCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartNm());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getLabelWrtCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
						}
					}
		);			
	}

/**
* deleteTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return int
*/
	@LocalName("deleteTbcMdMfgPart")
	public int deleteTbcMdMfgPart (final TbcMdMfgPartDVO tbcMdMfgPartDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.deleteTbcMdMfgPart.001*/  \n");
			sql.append(" TBC_MD_MFG_PART \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
						}
					}
		);			
	}

/**
* selectTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return TbcMdMfgPartDVO 
*/
	@LocalName("selectTbcMdMfgPart")
	public TbcMdMfgPartDVO selectTbcMdMfgPart (final TbcMdMfgPartDVO tbcMdMfgPartDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.selectTbcMdMfgPart.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        MFG_GRP_CODE , \n");
			sql.append("        MFG_PART_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MFG_PART \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");

		return (TbcMdMfgPartDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdMfgPartDVO returnTbcMdMfgPartDVO = new TbcMdMfgPartDVO();
									returnTbcMdMfgPartDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbcMdMfgPartDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgPartDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartNm(resultSet.getString("MFG_PART_NM"));
									returnTbcMdMfgPartDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdMfgPartDVO.setProcTypeCode(resultSet.getString("PROC_TYPE_CODE"));
									returnTbcMdMfgPartDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbcMdMfgPartDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgPartDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgPartDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgPartDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgPartDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgPartDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgPartDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdMfgPart Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdMfgPart Method")
	public int mergeTbcMdMfgPart (final TbcMdMfgPartDVO tbcMdMfgPartDVO) {
		
		if ( selectTbcMdMfgPart (tbcMdMfgPartDVO) == null) {
			return insertTbcMdMfgPart(tbcMdMfgPartDVO);
		} else {
			return selectUpdateTbcMdMfgPart (tbcMdMfgPartDVO);
		}
	}

	/**
	 * selectUpdateTbcMdMfgPart Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdMfgPart Method")
	public int selectUpdateTbcMdMfgPart (final TbcMdMfgPartDVO tbcMdMfgPartDVO) {
		
		TbcMdMfgPartDVO tmpTbcMdMfgPartDVO =  selectTbcMdMfgPart (tbcMdMfgPartDVO);
		if ( tbcMdMfgPartDVO.getFctCode() != null && !"".equals(tbcMdMfgPartDVO.getFctCode()) ) {
			tmpTbcMdMfgPartDVO.setFctCode(tbcMdMfgPartDVO.getFctCode());
		}		
		if ( tbcMdMfgPartDVO.getMfgPartCode() != null && !"".equals(tbcMdMfgPartDVO.getMfgPartCode()) ) {
			tmpTbcMdMfgPartDVO.setMfgPartCode(tbcMdMfgPartDVO.getMfgPartCode());
		}		
		if ( tbcMdMfgPartDVO.getMfgTeamCode() != null && !"".equals(tbcMdMfgPartDVO.getMfgTeamCode()) ) {
			tmpTbcMdMfgPartDVO.setMfgTeamCode(tbcMdMfgPartDVO.getMfgTeamCode());
		}		
		if ( tbcMdMfgPartDVO.getMfgGrpCode() != null && !"".equals(tbcMdMfgPartDVO.getMfgGrpCode()) ) {
			tmpTbcMdMfgPartDVO.setMfgGrpCode(tbcMdMfgPartDVO.getMfgGrpCode());
		}		
		if ( tbcMdMfgPartDVO.getMfgPartNm() != null && !"".equals(tbcMdMfgPartDVO.getMfgPartNm()) ) {
			tmpTbcMdMfgPartDVO.setMfgPartNm(tbcMdMfgPartDVO.getMfgPartNm());
		}		
		if ( tbcMdMfgPartDVO.getProcGubunCode() != null && !"".equals(tbcMdMfgPartDVO.getProcGubunCode()) ) {
			tmpTbcMdMfgPartDVO.setProcGubunCode(tbcMdMfgPartDVO.getProcGubunCode());
		}		
		if ( tbcMdMfgPartDVO.getProcTypeCode() != null && !"".equals(tbcMdMfgPartDVO.getProcTypeCode()) ) {
			tmpTbcMdMfgPartDVO.setProcTypeCode(tbcMdMfgPartDVO.getProcTypeCode());
		}		
		if ( tbcMdMfgPartDVO.getLabelWrtCode() != null && !"".equals(tbcMdMfgPartDVO.getLabelWrtCode()) ) {
			tmpTbcMdMfgPartDVO.setLabelWrtCode(tbcMdMfgPartDVO.getLabelWrtCode());
		}		
		if ( tbcMdMfgPartDVO.getFnlAcrsReflYn() != null && !"".equals(tbcMdMfgPartDVO.getFnlAcrsReflYn()) ) {
			tmpTbcMdMfgPartDVO.setFnlAcrsReflYn(tbcMdMfgPartDVO.getFnlAcrsReflYn());
		}		
		if ( tbcMdMfgPartDVO.getUseYn() != null && !"".equals(tbcMdMfgPartDVO.getUseYn()) ) {
			tmpTbcMdMfgPartDVO.setUseYn(tbcMdMfgPartDVO.getUseYn());
		}		
		if ( tbcMdMfgPartDVO.getFstRegDt() != null && !"".equals(tbcMdMfgPartDVO.getFstRegDt()) ) {
			tmpTbcMdMfgPartDVO.setFstRegDt(tbcMdMfgPartDVO.getFstRegDt());
		}		
		if ( tbcMdMfgPartDVO.getFstRegerId() != null && !"".equals(tbcMdMfgPartDVO.getFstRegerId()) ) {
			tmpTbcMdMfgPartDVO.setFstRegerId(tbcMdMfgPartDVO.getFstRegerId());
		}		
		if ( tbcMdMfgPartDVO.getFnlUpdDt() != null && !"".equals(tbcMdMfgPartDVO.getFnlUpdDt()) ) {
			tmpTbcMdMfgPartDVO.setFnlUpdDt(tbcMdMfgPartDVO.getFnlUpdDt());
		}		
		if ( tbcMdMfgPartDVO.getFnlUpderId() != null && !"".equals(tbcMdMfgPartDVO.getFnlUpderId()) ) {
			tmpTbcMdMfgPartDVO.setFnlUpderId(tbcMdMfgPartDVO.getFnlUpderId());
		}		
		return updateTbcMdMfgPart (tmpTbcMdMfgPartDVO);
	}

/**
* insertBatchTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return int[]
*/
	@LocalName("insertBatchTbcMdMfgPart")
	public int[] insertBatchTbcMdMfgPart (final List tbcMdMfgPartDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.insertBatchTbcMdMfgPart.001*/  \n");
			sql.append(" TBC_MD_MFG_PART (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        MFG_GRP_CODE , \n");
			sql.append("        MFG_PART_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgPartDVO tbcMdMfgPartDVO = (TbcMdMfgPartDVO)tbcMdMfgPartDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgGrpCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartNm());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getLabelWrtCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdMfgPartDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return int[]
*/
	@LocalName("updateBatchTbcMdMfgPart")
	public int[] updateBatchTbcMdMfgPart (final List tbcMdMfgPartDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.updateBatchTbcMdMfgPart.001*/  \n");
			sql.append(" TBC_MD_MFG_PART \n");
			sql.append(" SET   \n");
			sql.append("        MFG_TEAM_CODE = ? , \n");
			sql.append("        MFG_GRP_CODE = ? , \n");
			sql.append("        MFG_PART_NM = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        PROC_TYPE_CODE = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_PART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgPartDVO tbcMdMfgPartDVO = (TbcMdMfgPartDVO)tbcMdMfgPartDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgGrpCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartNm());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getLabelWrtCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgPartDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
						}
							public int getBatchSize() {
									return tbcMdMfgPartDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdMfgPart Method
* 
* @ref_table TBC_MD_MFG_PART
* @return int[]
*/
	@LocalName("deleteBatchTbcMdMfgPart")
	public int[] deleteBatchTbcMdMfgPart (final List tbcMdMfgPartDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMfgPartDEM.deleteBatchTbcMdMfgPart.001*/  \n");
			sql.append(" TBC_MD_MFG_PART \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgPartDVO tbcMdMfgPartDVO = (TbcMdMfgPartDVO)tbcMdMfgPartDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgPartDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgPartDVO.getMfgPartCode());
						}
							public int getBatchSize() {
									return tbcMdMfgPartDVOList.size();
							}
					}
		);			
	}

	
}