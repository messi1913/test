package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdModelSpecMapDVO extends AbstractVo {

	@Length(30) 
	private String prodAbbrCode;

	@Length(30) 
	private String fldGubunCode;

	@Length(500) 
	private String attrLvlNm;

	@Length(500) 
	private String attrNm;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getProdAbbrCode() {
		this.prodAbbrCode = super.getValue(0);
		return this.prodAbbrCode;
	}

	public void setProdAbbrCode(String prodAbbrCode) {
        super.setValue(0, prodAbbrCode);
		this.prodAbbrCode = prodAbbrCode;
	}
	
	public String getFldGubunCode() {
		this.fldGubunCode = super.getValue(1);
		return this.fldGubunCode;
	}

	public void setFldGubunCode(String fldGubunCode) {
        super.setValue(1, fldGubunCode);
		this.fldGubunCode = fldGubunCode;
	}
	
	public String getAttrLvlNm() {
		this.attrLvlNm = super.getValue(2);
		return this.attrLvlNm;
	}

	public void setAttrLvlNm(String attrLvlNm) {
        super.setValue(2, attrLvlNm);
		this.attrLvlNm = attrLvlNm;
	}
	
	public String getAttrNm() {
		this.attrNm = super.getValue(3);
		return this.attrNm;
	}

	public void setAttrNm(String attrNm) {
        super.setValue(3, attrNm);
		this.attrNm = attrNm;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(4);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(4, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(5);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(5, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(6);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(6, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(7);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(7, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}