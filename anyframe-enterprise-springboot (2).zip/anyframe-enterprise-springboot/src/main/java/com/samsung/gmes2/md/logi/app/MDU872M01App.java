package com.samsung.gmes2.md.logi.app;

public class MDU872M01App {

	/**
	 * 이동지시속성 목록 초기설정
	 */
	public void initMoveInstAttr(){}

	/**
	 * 이동지시속성 목록 조회
	 */
	public void listMoveInstAttr(){}

	/**
	 * 이동지시속성 목록 엑셀 다운로드
	 */
	public void excelMoveInstAttr(){}

	/**
	 * 이동지시속성 목록 저장
	 */
	public void saveMoveInstAttr(){}

}
