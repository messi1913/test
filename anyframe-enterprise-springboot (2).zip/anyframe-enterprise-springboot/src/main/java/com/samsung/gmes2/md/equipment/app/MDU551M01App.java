package com.samsung.gmes2.md.equipment.app;

public class MDU551M01App {

	/**
	 * 메탈마스크정보 목록 초기설정
	 */
	public void initMmskInfo(){}

	/**
	 * 메탈마스크정보 목록 조회
	 */
	public void listMmskInfo(){}

	/**
	 * 메탈마스크정보 목록 엑셀 다운로드
	 */
	public void excelMmskInfo(){}

}
