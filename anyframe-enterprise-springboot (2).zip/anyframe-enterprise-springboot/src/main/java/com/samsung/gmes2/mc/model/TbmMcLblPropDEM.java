package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_LBL_PROP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcLblPropDEM extends AbstractDAO {


/**
* insertTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return int
*/
	@LocalName("insertTbmMcLblProp")
	public int insertTbmMcLblProp (final TbmMcLblPropDVO tbmMcLblPropDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.insertTbmMcLblProp.001*/  \n");
			sql.append(" TBM_MC_LBL_PROP (   \n");
			sql.append("        PROP_ID , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PROP_NM , \n");
			sql.append("        PROP_TYPE_CODE , \n");
			sql.append("        TAGT_TAB_NM , \n");
			sql.append("        TAGT_CULM_NM , \n");
			sql.append("        COND_CULM_NM , \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        PARAM_TYPE_CODE , \n");
			sql.append("        TAGT_VALUE_TYPE_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
							ps.setString(psCount++, tbmMcLblPropDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtTabNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getCondCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getParamTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtValueTypeCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcLblProp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcLblProp Method")
	public int[][] updateBatchAllTbmMcLblProp (final List  tbmMcLblPropDVOList) {
		
		ArrayList updatetbmMcLblPropDVOList = new ArrayList();
		ArrayList insertttbmMcLblPropDVOList = new ArrayList();
		ArrayList deletetbmMcLblPropDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcLblPropDVOList.size() ; i++) {
		  TbmMcLblPropDVO tbmMcLblPropDVO = (TbmMcLblPropDVO) tbmMcLblPropDVOList.get(i);
		  
		  if (tbmMcLblPropDVO.getSqlAction().equals("C"))
		      insertttbmMcLblPropDVOList.add(tbmMcLblPropDVO);
		  else if (tbmMcLblPropDVO.getSqlAction().equals("U"))
		      updatetbmMcLblPropDVOList.add(tbmMcLblPropDVO);
		  else if (tbmMcLblPropDVO.getSqlAction().equals("D"))
		      deletetbmMcLblPropDVOList.add(tbmMcLblPropDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcLblPropDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcLblProp(insertttbmMcLblPropDVOList);
          
      if (updatetbmMcLblPropDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcLblProp(updatetbmMcLblPropDVOList);
      
      if (deletetbmMcLblPropDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcLblProp(deletetbmMcLblPropDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return int
*/
	@LocalName("updateTbmMcLblProp")
	public int updateTbmMcLblProp (final TbmMcLblPropDVO tbmMcLblPropDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.updateTbmMcLblProp.001*/  \n");
			sql.append(" TBM_MC_LBL_PROP \n");
			sql.append(" SET   \n");
			sql.append("        DIV_CODE = ? , \n");
			sql.append("        PROP_NM = ? , \n");
			sql.append("        PROP_TYPE_CODE = ? , \n");
			sql.append("        TAGT_TAB_NM = ? , \n");
			sql.append("        TAGT_CULM_NM = ? , \n");
			sql.append("        COND_CULM_NM = ? , \n");
			sql.append("        SPEC_ABBR_NM = ? , \n");
			sql.append("        PARAM_TYPE_CODE = ? , \n");
			sql.append("        TAGT_VALUE_TYPE_CODE = ? \n");
			sql.append(" WHERE PROP_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblPropDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtTabNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getCondCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getParamTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtValueTypeCode());

							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
						}
					}
		);			
	}

/**
* deleteTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return int
*/
	@LocalName("deleteTbmMcLblProp")
	public int deleteTbmMcLblProp (final TbmMcLblPropDVO tbmMcLblPropDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.deleteTbmMcLblProp.001*/  \n");
			sql.append(" TBM_MC_LBL_PROP \n");
			sql.append("  WHERE PROP_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
						}
					}
		);			
	}

/**
* selectTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return TbmMcLblPropDVO 
*/
	@LocalName("selectTbmMcLblProp")
	public TbmMcLblPropDVO selectTbmMcLblProp (final TbmMcLblPropDVO tbmMcLblPropDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.selectTbmMcLblProp.001*/  \n");
			sql.append("        PROP_ID , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PROP_NM , \n");
			sql.append("        PROP_TYPE_CODE , \n");
			sql.append("        TAGT_TAB_NM , \n");
			sql.append("        TAGT_CULM_NM , \n");
			sql.append("        COND_CULM_NM , \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        PARAM_TYPE_CODE , \n");
			sql.append("        TAGT_VALUE_TYPE_CODE \n");
			sql.append("   FROM TBM_MC_LBL_PROP \n");
			sql.append("  WHERE PROP_ID = ? \n");

		return (TbmMcLblPropDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcLblPropDVO returnTbmMcLblPropDVO = new TbmMcLblPropDVO();
									returnTbmMcLblPropDVO.setPropId(resultSet.getString("PROP_ID"));
									returnTbmMcLblPropDVO.setDivCode(resultSet.getString("DIV_CODE"));
									returnTbmMcLblPropDVO.setPropNm(resultSet.getString("PROP_NM"));
									returnTbmMcLblPropDVO.setPropTypeCode(resultSet.getString("PROP_TYPE_CODE"));
									returnTbmMcLblPropDVO.setTagtTabNm(resultSet.getString("TAGT_TAB_NM"));
									returnTbmMcLblPropDVO.setTagtCulmNm(resultSet.getString("TAGT_CULM_NM"));
									returnTbmMcLblPropDVO.setCondCulmNm(resultSet.getString("COND_CULM_NM"));
									returnTbmMcLblPropDVO.setSpecAbbrNm(resultSet.getString("SPEC_ABBR_NM"));
									returnTbmMcLblPropDVO.setParamTypeCode(resultSet.getString("PARAM_TYPE_CODE"));
									returnTbmMcLblPropDVO.setTagtValueTypeCode(resultSet.getString("TAGT_VALUE_TYPE_CODE"));
									return returnTbmMcLblPropDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcLblProp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcLblProp Method")
	public int mergeTbmMcLblProp (final TbmMcLblPropDVO tbmMcLblPropDVO) {
		
		if ( selectTbmMcLblProp (tbmMcLblPropDVO) == null) {
			return insertTbmMcLblProp(tbmMcLblPropDVO);
		} else {
			return selectUpdateTbmMcLblProp (tbmMcLblPropDVO);
		}
	}

	/**
	 * selectUpdateTbmMcLblProp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcLblProp Method")
	public int selectUpdateTbmMcLblProp (final TbmMcLblPropDVO tbmMcLblPropDVO) {
		
		TbmMcLblPropDVO tmpTbmMcLblPropDVO =  selectTbmMcLblProp (tbmMcLblPropDVO);
		if ( tbmMcLblPropDVO.getPropId() != null && !"".equals(tbmMcLblPropDVO.getPropId()) ) {
			tmpTbmMcLblPropDVO.setPropId(tbmMcLblPropDVO.getPropId());
		}		
		if ( tbmMcLblPropDVO.getDivCode() != null && !"".equals(tbmMcLblPropDVO.getDivCode()) ) {
			tmpTbmMcLblPropDVO.setDivCode(tbmMcLblPropDVO.getDivCode());
		}		
		if ( tbmMcLblPropDVO.getPropNm() != null && !"".equals(tbmMcLblPropDVO.getPropNm()) ) {
			tmpTbmMcLblPropDVO.setPropNm(tbmMcLblPropDVO.getPropNm());
		}		
		if ( tbmMcLblPropDVO.getPropTypeCode() != null && !"".equals(tbmMcLblPropDVO.getPropTypeCode()) ) {
			tmpTbmMcLblPropDVO.setPropTypeCode(tbmMcLblPropDVO.getPropTypeCode());
		}		
		if ( tbmMcLblPropDVO.getTagtTabNm() != null && !"".equals(tbmMcLblPropDVO.getTagtTabNm()) ) {
			tmpTbmMcLblPropDVO.setTagtTabNm(tbmMcLblPropDVO.getTagtTabNm());
		}		
		if ( tbmMcLblPropDVO.getTagtCulmNm() != null && !"".equals(tbmMcLblPropDVO.getTagtCulmNm()) ) {
			tmpTbmMcLblPropDVO.setTagtCulmNm(tbmMcLblPropDVO.getTagtCulmNm());
		}		
		if ( tbmMcLblPropDVO.getCondCulmNm() != null && !"".equals(tbmMcLblPropDVO.getCondCulmNm()) ) {
			tmpTbmMcLblPropDVO.setCondCulmNm(tbmMcLblPropDVO.getCondCulmNm());
		}		
		if ( tbmMcLblPropDVO.getSpecAbbrNm() != null && !"".equals(tbmMcLblPropDVO.getSpecAbbrNm()) ) {
			tmpTbmMcLblPropDVO.setSpecAbbrNm(tbmMcLblPropDVO.getSpecAbbrNm());
		}		
		if ( tbmMcLblPropDVO.getParamTypeCode() != null && !"".equals(tbmMcLblPropDVO.getParamTypeCode()) ) {
			tmpTbmMcLblPropDVO.setParamTypeCode(tbmMcLblPropDVO.getParamTypeCode());
		}		
		if ( tbmMcLblPropDVO.getTagtValueTypeCode() != null && !"".equals(tbmMcLblPropDVO.getTagtValueTypeCode()) ) {
			tmpTbmMcLblPropDVO.setTagtValueTypeCode(tbmMcLblPropDVO.getTagtValueTypeCode());
		}		
		return updateTbmMcLblProp (tmpTbmMcLblPropDVO);
	}

/**
* insertBatchTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return int[]
*/
	@LocalName("insertBatchTbmMcLblProp")
	public int[] insertBatchTbmMcLblProp (final List tbmMcLblPropDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.insertBatchTbmMcLblProp.001*/  \n");
			sql.append(" TBM_MC_LBL_PROP (   \n");
			sql.append("        PROP_ID , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PROP_NM , \n");
			sql.append("        PROP_TYPE_CODE , \n");
			sql.append("        TAGT_TAB_NM , \n");
			sql.append("        TAGT_CULM_NM , \n");
			sql.append("        COND_CULM_NM , \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        PARAM_TYPE_CODE , \n");
			sql.append("        TAGT_VALUE_TYPE_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblPropDVO tbmMcLblPropDVO = (TbmMcLblPropDVO)tbmMcLblPropDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
							ps.setString(psCount++, tbmMcLblPropDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtTabNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getCondCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getParamTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtValueTypeCode());

						}
							public int getBatchSize() {
									return tbmMcLblPropDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return int[]
*/
	@LocalName("updateBatchTbmMcLblProp")
	public int[] updateBatchTbmMcLblProp (final List tbmMcLblPropDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.updateBatchTbmMcLblProp.001*/  \n");
			sql.append(" TBM_MC_LBL_PROP \n");
			sql.append(" SET   \n");
			sql.append("        DIV_CODE = ? , \n");
			sql.append("        PROP_NM = ? , \n");
			sql.append("        PROP_TYPE_CODE = ? , \n");
			sql.append("        TAGT_TAB_NM = ? , \n");
			sql.append("        TAGT_CULM_NM = ? , \n");
			sql.append("        COND_CULM_NM = ? , \n");
			sql.append("        SPEC_ABBR_NM = ? , \n");
			sql.append("        PARAM_TYPE_CODE = ? , \n");
			sql.append("        TAGT_VALUE_TYPE_CODE = ? \n");
			sql.append(" WHERE PROP_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblPropDVO tbmMcLblPropDVO = (TbmMcLblPropDVO)tbmMcLblPropDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblPropDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getPropTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtTabNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getCondCulmNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmMcLblPropDVO.getParamTypeCode());
							ps.setString(psCount++, tbmMcLblPropDVO.getTagtValueTypeCode());

							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
						}
							public int getBatchSize() {
									return tbmMcLblPropDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcLblProp Method
* 
* @ref_table TBM_MC_LBL_PROP
* @return int[]
*/
	@LocalName("deleteBatchTbmMcLblProp")
	public int[] deleteBatchTbmMcLblProp (final List tbmMcLblPropDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblPropDEM.deleteBatchTbmMcLblProp.001*/  \n");
			sql.append(" TBM_MC_LBL_PROP \n");
			sql.append("  WHERE PROP_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblPropDVO tbmMcLblPropDVO = (TbmMcLblPropDVO)tbmMcLblPropDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblPropDVO.getPropId());
						}
							public int getBatchSize() {
									return tbmMcLblPropDVOList.size();
							}
					}
		);			
	}

	
}