package com.samsung.gmes2.base.util;

import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

public class CacheUtil
{
    private static final Logger logger = LoggerFactory.getLogger( CacheUtil.class );

    private static CacheManager cacheManager;

    public static CacheManager getManager( )
    {
        if ( cacheManager == null )
            cacheManager = (CacheManager) ( (Ehcache) BeanUtil.get( "ehcache" ) ).getCacheManager( );
        return cacheManager;
    }

    private static Boolean cacheable = null;

    /**
     * cache 가 사용가능한지 확인합니다.
     * 
     * @return
     */
    public static boolean isCacheable( )
    {
        if ( cacheable == null )
        {
            try
            {
                cacheable = BeanUtil.get( "ehcache" ) != null;
            }
            catch ( NoSuchBeanDefinitionException e )
            {
                cacheable = false;
            }
            catch ( NullPointerException e )
            {
                cacheable = false;
            }
        }
        if ( cacheable && ThreadPropertyUtil.contains( CACHEABLE ) )
        {
            @SuppressWarnings("unchecked")
            List<Boolean> list = (List<Boolean>) ThreadPropertyUtil.get( CACHEABLE );
            if ( list.isEmpty( ) )
                return cacheable;
            return list.get( 0 );
        }
        return cacheable;
    }

    private static final String CACHEABLE = "cacheable";

    @SuppressWarnings("unchecked")
    public static void setCacheable( boolean cacheable )
    {
        List<Boolean> list = null;
        if ( ThreadPropertyUtil.contains( CACHEABLE ) )
        {
            list = (List<Boolean>) ThreadPropertyUtil.get( CACHEABLE );
        }
        else
        {
            list = new ArrayList<Boolean>( );
            ThreadPropertyUtil.put( CACHEABLE, list );
        }
        list.add( 0, cacheable );
    }

    public static void release( )
    {
        if ( !ThreadPropertyUtil.contains( CACHEABLE ) )
            return;
        @SuppressWarnings("unchecked")
        List<Boolean> list = (List<Boolean>) ThreadPropertyUtil.get( CACHEABLE );
        if ( list.isEmpty( ) )
            return;
        list.remove( 0 );
    }

    /**
     * name, key 에 맞는 cache 된 객체를 얻습니다.
     * 
     * @param name
     * @param key
     * @return
     */
    public static Object get( String name, String key )
    {
        if ( !isCacheable( ) || BaseUtil.isEmpty( name ) || key == null )
            return null;
        if ( !getManager( ).cacheExists( name ) )
            getManager( ).addCache( name );
        Element elem = getManager( ).getCache( name ).get( key );
        Object obj = elem == null ? null : elem.getObjectValue( );
        if ( obj != null && logger.isDebugEnabled( ) )
            logger.debug( new StringBuffer( "get cache of name:" ).append( name ).append( " key:" ).append( key ).toString( ) );
        return obj;
    }

    /**
     * obj 를 name, key 에 따라 cache 합니다.
     * 
     * @param name
     * @param key
     * @param obj
     * @return
     * @throws Exception
     */
    public static Object put( String name, String key, Object obj ) throws Exception
    {
        if ( !isCacheable( ) || BaseUtil.isEmpty( name ) || key == null )
            return obj;
        getManager( ).getCache( name ).put( new Element( key, obj ) );
        if ( logger.isDebugEnabled( ) )
            logger.debug( new StringBuffer( "put cache of name:" ).append( name ).append( " key:" ).append( key ).toString( ) );
        return obj;
    }

    /**
     * name, key 에 맞는 cache 된 객체를 제거합니다.
     * 
     * @param name
     * @param key
     */
    public static void remove( String name, String key )
    {
        if ( !isCacheable( ) || BaseUtil.isEmpty( name ) || key == null )
            return;
        boolean removed = getManager( ).getCache( name ).remove( key );
        if ( removed && logger.isDebugEnabled( ) )
            logger.debug( new StringBuffer( "remove cache of name:" ).append( name ).append( " key:" ).append( key ).toString( ) );
    }
}
