package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author KYJ
 */
public class TbcMdMfgTeamDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String mfgTeamCode;

	@Length(50) 
	private String pidEmpNo;

	@Length(500) 
	private String mfgTeamNm;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getMfgTeamCode() {
		this.mfgTeamCode = super.getValue("mfgTeamCode");
		return this.mfgTeamCode;
	}

	public void setMfgTeamCode(String mfgTeamCode) {
        super.setValue("mfgTeamCode", mfgTeamCode);
		this.mfgTeamCode = mfgTeamCode;
	}
	
	public String getPidEmpNo() {
		this.pidEmpNo = super.getValue("pidEmpNo");
		return this.pidEmpNo;
	}

	public void setPidEmpNo(String pidEmpNo) {
        super.setValue("pidEmpNo", pidEmpNo);
		this.pidEmpNo = pidEmpNo;
	}
	
	public String getMfgTeamNm() {
		this.mfgTeamNm = super.getValue("mfgTeamNm");
		return this.mfgTeamNm;
	}

	public void setMfgTeamNm(String mfgTeamNm) {
        super.setValue("mfgTeamNm", mfgTeamNm);
		this.mfgTeamNm = mfgTeamNm;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue("fnlAcrsReflYn");
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue("fnlAcrsReflYn", fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}