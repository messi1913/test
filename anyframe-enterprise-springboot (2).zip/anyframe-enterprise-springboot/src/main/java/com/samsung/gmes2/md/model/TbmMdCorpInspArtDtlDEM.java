package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdCorpInspArtDtlDEM extends AbstractDAO {


/**
* insertTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return int
*/
	@LocalName("insertTbmMdCorpInspArtDtl")
	public int insertTbmMdCorpInspArtDtl (final TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.insertTbmMdCorpInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_CORP_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        MESNG_FORM_TRANS_YN , \n");
			sql.append("        COEF_FORM_TRANS_YN , \n");
			sql.append("        AUTO_INSP_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getMesngFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCoefFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getAutoInspYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdCorpInspArtDtl Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdCorpInspArtDtl Method")
	public int[][] updateBatchAllTbmMdCorpInspArtDtl (final List  tbmMdCorpInspArtDtlDVOList) {
		
		ArrayList updatetbmMdCorpInspArtDtlDVOList = new ArrayList();
		ArrayList insertttbmMdCorpInspArtDtlDVOList = new ArrayList();
		ArrayList deletetbmMdCorpInspArtDtlDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdCorpInspArtDtlDVOList.size() ; i++) {
		  TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO = (TbmMdCorpInspArtDtlDVO) tbmMdCorpInspArtDtlDVOList.get(i);
		  
		  if (tbmMdCorpInspArtDtlDVO.getSqlAction().equals("C"))
		      insertttbmMdCorpInspArtDtlDVOList.add(tbmMdCorpInspArtDtlDVO);
		  else if (tbmMdCorpInspArtDtlDVO.getSqlAction().equals("U"))
		      updatetbmMdCorpInspArtDtlDVOList.add(tbmMdCorpInspArtDtlDVO);
		  else if (tbmMdCorpInspArtDtlDVO.getSqlAction().equals("D"))
		      deletetbmMdCorpInspArtDtlDVOList.add(tbmMdCorpInspArtDtlDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdCorpInspArtDtlDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdCorpInspArtDtl(insertttbmMdCorpInspArtDtlDVOList);
          
      if (updatetbmMdCorpInspArtDtlDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdCorpInspArtDtl(updatetbmMdCorpInspArtDtlDVOList);
      
      if (deletetbmMdCorpInspArtDtlDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdCorpInspArtDtl(deletetbmMdCorpInspArtDtlDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return int
*/
	@LocalName("updateTbmMdCorpInspArtDtl")
	public int updateTbmMdCorpInspArtDtl (final TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.updateTbmMdCorpInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_CORP_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        MESNG_FORM_TRANS_YN = ? , \n");
			sql.append("        COEF_FORM_TRANS_YN = ? , \n");
			sql.append("        AUTO_INSP_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getMesngFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCoefFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getAutoInspYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
						}
					}
		);			
	}

/**
* deleteTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return int
*/
	@LocalName("deleteTbmMdCorpInspArtDtl")
	public int deleteTbmMdCorpInspArtDtl (final TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.deleteTbmMdCorpInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_CORP_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
						}
					}
		);			
	}

/**
* selectTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return TbmMdCorpInspArtDtlDVO 
*/
	@LocalName("selectTbmMdCorpInspArtDtl")
	public TbmMdCorpInspArtDtlDVO selectTbmMdCorpInspArtDtl (final TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.selectTbmMdCorpInspArtDtl.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        MESNG_FORM_TRANS_YN , \n");
			sql.append("        COEF_FORM_TRANS_YN , \n");
			sql.append("        AUTO_INSP_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_CORP_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return (TbmMdCorpInspArtDtlDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdCorpInspArtDtlDVO returnTbmMdCorpInspArtDtlDVO = new TbmMdCorpInspArtDtlDVO();
									returnTbmMdCorpInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdCorpInspArtDtlDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMdCorpInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbmMdCorpInspArtDtlDVO.setMesngFormTransYn(resultSet.getString("MESNG_FORM_TRANS_YN"));
									returnTbmMdCorpInspArtDtlDVO.setCoefFormTransYn(resultSet.getString("COEF_FORM_TRANS_YN"));
									returnTbmMdCorpInspArtDtlDVO.setAutoInspYn(resultSet.getString("AUTO_INSP_YN"));
									returnTbmMdCorpInspArtDtlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdCorpInspArtDtlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdCorpInspArtDtlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdCorpInspArtDtlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdCorpInspArtDtlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdCorpInspArtDtlDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdCorpInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdCorpInspArtDtl Method")
	public int mergeTbmMdCorpInspArtDtl (final TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO) {
		
		if ( selectTbmMdCorpInspArtDtl (tbmMdCorpInspArtDtlDVO) == null) {
			return insertTbmMdCorpInspArtDtl(tbmMdCorpInspArtDtlDVO);
		} else {
			return selectUpdateTbmMdCorpInspArtDtl (tbmMdCorpInspArtDtlDVO);
		}
	}

	/**
	 * selectUpdateTbmMdCorpInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdCorpInspArtDtl Method")
	public int selectUpdateTbmMdCorpInspArtDtl (final TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO) {
		
		TbmMdCorpInspArtDtlDVO tmpTbmMdCorpInspArtDtlDVO =  selectTbmMdCorpInspArtDtl (tbmMdCorpInspArtDtlDVO);
		if ( tbmMdCorpInspArtDtlDVO.getGbmCode() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getGbmCode()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setGbmCode(tbmMdCorpInspArtDtlDVO.getGbmCode());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getCorpCode() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getCorpCode()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setCorpCode(tbmMdCorpInspArtDtlDVO.getCorpCode());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getInspArtDtlCode() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getInspArtDtlCode()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setInspArtDtlCode(tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getMesngFormTransYn() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getMesngFormTransYn()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setMesngFormTransYn(tbmMdCorpInspArtDtlDVO.getMesngFormTransYn());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getCoefFormTransYn() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getCoefFormTransYn()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setCoefFormTransYn(tbmMdCorpInspArtDtlDVO.getCoefFormTransYn());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getAutoInspYn() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getAutoInspYn()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setAutoInspYn(tbmMdCorpInspArtDtlDVO.getAutoInspYn());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getUseYn() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getUseYn()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setUseYn(tbmMdCorpInspArtDtlDVO.getUseYn());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getFstRegDt() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getFstRegDt()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setFstRegDt(tbmMdCorpInspArtDtlDVO.getFstRegDt());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getFstRegerId() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getFstRegerId()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setFstRegerId(tbmMdCorpInspArtDtlDVO.getFstRegerId());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getFnlUpdDt() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getFnlUpdDt()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setFnlUpdDt(tbmMdCorpInspArtDtlDVO.getFnlUpdDt());
		}		
		if ( tbmMdCorpInspArtDtlDVO.getFnlUpderId() != null && !"".equals(tbmMdCorpInspArtDtlDVO.getFnlUpderId()) ) {
			tmpTbmMdCorpInspArtDtlDVO.setFnlUpderId(tbmMdCorpInspArtDtlDVO.getFnlUpderId());
		}		
		return updateTbmMdCorpInspArtDtl (tmpTbmMdCorpInspArtDtlDVO);
	}

/**
* insertBatchTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return int[]
*/
	@LocalName("insertBatchTbmMdCorpInspArtDtl")
	public int[] insertBatchTbmMdCorpInspArtDtl (final List tbmMdCorpInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.insertBatchTbmMdCorpInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_CORP_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        MESNG_FORM_TRANS_YN , \n");
			sql.append("        COEF_FORM_TRANS_YN , \n");
			sql.append("        AUTO_INSP_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO = (TbmMdCorpInspArtDtlDVO)tbmMdCorpInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getMesngFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCoefFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getAutoInspYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdCorpInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return int[]
*/
	@LocalName("updateBatchTbmMdCorpInspArtDtl")
	public int[] updateBatchTbmMdCorpInspArtDtl (final List tbmMdCorpInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.updateBatchTbmMdCorpInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_CORP_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        MESNG_FORM_TRANS_YN = ? , \n");
			sql.append("        COEF_FORM_TRANS_YN = ? , \n");
			sql.append("        AUTO_INSP_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO = (TbmMdCorpInspArtDtlDVO)tbmMdCorpInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getMesngFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCoefFormTransYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getAutoInspYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
						}
							public int getBatchSize() {
									return tbmMdCorpInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdCorpInspArtDtl Method
* 
* @ref_table TBM_MD_CORP_INSP_ART_DTL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdCorpInspArtDtl")
	public int[] deleteBatchTbmMdCorpInspArtDtl (final List tbmMdCorpInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdCorpInspArtDtlDEM.deleteBatchTbmMdCorpInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_CORP_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdCorpInspArtDtlDVO tbmMdCorpInspArtDtlDVO = (TbmMdCorpInspArtDtlDVO)tbmMdCorpInspArtDtlDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpInspArtDtlDVO.getInspArtDtlCode());
						}
							public int getBatchSize() {
									return tbmMdCorpInspArtDtlDVOList.size();
							}
					}
		);			
	}

	
}