package com.samsung.gmes2.md.logi.app;

public class MDU822M01App {

	/**
	 * Zone 목록 초기설정
	 */
	public void initZoneInfo(){}

	/**
	 * Zone 목록 조회
	 */
	public void listZoneInfo(){}

	/**
	 * Zone 목록 엑셀 다운로드
	 */
	public void excelZoneInfo(){}

	/**
	 * Zone 목록 저장
	 */
	public void saveZoneInfo(){}

	/**
	 * Zone 목록 등록/수정 초기설정
	 */
	public void editZoneInfo(){}

}
