package com.samsung.gmes2.md.material.biz;

public class MdManageModelKtngMatrBiz {

	/**
	 * 모델별Kitting 목록 조회
	 */
	public void listModelKitting(){}

	/**
	 * 모델별Kitting 목록 저장
	 */
	public void saveModelKitting(){}

}
