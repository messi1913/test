package com.samsung.gmes2.md.cmm.biz;

public class MdEquipBaseBiz {

	/**
	 * 설비분류 리스트
	 */
	public void listEquipClsfBase(){}
	
	/**
	 * 설비그룹 리스트
	 */
	public void listEquipGrpBase(){}

	/**
	 * 설비종류 리스트
	 */
	public void listEquipKindBase(){}

	/**
	 * 설비모델 리스트
	 */
	public void listEquipModelBase(){}

	/**
	 * 설비코드 리스트
	 */
	public void listEquipCodeBase(){}

	/**
	 * 설비ID 리스트
	 */
	public void listEquipIdBase(){}

}
