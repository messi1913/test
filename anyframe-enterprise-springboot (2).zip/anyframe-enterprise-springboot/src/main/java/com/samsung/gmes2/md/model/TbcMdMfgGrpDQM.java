package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMfgGrpDQM extends AbstractDAO {


/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_GRP_NM, 
* 	MFG_TEAM_CODE, 
* 	GRP_RPRS_EMP_NO, 
* 	OUTS_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_GRP 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgGrpNm) 
* AND MFG_GRP_NM = :mfgGrpNm 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($grpRprsEmpNo) 
* AND GRP_RPRS_EMP_NO = :grpRprsEmpNo 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_GRP_NM,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	GRP_RPRS_EMP_NO,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_GRP  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpNm)  \n");
			sql.append(" AND MFG_GRP_NM = :mfgGrpNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpRprsEmpNo)  \n");
			sql.append(" AND GRP_RPRS_EMP_NO = :grpRprsEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgGrpDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgGrpDVO returnTbcMdMfgGrpDVO = new TbcMdMfgGrpDVO();
									returnTbcMdMfgGrpDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpNm(resultSet.getString("MFG_GRP_NM"));
									returnTbcMdMfgGrpDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgGrpDVO.setGrpRprsEmpNo(resultSet.getString("GRP_RPRS_EMP_NO"));
									returnTbcMdMfgGrpDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdMfgGrpDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgGrpDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgGrpDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgGrpDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgGrpDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgGrpDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgGrpDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_GRP_NM, 
* 	MFG_TEAM_CODE, 
* 	GRP_RPRS_EMP_NO
* FROM TBC_MD_MFG_GRP 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgGrpNm) 
* AND MFG_GRP_NM = :mfgGrpNm 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($grpRprsEmpNo) 
* AND GRP_RPRS_EMP_NO = :grpRprsEmpNo 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_GRP_NM,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	GRP_RPRS_EMP_NO \n");
			sql.append(" FROM TBC_MD_MFG_GRP  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpNm)  \n");
			sql.append(" AND MFG_GRP_NM = :mfgGrpNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpRprsEmpNo)  \n");
			sql.append(" AND GRP_RPRS_EMP_NO = :grpRprsEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgGrpDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgGrpDVO returnTbcMdMfgGrpDVO = new TbcMdMfgGrpDVO();
									returnTbcMdMfgGrpDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpNm(resultSet.getString("MFG_GRP_NM"));
									returnTbcMdMfgGrpDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgGrpDVO.setGrpRprsEmpNo(resultSet.getString("GRP_RPRS_EMP_NO"));
									return returnTbcMdMfgGrpDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_GRP_NM, 
* 	MFG_TEAM_CODE, 
* 	GRP_RPRS_EMP_NO, 
* 	OUTS_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_GRP 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgGrpNm) 
* AND MFG_GRP_NM = :mfgGrpNm 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($grpRprsEmpNo) 
* AND GRP_RPRS_EMP_NO = :grpRprsEmpNo 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_GRP_NM,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	GRP_RPRS_EMP_NO,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_GRP  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpNm)  \n");
			sql.append(" AND MFG_GRP_NM = :mfgGrpNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpRprsEmpNo)  \n");
			sql.append(" AND GRP_RPRS_EMP_NO = :grpRprsEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgGrpDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgGrpDVO returnTbcMdMfgGrpDVO = new TbcMdMfgGrpDVO();
									returnTbcMdMfgGrpDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpNm(resultSet.getString("MFG_GRP_NM"));
									returnTbcMdMfgGrpDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgGrpDVO.setGrpRprsEmpNo(resultSet.getString("GRP_RPRS_EMP_NO"));
									returnTbcMdMfgGrpDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdMfgGrpDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgGrpDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgGrpDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgGrpDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgGrpDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgGrpDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgGrpDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_GRP_NM, 
* 	MFG_TEAM_CODE, 
* 	GRP_RPRS_EMP_NO
* FROM TBC_MD_MFG_GRP 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgGrpNm) 
* AND MFG_GRP_NM = :mfgGrpNm 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($grpRprsEmpNo) 
* AND GRP_RPRS_EMP_NO = :grpRprsEmpNo 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_GRP_NM,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	GRP_RPRS_EMP_NO \n");
			sql.append(" FROM TBC_MD_MFG_GRP  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpNm)  \n");
			sql.append(" AND MFG_GRP_NM = :mfgGrpNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($grpRprsEmpNo)  \n");
			sql.append(" AND GRP_RPRS_EMP_NO = :grpRprsEmpNo  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgGrpDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgGrpDVO returnTbcMdMfgGrpDVO = new TbcMdMfgGrpDVO();
									returnTbcMdMfgGrpDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgGrpDVO.setMfgGrpNm(resultSet.getString("MFG_GRP_NM"));
									returnTbcMdMfgGrpDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgGrpDVO.setGrpRprsEmpNo(resultSet.getString("GRP_RPRS_EMP_NO"));
									return returnTbcMdMfgGrpDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}