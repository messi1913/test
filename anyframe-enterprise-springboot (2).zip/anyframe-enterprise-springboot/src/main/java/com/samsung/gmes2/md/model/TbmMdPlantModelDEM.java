package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PLANT_MODEL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPlantModelDEM extends AbstractDAO {


/**
* insertTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return int
*/
	@LocalName("insertTbmMdPlantModel")
	public int insertTbmMdPlantModel (final TbmMdPlantModelDVO tbmMdPlantModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.insertTbmMdPlantModel.001*/  \n");
			sql.append(" TBM_MD_PLANT_MODEL (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        MATR_TYPE_CODE , \n");
			sql.append("        BUYER_CODE , \n");
			sql.append("        BUYER_INSP_YN , \n");
			sql.append("        SAL_REGN_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getSalRegnNm());
							ps.setString(psCount++, tbmMdPlantModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPlantModel Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPlantModel Method")
	public int[][] updateBatchAllTbmMdPlantModel (final List  tbmMdPlantModelDVOList) {
		
		ArrayList updatetbmMdPlantModelDVOList = new ArrayList();
		ArrayList insertttbmMdPlantModelDVOList = new ArrayList();
		ArrayList deletetbmMdPlantModelDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPlantModelDVOList.size() ; i++) {
		  TbmMdPlantModelDVO tbmMdPlantModelDVO = (TbmMdPlantModelDVO) tbmMdPlantModelDVOList.get(i);
		  
		  if (tbmMdPlantModelDVO.getSqlAction().equals("C"))
		      insertttbmMdPlantModelDVOList.add(tbmMdPlantModelDVO);
		  else if (tbmMdPlantModelDVO.getSqlAction().equals("U"))
		      updatetbmMdPlantModelDVOList.add(tbmMdPlantModelDVO);
		  else if (tbmMdPlantModelDVO.getSqlAction().equals("D"))
		      deletetbmMdPlantModelDVOList.add(tbmMdPlantModelDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPlantModelDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPlantModel(insertttbmMdPlantModelDVOList);
          
      if (updatetbmMdPlantModelDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPlantModel(updatetbmMdPlantModelDVOList);
      
      if (deletetbmMdPlantModelDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPlantModel(deletetbmMdPlantModelDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return int
*/
	@LocalName("updateTbmMdPlantModel")
	public int updateTbmMdPlantModel (final TbmMdPlantModelDVO tbmMdPlantModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.updateTbmMdPlantModel.001*/  \n");
			sql.append(" TBM_MD_PLANT_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        MATR_TYPE_CODE = ? , \n");
			sql.append("        BUYER_CODE = ? , \n");
			sql.append("        BUYER_INSP_YN = ? , \n");
			sql.append("        SAL_REGN_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantModelDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getSalRegnNm());
							ps.setString(psCount++, tbmMdPlantModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
						}
					}
		);			
	}

/**
* deleteTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return int
*/
	@LocalName("deleteTbmMdPlantModel")
	public int deleteTbmMdPlantModel (final TbmMdPlantModelDVO tbmMdPlantModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.deleteTbmMdPlantModel.001*/  \n");
			sql.append(" TBM_MD_PLANT_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
						}
					}
		);			
	}

/**
* selectTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return TbmMdPlantModelDVO 
*/
	@LocalName("selectTbmMdPlantModel")
	public TbmMdPlantModelDVO selectTbmMdPlantModel (final TbmMdPlantModelDVO tbmMdPlantModelDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.selectTbmMdPlantModel.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        MATR_TYPE_CODE , \n");
			sql.append("        BUYER_CODE , \n");
			sql.append("        BUYER_INSP_YN , \n");
			sql.append("        SAL_REGN_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PLANT_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return (TbmMdPlantModelDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPlantModelDVO returnTbmMdPlantModelDVO = new TbmMdPlantModelDVO();
									returnTbmMdPlantModelDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPlantModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdPlantModelDVO.setIfDt(resultSet.getString("IF_DT"));
									returnTbmMdPlantModelDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbmMdPlantModelDVO.setMatrTypeCode(resultSet.getString("MATR_TYPE_CODE"));
									returnTbmMdPlantModelDVO.setBuyerCode(resultSet.getString("BUYER_CODE"));
									returnTbmMdPlantModelDVO.setBuyerInspYn(resultSet.getString("BUYER_INSP_YN"));
									returnTbmMdPlantModelDVO.setSalRegnNm(resultSet.getString("SAL_REGN_NM"));
									returnTbmMdPlantModelDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdPlantModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPlantModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPlantModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPlantModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPlantModelDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPlantModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPlantModel Method")
	public int mergeTbmMdPlantModel (final TbmMdPlantModelDVO tbmMdPlantModelDVO) {
		
		if ( selectTbmMdPlantModel (tbmMdPlantModelDVO) == null) {
			return insertTbmMdPlantModel(tbmMdPlantModelDVO);
		} else {
			return selectUpdateTbmMdPlantModel (tbmMdPlantModelDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPlantModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPlantModel Method")
	public int selectUpdateTbmMdPlantModel (final TbmMdPlantModelDVO tbmMdPlantModelDVO) {
		
		TbmMdPlantModelDVO tmpTbmMdPlantModelDVO =  selectTbmMdPlantModel (tbmMdPlantModelDVO);
		if ( tbmMdPlantModelDVO.getPlantCode() != null && !"".equals(tbmMdPlantModelDVO.getPlantCode()) ) {
			tmpTbmMdPlantModelDVO.setPlantCode(tbmMdPlantModelDVO.getPlantCode());
		}		
		if ( tbmMdPlantModelDVO.getModelCode() != null && !"".equals(tbmMdPlantModelDVO.getModelCode()) ) {
			tmpTbmMdPlantModelDVO.setModelCode(tbmMdPlantModelDVO.getModelCode());
		}		
		if ( tbmMdPlantModelDVO.getIfDt() != null && !"".equals(tbmMdPlantModelDVO.getIfDt()) ) {
			tmpTbmMdPlantModelDVO.setIfDt(tbmMdPlantModelDVO.getIfDt());
		}		
		if ( tbmMdPlantModelDVO.getLabelWrtCode() != null && !"".equals(tbmMdPlantModelDVO.getLabelWrtCode()) ) {
			tmpTbmMdPlantModelDVO.setLabelWrtCode(tbmMdPlantModelDVO.getLabelWrtCode());
		}		
		if ( tbmMdPlantModelDVO.getMatrTypeCode() != null && !"".equals(tbmMdPlantModelDVO.getMatrTypeCode()) ) {
			tmpTbmMdPlantModelDVO.setMatrTypeCode(tbmMdPlantModelDVO.getMatrTypeCode());
		}		
		if ( tbmMdPlantModelDVO.getBuyerCode() != null && !"".equals(tbmMdPlantModelDVO.getBuyerCode()) ) {
			tmpTbmMdPlantModelDVO.setBuyerCode(tbmMdPlantModelDVO.getBuyerCode());
		}		
		if ( tbmMdPlantModelDVO.getBuyerInspYn() != null && !"".equals(tbmMdPlantModelDVO.getBuyerInspYn()) ) {
			tmpTbmMdPlantModelDVO.setBuyerInspYn(tbmMdPlantModelDVO.getBuyerInspYn());
		}		
		if ( tbmMdPlantModelDVO.getSalRegnNm() != null && !"".equals(tbmMdPlantModelDVO.getSalRegnNm()) ) {
			tmpTbmMdPlantModelDVO.setSalRegnNm(tbmMdPlantModelDVO.getSalRegnNm());
		}		
		if ( tbmMdPlantModelDVO.getUseYn() != null && !"".equals(tbmMdPlantModelDVO.getUseYn()) ) {
			tmpTbmMdPlantModelDVO.setUseYn(tbmMdPlantModelDVO.getUseYn());
		}		
		if ( tbmMdPlantModelDVO.getFstRegDt() != null && !"".equals(tbmMdPlantModelDVO.getFstRegDt()) ) {
			tmpTbmMdPlantModelDVO.setFstRegDt(tbmMdPlantModelDVO.getFstRegDt());
		}		
		if ( tbmMdPlantModelDVO.getFstRegerId() != null && !"".equals(tbmMdPlantModelDVO.getFstRegerId()) ) {
			tmpTbmMdPlantModelDVO.setFstRegerId(tbmMdPlantModelDVO.getFstRegerId());
		}		
		if ( tbmMdPlantModelDVO.getFnlUpdDt() != null && !"".equals(tbmMdPlantModelDVO.getFnlUpdDt()) ) {
			tmpTbmMdPlantModelDVO.setFnlUpdDt(tbmMdPlantModelDVO.getFnlUpdDt());
		}		
		if ( tbmMdPlantModelDVO.getFnlUpderId() != null && !"".equals(tbmMdPlantModelDVO.getFnlUpderId()) ) {
			tmpTbmMdPlantModelDVO.setFnlUpderId(tbmMdPlantModelDVO.getFnlUpderId());
		}		
		return updateTbmMdPlantModel (tmpTbmMdPlantModelDVO);
	}

/**
* insertBatchTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return int[]
*/
	@LocalName("insertBatchTbmMdPlantModel")
	public int[] insertBatchTbmMdPlantModel (final List tbmMdPlantModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.insertBatchTbmMdPlantModel.001*/  \n");
			sql.append(" TBM_MD_PLANT_MODEL (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        MATR_TYPE_CODE , \n");
			sql.append("        BUYER_CODE , \n");
			sql.append("        BUYER_INSP_YN , \n");
			sql.append("        SAL_REGN_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantModelDVO tbmMdPlantModelDVO = (TbmMdPlantModelDVO)tbmMdPlantModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getSalRegnNm());
							ps.setString(psCount++, tbmMdPlantModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPlantModelDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return int[]
*/
	@LocalName("updateBatchTbmMdPlantModel")
	public int[] updateBatchTbmMdPlantModel (final List tbmMdPlantModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.updateBatchTbmMdPlantModel.001*/  \n");
			sql.append(" TBM_MD_PLANT_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        MATR_TYPE_CODE = ? , \n");
			sql.append("        BUYER_CODE = ? , \n");
			sql.append("        BUYER_INSP_YN = ? , \n");
			sql.append("        SAL_REGN_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantModelDVO tbmMdPlantModelDVO = (TbmMdPlantModelDVO)tbmMdPlantModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantModelDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getSalRegnNm());
							ps.setString(psCount++, tbmMdPlantModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdPlantModelDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPlantModel Method
* 
* @ref_table TBM_MD_PLANT_MODEL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPlantModel")
	public int[] deleteBatchTbmMdPlantModel (final List tbmMdPlantModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantModelDEM.deleteBatchTbmMdPlantModel.001*/  \n");
			sql.append(" TBM_MD_PLANT_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantModelDVO tbmMdPlantModelDVO = (TbmMdPlantModelDVO)tbmMdPlantModelDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantModelDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdPlantModelDVOList.size();
							}
					}
		);			
	}

	
}