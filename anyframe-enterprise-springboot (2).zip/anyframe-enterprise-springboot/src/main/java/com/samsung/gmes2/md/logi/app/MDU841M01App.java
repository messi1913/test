package com.samsung.gmes2.md.logi.app;

public class MDU841M01App {

	/**
	 * 출항지 목록 초기설정
	 */
	public void initOport(){}

	/**
	 * 출항지 목록 조회
	 */
	public void listOport(){}

	/**
	 * 출항지 목록 엑셀 다운로드
	 */
	public void excelOport(){}

	/**
	 * 출항지 목록 저장
	 */
	public void saveOport(){}

}
