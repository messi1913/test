package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractSVO;

/**
 * 
 * @stereotype SVO
 * @author sangminKim
 */
public class TbcMdProcGubunDVO extends AbstractSVO {

	@Length(30) @NotNull
	private String procGubunCode;

	@Length(500) 
	private String procGubunCodeNm;

	@Length(2000) 
	private String procGubunDesc;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getProcGubunCode() {
		this.procGubunCode = super.getValue("procGubunCode");
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue("procGubunCode", procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getProcGubunCodeNm() {
		this.procGubunCodeNm = super.getValue("procGubunCodeNm");
		return this.procGubunCodeNm;
	}

	public void setProcGubunCodeNm(String procGubunCodeNm) {
        super.setValue("procGubunCodeNm", procGubunCodeNm);
		this.procGubunCodeNm = procGubunCodeNm;
	}
	
	public String getProcGubunDesc() {
		this.procGubunDesc = super.getValue("procGubunDesc");
		return this.procGubunDesc;
	}

	public void setProcGubunDesc(String procGubunDesc) {
        super.setValue("procGubunDesc", procGubunDesc);
		this.procGubunDesc = procGubunDesc;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}