package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeftCauseClsfDQM extends AbstractDAO {


/**
*
* SELECT 
*        DEFT_CAUSE_CLSF_CODE ,
*        PROC_GUBUN_CODE ,
*        DEFT_CAUSE_CLSF_NM ,
*        USE_YN ,
*        FST_REG_DT ,
*        FST_REGER_ID ,
*        FNL_UPD_DT ,
*        FNL_UPDER_ID
*  FROM TBC_MD_DEFT_CAUSE_CLSF
* 
* @ref_table 
* @return List
*
*/
	public List listTbcMdDeftCauseClsfDVO (final Map inputMap) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        DEFT_CAUSE_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("  FROM TBC_MD_DEFT_CAUSE_CLSF \n");
		sql.append(" /* com.samsung.gmes2.md.cmm.api.mdm.TbcMdDeftCauseClsfDQM.listTbcMdDeftCauseClsfDVO.001 */ \n");

		Object[] args = new Object[] {};
		int[] argTypes = new int[] {};
		if ( inputMap != null) {
			int inputSize = new String[] {}.length;
			if (inputSize > 0) {
				args = new Object[inputSize];
				argTypes =  new int[inputSize];
			
				int cnt = 0;
 			}	
		}

		return query(sql.toString() , args , argTypes ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdDeftCauseClsfDVO returnTbcMdDeftCauseClsfDVO = new TbcMdDeftCauseClsfDVO();
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(resultSet.getString("DEFT_CAUSE_CLSF_NM"));
									returnTbcMdDeftCauseClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftCauseClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftCauseClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftCauseClsfDVO;
					    	}
					    	
					   }
 		);
	}


/**
* 
*
* SELECT 
* 	DEFT_CAUSE_CLSF_CODE, 
* 	PROC_GUBUN_CODE, 
* 	DEFT_CAUSE_CLSF_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_DEFT_CAUSE_CLSF 
* WHERE 1=1 
* #if($deftCauseClsfCode) 
* AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($deftCauseClsfNm) 
* AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_DEFT_CAUSE_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($deftCauseClsfCode)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($deftCauseClsfNm)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.cmm.api.mdm.TbcMdDeftCauseClsfDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdDeftCauseClsfDVO returnTbcMdDeftCauseClsfDVO = new TbcMdDeftCauseClsfDVO();
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(resultSet.getString("DEFT_CAUSE_CLSF_NM"));
									returnTbcMdDeftCauseClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftCauseClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftCauseClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftCauseClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	DEFT_CAUSE_CLSF_CODE, 
* 	PROC_GUBUN_CODE, 
* 	DEFT_CAUSE_CLSF_NM
* FROM TBC_MD_DEFT_CAUSE_CLSF 
* WHERE 1=1 
* #if($deftCauseClsfCode) 
* AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($deftCauseClsfNm) 
* AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_NM \n");
			sql.append(" FROM TBC_MD_DEFT_CAUSE_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($deftCauseClsfCode)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($deftCauseClsfNm)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.cmm.api.mdm.TbcMdDeftCauseClsfDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdDeftCauseClsfDVO returnTbcMdDeftCauseClsfDVO = new TbcMdDeftCauseClsfDVO();
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(resultSet.getString("DEFT_CAUSE_CLSF_NM"));
									return returnTbcMdDeftCauseClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	DEFT_CAUSE_CLSF_CODE, 
* 	PROC_GUBUN_CODE, 
* 	DEFT_CAUSE_CLSF_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_DEFT_CAUSE_CLSF 
* WHERE 1=1 
* #if($deftCauseClsfCode) 
* AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($deftCauseClsfNm) 
* AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_DEFT_CAUSE_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($deftCauseClsfCode)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($deftCauseClsfNm)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.cmm.api.mdm.TbcMdDeftCauseClsfDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdDeftCauseClsfDVO returnTbcMdDeftCauseClsfDVO = new TbcMdDeftCauseClsfDVO();
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(resultSet.getString("DEFT_CAUSE_CLSF_NM"));
									returnTbcMdDeftCauseClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftCauseClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftCauseClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftCauseClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
* 
*
* SELECT 
* 	DEFT_CAUSE_CLSF_CODE, 
* 	PROC_GUBUN_CODE, 
* 	DEFT_CAUSE_CLSF_NM
* FROM TBC_MD_DEFT_CAUSE_CLSF 
* WHERE 1=1 
* #if($deftCauseClsfCode) 
* AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($deftCauseClsfNm) 
* AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	DEFT_CAUSE_CLSF_NM \n");
			sql.append(" FROM TBC_MD_DEFT_CAUSE_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($deftCauseClsfCode)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_CODE = :deftCauseClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($deftCauseClsfNm)  \n");
			sql.append(" AND DEFT_CAUSE_CLSF_NM = :deftCauseClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.cmm.api.mdm.TbcMdDeftCauseClsfDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdDeftCauseClsfDVO returnTbcMdDeftCauseClsfDVO = new TbcMdDeftCauseClsfDVO();
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(resultSet.getString("DEFT_CAUSE_CLSF_NM"));
									return returnTbcMdDeftCauseClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}