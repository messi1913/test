package com.samsung.gmes2.md.logi.app;

public class MDU823M01App {

	/**
	 * Bin 목록 초기설정
	 */
	public void initBinInfo(){}

	/**
	 * Bin 목록 조회
	 */
	public void listBinInfo(){}

	/**
	 * Bin 목록 엑셀 다운로드
	 */
	public void excelBinInfo(){}

	/**
	 * Bin 목록 등록/수정 초기설정
	 */
	public void editBinInfo(){}

	/**
	 * Bin 목록 저장
	 */
	public void saveBinInfo(){}

}
