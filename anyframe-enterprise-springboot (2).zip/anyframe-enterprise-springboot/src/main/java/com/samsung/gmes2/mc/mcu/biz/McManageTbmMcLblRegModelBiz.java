package com.samsung.gmes2.mc.mcu.biz;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.samsung.gmes2.base.Constants;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.mc.mcu.vo.McU611M0006DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M0008DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M00SVO;
import com.samsung.gmes2.mc.model.TbmMcLblRegModelDEM;
import com.samsung.gmes2.mc.model.TbmMcLblRegModelDVO;
/**
 * 한글명 : 라벨모델 조회 
 * 작성일 : 2011.07.08 
 * 작성자 : 심 재 국 
 * 작업상태 : 완료 
 * 개요 : 팝업창에서 라벨모델 조회를 하고 
 * 라벨모델을 선택하여 새로운 라벨을 등록하거나 삭제 할 수 있다.
 * 등록과 삭제가 한번에 이루어진다.
 * 
 * @author shim
 *
 */
public class McManageTbmMcLblRegModelBiz {

	private TbmMcLblRegModelDEM tbmMcLblRegModelDEM;
	
	private TbmMcLblRegModelDEM getTbmMcLblRegModelDEM(){
		if(tbmMcLblRegModelDEM==null){
			tbmMcLblRegModelDEM = BaseUtil.getBean(TbmMcLblRegModelDEM.class);
		}
		return tbmMcLblRegModelDEM;
	}
	public void saveTbmMcLblRegModel(List<McU611M0006DVO> tempList) {
		//DAO는 new로 생성해서 사용하지 않고 BaseUtil을 이용하여 얻어서 사용한다.
		//TbmMcLblRegModelDEM tbmMcLblRegModelDEM = new TbmMcLblRegModelDEM();
		TbmMcLblRegModelDEM tbmMcLblRegModelDEM = getTbmMcLblRegModelDEM();
		
		List<McU611M0006DVO> insertList= new ArrayList<McU611M0006DVO>();
		List<McU611M0006DVO> deleteList= new ArrayList<McU611M0006DVO>();

		List<McU611M0006DVO> mcU611M0006DVOList=new ArrayList<McU611M0006DVO>();

		for (McU611M0006DVO dvo : tempList){
			// 현재 여기서 순서를 중요시 해야한다.
			// xframe 에서  _status 가 I 가 D 보다 먼저 넘어 오기때문에
			// D를 먼저 처리 하고 I를 처리한다.
			// 따라서 Constants.DELETE_FLAG 를 먼저 처리한다.
			if(dvo.get_status() == Constants.DELETE_FLAG){
				deleteList.add(dvo);
			}else if(dvo.get_status() == Constants.INSERT_FLAG ){
				insertList.add(dvo);
			}

		}
		
		// table과 1:1 이면 위에 까지 하고 if문을 활용하여 size를 check 하고 
		// insertBatch, deleteBatch 를 시켜주면 된다.
		// 위와 같지않으면 아래와 같이 값들을 맵핑 시켜줘야 한다.
		
		TbmMcLblRegModelDVO tbmMcLblRegModelDVO = null;
		List<TbmMcLblRegModelDVO> TbmMcLblRegModelDVOList = null;

		if(deleteList.size()>0){
			TbmMcLblRegModelDVOList = new ArrayList<TbmMcLblRegModelDVO>();
			for(McU611M0006DVO dvo : deleteList){

				tbmMcLblRegModelDVO = new TbmMcLblRegModelDVO();

				tbmMcLblRegModelDVO.setModelCode(dvo.getModelCode());
				tbmMcLblRegModelDVO.setLabelId(dvo.getLabelId());
				tbmMcLblRegModelDVO.setStatusCode("작성중");
				tbmMcLblRegModelDVO.setReger("홍길동");
				//tbmMcLblRegModelDVO.setRegDt("20110708");

				TbmMcLblRegModelDVOList.add(tbmMcLblRegModelDVO);
			}				
			tbmMcLblRegModelDEM.deleteBatchTbmMcLblRegModel(TbmMcLblRegModelDVOList);
		}
		
		if(insertList.size() >0 ){
			TbmMcLblRegModelDVOList = new ArrayList<TbmMcLblRegModelDVO>();
			for(McU611M0006DVO dvo : insertList){
				tbmMcLblRegModelDVO = new TbmMcLblRegModelDVO();

				tbmMcLblRegModelDVO.setModelCode(dvo.getModelCode());
				tbmMcLblRegModelDVO.setLabelId(dvo.getLabelId());
				tbmMcLblRegModelDVO.setStatusCode("작성중");
				tbmMcLblRegModelDVO.setReger("홍길동");
				SimpleDateFormat formatter = new SimpleDateFormat ( "yyyyMMdd", Locale.KOREA );
				tbmMcLblRegModelDVO.setRegDt(formatter.format(new Date()));
				TbmMcLblRegModelDVOList.add(tbmMcLblRegModelDVO);
			}

			tbmMcLblRegModelDEM.insertBatchTbmMcLblRegModel(TbmMcLblRegModelDVOList);
		}
		
	}
	public McU611M00SVO delelteModelCode(McU611M00SVO svo) {
		
		// Exception 처리
		if (svo.getMcU611M0008DVOList().size() > 0) {
			// delete시 현재는 단건이면 McU611M0008DVO 로 받아도 되지만
			// 나중에 여러게 클릭후 한번에 삭제 가능성이있기에 McU611M0008DVOList로 받음
			// 다건이면 for문을 이용해서 setting 해주고
			// 현재는 단건 하나기때문에 하나만 setting
			McU611M0008DVO mcU611M0008DVO = svo.getMcU611M0008DVOList().get(0);

			String modelCode = mcU611M0008DVO.getModelCode();
			String labelId = mcU611M0008DVO.getLabelId();

			TbmMcLblRegModelDVO tbmMcLblRegModelDVO = new TbmMcLblRegModelDVO();

			tbmMcLblRegModelDVO.setModelCode(modelCode);
			tbmMcLblRegModelDVO.setLabelId(labelId);
			//DAO는 new로 생성해서 사용하지 않고 BaseUtil을 이용하여 얻어서 사용한다.
			//TbmMcLblRegModelDEM tbmMcLblRegModelDEM = new TbmMcLblRegModelDEM();
			TbmMcLblRegModelDEM tbmMcLblRegModelDEM = getTbmMcLblRegModelDEM();
			

			tbmMcLblRegModelDEM.deleteTbmMcLblRegModel(tbmMcLblRegModelDVO);
		} else {
			throw new Gmes2LogicException("SMSE0004", "데이터 값이 없습니다.");
		}
		return svo;
	}

}
