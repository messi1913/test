package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_SPEC
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelSpecDEM extends AbstractDAO {


/**
* insertTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return int
*/
	@LocalName("insertTbmMdModelSpec")
	public int insertTbmMdModelSpec (final TbmMdModelSpecDVO tbmMdModelSpecDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.insertTbmMdModelSpec.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        FLD_GUBUN_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        IF_YN , \n");
			sql.append("        FLD_VALUE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getIfDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldValue());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelSpec Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelSpec Method")
	public int[][] updateBatchAllTbmMdModelSpec (final List  tbmMdModelSpecDVOList) {
		
		ArrayList updatetbmMdModelSpecDVOList = new ArrayList();
		ArrayList insertttbmMdModelSpecDVOList = new ArrayList();
		ArrayList deletetbmMdModelSpecDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelSpecDVOList.size() ; i++) {
		  TbmMdModelSpecDVO tbmMdModelSpecDVO = (TbmMdModelSpecDVO) tbmMdModelSpecDVOList.get(i);
		  
		  if (tbmMdModelSpecDVO.getSqlAction().equals("C"))
		      insertttbmMdModelSpecDVOList.add(tbmMdModelSpecDVO);
		  else if (tbmMdModelSpecDVO.getSqlAction().equals("U"))
		      updatetbmMdModelSpecDVOList.add(tbmMdModelSpecDVO);
		  else if (tbmMdModelSpecDVO.getSqlAction().equals("D"))
		      deletetbmMdModelSpecDVOList.add(tbmMdModelSpecDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelSpecDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelSpec(insertttbmMdModelSpecDVOList);
          
      if (updatetbmMdModelSpecDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelSpec(updatetbmMdModelSpecDVOList);
      
      if (deletetbmMdModelSpecDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelSpec(deletetbmMdModelSpecDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return int
*/
	@LocalName("updateTbmMdModelSpec")
	public int updateTbmMdModelSpec (final TbmMdModelSpecDVO tbmMdModelSpecDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.updateTbmMdModelSpec.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        IF_YN = ? , \n");
			sql.append("        FLD_VALUE = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND PROD_ABBR_CODE = ? \n");
			sql.append("   AND FLD_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecDVO.getIfDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldValue());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
						}
					}
		);			
	}

/**
* deleteTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return int
*/
	@LocalName("deleteTbmMdModelSpec")
	public int deleteTbmMdModelSpec (final TbmMdModelSpecDVO tbmMdModelSpecDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.deleteTbmMdModelSpec.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND FLD_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
						}
					}
		);			
	}

/**
* selectTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return TbmMdModelSpecDVO 
*/
	@LocalName("selectTbmMdModelSpec")
	public TbmMdModelSpecDVO selectTbmMdModelSpec (final TbmMdModelSpecDVO tbmMdModelSpecDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.selectTbmMdModelSpec.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        FLD_GUBUN_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        IF_YN , \n");
			sql.append("        FLD_VALUE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_SPEC \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND FLD_GUBUN_CODE = ? \n");

		return (TbmMdModelSpecDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelSpecDVO returnTbmMdModelSpecDVO = new TbmMdModelSpecDVO();
									returnTbmMdModelSpecDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdModelSpecDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelSpecDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbmMdModelSpecDVO.setFldGubunCode(resultSet.getString("FLD_GUBUN_CODE"));
									returnTbmMdModelSpecDVO.setIfDt(resultSet.getString("IF_DT"));
									returnTbmMdModelSpecDVO.setIfYn(resultSet.getString("IF_YN"));
									returnTbmMdModelSpecDVO.setFldValue(resultSet.getString("FLD_VALUE"));
									returnTbmMdModelSpecDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelSpecDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelSpecDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelSpecDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelSpecDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelSpec Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelSpec Method")
	public int mergeTbmMdModelSpec (final TbmMdModelSpecDVO tbmMdModelSpecDVO) {
		
		if ( selectTbmMdModelSpec (tbmMdModelSpecDVO) == null) {
			return insertTbmMdModelSpec(tbmMdModelSpecDVO);
		} else {
			return selectUpdateTbmMdModelSpec (tbmMdModelSpecDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelSpec Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelSpec Method")
	public int selectUpdateTbmMdModelSpec (final TbmMdModelSpecDVO tbmMdModelSpecDVO) {
		
		TbmMdModelSpecDVO tmpTbmMdModelSpecDVO =  selectTbmMdModelSpec (tbmMdModelSpecDVO);
		if ( tbmMdModelSpecDVO.getPlantCode() != null && !"".equals(tbmMdModelSpecDVO.getPlantCode()) ) {
			tmpTbmMdModelSpecDVO.setPlantCode(tbmMdModelSpecDVO.getPlantCode());
		}		
		if ( tbmMdModelSpecDVO.getModelCode() != null && !"".equals(tbmMdModelSpecDVO.getModelCode()) ) {
			tmpTbmMdModelSpecDVO.setModelCode(tbmMdModelSpecDVO.getModelCode());
		}		
		if ( tbmMdModelSpecDVO.getProdAbbrCode() != null && !"".equals(tbmMdModelSpecDVO.getProdAbbrCode()) ) {
			tmpTbmMdModelSpecDVO.setProdAbbrCode(tbmMdModelSpecDVO.getProdAbbrCode());
		}		
		if ( tbmMdModelSpecDVO.getFldGubunCode() != null && !"".equals(tbmMdModelSpecDVO.getFldGubunCode()) ) {
			tmpTbmMdModelSpecDVO.setFldGubunCode(tbmMdModelSpecDVO.getFldGubunCode());
		}		
		if ( tbmMdModelSpecDVO.getIfDt() != null && !"".equals(tbmMdModelSpecDVO.getIfDt()) ) {
			tmpTbmMdModelSpecDVO.setIfDt(tbmMdModelSpecDVO.getIfDt());
		}		
		if ( tbmMdModelSpecDVO.getIfYn() != null && !"".equals(tbmMdModelSpecDVO.getIfYn()) ) {
			tmpTbmMdModelSpecDVO.setIfYn(tbmMdModelSpecDVO.getIfYn());
		}		
		if ( tbmMdModelSpecDVO.getFldValue() != null && !"".equals(tbmMdModelSpecDVO.getFldValue()) ) {
			tmpTbmMdModelSpecDVO.setFldValue(tbmMdModelSpecDVO.getFldValue());
		}		
		if ( tbmMdModelSpecDVO.getFstRegDt() != null && !"".equals(tbmMdModelSpecDVO.getFstRegDt()) ) {
			tmpTbmMdModelSpecDVO.setFstRegDt(tbmMdModelSpecDVO.getFstRegDt());
		}		
		if ( tbmMdModelSpecDVO.getFstRegerId() != null && !"".equals(tbmMdModelSpecDVO.getFstRegerId()) ) {
			tmpTbmMdModelSpecDVO.setFstRegerId(tbmMdModelSpecDVO.getFstRegerId());
		}		
		if ( tbmMdModelSpecDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelSpecDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelSpecDVO.setFnlUpdDt(tbmMdModelSpecDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelSpecDVO.getFnlUpderId() != null && !"".equals(tbmMdModelSpecDVO.getFnlUpderId()) ) {
			tmpTbmMdModelSpecDVO.setFnlUpderId(tbmMdModelSpecDVO.getFnlUpderId());
		}		
		return updateTbmMdModelSpec (tmpTbmMdModelSpecDVO);
	}

/**
* insertBatchTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelSpec")
	public int[] insertBatchTbmMdModelSpec (final List tbmMdModelSpecDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.insertBatchTbmMdModelSpec.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        FLD_GUBUN_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        IF_YN , \n");
			sql.append("        FLD_VALUE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelSpecDVO tbmMdModelSpecDVO = (TbmMdModelSpecDVO)tbmMdModelSpecDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getIfDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldValue());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelSpecDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelSpec")
	public int[] updateBatchTbmMdModelSpec (final List tbmMdModelSpecDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.updateBatchTbmMdModelSpec.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        IF_YN = ? , \n");
			sql.append("        FLD_VALUE = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND PROD_ABBR_CODE = ? \n");
			sql.append("   AND FLD_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelSpecDVO tbmMdModelSpecDVO = (TbmMdModelSpecDVO)tbmMdModelSpecDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecDVO.getIfDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldValue());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
						}
							public int getBatchSize() {
									return tbmMdModelSpecDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelSpec Method
* 
* @ref_table TBM_MD_MODEL_SPEC
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelSpec")
	public int[] deleteBatchTbmMdModelSpec (final List tbmMdModelSpecDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelSpecDEM.deleteBatchTbmMdModelSpec.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND FLD_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelSpecDVO tbmMdModelSpecDVO = (TbmMdModelSpecDVO)tbmMdModelSpecDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelSpecDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecDVO.getFldGubunCode());
						}
							public int getBatchSize() {
									return tbmMdModelSpecDVOList.size();
							}
					}
		);			
	}

	
}