package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_EQUIP_STNG
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcEquipStngDEM extends AbstractDAO {


/**
* insertTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return int
*/
	@LocalName("insertTbmMcEquipStng")
	public int insertTbmMcEquipStng (final TbmMcEquipStngDVO tbmMcEquipStngDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.insertTbmMcEquipStng.001*/  \n");
			sql.append(" TBM_MC_EQUIP_STNG (   \n");
			sql.append("        IP , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        EQUIP_NO , \n");
			sql.append("        EQUIP_CTGR_CODE , \n");
			sql.append("        PRTMC_CTGR_CODE , \n");
			sql.append("        PRTMC_PORT_NO , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        DARKNESS_VALUE , \n");
			sql.append("        TROFFPOS_VALUE , \n");
			sql.append("        TOPPOS_VALUE , \n");
			sql.append("        PRTMC_SPEED , \n");
			sql.append("        SCNNR_PORT_NO , \n");
			sql.append("        COMN_SPEED , \n");
			sql.append("        PRTBIT_VALUE , \n");
			sql.append("        DATBIT_VALUE , \n");
			sql.append("        STOPBIT_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDarknessValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTroffposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTopposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtmcSpeed());
							ps.setString(psCount++, tbmMcEquipStngDVO.getScnnrPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getComnSpeed());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDatbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getStopbitValue());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcEquipStng Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcEquipStng Method")
	public int[][] updateBatchAllTbmMcEquipStng (final List  tbmMcEquipStngDVOList) {
		
		ArrayList updatetbmMcEquipStngDVOList = new ArrayList();
		ArrayList insertttbmMcEquipStngDVOList = new ArrayList();
		ArrayList deletetbmMcEquipStngDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcEquipStngDVOList.size() ; i++) {
		  TbmMcEquipStngDVO tbmMcEquipStngDVO = (TbmMcEquipStngDVO) tbmMcEquipStngDVOList.get(i);
		  
		  if (tbmMcEquipStngDVO.getSqlAction().equals("C"))
		      insertttbmMcEquipStngDVOList.add(tbmMcEquipStngDVO);
		  else if (tbmMcEquipStngDVO.getSqlAction().equals("U"))
		      updatetbmMcEquipStngDVOList.add(tbmMcEquipStngDVO);
		  else if (tbmMcEquipStngDVO.getSqlAction().equals("D"))
		      deletetbmMcEquipStngDVOList.add(tbmMcEquipStngDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcEquipStngDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcEquipStng(insertttbmMcEquipStngDVOList);
          
      if (updatetbmMcEquipStngDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcEquipStng(updatetbmMcEquipStngDVOList);
      
      if (deletetbmMcEquipStngDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcEquipStng(deletetbmMcEquipStngDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return int
*/
	@LocalName("updateTbmMcEquipStng")
	public int updateTbmMcEquipStng (final TbmMcEquipStngDVO tbmMcEquipStngDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.updateTbmMcEquipStng.001*/  \n");
			sql.append(" TBM_MC_EQUIP_STNG \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_CTGR_CODE = ? , \n");
			sql.append("        PRTMC_CTGR_CODE = ? , \n");
			sql.append("        PRTMC_PORT_NO = ? , \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        DARKNESS_VALUE = ? , \n");
			sql.append("        TROFFPOS_VALUE = ? , \n");
			sql.append("        TOPPOS_VALUE = ? , \n");
			sql.append("        PRTMC_SPEED = ? , \n");
			sql.append("        SCNNR_PORT_NO = ? , \n");
			sql.append("        COMN_SPEED = ? , \n");
			sql.append("        PRTBIT_VALUE = ? , \n");
			sql.append("        DATBIT_VALUE = ? , \n");
			sql.append("        STOPBIT_VALUE = ? \n");
			sql.append(" WHERE IP = ? \n");
			sql.append("   AND PGM_CODE = ? \n");
			sql.append("   AND EQUIP_NO = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDarknessValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTroffposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTopposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtmcSpeed());
							ps.setString(psCount++, tbmMcEquipStngDVO.getScnnrPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getComnSpeed());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDatbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getStopbitValue());

							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
						}
					}
		);			
	}

/**
* deleteTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return int
*/
	@LocalName("deleteTbmMcEquipStng")
	public int deleteTbmMcEquipStng (final TbmMcEquipStngDVO tbmMcEquipStngDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.deleteTbmMcEquipStng.001*/  \n");
			sql.append(" TBM_MC_EQUIP_STNG \n");
			sql.append("  WHERE IP = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND EQUIP_NO = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
						}
					}
		);			
	}

/**
* selectTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return TbmMcEquipStngDVO 
*/
	@LocalName("selectTbmMcEquipStng")
	public TbmMcEquipStngDVO selectTbmMcEquipStng (final TbmMcEquipStngDVO tbmMcEquipStngDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.selectTbmMcEquipStng.001*/  \n");
			sql.append("        IP , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        EQUIP_NO , \n");
			sql.append("        EQUIP_CTGR_CODE , \n");
			sql.append("        PRTMC_CTGR_CODE , \n");
			sql.append("        PRTMC_PORT_NO , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        DARKNESS_VALUE , \n");
			sql.append("        TROFFPOS_VALUE , \n");
			sql.append("        TOPPOS_VALUE , \n");
			sql.append("        PRTMC_SPEED , \n");
			sql.append("        SCNNR_PORT_NO , \n");
			sql.append("        COMN_SPEED , \n");
			sql.append("        PRTBIT_VALUE , \n");
			sql.append("        DATBIT_VALUE , \n");
			sql.append("        STOPBIT_VALUE \n");
			sql.append("   FROM TBM_MC_EQUIP_STNG \n");
			sql.append("  WHERE IP = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND EQUIP_NO = ? \n");

		return (TbmMcEquipStngDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcEquipStngDVO returnTbmMcEquipStngDVO = new TbmMcEquipStngDVO();
									returnTbmMcEquipStngDVO.setIp(resultSet.getString("IP"));
									returnTbmMcEquipStngDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbmMcEquipStngDVO.setEquipNo(resultSet.getString("EQUIP_NO"));
									returnTbmMcEquipStngDVO.setEquipCtgrCode(resultSet.getString("EQUIP_CTGR_CODE"));
									returnTbmMcEquipStngDVO.setPrtmcCtgrCode(resultSet.getString("PRTMC_CTGR_CODE"));
									returnTbmMcEquipStngDVO.setPrtmcPortNo(resultSet.getString("PRTMC_PORT_NO"));
									returnTbmMcEquipStngDVO.setxValue(resultSet.getBigDecimal("X_VALUE"));
									returnTbmMcEquipStngDVO.setyValue(resultSet.getBigDecimal("Y_VALUE"));
									returnTbmMcEquipStngDVO.setDarknessValue(resultSet.getBigDecimal("DARKNESS_VALUE"));
									returnTbmMcEquipStngDVO.setTroffposValue(resultSet.getBigDecimal("TROFFPOS_VALUE"));
									returnTbmMcEquipStngDVO.setTopposValue(resultSet.getBigDecimal("TOPPOS_VALUE"));
									returnTbmMcEquipStngDVO.setPrtmcSpeed(resultSet.getBigDecimal("PRTMC_SPEED"));
									returnTbmMcEquipStngDVO.setScnnrPortNo(resultSet.getString("SCNNR_PORT_NO"));
									returnTbmMcEquipStngDVO.setComnSpeed(resultSet.getBigDecimal("COMN_SPEED"));
									returnTbmMcEquipStngDVO.setPrtbitValue(resultSet.getBigDecimal("PRTBIT_VALUE"));
									returnTbmMcEquipStngDVO.setDatbitValue(resultSet.getBigDecimal("DATBIT_VALUE"));
									returnTbmMcEquipStngDVO.setStopbitValue(resultSet.getBigDecimal("STOPBIT_VALUE"));
									return returnTbmMcEquipStngDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcEquipStng Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcEquipStng Method")
	public int mergeTbmMcEquipStng (final TbmMcEquipStngDVO tbmMcEquipStngDVO) {
		
		if ( selectTbmMcEquipStng (tbmMcEquipStngDVO) == null) {
			return insertTbmMcEquipStng(tbmMcEquipStngDVO);
		} else {
			return selectUpdateTbmMcEquipStng (tbmMcEquipStngDVO);
		}
	}

	/**
	 * selectUpdateTbmMcEquipStng Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcEquipStng Method")
	public int selectUpdateTbmMcEquipStng (final TbmMcEquipStngDVO tbmMcEquipStngDVO) {
		
		TbmMcEquipStngDVO tmpTbmMcEquipStngDVO =  selectTbmMcEquipStng (tbmMcEquipStngDVO);
		if ( tbmMcEquipStngDVO.getIp() != null && !"".equals(tbmMcEquipStngDVO.getIp()) ) {
			tmpTbmMcEquipStngDVO.setIp(tbmMcEquipStngDVO.getIp());
		}		
		if ( tbmMcEquipStngDVO.getPgmCode() != null && !"".equals(tbmMcEquipStngDVO.getPgmCode()) ) {
			tmpTbmMcEquipStngDVO.setPgmCode(tbmMcEquipStngDVO.getPgmCode());
		}		
		if ( tbmMcEquipStngDVO.getEquipNo() != null && !"".equals(tbmMcEquipStngDVO.getEquipNo()) ) {
			tmpTbmMcEquipStngDVO.setEquipNo(tbmMcEquipStngDVO.getEquipNo());
		}		
		if ( tbmMcEquipStngDVO.getEquipCtgrCode() != null && !"".equals(tbmMcEquipStngDVO.getEquipCtgrCode()) ) {
			tmpTbmMcEquipStngDVO.setEquipCtgrCode(tbmMcEquipStngDVO.getEquipCtgrCode());
		}		
		if ( tbmMcEquipStngDVO.getPrtmcCtgrCode() != null && !"".equals(tbmMcEquipStngDVO.getPrtmcCtgrCode()) ) {
			tmpTbmMcEquipStngDVO.setPrtmcCtgrCode(tbmMcEquipStngDVO.getPrtmcCtgrCode());
		}		
		if ( tbmMcEquipStngDVO.getPrtmcPortNo() != null && !"".equals(tbmMcEquipStngDVO.getPrtmcPortNo()) ) {
			tmpTbmMcEquipStngDVO.setPrtmcPortNo(tbmMcEquipStngDVO.getPrtmcPortNo());
		}		
		if ( tbmMcEquipStngDVO.getxValue() != null && !"".equals(tbmMcEquipStngDVO.getxValue()) ) {
			tmpTbmMcEquipStngDVO.setxValue(tbmMcEquipStngDVO.getxValue());
		}		
		if ( tbmMcEquipStngDVO.getyValue() != null && !"".equals(tbmMcEquipStngDVO.getyValue()) ) {
			tmpTbmMcEquipStngDVO.setyValue(tbmMcEquipStngDVO.getyValue());
		}		
		if ( tbmMcEquipStngDVO.getDarknessValue() != null && !"".equals(tbmMcEquipStngDVO.getDarknessValue()) ) {
			tmpTbmMcEquipStngDVO.setDarknessValue(tbmMcEquipStngDVO.getDarknessValue());
		}		
		if ( tbmMcEquipStngDVO.getTroffposValue() != null && !"".equals(tbmMcEquipStngDVO.getTroffposValue()) ) {
			tmpTbmMcEquipStngDVO.setTroffposValue(tbmMcEquipStngDVO.getTroffposValue());
		}		
		if ( tbmMcEquipStngDVO.getTopposValue() != null && !"".equals(tbmMcEquipStngDVO.getTopposValue()) ) {
			tmpTbmMcEquipStngDVO.setTopposValue(tbmMcEquipStngDVO.getTopposValue());
		}		
		if ( tbmMcEquipStngDVO.getPrtmcSpeed() != null && !"".equals(tbmMcEquipStngDVO.getPrtmcSpeed()) ) {
			tmpTbmMcEquipStngDVO.setPrtmcSpeed(tbmMcEquipStngDVO.getPrtmcSpeed());
		}		
		if ( tbmMcEquipStngDVO.getScnnrPortNo() != null && !"".equals(tbmMcEquipStngDVO.getScnnrPortNo()) ) {
			tmpTbmMcEquipStngDVO.setScnnrPortNo(tbmMcEquipStngDVO.getScnnrPortNo());
		}		
		if ( tbmMcEquipStngDVO.getComnSpeed() != null && !"".equals(tbmMcEquipStngDVO.getComnSpeed()) ) {
			tmpTbmMcEquipStngDVO.setComnSpeed(tbmMcEquipStngDVO.getComnSpeed());
		}		
		if ( tbmMcEquipStngDVO.getPrtbitValue() != null && !"".equals(tbmMcEquipStngDVO.getPrtbitValue()) ) {
			tmpTbmMcEquipStngDVO.setPrtbitValue(tbmMcEquipStngDVO.getPrtbitValue());
		}		
		if ( tbmMcEquipStngDVO.getDatbitValue() != null && !"".equals(tbmMcEquipStngDVO.getDatbitValue()) ) {
			tmpTbmMcEquipStngDVO.setDatbitValue(tbmMcEquipStngDVO.getDatbitValue());
		}		
		if ( tbmMcEquipStngDVO.getStopbitValue() != null && !"".equals(tbmMcEquipStngDVO.getStopbitValue()) ) {
			tmpTbmMcEquipStngDVO.setStopbitValue(tbmMcEquipStngDVO.getStopbitValue());
		}		
		return updateTbmMcEquipStng (tmpTbmMcEquipStngDVO);
	}

/**
* insertBatchTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return int[]
*/
	@LocalName("insertBatchTbmMcEquipStng")
	public int[] insertBatchTbmMcEquipStng (final List tbmMcEquipStngDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.insertBatchTbmMcEquipStng.001*/  \n");
			sql.append(" TBM_MC_EQUIP_STNG (   \n");
			sql.append("        IP , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        EQUIP_NO , \n");
			sql.append("        EQUIP_CTGR_CODE , \n");
			sql.append("        PRTMC_CTGR_CODE , \n");
			sql.append("        PRTMC_PORT_NO , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        DARKNESS_VALUE , \n");
			sql.append("        TROFFPOS_VALUE , \n");
			sql.append("        TOPPOS_VALUE , \n");
			sql.append("        PRTMC_SPEED , \n");
			sql.append("        SCNNR_PORT_NO , \n");
			sql.append("        COMN_SPEED , \n");
			sql.append("        PRTBIT_VALUE , \n");
			sql.append("        DATBIT_VALUE , \n");
			sql.append("        STOPBIT_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcEquipStngDVO tbmMcEquipStngDVO = (TbmMcEquipStngDVO)tbmMcEquipStngDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDarknessValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTroffposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTopposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtmcSpeed());
							ps.setString(psCount++, tbmMcEquipStngDVO.getScnnrPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getComnSpeed());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDatbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getStopbitValue());

						}
							public int getBatchSize() {
									return tbmMcEquipStngDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return int[]
*/
	@LocalName("updateBatchTbmMcEquipStng")
	public int[] updateBatchTbmMcEquipStng (final List tbmMcEquipStngDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.updateBatchTbmMcEquipStng.001*/  \n");
			sql.append(" TBM_MC_EQUIP_STNG \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_CTGR_CODE = ? , \n");
			sql.append("        PRTMC_CTGR_CODE = ? , \n");
			sql.append("        PRTMC_PORT_NO = ? , \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        DARKNESS_VALUE = ? , \n");
			sql.append("        TROFFPOS_VALUE = ? , \n");
			sql.append("        TOPPOS_VALUE = ? , \n");
			sql.append("        PRTMC_SPEED = ? , \n");
			sql.append("        SCNNR_PORT_NO = ? , \n");
			sql.append("        COMN_SPEED = ? , \n");
			sql.append("        PRTBIT_VALUE = ? , \n");
			sql.append("        DATBIT_VALUE = ? , \n");
			sql.append("        STOPBIT_VALUE = ? \n");
			sql.append(" WHERE IP = ? \n");
			sql.append("   AND PGM_CODE = ? \n");
			sql.append("   AND EQUIP_NO = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcEquipStngDVO tbmMcEquipStngDVO = (TbmMcEquipStngDVO)tbmMcEquipStngDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcCtgrCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPrtmcPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getxValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getyValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDarknessValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTroffposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getTopposValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtmcSpeed());
							ps.setString(psCount++, tbmMcEquipStngDVO.getScnnrPortNo());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getComnSpeed());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getPrtbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getDatbitValue());
							ps.setBigDecimal(psCount++, tbmMcEquipStngDVO.getStopbitValue());

							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
						}
							public int getBatchSize() {
									return tbmMcEquipStngDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcEquipStng Method
* 
* @ref_table TBM_MC_EQUIP_STNG
* @return int[]
*/
	@LocalName("deleteBatchTbmMcEquipStng")
	public int[] deleteBatchTbmMcEquipStng (final List tbmMcEquipStngDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcEquipStngDEM.deleteBatchTbmMcEquipStng.001*/  \n");
			sql.append(" TBM_MC_EQUIP_STNG \n");
			sql.append("  WHERE IP = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND EQUIP_NO = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcEquipStngDVO tbmMcEquipStngDVO = (TbmMcEquipStngDVO)tbmMcEquipStngDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcEquipStngDVO.getIp());
							ps.setString(psCount++, tbmMcEquipStngDVO.getPgmCode());
							ps.setString(psCount++, tbmMcEquipStngDVO.getEquipNo());
						}
							public int getBatchSize() {
									return tbmMcEquipStngDVOList.size();
							}
					}
		);			
	}

	
}