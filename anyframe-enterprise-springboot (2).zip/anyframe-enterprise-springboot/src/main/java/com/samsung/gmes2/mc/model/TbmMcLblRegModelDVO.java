package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * Reg Model에 대한 DEM
 * @author shim
 */
@LocalName("Reg Model에 대한 DEM")
public class TbmMcLblRegModelDVO extends AbstractVo {

	@Length(20) 
	private String modelCode;

	@Length(20) 
	private String labelId;

	@Length(5) @Scale(2) 
	private BigDecimal aplyLblVer;

	@Length(20) 
	private String divCode;

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String statusCode;

	@Length(20) 
	private String aprvId;

	@Length(50) 
	private String cfmerId;

	@Length(14) 
	private String cfmDt;

	@Length(1) 
	private String useYn;

	@Length(10) 
	private String reger;

	@Length(8) 
	private String regDt;

	@Length(50) 
	private String pviewImgFile;


	public String getModelCode() {
		this.modelCode = super.getValue(0);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(0, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue(1);
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue(1, labelId);
		this.labelId = labelId;
	}
	
	public BigDecimal getAplyLblVer() {
		this.aplyLblVer = super.getValue(2);
		return this.aplyLblVer;
	}

	public void setAplyLblVer(BigDecimal aplyLblVer) {
        super.setValue(2, aplyLblVer);
		this.aplyLblVer = aplyLblVer;
	}
	
	public String getDivCode() {
		this.divCode = super.getValue(3);
		return this.divCode;
	}

	public void setDivCode(String divCode) {
        super.setValue(3, divCode);
		this.divCode = divCode;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(4);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(4, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getStatusCode() {
		this.statusCode = super.getValue(5);
		return this.statusCode;
	}

	public void setStatusCode(String statusCode) {
        super.setValue(5, statusCode);
		this.statusCode = statusCode;
	}
	
	public String getAprvId() {
		this.aprvId = super.getValue(6);
		return this.aprvId;
	}

	public void setAprvId(String aprvId) {
        super.setValue(6, aprvId);
		this.aprvId = aprvId;
	}
	
	public String getCfmerId() {
		this.cfmerId = super.getValue(7);
		return this.cfmerId;
	}

	public void setCfmerId(String cfmerId) {
        super.setValue(7, cfmerId);
		this.cfmerId = cfmerId;
	}
	
	public String getCfmDt() {
		this.cfmDt = super.getValue(8);
		return this.cfmDt;
	}

	public void setCfmDt(String cfmDt) {
        super.setValue(8, cfmDt);
		this.cfmDt = cfmDt;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(9);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(9, useYn);
		this.useYn = useYn;
	}
	
	public String getReger() {
		this.reger = super.getValue(10);
		return this.reger;
	}

	public void setReger(String reger) {
        super.setValue(10, reger);
		this.reger = reger;
	}
	
	public String getRegDt() {
		this.regDt = super.getValue(11);
		return this.regDt;
	}

	public void setRegDt(String regDt) {
        super.setValue(11, regDt);
		this.regDt = regDt;
	}
	
	public String getPviewImgFile() {
		this.pviewImgFile = super.getValue(12);
		return this.pviewImgFile;
	}

	public void setPviewImgFile(String pviewImgFile) {
        super.setValue(12, pviewImgFile);
		this.pviewImgFile = pviewImgFile;
	}
	
}