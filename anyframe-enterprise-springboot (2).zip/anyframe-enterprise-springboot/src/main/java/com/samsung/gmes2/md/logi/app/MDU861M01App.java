package com.samsung.gmes2.md.logi.app;

public class MDU861M01App {

	/**
	 * 매거진 목록 초기설정
	 */
	public void initMag(){}

	/**
	 * 매거진 목록 조회
	 */
	public void listMag(){}

	/**
	 * 매거진 목록 엑셀 다운로드
	 */
	public void excelMsg(){}

	/**
	 * 매거진 목록 저장
	 */
	public void saveMsg(){}

}
