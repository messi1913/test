package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdLossDutyPicDVO extends AbstractVo {

	@Length(30) 
	private String corpCode;

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String lossDutyGrpCode;

	@Length(30) 
	private String lossDutyPartCode;

	@Length(50) 
	private String pidEmpNo;

	@Length(500) 
	private String lossDutyGrpNm;

	@Length(500) 
	private String lossDutyPartNm;

	@Length(500) 
	private String pidNm;

	@Length(2000) 
	private String lossDutyDesc;

	@Length(30) 
	private String dutyClsfCode;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getCorpCode() {
		this.corpCode = super.getValue(0);
		return this.corpCode;
	}

	public void setCorpCode(String corpCode) {
        super.setValue(0, corpCode);
		this.corpCode = corpCode;
	}
	
	public String getFctCode() {
		this.fctCode = super.getValue(1);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(1, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLossDutyGrpCode() {
		this.lossDutyGrpCode = super.getValue(2);
		return this.lossDutyGrpCode;
	}

	public void setLossDutyGrpCode(String lossDutyGrpCode) {
        super.setValue(2, lossDutyGrpCode);
		this.lossDutyGrpCode = lossDutyGrpCode;
	}
	
	public String getLossDutyPartCode() {
		this.lossDutyPartCode = super.getValue(3);
		return this.lossDutyPartCode;
	}

	public void setLossDutyPartCode(String lossDutyPartCode) {
        super.setValue(3, lossDutyPartCode);
		this.lossDutyPartCode = lossDutyPartCode;
	}
	
	public String getPidEmpNo() {
		this.pidEmpNo = super.getValue(4);
		return this.pidEmpNo;
	}

	public void setPidEmpNo(String pidEmpNo) {
        super.setValue(4, pidEmpNo);
		this.pidEmpNo = pidEmpNo;
	}
	
	public String getLossDutyGrpNm() {
		this.lossDutyGrpNm = super.getValue(5);
		return this.lossDutyGrpNm;
	}

	public void setLossDutyGrpNm(String lossDutyGrpNm) {
        super.setValue(5, lossDutyGrpNm);
		this.lossDutyGrpNm = lossDutyGrpNm;
	}
	
	public String getLossDutyPartNm() {
		this.lossDutyPartNm = super.getValue(6);
		return this.lossDutyPartNm;
	}

	public void setLossDutyPartNm(String lossDutyPartNm) {
        super.setValue(6, lossDutyPartNm);
		this.lossDutyPartNm = lossDutyPartNm;
	}
	
	public String getPidNm() {
		this.pidNm = super.getValue(7);
		return this.pidNm;
	}

	public void setPidNm(String pidNm) {
        super.setValue(7, pidNm);
		this.pidNm = pidNm;
	}
	
	public String getLossDutyDesc() {
		this.lossDutyDesc = super.getValue(8);
		return this.lossDutyDesc;
	}

	public void setLossDutyDesc(String lossDutyDesc) {
        super.setValue(8, lossDutyDesc);
		this.lossDutyDesc = lossDutyDesc;
	}
	
	public String getDutyClsfCode() {
		this.dutyClsfCode = super.getValue(9);
		return this.dutyClsfCode;
	}

	public void setDutyClsfCode(String dutyClsfCode) {
        super.setValue(9, dutyClsfCode);
		this.dutyClsfCode = dutyClsfCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(10);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(10, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(11);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(11, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(12);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(12, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(13);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(13, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(14);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(14, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}