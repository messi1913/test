package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_UNIT_PROC
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdUnitProcDEM extends AbstractDAO {


/**
* insertTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return int
*/
	@LocalName("insertTbcMdUnitProc")
	public int insertTbcMdUnitProc (final TbcMdUnitProcDVO tbcMdUnitProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.insertTbcMdUnitProc.001*/  \n");
			sql.append(" TBC_MD_UNIT_PROC (   \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        BASE_PROC_CODE , \n");
			sql.append("        UNIT_PROC_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getBaseProcCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcNm());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdUnitProc Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdUnitProc Method")
	public int[][] updateBatchAllTbcMdUnitProc (final List  tbcMdUnitProcDVOList) {
		
		ArrayList updatetbcMdUnitProcDVOList = new ArrayList();
		ArrayList insertttbcMdUnitProcDVOList = new ArrayList();
		ArrayList deletetbcMdUnitProcDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdUnitProcDVOList.size() ; i++) {
		  TbcMdUnitProcDVO tbcMdUnitProcDVO = (TbcMdUnitProcDVO) tbcMdUnitProcDVOList.get(i);
		  
		  if (tbcMdUnitProcDVO.getSqlAction().equals("C"))
		      insertttbcMdUnitProcDVOList.add(tbcMdUnitProcDVO);
		  else if (tbcMdUnitProcDVO.getSqlAction().equals("U"))
		      updatetbcMdUnitProcDVOList.add(tbcMdUnitProcDVO);
		  else if (tbcMdUnitProcDVO.getSqlAction().equals("D"))
		      deletetbcMdUnitProcDVOList.add(tbcMdUnitProcDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdUnitProcDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdUnitProc(insertttbcMdUnitProcDVOList);
          
      if (updatetbcMdUnitProcDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdUnitProc(updatetbcMdUnitProcDVOList);
      
      if (deletetbcMdUnitProcDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdUnitProc(deletetbcMdUnitProcDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return int
*/
	@LocalName("updateTbcMdUnitProc")
	public int updateTbcMdUnitProc (final TbcMdUnitProcDVO tbcMdUnitProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.updateTbcMdUnitProc.001*/  \n");
			sql.append(" TBC_MD_UNIT_PROC \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        PROC_TYPE_CODE = ? , \n");
			sql.append("        BASE_PROC_CODE = ? , \n");
			sql.append("        UNIT_PROC_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE UNIT_PROC_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdUnitProcDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getBaseProcCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcNm());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
						}
					}
		);			
	}

/**
* deleteTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return int
*/
	@LocalName("deleteTbcMdUnitProc")
	public int deleteTbcMdUnitProc (final TbcMdUnitProcDVO tbcMdUnitProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.deleteTbcMdUnitProc.001*/  \n");
			sql.append(" TBC_MD_UNIT_PROC \n");
			sql.append("  WHERE UNIT_PROC_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
						}
					}
		);			
	}

/**
* selectTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return TbcMdUnitProcDVO 
*/
	@LocalName("selectTbcMdUnitProc")
	public TbcMdUnitProcDVO selectTbcMdUnitProc (final TbcMdUnitProcDVO tbcMdUnitProcDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.selectTbcMdUnitProc.001*/  \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        BASE_PROC_CODE , \n");
			sql.append("        UNIT_PROC_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_UNIT_PROC \n");
			sql.append("  WHERE UNIT_PROC_CODE = ? \n");

		return (TbcMdUnitProcDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdUnitProcDVO returnTbcMdUnitProcDVO = new TbcMdUnitProcDVO();
									returnTbcMdUnitProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbcMdUnitProcDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdUnitProcDVO.setProcTypeCode(resultSet.getString("PROC_TYPE_CODE"));
									returnTbcMdUnitProcDVO.setBaseProcCode(resultSet.getString("BASE_PROC_CODE"));
									returnTbcMdUnitProcDVO.setUnitProcNm(resultSet.getString("UNIT_PROC_NM"));
									returnTbcMdUnitProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdUnitProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdUnitProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdUnitProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdUnitProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdUnitProcDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdUnitProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdUnitProc Method")
	public int mergeTbcMdUnitProc (final TbcMdUnitProcDVO tbcMdUnitProcDVO) {
		
		if ( selectTbcMdUnitProc (tbcMdUnitProcDVO) == null) {
			return insertTbcMdUnitProc(tbcMdUnitProcDVO);
		} else {
			return selectUpdateTbcMdUnitProc (tbcMdUnitProcDVO);
		}
	}

	/**
	 * selectUpdateTbcMdUnitProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdUnitProc Method")
	public int selectUpdateTbcMdUnitProc (final TbcMdUnitProcDVO tbcMdUnitProcDVO) {
		
		TbcMdUnitProcDVO tmpTbcMdUnitProcDVO =  selectTbcMdUnitProc (tbcMdUnitProcDVO);
		if ( tbcMdUnitProcDVO.getUnitProcCode() != null && !"".equals(tbcMdUnitProcDVO.getUnitProcCode()) ) {
			tmpTbcMdUnitProcDVO.setUnitProcCode(tbcMdUnitProcDVO.getUnitProcCode());
		}		
		if ( tbcMdUnitProcDVO.getProcGubunCode() != null && !"".equals(tbcMdUnitProcDVO.getProcGubunCode()) ) {
			tmpTbcMdUnitProcDVO.setProcGubunCode(tbcMdUnitProcDVO.getProcGubunCode());
		}		
		if ( tbcMdUnitProcDVO.getProcTypeCode() != null && !"".equals(tbcMdUnitProcDVO.getProcTypeCode()) ) {
			tmpTbcMdUnitProcDVO.setProcTypeCode(tbcMdUnitProcDVO.getProcTypeCode());
		}		
		if ( tbcMdUnitProcDVO.getBaseProcCode() != null && !"".equals(tbcMdUnitProcDVO.getBaseProcCode()) ) {
			tmpTbcMdUnitProcDVO.setBaseProcCode(tbcMdUnitProcDVO.getBaseProcCode());
		}		
		if ( tbcMdUnitProcDVO.getUnitProcNm() != null && !"".equals(tbcMdUnitProcDVO.getUnitProcNm()) ) {
			tmpTbcMdUnitProcDVO.setUnitProcNm(tbcMdUnitProcDVO.getUnitProcNm());
		}		
		if ( tbcMdUnitProcDVO.getUseYn() != null && !"".equals(tbcMdUnitProcDVO.getUseYn()) ) {
			tmpTbcMdUnitProcDVO.setUseYn(tbcMdUnitProcDVO.getUseYn());
		}		
		if ( tbcMdUnitProcDVO.getFstRegDt() != null && !"".equals(tbcMdUnitProcDVO.getFstRegDt()) ) {
			tmpTbcMdUnitProcDVO.setFstRegDt(tbcMdUnitProcDVO.getFstRegDt());
		}		
		if ( tbcMdUnitProcDVO.getFstRegerId() != null && !"".equals(tbcMdUnitProcDVO.getFstRegerId()) ) {
			tmpTbcMdUnitProcDVO.setFstRegerId(tbcMdUnitProcDVO.getFstRegerId());
		}		
		if ( tbcMdUnitProcDVO.getFnlUpdDt() != null && !"".equals(tbcMdUnitProcDVO.getFnlUpdDt()) ) {
			tmpTbcMdUnitProcDVO.setFnlUpdDt(tbcMdUnitProcDVO.getFnlUpdDt());
		}		
		if ( tbcMdUnitProcDVO.getFnlUpderId() != null && !"".equals(tbcMdUnitProcDVO.getFnlUpderId()) ) {
			tmpTbcMdUnitProcDVO.setFnlUpderId(tbcMdUnitProcDVO.getFnlUpderId());
		}		
		return updateTbcMdUnitProc (tmpTbcMdUnitProcDVO);
	}

/**
* insertBatchTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return int[]
*/
	@LocalName("insertBatchTbcMdUnitProc")
	public int[] insertBatchTbcMdUnitProc (final List tbcMdUnitProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.insertBatchTbcMdUnitProc.001*/  \n");
			sql.append(" TBC_MD_UNIT_PROC (   \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_TYPE_CODE , \n");
			sql.append("        BASE_PROC_CODE , \n");
			sql.append("        UNIT_PROC_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdUnitProcDVO tbcMdUnitProcDVO = (TbcMdUnitProcDVO)tbcMdUnitProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getBaseProcCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcNm());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdUnitProcDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return int[]
*/
	@LocalName("updateBatchTbcMdUnitProc")
	public int[] updateBatchTbcMdUnitProc (final List tbcMdUnitProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.updateBatchTbcMdUnitProc.001*/  \n");
			sql.append(" TBC_MD_UNIT_PROC \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        PROC_TYPE_CODE = ? , \n");
			sql.append("        BASE_PROC_CODE = ? , \n");
			sql.append("        UNIT_PROC_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE UNIT_PROC_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdUnitProcDVO tbcMdUnitProcDVO = (TbcMdUnitProcDVO)tbcMdUnitProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdUnitProcDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getProcTypeCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getBaseProcCode());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcNm());
							ps.setString(psCount++, tbcMdUnitProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdUnitProcDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
						}
							public int getBatchSize() {
									return tbcMdUnitProcDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdUnitProc Method
* 
* @ref_table TBC_MD_UNIT_PROC
* @return int[]
*/
	@LocalName("deleteBatchTbcMdUnitProc")
	public int[] deleteBatchTbcMdUnitProc (final List tbcMdUnitProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdUnitProcDEM.deleteBatchTbcMdUnitProc.001*/  \n");
			sql.append(" TBC_MD_UNIT_PROC \n");
			sql.append("  WHERE UNIT_PROC_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdUnitProcDVO tbcMdUnitProcDVO = (TbcMdUnitProcDVO)tbcMdUnitProcDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdUnitProcDVO.getUnitProcCode());
						}
							public int getBatchSize() {
									return tbcMdUnitProcDVOList.size();
							}
					}
		);			
	}

	
}