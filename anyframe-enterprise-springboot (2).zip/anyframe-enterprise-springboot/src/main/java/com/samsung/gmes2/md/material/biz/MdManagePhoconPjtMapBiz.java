package com.samsung.gmes2.md.material.biz;

public class MdManagePhoconPjtMapBiz {

	/**
	 * 현상기Project매핑 목록 조회
	 */
	public void listPhoconPjtMap(){}

	/**
	 * 현상기 모델코드 리스트 조회(Combo용)
	 */
	public void listPhoconModel(){}

	/**
	 * 현상기Project매핑 목록 저장
	 */
	public void savePhoconPjtMap(){}

}
