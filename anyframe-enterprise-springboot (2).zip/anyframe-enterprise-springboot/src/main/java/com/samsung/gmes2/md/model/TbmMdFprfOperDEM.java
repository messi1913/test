package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_FPRF_OPER
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdFprfOperDEM extends AbstractDAO {


/**
* insertTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return int
*/
	@LocalName("insertTbmMdFprfOper")
	public int insertTbmMdFprfOper (final TbmMdFprfOperDVO tbmMdFprfOperDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.insertTbmMdFprfOper.001*/  \n");
			sql.append(" TBM_MD_FPRF_OPER (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        BCR_PORT_VALUE , \n");
			sql.append("        FPRF_PORT_DESC , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FPRF_APLY_ART_CODE , \n");
			sql.append("        APLY_LOC_CODE , \n");
			sql.append("        INP_ACRS_SUMR_YN , \n");
			sql.append("        OUT_ACRS_SUMR_YN , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfPortDesc());
							ps.setString(psCount++, tbmMdFprfOperDVO.getCorpCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyArtCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getAplyLocCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getInpAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getOutAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUseYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdFprfOper Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdFprfOper Method")
	public int[][] updateBatchAllTbmMdFprfOper (final List  tbmMdFprfOperDVOList) {
		
		ArrayList updatetbmMdFprfOperDVOList = new ArrayList();
		ArrayList insertttbmMdFprfOperDVOList = new ArrayList();
		ArrayList deletetbmMdFprfOperDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdFprfOperDVOList.size() ; i++) {
		  TbmMdFprfOperDVO tbmMdFprfOperDVO = (TbmMdFprfOperDVO) tbmMdFprfOperDVOList.get(i);
		  
		  if (tbmMdFprfOperDVO.getSqlAction().equals("C"))
		      insertttbmMdFprfOperDVOList.add(tbmMdFprfOperDVO);
		  else if (tbmMdFprfOperDVO.getSqlAction().equals("U"))
		      updatetbmMdFprfOperDVOList.add(tbmMdFprfOperDVO);
		  else if (tbmMdFprfOperDVO.getSqlAction().equals("D"))
		      deletetbmMdFprfOperDVOList.add(tbmMdFprfOperDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdFprfOperDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdFprfOper(insertttbmMdFprfOperDVOList);
          
      if (updatetbmMdFprfOperDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdFprfOper(updatetbmMdFprfOperDVOList);
      
      if (deletetbmMdFprfOperDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdFprfOper(deletetbmMdFprfOperDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return int
*/
	@LocalName("updateTbmMdFprfOper")
	public int updateTbmMdFprfOper (final TbmMdFprfOperDVO tbmMdFprfOperDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.updateTbmMdFprfOper.001*/  \n");
			sql.append(" TBM_MD_FPRF_OPER \n");
			sql.append(" SET   \n");
			sql.append("        FPRF_PORT_DESC = ? , \n");
			sql.append("        CORP_CODE = ? , \n");
			sql.append("        FPRF_APLY_ART_CODE = ? , \n");
			sql.append("        APLY_LOC_CODE = ? , \n");
			sql.append("        INP_ACRS_SUMR_YN = ? , \n");
			sql.append("        OUT_ACRS_SUMR_YN = ? , \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND BCR_PORT_VALUE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfPortDesc());
							ps.setString(psCount++, tbmMdFprfOperDVO.getCorpCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyArtCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getAplyLocCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getInpAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getOutAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUseYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
						}
					}
		);			
	}

/**
* deleteTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return int
*/
	@LocalName("deleteTbmMdFprfOper")
	public int deleteTbmMdFprfOper (final TbmMdFprfOperDVO tbmMdFprfOperDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.deleteTbmMdFprfOper.001*/  \n");
			sql.append(" TBM_MD_FPRF_OPER \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND BCR_PORT_VALUE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
						}
					}
		);			
	}

/**
* selectTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return TbmMdFprfOperDVO 
*/
	@LocalName("selectTbmMdFprfOper")
	public TbmMdFprfOperDVO selectTbmMdFprfOper (final TbmMdFprfOperDVO tbmMdFprfOperDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.selectTbmMdFprfOper.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        BCR_PORT_VALUE , \n");
			sql.append("        FPRF_PORT_DESC , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FPRF_APLY_ART_CODE , \n");
			sql.append("        APLY_LOC_CODE , \n");
			sql.append("        INP_ACRS_SUMR_YN , \n");
			sql.append("        OUT_ACRS_SUMR_YN , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_FPRF_OPER \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND BCR_PORT_VALUE = ? \n");

		return (TbmMdFprfOperDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdFprfOperDVO returnTbmMdFprfOperDVO = new TbmMdFprfOperDVO();
									returnTbmMdFprfOperDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdFprfOperDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdFprfOperDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdFprfOperDVO.setBcrPortValue(resultSet.getString("BCR_PORT_VALUE"));
									returnTbmMdFprfOperDVO.setFprfPortDesc(resultSet.getString("FPRF_PORT_DESC"));
									returnTbmMdFprfOperDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMdFprfOperDVO.setFprfAplyArtCode(resultSet.getString("FPRF_APLY_ART_CODE"));
									returnTbmMdFprfOperDVO.setAplyLocCode(resultSet.getString("APLY_LOC_CODE"));
									returnTbmMdFprfOperDVO.setInpAcrsSumrYn(resultSet.getString("INP_ACRS_SUMR_YN"));
									returnTbmMdFprfOperDVO.setOutAcrsSumrYn(resultSet.getString("OUT_ACRS_SUMR_YN"));
									returnTbmMdFprfOperDVO.setFprfAplyYn(resultSet.getString("FPRF_APLY_YN"));
									returnTbmMdFprfOperDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdFprfOperDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdFprfOperDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdFprfOperDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdFprfOperDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdFprfOperDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdFprfOper Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdFprfOper Method")
	public int mergeTbmMdFprfOper (final TbmMdFprfOperDVO tbmMdFprfOperDVO) {
		
		if ( selectTbmMdFprfOper (tbmMdFprfOperDVO) == null) {
			return insertTbmMdFprfOper(tbmMdFprfOperDVO);
		} else {
			return selectUpdateTbmMdFprfOper (tbmMdFprfOperDVO);
		}
	}

	/**
	 * selectUpdateTbmMdFprfOper Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdFprfOper Method")
	public int selectUpdateTbmMdFprfOper (final TbmMdFprfOperDVO tbmMdFprfOperDVO) {
		
		TbmMdFprfOperDVO tmpTbmMdFprfOperDVO =  selectTbmMdFprfOper (tbmMdFprfOperDVO);
		if ( tbmMdFprfOperDVO.getFctCode() != null && !"".equals(tbmMdFprfOperDVO.getFctCode()) ) {
			tmpTbmMdFprfOperDVO.setFctCode(tbmMdFprfOperDVO.getFctCode());
		}		
		if ( tbmMdFprfOperDVO.getLineCode() != null && !"".equals(tbmMdFprfOperDVO.getLineCode()) ) {
			tmpTbmMdFprfOperDVO.setLineCode(tbmMdFprfOperDVO.getLineCode());
		}		
		if ( tbmMdFprfOperDVO.getUnitProcCode() != null && !"".equals(tbmMdFprfOperDVO.getUnitProcCode()) ) {
			tmpTbmMdFprfOperDVO.setUnitProcCode(tbmMdFprfOperDVO.getUnitProcCode());
		}		
		if ( tbmMdFprfOperDVO.getBcrPortValue() != null && !"".equals(tbmMdFprfOperDVO.getBcrPortValue()) ) {
			tmpTbmMdFprfOperDVO.setBcrPortValue(tbmMdFprfOperDVO.getBcrPortValue());
		}		
		if ( tbmMdFprfOperDVO.getFprfPortDesc() != null && !"".equals(tbmMdFprfOperDVO.getFprfPortDesc()) ) {
			tmpTbmMdFprfOperDVO.setFprfPortDesc(tbmMdFprfOperDVO.getFprfPortDesc());
		}		
		if ( tbmMdFprfOperDVO.getCorpCode() != null && !"".equals(tbmMdFprfOperDVO.getCorpCode()) ) {
			tmpTbmMdFprfOperDVO.setCorpCode(tbmMdFprfOperDVO.getCorpCode());
		}		
		if ( tbmMdFprfOperDVO.getFprfAplyArtCode() != null && !"".equals(tbmMdFprfOperDVO.getFprfAplyArtCode()) ) {
			tmpTbmMdFprfOperDVO.setFprfAplyArtCode(tbmMdFprfOperDVO.getFprfAplyArtCode());
		}		
		if ( tbmMdFprfOperDVO.getAplyLocCode() != null && !"".equals(tbmMdFprfOperDVO.getAplyLocCode()) ) {
			tmpTbmMdFprfOperDVO.setAplyLocCode(tbmMdFprfOperDVO.getAplyLocCode());
		}		
		if ( tbmMdFprfOperDVO.getInpAcrsSumrYn() != null && !"".equals(tbmMdFprfOperDVO.getInpAcrsSumrYn()) ) {
			tmpTbmMdFprfOperDVO.setInpAcrsSumrYn(tbmMdFprfOperDVO.getInpAcrsSumrYn());
		}		
		if ( tbmMdFprfOperDVO.getOutAcrsSumrYn() != null && !"".equals(tbmMdFprfOperDVO.getOutAcrsSumrYn()) ) {
			tmpTbmMdFprfOperDVO.setOutAcrsSumrYn(tbmMdFprfOperDVO.getOutAcrsSumrYn());
		}		
		if ( tbmMdFprfOperDVO.getFprfAplyYn() != null && !"".equals(tbmMdFprfOperDVO.getFprfAplyYn()) ) {
			tmpTbmMdFprfOperDVO.setFprfAplyYn(tbmMdFprfOperDVO.getFprfAplyYn());
		}		
		if ( tbmMdFprfOperDVO.getUseYn() != null && !"".equals(tbmMdFprfOperDVO.getUseYn()) ) {
			tmpTbmMdFprfOperDVO.setUseYn(tbmMdFprfOperDVO.getUseYn());
		}		
		if ( tbmMdFprfOperDVO.getFstRegDt() != null && !"".equals(tbmMdFprfOperDVO.getFstRegDt()) ) {
			tmpTbmMdFprfOperDVO.setFstRegDt(tbmMdFprfOperDVO.getFstRegDt());
		}		
		if ( tbmMdFprfOperDVO.getFstRegerId() != null && !"".equals(tbmMdFprfOperDVO.getFstRegerId()) ) {
			tmpTbmMdFprfOperDVO.setFstRegerId(tbmMdFprfOperDVO.getFstRegerId());
		}		
		if ( tbmMdFprfOperDVO.getFnlUpdDt() != null && !"".equals(tbmMdFprfOperDVO.getFnlUpdDt()) ) {
			tmpTbmMdFprfOperDVO.setFnlUpdDt(tbmMdFprfOperDVO.getFnlUpdDt());
		}		
		if ( tbmMdFprfOperDVO.getFnlUpderId() != null && !"".equals(tbmMdFprfOperDVO.getFnlUpderId()) ) {
			tmpTbmMdFprfOperDVO.setFnlUpderId(tbmMdFprfOperDVO.getFnlUpderId());
		}		
		return updateTbmMdFprfOper (tmpTbmMdFprfOperDVO);
	}

/**
* insertBatchTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return int[]
*/
	@LocalName("insertBatchTbmMdFprfOper")
	public int[] insertBatchTbmMdFprfOper (final List tbmMdFprfOperDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.insertBatchTbmMdFprfOper.001*/  \n");
			sql.append(" TBM_MD_FPRF_OPER (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        BCR_PORT_VALUE , \n");
			sql.append("        FPRF_PORT_DESC , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FPRF_APLY_ART_CODE , \n");
			sql.append("        APLY_LOC_CODE , \n");
			sql.append("        INP_ACRS_SUMR_YN , \n");
			sql.append("        OUT_ACRS_SUMR_YN , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdFprfOperDVO tbmMdFprfOperDVO = (TbmMdFprfOperDVO)tbmMdFprfOperDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfPortDesc());
							ps.setString(psCount++, tbmMdFprfOperDVO.getCorpCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyArtCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getAplyLocCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getInpAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getOutAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUseYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdFprfOperDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return int[]
*/
	@LocalName("updateBatchTbmMdFprfOper")
	public int[] updateBatchTbmMdFprfOper (final List tbmMdFprfOperDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.updateBatchTbmMdFprfOper.001*/  \n");
			sql.append(" TBM_MD_FPRF_OPER \n");
			sql.append(" SET   \n");
			sql.append("        FPRF_PORT_DESC = ? , \n");
			sql.append("        CORP_CODE = ? , \n");
			sql.append("        FPRF_APLY_ART_CODE = ? , \n");
			sql.append("        APLY_LOC_CODE = ? , \n");
			sql.append("        INP_ACRS_SUMR_YN = ? , \n");
			sql.append("        OUT_ACRS_SUMR_YN = ? , \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND BCR_PORT_VALUE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdFprfOperDVO tbmMdFprfOperDVO = (TbmMdFprfOperDVO)tbmMdFprfOperDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfPortDesc());
							ps.setString(psCount++, tbmMdFprfOperDVO.getCorpCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyArtCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getAplyLocCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getInpAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getOutAcrsSumrYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUseYn());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFprfOperDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
						}
							public int getBatchSize() {
									return tbmMdFprfOperDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdFprfOper Method
* 
* @ref_table TBM_MD_FPRF_OPER
* @return int[]
*/
	@LocalName("deleteBatchTbmMdFprfOper")
	public int[] deleteBatchTbmMdFprfOper (final List tbmMdFprfOperDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdFprfOperDEM.deleteBatchTbmMdFprfOper.001*/  \n");
			sql.append(" TBM_MD_FPRF_OPER \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND BCR_PORT_VALUE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdFprfOperDVO tbmMdFprfOperDVO = (TbmMdFprfOperDVO)tbmMdFprfOperDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdFprfOperDVO.getFctCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getLineCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdFprfOperDVO.getBcrPortValue());
						}
							public int getBatchSize() {
									return tbmMdFprfOperDVOList.size();
							}
					}
		);			
	}

	
}