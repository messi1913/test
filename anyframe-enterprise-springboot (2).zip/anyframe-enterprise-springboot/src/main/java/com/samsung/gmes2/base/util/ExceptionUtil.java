package com.samsung.gmes2.base.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import com.samsung.gmes2.exception.Gmes2BugException;
import com.samsung.gmes2.exception.Gmes2Exception;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.exception.Property;

public class ExceptionUtil
{
	public static Gmes2Exception populate( Gmes2Exception e )
	{
		if ( e == null )
			return e;

		Exception orgE = e;

		String code = e.getCode( );
		if ( BaseUtil.isEmpty( code ) )
		{
			e = new Gmes2BugException( "Error Code is empty.", e );
			code = e.getCode( );
		}

		String userMessage = null;
		try
		{
			userMessage = BaseUtil.getMessage( code );
			if ( BaseUtil.isEqual( userMessage, code ) )
				userMessage = BaseUtil.toString( e.getMessage( ), userMessage );
		}
		catch ( Exception e1 )
		{
		}

		StringBuffer msgBuf = new StringBuffer( );
		msgBuf.append( "code: " ).append( code );
		if ( BaseUtil.isNotEmpty( userMessage ) )
			msgBuf.append( "\r\nuserMessage: " ).append( userMessage );
		if ( BaseUtil.isNotEmpty( orgE.getMessage( ) ) )
			msgBuf.append( "\r\nmessage: " ).append( orgE.getMessage( ) );

		StringBuffer detailBuf = new StringBuffer( );
		List<Property> propList = orgE instanceof Gmes2LogicException ? ( (Gmes2LogicException) orgE ).getProperty( ) : null;
		if ( BaseUtil.isEmpty( propList ) )
		{
			detailBuf.append( toStackTraceString( orgE ) );
		}
		else
		{
			int i = 0;
			for ( Property prop : propList )
			{
				try
				{
					detailBuf.append( i++ == 0 ? "" : "\r\n" ).append( BaseUtil.getMessage( prop.getName( ) ) );
					detailBuf.append( ": " ).append( prop.getValue( ) );
				}
				catch ( Exception e1 )
				{
				}
			}
			msgBuf.append( "\r\n" ).append( detailBuf );
		}

		e.setMessage( msgBuf.toString( ) );
		e.setUserMessage( userMessage );
		e.setDetailMessage( detailBuf.toString( ) );

		return e;
	}

	private static String toStackTraceString( Exception e )
	{
		StringWriter w = new StringWriter( );
		e.printStackTrace( new PrintWriter( w ) );
		return w.toString( );
	}
}
