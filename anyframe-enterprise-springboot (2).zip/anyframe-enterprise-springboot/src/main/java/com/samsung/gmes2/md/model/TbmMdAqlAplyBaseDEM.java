package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_AQL_APLY_BASE
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdAqlAplyBaseDEM extends AbstractDAO {


/**
* insertTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return int
*/
	@LocalName("insertTbmMdAqlAplyBase")
	public int insertTbmMdAqlAplyBase (final TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.insertTbmMdAqlAplyBase.001*/  \n");
			sql.append(" TBM_MD_AQL_APLY_BASE (   \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        INSP_GUBUN_CODE , \n");
			sql.append("        SMPL_CHAR_CODE , \n");
			sql.append("        AQL_BASE_CODE , \n");
			sql.append("        SMPL_NUM , \n");
			sql.append("        PASS_NUM , \n");
			sql.append("        FAIL_NUM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getAqlBaseCode());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getSmplNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getPassNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getFailNum());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdAqlAplyBase Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdAqlAplyBase Method")
	public int[][] updateBatchAllTbmMdAqlAplyBase (final List  tbmMdAqlAplyBaseDVOList) {
		
		ArrayList updatetbmMdAqlAplyBaseDVOList = new ArrayList();
		ArrayList insertttbmMdAqlAplyBaseDVOList = new ArrayList();
		ArrayList deletetbmMdAqlAplyBaseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdAqlAplyBaseDVOList.size() ; i++) {
		  TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO = (TbmMdAqlAplyBaseDVO) tbmMdAqlAplyBaseDVOList.get(i);
		  
		  if (tbmMdAqlAplyBaseDVO.getSqlAction().equals("C"))
		      insertttbmMdAqlAplyBaseDVOList.add(tbmMdAqlAplyBaseDVO);
		  else if (tbmMdAqlAplyBaseDVO.getSqlAction().equals("U"))
		      updatetbmMdAqlAplyBaseDVOList.add(tbmMdAqlAplyBaseDVO);
		  else if (tbmMdAqlAplyBaseDVO.getSqlAction().equals("D"))
		      deletetbmMdAqlAplyBaseDVOList.add(tbmMdAqlAplyBaseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdAqlAplyBaseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdAqlAplyBase(insertttbmMdAqlAplyBaseDVOList);
          
      if (updatetbmMdAqlAplyBaseDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdAqlAplyBase(updatetbmMdAqlAplyBaseDVOList);
      
      if (deletetbmMdAqlAplyBaseDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdAqlAplyBase(deletetbmMdAqlAplyBaseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return int
*/
	@LocalName("updateTbmMdAqlAplyBase")
	public int updateTbmMdAqlAplyBase (final TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.updateTbmMdAqlAplyBase.001*/  \n");
			sql.append(" TBM_MD_AQL_APLY_BASE \n");
			sql.append(" SET   \n");
			sql.append("        AQL_BASE_CODE = ? , \n");
			sql.append("        SMPL_NUM = ? , \n");
			sql.append("        PASS_NUM = ? , \n");
			sql.append("        FAIL_NUM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_GRP_CODE = ? \n");
			sql.append("   AND PROD_ABBR_CODE = ? \n");
			sql.append("   AND INSP_GUBUN_CODE = ? \n");
			sql.append("   AND SMPL_CHAR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getAqlBaseCode());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getSmplNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getPassNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getFailNum());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
						}
					}
		);			
	}

/**
* deleteTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return int
*/
	@LocalName("deleteTbmMdAqlAplyBase")
	public int deleteTbmMdAqlAplyBase (final TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.deleteTbmMdAqlAplyBase.001*/  \n");
			sql.append(" TBM_MD_AQL_APLY_BASE \n");
			sql.append("  WHERE PROD_GRP_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND INSP_GUBUN_CODE = ? \n");
			sql.append("    AND SMPL_CHAR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
						}
					}
		);			
	}

/**
* selectTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return TbmMdAqlAplyBaseDVO 
*/
	@LocalName("selectTbmMdAqlAplyBase")
	public TbmMdAqlAplyBaseDVO selectTbmMdAqlAplyBase (final TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.selectTbmMdAqlAplyBase.001*/  \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        INSP_GUBUN_CODE , \n");
			sql.append("        SMPL_CHAR_CODE , \n");
			sql.append("        AQL_BASE_CODE , \n");
			sql.append("        SMPL_NUM , \n");
			sql.append("        PASS_NUM , \n");
			sql.append("        FAIL_NUM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_AQL_APLY_BASE \n");
			sql.append("  WHERE PROD_GRP_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND INSP_GUBUN_CODE = ? \n");
			sql.append("    AND SMPL_CHAR_CODE = ? \n");

		return (TbmMdAqlAplyBaseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdAqlAplyBaseDVO returnTbmMdAqlAplyBaseDVO = new TbmMdAqlAplyBaseDVO();
									returnTbmMdAqlAplyBaseDVO.setProdGrpCode(resultSet.getString("PROD_GRP_CODE"));
									returnTbmMdAqlAplyBaseDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbmMdAqlAplyBaseDVO.setInspGubunCode(resultSet.getString("INSP_GUBUN_CODE"));
									returnTbmMdAqlAplyBaseDVO.setSmplCharCode(resultSet.getString("SMPL_CHAR_CODE"));
									returnTbmMdAqlAplyBaseDVO.setAqlBaseCode(resultSet.getString("AQL_BASE_CODE"));
									returnTbmMdAqlAplyBaseDVO.setSmplNum(resultSet.getBigDecimal("SMPL_NUM"));
									returnTbmMdAqlAplyBaseDVO.setPassNum(resultSet.getBigDecimal("PASS_NUM"));
									returnTbmMdAqlAplyBaseDVO.setFailNum(resultSet.getBigDecimal("FAIL_NUM"));
									returnTbmMdAqlAplyBaseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdAqlAplyBaseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdAqlAplyBaseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdAqlAplyBaseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdAqlAplyBaseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdAqlAplyBaseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdAqlAplyBase Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdAqlAplyBase Method")
	public int mergeTbmMdAqlAplyBase (final TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO) {
		
		if ( selectTbmMdAqlAplyBase (tbmMdAqlAplyBaseDVO) == null) {
			return insertTbmMdAqlAplyBase(tbmMdAqlAplyBaseDVO);
		} else {
			return selectUpdateTbmMdAqlAplyBase (tbmMdAqlAplyBaseDVO);
		}
	}

	/**
	 * selectUpdateTbmMdAqlAplyBase Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdAqlAplyBase Method")
	public int selectUpdateTbmMdAqlAplyBase (final TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO) {
		
		TbmMdAqlAplyBaseDVO tmpTbmMdAqlAplyBaseDVO =  selectTbmMdAqlAplyBase (tbmMdAqlAplyBaseDVO);
		if ( tbmMdAqlAplyBaseDVO.getProdGrpCode() != null && !"".equals(tbmMdAqlAplyBaseDVO.getProdGrpCode()) ) {
			tmpTbmMdAqlAplyBaseDVO.setProdGrpCode(tbmMdAqlAplyBaseDVO.getProdGrpCode());
		}		
		if ( tbmMdAqlAplyBaseDVO.getProdAbbrCode() != null && !"".equals(tbmMdAqlAplyBaseDVO.getProdAbbrCode()) ) {
			tmpTbmMdAqlAplyBaseDVO.setProdAbbrCode(tbmMdAqlAplyBaseDVO.getProdAbbrCode());
		}		
		if ( tbmMdAqlAplyBaseDVO.getInspGubunCode() != null && !"".equals(tbmMdAqlAplyBaseDVO.getInspGubunCode()) ) {
			tmpTbmMdAqlAplyBaseDVO.setInspGubunCode(tbmMdAqlAplyBaseDVO.getInspGubunCode());
		}		
		if ( tbmMdAqlAplyBaseDVO.getSmplCharCode() != null && !"".equals(tbmMdAqlAplyBaseDVO.getSmplCharCode()) ) {
			tmpTbmMdAqlAplyBaseDVO.setSmplCharCode(tbmMdAqlAplyBaseDVO.getSmplCharCode());
		}		
		if ( tbmMdAqlAplyBaseDVO.getAqlBaseCode() != null && !"".equals(tbmMdAqlAplyBaseDVO.getAqlBaseCode()) ) {
			tmpTbmMdAqlAplyBaseDVO.setAqlBaseCode(tbmMdAqlAplyBaseDVO.getAqlBaseCode());
		}		
		if ( tbmMdAqlAplyBaseDVO.getSmplNum() != null && !"".equals(tbmMdAqlAplyBaseDVO.getSmplNum()) ) {
			tmpTbmMdAqlAplyBaseDVO.setSmplNum(tbmMdAqlAplyBaseDVO.getSmplNum());
		}		
		if ( tbmMdAqlAplyBaseDVO.getPassNum() != null && !"".equals(tbmMdAqlAplyBaseDVO.getPassNum()) ) {
			tmpTbmMdAqlAplyBaseDVO.setPassNum(tbmMdAqlAplyBaseDVO.getPassNum());
		}		
		if ( tbmMdAqlAplyBaseDVO.getFailNum() != null && !"".equals(tbmMdAqlAplyBaseDVO.getFailNum()) ) {
			tmpTbmMdAqlAplyBaseDVO.setFailNum(tbmMdAqlAplyBaseDVO.getFailNum());
		}		
		if ( tbmMdAqlAplyBaseDVO.getUseYn() != null && !"".equals(tbmMdAqlAplyBaseDVO.getUseYn()) ) {
			tmpTbmMdAqlAplyBaseDVO.setUseYn(tbmMdAqlAplyBaseDVO.getUseYn());
		}		
		if ( tbmMdAqlAplyBaseDVO.getFstRegDt() != null && !"".equals(tbmMdAqlAplyBaseDVO.getFstRegDt()) ) {
			tmpTbmMdAqlAplyBaseDVO.setFstRegDt(tbmMdAqlAplyBaseDVO.getFstRegDt());
		}		
		if ( tbmMdAqlAplyBaseDVO.getFstRegerId() != null && !"".equals(tbmMdAqlAplyBaseDVO.getFstRegerId()) ) {
			tmpTbmMdAqlAplyBaseDVO.setFstRegerId(tbmMdAqlAplyBaseDVO.getFstRegerId());
		}		
		if ( tbmMdAqlAplyBaseDVO.getFnlUpdDt() != null && !"".equals(tbmMdAqlAplyBaseDVO.getFnlUpdDt()) ) {
			tmpTbmMdAqlAplyBaseDVO.setFnlUpdDt(tbmMdAqlAplyBaseDVO.getFnlUpdDt());
		}		
		if ( tbmMdAqlAplyBaseDVO.getFnlUpderId() != null && !"".equals(tbmMdAqlAplyBaseDVO.getFnlUpderId()) ) {
			tmpTbmMdAqlAplyBaseDVO.setFnlUpderId(tbmMdAqlAplyBaseDVO.getFnlUpderId());
		}		
		return updateTbmMdAqlAplyBase (tmpTbmMdAqlAplyBaseDVO);
	}

/**
* insertBatchTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return int[]
*/
	@LocalName("insertBatchTbmMdAqlAplyBase")
	public int[] insertBatchTbmMdAqlAplyBase (final List tbmMdAqlAplyBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.insertBatchTbmMdAqlAplyBase.001*/  \n");
			sql.append(" TBM_MD_AQL_APLY_BASE (   \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        INSP_GUBUN_CODE , \n");
			sql.append("        SMPL_CHAR_CODE , \n");
			sql.append("        AQL_BASE_CODE , \n");
			sql.append("        SMPL_NUM , \n");
			sql.append("        PASS_NUM , \n");
			sql.append("        FAIL_NUM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO = (TbmMdAqlAplyBaseDVO)tbmMdAqlAplyBaseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getAqlBaseCode());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getSmplNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getPassNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getFailNum());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdAqlAplyBaseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return int[]
*/
	@LocalName("updateBatchTbmMdAqlAplyBase")
	public int[] updateBatchTbmMdAqlAplyBase (final List tbmMdAqlAplyBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.updateBatchTbmMdAqlAplyBase.001*/  \n");
			sql.append(" TBM_MD_AQL_APLY_BASE \n");
			sql.append(" SET   \n");
			sql.append("        AQL_BASE_CODE = ? , \n");
			sql.append("        SMPL_NUM = ? , \n");
			sql.append("        PASS_NUM = ? , \n");
			sql.append("        FAIL_NUM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_GRP_CODE = ? \n");
			sql.append("   AND PROD_ABBR_CODE = ? \n");
			sql.append("   AND INSP_GUBUN_CODE = ? \n");
			sql.append("   AND SMPL_CHAR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO = (TbmMdAqlAplyBaseDVO)tbmMdAqlAplyBaseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getAqlBaseCode());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getSmplNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getPassNum());
							ps.setBigDecimal(psCount++, tbmMdAqlAplyBaseDVO.getFailNum());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getUseYn());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
						}
							public int getBatchSize() {
									return tbmMdAqlAplyBaseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdAqlAplyBase Method
* 
* @ref_table TBM_MD_AQL_APLY_BASE
* @return int[]
*/
	@LocalName("deleteBatchTbmMdAqlAplyBase")
	public int[] deleteBatchTbmMdAqlAplyBase (final List tbmMdAqlAplyBaseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdAqlAplyBaseDEM.deleteBatchTbmMdAqlAplyBase.001*/  \n");
			sql.append(" TBM_MD_AQL_APLY_BASE \n");
			sql.append("  WHERE PROD_GRP_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND INSP_GUBUN_CODE = ? \n");
			sql.append("    AND SMPL_CHAR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAqlAplyBaseDVO tbmMdAqlAplyBaseDVO = (TbmMdAqlAplyBaseDVO)tbmMdAqlAplyBaseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getInspGubunCode());
							ps.setString(psCount++, tbmMdAqlAplyBaseDVO.getSmplCharCode());
						}
							public int getBatchSize() {
									return tbmMdAqlAplyBaseDVOList.size();
							}
					}
		);			
	}

	
}