package com.samsung.gmes2.bi.edu.chris.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * ...l
 * @stereotype DAOVO
 * @author Chris
 */
@LocalName("직원나이DVO")
public class EmpAgeDVO extends AbstractDVO {

	@LocalName("직원나이") @Length(3) 
	private String empAge;


	/**
	 * 직원나이 Getter Method
	 * 
	 * @return 직원나이
	 */
	@LocalName("직원나이 Getter Method")
	public String getEmpAge() {
		this.empAge = super.getValue("empAge");
		return this.empAge;
	}

	/**
	 * 직원나이 Setter Method
	 * 
	 * @param String 직원나이
	 */
	@LocalName("직원나이 Setter Method")
	public void setEmpAge(String empAge) {
        super.setValue("empAge", empAge);
		this.empAge = empAge;
	}
	
}