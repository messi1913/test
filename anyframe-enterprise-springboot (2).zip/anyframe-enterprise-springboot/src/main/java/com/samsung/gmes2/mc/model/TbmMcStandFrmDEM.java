package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_STAND_FRM
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcStandFrmDEM extends AbstractDAO {


/**
* insertTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return int
*/
	@LocalName("insertTbmMcStandFrm")
	public int insertTbmMcStandFrm (final TbmMcStandFrmDVO tbmMcStandFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.insertTbmMcStandFrm.001*/  \n");
			sql.append(" TBM_MC_STAND_FRM (   \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        FRM_CTGR_CODE , \n");
			sql.append("        FRM_NM , \n");
			sql.append("        FRM_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmCtgrCode());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmNm());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmDesc());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcStandFrm Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcStandFrm Method")
	public int[][] updateBatchAllTbmMcStandFrm (final List  tbmMcStandFrmDVOList) {
		
		ArrayList updatetbmMcStandFrmDVOList = new ArrayList();
		ArrayList insertttbmMcStandFrmDVOList = new ArrayList();
		ArrayList deletetbmMcStandFrmDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcStandFrmDVOList.size() ; i++) {
		  TbmMcStandFrmDVO tbmMcStandFrmDVO = (TbmMcStandFrmDVO) tbmMcStandFrmDVOList.get(i);
		  
		  if (tbmMcStandFrmDVO.getSqlAction().equals("C"))
		      insertttbmMcStandFrmDVOList.add(tbmMcStandFrmDVO);
		  else if (tbmMcStandFrmDVO.getSqlAction().equals("U"))
		      updatetbmMcStandFrmDVOList.add(tbmMcStandFrmDVO);
		  else if (tbmMcStandFrmDVO.getSqlAction().equals("D"))
		      deletetbmMcStandFrmDVOList.add(tbmMcStandFrmDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcStandFrmDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcStandFrm(insertttbmMcStandFrmDVOList);
          
      if (updatetbmMcStandFrmDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcStandFrm(updatetbmMcStandFrmDVOList);
      
      if (deletetbmMcStandFrmDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcStandFrm(deletetbmMcStandFrmDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return int
*/
	@LocalName("updateTbmMcStandFrm")
	public int updateTbmMcStandFrm (final TbmMcStandFrmDVO tbmMcStandFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.updateTbmMcStandFrm.001*/  \n");
			sql.append(" TBM_MC_STAND_FRM \n");
			sql.append(" SET   \n");
			sql.append("        FRM_CTGR_CODE = ? , \n");
			sql.append("        FRM_NM = ? , \n");
			sql.append("        FRM_DESC = ? \n");
			sql.append(" WHERE STAND_FRM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmCtgrCode());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmNm());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmDesc());

							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
						}
					}
		);			
	}

/**
* deleteTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return int
*/
	@LocalName("deleteTbmMcStandFrm")
	public int deleteTbmMcStandFrm (final TbmMcStandFrmDVO tbmMcStandFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.deleteTbmMcStandFrm.001*/  \n");
			sql.append(" TBM_MC_STAND_FRM \n");
			sql.append("  WHERE STAND_FRM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
						}
					}
		);			
	}

/**
* selectTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return TbmMcStandFrmDVO 
*/
	@LocalName("selectTbmMcStandFrm")
	public TbmMcStandFrmDVO selectTbmMcStandFrm (final TbmMcStandFrmDVO tbmMcStandFrmDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.selectTbmMcStandFrm.001*/  \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        FRM_CTGR_CODE , \n");
			sql.append("        FRM_NM , \n");
			sql.append("        FRM_DESC \n");
			sql.append("   FROM TBM_MC_STAND_FRM \n");
			sql.append("  WHERE STAND_FRM_CODE = ? \n");

		return (TbmMcStandFrmDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcStandFrmDVO returnTbmMcStandFrmDVO = new TbmMcStandFrmDVO();
									returnTbmMcStandFrmDVO.setStandFrmCode(resultSet.getString("STAND_FRM_CODE"));
									returnTbmMcStandFrmDVO.setFrmCtgrCode(resultSet.getString("FRM_CTGR_CODE"));
									returnTbmMcStandFrmDVO.setFrmNm(resultSet.getString("FRM_NM"));
									returnTbmMcStandFrmDVO.setFrmDesc(resultSet.getString("FRM_DESC"));
									return returnTbmMcStandFrmDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcStandFrm Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcStandFrm Method")
	public int mergeTbmMcStandFrm (final TbmMcStandFrmDVO tbmMcStandFrmDVO) {
		
		if ( selectTbmMcStandFrm (tbmMcStandFrmDVO) == null) {
			return insertTbmMcStandFrm(tbmMcStandFrmDVO);
		} else {
			return selectUpdateTbmMcStandFrm (tbmMcStandFrmDVO);
		}
	}

	/**
	 * selectUpdateTbmMcStandFrm Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcStandFrm Method")
	public int selectUpdateTbmMcStandFrm (final TbmMcStandFrmDVO tbmMcStandFrmDVO) {
		
		TbmMcStandFrmDVO tmpTbmMcStandFrmDVO =  selectTbmMcStandFrm (tbmMcStandFrmDVO);
		if ( tbmMcStandFrmDVO.getStandFrmCode() != null && !"".equals(tbmMcStandFrmDVO.getStandFrmCode()) ) {
			tmpTbmMcStandFrmDVO.setStandFrmCode(tbmMcStandFrmDVO.getStandFrmCode());
		}		
		if ( tbmMcStandFrmDVO.getFrmCtgrCode() != null && !"".equals(tbmMcStandFrmDVO.getFrmCtgrCode()) ) {
			tmpTbmMcStandFrmDVO.setFrmCtgrCode(tbmMcStandFrmDVO.getFrmCtgrCode());
		}		
		if ( tbmMcStandFrmDVO.getFrmNm() != null && !"".equals(tbmMcStandFrmDVO.getFrmNm()) ) {
			tmpTbmMcStandFrmDVO.setFrmNm(tbmMcStandFrmDVO.getFrmNm());
		}		
		if ( tbmMcStandFrmDVO.getFrmDesc() != null && !"".equals(tbmMcStandFrmDVO.getFrmDesc()) ) {
			tmpTbmMcStandFrmDVO.setFrmDesc(tbmMcStandFrmDVO.getFrmDesc());
		}		
		return updateTbmMcStandFrm (tmpTbmMcStandFrmDVO);
	}

/**
* insertBatchTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return int[]
*/
	@LocalName("insertBatchTbmMcStandFrm")
	public int[] insertBatchTbmMcStandFrm (final List tbmMcStandFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.insertBatchTbmMcStandFrm.001*/  \n");
			sql.append(" TBM_MC_STAND_FRM (   \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        FRM_CTGR_CODE , \n");
			sql.append("        FRM_NM , \n");
			sql.append("        FRM_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcStandFrmDVO tbmMcStandFrmDVO = (TbmMcStandFrmDVO)tbmMcStandFrmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmCtgrCode());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmNm());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmDesc());

						}
							public int getBatchSize() {
									return tbmMcStandFrmDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return int[]
*/
	@LocalName("updateBatchTbmMcStandFrm")
	public int[] updateBatchTbmMcStandFrm (final List tbmMcStandFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.updateBatchTbmMcStandFrm.001*/  \n");
			sql.append(" TBM_MC_STAND_FRM \n");
			sql.append(" SET   \n");
			sql.append("        FRM_CTGR_CODE = ? , \n");
			sql.append("        FRM_NM = ? , \n");
			sql.append("        FRM_DESC = ? \n");
			sql.append(" WHERE STAND_FRM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcStandFrmDVO tbmMcStandFrmDVO = (TbmMcStandFrmDVO)tbmMcStandFrmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmCtgrCode());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmNm());
							ps.setString(psCount++, tbmMcStandFrmDVO.getFrmDesc());

							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
						}
							public int getBatchSize() {
									return tbmMcStandFrmDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcStandFrm Method
* 
* @ref_table TBM_MC_STAND_FRM
* @return int[]
*/
	@LocalName("deleteBatchTbmMcStandFrm")
	public int[] deleteBatchTbmMcStandFrm (final List tbmMcStandFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcStandFrmDEM.deleteBatchTbmMcStandFrm.001*/  \n");
			sql.append(" TBM_MC_STAND_FRM \n");
			sql.append("  WHERE STAND_FRM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcStandFrmDVO tbmMcStandFrmDVO = (TbmMcStandFrmDVO)tbmMcStandFrmDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcStandFrmDVO.getStandFrmCode());
						}
							public int getBatchSize() {
									return tbmMcStandFrmDVOList.size();
							}
					}
		);			
	}

	
}