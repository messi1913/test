package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdDaiDiffCauseDVO extends AbstractVo {

	@Length(30) 
	private String daiDiffCauseCode;

	@Length(500) 
	private String daiDiffCauseNm;

	@Length(2000) 
	private String daiDiffCauseDesc;

	@Length(1) 
	private String prtyReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getDaiDiffCauseCode() {
		this.daiDiffCauseCode = super.getValue(0);
		return this.daiDiffCauseCode;
	}

	public void setDaiDiffCauseCode(String daiDiffCauseCode) {
        super.setValue(0, daiDiffCauseCode);
		this.daiDiffCauseCode = daiDiffCauseCode;
	}
	
	public String getDaiDiffCauseNm() {
		this.daiDiffCauseNm = super.getValue(1);
		return this.daiDiffCauseNm;
	}

	public void setDaiDiffCauseNm(String daiDiffCauseNm) {
        super.setValue(1, daiDiffCauseNm);
		this.daiDiffCauseNm = daiDiffCauseNm;
	}
	
	public String getDaiDiffCauseDesc() {
		this.daiDiffCauseDesc = super.getValue(2);
		return this.daiDiffCauseDesc;
	}

	public void setDaiDiffCauseDesc(String daiDiffCauseDesc) {
        super.setValue(2, daiDiffCauseDesc);
		this.daiDiffCauseDesc = daiDiffCauseDesc;
	}
	
	public String getPrtyReflYn() {
		this.prtyReflYn = super.getValue(3);
		return this.prtyReflYn;
	}

	public void setPrtyReflYn(String prtyReflYn) {
        super.setValue(3, prtyReflYn);
		this.prtyReflYn = prtyReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(4);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(4, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(5);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(5, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(6);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(6, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(7);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(7, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(8);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(8, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}