package com.samsung.gmes2.base.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 클래스 설명.
 * @stereotype DAOVO
 * @author myjung
 */
@LocalName("xxx 클래스")
public class LongDVO extends AbstractDVO {

	
	private BigDecimal value;


	public BigDecimal getValue() {
		this.value = super.getValue("value");
		return this.value;
	}

	public void setValue(BigDecimal value) {
        super.setValue("value", value);
		this.value = value;
	}
	
}