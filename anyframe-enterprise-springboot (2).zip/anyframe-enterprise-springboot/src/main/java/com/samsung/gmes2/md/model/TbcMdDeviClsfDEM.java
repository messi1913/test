package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEVI_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeviClsfDEM extends AbstractDAO {


/**
* insertTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return int
*/
	@LocalName("insertTbcMdDeviClsf")
	public int insertTbcMdDeviClsf (final TbcMdDeviClsfDVO tbcMdDeviClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.insertTbcMdDeviClsf.001*/  \n");
			sql.append(" TBC_MD_DEVI_CLSF (   \n");
			sql.append("        DEVI_CLSF_CODE , \n");
			sql.append("        DEVI_CLSF_DESC , \n");
			sql.append("        DEVI_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfDesc());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviGubunCode());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeviClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeviClsf Method")
	public int[][] updateBatchAllTbcMdDeviClsf (final List  tbcMdDeviClsfDVOList) {
		
		ArrayList updatetbcMdDeviClsfDVOList = new ArrayList();
		ArrayList insertttbcMdDeviClsfDVOList = new ArrayList();
		ArrayList deletetbcMdDeviClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeviClsfDVOList.size() ; i++) {
		  TbcMdDeviClsfDVO tbcMdDeviClsfDVO = (TbcMdDeviClsfDVO) tbcMdDeviClsfDVOList.get(i);
		  
		  if (tbcMdDeviClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdDeviClsfDVOList.add(tbcMdDeviClsfDVO);
		  else if (tbcMdDeviClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdDeviClsfDVOList.add(tbcMdDeviClsfDVO);
		  else if (tbcMdDeviClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdDeviClsfDVOList.add(tbcMdDeviClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeviClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeviClsf(insertttbcMdDeviClsfDVOList);
          
      if (updatetbcMdDeviClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeviClsf(updatetbcMdDeviClsfDVOList);
      
      if (deletetbcMdDeviClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeviClsf(deletetbcMdDeviClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return int
*/
	@LocalName("updateTbcMdDeviClsf")
	public int updateTbcMdDeviClsf (final TbcMdDeviClsfDVO tbcMdDeviClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.updateTbcMdDeviClsf.001*/  \n");
			sql.append(" TBC_MD_DEVI_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        DEVI_CLSF_DESC = ? , \n");
			sql.append("        DEVI_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEVI_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfDesc());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviGubunCode());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return int
*/
	@LocalName("deleteTbcMdDeviClsf")
	public int deleteTbcMdDeviClsf (final TbcMdDeviClsfDVO tbcMdDeviClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.deleteTbcMdDeviClsf.001*/  \n");
			sql.append(" TBC_MD_DEVI_CLSF \n");
			sql.append("  WHERE DEVI_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return TbcMdDeviClsfDVO 
*/
	@LocalName("selectTbcMdDeviClsf")
	public TbcMdDeviClsfDVO selectTbcMdDeviClsf (final TbcMdDeviClsfDVO tbcMdDeviClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.selectTbcMdDeviClsf.001*/  \n");
			sql.append("        DEVI_CLSF_CODE , \n");
			sql.append("        DEVI_CLSF_DESC , \n");
			sql.append("        DEVI_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEVI_CLSF \n");
			sql.append("  WHERE DEVI_CLSF_CODE = ? \n");

		return (TbcMdDeviClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeviClsfDVO returnTbcMdDeviClsfDVO = new TbcMdDeviClsfDVO();
									returnTbcMdDeviClsfDVO.setDeviClsfCode(resultSet.getString("DEVI_CLSF_CODE"));
									returnTbcMdDeviClsfDVO.setDeviClsfDesc(resultSet.getString("DEVI_CLSF_DESC"));
									returnTbcMdDeviClsfDVO.setDeviGubunCode(resultSet.getString("DEVI_GUBUN_CODE"));
									returnTbcMdDeviClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeviClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeviClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeviClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeviClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeviClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeviClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeviClsf Method")
	public int mergeTbcMdDeviClsf (final TbcMdDeviClsfDVO tbcMdDeviClsfDVO) {
		
		if ( selectTbcMdDeviClsf (tbcMdDeviClsfDVO) == null) {
			return insertTbcMdDeviClsf(tbcMdDeviClsfDVO);
		} else {
			return selectUpdateTbcMdDeviClsf (tbcMdDeviClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeviClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeviClsf Method")
	public int selectUpdateTbcMdDeviClsf (final TbcMdDeviClsfDVO tbcMdDeviClsfDVO) {
		
		TbcMdDeviClsfDVO tmpTbcMdDeviClsfDVO =  selectTbcMdDeviClsf (tbcMdDeviClsfDVO);
		if ( tbcMdDeviClsfDVO.getDeviClsfCode() != null && !"".equals(tbcMdDeviClsfDVO.getDeviClsfCode()) ) {
			tmpTbcMdDeviClsfDVO.setDeviClsfCode(tbcMdDeviClsfDVO.getDeviClsfCode());
		}		
		if ( tbcMdDeviClsfDVO.getDeviClsfDesc() != null && !"".equals(tbcMdDeviClsfDVO.getDeviClsfDesc()) ) {
			tmpTbcMdDeviClsfDVO.setDeviClsfDesc(tbcMdDeviClsfDVO.getDeviClsfDesc());
		}		
		if ( tbcMdDeviClsfDVO.getDeviGubunCode() != null && !"".equals(tbcMdDeviClsfDVO.getDeviGubunCode()) ) {
			tmpTbcMdDeviClsfDVO.setDeviGubunCode(tbcMdDeviClsfDVO.getDeviGubunCode());
		}		
		if ( tbcMdDeviClsfDVO.getUseYn() != null && !"".equals(tbcMdDeviClsfDVO.getUseYn()) ) {
			tmpTbcMdDeviClsfDVO.setUseYn(tbcMdDeviClsfDVO.getUseYn());
		}		
		if ( tbcMdDeviClsfDVO.getFstRegDt() != null && !"".equals(tbcMdDeviClsfDVO.getFstRegDt()) ) {
			tmpTbcMdDeviClsfDVO.setFstRegDt(tbcMdDeviClsfDVO.getFstRegDt());
		}		
		if ( tbcMdDeviClsfDVO.getFstRegerId() != null && !"".equals(tbcMdDeviClsfDVO.getFstRegerId()) ) {
			tmpTbcMdDeviClsfDVO.setFstRegerId(tbcMdDeviClsfDVO.getFstRegerId());
		}		
		if ( tbcMdDeviClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeviClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeviClsfDVO.setFnlUpdDt(tbcMdDeviClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeviClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdDeviClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdDeviClsfDVO.setFnlUpderId(tbcMdDeviClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdDeviClsf (tmpTbcMdDeviClsfDVO);
	}

/**
* insertBatchTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeviClsf")
	public int[] insertBatchTbcMdDeviClsf (final List tbcMdDeviClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.insertBatchTbcMdDeviClsf.001*/  \n");
			sql.append(" TBC_MD_DEVI_CLSF (   \n");
			sql.append("        DEVI_CLSF_CODE , \n");
			sql.append("        DEVI_CLSF_DESC , \n");
			sql.append("        DEVI_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeviClsfDVO tbcMdDeviClsfDVO = (TbcMdDeviClsfDVO)tbcMdDeviClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfDesc());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviGubunCode());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeviClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeviClsf")
	public int[] updateBatchTbcMdDeviClsf (final List tbcMdDeviClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.updateBatchTbcMdDeviClsf.001*/  \n");
			sql.append(" TBC_MD_DEVI_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        DEVI_CLSF_DESC = ? , \n");
			sql.append("        DEVI_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEVI_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeviClsfDVO tbcMdDeviClsfDVO = (TbcMdDeviClsfDVO)tbcMdDeviClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfDesc());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviGubunCode());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeviClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDeviClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeviClsf Method
* 
* @ref_table TBC_MD_DEVI_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeviClsf")
	public int[] deleteBatchTbcMdDeviClsf (final List tbcMdDeviClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeviClsfDEM.deleteBatchTbcMdDeviClsf.001*/  \n");
			sql.append(" TBC_MD_DEVI_CLSF \n");
			sql.append("  WHERE DEVI_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeviClsfDVO tbcMdDeviClsfDVO = (TbcMdDeviClsfDVO)tbcMdDeviClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeviClsfDVO.getDeviClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDeviClsfDVOList.size();
							}
					}
		);			
	}

	
}