package com.samsung.gmes2.md.logi.biz;

public class MdManageBuyerInfoBiz {

	/**
	 * Buyer 목록 조회
	 */
	public void listBuyerInfo(){}

	/**
	 * Buyer 목록 저장
	 */
	public void saveBuyerInfo(){}

}
