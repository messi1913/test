package com.samsung.gmes2.md.cmm.biz;

public class MdQualBaseBiz {

	/**
	 * 검사분류 리스트
	 */
	public void listInspClsfBase(){}

	/**
	 * 검사항목 리스트
	 */
	public void listInspArtBase(){}

	/**
	 * 검사세부항목 리스트
	 */
	public void listInspArtDtlBase(){}

	/**
	 * 불량증상분류 리스트
	 */
	public void listDeftSympClsfBase(){}

	/**
	 * Audit항목분류 리스트
	 */
	public void listAuditEstiClsfBase(){}

	/**
	 * E/W Rule ID 리스트
	 */
	public void listEwRuleIdBase(){}

}
