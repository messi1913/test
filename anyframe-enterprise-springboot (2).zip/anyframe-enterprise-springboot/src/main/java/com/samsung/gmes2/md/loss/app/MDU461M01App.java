package com.samsung.gmes2.md.loss.app;

public class MDU461M01App {

	/**
	 * 근태차이원인 목록 초기설정
	 */
	public void initDaiDiffCauseInfo(){}

	/**
	 * 근태차이원인 목록 조회
	 */
	public void listDaiDiffCauseInfo(){}

	/**
	 * 근태차이원인 목록 엑셀 다운로드
	 */
	public void excelDaiDiffCauseInfo(){}

	/**
	 * 근태차이원인 목록 저장
	 */
	public void saveDaiDiffCauseInfo(){}

}
