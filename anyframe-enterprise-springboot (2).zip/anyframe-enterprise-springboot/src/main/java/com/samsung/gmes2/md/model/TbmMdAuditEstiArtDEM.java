package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdAuditEstiArtDEM extends AbstractDAO {


/**
* insertTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return int
*/
	@LocalName("insertTbmMdAuditEstiArt")
	public int insertTbmMdAuditEstiArt (final TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.insertTbmMdAuditEstiArt.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_ART (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        ESTI_CLSF_CODE , \n");
			sql.append("        ESTI_ART_CODE , \n");
			sql.append("        ESTI_ART_NM , \n");
			sql.append("        ASGN_POINT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtNm());
							ps.setBigDecimal(psCount++, tbmMdAuditEstiArtDVO.getAsgnPoint());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdAuditEstiArt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdAuditEstiArt Method")
	public int[][] updateBatchAllTbmMdAuditEstiArt (final List  tbmMdAuditEstiArtDVOList) {
		
		ArrayList updatetbmMdAuditEstiArtDVOList = new ArrayList();
		ArrayList insertttbmMdAuditEstiArtDVOList = new ArrayList();
		ArrayList deletetbmMdAuditEstiArtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdAuditEstiArtDVOList.size() ; i++) {
		  TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO = (TbmMdAuditEstiArtDVO) tbmMdAuditEstiArtDVOList.get(i);
		  
		  if (tbmMdAuditEstiArtDVO.getSqlAction().equals("C"))
		      insertttbmMdAuditEstiArtDVOList.add(tbmMdAuditEstiArtDVO);
		  else if (tbmMdAuditEstiArtDVO.getSqlAction().equals("U"))
		      updatetbmMdAuditEstiArtDVOList.add(tbmMdAuditEstiArtDVO);
		  else if (tbmMdAuditEstiArtDVO.getSqlAction().equals("D"))
		      deletetbmMdAuditEstiArtDVOList.add(tbmMdAuditEstiArtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdAuditEstiArtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdAuditEstiArt(insertttbmMdAuditEstiArtDVOList);
          
      if (updatetbmMdAuditEstiArtDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdAuditEstiArt(updatetbmMdAuditEstiArtDVOList);
      
      if (deletetbmMdAuditEstiArtDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdAuditEstiArt(deletetbmMdAuditEstiArtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return int
*/
	@LocalName("updateTbmMdAuditEstiArt")
	public int updateTbmMdAuditEstiArt (final TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.updateTbmMdAuditEstiArt.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_ART \n");
			sql.append(" SET   \n");
			sql.append("        ESTI_ART_NM = ? , \n");
			sql.append("        ASGN_POINT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND PROC_GUBUN_CODE = ? \n");
			sql.append("   AND ESTI_CLSF_CODE = ? \n");
			sql.append("   AND ESTI_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtNm());
							ps.setBigDecimal(psCount++, tbmMdAuditEstiArtDVO.getAsgnPoint());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
						}
					}
		);			
	}

/**
* deleteTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return int
*/
	@LocalName("deleteTbmMdAuditEstiArt")
	public int deleteTbmMdAuditEstiArt (final TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.deleteTbmMdAuditEstiArt.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_ART \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND PROC_GUBUN_CODE = ? \n");
			sql.append("    AND ESTI_CLSF_CODE = ? \n");
			sql.append("    AND ESTI_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
						}
					}
		);			
	}

/**
* selectTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return TbmMdAuditEstiArtDVO 
*/
	@LocalName("selectTbmMdAuditEstiArt")
	public TbmMdAuditEstiArtDVO selectTbmMdAuditEstiArt (final TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.selectTbmMdAuditEstiArt.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        ESTI_CLSF_CODE , \n");
			sql.append("        ESTI_ART_CODE , \n");
			sql.append("        ESTI_ART_NM , \n");
			sql.append("        ASGN_POINT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_AUDIT_ESTI_ART \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND PROC_GUBUN_CODE = ? \n");
			sql.append("    AND ESTI_CLSF_CODE = ? \n");
			sql.append("    AND ESTI_ART_CODE = ? \n");

		return (TbmMdAuditEstiArtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdAuditEstiArtDVO returnTbmMdAuditEstiArtDVO = new TbmMdAuditEstiArtDVO();
									returnTbmMdAuditEstiArtDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdAuditEstiArtDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdAuditEstiArtDVO.setEstiClsfCode(resultSet.getString("ESTI_CLSF_CODE"));
									returnTbmMdAuditEstiArtDVO.setEstiArtCode(resultSet.getString("ESTI_ART_CODE"));
									returnTbmMdAuditEstiArtDVO.setEstiArtNm(resultSet.getString("ESTI_ART_NM"));
									returnTbmMdAuditEstiArtDVO.setAsgnPoint(resultSet.getBigDecimal("ASGN_POINT"));
									returnTbmMdAuditEstiArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdAuditEstiArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdAuditEstiArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdAuditEstiArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdAuditEstiArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdAuditEstiArtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdAuditEstiArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdAuditEstiArt Method")
	public int mergeTbmMdAuditEstiArt (final TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO) {
		
		if ( selectTbmMdAuditEstiArt (tbmMdAuditEstiArtDVO) == null) {
			return insertTbmMdAuditEstiArt(tbmMdAuditEstiArtDVO);
		} else {
			return selectUpdateTbmMdAuditEstiArt (tbmMdAuditEstiArtDVO);
		}
	}

	/**
	 * selectUpdateTbmMdAuditEstiArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdAuditEstiArt Method")
	public int selectUpdateTbmMdAuditEstiArt (final TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO) {
		
		TbmMdAuditEstiArtDVO tmpTbmMdAuditEstiArtDVO =  selectTbmMdAuditEstiArt (tbmMdAuditEstiArtDVO);
		if ( tbmMdAuditEstiArtDVO.getGbmCode() != null && !"".equals(tbmMdAuditEstiArtDVO.getGbmCode()) ) {
			tmpTbmMdAuditEstiArtDVO.setGbmCode(tbmMdAuditEstiArtDVO.getGbmCode());
		}		
		if ( tbmMdAuditEstiArtDVO.getProcGubunCode() != null && !"".equals(tbmMdAuditEstiArtDVO.getProcGubunCode()) ) {
			tmpTbmMdAuditEstiArtDVO.setProcGubunCode(tbmMdAuditEstiArtDVO.getProcGubunCode());
		}		
		if ( tbmMdAuditEstiArtDVO.getEstiClsfCode() != null && !"".equals(tbmMdAuditEstiArtDVO.getEstiClsfCode()) ) {
			tmpTbmMdAuditEstiArtDVO.setEstiClsfCode(tbmMdAuditEstiArtDVO.getEstiClsfCode());
		}		
		if ( tbmMdAuditEstiArtDVO.getEstiArtCode() != null && !"".equals(tbmMdAuditEstiArtDVO.getEstiArtCode()) ) {
			tmpTbmMdAuditEstiArtDVO.setEstiArtCode(tbmMdAuditEstiArtDVO.getEstiArtCode());
		}		
		if ( tbmMdAuditEstiArtDVO.getEstiArtNm() != null && !"".equals(tbmMdAuditEstiArtDVO.getEstiArtNm()) ) {
			tmpTbmMdAuditEstiArtDVO.setEstiArtNm(tbmMdAuditEstiArtDVO.getEstiArtNm());
		}		
		if ( tbmMdAuditEstiArtDVO.getAsgnPoint() != null && !"".equals(tbmMdAuditEstiArtDVO.getAsgnPoint()) ) {
			tmpTbmMdAuditEstiArtDVO.setAsgnPoint(tbmMdAuditEstiArtDVO.getAsgnPoint());
		}		
		if ( tbmMdAuditEstiArtDVO.getUseYn() != null && !"".equals(tbmMdAuditEstiArtDVO.getUseYn()) ) {
			tmpTbmMdAuditEstiArtDVO.setUseYn(tbmMdAuditEstiArtDVO.getUseYn());
		}		
		if ( tbmMdAuditEstiArtDVO.getFstRegDt() != null && !"".equals(tbmMdAuditEstiArtDVO.getFstRegDt()) ) {
			tmpTbmMdAuditEstiArtDVO.setFstRegDt(tbmMdAuditEstiArtDVO.getFstRegDt());
		}		
		if ( tbmMdAuditEstiArtDVO.getFstRegerId() != null && !"".equals(tbmMdAuditEstiArtDVO.getFstRegerId()) ) {
			tmpTbmMdAuditEstiArtDVO.setFstRegerId(tbmMdAuditEstiArtDVO.getFstRegerId());
		}		
		if ( tbmMdAuditEstiArtDVO.getFnlUpdDt() != null && !"".equals(tbmMdAuditEstiArtDVO.getFnlUpdDt()) ) {
			tmpTbmMdAuditEstiArtDVO.setFnlUpdDt(tbmMdAuditEstiArtDVO.getFnlUpdDt());
		}		
		if ( tbmMdAuditEstiArtDVO.getFnlUpderId() != null && !"".equals(tbmMdAuditEstiArtDVO.getFnlUpderId()) ) {
			tmpTbmMdAuditEstiArtDVO.setFnlUpderId(tbmMdAuditEstiArtDVO.getFnlUpderId());
		}		
		return updateTbmMdAuditEstiArt (tmpTbmMdAuditEstiArtDVO);
	}

/**
* insertBatchTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return int[]
*/
	@LocalName("insertBatchTbmMdAuditEstiArt")
	public int[] insertBatchTbmMdAuditEstiArt (final List tbmMdAuditEstiArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.insertBatchTbmMdAuditEstiArt.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_ART (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        ESTI_CLSF_CODE , \n");
			sql.append("        ESTI_ART_CODE , \n");
			sql.append("        ESTI_ART_NM , \n");
			sql.append("        ASGN_POINT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO = (TbmMdAuditEstiArtDVO)tbmMdAuditEstiArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtNm());
							ps.setBigDecimal(psCount++, tbmMdAuditEstiArtDVO.getAsgnPoint());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdAuditEstiArtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return int[]
*/
	@LocalName("updateBatchTbmMdAuditEstiArt")
	public int[] updateBatchTbmMdAuditEstiArt (final List tbmMdAuditEstiArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.updateBatchTbmMdAuditEstiArt.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_ART \n");
			sql.append(" SET   \n");
			sql.append("        ESTI_ART_NM = ? , \n");
			sql.append("        ASGN_POINT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND PROC_GUBUN_CODE = ? \n");
			sql.append("   AND ESTI_CLSF_CODE = ? \n");
			sql.append("   AND ESTI_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO = (TbmMdAuditEstiArtDVO)tbmMdAuditEstiArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtNm());
							ps.setBigDecimal(psCount++, tbmMdAuditEstiArtDVO.getAsgnPoint());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
						}
							public int getBatchSize() {
									return tbmMdAuditEstiArtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdAuditEstiArt Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_ART
* @return int[]
*/
	@LocalName("deleteBatchTbmMdAuditEstiArt")
	public int[] deleteBatchTbmMdAuditEstiArt (final List tbmMdAuditEstiArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdAuditEstiArtDEM.deleteBatchTbmMdAuditEstiArt.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_ART \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND PROC_GUBUN_CODE = ? \n");
			sql.append("    AND ESTI_CLSF_CODE = ? \n");
			sql.append("    AND ESTI_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAuditEstiArtDVO tbmMdAuditEstiArtDVO = (TbmMdAuditEstiArtDVO)tbmMdAuditEstiArtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiArtDVO.getEstiArtCode());
						}
							public int getBatchSize() {
									return tbmMdAuditEstiArtDVOList.size();
							}
					}
		);			
	}

	
}