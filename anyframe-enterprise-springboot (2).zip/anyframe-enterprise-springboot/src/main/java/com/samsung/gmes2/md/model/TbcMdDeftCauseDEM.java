package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEFT_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeftCauseDEM extends AbstractDAO {


/**
* insertTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return int
*/
	@LocalName("insertTbcMdDeftCause")
	public int insertTbcMdDeftCause (final TbcMdDeftCauseDVO tbcMdDeftCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.insertTbcMdDeftCause.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE (   \n");
			sql.append("        DEFT_CAUSE_CODE , \n");
			sql.append("        DEFT_CAUSE_NM , \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseNm());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseClsfCode());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeftCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeftCause Method")
	public int[][] updateBatchAllTbcMdDeftCause (final List  tbcMdDeftCauseDVOList) {
		
		ArrayList updatetbcMdDeftCauseDVOList = new ArrayList();
		ArrayList insertttbcMdDeftCauseDVOList = new ArrayList();
		ArrayList deletetbcMdDeftCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeftCauseDVOList.size() ; i++) {
		  TbcMdDeftCauseDVO tbcMdDeftCauseDVO = (TbcMdDeftCauseDVO) tbcMdDeftCauseDVOList.get(i);
		  
		  if (tbcMdDeftCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdDeftCauseDVOList.add(tbcMdDeftCauseDVO);
		  else if (tbcMdDeftCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdDeftCauseDVOList.add(tbcMdDeftCauseDVO);
		  else if (tbcMdDeftCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdDeftCauseDVOList.add(tbcMdDeftCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeftCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeftCause(insertttbcMdDeftCauseDVOList);
          
      if (updatetbcMdDeftCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeftCause(updatetbcMdDeftCauseDVOList);
      
      if (deletetbcMdDeftCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeftCause(deletetbcMdDeftCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return int
*/
	@LocalName("updateTbcMdDeftCause")
	public int updateTbcMdDeftCause (final TbcMdDeftCauseDVO tbcMdDeftCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.updateTbcMdDeftCause.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_CAUSE_NM = ? , \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseNm());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseClsfCode());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdDeftCause")
	public int deleteTbcMdDeftCause (final TbcMdDeftCauseDVO tbcMdDeftCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.deleteTbcMdDeftCause.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE \n");
			sql.append("  WHERE DEFT_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return TbcMdDeftCauseDVO 
*/
	@LocalName("selectTbcMdDeftCause")
	public TbcMdDeftCauseDVO selectTbcMdDeftCause (final TbcMdDeftCauseDVO tbcMdDeftCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.selectTbcMdDeftCause.001*/  \n");
			sql.append("        DEFT_CAUSE_CODE , \n");
			sql.append("        DEFT_CAUSE_NM , \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEFT_CAUSE \n");
			sql.append("  WHERE DEFT_CAUSE_CODE = ? \n");

		return (TbcMdDeftCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeftCauseDVO returnTbcMdDeftCauseDVO = new TbcMdDeftCauseDVO();
									returnTbcMdDeftCauseDVO.setDeftCauseCode(resultSet.getString("DEFT_CAUSE_CODE"));
									returnTbcMdDeftCauseDVO.setDeftCauseNm(resultSet.getString("DEFT_CAUSE_NM"));
									returnTbcMdDeftCauseDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeftCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeftCause Method")
	public int mergeTbcMdDeftCause (final TbcMdDeftCauseDVO tbcMdDeftCauseDVO) {
		
		if ( selectTbcMdDeftCause (tbcMdDeftCauseDVO) == null) {
			return insertTbcMdDeftCause(tbcMdDeftCauseDVO);
		} else {
			return selectUpdateTbcMdDeftCause (tbcMdDeftCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeftCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeftCause Method")
	public int selectUpdateTbcMdDeftCause (final TbcMdDeftCauseDVO tbcMdDeftCauseDVO) {
		
		TbcMdDeftCauseDVO tmpTbcMdDeftCauseDVO =  selectTbcMdDeftCause (tbcMdDeftCauseDVO);
		if ( tbcMdDeftCauseDVO.getDeftCauseCode() != null && !"".equals(tbcMdDeftCauseDVO.getDeftCauseCode()) ) {
			tmpTbcMdDeftCauseDVO.setDeftCauseCode(tbcMdDeftCauseDVO.getDeftCauseCode());
		}		
		if ( tbcMdDeftCauseDVO.getDeftCauseNm() != null && !"".equals(tbcMdDeftCauseDVO.getDeftCauseNm()) ) {
			tmpTbcMdDeftCauseDVO.setDeftCauseNm(tbcMdDeftCauseDVO.getDeftCauseNm());
		}		
		if ( tbcMdDeftCauseDVO.getDeftCauseClsfCode() != null && !"".equals(tbcMdDeftCauseDVO.getDeftCauseClsfCode()) ) {
			tmpTbcMdDeftCauseDVO.setDeftCauseClsfCode(tbcMdDeftCauseDVO.getDeftCauseClsfCode());
		}		
		if ( tbcMdDeftCauseDVO.getUseYn() != null && !"".equals(tbcMdDeftCauseDVO.getUseYn()) ) {
			tmpTbcMdDeftCauseDVO.setUseYn(tbcMdDeftCauseDVO.getUseYn());
		}		
		if ( tbcMdDeftCauseDVO.getFstRegDt() != null && !"".equals(tbcMdDeftCauseDVO.getFstRegDt()) ) {
			tmpTbcMdDeftCauseDVO.setFstRegDt(tbcMdDeftCauseDVO.getFstRegDt());
		}		
		if ( tbcMdDeftCauseDVO.getFstRegerId() != null && !"".equals(tbcMdDeftCauseDVO.getFstRegerId()) ) {
			tmpTbcMdDeftCauseDVO.setFstRegerId(tbcMdDeftCauseDVO.getFstRegerId());
		}		
		if ( tbcMdDeftCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeftCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeftCauseDVO.setFnlUpdDt(tbcMdDeftCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeftCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdDeftCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdDeftCauseDVO.setFnlUpderId(tbcMdDeftCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdDeftCause (tmpTbcMdDeftCauseDVO);
	}

/**
* insertBatchTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeftCause")
	public int[] insertBatchTbcMdDeftCause (final List tbcMdDeftCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.insertBatchTbcMdDeftCause.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE (   \n");
			sql.append("        DEFT_CAUSE_CODE , \n");
			sql.append("        DEFT_CAUSE_NM , \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftCauseDVO tbcMdDeftCauseDVO = (TbcMdDeftCauseDVO)tbcMdDeftCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseNm());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseClsfCode());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeftCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeftCause")
	public int[] updateBatchTbcMdDeftCause (final List tbcMdDeftCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.updateBatchTbcMdDeftCause.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        DEFT_CAUSE_NM = ? , \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftCauseDVO tbcMdDeftCauseDVO = (TbcMdDeftCauseDVO)tbcMdDeftCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseNm());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseClsfCode());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
						}
							public int getBatchSize() {
									return tbcMdDeftCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeftCause Method
* 
* @ref_table TBC_MD_DEFT_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeftCause")
	public int[] deleteBatchTbcMdDeftCause (final List tbcMdDeftCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftCauseDEM.deleteBatchTbcMdDeftCause.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE \n");
			sql.append("  WHERE DEFT_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftCauseDVO tbcMdDeftCauseDVO = (TbcMdDeftCauseDVO)tbcMdDeftCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftCauseDVO.getDeftCauseCode());
						}
							public int getBatchSize() {
									return tbcMdDeftCauseDVOList.size();
							}
					}
		);			
	}

	
}