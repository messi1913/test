package com.samsung.gmes2.base;

public class Constants
{

    public static final String SERVICE_INFO        = "serviceInfo";

    public static final String _STATUS             = "_status";

    public static final String INSERT_FLAG         = "I";

    public static final String UPDATE_FLAG         = "U";

    public static final String DELETE_FLAG         = "D";

    public static final String DML_TABLE_NAME      = "dmlTableName";

    public static final String DML_CALL_METHOD     = "dmlCallMethod";

    public static final String TRANSACTION_MANAGER = "businessTxManager";

}
