package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MUL_LANG_COLM
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMulLangColmDEM extends AbstractDAO {


/**
* insertTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return int
*/
	@LocalName("insertTbcMdMulLangColm")
	public int insertTbcMdMulLangColm (final TbcMdMulLangColmDVO tbcMdMulLangColmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.insertTbcMdMulLangColm.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG_COLM (   \n");
			sql.append("        TAB_ID , \n");
			sql.append("        LANG_CODE , \n");
			sql.append("        N1_CULM_NM , \n");
			sql.append("        N2_CULM_NM , \n");
			sql.append("        N3_CULM_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN1CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN2CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN3CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdMulLangColm Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdMulLangColm Method")
	public int[][] updateBatchAllTbcMdMulLangColm (final List  tbcMdMulLangColmDVOList) {
		
		ArrayList updatetbcMdMulLangColmDVOList = new ArrayList();
		ArrayList insertttbcMdMulLangColmDVOList = new ArrayList();
		ArrayList deletetbcMdMulLangColmDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdMulLangColmDVOList.size() ; i++) {
		  TbcMdMulLangColmDVO tbcMdMulLangColmDVO = (TbcMdMulLangColmDVO) tbcMdMulLangColmDVOList.get(i);
		  
		  if (tbcMdMulLangColmDVO.getSqlAction().equals("C"))
		      insertttbcMdMulLangColmDVOList.add(tbcMdMulLangColmDVO);
		  else if (tbcMdMulLangColmDVO.getSqlAction().equals("U"))
		      updatetbcMdMulLangColmDVOList.add(tbcMdMulLangColmDVO);
		  else if (tbcMdMulLangColmDVO.getSqlAction().equals("D"))
		      deletetbcMdMulLangColmDVOList.add(tbcMdMulLangColmDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdMulLangColmDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdMulLangColm(insertttbcMdMulLangColmDVOList);
          
      if (updatetbcMdMulLangColmDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdMulLangColm(updatetbcMdMulLangColmDVOList);
      
      if (deletetbcMdMulLangColmDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdMulLangColm(deletetbcMdMulLangColmDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return int
*/
	@LocalName("updateTbcMdMulLangColm")
	public int updateTbcMdMulLangColm (final TbcMdMulLangColmDVO tbcMdMulLangColmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.updateTbcMdMulLangColm.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG_COLM \n");
			sql.append(" SET   \n");
			sql.append("        N1_CULM_NM = ? , \n");
			sql.append("        N2_CULM_NM = ? , \n");
			sql.append("        N3_CULM_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TAB_ID = ? \n");
			sql.append("   AND LANG_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangColmDVO.getN1CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN2CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN3CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
						}
					}
		);			
	}

/**
* deleteTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return int
*/
	@LocalName("deleteTbcMdMulLangColm")
	public int deleteTbcMdMulLangColm (final TbcMdMulLangColmDVO tbcMdMulLangColmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.deleteTbcMdMulLangColm.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG_COLM \n");
			sql.append("  WHERE TAB_ID = ? \n");
			sql.append("    AND LANG_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
						}
					}
		);			
	}

/**
* selectTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return TbcMdMulLangColmDVO 
*/
	@LocalName("selectTbcMdMulLangColm")
	public TbcMdMulLangColmDVO selectTbcMdMulLangColm (final TbcMdMulLangColmDVO tbcMdMulLangColmDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.selectTbcMdMulLangColm.001*/  \n");
			sql.append("        TAB_ID , \n");
			sql.append("        LANG_CODE , \n");
			sql.append("        N1_CULM_NM , \n");
			sql.append("        N2_CULM_NM , \n");
			sql.append("        N3_CULM_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MUL_LANG_COLM \n");
			sql.append("  WHERE TAB_ID = ? \n");
			sql.append("    AND LANG_CODE = ? \n");

		return (TbcMdMulLangColmDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdMulLangColmDVO returnTbcMdMulLangColmDVO = new TbcMdMulLangColmDVO();
									returnTbcMdMulLangColmDVO.setTabId(resultSet.getString("TAB_ID"));
									returnTbcMdMulLangColmDVO.setLangCode(resultSet.getString("LANG_CODE"));
									returnTbcMdMulLangColmDVO.setN1CulmNm(resultSet.getString("N1_CULM_NM"));
									returnTbcMdMulLangColmDVO.setN2CulmNm(resultSet.getString("N2_CULM_NM"));
									returnTbcMdMulLangColmDVO.setN3CulmNm(resultSet.getString("N3_CULM_NM"));
									returnTbcMdMulLangColmDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMulLangColmDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMulLangColmDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMulLangColmDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMulLangColmDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdMulLangColm Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdMulLangColm Method")
	public int mergeTbcMdMulLangColm (final TbcMdMulLangColmDVO tbcMdMulLangColmDVO) {
		
		if ( selectTbcMdMulLangColm (tbcMdMulLangColmDVO) == null) {
			return insertTbcMdMulLangColm(tbcMdMulLangColmDVO);
		} else {
			return selectUpdateTbcMdMulLangColm (tbcMdMulLangColmDVO);
		}
	}

	/**
	 * selectUpdateTbcMdMulLangColm Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdMulLangColm Method")
	public int selectUpdateTbcMdMulLangColm (final TbcMdMulLangColmDVO tbcMdMulLangColmDVO) {
		
		TbcMdMulLangColmDVO tmpTbcMdMulLangColmDVO =  selectTbcMdMulLangColm (tbcMdMulLangColmDVO);
		if ( tbcMdMulLangColmDVO.getTabId() != null && !"".equals(tbcMdMulLangColmDVO.getTabId()) ) {
			tmpTbcMdMulLangColmDVO.setTabId(tbcMdMulLangColmDVO.getTabId());
		}		
		if ( tbcMdMulLangColmDVO.getLangCode() != null && !"".equals(tbcMdMulLangColmDVO.getLangCode()) ) {
			tmpTbcMdMulLangColmDVO.setLangCode(tbcMdMulLangColmDVO.getLangCode());
		}		
		if ( tbcMdMulLangColmDVO.getN1CulmNm() != null && !"".equals(tbcMdMulLangColmDVO.getN1CulmNm()) ) {
			tmpTbcMdMulLangColmDVO.setN1CulmNm(tbcMdMulLangColmDVO.getN1CulmNm());
		}		
		if ( tbcMdMulLangColmDVO.getN2CulmNm() != null && !"".equals(tbcMdMulLangColmDVO.getN2CulmNm()) ) {
			tmpTbcMdMulLangColmDVO.setN2CulmNm(tbcMdMulLangColmDVO.getN2CulmNm());
		}		
		if ( tbcMdMulLangColmDVO.getN3CulmNm() != null && !"".equals(tbcMdMulLangColmDVO.getN3CulmNm()) ) {
			tmpTbcMdMulLangColmDVO.setN3CulmNm(tbcMdMulLangColmDVO.getN3CulmNm());
		}		
		if ( tbcMdMulLangColmDVO.getFstRegDt() != null && !"".equals(tbcMdMulLangColmDVO.getFstRegDt()) ) {
			tmpTbcMdMulLangColmDVO.setFstRegDt(tbcMdMulLangColmDVO.getFstRegDt());
		}		
		if ( tbcMdMulLangColmDVO.getFstRegerId() != null && !"".equals(tbcMdMulLangColmDVO.getFstRegerId()) ) {
			tmpTbcMdMulLangColmDVO.setFstRegerId(tbcMdMulLangColmDVO.getFstRegerId());
		}		
		if ( tbcMdMulLangColmDVO.getFnlUpdDt() != null && !"".equals(tbcMdMulLangColmDVO.getFnlUpdDt()) ) {
			tmpTbcMdMulLangColmDVO.setFnlUpdDt(tbcMdMulLangColmDVO.getFnlUpdDt());
		}		
		if ( tbcMdMulLangColmDVO.getFnlUpderId() != null && !"".equals(tbcMdMulLangColmDVO.getFnlUpderId()) ) {
			tmpTbcMdMulLangColmDVO.setFnlUpderId(tbcMdMulLangColmDVO.getFnlUpderId());
		}		
		return updateTbcMdMulLangColm (tmpTbcMdMulLangColmDVO);
	}

/**
* insertBatchTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return int[]
*/
	@LocalName("insertBatchTbcMdMulLangColm")
	public int[] insertBatchTbcMdMulLangColm (final List tbcMdMulLangColmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.insertBatchTbcMdMulLangColm.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG_COLM (   \n");
			sql.append("        TAB_ID , \n");
			sql.append("        LANG_CODE , \n");
			sql.append("        N1_CULM_NM , \n");
			sql.append("        N2_CULM_NM , \n");
			sql.append("        N3_CULM_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMulLangColmDVO tbcMdMulLangColmDVO = (TbcMdMulLangColmDVO)tbcMdMulLangColmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN1CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN2CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN3CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdMulLangColmDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return int[]
*/
	@LocalName("updateBatchTbcMdMulLangColm")
	public int[] updateBatchTbcMdMulLangColm (final List tbcMdMulLangColmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.updateBatchTbcMdMulLangColm.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG_COLM \n");
			sql.append(" SET   \n");
			sql.append("        N1_CULM_NM = ? , \n");
			sql.append("        N2_CULM_NM = ? , \n");
			sql.append("        N3_CULM_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TAB_ID = ? \n");
			sql.append("   AND LANG_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMulLangColmDVO tbcMdMulLangColmDVO = (TbcMdMulLangColmDVO)tbcMdMulLangColmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangColmDVO.getN1CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN2CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getN3CulmNm());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
						}
							public int getBatchSize() {
									return tbcMdMulLangColmDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdMulLangColm Method
* 
* @ref_table TBC_MD_MUL_LANG_COLM
* @return int[]
*/
	@LocalName("deleteBatchTbcMdMulLangColm")
	public int[] deleteBatchTbcMdMulLangColm (final List tbcMdMulLangColmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMulLangColmDEM.deleteBatchTbcMdMulLangColm.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG_COLM \n");
			sql.append("  WHERE TAB_ID = ? \n");
			sql.append("    AND LANG_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMulLangColmDVO tbcMdMulLangColmDVO = (TbcMdMulLangColmDVO)tbcMdMulLangColmDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdMulLangColmDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangColmDVO.getLangCode());
						}
							public int getBatchSize() {
									return tbcMdMulLangColmDVOList.size();
							}
					}
		);			
	}

	
}