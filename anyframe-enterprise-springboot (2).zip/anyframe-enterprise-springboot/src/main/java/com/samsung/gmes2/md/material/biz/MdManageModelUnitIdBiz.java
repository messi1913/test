package com.samsung.gmes2.md.material.biz;

public class MdManageModelUnitIdBiz {

	/**
	 * 모델별 UNIT ID 목록 조회
	 */
	public void listModelUnitId(){}

	/**
	 * 모델별 UNIT ID 목록 저장
	 */
	public void saveModelUnitId(){}

}
