package com.samsung.gmes2.md.equipment.app;

public class MDU522M01App {

	/**
	 * 설비종류 목록 초기설정
	 */
	public void initEquipKind(){}

	/**
	 * 설비종류 목록 조회
	 */
	public void listEquipKind(){}

	/**
	 * 설비종류 목록 엑셀 다운로드
	 */
	public void excelEquipKind(){}

	/**
	 * 설비종류 목록 저장
	 */
	public void saveEquipKind(){}

}
