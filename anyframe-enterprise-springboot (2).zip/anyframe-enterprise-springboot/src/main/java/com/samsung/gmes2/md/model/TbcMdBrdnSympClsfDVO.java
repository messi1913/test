package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdBrdnSympClsfDVO extends AbstractVo {

	@Length(30) 
	private String brdnSympClsfCode;

	@Length(500) 
	private String brdnSympClsfNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getBrdnSympClsfCode() {
		this.brdnSympClsfCode = super.getValue(0);
		return this.brdnSympClsfCode;
	}

	public void setBrdnSympClsfCode(String brdnSympClsfCode) {
        super.setValue(0, brdnSympClsfCode);
		this.brdnSympClsfCode = brdnSympClsfCode;
	}
	
	public String getBrdnSympClsfNm() {
		this.brdnSympClsfNm = super.getValue(1);
		return this.brdnSympClsfNm;
	}

	public void setBrdnSympClsfNm(String brdnSympClsfNm) {
        super.setValue(1, brdnSympClsfNm);
		this.brdnSympClsfNm = brdnSympClsfNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(2);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(2, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(3);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(3, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(4);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(4, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(5);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(5, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(6);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(6, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}