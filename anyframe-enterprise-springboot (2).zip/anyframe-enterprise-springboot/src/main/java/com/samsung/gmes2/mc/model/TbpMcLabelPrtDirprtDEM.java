package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbpMcLabelPrtDirprtDEM extends AbstractDAO {


/**
* insertTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return int
*/
	@LocalName("insertTbpMcLabelPrtDirprt")
	public int insertTbpMcLabelPrtDirprt (final TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.insertTbpMcLabelPrtDirprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_DIRPRT (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRT_QTY \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtDirprtDVO.getPrtQty());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbpMcLabelPrtDirprt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbpMcLabelPrtDirprt Method")
	public int[][] updateBatchAllTbpMcLabelPrtDirprt (final List  tbpMcLabelPrtDirprtDVOList) {
		
		ArrayList updatetbpMcLabelPrtDirprtDVOList = new ArrayList();
		ArrayList insertttbpMcLabelPrtDirprtDVOList = new ArrayList();
		ArrayList deletetbpMcLabelPrtDirprtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbpMcLabelPrtDirprtDVOList.size() ; i++) {
		  TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO = (TbpMcLabelPrtDirprtDVO) tbpMcLabelPrtDirprtDVOList.get(i);
		  
		  if (tbpMcLabelPrtDirprtDVO.getSqlAction().equals("C"))
		      insertttbpMcLabelPrtDirprtDVOList.add(tbpMcLabelPrtDirprtDVO);
		  else if (tbpMcLabelPrtDirprtDVO.getSqlAction().equals("U"))
		      updatetbpMcLabelPrtDirprtDVOList.add(tbpMcLabelPrtDirprtDVO);
		  else if (tbpMcLabelPrtDirprtDVO.getSqlAction().equals("D"))
		      deletetbpMcLabelPrtDirprtDVOList.add(tbpMcLabelPrtDirprtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbpMcLabelPrtDirprtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbpMcLabelPrtDirprt(insertttbpMcLabelPrtDirprtDVOList);
          
      if (updatetbpMcLabelPrtDirprtDVOList.size() >0)
          resultValues[1] = updateBatchTbpMcLabelPrtDirprt(updatetbpMcLabelPrtDirprtDVOList);
      
      if (deletetbpMcLabelPrtDirprtDVOList.size() >0)
          resultValues[2] = deleteBatchTbpMcLabelPrtDirprt(deletetbpMcLabelPrtDirprtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return int
*/
	@LocalName("updateTbpMcLabelPrtDirprt")
	public int updateTbpMcLabelPrtDirprt (final TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.updateTbpMcLabelPrtDirprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_DIRPRT \n");
			sql.append(" SET   \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        PRT_QTY = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND LABEL_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");
			sql.append("   AND PLANT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtDirprtDVO.getPrtQty());

							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
						}
					}
		);			
	}

/**
* deleteTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return int
*/
	@LocalName("deleteTbpMcLabelPrtDirprt")
	public int deleteTbpMcLabelPrtDirprt (final TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.deleteTbpMcLabelPrtDirprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_DIRPRT \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
						}
					}
		);			
	}

/**
* selectTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return TbpMcLabelPrtDirprtDVO 
*/
	@LocalName("selectTbpMcLabelPrtDirprt")
	public TbpMcLabelPrtDirprtDVO selectTbpMcLabelPrtDirprt (final TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.selectTbpMcLabelPrtDirprt.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRT_QTY \n");
			sql.append("   FROM TBP_MC_LABEL_PRT_DIRPRT \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");

		return (TbpMcLabelPrtDirprtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbpMcLabelPrtDirprtDVO returnTbpMcLabelPrtDirprtDVO = new TbpMcLabelPrtDirprtDVO();
									returnTbpMcLabelPrtDirprtDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbpMcLabelPrtDirprtDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbpMcLabelPrtDirprtDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbpMcLabelPrtDirprtDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbpMcLabelPrtDirprtDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbpMcLabelPrtDirprtDVO.setRePrtYn(resultSet.getString("RE_PRT_YN"));
									returnTbpMcLabelPrtDirprtDVO.setRePrtRsn(resultSet.getString("RE_PRT_RSN"));
									returnTbpMcLabelPrtDirprtDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbpMcLabelPrtDirprtDVO.setPrtQty(resultSet.getBigDecimal("PRT_QTY"));
									return returnTbpMcLabelPrtDirprtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbpMcLabelPrtDirprt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbpMcLabelPrtDirprt Method")
	public int mergeTbpMcLabelPrtDirprt (final TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO) {
		
		if ( selectTbpMcLabelPrtDirprt (tbpMcLabelPrtDirprtDVO) == null) {
			return insertTbpMcLabelPrtDirprt(tbpMcLabelPrtDirprtDVO);
		} else {
			return selectUpdateTbpMcLabelPrtDirprt (tbpMcLabelPrtDirprtDVO);
		}
	}

	/**
	 * selectUpdateTbpMcLabelPrtDirprt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbpMcLabelPrtDirprt Method")
	public int selectUpdateTbpMcLabelPrtDirprt (final TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO) {
		
		TbpMcLabelPrtDirprtDVO tmpTbpMcLabelPrtDirprtDVO =  selectTbpMcLabelPrtDirprt (tbpMcLabelPrtDirprtDVO);
		if ( tbpMcLabelPrtDirprtDVO.getModelCode() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getModelCode()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setModelCode(tbpMcLabelPrtDirprtDVO.getModelCode());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getLabelId() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getLabelId()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setLabelId(tbpMcLabelPrtDirprtDVO.getLabelId());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getPrtDt() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getPrtDt()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setPrtDt(tbpMcLabelPrtDirprtDVO.getPrtDt());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getPlantCode() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getPlantCode()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setPlantCode(tbpMcLabelPrtDirprtDVO.getPlantCode());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getPrterId() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getPrterId()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setPrterId(tbpMcLabelPrtDirprtDVO.getPrterId());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getRePrtYn() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getRePrtYn()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setRePrtYn(tbpMcLabelPrtDirprtDVO.getRePrtYn());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getRePrtRsn() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getRePrtRsn()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setRePrtRsn(tbpMcLabelPrtDirprtDVO.getRePrtRsn());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getLineCode() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getLineCode()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setLineCode(tbpMcLabelPrtDirprtDVO.getLineCode());
		}		
		if ( tbpMcLabelPrtDirprtDVO.getPrtQty() != null && !"".equals(tbpMcLabelPrtDirprtDVO.getPrtQty()) ) {
			tmpTbpMcLabelPrtDirprtDVO.setPrtQty(tbpMcLabelPrtDirprtDVO.getPrtQty());
		}		
		return updateTbpMcLabelPrtDirprt (tmpTbpMcLabelPrtDirprtDVO);
	}

/**
* insertBatchTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return int[]
*/
	@LocalName("insertBatchTbpMcLabelPrtDirprt")
	public int[] insertBatchTbpMcLabelPrtDirprt (final List tbpMcLabelPrtDirprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.insertBatchTbpMcLabelPrtDirprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_DIRPRT (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRT_QTY \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO = (TbpMcLabelPrtDirprtDVO)tbpMcLabelPrtDirprtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtDirprtDVO.getPrtQty());

						}
							public int getBatchSize() {
									return tbpMcLabelPrtDirprtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return int[]
*/
	@LocalName("updateBatchTbpMcLabelPrtDirprt")
	public int[] updateBatchTbpMcLabelPrtDirprt (final List tbpMcLabelPrtDirprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.updateBatchTbpMcLabelPrtDirprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_DIRPRT \n");
			sql.append(" SET   \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        PRT_QTY = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND LABEL_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");
			sql.append("   AND PLANT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO = (TbpMcLabelPrtDirprtDVO)tbpMcLabelPrtDirprtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtDirprtDVO.getPrtQty());

							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
						}
							public int getBatchSize() {
									return tbpMcLabelPrtDirprtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbpMcLabelPrtDirprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_DIRPRT
* @return int[]
*/
	@LocalName("deleteBatchTbpMcLabelPrtDirprt")
	public int[] deleteBatchTbpMcLabelPrtDirprt (final List tbpMcLabelPrtDirprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLabelPrtDirprtDEM.deleteBatchTbpMcLabelPrtDirprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_DIRPRT \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtDirprtDVO tbpMcLabelPrtDirprtDVO = (TbpMcLabelPrtDirprtDVO)tbpMcLabelPrtDirprtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtDirprtDVO.getPlantCode());
						}
							public int getBatchSize() {
									return tbpMcLabelPrtDirprtDVOList.size();
							}
					}
		);			
	}

	
}