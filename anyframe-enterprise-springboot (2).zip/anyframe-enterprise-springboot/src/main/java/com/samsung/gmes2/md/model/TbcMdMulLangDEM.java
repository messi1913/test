package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MUL_LANG
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMulLangDEM extends AbstractDAO {


/**
* insertTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return int
*/
	@LocalName("insertTbcMdMulLang")
	public int insertTbcMdMulLang (final TbcMdMulLangDVO tbcMdMulLangDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.insertTbcMdMulLang.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG (   \n");
			sql.append("        TAB_ID , \n");
			sql.append("        N1_KEY_VALUE , \n");
			sql.append("        N2_KEY_VALUE , \n");
			sql.append("        N3_KEY_VALUE , \n");
			sql.append("        N4_KEY_VALUE , \n");
			sql.append("        N5_KEY_VALUE , \n");
			sql.append("        LANG_CODE , \n");
			sql.append("        CODE_NM , \n");
			sql.append("        CODE_DESC , \n");
			sql.append("        N1_CULM_ID , \n");
			sql.append("        N1_CULM_CONT , \n");
			sql.append("        N2_CULM_ID , \n");
			sql.append("        N2_CULM_CONT , \n");
			sql.append("        N3_CULM_ID , \n");
			sql.append("        N3_CULM_CONT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
							ps.setString(psCount++, tbcMdMulLangDVO.getCodeNm());
							ps.setString(psCount++, tbcMdMulLangDVO.getCodeDesc());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getUseYn());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdMulLang Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdMulLang Method")
	public int[][] updateBatchAllTbcMdMulLang (final List  tbcMdMulLangDVOList) {
		
		ArrayList updatetbcMdMulLangDVOList = new ArrayList();
		ArrayList insertttbcMdMulLangDVOList = new ArrayList();
		ArrayList deletetbcMdMulLangDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdMulLangDVOList.size() ; i++) {
		  TbcMdMulLangDVO tbcMdMulLangDVO = (TbcMdMulLangDVO) tbcMdMulLangDVOList.get(i);
		  
		  if (tbcMdMulLangDVO.getSqlAction().equals("C"))
		      insertttbcMdMulLangDVOList.add(tbcMdMulLangDVO);
		  else if (tbcMdMulLangDVO.getSqlAction().equals("U"))
		      updatetbcMdMulLangDVOList.add(tbcMdMulLangDVO);
		  else if (tbcMdMulLangDVO.getSqlAction().equals("D"))
		      deletetbcMdMulLangDVOList.add(tbcMdMulLangDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdMulLangDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdMulLang(insertttbcMdMulLangDVOList);
          
      if (updatetbcMdMulLangDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdMulLang(updatetbcMdMulLangDVOList);
      
      if (deletetbcMdMulLangDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdMulLang(deletetbcMdMulLangDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return int
*/
	@LocalName("updateTbcMdMulLang")
	public int updateTbcMdMulLang (final TbcMdMulLangDVO tbcMdMulLangDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.updateTbcMdMulLang.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG \n");
			sql.append(" SET   \n");
			sql.append("        CODE_NM = ? , \n");
			sql.append("        CODE_DESC = ? , \n");
			sql.append("        N1_CULM_ID = ? , \n");
			sql.append("        N1_CULM_CONT = ? , \n");
			sql.append("        N2_CULM_ID = ? , \n");
			sql.append("        N2_CULM_CONT = ? , \n");
			sql.append("        N3_CULM_ID = ? , \n");
			sql.append("        N3_CULM_CONT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TAB_ID = ? \n");
			sql.append("   AND N1_KEY_VALUE = ? \n");
			sql.append("   AND N2_KEY_VALUE = ? \n");
			sql.append("   AND N3_KEY_VALUE = ? \n");
			sql.append("   AND N4_KEY_VALUE = ? \n");
			sql.append("   AND N5_KEY_VALUE = ? \n");
			sql.append("   AND LANG_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangDVO.getCodeNm());
							ps.setString(psCount++, tbcMdMulLangDVO.getCodeDesc());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getUseYn());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
						}
					}
		);			
	}

/**
* deleteTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return int
*/
	@LocalName("deleteTbcMdMulLang")
	public int deleteTbcMdMulLang (final TbcMdMulLangDVO tbcMdMulLangDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.deleteTbcMdMulLang.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG \n");
			sql.append("  WHERE TAB_ID = ? \n");
			sql.append("    AND N1_KEY_VALUE = ? \n");
			sql.append("    AND N2_KEY_VALUE = ? \n");
			sql.append("    AND N3_KEY_VALUE = ? \n");
			sql.append("    AND N4_KEY_VALUE = ? \n");
			sql.append("    AND N5_KEY_VALUE = ? \n");
			sql.append("    AND LANG_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
						}
					}
		);			
	}

/**
* selectTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return TbcMdMulLangDVO 
*/
	@LocalName("selectTbcMdMulLang")
	public TbcMdMulLangDVO selectTbcMdMulLang (final TbcMdMulLangDVO tbcMdMulLangDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.selectTbcMdMulLang.001*/  \n");
			sql.append("        TAB_ID , \n");
			sql.append("        N1_KEY_VALUE , \n");
			sql.append("        N2_KEY_VALUE , \n");
			sql.append("        N3_KEY_VALUE , \n");
			sql.append("        N4_KEY_VALUE , \n");
			sql.append("        N5_KEY_VALUE , \n");
			sql.append("        LANG_CODE , \n");
			sql.append("        CODE_NM , \n");
			sql.append("        CODE_DESC , \n");
			sql.append("        N1_CULM_ID , \n");
			sql.append("        N1_CULM_CONT , \n");
			sql.append("        N2_CULM_ID , \n");
			sql.append("        N2_CULM_CONT , \n");
			sql.append("        N3_CULM_ID , \n");
			sql.append("        N3_CULM_CONT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MUL_LANG \n");
			sql.append("  WHERE TAB_ID = ? \n");
			sql.append("    AND N1_KEY_VALUE = ? \n");
			sql.append("    AND N2_KEY_VALUE = ? \n");
			sql.append("    AND N3_KEY_VALUE = ? \n");
			sql.append("    AND N4_KEY_VALUE = ? \n");
			sql.append("    AND N5_KEY_VALUE = ? \n");
			sql.append("    AND LANG_CODE = ? \n");

		return (TbcMdMulLangDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdMulLangDVO returnTbcMdMulLangDVO = new TbcMdMulLangDVO();
									returnTbcMdMulLangDVO.setTabId(resultSet.getString("TAB_ID"));
									returnTbcMdMulLangDVO.setN1KeyValue(resultSet.getString("N1_KEY_VALUE"));
									returnTbcMdMulLangDVO.setN2KeyValue(resultSet.getString("N2_KEY_VALUE"));
									returnTbcMdMulLangDVO.setN3KeyValue(resultSet.getString("N3_KEY_VALUE"));
									returnTbcMdMulLangDVO.setN4KeyValue(resultSet.getString("N4_KEY_VALUE"));
									returnTbcMdMulLangDVO.setN5KeyValue(resultSet.getString("N5_KEY_VALUE"));
									returnTbcMdMulLangDVO.setLangCode(resultSet.getString("LANG_CODE"));
									returnTbcMdMulLangDVO.setCodeNm(resultSet.getString("CODE_NM"));
									returnTbcMdMulLangDVO.setCodeDesc(resultSet.getString("CODE_DESC"));
									returnTbcMdMulLangDVO.setN1CulmId(resultSet.getString("N1_CULM_ID"));
									returnTbcMdMulLangDVO.setN1CulmCont(resultSet.getString("N1_CULM_CONT"));
									returnTbcMdMulLangDVO.setN2CulmId(resultSet.getString("N2_CULM_ID"));
									returnTbcMdMulLangDVO.setN2CulmCont(resultSet.getString("N2_CULM_CONT"));
									returnTbcMdMulLangDVO.setN3CulmId(resultSet.getString("N3_CULM_ID"));
									returnTbcMdMulLangDVO.setN3CulmCont(resultSet.getString("N3_CULM_CONT"));
									returnTbcMdMulLangDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMulLangDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMulLangDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMulLangDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMulLangDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMulLangDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdMulLang Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdMulLang Method")
	public int mergeTbcMdMulLang (final TbcMdMulLangDVO tbcMdMulLangDVO) {
		
		if ( selectTbcMdMulLang (tbcMdMulLangDVO) == null) {
			return insertTbcMdMulLang(tbcMdMulLangDVO);
		} else {
			return selectUpdateTbcMdMulLang (tbcMdMulLangDVO);
		}
	}

	/**
	 * selectUpdateTbcMdMulLang Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdMulLang Method")
	public int selectUpdateTbcMdMulLang (final TbcMdMulLangDVO tbcMdMulLangDVO) {
		
		TbcMdMulLangDVO tmpTbcMdMulLangDVO =  selectTbcMdMulLang (tbcMdMulLangDVO);
		if ( tbcMdMulLangDVO.getTabId() != null && !"".equals(tbcMdMulLangDVO.getTabId()) ) {
			tmpTbcMdMulLangDVO.setTabId(tbcMdMulLangDVO.getTabId());
		}		
		if ( tbcMdMulLangDVO.getN1KeyValue() != null && !"".equals(tbcMdMulLangDVO.getN1KeyValue()) ) {
			tmpTbcMdMulLangDVO.setN1KeyValue(tbcMdMulLangDVO.getN1KeyValue());
		}		
		if ( tbcMdMulLangDVO.getN2KeyValue() != null && !"".equals(tbcMdMulLangDVO.getN2KeyValue()) ) {
			tmpTbcMdMulLangDVO.setN2KeyValue(tbcMdMulLangDVO.getN2KeyValue());
		}		
		if ( tbcMdMulLangDVO.getN3KeyValue() != null && !"".equals(tbcMdMulLangDVO.getN3KeyValue()) ) {
			tmpTbcMdMulLangDVO.setN3KeyValue(tbcMdMulLangDVO.getN3KeyValue());
		}		
		if ( tbcMdMulLangDVO.getN4KeyValue() != null && !"".equals(tbcMdMulLangDVO.getN4KeyValue()) ) {
			tmpTbcMdMulLangDVO.setN4KeyValue(tbcMdMulLangDVO.getN4KeyValue());
		}		
		if ( tbcMdMulLangDVO.getN5KeyValue() != null && !"".equals(tbcMdMulLangDVO.getN5KeyValue()) ) {
			tmpTbcMdMulLangDVO.setN5KeyValue(tbcMdMulLangDVO.getN5KeyValue());
		}		
		if ( tbcMdMulLangDVO.getLangCode() != null && !"".equals(tbcMdMulLangDVO.getLangCode()) ) {
			tmpTbcMdMulLangDVO.setLangCode(tbcMdMulLangDVO.getLangCode());
		}		
		if ( tbcMdMulLangDVO.getCodeNm() != null && !"".equals(tbcMdMulLangDVO.getCodeNm()) ) {
			tmpTbcMdMulLangDVO.setCodeNm(tbcMdMulLangDVO.getCodeNm());
		}		
		if ( tbcMdMulLangDVO.getCodeDesc() != null && !"".equals(tbcMdMulLangDVO.getCodeDesc()) ) {
			tmpTbcMdMulLangDVO.setCodeDesc(tbcMdMulLangDVO.getCodeDesc());
		}		
		if ( tbcMdMulLangDVO.getN1CulmId() != null && !"".equals(tbcMdMulLangDVO.getN1CulmId()) ) {
			tmpTbcMdMulLangDVO.setN1CulmId(tbcMdMulLangDVO.getN1CulmId());
		}		
		if ( tbcMdMulLangDVO.getN1CulmCont() != null && !"".equals(tbcMdMulLangDVO.getN1CulmCont()) ) {
			tmpTbcMdMulLangDVO.setN1CulmCont(tbcMdMulLangDVO.getN1CulmCont());
		}		
		if ( tbcMdMulLangDVO.getN2CulmId() != null && !"".equals(tbcMdMulLangDVO.getN2CulmId()) ) {
			tmpTbcMdMulLangDVO.setN2CulmId(tbcMdMulLangDVO.getN2CulmId());
		}		
		if ( tbcMdMulLangDVO.getN2CulmCont() != null && !"".equals(tbcMdMulLangDVO.getN2CulmCont()) ) {
			tmpTbcMdMulLangDVO.setN2CulmCont(tbcMdMulLangDVO.getN2CulmCont());
		}		
		if ( tbcMdMulLangDVO.getN3CulmId() != null && !"".equals(tbcMdMulLangDVO.getN3CulmId()) ) {
			tmpTbcMdMulLangDVO.setN3CulmId(tbcMdMulLangDVO.getN3CulmId());
		}		
		if ( tbcMdMulLangDVO.getN3CulmCont() != null && !"".equals(tbcMdMulLangDVO.getN3CulmCont()) ) {
			tmpTbcMdMulLangDVO.setN3CulmCont(tbcMdMulLangDVO.getN3CulmCont());
		}		
		if ( tbcMdMulLangDVO.getUseYn() != null && !"".equals(tbcMdMulLangDVO.getUseYn()) ) {
			tmpTbcMdMulLangDVO.setUseYn(tbcMdMulLangDVO.getUseYn());
		}		
		if ( tbcMdMulLangDVO.getFstRegDt() != null && !"".equals(tbcMdMulLangDVO.getFstRegDt()) ) {
			tmpTbcMdMulLangDVO.setFstRegDt(tbcMdMulLangDVO.getFstRegDt());
		}		
		if ( tbcMdMulLangDVO.getFstRegerId() != null && !"".equals(tbcMdMulLangDVO.getFstRegerId()) ) {
			tmpTbcMdMulLangDVO.setFstRegerId(tbcMdMulLangDVO.getFstRegerId());
		}		
		if ( tbcMdMulLangDVO.getFnlUpdDt() != null && !"".equals(tbcMdMulLangDVO.getFnlUpdDt()) ) {
			tmpTbcMdMulLangDVO.setFnlUpdDt(tbcMdMulLangDVO.getFnlUpdDt());
		}		
		if ( tbcMdMulLangDVO.getFnlUpderId() != null && !"".equals(tbcMdMulLangDVO.getFnlUpderId()) ) {
			tmpTbcMdMulLangDVO.setFnlUpderId(tbcMdMulLangDVO.getFnlUpderId());
		}		
		return updateTbcMdMulLang (tmpTbcMdMulLangDVO);
	}

/**
* insertBatchTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return int[]
*/
	@LocalName("insertBatchTbcMdMulLang")
	public int[] insertBatchTbcMdMulLang (final List tbcMdMulLangDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.insertBatchTbcMdMulLang.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG (   \n");
			sql.append("        TAB_ID , \n");
			sql.append("        N1_KEY_VALUE , \n");
			sql.append("        N2_KEY_VALUE , \n");
			sql.append("        N3_KEY_VALUE , \n");
			sql.append("        N4_KEY_VALUE , \n");
			sql.append("        N5_KEY_VALUE , \n");
			sql.append("        LANG_CODE , \n");
			sql.append("        CODE_NM , \n");
			sql.append("        CODE_DESC , \n");
			sql.append("        N1_CULM_ID , \n");
			sql.append("        N1_CULM_CONT , \n");
			sql.append("        N2_CULM_ID , \n");
			sql.append("        N2_CULM_CONT , \n");
			sql.append("        N3_CULM_ID , \n");
			sql.append("        N3_CULM_CONT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMulLangDVO tbcMdMulLangDVO = (TbcMdMulLangDVO)tbcMdMulLangDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
							ps.setString(psCount++, tbcMdMulLangDVO.getCodeNm());
							ps.setString(psCount++, tbcMdMulLangDVO.getCodeDesc());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getUseYn());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdMulLangDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return int[]
*/
	@LocalName("updateBatchTbcMdMulLang")
	public int[] updateBatchTbcMdMulLang (final List tbcMdMulLangDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.updateBatchTbcMdMulLang.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG \n");
			sql.append(" SET   \n");
			sql.append("        CODE_NM = ? , \n");
			sql.append("        CODE_DESC = ? , \n");
			sql.append("        N1_CULM_ID = ? , \n");
			sql.append("        N1_CULM_CONT = ? , \n");
			sql.append("        N2_CULM_ID = ? , \n");
			sql.append("        N2_CULM_CONT = ? , \n");
			sql.append("        N3_CULM_ID = ? , \n");
			sql.append("        N3_CULM_CONT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TAB_ID = ? \n");
			sql.append("   AND N1_KEY_VALUE = ? \n");
			sql.append("   AND N2_KEY_VALUE = ? \n");
			sql.append("   AND N3_KEY_VALUE = ? \n");
			sql.append("   AND N4_KEY_VALUE = ? \n");
			sql.append("   AND N5_KEY_VALUE = ? \n");
			sql.append("   AND LANG_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMulLangDVO tbcMdMulLangDVO = (TbcMdMulLangDVO)tbcMdMulLangDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMulLangDVO.getCodeNm());
							ps.setString(psCount++, tbcMdMulLangDVO.getCodeDesc());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3CulmCont());
							ps.setString(psCount++, tbcMdMulLangDVO.getUseYn());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMulLangDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
						}
							public int getBatchSize() {
									return tbcMdMulLangDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdMulLang Method
* 
* @ref_table TBC_MD_MUL_LANG
* @return int[]
*/
	@LocalName("deleteBatchTbcMdMulLang")
	public int[] deleteBatchTbcMdMulLang (final List tbcMdMulLangDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMulLangDEM.deleteBatchTbcMdMulLang.001*/  \n");
			sql.append(" TBC_MD_MUL_LANG \n");
			sql.append("  WHERE TAB_ID = ? \n");
			sql.append("    AND N1_KEY_VALUE = ? \n");
			sql.append("    AND N2_KEY_VALUE = ? \n");
			sql.append("    AND N3_KEY_VALUE = ? \n");
			sql.append("    AND N4_KEY_VALUE = ? \n");
			sql.append("    AND N5_KEY_VALUE = ? \n");
			sql.append("    AND LANG_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMulLangDVO tbcMdMulLangDVO = (TbcMdMulLangDVO)tbcMdMulLangDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdMulLangDVO.getTabId());
							ps.setString(psCount++, tbcMdMulLangDVO.getN1KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN2KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN3KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN4KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getN5KeyValue());
							ps.setString(psCount++, tbcMdMulLangDVO.getLangCode());
						}
							public int getBatchSize() {
									return tbcMdMulLangDVOList.size();
							}
					}
		);			
	}

	
}