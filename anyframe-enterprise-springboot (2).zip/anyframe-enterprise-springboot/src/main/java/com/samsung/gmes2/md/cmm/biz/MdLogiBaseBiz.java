package com.samsung.gmes2.md.cmm.biz;

public class MdLogiBaseBiz {

	/**
	 * Storage 리스트
	 */
	public void listStrgBase(){}

	/**
	 * Zone 리스트
	 */
	public void listZoneBase(){}

	/**
	 * Bin 리스트
	 */
	public void listBinBase(){}

	/**
	 * Serial형태 리스트
	 */
	public void listSnNoFormBase(){}

}
