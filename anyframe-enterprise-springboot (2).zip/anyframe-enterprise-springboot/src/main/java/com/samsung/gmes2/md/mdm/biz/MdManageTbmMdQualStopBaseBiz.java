/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbmMdQualStopBaseBiz.java
 * Description : 테이블 TbmMdQualStopBase에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.21          심재국          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdMfgPartDVO;
import com.samsung.gmes2.md.model.TbmMdProcDVO;
import com.samsung.gmes2.md.model.TbmMdQualStopBaseDVO;

public class MdManageTbmMdQualStopBaseBiz {
	
	/**
	 * TbmdQualStopBase Table 에서
	 * 다른 table의 참조키를 check
	 * 하는 공통 로직
	 * @name_ko TbmdQualStopBase공통check
	 */
	public void common(TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO)
			throws Exception {
		BaseUtil.checkNotEmpty(tbmMdQualStopBaseDVO);

		TbmMdProcDVO tbmMdProcDVO = new TbmMdProcDVO();
		BaseUtil.populate(tbmMdQualStopBaseDVO, tbmMdProcDVO, "fctCode, lineCode, unitProcCode");
		BaseUtil.checkFound(tbmMdProcDVO);

		TbcMdMfgPartDVO tbcMdMfgPartDVO = new TbcMdMfgPartDVO();
		BaseUtil.populate(tbmMdQualStopBaseDVO, tbcMdMfgPartDVO, "mfgPartCode");
		BaseUtil.checkFound(tbcMdMfgPartDVO);
		
	}

	/**
	 * TbmMdQualStopBase 등록을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdQualStopBaseDVO 값을 넣어준다
	 * @name_ko TbmMdQualStopBase등록
	 */
	public TbmMdQualStopBaseDVO createTbmMdQualStopBase(
			TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) throws Exception {
		common(tbmMdQualStopBaseDVO);
		return CrudUtil.create(tbmMdQualStopBaseDVO);
	}

	/**
	 * TbmMdQualStopBase 삭제 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdQualStopBaseDVO 값을 넣어준다
	 * @name_ko TbmMdQualStopBase삭제
	 */
	public TbmMdQualStopBaseDVO deleteTbmMdQualStopBase(
			TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) throws Exception {
		common(tbmMdQualStopBaseDVO);
		return CrudUtil.delete(tbmMdQualStopBaseDVO);
	}

	/**
	 * TbmMdQualStopBase 수정을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdQualStopBaseDVO 값을 넣어준다
	 * @name_ko TbmMdQualStopBase 수정
	 */
	public TbmMdQualStopBaseDVO updateTbmMdQualStopBase(
			TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) throws Exception {
		common(tbmMdQualStopBaseDVO);
		return CrudUtil.update(tbmMdQualStopBaseDVO);
	}

	/**
	 * TbmMdQualStopBase의 값을  얻기 위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdQualStopBaseDVO 값을 넣어준다
	 * 단건 조회 기능
	 */
	public TbmMdQualStopBaseDVO getTbmMdQualStopBase(
			TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) throws Exception {
		//BaseUtil.checkNotEmpty(tbmMdQualStopBaseDVO);
		return CrudUtil.get(tbmMdQualStopBaseDVO);
	}

	/**
	 * TbmMdQualStopBase의 list 값을  얻기 위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdQualStopBaseDVO 값을 넣어준다
	 * 다건 조회 기능
	 * @param tbmMdQualStopBaseDVO
	 * @return
	 */
	public List<TbmMdQualStopBaseDVO> listTbmMdQualStopBase(
			TbmMdQualStopBaseDVO tbmMdQualStopBaseDVO) throws Exception {
		// Pk 값이 5개 이므로 기본키가 5개가 있는지 확인
		// FctCode, MfgPartCode, LineCode, UnitProcCode, DeftSympClsfCode
		// CrudUtil.list0 은 TbmMdQualStopBaseDQM에 dlistpage0000을 호출한다
		return CrudUtil.list0(TbmMdQualStopBaseDVO.class, tbmMdQualStopBaseDVO,
				0, 0);
	}

}
