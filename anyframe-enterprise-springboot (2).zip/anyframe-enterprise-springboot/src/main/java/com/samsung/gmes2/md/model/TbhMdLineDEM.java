package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_LINE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMdLineDEM extends AbstractDAO {


/**
* insertTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return int
*/
	@LocalName("insertTbhMdLine")
	public int insertTbhMdLine (final TbhMdLineDVO tbhMdLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdLineDEM.insertTbhMdLine.001*/  \n");
			sql.append(" TBH_MD_LINE (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        LINE_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        LINE_FORM_CODE , \n");
			sql.append("        LINE_LOC_DESC , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        TB_GUBUN_CODE , \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        PLAN_MANUAL_CRE_YN , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        WORK_START_HMS , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
							ps.setString(psCount++, tbhMdLineDVO.getLineNm());
							ps.setString(psCount++, tbhMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbhMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbhMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbhMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getCellTypeCode());
							ps.setString(psCount++, tbhMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbhMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbhMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbhMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbhMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbhMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdLineDVO.getUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdLineDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdLine Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdLine Method")
	public int[][] updateBatchAllTbhMdLine (final List  tbhMdLineDVOList) {
		
		ArrayList updatetbhMdLineDVOList = new ArrayList();
		ArrayList insertttbhMdLineDVOList = new ArrayList();
		ArrayList deletetbhMdLineDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdLineDVOList.size() ; i++) {
		  TbhMdLineDVO tbhMdLineDVO = (TbhMdLineDVO) tbhMdLineDVOList.get(i);
		  
		  if (tbhMdLineDVO.getSqlAction().equals("C"))
		      insertttbhMdLineDVOList.add(tbhMdLineDVO);
		  else if (tbhMdLineDVO.getSqlAction().equals("U"))
		      updatetbhMdLineDVOList.add(tbhMdLineDVO);
		  else if (tbhMdLineDVO.getSqlAction().equals("D"))
		      deletetbhMdLineDVOList.add(tbhMdLineDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdLineDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdLine(insertttbhMdLineDVOList);
          
      if (updatetbhMdLineDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdLine(updatetbhMdLineDVOList);
      
      if (deletetbhMdLineDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdLine(deletetbhMdLineDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return int
*/
	@LocalName("updateTbhMdLine")
	public int updateTbhMdLine (final TbhMdLineDVO tbhMdLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdLineDEM.updateTbhMdLine.001*/  \n");
			sql.append(" TBH_MD_LINE \n");
			sql.append(" SET   \n");
			sql.append("        LINE_NM = ? , \n");
			sql.append("        MFG_PART_CODE = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        LINE_FORM_CODE = ? , \n");
			sql.append("        LINE_LOC_DESC = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        TB_GUBUN_CODE = ? , \n");
			sql.append("        CELL_TYPE_CODE = ? , \n");
			sql.append("        PLAN_MANUAL_CRE_YN = ? , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        WORK_START_HMS = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        TT_CALC_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdLineDVO.getLineNm());
							ps.setString(psCount++, tbhMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbhMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbhMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbhMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getCellTypeCode());
							ps.setString(psCount++, tbhMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbhMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbhMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbhMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbhMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbhMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdLineDVO.getUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdLineDVO.getEvtNm());

							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return int
*/
	@LocalName("deleteTbhMdLine")
	public int deleteTbhMdLine (final TbhMdLineDVO tbhMdLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdLineDEM.deleteTbhMdLine.001*/  \n");
			sql.append(" TBH_MD_LINE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return TbhMdLineDVO 
*/
	@LocalName("selectTbhMdLine")
	public TbhMdLineDVO selectTbhMdLine (final TbhMdLineDVO tbhMdLineDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdLineDEM.selectTbhMdLine.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        LINE_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        LINE_FORM_CODE , \n");
			sql.append("        LINE_LOC_DESC , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        TB_GUBUN_CODE , \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        PLAN_MANUAL_CRE_YN , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        WORK_START_HMS , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBH_MD_LINE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdLineDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdLineDVO returnTbhMdLineDVO = new TbhMdLineDVO();
									returnTbhMdLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbhMdLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbhMdLineDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdLineDVO.setLineNm(resultSet.getString("LINE_NM"));
									returnTbhMdLineDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbhMdLineDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbhMdLineDVO.setLineFormCode(resultSet.getString("LINE_FORM_CODE"));
									returnTbhMdLineDVO.setLineLocDesc(resultSet.getString("LINE_LOC_DESC"));
									returnTbhMdLineDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbhMdLineDVO.setTbGubunCode(resultSet.getString("TB_GUBUN_CODE"));
									returnTbhMdLineDVO.setCellTypeCode(resultSet.getString("CELL_TYPE_CODE"));
									returnTbhMdLineDVO.setPlanManualCreYn(resultSet.getString("PLAN_MANUAL_CRE_YN"));
									returnTbhMdLineDVO.setMainPackLineInlineYn(resultSet.getString("MAIN_PACK_LINE_INLINE_YN"));
									returnTbhMdLineDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbhMdLineDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbhMdLineDVO.setWorkStartHms(resultSet.getString("WORK_START_HMS"));
									returnTbhMdLineDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbhMdLineDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbhMdLineDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbhMdLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbhMdLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbhMdLineDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbhMdLineDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdLine Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdLine Method")
	public int mergeTbhMdLine (final TbhMdLineDVO tbhMdLineDVO) {
		
		if ( selectTbhMdLine (tbhMdLineDVO) == null) {
			return insertTbhMdLine(tbhMdLineDVO);
		} else {
			return selectUpdateTbhMdLine (tbhMdLineDVO);
		}
	}

	/**
	 * selectUpdateTbhMdLine Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdLine Method")
	public int selectUpdateTbhMdLine (final TbhMdLineDVO tbhMdLineDVO) {
		
		TbhMdLineDVO tmpTbhMdLineDVO =  selectTbhMdLine (tbhMdLineDVO);
		if ( tbhMdLineDVO.getFctCode() != null && !"".equals(tbhMdLineDVO.getFctCode()) ) {
			tmpTbhMdLineDVO.setFctCode(tbhMdLineDVO.getFctCode());
		}		
		if ( tbhMdLineDVO.getLineCode() != null && !"".equals(tbhMdLineDVO.getLineCode()) ) {
			tmpTbhMdLineDVO.setLineCode(tbhMdLineDVO.getLineCode());
		}		
		if ( tbhMdLineDVO.getHistTsp() != null && !"".equals(tbhMdLineDVO.getHistTsp()) ) {
			tmpTbhMdLineDVO.setHistTsp(tbhMdLineDVO.getHistTsp());
		}		
		if ( tbhMdLineDVO.getLineNm() != null && !"".equals(tbhMdLineDVO.getLineNm()) ) {
			tmpTbhMdLineDVO.setLineNm(tbhMdLineDVO.getLineNm());
		}		
		if ( tbhMdLineDVO.getMfgPartCode() != null && !"".equals(tbhMdLineDVO.getMfgPartCode()) ) {
			tmpTbhMdLineDVO.setMfgPartCode(tbhMdLineDVO.getMfgPartCode());
		}		
		if ( tbhMdLineDVO.getProcGubunCode() != null && !"".equals(tbhMdLineDVO.getProcGubunCode()) ) {
			tmpTbhMdLineDVO.setProcGubunCode(tbhMdLineDVO.getProcGubunCode());
		}		
		if ( tbhMdLineDVO.getLineFormCode() != null && !"".equals(tbhMdLineDVO.getLineFormCode()) ) {
			tmpTbhMdLineDVO.setLineFormCode(tbhMdLineDVO.getLineFormCode());
		}		
		if ( tbhMdLineDVO.getLineLocDesc() != null && !"".equals(tbhMdLineDVO.getLineLocDesc()) ) {
			tmpTbhMdLineDVO.setLineLocDesc(tbhMdLineDVO.getLineLocDesc());
		}		
		if ( tbhMdLineDVO.getOutsYn() != null && !"".equals(tbhMdLineDVO.getOutsYn()) ) {
			tmpTbhMdLineDVO.setOutsYn(tbhMdLineDVO.getOutsYn());
		}		
		if ( tbhMdLineDVO.getTbGubunCode() != null && !"".equals(tbhMdLineDVO.getTbGubunCode()) ) {
			tmpTbhMdLineDVO.setTbGubunCode(tbhMdLineDVO.getTbGubunCode());
		}		
		if ( tbhMdLineDVO.getCellTypeCode() != null && !"".equals(tbhMdLineDVO.getCellTypeCode()) ) {
			tmpTbhMdLineDVO.setCellTypeCode(tbhMdLineDVO.getCellTypeCode());
		}		
		if ( tbhMdLineDVO.getPlanManualCreYn() != null && !"".equals(tbhMdLineDVO.getPlanManualCreYn()) ) {
			tmpTbhMdLineDVO.setPlanManualCreYn(tbhMdLineDVO.getPlanManualCreYn());
		}		
		if ( tbhMdLineDVO.getMainPackLineInlineYn() != null && !"".equals(tbhMdLineDVO.getMainPackLineInlineYn()) ) {
			tmpTbhMdLineDVO.setMainPackLineInlineYn(tbhMdLineDVO.getMainPackLineInlineYn());
		}		
		if ( tbhMdLineDVO.getCatvUseYn() != null && !"".equals(tbhMdLineDVO.getCatvUseYn()) ) {
			tmpTbhMdLineDVO.setCatvUseYn(tbhMdLineDVO.getCatvUseYn());
		}		
		if ( tbhMdLineDVO.getBoardUseYn() != null && !"".equals(tbhMdLineDVO.getBoardUseYn()) ) {
			tmpTbhMdLineDVO.setBoardUseYn(tbhMdLineDVO.getBoardUseYn());
		}		
		if ( tbhMdLineDVO.getWorkStartHms() != null && !"".equals(tbhMdLineDVO.getWorkStartHms()) ) {
			tmpTbhMdLineDVO.setWorkStartHms(tbhMdLineDVO.getWorkStartHms());
		}		
		if ( tbhMdLineDVO.getLabelWrtCode() != null && !"".equals(tbhMdLineDVO.getLabelWrtCode()) ) {
			tmpTbhMdLineDVO.setLabelWrtCode(tbhMdLineDVO.getLabelWrtCode());
		}		
		if ( tbhMdLineDVO.getTtCalcYn() != null && !"".equals(tbhMdLineDVO.getTtCalcYn()) ) {
			tmpTbhMdLineDVO.setTtCalcYn(tbhMdLineDVO.getTtCalcYn());
		}		
		if ( tbhMdLineDVO.getFnlAcrsReflYn() != null && !"".equals(tbhMdLineDVO.getFnlAcrsReflYn()) ) {
			tmpTbhMdLineDVO.setFnlAcrsReflYn(tbhMdLineDVO.getFnlAcrsReflYn());
		}		
		if ( tbhMdLineDVO.getUseYn() != null && !"".equals(tbhMdLineDVO.getUseYn()) ) {
			tmpTbhMdLineDVO.setUseYn(tbhMdLineDVO.getUseYn());
		}		
		if ( tbhMdLineDVO.getFstRegDt() != null && !"".equals(tbhMdLineDVO.getFstRegDt()) ) {
			tmpTbhMdLineDVO.setFstRegDt(tbhMdLineDVO.getFstRegDt());
		}		
		if ( tbhMdLineDVO.getFstRegerId() != null && !"".equals(tbhMdLineDVO.getFstRegerId()) ) {
			tmpTbhMdLineDVO.setFstRegerId(tbhMdLineDVO.getFstRegerId());
		}		
		if ( tbhMdLineDVO.getFnlUpdDt() != null && !"".equals(tbhMdLineDVO.getFnlUpdDt()) ) {
			tmpTbhMdLineDVO.setFnlUpdDt(tbhMdLineDVO.getFnlUpdDt());
		}		
		if ( tbhMdLineDVO.getFnlUpderId() != null && !"".equals(tbhMdLineDVO.getFnlUpderId()) ) {
			tmpTbhMdLineDVO.setFnlUpderId(tbhMdLineDVO.getFnlUpderId());
		}		
		if ( tbhMdLineDVO.getEvtNm() != null && !"".equals(tbhMdLineDVO.getEvtNm()) ) {
			tmpTbhMdLineDVO.setEvtNm(tbhMdLineDVO.getEvtNm());
		}		
		return updateTbhMdLine (tmpTbhMdLineDVO);
	}

/**
* insertBatchTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return int[]
*/
	@LocalName("insertBatchTbhMdLine")
	public int[] insertBatchTbhMdLine (final List tbhMdLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdLineDEM.insertBatchTbhMdLine.001*/  \n");
			sql.append(" TBH_MD_LINE (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        LINE_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        LINE_FORM_CODE , \n");
			sql.append("        LINE_LOC_DESC , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        TB_GUBUN_CODE , \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        PLAN_MANUAL_CRE_YN , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        WORK_START_HMS , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdLineDVO tbhMdLineDVO = (TbhMdLineDVO)tbhMdLineDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
							ps.setString(psCount++, tbhMdLineDVO.getLineNm());
							ps.setString(psCount++, tbhMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbhMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbhMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbhMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getCellTypeCode());
							ps.setString(psCount++, tbhMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbhMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbhMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbhMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbhMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbhMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdLineDVO.getUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdLineDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbhMdLineDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return int[]
*/
	@LocalName("updateBatchTbhMdLine")
	public int[] updateBatchTbhMdLine (final List tbhMdLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdLineDEM.updateBatchTbhMdLine.001*/  \n");
			sql.append(" TBH_MD_LINE \n");
			sql.append(" SET   \n");
			sql.append("        LINE_NM = ? , \n");
			sql.append("        MFG_PART_CODE = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        LINE_FORM_CODE = ? , \n");
			sql.append("        LINE_LOC_DESC = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        TB_GUBUN_CODE = ? , \n");
			sql.append("        CELL_TYPE_CODE = ? , \n");
			sql.append("        PLAN_MANUAL_CRE_YN = ? , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        WORK_START_HMS = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        TT_CALC_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdLineDVO tbhMdLineDVO = (TbhMdLineDVO)tbhMdLineDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdLineDVO.getLineNm());
							ps.setString(psCount++, tbhMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbhMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbhMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbhMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbhMdLineDVO.getCellTypeCode());
							ps.setString(psCount++, tbhMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbhMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbhMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbhMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbhMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbhMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbhMdLineDVO.getUseYn());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdLineDVO.getEvtNm());

							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdLineDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdLine Method
* 
* @ref_table TBH_MD_LINE
* @return int[]
*/
	@LocalName("deleteBatchTbhMdLine")
	public int[] deleteBatchTbhMdLine (final List tbhMdLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdLineDEM.deleteBatchTbhMdLine.001*/  \n");
			sql.append(" TBH_MD_LINE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdLineDVO tbhMdLineDVO = (TbhMdLineDVO)tbhMdLineDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdLineDVO.getFctCode());
							ps.setString(psCount++, tbhMdLineDVO.getLineCode());
							ps.setString(psCount++, tbhMdLineDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdLineDVOList.size();
							}
					}
		);			
	}

	
}