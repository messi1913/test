package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdLossArtDVO extends AbstractVo {

	@Length(30) 
	private String lossArtCode;

	@Length(2000) 
	private String lossArtDesc;

	@Length(10) 
	private String lossTypeCode;

	@Length(30) 
	private String dutyClsfCode;

	@Length(1) 
	private String prtyReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getLossArtCode() {
		this.lossArtCode = super.getValue(0);
		return this.lossArtCode;
	}

	public void setLossArtCode(String lossArtCode) {
        super.setValue(0, lossArtCode);
		this.lossArtCode = lossArtCode;
	}
	
	public String getLossArtDesc() {
		this.lossArtDesc = super.getValue(1);
		return this.lossArtDesc;
	}

	public void setLossArtDesc(String lossArtDesc) {
        super.setValue(1, lossArtDesc);
		this.lossArtDesc = lossArtDesc;
	}
	
	public String getLossTypeCode() {
		this.lossTypeCode = super.getValue(2);
		return this.lossTypeCode;
	}

	public void setLossTypeCode(String lossTypeCode) {
        super.setValue(2, lossTypeCode);
		this.lossTypeCode = lossTypeCode;
	}
	
	public String getDutyClsfCode() {
		this.dutyClsfCode = super.getValue(3);
		return this.dutyClsfCode;
	}

	public void setDutyClsfCode(String dutyClsfCode) {
        super.setValue(3, dutyClsfCode);
		this.dutyClsfCode = dutyClsfCode;
	}
	
	public String getPrtyReflYn() {
		this.prtyReflYn = super.getValue(4);
		return this.prtyReflYn;
	}

	public void setPrtyReflYn(String prtyReflYn) {
        super.setValue(4, prtyReflYn);
		this.prtyReflYn = prtyReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(5);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(5, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(6);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(6, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(7);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(7, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(8);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(8, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(9);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(9, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}