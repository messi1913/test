package com.samsung.gmes2.md.mmdm.vo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;


/**
* 권역코드
*
* @ref_table  
* @author sjlee
*/
@Stereotype(Stereotype.Dao) @LocalName("권역코드")
public class MdU712M01DQM extends AbstractDAO {


/**
*
* SELECT 
* 	COMM_ORG_CODE, 
* 	HRNK_COMM_ORG_CODE, 
* 	COMM_ORG_TYPE_CODE, 
* 	COMM_ORG_CODE_NM, 
* 	COMM_ORG_CODE_DESC, 
* 	CODE_SORT_PRIOR, 
* 	N1_CODE_ATTR_CONT, 
* 	CIS_MAPP_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPDER_ID, 
* 	FNL_UPD_DT 
* FROM TBC_MD_COMM_ORG 
* WHERE 1=1 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListRegionCode (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	COMM_ORG_CODE,  \n");
			sql.append(" 	HRNK_COMM_ORG_CODE,  \n");
			sql.append(" 	COMM_ORG_TYPE_CODE,  \n");
			sql.append(" 	COMM_ORG_CODE_NM,  \n");
			sql.append(" 	COMM_ORG_CODE_DESC,  \n");
			sql.append(" 	CODE_SORT_PRIOR,  \n");
			sql.append(" 	N1_CODE_ATTR_CONT,  \n");
			sql.append(" 	CIS_MAPP_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPDER_ID,  \n");
			sql.append(" 	FNL_UPD_DT  \n");
			sql.append(" FROM TBC_MD_COMM_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.mmdm.vo.MdU712M01DQM.dListRegionCode.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommOrgDVO returnTbcMdCommOrgDVO = new TbcMdCommOrgDVO();
									returnTbcMdCommOrgDVO.setCommOrgCode(resultSet.getString("COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setHrnkCommOrgCode(resultSet.getString("HRNK_COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgTypeCode(resultSet.getString("COMM_ORG_TYPE_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgCodeNm(resultSet.getString("COMM_ORG_CODE_NM"));
									returnTbcMdCommOrgDVO.setCommOrgCodeDesc(resultSet.getString("COMM_ORG_CODE_DESC"));
									returnTbcMdCommOrgDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommOrgDVO.setN1CodeAttrCont(resultSet.getString("N1_CODE_ATTR_CONT"));
									returnTbcMdCommOrgDVO.setCisMappCode(resultSet.getString("CIS_MAPP_CODE"));
									returnTbcMdCommOrgDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbcMdCommOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									return returnTbcMdCommOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}



}