package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbhMdDataUpdDVO extends AbstractVo {

	@Length(500) 
	private String tabNm;

	@Length(50) 
	private String culmId;

	@Length(17) 
	private String histTsp;

	@Length(30) 
	private String n1KeyValue;

	@Length(30) 
	private String n2KeyValue;

	@Length(30) 
	private String n3KeyValue;

	@Length(30) 
	private String n4KeyValue;

	@Length(30) 
	private String n5KeyValue;

	@Length(2000) 
	private String newDataCont;

	@Length(2000) 
	private String prevDataCont;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getTabNm() {
		this.tabNm = super.getValue(0);
		return this.tabNm;
	}

	public void setTabNm(String tabNm) {
        super.setValue(0, tabNm);
		this.tabNm = tabNm;
	}
	
	public String getCulmId() {
		this.culmId = super.getValue(1);
		return this.culmId;
	}

	public void setCulmId(String culmId) {
        super.setValue(1, culmId);
		this.culmId = culmId;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(2);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(2, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getN1KeyValue() {
		this.n1KeyValue = super.getValue(3);
		return this.n1KeyValue;
	}

	public void setN1KeyValue(String n1KeyValue) {
        super.setValue(3, n1KeyValue);
		this.n1KeyValue = n1KeyValue;
	}
	
	public String getN2KeyValue() {
		this.n2KeyValue = super.getValue(4);
		return this.n2KeyValue;
	}

	public void setN2KeyValue(String n2KeyValue) {
        super.setValue(4, n2KeyValue);
		this.n2KeyValue = n2KeyValue;
	}
	
	public String getN3KeyValue() {
		this.n3KeyValue = super.getValue(5);
		return this.n3KeyValue;
	}

	public void setN3KeyValue(String n3KeyValue) {
        super.setValue(5, n3KeyValue);
		this.n3KeyValue = n3KeyValue;
	}
	
	public String getN4KeyValue() {
		this.n4KeyValue = super.getValue(6);
		return this.n4KeyValue;
	}

	public void setN4KeyValue(String n4KeyValue) {
        super.setValue(6, n4KeyValue);
		this.n4KeyValue = n4KeyValue;
	}
	
	public String getN5KeyValue() {
		this.n5KeyValue = super.getValue(7);
		return this.n5KeyValue;
	}

	public void setN5KeyValue(String n5KeyValue) {
        super.setValue(7, n5KeyValue);
		this.n5KeyValue = n5KeyValue;
	}
	
	public String getNewDataCont() {
		this.newDataCont = super.getValue(8);
		return this.newDataCont;
	}

	public void setNewDataCont(String newDataCont) {
        super.setValue(8, newDataCont);
		this.newDataCont = newDataCont;
	}
	
	public String getPrevDataCont() {
		this.prevDataCont = super.getValue(9);
		return this.prevDataCont;
	}

	public void setPrevDataCont(String prevDataCont) {
        super.setValue(9, prevDataCont);
		this.prevDataCont = prevDataCont;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(10);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(10, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(11);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(11, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(12);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(12, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(13);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(13, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}