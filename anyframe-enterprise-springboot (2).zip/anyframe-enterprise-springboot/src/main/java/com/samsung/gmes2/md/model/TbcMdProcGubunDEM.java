package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PROC_GUBUN
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdProcGubunDEM extends AbstractDAO {


/**
* insertTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return int
*/
	@LocalName("insertTbcMdProcGubun")
	public int insertTbcMdProcGubun (final TbcMdProcGubunDVO tbcMdProcGubunDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.insertTbcMdProcGubun.001*/  \n");
			sql.append(" TBC_MD_PROC_GUBUN (   \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_GUBUN_CODE_NM , \n");
			sql.append("        PROC_GUBUN_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCodeNm());
							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunDesc());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdProcGubun Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdProcGubun Method")
	public int[][] updateBatchAllTbcMdProcGubun (final List  tbcMdProcGubunDVOList) {
		
		ArrayList updatetbcMdProcGubunDVOList = new ArrayList();
		ArrayList insertttbcMdProcGubunDVOList = new ArrayList();
		ArrayList deletetbcMdProcGubunDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdProcGubunDVOList.size() ; i++) {
		  TbcMdProcGubunDVO tbcMdProcGubunDVO = (TbcMdProcGubunDVO) tbcMdProcGubunDVOList.get(i);
		  
		  if (tbcMdProcGubunDVO.getSqlAction().equals("C"))
		      insertttbcMdProcGubunDVOList.add(tbcMdProcGubunDVO);
		  else if (tbcMdProcGubunDVO.getSqlAction().equals("U"))
		      updatetbcMdProcGubunDVOList.add(tbcMdProcGubunDVO);
		  else if (tbcMdProcGubunDVO.getSqlAction().equals("D"))
		      deletetbcMdProcGubunDVOList.add(tbcMdProcGubunDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdProcGubunDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdProcGubun(insertttbcMdProcGubunDVOList);
          
      if (updatetbcMdProcGubunDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdProcGubun(updatetbcMdProcGubunDVOList);
      
      if (deletetbcMdProcGubunDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdProcGubun(deletetbcMdProcGubunDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return int
*/
	@LocalName("updateTbcMdProcGubun")
	public int updateTbcMdProcGubun (final TbcMdProcGubunDVO tbcMdProcGubunDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.updateTbcMdProcGubun.001*/  \n");
			sql.append(" TBC_MD_PROC_GUBUN \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE_NM = ? , \n");
			sql.append("        PROC_GUBUN_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROC_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCodeNm());
							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunDesc());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
						}
					}
		);			
	}

/**
* deleteTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return int
*/
	@LocalName("deleteTbcMdProcGubun")
	public int deleteTbcMdProcGubun (final TbcMdProcGubunDVO tbcMdProcGubunDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.deleteTbcMdProcGubun.001*/  \n");
			sql.append(" TBC_MD_PROC_GUBUN \n");
			sql.append("  WHERE PROC_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
						}
					}
		);			
	}

/**
* selectTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return TbcMdProcGubunDVO 
*/
	@LocalName("selectTbcMdProcGubun")
	public TbcMdProcGubunDVO selectTbcMdProcGubun (final TbcMdProcGubunDVO tbcMdProcGubunDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.selectTbcMdProcGubun.001*/  \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_GUBUN_CODE_NM , \n");
			sql.append("        PROC_GUBUN_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PROC_GUBUN \n");
			sql.append("  WHERE PROC_GUBUN_CODE = ? \n");

		return (TbcMdProcGubunDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdProcGubunDVO returnTbcMdProcGubunDVO = new TbcMdProcGubunDVO();
									returnTbcMdProcGubunDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdProcGubunDVO.setProcGubunCodeNm(resultSet.getString("PROC_GUBUN_CODE_NM"));
									returnTbcMdProcGubunDVO.setProcGubunDesc(resultSet.getString("PROC_GUBUN_DESC"));
									returnTbcMdProcGubunDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProcGubunDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProcGubunDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProcGubunDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProcGubunDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdProcGubun Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdProcGubun Method")
	public int mergeTbcMdProcGubun (final TbcMdProcGubunDVO tbcMdProcGubunDVO) {
		
		if ( selectTbcMdProcGubun (tbcMdProcGubunDVO) == null) {
			return insertTbcMdProcGubun(tbcMdProcGubunDVO);
		} else {
			return selectUpdateTbcMdProcGubun (tbcMdProcGubunDVO);
		}
	}

	/**
	 * selectUpdateTbcMdProcGubun Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdProcGubun Method")
	public int selectUpdateTbcMdProcGubun (final TbcMdProcGubunDVO tbcMdProcGubunDVO) {
		
		TbcMdProcGubunDVO tmpTbcMdProcGubunDVO =  selectTbcMdProcGubun (tbcMdProcGubunDVO);
		if ( tbcMdProcGubunDVO.getProcGubunCode() != null && !"".equals(tbcMdProcGubunDVO.getProcGubunCode()) ) {
			tmpTbcMdProcGubunDVO.setProcGubunCode(tbcMdProcGubunDVO.getProcGubunCode());
		}		
		if ( tbcMdProcGubunDVO.getProcGubunCodeNm() != null && !"".equals(tbcMdProcGubunDVO.getProcGubunCodeNm()) ) {
			tmpTbcMdProcGubunDVO.setProcGubunCodeNm(tbcMdProcGubunDVO.getProcGubunCodeNm());
		}		
		if ( tbcMdProcGubunDVO.getProcGubunDesc() != null && !"".equals(tbcMdProcGubunDVO.getProcGubunDesc()) ) {
			tmpTbcMdProcGubunDVO.setProcGubunDesc(tbcMdProcGubunDVO.getProcGubunDesc());
		}		
		if ( tbcMdProcGubunDVO.getFstRegDt() != null && !"".equals(tbcMdProcGubunDVO.getFstRegDt()) ) {
			tmpTbcMdProcGubunDVO.setFstRegDt(tbcMdProcGubunDVO.getFstRegDt());
		}		
		if ( tbcMdProcGubunDVO.getFstRegerId() != null && !"".equals(tbcMdProcGubunDVO.getFstRegerId()) ) {
			tmpTbcMdProcGubunDVO.setFstRegerId(tbcMdProcGubunDVO.getFstRegerId());
		}		
		if ( tbcMdProcGubunDVO.getFnlUpdDt() != null && !"".equals(tbcMdProcGubunDVO.getFnlUpdDt()) ) {
			tmpTbcMdProcGubunDVO.setFnlUpdDt(tbcMdProcGubunDVO.getFnlUpdDt());
		}		
		if ( tbcMdProcGubunDVO.getFnlUpderId() != null && !"".equals(tbcMdProcGubunDVO.getFnlUpderId()) ) {
			tmpTbcMdProcGubunDVO.setFnlUpderId(tbcMdProcGubunDVO.getFnlUpderId());
		}		
		return updateTbcMdProcGubun (tmpTbcMdProcGubunDVO);
	}

/**
* insertBatchTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return int[]
*/
	@LocalName("insertBatchTbcMdProcGubun")
	public int[] insertBatchTbcMdProcGubun (final List tbcMdProcGubunDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.insertBatchTbcMdProcGubun.001*/  \n");
			sql.append(" TBC_MD_PROC_GUBUN (   \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        PROC_GUBUN_CODE_NM , \n");
			sql.append("        PROC_GUBUN_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProcGubunDVO tbcMdProcGubunDVO = (TbcMdProcGubunDVO)tbcMdProcGubunDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCodeNm());
							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunDesc());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdProcGubunDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return int[]
*/
	@LocalName("updateBatchTbcMdProcGubun")
	public int[] updateBatchTbcMdProcGubun (final List tbcMdProcGubunDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.updateBatchTbcMdProcGubun.001*/  \n");
			sql.append(" TBC_MD_PROC_GUBUN \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE_NM = ? , \n");
			sql.append("        PROC_GUBUN_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROC_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProcGubunDVO tbcMdProcGubunDVO = (TbcMdProcGubunDVO)tbcMdProcGubunDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCodeNm());
							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunDesc());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProcGubunDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
						}
							public int getBatchSize() {
									return tbcMdProcGubunDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdProcGubun Method
* 
* @ref_table TBC_MD_PROC_GUBUN
* @return int[]
*/
	@LocalName("deleteBatchTbcMdProcGubun")
	public int[] deleteBatchTbcMdProcGubun (final List tbcMdProcGubunDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProcGubunDEM.deleteBatchTbcMdProcGubun.001*/  \n");
			sql.append(" TBC_MD_PROC_GUBUN \n");
			sql.append("  WHERE PROC_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProcGubunDVO tbcMdProcGubunDVO = (TbcMdProcGubunDVO)tbcMdProcGubunDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdProcGubunDVO.getProcGubunCode());
						}
							public int getBatchSize() {
									return tbcMdProcGubunDVOList.size();
							}
					}
		);			
	}

	
}