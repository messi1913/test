package com.samsung.gmes2.base.vo;

import java.util.Set;

import com.samsung.gmes2.base.util.BaseUtil;

public class DVO
{
    public static final String      FIELD_FSTREGERID       = "fstRegerId";

    public static final String      FIELD_FSTREGDT         = "fstRegDt";

    public static final String      FIELD_FNLUPDERID       = "fnlUpderId";

    public static final String      FIELD_FNLUPDDT         = "fnlUpdDt";

    public static final String      FIELD_USEYN            = "useYn";

    public static final String      FIELD_DELYN            = "delYn";

    public static final Set<String> FIELDSET_UNPOPULATABLE = BaseUtil.toSet( FIELD_FSTREGERID, FIELD_FSTREGDT, FIELD_FNLUPDERID, FIELD_FNLUPDDT );
}
