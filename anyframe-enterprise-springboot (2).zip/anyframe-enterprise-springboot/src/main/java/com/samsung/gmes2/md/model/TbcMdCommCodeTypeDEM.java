package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_COMM_CODE_TYPE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdCommCodeTypeDEM extends AbstractDAO {


/**
* insertTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return int
*/
	@LocalName("insertTbcMdCommCodeType")
	public int insertTbcMdCommCodeType (final TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.insertTbcMdCommCodeType.001*/  \n");
			sql.append(" TBC_MD_COMM_CODE_TYPE (   \n");
			sql.append("        TYPE_CODE , \n");
			sql.append("        HRNK_TYPE_CODE , \n");
			sql.append("        TYPE_CODE_NM , \n");
			sql.append("        TYPE_CODE_DESC , \n");
			sql.append("        GRP_CODE , \n");
			sql.append("        CODE_SORT_PRIOR , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getHrnkTypeCode());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeNm());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeDesc());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getGrpCode());
							ps.setBigDecimal(psCount++, tbcMdCommCodeTypeDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdCommCodeType Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdCommCodeType Method")
	public int[][] updateBatchAllTbcMdCommCodeType (final List  tbcMdCommCodeTypeDVOList) {
		
		ArrayList updatetbcMdCommCodeTypeDVOList = new ArrayList();
		ArrayList insertttbcMdCommCodeTypeDVOList = new ArrayList();
		ArrayList deletetbcMdCommCodeTypeDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdCommCodeTypeDVOList.size() ; i++) {
		  TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO = (TbcMdCommCodeTypeDVO) tbcMdCommCodeTypeDVOList.get(i);
		  
		  if (tbcMdCommCodeTypeDVO.getSqlAction().equals("C"))
		      insertttbcMdCommCodeTypeDVOList.add(tbcMdCommCodeTypeDVO);
		  else if (tbcMdCommCodeTypeDVO.getSqlAction().equals("U"))
		      updatetbcMdCommCodeTypeDVOList.add(tbcMdCommCodeTypeDVO);
		  else if (tbcMdCommCodeTypeDVO.getSqlAction().equals("D"))
		      deletetbcMdCommCodeTypeDVOList.add(tbcMdCommCodeTypeDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdCommCodeTypeDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdCommCodeType(insertttbcMdCommCodeTypeDVOList);
          
      if (updatetbcMdCommCodeTypeDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdCommCodeType(updatetbcMdCommCodeTypeDVOList);
      
      if (deletetbcMdCommCodeTypeDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdCommCodeType(deletetbcMdCommCodeTypeDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return int
*/
	@LocalName("updateTbcMdCommCodeType")
	public int updateTbcMdCommCodeType (final TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.updateTbcMdCommCodeType.001*/  \n");
			sql.append(" TBC_MD_COMM_CODE_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        HRNK_TYPE_CODE = ? , \n");
			sql.append("        TYPE_CODE_NM = ? , \n");
			sql.append("        TYPE_CODE_DESC = ? , \n");
			sql.append("        GRP_CODE = ? , \n");
			sql.append("        CODE_SORT_PRIOR = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getHrnkTypeCode());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeNm());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeDesc());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getGrpCode());
							ps.setBigDecimal(psCount++, tbcMdCommCodeTypeDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
						}
					}
		);			
	}

/**
* deleteTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return int
*/
	@LocalName("deleteTbcMdCommCodeType")
	public int deleteTbcMdCommCodeType (final TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.deleteTbcMdCommCodeType.001*/  \n");
			sql.append(" TBC_MD_COMM_CODE_TYPE \n");
			sql.append("  WHERE TYPE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
						}
					}
		);			
	}

/**
* selectTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return TbcMdCommCodeTypeDVO 
*/
	@LocalName("selectTbcMdCommCodeType")
	public TbcMdCommCodeTypeDVO selectTbcMdCommCodeType (final TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.selectTbcMdCommCodeType.001*/  \n");
			sql.append("        TYPE_CODE , \n");
			sql.append("        HRNK_TYPE_CODE , \n");
			sql.append("        TYPE_CODE_NM , \n");
			sql.append("        TYPE_CODE_DESC , \n");
			sql.append("        GRP_CODE , \n");
			sql.append("        CODE_SORT_PRIOR , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_COMM_CODE_TYPE \n");
			sql.append("  WHERE TYPE_CODE = ? \n");

		return (TbcMdCommCodeTypeDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdCommCodeTypeDVO returnTbcMdCommCodeTypeDVO = new TbcMdCommCodeTypeDVO();
									returnTbcMdCommCodeTypeDVO.setTypeCode(resultSet.getString("TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setHrnkTypeCode(resultSet.getString("HRNK_TYPE_CODE"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeNm(resultSet.getString("TYPE_CODE_NM"));
									returnTbcMdCommCodeTypeDVO.setTypeCodeDesc(resultSet.getString("TYPE_CODE_DESC"));
									returnTbcMdCommCodeTypeDVO.setGrpCode(resultSet.getString("GRP_CODE"));
									returnTbcMdCommCodeTypeDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommCodeTypeDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommCodeTypeDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommCodeTypeDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommCodeTypeDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommCodeTypeDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommCodeTypeDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdCommCodeType Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdCommCodeType Method")
	public int mergeTbcMdCommCodeType (final TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO) {
		
		if ( selectTbcMdCommCodeType (tbcMdCommCodeTypeDVO) == null) {
			return insertTbcMdCommCodeType(tbcMdCommCodeTypeDVO);
		} else {
			return selectUpdateTbcMdCommCodeType (tbcMdCommCodeTypeDVO);
		}
	}

	/**
	 * selectUpdateTbcMdCommCodeType Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdCommCodeType Method")
	public int selectUpdateTbcMdCommCodeType (final TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO) {
		
		TbcMdCommCodeTypeDVO tmpTbcMdCommCodeTypeDVO =  selectTbcMdCommCodeType (tbcMdCommCodeTypeDVO);
		if ( tbcMdCommCodeTypeDVO.getTypeCode() != null && !"".equals(tbcMdCommCodeTypeDVO.getTypeCode()) ) {
			tmpTbcMdCommCodeTypeDVO.setTypeCode(tbcMdCommCodeTypeDVO.getTypeCode());
		}		
		if ( tbcMdCommCodeTypeDVO.getHrnkTypeCode() != null && !"".equals(tbcMdCommCodeTypeDVO.getHrnkTypeCode()) ) {
			tmpTbcMdCommCodeTypeDVO.setHrnkTypeCode(tbcMdCommCodeTypeDVO.getHrnkTypeCode());
		}		
		if ( tbcMdCommCodeTypeDVO.getTypeCodeNm() != null && !"".equals(tbcMdCommCodeTypeDVO.getTypeCodeNm()) ) {
			tmpTbcMdCommCodeTypeDVO.setTypeCodeNm(tbcMdCommCodeTypeDVO.getTypeCodeNm());
		}		
		if ( tbcMdCommCodeTypeDVO.getTypeCodeDesc() != null && !"".equals(tbcMdCommCodeTypeDVO.getTypeCodeDesc()) ) {
			tmpTbcMdCommCodeTypeDVO.setTypeCodeDesc(tbcMdCommCodeTypeDVO.getTypeCodeDesc());
		}		
		if ( tbcMdCommCodeTypeDVO.getGrpCode() != null && !"".equals(tbcMdCommCodeTypeDVO.getGrpCode()) ) {
			tmpTbcMdCommCodeTypeDVO.setGrpCode(tbcMdCommCodeTypeDVO.getGrpCode());
		}		
		if ( tbcMdCommCodeTypeDVO.getCodeSortPrior() != null && !"".equals(tbcMdCommCodeTypeDVO.getCodeSortPrior()) ) {
			tmpTbcMdCommCodeTypeDVO.setCodeSortPrior(tbcMdCommCodeTypeDVO.getCodeSortPrior());
		}		
		if ( tbcMdCommCodeTypeDVO.getUseYn() != null && !"".equals(tbcMdCommCodeTypeDVO.getUseYn()) ) {
			tmpTbcMdCommCodeTypeDVO.setUseYn(tbcMdCommCodeTypeDVO.getUseYn());
		}		
		if ( tbcMdCommCodeTypeDVO.getFstRegDt() != null && !"".equals(tbcMdCommCodeTypeDVO.getFstRegDt()) ) {
			tmpTbcMdCommCodeTypeDVO.setFstRegDt(tbcMdCommCodeTypeDVO.getFstRegDt());
		}		
		if ( tbcMdCommCodeTypeDVO.getFstRegerId() != null && !"".equals(tbcMdCommCodeTypeDVO.getFstRegerId()) ) {
			tmpTbcMdCommCodeTypeDVO.setFstRegerId(tbcMdCommCodeTypeDVO.getFstRegerId());
		}		
		if ( tbcMdCommCodeTypeDVO.getFnlUpdDt() != null && !"".equals(tbcMdCommCodeTypeDVO.getFnlUpdDt()) ) {
			tmpTbcMdCommCodeTypeDVO.setFnlUpdDt(tbcMdCommCodeTypeDVO.getFnlUpdDt());
		}		
		if ( tbcMdCommCodeTypeDVO.getFnlUpderId() != null && !"".equals(tbcMdCommCodeTypeDVO.getFnlUpderId()) ) {
			tmpTbcMdCommCodeTypeDVO.setFnlUpderId(tbcMdCommCodeTypeDVO.getFnlUpderId());
		}		
		return updateTbcMdCommCodeType (tmpTbcMdCommCodeTypeDVO);
	}

/**
* insertBatchTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return int[]
*/
	@LocalName("insertBatchTbcMdCommCodeType")
	public int[] insertBatchTbcMdCommCodeType (final List tbcMdCommCodeTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.insertBatchTbcMdCommCodeType.001*/  \n");
			sql.append(" TBC_MD_COMM_CODE_TYPE (   \n");
			sql.append("        TYPE_CODE , \n");
			sql.append("        HRNK_TYPE_CODE , \n");
			sql.append("        TYPE_CODE_NM , \n");
			sql.append("        TYPE_CODE_DESC , \n");
			sql.append("        GRP_CODE , \n");
			sql.append("        CODE_SORT_PRIOR , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO = (TbcMdCommCodeTypeDVO)tbcMdCommCodeTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getHrnkTypeCode());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeNm());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeDesc());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getGrpCode());
							ps.setBigDecimal(psCount++, tbcMdCommCodeTypeDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdCommCodeTypeDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return int[]
*/
	@LocalName("updateBatchTbcMdCommCodeType")
	public int[] updateBatchTbcMdCommCodeType (final List tbcMdCommCodeTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.updateBatchTbcMdCommCodeType.001*/  \n");
			sql.append(" TBC_MD_COMM_CODE_TYPE \n");
			sql.append(" SET   \n");
			sql.append("        HRNK_TYPE_CODE = ? , \n");
			sql.append("        TYPE_CODE_NM = ? , \n");
			sql.append("        TYPE_CODE_DESC = ? , \n");
			sql.append("        GRP_CODE = ? , \n");
			sql.append("        CODE_SORT_PRIOR = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO = (TbcMdCommCodeTypeDVO)tbcMdCommCodeTypeDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getHrnkTypeCode());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeNm());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCodeDesc());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getGrpCode());
							ps.setBigDecimal(psCount++, tbcMdCommCodeTypeDVO.getCodeSortPrior());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getUseYn());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
						}
							public int getBatchSize() {
									return tbcMdCommCodeTypeDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdCommCodeType Method
* 
* @ref_table TBC_MD_COMM_CODE_TYPE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdCommCodeType")
	public int[] deleteBatchTbcMdCommCodeType (final List tbcMdCommCodeTypeDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdCommCodeTypeDEM.deleteBatchTbcMdCommCodeType.001*/  \n");
			sql.append(" TBC_MD_COMM_CODE_TYPE \n");
			sql.append("  WHERE TYPE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdCommCodeTypeDVO tbcMdCommCodeTypeDVO = (TbcMdCommCodeTypeDVO)tbcMdCommCodeTypeDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdCommCodeTypeDVO.getTypeCode());
						}
							public int getBatchSize() {
									return tbcMdCommCodeTypeDVOList.size();
							}
					}
		);			
	}

	
}