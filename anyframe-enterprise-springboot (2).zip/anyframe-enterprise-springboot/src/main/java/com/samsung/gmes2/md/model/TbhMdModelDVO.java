package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbhMdModelDVO extends AbstractVo {

	@Length(20) 
	private String modelCode;

	@Length(17) 
	private String histTsp;

	@Length(30) 
	private String prodCode;

	@Length(30) 
	private String prodTypeCode;

	@Length(1000) 
	private String modelDesc;

	@Length(30) 
	private String modelGrpCode;

	@Length(30) 
	private String pjtCode;

	@Length(30) 
	private String devTaskCode;

	@Length(5) @Scale(2) 
	private BigDecimal revVer;

	@Length(30) 
	private String segCode;

	@Length(30) 
	private String basicModelCode;

	@Length(30) 
	private String salModelCode;

	@Length(30) 
	private String eanCode;

	@Length(30) 
	private String upcCode;

	@Length(30) 
	private String kanCode;

	@Length(30) 
	private String domExpGubunCode;

	@Length(1) 
	private String oemYn;

	@Length(1) 
	private String buyerInspYn;

	@Length(1) 
	private String disuseYn;

	@Length(500) 
	private String colorNm;

	@Length(11) @Scale(5) 
	private BigDecimal prodTotalWeit;

	@Length(11) @Scale(5) 
	private BigDecimal prodActuWeit;

	@Length(11) @Scale(5) 
	private BigDecimal prodSize;

	@Length(500) 
	private String chassisNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;

	@Length(50) 
	private String evtNm;


	public String getModelCode() {
		this.modelCode = super.getValue(0);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(0, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(1);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(1, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getProdCode() {
		this.prodCode = super.getValue(2);
		return this.prodCode;
	}

	public void setProdCode(String prodCode) {
        super.setValue(2, prodCode);
		this.prodCode = prodCode;
	}
	
	public String getProdTypeCode() {
		this.prodTypeCode = super.getValue(3);
		return this.prodTypeCode;
	}

	public void setProdTypeCode(String prodTypeCode) {
        super.setValue(3, prodTypeCode);
		this.prodTypeCode = prodTypeCode;
	}
	
	public String getModelDesc() {
		this.modelDesc = super.getValue(4);
		return this.modelDesc;
	}

	public void setModelDesc(String modelDesc) {
        super.setValue(4, modelDesc);
		this.modelDesc = modelDesc;
	}
	
	public String getModelGrpCode() {
		this.modelGrpCode = super.getValue(5);
		return this.modelGrpCode;
	}

	public void setModelGrpCode(String modelGrpCode) {
        super.setValue(5, modelGrpCode);
		this.modelGrpCode = modelGrpCode;
	}
	
	public String getPjtCode() {
		this.pjtCode = super.getValue(6);
		return this.pjtCode;
	}

	public void setPjtCode(String pjtCode) {
        super.setValue(6, pjtCode);
		this.pjtCode = pjtCode;
	}
	
	public String getDevTaskCode() {
		this.devTaskCode = super.getValue(7);
		return this.devTaskCode;
	}

	public void setDevTaskCode(String devTaskCode) {
        super.setValue(7, devTaskCode);
		this.devTaskCode = devTaskCode;
	}
	
	public BigDecimal getRevVer() {
		this.revVer = super.getValue(8);
		return this.revVer;
	}

	public void setRevVer(BigDecimal revVer) {
        super.setValue(8, revVer);
		this.revVer = revVer;
	}
	
	public String getSegCode() {
		this.segCode = super.getValue(9);
		return this.segCode;
	}

	public void setSegCode(String segCode) {
        super.setValue(9, segCode);
		this.segCode = segCode;
	}
	
	public String getBasicModelCode() {
		this.basicModelCode = super.getValue(10);
		return this.basicModelCode;
	}

	public void setBasicModelCode(String basicModelCode) {
        super.setValue(10, basicModelCode);
		this.basicModelCode = basicModelCode;
	}
	
	public String getSalModelCode() {
		this.salModelCode = super.getValue(11);
		return this.salModelCode;
	}

	public void setSalModelCode(String salModelCode) {
        super.setValue(11, salModelCode);
		this.salModelCode = salModelCode;
	}
	
	public String getEanCode() {
		this.eanCode = super.getValue(12);
		return this.eanCode;
	}

	public void setEanCode(String eanCode) {
        super.setValue(12, eanCode);
		this.eanCode = eanCode;
	}
	
	public String getUpcCode() {
		this.upcCode = super.getValue(13);
		return this.upcCode;
	}

	public void setUpcCode(String upcCode) {
        super.setValue(13, upcCode);
		this.upcCode = upcCode;
	}
	
	public String getKanCode() {
		this.kanCode = super.getValue(14);
		return this.kanCode;
	}

	public void setKanCode(String kanCode) {
        super.setValue(14, kanCode);
		this.kanCode = kanCode;
	}
	
	public String getDomExpGubunCode() {
		this.domExpGubunCode = super.getValue(15);
		return this.domExpGubunCode;
	}

	public void setDomExpGubunCode(String domExpGubunCode) {
        super.setValue(15, domExpGubunCode);
		this.domExpGubunCode = domExpGubunCode;
	}
	
	public String getOemYn() {
		this.oemYn = super.getValue(16);
		return this.oemYn;
	}

	public void setOemYn(String oemYn) {
        super.setValue(16, oemYn);
		this.oemYn = oemYn;
	}
	
	public String getBuyerInspYn() {
		this.buyerInspYn = super.getValue(17);
		return this.buyerInspYn;
	}

	public void setBuyerInspYn(String buyerInspYn) {
        super.setValue(17, buyerInspYn);
		this.buyerInspYn = buyerInspYn;
	}
	
	public String getDisuseYn() {
		this.disuseYn = super.getValue(18);
		return this.disuseYn;
	}

	public void setDisuseYn(String disuseYn) {
        super.setValue(18, disuseYn);
		this.disuseYn = disuseYn;
	}
	
	public String getColorNm() {
		this.colorNm = super.getValue(19);
		return this.colorNm;
	}

	public void setColorNm(String colorNm) {
        super.setValue(19, colorNm);
		this.colorNm = colorNm;
	}
	
	public BigDecimal getProdTotalWeit() {
		this.prodTotalWeit = super.getValue(20);
		return this.prodTotalWeit;
	}

	public void setProdTotalWeit(BigDecimal prodTotalWeit) {
        super.setValue(20, prodTotalWeit);
		this.prodTotalWeit = prodTotalWeit;
	}
	
	public BigDecimal getProdActuWeit() {
		this.prodActuWeit = super.getValue(21);
		return this.prodActuWeit;
	}

	public void setProdActuWeit(BigDecimal prodActuWeit) {
        super.setValue(21, prodActuWeit);
		this.prodActuWeit = prodActuWeit;
	}
	
	public BigDecimal getProdSize() {
		this.prodSize = super.getValue(22);
		return this.prodSize;
	}

	public void setProdSize(BigDecimal prodSize) {
        super.setValue(22, prodSize);
		this.prodSize = prodSize;
	}
	
	public String getChassisNm() {
		this.chassisNm = super.getValue(23);
		return this.chassisNm;
	}

	public void setChassisNm(String chassisNm) {
        super.setValue(23, chassisNm);
		this.chassisNm = chassisNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(24);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(24, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(25);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(25, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(26);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(26, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(27);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(27, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(28);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(28, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
	public String getEvtNm() {
		this.evtNm = super.getValue(29);
		return this.evtNm;
	}

	public void setEvtNm(String evtNm) {
        super.setValue(29, evtNm);
		this.evtNm = evtNm;
	}
	
}