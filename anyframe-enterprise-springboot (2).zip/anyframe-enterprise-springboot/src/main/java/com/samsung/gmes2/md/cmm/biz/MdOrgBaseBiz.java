package com.samsung.gmes2.md.cmm.biz;

public class MdOrgBaseBiz {

	/**
	 * 권역 리스트
	 */
	public void listRegionBase(){}

	/**
	 * 국가 리스트
	 */
	public void listNationBase(){}

	/**
	 * 법인 리스트
	 */
	public void listCorpBase(){}

	/**
	 * 사업장 리스트
	 */
	public void listFctBase(){}

	/**
	 * GBM 리스트
	 */
	public void listGbmBase(){}

	/**
	 * Plant 리스트
	 */
	public void listPlantBase(){}

	/**
	 * 제조팀 리스트
	 */
	public void listMfgTeamBase(){}

	/**
	 * 제조그룹 리스트
	 */
	public void listMfgGrpBase(){}

	/**
	 * 제조파트 리스트
	 */
	public void listMfgPartBase(){}

	/**
	 * 라인 리스트
	 */
	public void listLineBase(){}

	/**
	 * 공정구분 리스트
	 */
	public void listProcGubunBase(){}

	/**
	 * 공정타입 리스트
	 */
	public void listProcTypeBase(){}

	/**
	 * 기준공정 리스트
	 */
	public void listBaseProcBase(){}

	/**
	 * 단위공정 리스트
	 */
	public void listUnitProcBase(){}

	/**
	 * Cell 리스트
	 */
	public void listCellBase(){}

}
