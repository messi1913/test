package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdMfgPartDVO extends AbstractVo {

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String mfgPartCode;

	@Length(30) 
	private String mfgTeamCode;

	@Length(30) 
	private String mfgGrpCode;

	@Length(500) 
	private String mfgPartNm;

	@Length(30) 
	private String procGubunCode;

	@Length(30) 
	private String procTypeCode;

	@Length(30) 
	private String labelWrtCode;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue(0);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(0, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getMfgPartCode() {
		this.mfgPartCode = super.getValue(1);
		return this.mfgPartCode;
	}

	public void setMfgPartCode(String mfgPartCode) {
        super.setValue(1, mfgPartCode);
		this.mfgPartCode = mfgPartCode;
	}
	
	public String getMfgTeamCode() {
		this.mfgTeamCode = super.getValue(2);
		return this.mfgTeamCode;
	}

	public void setMfgTeamCode(String mfgTeamCode) {
        super.setValue(2, mfgTeamCode);
		this.mfgTeamCode = mfgTeamCode;
	}
	
	public String getMfgGrpCode() {
		this.mfgGrpCode = super.getValue(3);
		return this.mfgGrpCode;
	}

	public void setMfgGrpCode(String mfgGrpCode) {
        super.setValue(3, mfgGrpCode);
		this.mfgGrpCode = mfgGrpCode;
	}
	
	public String getMfgPartNm() {
		this.mfgPartNm = super.getValue(4);
		return this.mfgPartNm;
	}

	public void setMfgPartNm(String mfgPartNm) {
        super.setValue(4, mfgPartNm);
		this.mfgPartNm = mfgPartNm;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue(5);
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue(5, procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getProcTypeCode() {
		this.procTypeCode = super.getValue(6);
		return this.procTypeCode;
	}

	public void setProcTypeCode(String procTypeCode) {
        super.setValue(6, procTypeCode);
		this.procTypeCode = procTypeCode;
	}
	
	public String getLabelWrtCode() {
		this.labelWrtCode = super.getValue(7);
		return this.labelWrtCode;
	}

	public void setLabelWrtCode(String labelWrtCode) {
        super.setValue(7, labelWrtCode);
		this.labelWrtCode = labelWrtCode;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue(8);
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue(8, fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(9);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(9, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(10);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(10, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(11);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(11, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(12);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(12, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(13);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(13, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}