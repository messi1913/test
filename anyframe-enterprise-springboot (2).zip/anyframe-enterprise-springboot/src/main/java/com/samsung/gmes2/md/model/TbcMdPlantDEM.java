package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PLANT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdPlantDEM extends AbstractDAO {


/**
* insertTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return int
*/
	@LocalName("insertTbcMdPlant")
	public int insertTbcMdPlant (final TbcMdPlantDVO tbcMdPlantDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdPlantDEM.insertTbcMdPlant.001*/  \n");
			sql.append(" TBC_MD_PLANT (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PLANT_NM , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
							ps.setString(psCount++, tbcMdPlantDVO.getFctCode());
							ps.setString(psCount++, tbcMdPlantDVO.getGbmCode());
							ps.setString(psCount++, tbcMdPlantDVO.getPlantNm());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdPlantDVO.getOutsYn());
							ps.setString(psCount++, tbcMdPlantDVO.getUseYn());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdPlant Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdPlant Method")
	public int[][] updateBatchAllTbcMdPlant (final List  tbcMdPlantDVOList) {
		
		ArrayList updatetbcMdPlantDVOList = new ArrayList();
		ArrayList insertttbcMdPlantDVOList = new ArrayList();
		ArrayList deletetbcMdPlantDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdPlantDVOList.size() ; i++) {
		  TbcMdPlantDVO tbcMdPlantDVO = (TbcMdPlantDVO) tbcMdPlantDVOList.get(i);
		  
		  if (tbcMdPlantDVO.getSqlAction().equals("C"))
		      insertttbcMdPlantDVOList.add(tbcMdPlantDVO);
		  else if (tbcMdPlantDVO.getSqlAction().equals("U"))
		      updatetbcMdPlantDVOList.add(tbcMdPlantDVO);
		  else if (tbcMdPlantDVO.getSqlAction().equals("D"))
		      deletetbcMdPlantDVOList.add(tbcMdPlantDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdPlantDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdPlant(insertttbcMdPlantDVOList);
          
      if (updatetbcMdPlantDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdPlant(updatetbcMdPlantDVOList);
      
      if (deletetbcMdPlantDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdPlant(deletetbcMdPlantDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return int
*/
	@LocalName("updateTbcMdPlant")
	public int updateTbcMdPlant (final TbcMdPlantDVO tbcMdPlantDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdPlantDEM.updateTbcMdPlant.001*/  \n");
			sql.append(" TBC_MD_PLANT \n");
			sql.append(" SET   \n");
			sql.append("        FCT_CODE = ? , \n");
			sql.append("        GBM_CODE = ? , \n");
			sql.append("        PLANT_NM = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdPlantDVO.getFctCode());
							ps.setString(psCount++, tbcMdPlantDVO.getGbmCode());
							ps.setString(psCount++, tbcMdPlantDVO.getPlantNm());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdPlantDVO.getOutsYn());
							ps.setString(psCount++, tbcMdPlantDVO.getUseYn());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
						}
					}
		);			
	}

/**
* deleteTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return int
*/
	@LocalName("deleteTbcMdPlant")
	public int deleteTbcMdPlant (final TbcMdPlantDVO tbcMdPlantDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdPlantDEM.deleteTbcMdPlant.001*/  \n");
			sql.append(" TBC_MD_PLANT \n");
			sql.append("  WHERE PLANT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
						}
					}
		);			
	}

/**
* selectTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return TbcMdPlantDVO 
*/
	@LocalName("selectTbcMdPlant")
	public TbcMdPlantDVO selectTbcMdPlant (final TbcMdPlantDVO tbcMdPlantDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdPlantDEM.selectTbcMdPlant.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PLANT_NM , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PLANT \n");
			sql.append("  WHERE PLANT_CODE = ? \n");

		return (TbcMdPlantDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdPlantDVO returnTbcMdPlantDVO = new TbcMdPlantDVO();
									returnTbcMdPlantDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbcMdPlantDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdPlantDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdPlantDVO.setPlantNm(resultSet.getString("PLANT_NM"));
									returnTbcMdPlantDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdPlantDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdPlantDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdPlantDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdPlantDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdPlantDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdPlantDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdPlantDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdPlant Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdPlant Method")
	public int mergeTbcMdPlant (final TbcMdPlantDVO tbcMdPlantDVO) {
		
		if ( selectTbcMdPlant (tbcMdPlantDVO) == null) {
			return insertTbcMdPlant(tbcMdPlantDVO);
		} else {
			return selectUpdateTbcMdPlant (tbcMdPlantDVO);
		}
	}

	/**
	 * selectUpdateTbcMdPlant Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdPlant Method")
	public int selectUpdateTbcMdPlant (final TbcMdPlantDVO tbcMdPlantDVO) {
		
		TbcMdPlantDVO tmpTbcMdPlantDVO =  selectTbcMdPlant (tbcMdPlantDVO);
		if ( tbcMdPlantDVO.getPlantCode() != null && !"".equals(tbcMdPlantDVO.getPlantCode()) ) {
			tmpTbcMdPlantDVO.setPlantCode(tbcMdPlantDVO.getPlantCode());
		}		
		if ( tbcMdPlantDVO.getFctCode() != null && !"".equals(tbcMdPlantDVO.getFctCode()) ) {
			tmpTbcMdPlantDVO.setFctCode(tbcMdPlantDVO.getFctCode());
		}		
		if ( tbcMdPlantDVO.getGbmCode() != null && !"".equals(tbcMdPlantDVO.getGbmCode()) ) {
			tmpTbcMdPlantDVO.setGbmCode(tbcMdPlantDVO.getGbmCode());
		}		
		if ( tbcMdPlantDVO.getPlantNm() != null && !"".equals(tbcMdPlantDVO.getPlantNm()) ) {
			tmpTbcMdPlantDVO.setPlantNm(tbcMdPlantDVO.getPlantNm());
		}		
		if ( tbcMdPlantDVO.getFnlAcrsReflYn() != null && !"".equals(tbcMdPlantDVO.getFnlAcrsReflYn()) ) {
			tmpTbcMdPlantDVO.setFnlAcrsReflYn(tbcMdPlantDVO.getFnlAcrsReflYn());
		}		
		if ( tbcMdPlantDVO.getOutsYn() != null && !"".equals(tbcMdPlantDVO.getOutsYn()) ) {
			tmpTbcMdPlantDVO.setOutsYn(tbcMdPlantDVO.getOutsYn());
		}		
		if ( tbcMdPlantDVO.getUseYn() != null && !"".equals(tbcMdPlantDVO.getUseYn()) ) {
			tmpTbcMdPlantDVO.setUseYn(tbcMdPlantDVO.getUseYn());
		}		
		if ( tbcMdPlantDVO.getFstRegDt() != null && !"".equals(tbcMdPlantDVO.getFstRegDt()) ) {
			tmpTbcMdPlantDVO.setFstRegDt(tbcMdPlantDVO.getFstRegDt());
		}		
		if ( tbcMdPlantDVO.getFstRegerId() != null && !"".equals(tbcMdPlantDVO.getFstRegerId()) ) {
			tmpTbcMdPlantDVO.setFstRegerId(tbcMdPlantDVO.getFstRegerId());
		}		
		if ( tbcMdPlantDVO.getFnlUpdDt() != null && !"".equals(tbcMdPlantDVO.getFnlUpdDt()) ) {
			tmpTbcMdPlantDVO.setFnlUpdDt(tbcMdPlantDVO.getFnlUpdDt());
		}		
		if ( tbcMdPlantDVO.getFnlUpderId() != null && !"".equals(tbcMdPlantDVO.getFnlUpderId()) ) {
			tmpTbcMdPlantDVO.setFnlUpderId(tbcMdPlantDVO.getFnlUpderId());
		}		
		return updateTbcMdPlant (tmpTbcMdPlantDVO);
	}

/**
* insertBatchTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return int[]
*/
	@LocalName("insertBatchTbcMdPlant")
	public int[] insertBatchTbcMdPlant (final List tbcMdPlantDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdPlantDEM.insertBatchTbcMdPlant.001*/  \n");
			sql.append(" TBC_MD_PLANT (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PLANT_NM , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdPlantDVO tbcMdPlantDVO = (TbcMdPlantDVO)tbcMdPlantDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
							ps.setString(psCount++, tbcMdPlantDVO.getFctCode());
							ps.setString(psCount++, tbcMdPlantDVO.getGbmCode());
							ps.setString(psCount++, tbcMdPlantDVO.getPlantNm());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdPlantDVO.getOutsYn());
							ps.setString(psCount++, tbcMdPlantDVO.getUseYn());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdPlantDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return int[]
*/
	@LocalName("updateBatchTbcMdPlant")
	public int[] updateBatchTbcMdPlant (final List tbcMdPlantDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdPlantDEM.updateBatchTbcMdPlant.001*/  \n");
			sql.append(" TBC_MD_PLANT \n");
			sql.append(" SET   \n");
			sql.append("        FCT_CODE = ? , \n");
			sql.append("        GBM_CODE = ? , \n");
			sql.append("        PLANT_NM = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdPlantDVO tbcMdPlantDVO = (TbcMdPlantDVO)tbcMdPlantDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdPlantDVO.getFctCode());
							ps.setString(psCount++, tbcMdPlantDVO.getGbmCode());
							ps.setString(psCount++, tbcMdPlantDVO.getPlantNm());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdPlantDVO.getOutsYn());
							ps.setString(psCount++, tbcMdPlantDVO.getUseYn());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdPlantDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
						}
							public int getBatchSize() {
									return tbcMdPlantDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdPlant Method
* 
* @ref_table TBC_MD_PLANT
* @return int[]
*/
	@LocalName("deleteBatchTbcMdPlant")
	public int[] deleteBatchTbcMdPlant (final List tbcMdPlantDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdPlantDEM.deleteBatchTbcMdPlant.001*/  \n");
			sql.append(" TBC_MD_PLANT \n");
			sql.append("  WHERE PLANT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdPlantDVO tbcMdPlantDVO = (TbcMdPlantDVO)tbcMdPlantDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdPlantDVO.getPlantCode());
						}
							public int getBatchSize() {
									return tbcMdPlantDVOList.size();
							}
					}
		);			
	}

	
}