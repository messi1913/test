package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBS_MC_LBL_NMG_STATE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbsMcLblNmgStateDEM extends AbstractDAO {


/**
* insertTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return int
*/
	@LocalName("insertTbsMcLblNmgState")
	public int insertTbsMcLblNmgState (final TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.insertTbsMcLblNmgState.001*/  \n");
			sql.append(" TBS_MC_LBL_NMG_STATE (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        NMG_RNG_MIN_VALUE , \n");
			sql.append("        NMG_RNG_MAX_VALUE , \n");
			sql.append("        NMG_FNL_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMaxValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgFnlValue());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbsMcLblNmgState Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbsMcLblNmgState Method")
	public int[][] updateBatchAllTbsMcLblNmgState (final List  tbsMcLblNmgStateDVOList) {
		
		ArrayList updatetbsMcLblNmgStateDVOList = new ArrayList();
		ArrayList insertttbsMcLblNmgStateDVOList = new ArrayList();
		ArrayList deletetbsMcLblNmgStateDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbsMcLblNmgStateDVOList.size() ; i++) {
		  TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO = (TbsMcLblNmgStateDVO) tbsMcLblNmgStateDVOList.get(i);
		  
		  if (tbsMcLblNmgStateDVO.getSqlAction().equals("C"))
		      insertttbsMcLblNmgStateDVOList.add(tbsMcLblNmgStateDVO);
		  else if (tbsMcLblNmgStateDVO.getSqlAction().equals("U"))
		      updatetbsMcLblNmgStateDVOList.add(tbsMcLblNmgStateDVO);
		  else if (tbsMcLblNmgStateDVO.getSqlAction().equals("D"))
		      deletetbsMcLblNmgStateDVOList.add(tbsMcLblNmgStateDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbsMcLblNmgStateDVOList.size() > 0) 
          resultValues[0] = insertBatchTbsMcLblNmgState(insertttbsMcLblNmgStateDVOList);
          
      if (updatetbsMcLblNmgStateDVOList.size() >0)
          resultValues[1] = updateBatchTbsMcLblNmgState(updatetbsMcLblNmgStateDVOList);
      
      if (deletetbsMcLblNmgStateDVOList.size() >0)
          resultValues[2] = deleteBatchTbsMcLblNmgState(deletetbsMcLblNmgStateDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return int
*/
	@LocalName("updateTbsMcLblNmgState")
	public int updateTbsMcLblNmgState (final TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.updateTbsMcLblNmgState.001*/  \n");
			sql.append(" TBS_MC_LBL_NMG_STATE \n");
			sql.append(" SET   \n");
			sql.append("        NMG_RNG_MIN_VALUE = ? , \n");
			sql.append("        NMG_RNG_MAX_VALUE = ? , \n");
			sql.append("        NMG_FNL_VALUE = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND NMG_KEY_VALUE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMaxValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgFnlValue());

							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
						}
					}
		);			
	}

/**
* deleteTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return int
*/
	@LocalName("deleteTbsMcLblNmgState")
	public int deleteTbsMcLblNmgState (final TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.deleteTbsMcLblNmgState.001*/  \n");
			sql.append(" TBS_MC_LBL_NMG_STATE \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND NMG_KEY_VALUE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
						}
					}
		);			
	}

/**
* selectTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return TbsMcLblNmgStateDVO 
*/
	@LocalName("selectTbsMcLblNmgState")
	public TbsMcLblNmgStateDVO selectTbsMcLblNmgState (final TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.selectTbsMcLblNmgState.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        NMG_RNG_MIN_VALUE , \n");
			sql.append("        NMG_RNG_MAX_VALUE , \n");
			sql.append("        NMG_FNL_VALUE \n");
			sql.append("   FROM TBS_MC_LBL_NMG_STATE \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND NMG_KEY_VALUE = ? \n");

		return (TbsMcLblNmgStateDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbsMcLblNmgStateDVO returnTbsMcLblNmgStateDVO = new TbsMcLblNmgStateDVO();
									returnTbsMcLblNmgStateDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbsMcLblNmgStateDVO.setNmgKeyValue(resultSet.getString("NMG_KEY_VALUE"));
									returnTbsMcLblNmgStateDVO.setNmgRngMinValue(resultSet.getBigDecimal("NMG_RNG_MIN_VALUE"));
									returnTbsMcLblNmgStateDVO.setNmgRngMaxValue(resultSet.getBigDecimal("NMG_RNG_MAX_VALUE"));
									returnTbsMcLblNmgStateDVO.setNmgFnlValue(resultSet.getBigDecimal("NMG_FNL_VALUE"));
									return returnTbsMcLblNmgStateDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbsMcLblNmgState Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbsMcLblNmgState Method")
	public int mergeTbsMcLblNmgState (final TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO) {
		
		if ( selectTbsMcLblNmgState (tbsMcLblNmgStateDVO) == null) {
			return insertTbsMcLblNmgState(tbsMcLblNmgStateDVO);
		} else {
			return selectUpdateTbsMcLblNmgState (tbsMcLblNmgStateDVO);
		}
	}

	/**
	 * selectUpdateTbsMcLblNmgState Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbsMcLblNmgState Method")
	public int selectUpdateTbsMcLblNmgState (final TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO) {
		
		TbsMcLblNmgStateDVO tmpTbsMcLblNmgStateDVO =  selectTbsMcLblNmgState (tbsMcLblNmgStateDVO);
		if ( tbsMcLblNmgStateDVO.getPlantCode() != null && !"".equals(tbsMcLblNmgStateDVO.getPlantCode()) ) {
			tmpTbsMcLblNmgStateDVO.setPlantCode(tbsMcLblNmgStateDVO.getPlantCode());
		}		
		if ( tbsMcLblNmgStateDVO.getNmgKeyValue() != null && !"".equals(tbsMcLblNmgStateDVO.getNmgKeyValue()) ) {
			tmpTbsMcLblNmgStateDVO.setNmgKeyValue(tbsMcLblNmgStateDVO.getNmgKeyValue());
		}		
		if ( tbsMcLblNmgStateDVO.getNmgRngMinValue() != null && !"".equals(tbsMcLblNmgStateDVO.getNmgRngMinValue()) ) {
			tmpTbsMcLblNmgStateDVO.setNmgRngMinValue(tbsMcLblNmgStateDVO.getNmgRngMinValue());
		}		
		if ( tbsMcLblNmgStateDVO.getNmgRngMaxValue() != null && !"".equals(tbsMcLblNmgStateDVO.getNmgRngMaxValue()) ) {
			tmpTbsMcLblNmgStateDVO.setNmgRngMaxValue(tbsMcLblNmgStateDVO.getNmgRngMaxValue());
		}		
		if ( tbsMcLblNmgStateDVO.getNmgFnlValue() != null && !"".equals(tbsMcLblNmgStateDVO.getNmgFnlValue()) ) {
			tmpTbsMcLblNmgStateDVO.setNmgFnlValue(tbsMcLblNmgStateDVO.getNmgFnlValue());
		}		
		return updateTbsMcLblNmgState (tmpTbsMcLblNmgStateDVO);
	}

/**
* insertBatchTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return int[]
*/
	@LocalName("insertBatchTbsMcLblNmgState")
	public int[] insertBatchTbsMcLblNmgState (final List tbsMcLblNmgStateDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.insertBatchTbsMcLblNmgState.001*/  \n");
			sql.append(" TBS_MC_LBL_NMG_STATE (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        NMG_RNG_MIN_VALUE , \n");
			sql.append("        NMG_RNG_MAX_VALUE , \n");
			sql.append("        NMG_FNL_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO = (TbsMcLblNmgStateDVO)tbsMcLblNmgStateDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMaxValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgFnlValue());

						}
							public int getBatchSize() {
									return tbsMcLblNmgStateDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return int[]
*/
	@LocalName("updateBatchTbsMcLblNmgState")
	public int[] updateBatchTbsMcLblNmgState (final List tbsMcLblNmgStateDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.updateBatchTbsMcLblNmgState.001*/  \n");
			sql.append(" TBS_MC_LBL_NMG_STATE \n");
			sql.append(" SET   \n");
			sql.append("        NMG_RNG_MIN_VALUE = ? , \n");
			sql.append("        NMG_RNG_MAX_VALUE = ? , \n");
			sql.append("        NMG_FNL_VALUE = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND NMG_KEY_VALUE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO = (TbsMcLblNmgStateDVO)tbsMcLblNmgStateDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMinValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgRngMaxValue());
							ps.setBigDecimal(psCount++, tbsMcLblNmgStateDVO.getNmgFnlValue());

							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
						}
							public int getBatchSize() {
									return tbsMcLblNmgStateDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbsMcLblNmgState Method
* 
* @ref_table TBS_MC_LBL_NMG_STATE
* @return int[]
*/
	@LocalName("deleteBatchTbsMcLblNmgState")
	public int[] deleteBatchTbsMcLblNmgState (final List tbsMcLblNmgStateDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbsMcLblNmgStateDEM.deleteBatchTbsMcLblNmgState.001*/  \n");
			sql.append(" TBS_MC_LBL_NMG_STATE \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND NMG_KEY_VALUE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbsMcLblNmgStateDVO tbsMcLblNmgStateDVO = (TbsMcLblNmgStateDVO)tbsMcLblNmgStateDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbsMcLblNmgStateDVO.getPlantCode());
							ps.setString(psCount++, tbsMcLblNmgStateDVO.getNmgKeyValue());
						}
							public int getBatchSize() {
									return tbsMcLblNmgStateDVOList.size();
							}
					}
		);			
	}

	
}