package com.samsung.gmes2.md.loss.biz;

public class MdManageDeviCauseBiz {

	/**
	 * 이탈원인코드 목록 조회
	 */
	public void listDeviCauseCode(){}

	/**
	 * 이탈원인코드 목록 저장
	 */
	public void saveDeviCauseCode(){}

}
