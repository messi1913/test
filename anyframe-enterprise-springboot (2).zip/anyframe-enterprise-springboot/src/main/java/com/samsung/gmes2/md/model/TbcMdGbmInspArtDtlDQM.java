package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author hkw
*/
@Stereotype(Stereotype.Dao)
public class TbcMdGbmInspArtDtlDQM extends AbstractDAO {


/**
*
* SELECT 
* 	GBM_CODE, 
* 	INSP_ART_DTL_CODE, 
* 	PROC_OUT_GUBUN_CODE, 
* 	INSP_ART_CODE, 
* 	INSP_ART_DTL_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_GBM_INSP_ART_DTL 
* WHERE 1=1 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($inspArtDtlCode) 
* AND INSP_ART_DTL_CODE = :inspArtDtlCode 
* #end 
* #if($procOutGubunCode) 
* AND PROC_OUT_GUBUN_CODE = :procOutGubunCode 
* #end 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtDtlNm) 
* AND INSP_ART_DTL_NM = :inspArtDtlNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	INSP_ART_DTL_CODE,  \n");
			sql.append(" 	PROC_OUT_GUBUN_CODE,  \n");
			sql.append(" 	INSP_ART_CODE,  \n");
			sql.append(" 	INSP_ART_DTL_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_GBM_INSP_ART_DTL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlCode)  \n");
			sql.append(" AND INSP_ART_DTL_CODE = :inspArtDtlCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procOutGubunCode)  \n");
			sql.append(" AND PROC_OUT_GUBUN_CODE = :procOutGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlNm)  \n");
			sql.append(" AND INSP_ART_DTL_NM = :inspArtDtlNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdGbmInspArtDtlDVO returnTbcMdGbmInspArtDtlDVO = new TbcMdGbmInspArtDtlDVO();
									returnTbcMdGbmInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlNm(resultSet.getString("INSP_ART_DTL_NM"));
									returnTbcMdGbmInspArtDtlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdGbmInspArtDtlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdGbmInspArtDtlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdGbmInspArtDtlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdGbmInspArtDtlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdGbmInspArtDtlDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	GBM_CODE, 
* 	INSP_ART_DTL_CODE, 
* 	PROC_OUT_GUBUN_CODE, 
* 	INSP_ART_CODE
* FROM TBC_MD_GBM_INSP_ART_DTL 
* WHERE 1=1 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($inspArtDtlCode) 
* AND INSP_ART_DTL_CODE = :inspArtDtlCode 
* #end 
* #if($procOutGubunCode) 
* AND PROC_OUT_GUBUN_CODE = :procOutGubunCode 
* #end 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtDtlNm) 
* AND INSP_ART_DTL_NM = :inspArtDtlNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	INSP_ART_DTL_CODE,  \n");
			sql.append(" 	PROC_OUT_GUBUN_CODE,  \n");
			sql.append(" 	INSP_ART_CODE \n");
			sql.append(" FROM TBC_MD_GBM_INSP_ART_DTL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlCode)  \n");
			sql.append(" AND INSP_ART_DTL_CODE = :inspArtDtlCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procOutGubunCode)  \n");
			sql.append(" AND PROC_OUT_GUBUN_CODE = :procOutGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlNm)  \n");
			sql.append(" AND INSP_ART_DTL_NM = :inspArtDtlNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdGbmInspArtDtlDVO returnTbcMdGbmInspArtDtlDVO = new TbcMdGbmInspArtDtlDVO();
									returnTbcMdGbmInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									return returnTbcMdGbmInspArtDtlDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	GBM_CODE, 
* 	INSP_ART_DTL_CODE, 
* 	PROC_OUT_GUBUN_CODE, 
* 	INSP_ART_CODE, 
* 	INSP_ART_DTL_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_GBM_INSP_ART_DTL 
* WHERE 1=1 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($inspArtDtlCode) 
* AND INSP_ART_DTL_CODE = :inspArtDtlCode 
* #end 
* #if($procOutGubunCode) 
* AND PROC_OUT_GUBUN_CODE = :procOutGubunCode 
* #end 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtDtlNm) 
* AND INSP_ART_DTL_NM = :inspArtDtlNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	INSP_ART_DTL_CODE,  \n");
			sql.append(" 	PROC_OUT_GUBUN_CODE,  \n");
			sql.append(" 	INSP_ART_CODE,  \n");
			sql.append(" 	INSP_ART_DTL_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_GBM_INSP_ART_DTL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlCode)  \n");
			sql.append(" AND INSP_ART_DTL_CODE = :inspArtDtlCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procOutGubunCode)  \n");
			sql.append(" AND PROC_OUT_GUBUN_CODE = :procOutGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlNm)  \n");
			sql.append(" AND INSP_ART_DTL_NM = :inspArtDtlNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdGbmInspArtDtlDVO returnTbcMdGbmInspArtDtlDVO = new TbcMdGbmInspArtDtlDVO();
									returnTbcMdGbmInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlNm(resultSet.getString("INSP_ART_DTL_NM"));
									returnTbcMdGbmInspArtDtlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdGbmInspArtDtlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdGbmInspArtDtlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdGbmInspArtDtlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdGbmInspArtDtlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdGbmInspArtDtlDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	GBM_CODE, 
* 	INSP_ART_DTL_CODE, 
* 	PROC_OUT_GUBUN_CODE, 
* 	INSP_ART_CODE
* FROM TBC_MD_GBM_INSP_ART_DTL 
* WHERE 1=1 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($inspArtDtlCode) 
* AND INSP_ART_DTL_CODE = :inspArtDtlCode 
* #end 
* #if($procOutGubunCode) 
* AND PROC_OUT_GUBUN_CODE = :procOutGubunCode 
* #end 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtDtlNm) 
* AND INSP_ART_DTL_NM = :inspArtDtlNm 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	INSP_ART_DTL_CODE,  \n");
			sql.append(" 	PROC_OUT_GUBUN_CODE,  \n");
			sql.append(" 	INSP_ART_CODE \n");
			sql.append(" FROM TBC_MD_GBM_INSP_ART_DTL  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlCode)  \n");
			sql.append(" AND INSP_ART_DTL_CODE = :inspArtDtlCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procOutGubunCode)  \n");
			sql.append(" AND PROC_OUT_GUBUN_CODE = :procOutGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtDtlNm)  \n");
			sql.append(" AND INSP_ART_DTL_NM = :inspArtDtlNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdGbmInspArtDtlDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdGbmInspArtDtlDVO returnTbcMdGbmInspArtDtlDVO = new TbcMdGbmInspArtDtlDVO();
									returnTbcMdGbmInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbcMdGbmInspArtDtlDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									return returnTbcMdGbmInspArtDtlDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}