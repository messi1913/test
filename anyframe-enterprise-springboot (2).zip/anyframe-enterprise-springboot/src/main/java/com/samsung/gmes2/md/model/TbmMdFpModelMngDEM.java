package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_FP_MODEL_MNG
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdFpModelMngDEM extends AbstractDAO {


/**
* insertTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return int
*/
	@LocalName("insertTbmMdFpModelMng")
	public int insertTbmMdFpModelMng (final TbmMdFpModelMngDVO tbmMdFpModelMngDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.insertTbmMdFpModelMng.001*/  \n");
			sql.append(" TBM_MD_FP_MODEL_MNG (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        FPRF_SKIP_YN , \n");
			sql.append("        FPRF_MODEL_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfSkipYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfModelDesc());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdFpModelMng Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdFpModelMng Method")
	public int[][] updateBatchAllTbmMdFpModelMng (final List  tbmMdFpModelMngDVOList) {
		
		ArrayList updatetbmMdFpModelMngDVOList = new ArrayList();
		ArrayList insertttbmMdFpModelMngDVOList = new ArrayList();
		ArrayList deletetbmMdFpModelMngDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdFpModelMngDVOList.size() ; i++) {
		  TbmMdFpModelMngDVO tbmMdFpModelMngDVO = (TbmMdFpModelMngDVO) tbmMdFpModelMngDVOList.get(i);
		  
		  if (tbmMdFpModelMngDVO.getSqlAction().equals("C"))
		      insertttbmMdFpModelMngDVOList.add(tbmMdFpModelMngDVO);
		  else if (tbmMdFpModelMngDVO.getSqlAction().equals("U"))
		      updatetbmMdFpModelMngDVOList.add(tbmMdFpModelMngDVO);
		  else if (tbmMdFpModelMngDVO.getSqlAction().equals("D"))
		      deletetbmMdFpModelMngDVOList.add(tbmMdFpModelMngDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdFpModelMngDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdFpModelMng(insertttbmMdFpModelMngDVOList);
          
      if (updatetbmMdFpModelMngDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdFpModelMng(updatetbmMdFpModelMngDVOList);
      
      if (deletetbmMdFpModelMngDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdFpModelMng(deletetbmMdFpModelMngDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return int
*/
	@LocalName("updateTbmMdFpModelMng")
	public int updateTbmMdFpModelMng (final TbmMdFpModelMngDVO tbmMdFpModelMngDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.updateTbmMdFpModelMng.001*/  \n");
			sql.append(" TBM_MD_FP_MODEL_MNG \n");
			sql.append(" SET   \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        FPRF_SKIP_YN = ? , \n");
			sql.append("        FPRF_MODEL_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfSkipYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfModelDesc());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
						}
					}
		);			
	}

/**
* deleteTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return int
*/
	@LocalName("deleteTbmMdFpModelMng")
	public int deleteTbmMdFpModelMng (final TbmMdFpModelMngDVO tbmMdFpModelMngDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.deleteTbmMdFpModelMng.001*/  \n");
			sql.append(" TBM_MD_FP_MODEL_MNG \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
						}
					}
		);			
	}

/**
* selectTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return TbmMdFpModelMngDVO 
*/
	@LocalName("selectTbmMdFpModelMng")
	public TbmMdFpModelMngDVO selectTbmMdFpModelMng (final TbmMdFpModelMngDVO tbmMdFpModelMngDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.selectTbmMdFpModelMng.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        FPRF_SKIP_YN , \n");
			sql.append("        FPRF_MODEL_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_FP_MODEL_MNG \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return (TbmMdFpModelMngDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdFpModelMngDVO returnTbmMdFpModelMngDVO = new TbmMdFpModelMngDVO();
									returnTbmMdFpModelMngDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdFpModelMngDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdFpModelMngDVO.setFprfAplyYn(resultSet.getString("FPRF_APLY_YN"));
									returnTbmMdFpModelMngDVO.setFprfSkipYn(resultSet.getString("FPRF_SKIP_YN"));
									returnTbmMdFpModelMngDVO.setFprfModelDesc(resultSet.getString("FPRF_MODEL_DESC"));
									returnTbmMdFpModelMngDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdFpModelMngDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdFpModelMngDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdFpModelMngDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdFpModelMngDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdFpModelMng Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdFpModelMng Method")
	public int mergeTbmMdFpModelMng (final TbmMdFpModelMngDVO tbmMdFpModelMngDVO) {
		
		if ( selectTbmMdFpModelMng (tbmMdFpModelMngDVO) == null) {
			return insertTbmMdFpModelMng(tbmMdFpModelMngDVO);
		} else {
			return selectUpdateTbmMdFpModelMng (tbmMdFpModelMngDVO);
		}
	}

	/**
	 * selectUpdateTbmMdFpModelMng Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdFpModelMng Method")
	public int selectUpdateTbmMdFpModelMng (final TbmMdFpModelMngDVO tbmMdFpModelMngDVO) {
		
		TbmMdFpModelMngDVO tmpTbmMdFpModelMngDVO =  selectTbmMdFpModelMng (tbmMdFpModelMngDVO);
		if ( tbmMdFpModelMngDVO.getPlantCode() != null && !"".equals(tbmMdFpModelMngDVO.getPlantCode()) ) {
			tmpTbmMdFpModelMngDVO.setPlantCode(tbmMdFpModelMngDVO.getPlantCode());
		}		
		if ( tbmMdFpModelMngDVO.getModelCode() != null && !"".equals(tbmMdFpModelMngDVO.getModelCode()) ) {
			tmpTbmMdFpModelMngDVO.setModelCode(tbmMdFpModelMngDVO.getModelCode());
		}		
		if ( tbmMdFpModelMngDVO.getFprfAplyYn() != null && !"".equals(tbmMdFpModelMngDVO.getFprfAplyYn()) ) {
			tmpTbmMdFpModelMngDVO.setFprfAplyYn(tbmMdFpModelMngDVO.getFprfAplyYn());
		}		
		if ( tbmMdFpModelMngDVO.getFprfSkipYn() != null && !"".equals(tbmMdFpModelMngDVO.getFprfSkipYn()) ) {
			tmpTbmMdFpModelMngDVO.setFprfSkipYn(tbmMdFpModelMngDVO.getFprfSkipYn());
		}		
		if ( tbmMdFpModelMngDVO.getFprfModelDesc() != null && !"".equals(tbmMdFpModelMngDVO.getFprfModelDesc()) ) {
			tmpTbmMdFpModelMngDVO.setFprfModelDesc(tbmMdFpModelMngDVO.getFprfModelDesc());
		}		
		if ( tbmMdFpModelMngDVO.getFstRegDt() != null && !"".equals(tbmMdFpModelMngDVO.getFstRegDt()) ) {
			tmpTbmMdFpModelMngDVO.setFstRegDt(tbmMdFpModelMngDVO.getFstRegDt());
		}		
		if ( tbmMdFpModelMngDVO.getFstRegerId() != null && !"".equals(tbmMdFpModelMngDVO.getFstRegerId()) ) {
			tmpTbmMdFpModelMngDVO.setFstRegerId(tbmMdFpModelMngDVO.getFstRegerId());
		}		
		if ( tbmMdFpModelMngDVO.getFnlUpdDt() != null && !"".equals(tbmMdFpModelMngDVO.getFnlUpdDt()) ) {
			tmpTbmMdFpModelMngDVO.setFnlUpdDt(tbmMdFpModelMngDVO.getFnlUpdDt());
		}		
		if ( tbmMdFpModelMngDVO.getFnlUpderId() != null && !"".equals(tbmMdFpModelMngDVO.getFnlUpderId()) ) {
			tmpTbmMdFpModelMngDVO.setFnlUpderId(tbmMdFpModelMngDVO.getFnlUpderId());
		}		
		return updateTbmMdFpModelMng (tmpTbmMdFpModelMngDVO);
	}

/**
* insertBatchTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return int[]
*/
	@LocalName("insertBatchTbmMdFpModelMng")
	public int[] insertBatchTbmMdFpModelMng (final List tbmMdFpModelMngDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.insertBatchTbmMdFpModelMng.001*/  \n");
			sql.append(" TBM_MD_FP_MODEL_MNG (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        FPRF_SKIP_YN , \n");
			sql.append("        FPRF_MODEL_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdFpModelMngDVO tbmMdFpModelMngDVO = (TbmMdFpModelMngDVO)tbmMdFpModelMngDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfSkipYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfModelDesc());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdFpModelMngDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return int[]
*/
	@LocalName("updateBatchTbmMdFpModelMng")
	public int[] updateBatchTbmMdFpModelMng (final List tbmMdFpModelMngDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.updateBatchTbmMdFpModelMng.001*/  \n");
			sql.append(" TBM_MD_FP_MODEL_MNG \n");
			sql.append(" SET   \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        FPRF_SKIP_YN = ? , \n");
			sql.append("        FPRF_MODEL_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdFpModelMngDVO tbmMdFpModelMngDVO = (TbmMdFpModelMngDVO)tbmMdFpModelMngDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfSkipYn());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFprfModelDesc());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdFpModelMngDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdFpModelMng Method
* 
* @ref_table TBM_MD_FP_MODEL_MNG
* @return int[]
*/
	@LocalName("deleteBatchTbmMdFpModelMng")
	public int[] deleteBatchTbmMdFpModelMng (final List tbmMdFpModelMngDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdFpModelMngDEM.deleteBatchTbmMdFpModelMng.001*/  \n");
			sql.append(" TBM_MD_FP_MODEL_MNG \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdFpModelMngDVO tbmMdFpModelMngDVO = (TbmMdFpModelMngDVO)tbmMdFpModelMngDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdFpModelMngDVO.getPlantCode());
							ps.setString(psCount++, tbmMdFpModelMngDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdFpModelMngDVOList.size();
							}
					}
		);			
	}

	
}