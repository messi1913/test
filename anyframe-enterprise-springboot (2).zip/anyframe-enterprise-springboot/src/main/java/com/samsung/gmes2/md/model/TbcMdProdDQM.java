package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* TbcMdProdDQM
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao) @LocalName("TbcMdProdDQM")
public class TbcMdProdDQM extends AbstractDAO {


/**
* 
*
* SELECT 
* 	PROD_CODE, 
* 	PROD_ABBR_CODE, 
* 	PROD_NM, 
* 	CLS_TYPE_NM, 
* 	TT_CALC_YN, 
* 	PBA_DEFT_SUMR_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PROD 
* WHERE 1=1 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodAbbrCode) 
* AND PROD_ABBR_CODE = :prodAbbrCode 
* #end 
* #if($prodNm) 
* AND PROD_NM = :prodNm 
* #end 
* #if($prodNmLike) 
* AND PROD_NM like '%' || :prodNmLike || '%' 
* #end 
* #if($clsTypeNm) 
* AND CLS_TYPE_NM = :clsTypeNm 
* #end 
* #if($clsTypeNmLike) 
* AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%' 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($pbaDeftSumrYn) 
* AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_ABBR_CODE,  \n");
			sql.append(" 	PROD_NM,  \n");
			sql.append(" 	CLS_TYPE_NM,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	PBA_DEFT_SUMR_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PROD  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodAbbrCode)  \n");
			sql.append(" AND PROD_ABBR_CODE = :prodAbbrCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNm)  \n");
			sql.append(" AND PROD_NM = :prodNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNmLike)  \n");
			sql.append(" AND PROD_NM like '%' || :prodNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNm)  \n");
			sql.append(" AND CLS_TYPE_NM = :clsTypeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNmLike)  \n");
			sql.append(" AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pbaDeftSumrYn)  \n");
			sql.append(" AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProdDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProdDVO returnTbcMdProdDVO = new TbcMdProdDVO();
									returnTbcMdProdDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbcMdProdDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbcMdProdDVO.setProdNm(resultSet.getString("PROD_NM"));
									returnTbcMdProdDVO.setClsTypeNm(resultSet.getString("CLS_TYPE_NM"));
									returnTbcMdProdDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbcMdProdDVO.setPbaDeftSumrYn(resultSet.getString("PBA_DEFT_SUMR_YN"));
									returnTbcMdProdDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	PROD_CODE, 
* 	PROD_ABBR_CODE, 
* 	PROD_NM, 
* 	CLS_TYPE_NM, 
* 	TT_CALC_YN, 
* 	PBA_DEFT_SUMR_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PROD 
* WHERE 1=1 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodAbbrCode) 
* AND PROD_ABBR_CODE = :prodAbbrCode 
* #end 
* #if($prodNm) 
* AND PROD_NM = :prodNm 
* #end 
* #if($prodNmLike) 
* AND PROD_NM like '%' || :prodNmLike || '%' 
* #end 
* #if($clsTypeNm) 
* AND CLS_TYPE_NM = :clsTypeNm 
* #end 
* #if($clsTypeNmLike) 
* AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%' 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($pbaDeftSumrYn) 
* AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_ABBR_CODE,  \n");
			sql.append(" 	PROD_NM,  \n");
			sql.append(" 	CLS_TYPE_NM,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	PBA_DEFT_SUMR_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PROD  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodAbbrCode)  \n");
			sql.append(" AND PROD_ABBR_CODE = :prodAbbrCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNm)  \n");
			sql.append(" AND PROD_NM = :prodNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNmLike)  \n");
			sql.append(" AND PROD_NM like '%' || :prodNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNm)  \n");
			sql.append(" AND CLS_TYPE_NM = :clsTypeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNmLike)  \n");
			sql.append(" AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pbaDeftSumrYn)  \n");
			sql.append(" AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProdDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProdDVO returnTbcMdProdDVO = new TbcMdProdDVO();
									returnTbcMdProdDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbcMdProdDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbcMdProdDVO.setProdNm(resultSet.getString("PROD_NM"));
									returnTbcMdProdDVO.setClsTypeNm(resultSet.getString("CLS_TYPE_NM"));
									returnTbcMdProdDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbcMdProdDVO.setPbaDeftSumrYn(resultSet.getString("PBA_DEFT_SUMR_YN"));
									returnTbcMdProdDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	PROD_CODE, 
* 	PROD_ABBR_CODE, 
* 	PROD_NM, 
* 	CLS_TYPE_NM, 
* 	TT_CALC_YN, 
* 	PBA_DEFT_SUMR_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PROD 
* WHERE 1=1 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodAbbrCode) 
* AND PROD_ABBR_CODE = :prodAbbrCode 
* #end 
* #if($prodNm) 
* AND PROD_NM = :prodNm 
* #end 
* #if($prodNmLike) 
* AND PROD_NM like '%' || :prodNmLike || '%' 
* #end 
* #if($clsTypeNm) 
* AND CLS_TYPE_NM = :clsTypeNm 
* #end 
* #if($clsTypeNmLike) 
* AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%' 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($pbaDeftSumrYn) 
* AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_ABBR_CODE,  \n");
			sql.append(" 	PROD_NM,  \n");
			sql.append(" 	CLS_TYPE_NM,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	PBA_DEFT_SUMR_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PROD  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodAbbrCode)  \n");
			sql.append(" AND PROD_ABBR_CODE = :prodAbbrCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNm)  \n");
			sql.append(" AND PROD_NM = :prodNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNmLike)  \n");
			sql.append(" AND PROD_NM like '%' || :prodNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNm)  \n");
			sql.append(" AND CLS_TYPE_NM = :clsTypeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNmLike)  \n");
			sql.append(" AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pbaDeftSumrYn)  \n");
			sql.append(" AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProdDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProdDVO returnTbcMdProdDVO = new TbcMdProdDVO();
									returnTbcMdProdDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbcMdProdDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbcMdProdDVO.setProdNm(resultSet.getString("PROD_NM"));
									returnTbcMdProdDVO.setClsTypeNm(resultSet.getString("CLS_TYPE_NM"));
									returnTbcMdProdDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbcMdProdDVO.setPbaDeftSumrYn(resultSet.getString("PBA_DEFT_SUMR_YN"));
									returnTbcMdProdDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
* 
*
* SELECT 
* 	PROD_CODE, 
* 	PROD_ABBR_CODE, 
* 	PROD_NM, 
* 	CLS_TYPE_NM, 
* 	TT_CALC_YN, 
* 	PBA_DEFT_SUMR_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PROD 
* WHERE 1=1 
* #if($prodCode) 
* AND PROD_CODE = :prodCode 
* #end 
* #if($prodAbbrCode) 
* AND PROD_ABBR_CODE = :prodAbbrCode 
* #end 
* #if($prodNm) 
* AND PROD_NM = :prodNm 
* #end 
* #if($prodNmLike) 
* AND PROD_NM like '%' || :prodNmLike || '%' 
* #end 
* #if($clsTypeNm) 
* AND CLS_TYPE_NM = :clsTypeNm 
* #end 
* #if($clsTypeNmLike) 
* AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%' 
* #end 
* #if($ttCalcYn) 
* AND TT_CALC_YN = :ttCalcYn 
* #end 
* #if($pbaDeftSumrYn) 
* AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROD_CODE,  \n");
			sql.append(" 	PROD_ABBR_CODE,  \n");
			sql.append(" 	PROD_NM,  \n");
			sql.append(" 	CLS_TYPE_NM,  \n");
			sql.append(" 	TT_CALC_YN,  \n");
			sql.append(" 	PBA_DEFT_SUMR_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PROD  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($prodCode)  \n");
			sql.append(" AND PROD_CODE = :prodCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodAbbrCode)  \n");
			sql.append(" AND PROD_ABBR_CODE = :prodAbbrCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNm)  \n");
			sql.append(" AND PROD_NM = :prodNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prodNmLike)  \n");
			sql.append(" AND PROD_NM like '%' || :prodNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNm)  \n");
			sql.append(" AND CLS_TYPE_NM = :clsTypeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($clsTypeNmLike)  \n");
			sql.append(" AND CLS_TYPE_NM like '%' || :clsTypeNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($ttCalcYn)  \n");
			sql.append(" AND TT_CALC_YN = :ttCalcYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($pbaDeftSumrYn)  \n");
			sql.append(" AND PBA_DEFT_SUMR_YN = :pbaDeftSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProdDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProdDVO returnTbcMdProdDVO = new TbcMdProdDVO();
									returnTbcMdProdDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbcMdProdDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbcMdProdDVO.setProdNm(resultSet.getString("PROD_NM"));
									returnTbcMdProdDVO.setClsTypeNm(resultSet.getString("CLS_TYPE_NM"));
									returnTbcMdProdDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbcMdProdDVO.setPbaDeftSumrYn(resultSet.getString("PBA_DEFT_SUMR_YN"));
									returnTbcMdProdDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}