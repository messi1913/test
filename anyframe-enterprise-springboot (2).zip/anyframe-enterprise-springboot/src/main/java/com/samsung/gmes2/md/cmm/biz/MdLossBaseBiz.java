package com.samsung.gmes2.md.cmm.biz;

public class MdLossBaseBiz {

	/**
	 * 이탈분류 리스트
	 */
	public void listDeviClsfBase(){}

	/**
	 * 이탈원인 리스트
	 */
	public void listDeviCauseBase(){}

	/**
	 * 유실유형 리스트
	 */
	public void listLossTypeBase(){}

	/**
	 * 유실항목 리스트
	 */
	public void listLossArtBase(){}

	/**
	 * 유실원인 리스트
	 */
	public void listLossCauseBase(){}

	/**
	 * 책임분류 리스트
	 */
	public void listDutyClsfBase(){}

}
