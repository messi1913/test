/**
 * <PRE>
 * System Name : MD
 * Business Name : L4명
 * Class Name : UserConstants.java
 * Description : 클래스 설명 기재
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------------------------------------------
 *    2011. 7. 26.   sjlee   최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.cmm;

/**
 * 조직 관리 관련 상수 
 *
 * @name_ko MdConstants 클래스
 * @author  sjlee
 */

public class MdConstants
{
    public static final String REGION_CODE = "REGION"; //권역코드

    public static final String NATION_CODE = "NATION"; //국가코드

    public static final String CORP_CODE   = "CORP";  //법인코드

    public static final String FCT_CODE    = "FCT";   //사업장코드

    public static final String GBM_CODE    = "GBM";   //GBM
}
