package com.samsung.gmes2.md.logi.biz;

public class MdManageFbGrCtrntBiz {

	/**
	 * Feedback입고제한정보 목록 조회
	 */
	public void listFbGrCtrnt(){}

	/**
	 * Feedback입고제한정보 목록 저장
	 */
	public void saveFbGrCtrnt(){}

}
