package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_BUYER
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdBuyerDEM extends AbstractDAO {


/**
* insertTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return int
*/
	@LocalName("insertTbmMdBuyer")
	public int insertTbmMdBuyer (final TbmMdBuyerDVO tbmMdBuyerDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.insertTbmMdBuyer.001*/  \n");
			sql.append(" TBM_MD_BUYER (   \n");
			sql.append("        BUYER_CODE , \n");
			sql.append("        BUYER_NM , \n");
			sql.append("        BRND_NM , \n");
			sql.append("        BRND_TYPE_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndTypeNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdBuyer Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdBuyer Method")
	public int[][] updateBatchAllTbmMdBuyer (final List  tbmMdBuyerDVOList) {
		
		ArrayList updatetbmMdBuyerDVOList = new ArrayList();
		ArrayList insertttbmMdBuyerDVOList = new ArrayList();
		ArrayList deletetbmMdBuyerDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdBuyerDVOList.size() ; i++) {
		  TbmMdBuyerDVO tbmMdBuyerDVO = (TbmMdBuyerDVO) tbmMdBuyerDVOList.get(i);
		  
		  if (tbmMdBuyerDVO.getSqlAction().equals("C"))
		      insertttbmMdBuyerDVOList.add(tbmMdBuyerDVO);
		  else if (tbmMdBuyerDVO.getSqlAction().equals("U"))
		      updatetbmMdBuyerDVOList.add(tbmMdBuyerDVO);
		  else if (tbmMdBuyerDVO.getSqlAction().equals("D"))
		      deletetbmMdBuyerDVOList.add(tbmMdBuyerDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdBuyerDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdBuyer(insertttbmMdBuyerDVOList);
          
      if (updatetbmMdBuyerDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdBuyer(updatetbmMdBuyerDVOList);
      
      if (deletetbmMdBuyerDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdBuyer(deletetbmMdBuyerDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return int
*/
	@LocalName("updateTbmMdBuyer")
	public int updateTbmMdBuyer (final TbmMdBuyerDVO tbmMdBuyerDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.updateTbmMdBuyer.001*/  \n");
			sql.append(" TBM_MD_BUYER \n");
			sql.append(" SET   \n");
			sql.append("        BUYER_NM = ? , \n");
			sql.append("        BRND_NM = ? , \n");
			sql.append("        BRND_TYPE_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BUYER_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndTypeNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
						}
					}
		);			
	}

/**
* deleteTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return int
*/
	@LocalName("deleteTbmMdBuyer")
	public int deleteTbmMdBuyer (final TbmMdBuyerDVO tbmMdBuyerDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.deleteTbmMdBuyer.001*/  \n");
			sql.append(" TBM_MD_BUYER \n");
			sql.append("  WHERE BUYER_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
						}
					}
		);			
	}

/**
* selectTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return TbmMdBuyerDVO 
*/
	@LocalName("selectTbmMdBuyer")
	public TbmMdBuyerDVO selectTbmMdBuyer (final TbmMdBuyerDVO tbmMdBuyerDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.selectTbmMdBuyer.001*/  \n");
			sql.append("        BUYER_CODE , \n");
			sql.append("        BUYER_NM , \n");
			sql.append("        BRND_NM , \n");
			sql.append("        BRND_TYPE_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_BUYER \n");
			sql.append("  WHERE BUYER_CODE = ? \n");

		return (TbmMdBuyerDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdBuyerDVO returnTbmMdBuyerDVO = new TbmMdBuyerDVO();
									returnTbmMdBuyerDVO.setBuyerCode(resultSet.getString("BUYER_CODE"));
									returnTbmMdBuyerDVO.setBuyerNm(resultSet.getString("BUYER_NM"));
									returnTbmMdBuyerDVO.setBrndNm(resultSet.getString("BRND_NM"));
									returnTbmMdBuyerDVO.setBrndTypeNm(resultSet.getString("BRND_TYPE_NM"));
									returnTbmMdBuyerDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdBuyerDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdBuyerDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdBuyerDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdBuyerDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdBuyer Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdBuyer Method")
	public int mergeTbmMdBuyer (final TbmMdBuyerDVO tbmMdBuyerDVO) {
		
		if ( selectTbmMdBuyer (tbmMdBuyerDVO) == null) {
			return insertTbmMdBuyer(tbmMdBuyerDVO);
		} else {
			return selectUpdateTbmMdBuyer (tbmMdBuyerDVO);
		}
	}

	/**
	 * selectUpdateTbmMdBuyer Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdBuyer Method")
	public int selectUpdateTbmMdBuyer (final TbmMdBuyerDVO tbmMdBuyerDVO) {
		
		TbmMdBuyerDVO tmpTbmMdBuyerDVO =  selectTbmMdBuyer (tbmMdBuyerDVO);
		if ( tbmMdBuyerDVO.getBuyerCode() != null && !"".equals(tbmMdBuyerDVO.getBuyerCode()) ) {
			tmpTbmMdBuyerDVO.setBuyerCode(tbmMdBuyerDVO.getBuyerCode());
		}		
		if ( tbmMdBuyerDVO.getBuyerNm() != null && !"".equals(tbmMdBuyerDVO.getBuyerNm()) ) {
			tmpTbmMdBuyerDVO.setBuyerNm(tbmMdBuyerDVO.getBuyerNm());
		}		
		if ( tbmMdBuyerDVO.getBrndNm() != null && !"".equals(tbmMdBuyerDVO.getBrndNm()) ) {
			tmpTbmMdBuyerDVO.setBrndNm(tbmMdBuyerDVO.getBrndNm());
		}		
		if ( tbmMdBuyerDVO.getBrndTypeNm() != null && !"".equals(tbmMdBuyerDVO.getBrndTypeNm()) ) {
			tmpTbmMdBuyerDVO.setBrndTypeNm(tbmMdBuyerDVO.getBrndTypeNm());
		}		
		if ( tbmMdBuyerDVO.getFstRegDt() != null && !"".equals(tbmMdBuyerDVO.getFstRegDt()) ) {
			tmpTbmMdBuyerDVO.setFstRegDt(tbmMdBuyerDVO.getFstRegDt());
		}		
		if ( tbmMdBuyerDVO.getFstRegerId() != null && !"".equals(tbmMdBuyerDVO.getFstRegerId()) ) {
			tmpTbmMdBuyerDVO.setFstRegerId(tbmMdBuyerDVO.getFstRegerId());
		}		
		if ( tbmMdBuyerDVO.getFnlUpdDt() != null && !"".equals(tbmMdBuyerDVO.getFnlUpdDt()) ) {
			tmpTbmMdBuyerDVO.setFnlUpdDt(tbmMdBuyerDVO.getFnlUpdDt());
		}		
		if ( tbmMdBuyerDVO.getFnlUpderId() != null && !"".equals(tbmMdBuyerDVO.getFnlUpderId()) ) {
			tmpTbmMdBuyerDVO.setFnlUpderId(tbmMdBuyerDVO.getFnlUpderId());
		}		
		return updateTbmMdBuyer (tmpTbmMdBuyerDVO);
	}

/**
* insertBatchTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return int[]
*/
	@LocalName("insertBatchTbmMdBuyer")
	public int[] insertBatchTbmMdBuyer (final List tbmMdBuyerDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.insertBatchTbmMdBuyer.001*/  \n");
			sql.append(" TBM_MD_BUYER (   \n");
			sql.append("        BUYER_CODE , \n");
			sql.append("        BUYER_NM , \n");
			sql.append("        BRND_NM , \n");
			sql.append("        BRND_TYPE_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdBuyerDVO tbmMdBuyerDVO = (TbmMdBuyerDVO)tbmMdBuyerDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndTypeNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdBuyerDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return int[]
*/
	@LocalName("updateBatchTbmMdBuyer")
	public int[] updateBatchTbmMdBuyer (final List tbmMdBuyerDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.updateBatchTbmMdBuyer.001*/  \n");
			sql.append(" TBM_MD_BUYER \n");
			sql.append(" SET   \n");
			sql.append("        BUYER_NM = ? , \n");
			sql.append("        BRND_NM = ? , \n");
			sql.append("        BRND_TYPE_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BUYER_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdBuyerDVO tbmMdBuyerDVO = (TbmMdBuyerDVO)tbmMdBuyerDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getBrndTypeNm());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBuyerDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
						}
							public int getBatchSize() {
									return tbmMdBuyerDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdBuyer Method
* 
* @ref_table TBM_MD_BUYER
* @return int[]
*/
	@LocalName("deleteBatchTbmMdBuyer")
	public int[] deleteBatchTbmMdBuyer (final List tbmMdBuyerDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdBuyerDEM.deleteBatchTbmMdBuyer.001*/  \n");
			sql.append(" TBM_MD_BUYER \n");
			sql.append("  WHERE BUYER_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdBuyerDVO tbmMdBuyerDVO = (TbmMdBuyerDVO)tbmMdBuyerDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdBuyerDVO.getBuyerCode());
						}
							public int getBatchSize() {
									return tbmMdBuyerDVOList.size();
							}
					}
		);			
	}

	
}