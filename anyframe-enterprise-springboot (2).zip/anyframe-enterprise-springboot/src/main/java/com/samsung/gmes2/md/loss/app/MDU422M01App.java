package com.samsung.gmes2.md.loss.app;

public class MDU422M01App {

	/**
	 * 유실항목코드 목록 초기설정
	 */
	public void initLossArtCode(){}

	/**
	 * 유실항목코드 목록 조회
	 */
	public void listLossArtCode(){}

	/**
	 * 유실항목코드 목록 엑셀 다운로드
	 */
	public void excelLossArtCode(){}

	/**
	 * 유실항목코드 목록 저장
	 */
	public void saveLossArtCode(){}

}
