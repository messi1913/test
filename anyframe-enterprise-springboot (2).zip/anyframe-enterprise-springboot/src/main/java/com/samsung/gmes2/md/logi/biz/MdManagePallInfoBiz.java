package com.samsung.gmes2.md.logi.biz;

public class MdManagePallInfoBiz {

	/**
	 * 모델별 Palletizing 목록 조회
	 */
	public void listPallInfo(){}

	/**
	 * 모델별 Palletizing 목록 저장
	 */
	public void savePallInfo(){}

}
