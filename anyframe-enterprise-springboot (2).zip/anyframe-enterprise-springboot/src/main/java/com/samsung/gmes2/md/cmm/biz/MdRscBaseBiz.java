package com.samsung.gmes2.md.cmm.biz;

public class MdRscBaseBiz {

	/**
	 * 년도 리스트
	 */
	public void listYearBase(){}

	/**
	 * 근무형태 리스트
	 */
	public void listWfkFormBase(){}

	/**
	 * 환경변수 리스트
	 */
	public void listKpiEnvVarBase(){}

}
