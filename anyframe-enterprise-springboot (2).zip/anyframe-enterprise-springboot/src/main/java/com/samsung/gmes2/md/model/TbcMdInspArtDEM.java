package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_INSP_ART
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdInspArtDEM extends AbstractDAO {


/**
* insertTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return int
*/
	@LocalName("insertTbcMdInspArt")
	public int insertTbcMdInspArt (final TbcMdInspArtDVO tbcMdInspArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.insertTbcMdInspArt.001*/  \n");
			sql.append(" TBC_MD_INSP_ART (   \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        INSP_ART_NM , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtNm());
							ps.setString(psCount++, tbcMdInspArtDVO.getInspClsfCode());
							ps.setString(psCount++, tbcMdInspArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdInspArt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdInspArt Method")
	public int[][] updateBatchAllTbcMdInspArt (final List  tbcMdInspArtDVOList) {
		
		ArrayList updatetbcMdInspArtDVOList = new ArrayList();
		ArrayList insertttbcMdInspArtDVOList = new ArrayList();
		ArrayList deletetbcMdInspArtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdInspArtDVOList.size() ; i++) {
		  TbcMdInspArtDVO tbcMdInspArtDVO = (TbcMdInspArtDVO) tbcMdInspArtDVOList.get(i);
		  
		  if (tbcMdInspArtDVO.getSqlAction().equals("C"))
		      insertttbcMdInspArtDVOList.add(tbcMdInspArtDVO);
		  else if (tbcMdInspArtDVO.getSqlAction().equals("U"))
		      updatetbcMdInspArtDVOList.add(tbcMdInspArtDVO);
		  else if (tbcMdInspArtDVO.getSqlAction().equals("D"))
		      deletetbcMdInspArtDVOList.add(tbcMdInspArtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdInspArtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdInspArt(insertttbcMdInspArtDVOList);
          
      if (updatetbcMdInspArtDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdInspArt(updatetbcMdInspArtDVOList);
      
      if (deletetbcMdInspArtDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdInspArt(deletetbcMdInspArtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return int
*/
	@LocalName("updateTbcMdInspArt")
	public int updateTbcMdInspArt (final TbcMdInspArtDVO tbcMdInspArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.updateTbcMdInspArt.001*/  \n");
			sql.append(" TBC_MD_INSP_ART \n");
			sql.append(" SET   \n");
			sql.append("        INSP_ART_NM = ? , \n");
			sql.append("        INSP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE INSP_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtNm());
							ps.setString(psCount++, tbcMdInspArtDVO.getInspClsfCode());
							ps.setString(psCount++, tbcMdInspArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
						}
					}
		);			
	}

/**
* deleteTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return int
*/
	@LocalName("deleteTbcMdInspArt")
	public int deleteTbcMdInspArt (final TbcMdInspArtDVO tbcMdInspArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.deleteTbcMdInspArt.001*/  \n");
			sql.append(" TBC_MD_INSP_ART \n");
			sql.append("  WHERE INSP_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
						}
					}
		);			
	}

/**
* selectTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return TbcMdInspArtDVO 
*/
	@LocalName("selectTbcMdInspArt")
	public TbcMdInspArtDVO selectTbcMdInspArt (final TbcMdInspArtDVO tbcMdInspArtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.selectTbcMdInspArt.001*/  \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        INSP_ART_NM , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_INSP_ART \n");
			sql.append("  WHERE INSP_ART_CODE = ? \n");

		return (TbcMdInspArtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdInspArtDVO returnTbcMdInspArtDVO = new TbcMdInspArtDVO();
									returnTbcMdInspArtDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdInspArtDVO.setInspArtNm(resultSet.getString("INSP_ART_NM"));
									returnTbcMdInspArtDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspArtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdInspArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdInspArt Method")
	public int mergeTbcMdInspArt (final TbcMdInspArtDVO tbcMdInspArtDVO) {
		
		if ( selectTbcMdInspArt (tbcMdInspArtDVO) == null) {
			return insertTbcMdInspArt(tbcMdInspArtDVO);
		} else {
			return selectUpdateTbcMdInspArt (tbcMdInspArtDVO);
		}
	}

	/**
	 * selectUpdateTbcMdInspArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdInspArt Method")
	public int selectUpdateTbcMdInspArt (final TbcMdInspArtDVO tbcMdInspArtDVO) {
		
		TbcMdInspArtDVO tmpTbcMdInspArtDVO =  selectTbcMdInspArt (tbcMdInspArtDVO);
		if ( tbcMdInspArtDVO.getInspArtCode() != null && !"".equals(tbcMdInspArtDVO.getInspArtCode()) ) {
			tmpTbcMdInspArtDVO.setInspArtCode(tbcMdInspArtDVO.getInspArtCode());
		}		
		if ( tbcMdInspArtDVO.getInspArtNm() != null && !"".equals(tbcMdInspArtDVO.getInspArtNm()) ) {
			tmpTbcMdInspArtDVO.setInspArtNm(tbcMdInspArtDVO.getInspArtNm());
		}		
		if ( tbcMdInspArtDVO.getInspClsfCode() != null && !"".equals(tbcMdInspArtDVO.getInspClsfCode()) ) {
			tmpTbcMdInspArtDVO.setInspClsfCode(tbcMdInspArtDVO.getInspClsfCode());
		}		
		if ( tbcMdInspArtDVO.getUseYn() != null && !"".equals(tbcMdInspArtDVO.getUseYn()) ) {
			tmpTbcMdInspArtDVO.setUseYn(tbcMdInspArtDVO.getUseYn());
		}		
		if ( tbcMdInspArtDVO.getFstRegDt() != null && !"".equals(tbcMdInspArtDVO.getFstRegDt()) ) {
			tmpTbcMdInspArtDVO.setFstRegDt(tbcMdInspArtDVO.getFstRegDt());
		}		
		if ( tbcMdInspArtDVO.getFstRegerId() != null && !"".equals(tbcMdInspArtDVO.getFstRegerId()) ) {
			tmpTbcMdInspArtDVO.setFstRegerId(tbcMdInspArtDVO.getFstRegerId());
		}		
		if ( tbcMdInspArtDVO.getFnlUpdDt() != null && !"".equals(tbcMdInspArtDVO.getFnlUpdDt()) ) {
			tmpTbcMdInspArtDVO.setFnlUpdDt(tbcMdInspArtDVO.getFnlUpdDt());
		}		
		if ( tbcMdInspArtDVO.getFnlUpderId() != null && !"".equals(tbcMdInspArtDVO.getFnlUpderId()) ) {
			tmpTbcMdInspArtDVO.setFnlUpderId(tbcMdInspArtDVO.getFnlUpderId());
		}		
		return updateTbcMdInspArt (tmpTbcMdInspArtDVO);
	}

/**
* insertBatchTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return int[]
*/
	@LocalName("insertBatchTbcMdInspArt")
	public int[] insertBatchTbcMdInspArt (final List tbcMdInspArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.insertBatchTbcMdInspArt.001*/  \n");
			sql.append(" TBC_MD_INSP_ART (   \n");
			sql.append("        INSP_ART_CODE , \n");
			sql.append("        INSP_ART_NM , \n");
			sql.append("        INSP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdInspArtDVO tbcMdInspArtDVO = (TbcMdInspArtDVO)tbcMdInspArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtNm());
							ps.setString(psCount++, tbcMdInspArtDVO.getInspClsfCode());
							ps.setString(psCount++, tbcMdInspArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdInspArtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return int[]
*/
	@LocalName("updateBatchTbcMdInspArt")
	public int[] updateBatchTbcMdInspArt (final List tbcMdInspArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.updateBatchTbcMdInspArt.001*/  \n");
			sql.append(" TBC_MD_INSP_ART \n");
			sql.append(" SET   \n");
			sql.append("        INSP_ART_NM = ? , \n");
			sql.append("        INSP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE INSP_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdInspArtDVO tbcMdInspArtDVO = (TbcMdInspArtDVO)tbcMdInspArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtNm());
							ps.setString(psCount++, tbcMdInspArtDVO.getInspClsfCode());
							ps.setString(psCount++, tbcMdInspArtDVO.getUseYn());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdInspArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
						}
							public int getBatchSize() {
									return tbcMdInspArtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdInspArt Method
* 
* @ref_table TBC_MD_INSP_ART
* @return int[]
*/
	@LocalName("deleteBatchTbcMdInspArt")
	public int[] deleteBatchTbcMdInspArt (final List tbcMdInspArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdInspArtDEM.deleteBatchTbcMdInspArt.001*/  \n");
			sql.append(" TBC_MD_INSP_ART \n");
			sql.append("  WHERE INSP_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdInspArtDVO tbcMdInspArtDVO = (TbcMdInspArtDVO)tbcMdInspArtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdInspArtDVO.getInspArtCode());
						}
							public int getBatchSize() {
									return tbcMdInspArtDVOList.size();
							}
					}
		);			
	}

	
}