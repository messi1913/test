package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_VEND
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdVendDEM extends AbstractDAO {


/**
* insertTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return int
*/
	@LocalName("insertTbmMdVend")
	public int insertTbmMdVend (final TbmMdVendDVO tbmMdVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdVendDEM.insertTbmMdVend.001*/  \n");
			sql.append(" TBM_MD_VEND (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        VEND_CODE , \n");
			sql.append("        VEND_GUBUN_CODE , \n");
			sql.append("        VEND_NM , \n");
			sql.append("        VEND_CTRAC_CODE , \n");
			sql.append("        VEND_ADDR , \n");
			sql.append("        DLGR_NM , \n");
			sql.append("        CONTCT_NO , \n");
			sql.append("        VEND_TYPE_CODE , \n");
			sql.append("        PROD_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendNm());
							ps.setString(psCount++, tbmMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbmMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbmMdVendDVO.getContctNo());
							ps.setString(psCount++, tbmMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbmMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbmMdVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdVend Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdVend Method")
	public int[][] updateBatchAllTbmMdVend (final List  tbmMdVendDVOList) {
		
		ArrayList updatetbmMdVendDVOList = new ArrayList();
		ArrayList insertttbmMdVendDVOList = new ArrayList();
		ArrayList deletetbmMdVendDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdVendDVOList.size() ; i++) {
		  TbmMdVendDVO tbmMdVendDVO = (TbmMdVendDVO) tbmMdVendDVOList.get(i);
		  
		  if (tbmMdVendDVO.getSqlAction().equals("C"))
		      insertttbmMdVendDVOList.add(tbmMdVendDVO);
		  else if (tbmMdVendDVO.getSqlAction().equals("U"))
		      updatetbmMdVendDVOList.add(tbmMdVendDVO);
		  else if (tbmMdVendDVO.getSqlAction().equals("D"))
		      deletetbmMdVendDVOList.add(tbmMdVendDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdVendDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdVend(insertttbmMdVendDVOList);
          
      if (updatetbmMdVendDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdVend(updatetbmMdVendDVOList);
      
      if (deletetbmMdVendDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdVend(deletetbmMdVendDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return int
*/
	@LocalName("updateTbmMdVend")
	public int updateTbmMdVend (final TbmMdVendDVO tbmMdVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdVendDEM.updateTbmMdVend.001*/  \n");
			sql.append(" TBM_MD_VEND \n");
			sql.append(" SET   \n");
			sql.append("        VEND_NM = ? , \n");
			sql.append("        VEND_CTRAC_CODE = ? , \n");
			sql.append("        VEND_ADDR = ? , \n");
			sql.append("        DLGR_NM = ? , \n");
			sql.append("        CONTCT_NO = ? , \n");
			sql.append("        VEND_TYPE_CODE = ? , \n");
			sql.append("        PROD_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND VEND_CODE = ? \n");
			sql.append("   AND VEND_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdVendDVO.getVendNm());
							ps.setString(psCount++, tbmMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbmMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbmMdVendDVO.getContctNo());
							ps.setString(psCount++, tbmMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbmMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbmMdVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
						}
					}
		);			
	}

/**
* deleteTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return int
*/
	@LocalName("deleteTbmMdVend")
	public int deleteTbmMdVend (final TbmMdVendDVO tbmMdVendDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdVendDEM.deleteTbmMdVend.001*/  \n");
			sql.append(" TBM_MD_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND VEND_CODE = ? \n");
			sql.append("    AND VEND_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
						}
					}
		);			
	}

/**
* selectTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return TbmMdVendDVO 
*/
	@LocalName("selectTbmMdVend")
	public TbmMdVendDVO selectTbmMdVend (final TbmMdVendDVO tbmMdVendDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdVendDEM.selectTbmMdVend.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        VEND_CODE , \n");
			sql.append("        VEND_GUBUN_CODE , \n");
			sql.append("        VEND_NM , \n");
			sql.append("        VEND_CTRAC_CODE , \n");
			sql.append("        VEND_ADDR , \n");
			sql.append("        DLGR_NM , \n");
			sql.append("        CONTCT_NO , \n");
			sql.append("        VEND_TYPE_CODE , \n");
			sql.append("        PROD_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND VEND_CODE = ? \n");
			sql.append("    AND VEND_GUBUN_CODE = ? \n");

		return (TbmMdVendDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdVendDVO returnTbmMdVendDVO = new TbmMdVendDVO();
									returnTbmMdVendDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdVendDVO.setVendCode(resultSet.getString("VEND_CODE"));
									returnTbmMdVendDVO.setVendGubunCode(resultSet.getString("VEND_GUBUN_CODE"));
									returnTbmMdVendDVO.setVendNm(resultSet.getString("VEND_NM"));
									returnTbmMdVendDVO.setVendCtracCode(resultSet.getString("VEND_CTRAC_CODE"));
									returnTbmMdVendDVO.setVendAddr(resultSet.getString("VEND_ADDR"));
									returnTbmMdVendDVO.setDlgrNm(resultSet.getString("DLGR_NM"));
									returnTbmMdVendDVO.setContctNo(resultSet.getString("CONTCT_NO"));
									returnTbmMdVendDVO.setVendTypeCode(resultSet.getString("VEND_TYPE_CODE"));
									returnTbmMdVendDVO.setProdGubunCode(resultSet.getString("PROD_GUBUN_CODE"));
									returnTbmMdVendDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdVendDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdVendDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdVendDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdVendDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdVendDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdVend Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdVend Method")
	public int mergeTbmMdVend (final TbmMdVendDVO tbmMdVendDVO) {
		
		if ( selectTbmMdVend (tbmMdVendDVO) == null) {
			return insertTbmMdVend(tbmMdVendDVO);
		} else {
			return selectUpdateTbmMdVend (tbmMdVendDVO);
		}
	}

	/**
	 * selectUpdateTbmMdVend Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdVend Method")
	public int selectUpdateTbmMdVend (final TbmMdVendDVO tbmMdVendDVO) {
		
		TbmMdVendDVO tmpTbmMdVendDVO =  selectTbmMdVend (tbmMdVendDVO);
		if ( tbmMdVendDVO.getPlantCode() != null && !"".equals(tbmMdVendDVO.getPlantCode()) ) {
			tmpTbmMdVendDVO.setPlantCode(tbmMdVendDVO.getPlantCode());
		}		
		if ( tbmMdVendDVO.getVendCode() != null && !"".equals(tbmMdVendDVO.getVendCode()) ) {
			tmpTbmMdVendDVO.setVendCode(tbmMdVendDVO.getVendCode());
		}		
		if ( tbmMdVendDVO.getVendGubunCode() != null && !"".equals(tbmMdVendDVO.getVendGubunCode()) ) {
			tmpTbmMdVendDVO.setVendGubunCode(tbmMdVendDVO.getVendGubunCode());
		}		
		if ( tbmMdVendDVO.getVendNm() != null && !"".equals(tbmMdVendDVO.getVendNm()) ) {
			tmpTbmMdVendDVO.setVendNm(tbmMdVendDVO.getVendNm());
		}		
		if ( tbmMdVendDVO.getVendCtracCode() != null && !"".equals(tbmMdVendDVO.getVendCtracCode()) ) {
			tmpTbmMdVendDVO.setVendCtracCode(tbmMdVendDVO.getVendCtracCode());
		}		
		if ( tbmMdVendDVO.getVendAddr() != null && !"".equals(tbmMdVendDVO.getVendAddr()) ) {
			tmpTbmMdVendDVO.setVendAddr(tbmMdVendDVO.getVendAddr());
		}		
		if ( tbmMdVendDVO.getDlgrNm() != null && !"".equals(tbmMdVendDVO.getDlgrNm()) ) {
			tmpTbmMdVendDVO.setDlgrNm(tbmMdVendDVO.getDlgrNm());
		}		
		if ( tbmMdVendDVO.getContctNo() != null && !"".equals(tbmMdVendDVO.getContctNo()) ) {
			tmpTbmMdVendDVO.setContctNo(tbmMdVendDVO.getContctNo());
		}		
		if ( tbmMdVendDVO.getVendTypeCode() != null && !"".equals(tbmMdVendDVO.getVendTypeCode()) ) {
			tmpTbmMdVendDVO.setVendTypeCode(tbmMdVendDVO.getVendTypeCode());
		}		
		if ( tbmMdVendDVO.getProdGubunCode() != null && !"".equals(tbmMdVendDVO.getProdGubunCode()) ) {
			tmpTbmMdVendDVO.setProdGubunCode(tbmMdVendDVO.getProdGubunCode());
		}		
		if ( tbmMdVendDVO.getUseYn() != null && !"".equals(tbmMdVendDVO.getUseYn()) ) {
			tmpTbmMdVendDVO.setUseYn(tbmMdVendDVO.getUseYn());
		}		
		if ( tbmMdVendDVO.getFstRegDt() != null && !"".equals(tbmMdVendDVO.getFstRegDt()) ) {
			tmpTbmMdVendDVO.setFstRegDt(tbmMdVendDVO.getFstRegDt());
		}		
		if ( tbmMdVendDVO.getFstRegerId() != null && !"".equals(tbmMdVendDVO.getFstRegerId()) ) {
			tmpTbmMdVendDVO.setFstRegerId(tbmMdVendDVO.getFstRegerId());
		}		
		if ( tbmMdVendDVO.getFnlUpdDt() != null && !"".equals(tbmMdVendDVO.getFnlUpdDt()) ) {
			tmpTbmMdVendDVO.setFnlUpdDt(tbmMdVendDVO.getFnlUpdDt());
		}		
		if ( tbmMdVendDVO.getFnlUpderId() != null && !"".equals(tbmMdVendDVO.getFnlUpderId()) ) {
			tmpTbmMdVendDVO.setFnlUpderId(tbmMdVendDVO.getFnlUpderId());
		}		
		return updateTbmMdVend (tmpTbmMdVendDVO);
	}

/**
* insertBatchTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return int[]
*/
	@LocalName("insertBatchTbmMdVend")
	public int[] insertBatchTbmMdVend (final List tbmMdVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdVendDEM.insertBatchTbmMdVend.001*/  \n");
			sql.append(" TBM_MD_VEND (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        VEND_CODE , \n");
			sql.append("        VEND_GUBUN_CODE , \n");
			sql.append("        VEND_NM , \n");
			sql.append("        VEND_CTRAC_CODE , \n");
			sql.append("        VEND_ADDR , \n");
			sql.append("        DLGR_NM , \n");
			sql.append("        CONTCT_NO , \n");
			sql.append("        VEND_TYPE_CODE , \n");
			sql.append("        PROD_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdVendDVO tbmMdVendDVO = (TbmMdVendDVO)tbmMdVendDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendNm());
							ps.setString(psCount++, tbmMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbmMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbmMdVendDVO.getContctNo());
							ps.setString(psCount++, tbmMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbmMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbmMdVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdVendDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return int[]
*/
	@LocalName("updateBatchTbmMdVend")
	public int[] updateBatchTbmMdVend (final List tbmMdVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdVendDEM.updateBatchTbmMdVend.001*/  \n");
			sql.append(" TBM_MD_VEND \n");
			sql.append(" SET   \n");
			sql.append("        VEND_NM = ? , \n");
			sql.append("        VEND_CTRAC_CODE = ? , \n");
			sql.append("        VEND_ADDR = ? , \n");
			sql.append("        DLGR_NM = ? , \n");
			sql.append("        CONTCT_NO = ? , \n");
			sql.append("        VEND_TYPE_CODE = ? , \n");
			sql.append("        PROD_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND VEND_CODE = ? \n");
			sql.append("   AND VEND_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdVendDVO tbmMdVendDVO = (TbmMdVendDVO)tbmMdVendDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdVendDVO.getVendNm());
							ps.setString(psCount++, tbmMdVendDVO.getVendCtracCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendAddr());
							ps.setString(psCount++, tbmMdVendDVO.getDlgrNm());
							ps.setString(psCount++, tbmMdVendDVO.getContctNo());
							ps.setString(psCount++, tbmMdVendDVO.getVendTypeCode());
							ps.setString(psCount++, tbmMdVendDVO.getProdGubunCode());
							ps.setString(psCount++, tbmMdVendDVO.getUseYn());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdVendDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdVendDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
						}
							public int getBatchSize() {
									return tbmMdVendDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdVend Method
* 
* @ref_table TBM_MD_VEND
* @return int[]
*/
	@LocalName("deleteBatchTbmMdVend")
	public int[] deleteBatchTbmMdVend (final List tbmMdVendDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdVendDEM.deleteBatchTbmMdVend.001*/  \n");
			sql.append(" TBM_MD_VEND \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND VEND_CODE = ? \n");
			sql.append("    AND VEND_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdVendDVO tbmMdVendDVO = (TbmMdVendDVO)tbmMdVendDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdVendDVO.getPlantCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendCode());
							ps.setString(psCount++, tbmMdVendDVO.getVendGubunCode());
						}
							public int getBatchSize() {
									return tbmMdVendDVOList.size();
							}
					}
		);			
	}

	
}