package com.samsung.gmes2.md.logi.app;

public class MDU873M01App {

	/**
	 * 이동지시패턴 목록 초기설정
	 */
	public void initMoveInstPtn(){}

	/**
	 * 이동지시패턴 목록 조회
	 */
	public void listMoveInstPtn(){}

	/**
	 * 이동지시패턴 목록 엑셀 다운로드
	 */
	public void excelMoveInstPtn(){}

	/**
	 * 이동지시패턴 목록 저장
	 */
	public void saveMoveInstPtn(){}

}
