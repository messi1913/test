package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbmMcLblNmgInisuDVO extends AbstractVo {

	@Length(50) 
	private String nmgId;

	@Length(20) 
	private String plantCode;

	@Length(20) 
	private String modelCode;

	@Length(50) 
	private String nmgArtId;

	@Length(30) 
	private String nmgKeyValue;

	@Length(50) 
	private String labelId;

	@Length(50) 
	private String poNo;

	@Length(30) 
	private String lineCode;

	@Length(8) 
	private String prodcPlanYmd;

	@Length(8) 
	private String nmgAplyYmd;

	@Length(1000) 
	private String nmgDesc;

	@Length(50) 
	private String nmgNo;

	@Length(1) 
	private String prtYn;

	@Length(17) @Scale(5) 
	private BigDecimal prtCnt;

	@Length(50) 
	private String prterId;

	@Length(14) 
	private String prtDt;

	@Length(50) 
	private String lastPrterId;

	@Length(14) 
	private String lastPrtDt;


	public String getNmgId() {
		this.nmgId = super.getValue(0);
		return this.nmgId;
	}

	public void setNmgId(String nmgId) {
        super.setValue(0, nmgId);
		this.nmgId = nmgId;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(1);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(1, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(2);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(2, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getNmgArtId() {
		this.nmgArtId = super.getValue(3);
		return this.nmgArtId;
	}

	public void setNmgArtId(String nmgArtId) {
        super.setValue(3, nmgArtId);
		this.nmgArtId = nmgArtId;
	}
	
	public String getNmgKeyValue() {
		this.nmgKeyValue = super.getValue(4);
		return this.nmgKeyValue;
	}

	public void setNmgKeyValue(String nmgKeyValue) {
        super.setValue(4, nmgKeyValue);
		this.nmgKeyValue = nmgKeyValue;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue(5);
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue(5, labelId);
		this.labelId = labelId;
	}
	
	public String getPoNo() {
		this.poNo = super.getValue(6);
		return this.poNo;
	}

	public void setPoNo(String poNo) {
        super.setValue(6, poNo);
		this.poNo = poNo;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(7);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(7, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getProdcPlanYmd() {
		this.prodcPlanYmd = super.getValue(8);
		return this.prodcPlanYmd;
	}

	public void setProdcPlanYmd(String prodcPlanYmd) {
        super.setValue(8, prodcPlanYmd);
		this.prodcPlanYmd = prodcPlanYmd;
	}
	
	public String getNmgAplyYmd() {
		this.nmgAplyYmd = super.getValue(9);
		return this.nmgAplyYmd;
	}

	public void setNmgAplyYmd(String nmgAplyYmd) {
        super.setValue(9, nmgAplyYmd);
		this.nmgAplyYmd = nmgAplyYmd;
	}
	
	public String getNmgDesc() {
		this.nmgDesc = super.getValue(10);
		return this.nmgDesc;
	}

	public void setNmgDesc(String nmgDesc) {
        super.setValue(10, nmgDesc);
		this.nmgDesc = nmgDesc;
	}
	
	public String getNmgNo() {
		this.nmgNo = super.getValue(11);
		return this.nmgNo;
	}

	public void setNmgNo(String nmgNo) {
        super.setValue(11, nmgNo);
		this.nmgNo = nmgNo;
	}
	
	public String getPrtYn() {
		this.prtYn = super.getValue(12);
		return this.prtYn;
	}

	public void setPrtYn(String prtYn) {
        super.setValue(12, prtYn);
		this.prtYn = prtYn;
	}
	
	public BigDecimal getPrtCnt() {
		this.prtCnt = super.getValue(13);
		return this.prtCnt;
	}

	public void setPrtCnt(BigDecimal prtCnt) {
        super.setValue(13, prtCnt);
		this.prtCnt = prtCnt;
	}
	
	public String getPrterId() {
		this.prterId = super.getValue(14);
		return this.prterId;
	}

	public void setPrterId(String prterId) {
        super.setValue(14, prterId);
		this.prterId = prterId;
	}
	
	public String getPrtDt() {
		this.prtDt = super.getValue(15);
		return this.prtDt;
	}

	public void setPrtDt(String prtDt) {
        super.setValue(15, prtDt);
		this.prtDt = prtDt;
	}
	
	public String getLastPrterId() {
		this.lastPrterId = super.getValue(16);
		return this.lastPrterId;
	}

	public void setLastPrterId(String lastPrterId) {
        super.setValue(16, lastPrterId);
		this.lastPrterId = lastPrterId;
	}
	
	public String getLastPrtDt() {
		this.lastPrtDt = super.getValue(17);
		return this.lastPrtDt;
	}

	public void setLastPrtDt(String lastPrtDt) {
        super.setValue(17, lastPrtDt);
		this.lastPrtDt = lastPrtDt;
	}
	
}