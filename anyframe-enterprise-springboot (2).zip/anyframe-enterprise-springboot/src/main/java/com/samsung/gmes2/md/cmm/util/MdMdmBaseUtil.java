package com.samsung.gmes2.md.cmm.util;

import com.anyframe.core.vo.AbstractVo;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;

public class MdMdmBaseUtil {
	/**
	 * 외래키에 대한 정보가 존재하는지 확인합니다.
	 * 확인해볼 DVO를 인자값으로 제공하면 
	 * BaseUtil.populate메서드로 to의 컬럼정보를 from으로 매핑한후 
	 * CrudUtil.checkFound메서드를 통해 FK값이 실제로 존재하는지 확인합니다.
	 * 
	 * @param to 값이 존재하는 dvo
	 * @param from 매핑할 대상 dvo
	 * @param checkCode 체크할 컬럼을 입력합니다. 컬럼명이 불일치할경우  ' : ' 로 구분
	 * @throws Exception
	 */
	public static void checkFkData(AbstractVo to,AbstractVo from ,String checkCode) throws Exception{
		BaseUtil.populate(to, from,checkCode);
	    CrudUtil.checkFound(from);
	}
}
