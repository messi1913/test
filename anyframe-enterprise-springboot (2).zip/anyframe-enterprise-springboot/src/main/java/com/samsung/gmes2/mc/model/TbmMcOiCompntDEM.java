package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_OI_COMPNT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcOiCompntDEM extends AbstractDAO {


/**
* insertTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return int
*/
	@LocalName("insertTbmMcOiCompnt")
	public int insertTbmMcOiCompnt (final TbmMcOiCompntDVO tbmMcOiCompntDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.insertTbmMcOiCompnt.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT (   \n");
			sql.append("        FRM_NO , \n");
			sql.append("        PGM_REV_NO , \n");
			sql.append("        COMPNT_REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_COMPNT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcOiCompnt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcOiCompnt Method")
	public int[][] updateBatchAllTbmMcOiCompnt (final List  tbmMcOiCompntDVOList) {
		
		ArrayList updatetbmMcOiCompntDVOList = new ArrayList();
		ArrayList insertttbmMcOiCompntDVOList = new ArrayList();
		ArrayList deletetbmMcOiCompntDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcOiCompntDVOList.size() ; i++) {
		  TbmMcOiCompntDVO tbmMcOiCompntDVO = (TbmMcOiCompntDVO) tbmMcOiCompntDVOList.get(i);
		  
		  if (tbmMcOiCompntDVO.getSqlAction().equals("C"))
		      insertttbmMcOiCompntDVOList.add(tbmMcOiCompntDVO);
		  else if (tbmMcOiCompntDVO.getSqlAction().equals("U"))
		      updatetbmMcOiCompntDVOList.add(tbmMcOiCompntDVO);
		  else if (tbmMcOiCompntDVO.getSqlAction().equals("D"))
		      deletetbmMcOiCompntDVOList.add(tbmMcOiCompntDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcOiCompntDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcOiCompnt(insertttbmMcOiCompntDVOList);
          
      if (updatetbmMcOiCompntDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcOiCompnt(updatetbmMcOiCompntDVOList);
      
      if (deletetbmMcOiCompntDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcOiCompnt(deletetbmMcOiCompntDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return int
*/
	@LocalName("updateTbmMcOiCompnt")
	public int updateTbmMcOiCompnt (final TbmMcOiCompntDVO tbmMcOiCompntDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.updateTbmMcOiCompnt.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT \n");
			sql.append(" WHERE FRM_NO = ? \n");
			sql.append("   AND PGM_REV_NO = ? \n");
			sql.append("   AND COMPNT_REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());
						}
					}
		);			
	}

/**
* deleteTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return int
*/
	@LocalName("deleteTbmMcOiCompnt")
	public int deleteTbmMcOiCompnt (final TbmMcOiCompntDVO tbmMcOiCompntDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.deleteTbmMcOiCompnt.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND PGM_REV_NO = ? \n");
			sql.append("    AND COMPNT_REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());
						}
					}
		);			
	}

/**
* selectTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return TbmMcOiCompntDVO 
*/
	@LocalName("selectTbmMcOiCompnt")
	public TbmMcOiCompntDVO selectTbmMcOiCompnt (final TbmMcOiCompntDVO tbmMcOiCompntDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.selectTbmMcOiCompnt.001*/  \n");
			sql.append("        FRM_NO , \n");
			sql.append("        PGM_REV_NO , \n");
			sql.append("        COMPNT_REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_COMPNT_CODE \n");
			sql.append("   FROM TBM_MC_OI_COMPNT \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND PGM_REV_NO = ? \n");
			sql.append("    AND COMPNT_REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return (TbmMcOiCompntDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcOiCompntDVO returnTbmMcOiCompntDVO = new TbmMcOiCompntDVO();
									returnTbmMcOiCompntDVO.setFrmNo(resultSet.getString("FRM_NO"));
									returnTbmMcOiCompntDVO.setPgmRevNo(resultSet.getString("PGM_REV_NO"));
									returnTbmMcOiCompntDVO.setCompntRevNo(resultSet.getString("COMPNT_REV_NO"));
									returnTbmMcOiCompntDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbmMcOiCompntDVO.setStandCompntCode(resultSet.getString("STAND_COMPNT_CODE"));
									return returnTbmMcOiCompntDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcOiCompnt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcOiCompnt Method")
	public int mergeTbmMcOiCompnt (final TbmMcOiCompntDVO tbmMcOiCompntDVO) {
		
		if ( selectTbmMcOiCompnt (tbmMcOiCompntDVO) == null) {
			return insertTbmMcOiCompnt(tbmMcOiCompntDVO);
		} else {
			return selectUpdateTbmMcOiCompnt (tbmMcOiCompntDVO);
		}
	}

	/**
	 * selectUpdateTbmMcOiCompnt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcOiCompnt Method")
	public int selectUpdateTbmMcOiCompnt (final TbmMcOiCompntDVO tbmMcOiCompntDVO) {
		
		TbmMcOiCompntDVO tmpTbmMcOiCompntDVO =  selectTbmMcOiCompnt (tbmMcOiCompntDVO);
		if ( tbmMcOiCompntDVO.getFrmNo() != null && !"".equals(tbmMcOiCompntDVO.getFrmNo()) ) {
			tmpTbmMcOiCompntDVO.setFrmNo(tbmMcOiCompntDVO.getFrmNo());
		}		
		if ( tbmMcOiCompntDVO.getPgmRevNo() != null && !"".equals(tbmMcOiCompntDVO.getPgmRevNo()) ) {
			tmpTbmMcOiCompntDVO.setPgmRevNo(tbmMcOiCompntDVO.getPgmRevNo());
		}		
		if ( tbmMcOiCompntDVO.getCompntRevNo() != null && !"".equals(tbmMcOiCompntDVO.getCompntRevNo()) ) {
			tmpTbmMcOiCompntDVO.setCompntRevNo(tbmMcOiCompntDVO.getCompntRevNo());
		}		
		if ( tbmMcOiCompntDVO.getPgmCode() != null && !"".equals(tbmMcOiCompntDVO.getPgmCode()) ) {
			tmpTbmMcOiCompntDVO.setPgmCode(tbmMcOiCompntDVO.getPgmCode());
		}		
		if ( tbmMcOiCompntDVO.getStandCompntCode() != null && !"".equals(tbmMcOiCompntDVO.getStandCompntCode()) ) {
			tmpTbmMcOiCompntDVO.setStandCompntCode(tbmMcOiCompntDVO.getStandCompntCode());
		}		
		return updateTbmMcOiCompnt (tmpTbmMcOiCompntDVO);
	}

/**
* insertBatchTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return int[]
*/
	@LocalName("insertBatchTbmMcOiCompnt")
	public int[] insertBatchTbmMcOiCompnt (final List tbmMcOiCompntDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.insertBatchTbmMcOiCompnt.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT (   \n");
			sql.append("        FRM_NO , \n");
			sql.append("        PGM_REV_NO , \n");
			sql.append("        COMPNT_REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_COMPNT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcOiCompntDVO tbmMcOiCompntDVO = (TbmMcOiCompntDVO)tbmMcOiCompntDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());

						}
							public int getBatchSize() {
									return tbmMcOiCompntDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return int[]
*/
	@LocalName("updateBatchTbmMcOiCompnt")
	public int[] updateBatchTbmMcOiCompnt (final List tbmMcOiCompntDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.updateBatchTbmMcOiCompnt.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT \n");
			sql.append(" WHERE FRM_NO = ? \n");
			sql.append("   AND PGM_REV_NO = ? \n");
			sql.append("   AND COMPNT_REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");
			sql.append("   AND STAND_COMPNT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcOiCompntDVO tbmMcOiCompntDVO = (TbmMcOiCompntDVO)tbmMcOiCompntDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());
						}
							public int getBatchSize() {
									return tbmMcOiCompntDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcOiCompnt Method
* 
* @ref_table TBM_MC_OI_COMPNT
* @return int[]
*/
	@LocalName("deleteBatchTbmMcOiCompnt")
	public int[] deleteBatchTbmMcOiCompnt (final List tbmMcOiCompntDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcOiCompntDEM.deleteBatchTbmMcOiCompnt.001*/  \n");
			sql.append(" TBM_MC_OI_COMPNT \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND PGM_REV_NO = ? \n");
			sql.append("    AND COMPNT_REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");
			sql.append("    AND STAND_COMPNT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcOiCompntDVO tbmMcOiCompntDVO = (TbmMcOiCompntDVO)tbmMcOiCompntDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcOiCompntDVO.getFrmNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getCompntRevNo());
							ps.setString(psCount++, tbmMcOiCompntDVO.getPgmCode());
							ps.setString(psCount++, tbmMcOiCompntDVO.getStandCompntCode());
						}
							public int getBatchSize() {
									return tbmMcOiCompntDVOList.size();
							}
					}
		);			
	}

	
}