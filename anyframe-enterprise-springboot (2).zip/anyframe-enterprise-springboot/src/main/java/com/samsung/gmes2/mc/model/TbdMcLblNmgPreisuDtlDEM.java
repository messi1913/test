package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbdMcLblNmgPreisuDtlDEM extends AbstractDAO {


/**
* insertTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return int
*/
	@LocalName("insertTbdMcLblNmgPreisuDtl")
	public int insertTbdMcLblNmgPreisuDtl (final TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.insertTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append(" TBD_MC_LBL_NMG_PREISU_DTL (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        NMG_NO , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        PRT_CNT , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        LAST_PRTER_ID , \n");
			sql.append("        LAST_PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgNo());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtCnt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPlantCode());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getModelCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbdMcLblNmgPreisuDtl Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbdMcLblNmgPreisuDtl Method")
	public int[][] updateBatchAllTbdMcLblNmgPreisuDtl (final List  tbdMcLblNmgPreisuDtlDVOList) {
		
		ArrayList updatetbdMcLblNmgPreisuDtlDVOList = new ArrayList();
		ArrayList insertttbdMcLblNmgPreisuDtlDVOList = new ArrayList();
		ArrayList deletetbdMcLblNmgPreisuDtlDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbdMcLblNmgPreisuDtlDVOList.size() ; i++) {
		  TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO = (TbdMcLblNmgPreisuDtlDVO) tbdMcLblNmgPreisuDtlDVOList.get(i);
		  
		  if (tbdMcLblNmgPreisuDtlDVO.getSqlAction().equals("C"))
		      insertttbdMcLblNmgPreisuDtlDVOList.add(tbdMcLblNmgPreisuDtlDVO);
		  else if (tbdMcLblNmgPreisuDtlDVO.getSqlAction().equals("U"))
		      updatetbdMcLblNmgPreisuDtlDVOList.add(tbdMcLblNmgPreisuDtlDVO);
		  else if (tbdMcLblNmgPreisuDtlDVO.getSqlAction().equals("D"))
		      deletetbdMcLblNmgPreisuDtlDVOList.add(tbdMcLblNmgPreisuDtlDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbdMcLblNmgPreisuDtlDVOList.size() > 0) 
          resultValues[0] = insertBatchTbdMcLblNmgPreisuDtl(insertttbdMcLblNmgPreisuDtlDVOList);
          
      if (updatetbdMcLblNmgPreisuDtlDVOList.size() >0)
          resultValues[1] = updateBatchTbdMcLblNmgPreisuDtl(updatetbdMcLblNmgPreisuDtlDVOList);
      
      if (deletetbdMcLblNmgPreisuDtlDVOList.size() >0)
          resultValues[2] = deleteBatchTbdMcLblNmgPreisuDtl(deletetbdMcLblNmgPreisuDtlDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return int
*/
	@LocalName("updateTbdMcLblNmgPreisuDtl")
	public int updateTbdMcLblNmgPreisuDtl (final TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.updateTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append(" TBD_MC_LBL_NMG_PREISU_DTL \n");
			sql.append(" SET   \n");
			sql.append("        NMG_NO = ? , \n");
			sql.append("        PRT_YN = ? , \n");
			sql.append("        PRT_CNT = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        PRT_DT = ? , \n");
			sql.append("        LAST_PRTER_ID = ? , \n");
			sql.append("        LAST_PRT_DT = ? , \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND NMG_SEQ = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgNo());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtCnt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPlantCode());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getModelCode());

							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
						}
					}
		);			
	}

/**
* deleteTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return int
*/
	@LocalName("deleteTbdMcLblNmgPreisuDtl")
	public int deleteTbdMcLblNmgPreisuDtl (final TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.deleteTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append(" TBD_MC_LBL_NMG_PREISU_DTL \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
						}
					}
		);			
	}

/**
* selectTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return TbdMcLblNmgPreisuDtlDVO 
*/
	@LocalName("selectTbdMcLblNmgPreisuDtl")
	public TbdMcLblNmgPreisuDtlDVO selectTbdMcLblNmgPreisuDtl (final TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.selectTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        NMG_NO , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        PRT_CNT , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        LAST_PRTER_ID , \n");
			sql.append("        LAST_PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE \n");
			sql.append("   FROM TBD_MC_LBL_NMG_PREISU_DTL \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");

		return (TbdMcLblNmgPreisuDtlDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbdMcLblNmgPreisuDtlDVO returnTbdMcLblNmgPreisuDtlDVO = new TbdMcLblNmgPreisuDtlDVO();
									returnTbdMcLblNmgPreisuDtlDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbdMcLblNmgPreisuDtlDVO.setNmgSeq(resultSet.getBigDecimal("NMG_SEQ"));
									returnTbdMcLblNmgPreisuDtlDVO.setNmgNo(resultSet.getString("NMG_NO"));
									returnTbdMcLblNmgPreisuDtlDVO.setPrtYn(resultSet.getString("PRT_YN"));
									returnTbdMcLblNmgPreisuDtlDVO.setPrtCnt(resultSet.getBigDecimal("PRT_CNT"));
									returnTbdMcLblNmgPreisuDtlDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbdMcLblNmgPreisuDtlDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbdMcLblNmgPreisuDtlDVO.setLastPrterId(resultSet.getString("LAST_PRTER_ID"));
									returnTbdMcLblNmgPreisuDtlDVO.setLastPrtDt(resultSet.getString("LAST_PRT_DT"));
									returnTbdMcLblNmgPreisuDtlDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbdMcLblNmgPreisuDtlDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									return returnTbdMcLblNmgPreisuDtlDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbdMcLblNmgPreisuDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbdMcLblNmgPreisuDtl Method")
	public int mergeTbdMcLblNmgPreisuDtl (final TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO) {
		
		if ( selectTbdMcLblNmgPreisuDtl (tbdMcLblNmgPreisuDtlDVO) == null) {
			return insertTbdMcLblNmgPreisuDtl(tbdMcLblNmgPreisuDtlDVO);
		} else {
			return selectUpdateTbdMcLblNmgPreisuDtl (tbdMcLblNmgPreisuDtlDVO);
		}
	}

	/**
	 * selectUpdateTbdMcLblNmgPreisuDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbdMcLblNmgPreisuDtl Method")
	public int selectUpdateTbdMcLblNmgPreisuDtl (final TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO) {
		
		TbdMcLblNmgPreisuDtlDVO tmpTbdMcLblNmgPreisuDtlDVO =  selectTbdMcLblNmgPreisuDtl (tbdMcLblNmgPreisuDtlDVO);
		if ( tbdMcLblNmgPreisuDtlDVO.getNmgId() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getNmgId()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setNmgId(tbdMcLblNmgPreisuDtlDVO.getNmgId());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getNmgSeq() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getNmgSeq()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setNmgSeq(tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getNmgNo() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getNmgNo()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setNmgNo(tbdMcLblNmgPreisuDtlDVO.getNmgNo());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getPrtYn() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getPrtYn()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setPrtYn(tbdMcLblNmgPreisuDtlDVO.getPrtYn());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getPrtCnt() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getPrtCnt()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setPrtCnt(tbdMcLblNmgPreisuDtlDVO.getPrtCnt());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getPrterId() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getPrterId()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setPrterId(tbdMcLblNmgPreisuDtlDVO.getPrterId());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getPrtDt() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getPrtDt()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setPrtDt(tbdMcLblNmgPreisuDtlDVO.getPrtDt());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getLastPrterId() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getLastPrterId()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setLastPrterId(tbdMcLblNmgPreisuDtlDVO.getLastPrterId());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getLastPrtDt() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getLastPrtDt()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setLastPrtDt(tbdMcLblNmgPreisuDtlDVO.getLastPrtDt());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getPlantCode() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getPlantCode()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setPlantCode(tbdMcLblNmgPreisuDtlDVO.getPlantCode());
		}		
		if ( tbdMcLblNmgPreisuDtlDVO.getModelCode() != null && !"".equals(tbdMcLblNmgPreisuDtlDVO.getModelCode()) ) {
			tmpTbdMcLblNmgPreisuDtlDVO.setModelCode(tbdMcLblNmgPreisuDtlDVO.getModelCode());
		}		
		return updateTbdMcLblNmgPreisuDtl (tmpTbdMcLblNmgPreisuDtlDVO);
	}

/**
* insertBatchTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return int[]
*/
	@LocalName("insertBatchTbdMcLblNmgPreisuDtl")
	public int[] insertBatchTbdMcLblNmgPreisuDtl (final List tbdMcLblNmgPreisuDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.insertBatchTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append(" TBD_MC_LBL_NMG_PREISU_DTL (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        NMG_NO , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        PRT_CNT , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        LAST_PRTER_ID , \n");
			sql.append("        LAST_PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO = (TbdMcLblNmgPreisuDtlDVO)tbdMcLblNmgPreisuDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgNo());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtCnt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPlantCode());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getModelCode());

						}
							public int getBatchSize() {
									return tbdMcLblNmgPreisuDtlDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return int[]
*/
	@LocalName("updateBatchTbdMcLblNmgPreisuDtl")
	public int[] updateBatchTbdMcLblNmgPreisuDtl (final List tbdMcLblNmgPreisuDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.updateBatchTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append(" TBD_MC_LBL_NMG_PREISU_DTL \n");
			sql.append(" SET   \n");
			sql.append("        NMG_NO = ? , \n");
			sql.append("        PRT_YN = ? , \n");
			sql.append("        PRT_CNT = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        PRT_DT = ? , \n");
			sql.append("        LAST_PRTER_ID = ? , \n");
			sql.append("        LAST_PRT_DT = ? , \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND NMG_SEQ = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO = (TbdMcLblNmgPreisuDtlDVO)tbdMcLblNmgPreisuDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgNo());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtCnt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrterId());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getLastPrtDt());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getPlantCode());
							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getModelCode());

							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
						}
							public int getBatchSize() {
									return tbdMcLblNmgPreisuDtlDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbdMcLblNmgPreisuDtl Method
* 
* @ref_table TBD_MC_LBL_NMG_PREISU_DTL
* @return int[]
*/
	@LocalName("deleteBatchTbdMcLblNmgPreisuDtl")
	public int[] deleteBatchTbdMcLblNmgPreisuDtl (final List tbdMcLblNmgPreisuDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcLblNmgPreisuDtlDEM.deleteBatchTbdMcLblNmgPreisuDtl.001*/  \n");
			sql.append(" TBD_MC_LBL_NMG_PREISU_DTL \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcLblNmgPreisuDtlDVO tbdMcLblNmgPreisuDtlDVO = (TbdMcLblNmgPreisuDtlDVO)tbdMcLblNmgPreisuDtlDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbdMcLblNmgPreisuDtlDVO.getNmgSeq());
						}
							public int getBatchSize() {
									return tbdMcLblNmgPreisuDtlDVOList.size();
							}
					}
		);			
	}

	
}