package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MC_OI_RELS
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMcOiRelsDEM extends AbstractDAO {


/**
* insertTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return int
*/
	@LocalName("insertTbhMcOiRels")
	public int insertTbhMcOiRels (final TbhMcOiRelsDVO tbhMcOiRelsDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.insertTbhMcOiRels.001*/  \n");
			sql.append(" TBH_MC_OI_RELS (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        RELS_DT , \n");
			sql.append("        RELS_HIST_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsDt());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsHistDesc());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMcOiRels Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMcOiRels Method")
	public int[][] updateBatchAllTbhMcOiRels (final List  tbhMcOiRelsDVOList) {
		
		ArrayList updatetbhMcOiRelsDVOList = new ArrayList();
		ArrayList insertttbhMcOiRelsDVOList = new ArrayList();
		ArrayList deletetbhMcOiRelsDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMcOiRelsDVOList.size() ; i++) {
		  TbhMcOiRelsDVO tbhMcOiRelsDVO = (TbhMcOiRelsDVO) tbhMcOiRelsDVOList.get(i);
		  
		  if (tbhMcOiRelsDVO.getSqlAction().equals("C"))
		      insertttbhMcOiRelsDVOList.add(tbhMcOiRelsDVO);
		  else if (tbhMcOiRelsDVO.getSqlAction().equals("U"))
		      updatetbhMcOiRelsDVOList.add(tbhMcOiRelsDVO);
		  else if (tbhMcOiRelsDVO.getSqlAction().equals("D"))
		      deletetbhMcOiRelsDVOList.add(tbhMcOiRelsDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMcOiRelsDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMcOiRels(insertttbhMcOiRelsDVOList);
          
      if (updatetbhMcOiRelsDVOList.size() >0)
          resultValues[1] = updateBatchTbhMcOiRels(updatetbhMcOiRelsDVOList);
      
      if (deletetbhMcOiRelsDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMcOiRels(deletetbhMcOiRelsDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return int
*/
	@LocalName("updateTbhMcOiRels")
	public int updateTbhMcOiRels (final TbhMcOiRelsDVO tbhMcOiRelsDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.updateTbhMcOiRels.001*/  \n");
			sql.append(" TBH_MC_OI_RELS \n");
			sql.append(" SET   \n");
			sql.append("        RELS_DT = ? , \n");
			sql.append("        RELS_HIST_DESC = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND DIV_CODE = ? \n");
			sql.append("   AND REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsDt());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsHistDesc());

							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
						}
					}
		);			
	}

/**
* deleteTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return int
*/
	@LocalName("deleteTbhMcOiRels")
	public int deleteTbhMcOiRels (final TbhMcOiRelsDVO tbhMcOiRelsDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.deleteTbhMcOiRels.001*/  \n");
			sql.append(" TBH_MC_OI_RELS \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND DIV_CODE = ? \n");
			sql.append("    AND REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
						}
					}
		);			
	}

/**
* selectTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return TbhMcOiRelsDVO 
*/
	@LocalName("selectTbhMcOiRels")
	public TbhMcOiRelsDVO selectTbhMcOiRels (final TbhMcOiRelsDVO tbhMcOiRelsDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.selectTbhMcOiRels.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        RELS_DT , \n");
			sql.append("        RELS_HIST_DESC \n");
			sql.append("   FROM TBH_MC_OI_RELS \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND DIV_CODE = ? \n");
			sql.append("    AND REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return (TbhMcOiRelsDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMcOiRelsDVO returnTbhMcOiRelsDVO = new TbhMcOiRelsDVO();
									returnTbhMcOiRelsDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbhMcOiRelsDVO.setDivCode(resultSet.getString("DIV_CODE"));
									returnTbhMcOiRelsDVO.setRevNo(resultSet.getString("REV_NO"));
									returnTbhMcOiRelsDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbhMcOiRelsDVO.setRelsDt(resultSet.getString("RELS_DT"));
									returnTbhMcOiRelsDVO.setRelsHistDesc(resultSet.getString("RELS_HIST_DESC"));
									return returnTbhMcOiRelsDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMcOiRels Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMcOiRels Method")
	public int mergeTbhMcOiRels (final TbhMcOiRelsDVO tbhMcOiRelsDVO) {
		
		if ( selectTbhMcOiRels (tbhMcOiRelsDVO) == null) {
			return insertTbhMcOiRels(tbhMcOiRelsDVO);
		} else {
			return selectUpdateTbhMcOiRels (tbhMcOiRelsDVO);
		}
	}

	/**
	 * selectUpdateTbhMcOiRels Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMcOiRels Method")
	public int selectUpdateTbhMcOiRels (final TbhMcOiRelsDVO tbhMcOiRelsDVO) {
		
		TbhMcOiRelsDVO tmpTbhMcOiRelsDVO =  selectTbhMcOiRels (tbhMcOiRelsDVO);
		if ( tbhMcOiRelsDVO.getPlantCode() != null && !"".equals(tbhMcOiRelsDVO.getPlantCode()) ) {
			tmpTbhMcOiRelsDVO.setPlantCode(tbhMcOiRelsDVO.getPlantCode());
		}		
		if ( tbhMcOiRelsDVO.getDivCode() != null && !"".equals(tbhMcOiRelsDVO.getDivCode()) ) {
			tmpTbhMcOiRelsDVO.setDivCode(tbhMcOiRelsDVO.getDivCode());
		}		
		if ( tbhMcOiRelsDVO.getRevNo() != null && !"".equals(tbhMcOiRelsDVO.getRevNo()) ) {
			tmpTbhMcOiRelsDVO.setRevNo(tbhMcOiRelsDVO.getRevNo());
		}		
		if ( tbhMcOiRelsDVO.getPgmCode() != null && !"".equals(tbhMcOiRelsDVO.getPgmCode()) ) {
			tmpTbhMcOiRelsDVO.setPgmCode(tbhMcOiRelsDVO.getPgmCode());
		}		
		if ( tbhMcOiRelsDVO.getRelsDt() != null && !"".equals(tbhMcOiRelsDVO.getRelsDt()) ) {
			tmpTbhMcOiRelsDVO.setRelsDt(tbhMcOiRelsDVO.getRelsDt());
		}		
		if ( tbhMcOiRelsDVO.getRelsHistDesc() != null && !"".equals(tbhMcOiRelsDVO.getRelsHistDesc()) ) {
			tmpTbhMcOiRelsDVO.setRelsHistDesc(tbhMcOiRelsDVO.getRelsHistDesc());
		}		
		return updateTbhMcOiRels (tmpTbhMcOiRelsDVO);
	}

/**
* insertBatchTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return int[]
*/
	@LocalName("insertBatchTbhMcOiRels")
	public int[] insertBatchTbhMcOiRels (final List tbhMcOiRelsDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.insertBatchTbhMcOiRels.001*/  \n");
			sql.append(" TBH_MC_OI_RELS (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        RELS_DT , \n");
			sql.append("        RELS_HIST_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcOiRelsDVO tbhMcOiRelsDVO = (TbhMcOiRelsDVO)tbhMcOiRelsDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsDt());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsHistDesc());

						}
							public int getBatchSize() {
									return tbhMcOiRelsDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return int[]
*/
	@LocalName("updateBatchTbhMcOiRels")
	public int[] updateBatchTbhMcOiRels (final List tbhMcOiRelsDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.updateBatchTbhMcOiRels.001*/  \n");
			sql.append(" TBH_MC_OI_RELS \n");
			sql.append(" SET   \n");
			sql.append("        RELS_DT = ? , \n");
			sql.append("        RELS_HIST_DESC = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND DIV_CODE = ? \n");
			sql.append("   AND REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcOiRelsDVO tbhMcOiRelsDVO = (TbhMcOiRelsDVO)tbhMcOiRelsDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsDt());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRelsHistDesc());

							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbhMcOiRelsDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMcOiRels Method
* 
* @ref_table TBH_MC_OI_RELS
* @return int[]
*/
	@LocalName("deleteBatchTbhMcOiRels")
	public int[] deleteBatchTbhMcOiRels (final List tbhMcOiRelsDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcOiRelsDEM.deleteBatchTbhMcOiRels.001*/  \n");
			sql.append(" TBH_MC_OI_RELS \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND DIV_CODE = ? \n");
			sql.append("    AND REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcOiRelsDVO tbhMcOiRelsDVO = (TbhMcOiRelsDVO)tbhMcOiRelsDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMcOiRelsDVO.getPlantCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getDivCode());
							ps.setString(psCount++, tbhMcOiRelsDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiRelsDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbhMcOiRelsDVOList.size();
							}
					}
		);			
	}

	
}