/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbMdLineBiz.java
 * Description : 테이블 TbMdLine에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.19          심재국          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.md.model.TbcMdMfgPartDVO;
import com.samsung.gmes2.md.model.TbcMdProcGubunDVO;
import com.samsung.gmes2.md.model.TbmMdLineDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;

public class MdManageTbmMdLineBiz{
	
	/**
	 * TbmMdLine table에서
	 * 다른 table의 참조키를 check
	 * 하는 공통 로직
	 */
	public void common(TbmMdLineDVO tbmMdLineDVO) throws Exception{
		BaseUtil.checkNotEmpty(tbmMdLineDVO);

		TbcMdCommOrgDVO tbcMdCommOrgDVO = new TbcMdCommOrgDVO();
		BaseUtil.populate(tbmMdLineDVO, tbcMdCommOrgDVO, "fctCode:commOrgCode");
		BaseUtil.checkFound(tbcMdCommOrgDVO);

		/*TbcMdMfgPartDVO tbcMdMfgPartDVO = new TbcMdMfgPartDVO();
		BaseUtil.populate(tbmMdLineDVO, tbcMdMfgPartDVO, "mgfPartCode");
		BaseUtil.checkFound(tbcMdMfgPartDVO);

		TbcMdProcGubunDVO tbcMdProcGubunDVO = new TbcMdProcGubunDVO();
		BaseUtil.populate(tbmMdLineDVO, tbcMdProcGubunDVO, "procGubunCode");
		BaseUtil.checkFound(tbcMdProcGubunDVO);*/

		/*TbcMdCommCodeDVO tbcMdCommCodeDVO = new TbcMdCommCodeDVO();
		BaseUtil.populate(tbmMdLineDVO, tbcMdCommCodeDVO,
				"lineFromCode:commCode");
		BaseUtil.checkFound(tbcMdCommCodeDVO);

		BaseUtil.populate(tbmMdLineDVO, tbcMdCommCodeDVO,
				"tbGubunCode:commCode");
		BaseUtil.checkFound(tbcMdCommCodeDVO);

		BaseUtil.populate(tbmMdLineDVO, tbcMdCommCodeDVO,
				"cellTypeCode:commCode");
		BaseUtil.checkFound(tbcMdCommCodeDVO);*/
	}
	
	/**
	 * TbmMdLine 등록을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdLineDVO 값을 넣어준다
	 */
	public TbmMdLineDVO createTbmMdLine(TbmMdLineDVO tbmMdLineDVO)
			throws Exception {
		common(tbmMdLineDVO);
		return CrudUtil.create(tbmMdLineDVO);
	}

	/**
	 * TbmMdLine 삭제을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdLineDVO 값을 넣어준다
	 */
	public TbmMdLineDVO deleteTbmMdLine(TbmMdLineDVO tbmMdLineDVO)
			throws Exception {
		common(tbmMdLineDVO);
		return CrudUtil.delete(tbmMdLineDVO);
	}

	/**
	 * TbmMdLine 수정을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdLineDVO 값을 넣어준다
	 */
	public TbmMdLineDVO updateTbmMdLine(TbmMdLineDVO tbmMdLineDVO)
			throws Exception {
		common(tbmMdLineDVO);
		return CrudUtil.update(tbmMdLineDVO);
	}

	/**
	 * TbmMdLine 정보를 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdLineDVO 값을 넣어준다
	 * 단건 조회
	 */
	public TbmMdLineDVO getTbmMdLine(TbmMdLineDVO tbmMdLineDVO)
			throws Exception {
		//BaseUtil.checkNotEmpty(tbmMdLineDVO);
		return CrudUtil.get(tbmMdLineDVO);
	}

	/**
	 * TbmMdLine 정보List 를 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdLineDVO 값을 넣어준다
	 * 다건 조회
	 * @param tbmMdLineDVO
	 * @return
	 */
	public List<TbmMdLineDVO> listTbmMdLine(TbmMdLineDVO tbmMdLineDVO)
			throws Exception {
		// PK 가 FCT_CODE 와 LINE_CODE 두개 이기 때문에
		// 키 값이 있는지 없는지 체크
		return CrudUtil.list0(TbmMdLineDVO.class, tbmMdLineDVO, 0, 0);
	}

}
