package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbmMcIpProcDVO extends AbstractDVO {

	@Length(18) @NotNull
	private String ip;

	@Length(30) 
	private String corpCode;

	@Length(30) 
	private String lineCode;

	@Length(50) 
	private String cellCode;

	@Length(50) 
	private String unitProcCode;

	@Length(1000) 
	private String ipDesc;


	public String getIp() {
		this.ip = super.getValue("ip");
		return this.ip;
	}

	public void setIp(String ip) {
        super.setValue("ip", ip);
		this.ip = ip;
	}
	
	public String getCorpCode() {
		this.corpCode = super.getValue("corpCode");
		return this.corpCode;
	}

	public void setCorpCode(String corpCode) {
        super.setValue("corpCode", corpCode);
		this.corpCode = corpCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue("lineCode");
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue("lineCode", lineCode);
		this.lineCode = lineCode;
	}
	
	public String getCellCode() {
		this.cellCode = super.getValue("cellCode");
		return this.cellCode;
	}

	public void setCellCode(String cellCode) {
        super.setValue("cellCode", cellCode);
		this.cellCode = cellCode;
	}
	
	public String getUnitProcCode() {
		this.unitProcCode = super.getValue("unitProcCode");
		return this.unitProcCode;
	}

	public void setUnitProcCode(String unitProcCode) {
        super.setValue("unitProcCode", unitProcCode);
		this.unitProcCode = unitProcCode;
	}
	
	public String getIpDesc() {
		this.ipDesc = super.getValue("ipDesc");
		return this.ipDesc;
	}

	public void setIpDesc(String ipDesc) {
        super.setValue("ipDesc", ipDesc);
		this.ipDesc = ipDesc;
	}
	
}