package com.samsung.gmes2.md.loss.biz;

public class MdManageEquipClsfBiz {

	/**
	 * 설비분류코드 목록 조회
	 */
	public void listEquipClsfCode(){}

	/**
	 * 설비분류코드 목록 저장
	 */
	public void saveEquipClsfCode(){}

}
