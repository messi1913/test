/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbcMdDeftCauseClsfBiz.java
 * Description : 테이블 TbcMdDeftCauseClsf에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.21          심재국          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDVO;
import com.samsung.gmes2.md.model.TbcMdProcGubunDVO;

public class MdManageTbcMdDeftCauseClsfBiz {
	/**
	 * MdDeftCauseCls Table 에서
	 * 다른 table의 참조키를 check
	 * 하는 공통 로직
	 */
	public void commom(TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) throws Exception{
		BaseUtil.checkNotEmpty(tbcMdDeftCauseClsfDVO);
		TbcMdProcGubunDVO tbcMdProcGubunDVO = new TbcMdProcGubunDVO();
		BaseUtil.populate(tbcMdDeftCauseClsfDVO, tbcMdProcGubunDVO, "procGubunCode");
		BaseUtil.checkFound(tbcMdProcGubunDVO);
	}
	/**
	 * TbcMdDeftCauseClsf 등록을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdDeftCauseClsfDVO 값을 넣어준다
	 */
	public TbcMdDeftCauseClsfDVO createTbcMdDeftCauseClsf(
			TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) throws Exception {
		
		commom(tbcMdDeftCauseClsfDVO);

		return CrudUtil.create(tbcMdDeftCauseClsfDVO);
	}

	/**
	 * TbcMdDeftCauseClsf 삭제을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdDeftCauseClsfDVO 값을 넣어준다
	 */
	public TbcMdDeftCauseClsfDVO deleteTbcMdDeftCauseClsf(
			TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) throws Exception {
		//commom(tbcMdDeftCauseClsfDVO);
		BaseUtil.checkNotEmpty(tbcMdDeftCauseClsfDVO);
		return CrudUtil.delete(tbcMdDeftCauseClsfDVO);

	}

	/**
	 * TbcMdDeftCauseClsf 수정을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdDeftCauseClsfDVO 값을 넣어준다
	 */
	public TbcMdDeftCauseClsfDVO updateTbcMdDeftCauseClsf(
			TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) throws Exception {
		commom(tbcMdDeftCauseClsfDVO);
		return CrudUtil.update(tbcMdDeftCauseClsfDVO);
	}

	/**
	 * TbcMdDeftCauseClsf 정보를 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdDeftCauseClsfDVO 값을 넣어준다
	 * 단건 조회
	 */
	public TbcMdDeftCauseClsfDVO getTbcMdDeftCauseClsf(
			TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) throws Exception {
		//BaseUtil.checkNotEmpty(tbcMdDeftCauseClsfDVO);
		return CrudUtil.get(tbcMdDeftCauseClsfDVO);
	}

	/**
	 * TbcMdDeftCauseClsf 정보를List 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbcMdDeftCauseClsfDVO 값을 넣어준다
	 * 다건 조회
	 * @return
	 */
	public List<TbcMdDeftCauseClsfDVO> listTbcMdDeftCauseClsf(
			TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) throws Exception {
		return CrudUtil.list0(TbcMdDeftCauseClsfDVO.class,
				tbcMdDeftCauseClsfDVO, 0, 0);
	}

}
