package com.samsung.gmes2.md.equipment.app;

public class MDU552M01App {

	/**
	 * Feeder정보 목록 초기설정
	 */
	public void initFeederInfo(){}

	/**
	 * Feeder정보 목록 조회
	 */
	public void listFeederInfo(){}

	/**
	 * Feeder정보 목록 엑셀 다운로드
	 */
	public void excelFeederInfo(){}

}
