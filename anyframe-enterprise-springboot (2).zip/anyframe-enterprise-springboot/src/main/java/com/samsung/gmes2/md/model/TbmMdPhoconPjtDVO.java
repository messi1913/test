package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdPhoconPjtDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(500) 
	private String n2PjtGrpNm;

	@Length(500) 
	private String n1PjtGrpNm;

	@Length(30) 
	private String pjtCode;

	@Length(500) 
	private String pjtAliasNm;

	@Length(2000) 
	private String phoconPjtDesc;

	@Length(17) @Scale(5) 
	private BigDecimal setNeedAmt;

	@Length(17) @Scale(5) 
	private BigDecimal consumNeedAmt;

	@Length(11) @Scale(5) 
	private BigDecimal tonerUseRate;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getN2PjtGrpNm() {
		this.n2PjtGrpNm = super.getValue(1);
		return this.n2PjtGrpNm;
	}

	public void setN2PjtGrpNm(String n2PjtGrpNm) {
        super.setValue(1, n2PjtGrpNm);
		this.n2PjtGrpNm = n2PjtGrpNm;
	}
	
	public String getN1PjtGrpNm() {
		this.n1PjtGrpNm = super.getValue(2);
		return this.n1PjtGrpNm;
	}

	public void setN1PjtGrpNm(String n1PjtGrpNm) {
        super.setValue(2, n1PjtGrpNm);
		this.n1PjtGrpNm = n1PjtGrpNm;
	}
	
	public String getPjtCode() {
		this.pjtCode = super.getValue(3);
		return this.pjtCode;
	}

	public void setPjtCode(String pjtCode) {
        super.setValue(3, pjtCode);
		this.pjtCode = pjtCode;
	}
	
	public String getPjtAliasNm() {
		this.pjtAliasNm = super.getValue(4);
		return this.pjtAliasNm;
	}

	public void setPjtAliasNm(String pjtAliasNm) {
        super.setValue(4, pjtAliasNm);
		this.pjtAliasNm = pjtAliasNm;
	}
	
	public String getPhoconPjtDesc() {
		this.phoconPjtDesc = super.getValue(5);
		return this.phoconPjtDesc;
	}

	public void setPhoconPjtDesc(String phoconPjtDesc) {
        super.setValue(5, phoconPjtDesc);
		this.phoconPjtDesc = phoconPjtDesc;
	}
	
	public BigDecimal getSetNeedAmt() {
		this.setNeedAmt = super.getValue(6);
		return this.setNeedAmt;
	}

	public void setSetNeedAmt(BigDecimal setNeedAmt) {
        super.setValue(6, setNeedAmt);
		this.setNeedAmt = setNeedAmt;
	}
	
	public BigDecimal getConsumNeedAmt() {
		this.consumNeedAmt = super.getValue(7);
		return this.consumNeedAmt;
	}

	public void setConsumNeedAmt(BigDecimal consumNeedAmt) {
        super.setValue(7, consumNeedAmt);
		this.consumNeedAmt = consumNeedAmt;
	}
	
	public BigDecimal getTonerUseRate() {
		this.tonerUseRate = super.getValue(8);
		return this.tonerUseRate;
	}

	public void setTonerUseRate(BigDecimal tonerUseRate) {
        super.setValue(8, tonerUseRate);
		this.tonerUseRate = tonerUseRate;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(9);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(9, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(10);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(10, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(11);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(11, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(12);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(12, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}