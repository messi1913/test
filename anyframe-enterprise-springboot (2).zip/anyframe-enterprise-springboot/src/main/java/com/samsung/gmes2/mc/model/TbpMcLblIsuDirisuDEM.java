package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbpMcLblIsuDirisuDEM extends AbstractDAO {


/**
* insertTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return int
*/
	@LocalName("insertTbpMcLblIsuDirisu")
	public int insertTbpMcLblIsuDirisu (final TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.insertTbpMcLblIsuDirisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_DIRISU (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRT_QTY \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLblIsuDirisuDVO.getPrtQty());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbpMcLblIsuDirisu Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbpMcLblIsuDirisu Method")
	public int[][] updateBatchAllTbpMcLblIsuDirisu (final List  tbpMcLblIsuDirisuDVOList) {
		
		ArrayList updatetbpMcLblIsuDirisuDVOList = new ArrayList();
		ArrayList insertttbpMcLblIsuDirisuDVOList = new ArrayList();
		ArrayList deletetbpMcLblIsuDirisuDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbpMcLblIsuDirisuDVOList.size() ; i++) {
		  TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO = (TbpMcLblIsuDirisuDVO) tbpMcLblIsuDirisuDVOList.get(i);
		  
		  if (tbpMcLblIsuDirisuDVO.getSqlAction().equals("C"))
		      insertttbpMcLblIsuDirisuDVOList.add(tbpMcLblIsuDirisuDVO);
		  else if (tbpMcLblIsuDirisuDVO.getSqlAction().equals("U"))
		      updatetbpMcLblIsuDirisuDVOList.add(tbpMcLblIsuDirisuDVO);
		  else if (tbpMcLblIsuDirisuDVO.getSqlAction().equals("D"))
		      deletetbpMcLblIsuDirisuDVOList.add(tbpMcLblIsuDirisuDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbpMcLblIsuDirisuDVOList.size() > 0) 
          resultValues[0] = insertBatchTbpMcLblIsuDirisu(insertttbpMcLblIsuDirisuDVOList);
          
      if (updatetbpMcLblIsuDirisuDVOList.size() >0)
          resultValues[1] = updateBatchTbpMcLblIsuDirisu(updatetbpMcLblIsuDirisuDVOList);
      
      if (deletetbpMcLblIsuDirisuDVOList.size() >0)
          resultValues[2] = deleteBatchTbpMcLblIsuDirisu(deletetbpMcLblIsuDirisuDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return int
*/
	@LocalName("updateTbpMcLblIsuDirisu")
	public int updateTbpMcLblIsuDirisu (final TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.updateTbpMcLblIsuDirisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_DIRISU \n");
			sql.append(" SET   \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        PRT_QTY = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND LABEL_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");
			sql.append("   AND PLANT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLblIsuDirisuDVO.getPrtQty());

							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
						}
					}
		);			
	}

/**
* deleteTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return int
*/
	@LocalName("deleteTbpMcLblIsuDirisu")
	public int deleteTbpMcLblIsuDirisu (final TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.deleteTbpMcLblIsuDirisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_DIRISU \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
						}
					}
		);			
	}

/**
* selectTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return TbpMcLblIsuDirisuDVO 
*/
	@LocalName("selectTbpMcLblIsuDirisu")
	public TbpMcLblIsuDirisuDVO selectTbpMcLblIsuDirisu (final TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.selectTbpMcLblIsuDirisu.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRT_QTY \n");
			sql.append("   FROM TBP_MC_LBL_ISU_DIRISU \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");

		return (TbpMcLblIsuDirisuDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbpMcLblIsuDirisuDVO returnTbpMcLblIsuDirisuDVO = new TbpMcLblIsuDirisuDVO();
									returnTbpMcLblIsuDirisuDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbpMcLblIsuDirisuDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbpMcLblIsuDirisuDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbpMcLblIsuDirisuDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbpMcLblIsuDirisuDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbpMcLblIsuDirisuDVO.setRePrtYn(resultSet.getString("RE_PRT_YN"));
									returnTbpMcLblIsuDirisuDVO.setRePrtRsn(resultSet.getString("RE_PRT_RSN"));
									returnTbpMcLblIsuDirisuDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbpMcLblIsuDirisuDVO.setPrtQty(resultSet.getBigDecimal("PRT_QTY"));
									return returnTbpMcLblIsuDirisuDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbpMcLblIsuDirisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbpMcLblIsuDirisu Method")
	public int mergeTbpMcLblIsuDirisu (final TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO) {
		
		if ( selectTbpMcLblIsuDirisu (tbpMcLblIsuDirisuDVO) == null) {
			return insertTbpMcLblIsuDirisu(tbpMcLblIsuDirisuDVO);
		} else {
			return selectUpdateTbpMcLblIsuDirisu (tbpMcLblIsuDirisuDVO);
		}
	}

	/**
	 * selectUpdateTbpMcLblIsuDirisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbpMcLblIsuDirisu Method")
	public int selectUpdateTbpMcLblIsuDirisu (final TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO) {
		
		TbpMcLblIsuDirisuDVO tmpTbpMcLblIsuDirisuDVO =  selectTbpMcLblIsuDirisu (tbpMcLblIsuDirisuDVO);
		if ( tbpMcLblIsuDirisuDVO.getModelCode() != null && !"".equals(tbpMcLblIsuDirisuDVO.getModelCode()) ) {
			tmpTbpMcLblIsuDirisuDVO.setModelCode(tbpMcLblIsuDirisuDVO.getModelCode());
		}		
		if ( tbpMcLblIsuDirisuDVO.getLabelId() != null && !"".equals(tbpMcLblIsuDirisuDVO.getLabelId()) ) {
			tmpTbpMcLblIsuDirisuDVO.setLabelId(tbpMcLblIsuDirisuDVO.getLabelId());
		}		
		if ( tbpMcLblIsuDirisuDVO.getPrtDt() != null && !"".equals(tbpMcLblIsuDirisuDVO.getPrtDt()) ) {
			tmpTbpMcLblIsuDirisuDVO.setPrtDt(tbpMcLblIsuDirisuDVO.getPrtDt());
		}		
		if ( tbpMcLblIsuDirisuDVO.getPlantCode() != null && !"".equals(tbpMcLblIsuDirisuDVO.getPlantCode()) ) {
			tmpTbpMcLblIsuDirisuDVO.setPlantCode(tbpMcLblIsuDirisuDVO.getPlantCode());
		}		
		if ( tbpMcLblIsuDirisuDVO.getPrterId() != null && !"".equals(tbpMcLblIsuDirisuDVO.getPrterId()) ) {
			tmpTbpMcLblIsuDirisuDVO.setPrterId(tbpMcLblIsuDirisuDVO.getPrterId());
		}		
		if ( tbpMcLblIsuDirisuDVO.getRePrtYn() != null && !"".equals(tbpMcLblIsuDirisuDVO.getRePrtYn()) ) {
			tmpTbpMcLblIsuDirisuDVO.setRePrtYn(tbpMcLblIsuDirisuDVO.getRePrtYn());
		}		
		if ( tbpMcLblIsuDirisuDVO.getRePrtRsn() != null && !"".equals(tbpMcLblIsuDirisuDVO.getRePrtRsn()) ) {
			tmpTbpMcLblIsuDirisuDVO.setRePrtRsn(tbpMcLblIsuDirisuDVO.getRePrtRsn());
		}		
		if ( tbpMcLblIsuDirisuDVO.getLineCode() != null && !"".equals(tbpMcLblIsuDirisuDVO.getLineCode()) ) {
			tmpTbpMcLblIsuDirisuDVO.setLineCode(tbpMcLblIsuDirisuDVO.getLineCode());
		}		
		if ( tbpMcLblIsuDirisuDVO.getPrtQty() != null && !"".equals(tbpMcLblIsuDirisuDVO.getPrtQty()) ) {
			tmpTbpMcLblIsuDirisuDVO.setPrtQty(tbpMcLblIsuDirisuDVO.getPrtQty());
		}		
		return updateTbpMcLblIsuDirisu (tmpTbpMcLblIsuDirisuDVO);
	}

/**
* insertBatchTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return int[]
*/
	@LocalName("insertBatchTbpMcLblIsuDirisu")
	public int[] insertBatchTbpMcLblIsuDirisu (final List tbpMcLblIsuDirisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.insertBatchTbpMcLblIsuDirisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_DIRISU (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRT_QTY \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO = (TbpMcLblIsuDirisuDVO)tbpMcLblIsuDirisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLblIsuDirisuDVO.getPrtQty());

						}
							public int getBatchSize() {
									return tbpMcLblIsuDirisuDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return int[]
*/
	@LocalName("updateBatchTbpMcLblIsuDirisu")
	public int[] updateBatchTbpMcLblIsuDirisu (final List tbpMcLblIsuDirisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.updateBatchTbpMcLblIsuDirisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_DIRISU \n");
			sql.append(" SET   \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        PRT_QTY = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND LABEL_ID = ? \n");
			sql.append("   AND PRT_DT = ? \n");
			sql.append("   AND PLANT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO = (TbpMcLblIsuDirisuDVO)tbpMcLblIsuDirisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrterId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getRePrtRsn());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLineCode());
							ps.setBigDecimal(psCount++, tbpMcLblIsuDirisuDVO.getPrtQty());

							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
						}
							public int getBatchSize() {
									return tbpMcLblIsuDirisuDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbpMcLblIsuDirisu Method
* 
* @ref_table TBP_MC_LBL_ISU_DIRISU
* @return int[]
*/
	@LocalName("deleteBatchTbpMcLblIsuDirisu")
	public int[] deleteBatchTbpMcLblIsuDirisu (final List tbpMcLblIsuDirisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLblIsuDirisuDEM.deleteBatchTbpMcLblIsuDirisu.001*/  \n");
			sql.append(" TBP_MC_LBL_ISU_DIRISU \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");
			sql.append("    AND PRT_DT = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLblIsuDirisuDVO tbpMcLblIsuDirisuDVO = (TbpMcLblIsuDirisuDVO)tbpMcLblIsuDirisuDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getModelCode());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getLabelId());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLblIsuDirisuDVO.getPlantCode());
						}
							public int getBatchSize() {
									return tbpMcLblIsuDirisuDVOList.size();
							}
					}
		);			
	}

	
}