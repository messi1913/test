package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcLblCommModelSpecDEM extends AbstractDAO {


/**
* insertTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return int
*/
	@LocalName("insertTbmMcLblCommModelSpec")
	public int insertTbmMcLblCommModelSpec (final TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.insertTbmMcLblCommModelSpec.001*/  \n");
			sql.append(" TBM_MC_LBL_COMM_MODEL_SPEC (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        SPEC_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecValue());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcLblCommModelSpec Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcLblCommModelSpec Method")
	public int[][] updateBatchAllTbmMcLblCommModelSpec (final List  tbmMcLblCommModelSpecDVOList) {
		
		ArrayList updatetbmMcLblCommModelSpecDVOList = new ArrayList();
		ArrayList insertttbmMcLblCommModelSpecDVOList = new ArrayList();
		ArrayList deletetbmMcLblCommModelSpecDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcLblCommModelSpecDVOList.size() ; i++) {
		  TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO = (TbmMcLblCommModelSpecDVO) tbmMcLblCommModelSpecDVOList.get(i);
		  
		  if (tbmMcLblCommModelSpecDVO.getSqlAction().equals("C"))
		      insertttbmMcLblCommModelSpecDVOList.add(tbmMcLblCommModelSpecDVO);
		  else if (tbmMcLblCommModelSpecDVO.getSqlAction().equals("U"))
		      updatetbmMcLblCommModelSpecDVOList.add(tbmMcLblCommModelSpecDVO);
		  else if (tbmMcLblCommModelSpecDVO.getSqlAction().equals("D"))
		      deletetbmMcLblCommModelSpecDVOList.add(tbmMcLblCommModelSpecDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcLblCommModelSpecDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcLblCommModelSpec(insertttbmMcLblCommModelSpecDVOList);
          
      if (updatetbmMcLblCommModelSpecDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcLblCommModelSpec(updatetbmMcLblCommModelSpecDVOList);
      
      if (deletetbmMcLblCommModelSpecDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcLblCommModelSpec(deletetbmMcLblCommModelSpecDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return int
*/
	@LocalName("updateTbmMcLblCommModelSpec")
	public int updateTbmMcLblCommModelSpec (final TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.updateTbmMcLblCommModelSpec.001*/  \n");
			sql.append(" TBM_MC_LBL_COMM_MODEL_SPEC \n");
			sql.append(" SET   \n");
			sql.append("        SPEC_VALUE = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND SPEC_ABBR_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecValue());

							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
						}
					}
		);			
	}

/**
* deleteTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return int
*/
	@LocalName("deleteTbmMcLblCommModelSpec")
	public int deleteTbmMcLblCommModelSpec (final TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.deleteTbmMcLblCommModelSpec.001*/  \n");
			sql.append(" TBM_MC_LBL_COMM_MODEL_SPEC \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND SPEC_ABBR_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
						}
					}
		);			
	}

/**
* selectTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return TbmMcLblCommModelSpecDVO 
*/
	@LocalName("selectTbmMcLblCommModelSpec")
	public TbmMcLblCommModelSpecDVO selectTbmMcLblCommModelSpec (final TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.selectTbmMcLblCommModelSpec.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        SPEC_VALUE \n");
			sql.append("   FROM TBM_MC_LBL_COMM_MODEL_SPEC \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND SPEC_ABBR_NM = ? \n");

		return (TbmMcLblCommModelSpecDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcLblCommModelSpecDVO returnTbmMcLblCommModelSpecDVO = new TbmMcLblCommModelSpecDVO();
									returnTbmMcLblCommModelSpecDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMcLblCommModelSpecDVO.setSpecAbbrNm(resultSet.getString("SPEC_ABBR_NM"));
									returnTbmMcLblCommModelSpecDVO.setSpecValue(resultSet.getString("SPEC_VALUE"));
									return returnTbmMcLblCommModelSpecDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcLblCommModelSpec Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcLblCommModelSpec Method")
	public int mergeTbmMcLblCommModelSpec (final TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO) {
		
		if ( selectTbmMcLblCommModelSpec (tbmMcLblCommModelSpecDVO) == null) {
			return insertTbmMcLblCommModelSpec(tbmMcLblCommModelSpecDVO);
		} else {
			return selectUpdateTbmMcLblCommModelSpec (tbmMcLblCommModelSpecDVO);
		}
	}

	/**
	 * selectUpdateTbmMcLblCommModelSpec Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcLblCommModelSpec Method")
	public int selectUpdateTbmMcLblCommModelSpec (final TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO) {
		
		TbmMcLblCommModelSpecDVO tmpTbmMcLblCommModelSpecDVO =  selectTbmMcLblCommModelSpec (tbmMcLblCommModelSpecDVO);
		if ( tbmMcLblCommModelSpecDVO.getModelCode() != null && !"".equals(tbmMcLblCommModelSpecDVO.getModelCode()) ) {
			tmpTbmMcLblCommModelSpecDVO.setModelCode(tbmMcLblCommModelSpecDVO.getModelCode());
		}		
		if ( tbmMcLblCommModelSpecDVO.getSpecAbbrNm() != null && !"".equals(tbmMcLblCommModelSpecDVO.getSpecAbbrNm()) ) {
			tmpTbmMcLblCommModelSpecDVO.setSpecAbbrNm(tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
		}		
		if ( tbmMcLblCommModelSpecDVO.getSpecValue() != null && !"".equals(tbmMcLblCommModelSpecDVO.getSpecValue()) ) {
			tmpTbmMcLblCommModelSpecDVO.setSpecValue(tbmMcLblCommModelSpecDVO.getSpecValue());
		}		
		return updateTbmMcLblCommModelSpec (tmpTbmMcLblCommModelSpecDVO);
	}

/**
* insertBatchTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return int[]
*/
	@LocalName("insertBatchTbmMcLblCommModelSpec")
	public int[] insertBatchTbmMcLblCommModelSpec (final List tbmMcLblCommModelSpecDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.insertBatchTbmMcLblCommModelSpec.001*/  \n");
			sql.append(" TBM_MC_LBL_COMM_MODEL_SPEC (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        SPEC_VALUE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO = (TbmMcLblCommModelSpecDVO)tbmMcLblCommModelSpecDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecValue());

						}
							public int getBatchSize() {
									return tbmMcLblCommModelSpecDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return int[]
*/
	@LocalName("updateBatchTbmMcLblCommModelSpec")
	public int[] updateBatchTbmMcLblCommModelSpec (final List tbmMcLblCommModelSpecDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.updateBatchTbmMcLblCommModelSpec.001*/  \n");
			sql.append(" TBM_MC_LBL_COMM_MODEL_SPEC \n");
			sql.append(" SET   \n");
			sql.append("        SPEC_VALUE = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND SPEC_ABBR_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO = (TbmMcLblCommModelSpecDVO)tbmMcLblCommModelSpecDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecValue());

							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
						}
							public int getBatchSize() {
									return tbmMcLblCommModelSpecDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcLblCommModelSpec Method
* 
* @ref_table TBM_MC_LBL_COMM_MODEL_SPEC
* @return int[]
*/
	@LocalName("deleteBatchTbmMcLblCommModelSpec")
	public int[] deleteBatchTbmMcLblCommModelSpec (final List tbmMcLblCommModelSpecDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblCommModelSpecDEM.deleteBatchTbmMcLblCommModelSpec.001*/  \n");
			sql.append(" TBM_MC_LBL_COMM_MODEL_SPEC \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND SPEC_ABBR_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblCommModelSpecDVO tbmMcLblCommModelSpecDVO = (TbmMcLblCommModelSpecDVO)tbmMcLblCommModelSpecDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblCommModelSpecDVO.getSpecAbbrNm());
						}
							public int getBatchSize() {
									return tbmMcLblCommModelSpecDVOList.size();
							}
					}
		);			
	}

	
}