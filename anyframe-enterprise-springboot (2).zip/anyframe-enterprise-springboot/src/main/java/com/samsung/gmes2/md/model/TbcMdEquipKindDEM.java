package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_EQUIP_KIND
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdEquipKindDEM extends AbstractDAO {


/**
* insertTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return int
*/
	@LocalName("insertTbcMdEquipKind")
	public int insertTbcMdEquipKind (final TbcMdEquipKindDVO tbcMdEquipKindDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.insertTbcMdEquipKind.001*/  \n");
			sql.append(" TBC_MD_EQUIP_KIND (   \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_KIND_NM , \n");
			sql.append("        EQUIP_GRP_CODE , \n");
			sql.append("        EQUIP_GRP_NM , \n");
			sql.append("        SUPP_OPER_INFO_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpCode());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getSuppOperInfoAplyYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdEquipKind Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdEquipKind Method")
	public int[][] updateBatchAllTbcMdEquipKind (final List  tbcMdEquipKindDVOList) {
		
		ArrayList updatetbcMdEquipKindDVOList = new ArrayList();
		ArrayList insertttbcMdEquipKindDVOList = new ArrayList();
		ArrayList deletetbcMdEquipKindDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdEquipKindDVOList.size() ; i++) {
		  TbcMdEquipKindDVO tbcMdEquipKindDVO = (TbcMdEquipKindDVO) tbcMdEquipKindDVOList.get(i);
		  
		  if (tbcMdEquipKindDVO.getSqlAction().equals("C"))
		      insertttbcMdEquipKindDVOList.add(tbcMdEquipKindDVO);
		  else if (tbcMdEquipKindDVO.getSqlAction().equals("U"))
		      updatetbcMdEquipKindDVOList.add(tbcMdEquipKindDVO);
		  else if (tbcMdEquipKindDVO.getSqlAction().equals("D"))
		      deletetbcMdEquipKindDVOList.add(tbcMdEquipKindDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdEquipKindDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdEquipKind(insertttbcMdEquipKindDVOList);
          
      if (updatetbcMdEquipKindDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdEquipKind(updatetbcMdEquipKindDVOList);
      
      if (deletetbcMdEquipKindDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdEquipKind(deletetbcMdEquipKindDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return int
*/
	@LocalName("updateTbcMdEquipKind")
	public int updateTbcMdEquipKind (final TbcMdEquipKindDVO tbcMdEquipKindDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.updateTbcMdEquipKind.001*/  \n");
			sql.append(" TBC_MD_EQUIP_KIND \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_KIND_NM = ? , \n");
			sql.append("        EQUIP_GRP_CODE = ? , \n");
			sql.append("        EQUIP_GRP_NM = ? , \n");
			sql.append("        SUPP_OPER_INFO_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE EQUIP_KIND_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpCode());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getSuppOperInfoAplyYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
						}
					}
		);			
	}

/**
* deleteTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return int
*/
	@LocalName("deleteTbcMdEquipKind")
	public int deleteTbcMdEquipKind (final TbcMdEquipKindDVO tbcMdEquipKindDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.deleteTbcMdEquipKind.001*/  \n");
			sql.append(" TBC_MD_EQUIP_KIND \n");
			sql.append("  WHERE EQUIP_KIND_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
						}
					}
		);			
	}

/**
* selectTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return TbcMdEquipKindDVO 
*/
	@LocalName("selectTbcMdEquipKind")
	public TbcMdEquipKindDVO selectTbcMdEquipKind (final TbcMdEquipKindDVO tbcMdEquipKindDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.selectTbcMdEquipKind.001*/  \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_KIND_NM , \n");
			sql.append("        EQUIP_GRP_CODE , \n");
			sql.append("        EQUIP_GRP_NM , \n");
			sql.append("        SUPP_OPER_INFO_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_EQUIP_KIND \n");
			sql.append("  WHERE EQUIP_KIND_CODE = ? \n");

		return (TbcMdEquipKindDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdEquipKindDVO returnTbcMdEquipKindDVO = new TbcMdEquipKindDVO();
									returnTbcMdEquipKindDVO.setEquipKindCode(resultSet.getString("EQUIP_KIND_CODE"));
									returnTbcMdEquipKindDVO.setEquipKindNm(resultSet.getString("EQUIP_KIND_NM"));
									returnTbcMdEquipKindDVO.setEquipGrpCode(resultSet.getString("EQUIP_GRP_CODE"));
									returnTbcMdEquipKindDVO.setEquipGrpNm(resultSet.getString("EQUIP_GRP_NM"));
									returnTbcMdEquipKindDVO.setSuppOperInfoAplyYn(resultSet.getString("SUPP_OPER_INFO_APLY_YN"));
									returnTbcMdEquipKindDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdEquipKindDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdEquipKindDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdEquipKindDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdEquipKindDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdEquipKindDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdEquipKind Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdEquipKind Method")
	public int mergeTbcMdEquipKind (final TbcMdEquipKindDVO tbcMdEquipKindDVO) {
		
		if ( selectTbcMdEquipKind (tbcMdEquipKindDVO) == null) {
			return insertTbcMdEquipKind(tbcMdEquipKindDVO);
		} else {
			return selectUpdateTbcMdEquipKind (tbcMdEquipKindDVO);
		}
	}

	/**
	 * selectUpdateTbcMdEquipKind Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdEquipKind Method")
	public int selectUpdateTbcMdEquipKind (final TbcMdEquipKindDVO tbcMdEquipKindDVO) {
		
		TbcMdEquipKindDVO tmpTbcMdEquipKindDVO =  selectTbcMdEquipKind (tbcMdEquipKindDVO);
		if ( tbcMdEquipKindDVO.getEquipKindCode() != null && !"".equals(tbcMdEquipKindDVO.getEquipKindCode()) ) {
			tmpTbcMdEquipKindDVO.setEquipKindCode(tbcMdEquipKindDVO.getEquipKindCode());
		}		
		if ( tbcMdEquipKindDVO.getEquipKindNm() != null && !"".equals(tbcMdEquipKindDVO.getEquipKindNm()) ) {
			tmpTbcMdEquipKindDVO.setEquipKindNm(tbcMdEquipKindDVO.getEquipKindNm());
		}		
		if ( tbcMdEquipKindDVO.getEquipGrpCode() != null && !"".equals(tbcMdEquipKindDVO.getEquipGrpCode()) ) {
			tmpTbcMdEquipKindDVO.setEquipGrpCode(tbcMdEquipKindDVO.getEquipGrpCode());
		}		
		if ( tbcMdEquipKindDVO.getEquipGrpNm() != null && !"".equals(tbcMdEquipKindDVO.getEquipGrpNm()) ) {
			tmpTbcMdEquipKindDVO.setEquipGrpNm(tbcMdEquipKindDVO.getEquipGrpNm());
		}		
		if ( tbcMdEquipKindDVO.getSuppOperInfoAplyYn() != null && !"".equals(tbcMdEquipKindDVO.getSuppOperInfoAplyYn()) ) {
			tmpTbcMdEquipKindDVO.setSuppOperInfoAplyYn(tbcMdEquipKindDVO.getSuppOperInfoAplyYn());
		}		
		if ( tbcMdEquipKindDVO.getUseYn() != null && !"".equals(tbcMdEquipKindDVO.getUseYn()) ) {
			tmpTbcMdEquipKindDVO.setUseYn(tbcMdEquipKindDVO.getUseYn());
		}		
		if ( tbcMdEquipKindDVO.getFstRegDt() != null && !"".equals(tbcMdEquipKindDVO.getFstRegDt()) ) {
			tmpTbcMdEquipKindDVO.setFstRegDt(tbcMdEquipKindDVO.getFstRegDt());
		}		
		if ( tbcMdEquipKindDVO.getFstRegerId() != null && !"".equals(tbcMdEquipKindDVO.getFstRegerId()) ) {
			tmpTbcMdEquipKindDVO.setFstRegerId(tbcMdEquipKindDVO.getFstRegerId());
		}		
		if ( tbcMdEquipKindDVO.getFnlUpdDt() != null && !"".equals(tbcMdEquipKindDVO.getFnlUpdDt()) ) {
			tmpTbcMdEquipKindDVO.setFnlUpdDt(tbcMdEquipKindDVO.getFnlUpdDt());
		}		
		if ( tbcMdEquipKindDVO.getFnlUpderId() != null && !"".equals(tbcMdEquipKindDVO.getFnlUpderId()) ) {
			tmpTbcMdEquipKindDVO.setFnlUpderId(tbcMdEquipKindDVO.getFnlUpderId());
		}		
		return updateTbcMdEquipKind (tmpTbcMdEquipKindDVO);
	}

/**
* insertBatchTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return int[]
*/
	@LocalName("insertBatchTbcMdEquipKind")
	public int[] insertBatchTbcMdEquipKind (final List tbcMdEquipKindDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.insertBatchTbcMdEquipKind.001*/  \n");
			sql.append(" TBC_MD_EQUIP_KIND (   \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_KIND_NM , \n");
			sql.append("        EQUIP_GRP_CODE , \n");
			sql.append("        EQUIP_GRP_NM , \n");
			sql.append("        SUPP_OPER_INFO_APLY_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdEquipKindDVO tbcMdEquipKindDVO = (TbcMdEquipKindDVO)tbcMdEquipKindDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpCode());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getSuppOperInfoAplyYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdEquipKindDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return int[]
*/
	@LocalName("updateBatchTbcMdEquipKind")
	public int[] updateBatchTbcMdEquipKind (final List tbcMdEquipKindDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.updateBatchTbcMdEquipKind.001*/  \n");
			sql.append(" TBC_MD_EQUIP_KIND \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_KIND_NM = ? , \n");
			sql.append("        EQUIP_GRP_CODE = ? , \n");
			sql.append("        EQUIP_GRP_NM = ? , \n");
			sql.append("        SUPP_OPER_INFO_APLY_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE EQUIP_KIND_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdEquipKindDVO tbcMdEquipKindDVO = (TbcMdEquipKindDVO)tbcMdEquipKindDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpCode());
							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipGrpNm());
							ps.setString(psCount++, tbcMdEquipKindDVO.getSuppOperInfoAplyYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getUseYn());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdEquipKindDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
						}
							public int getBatchSize() {
									return tbcMdEquipKindDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdEquipKind Method
* 
* @ref_table TBC_MD_EQUIP_KIND
* @return int[]
*/
	@LocalName("deleteBatchTbcMdEquipKind")
	public int[] deleteBatchTbcMdEquipKind (final List tbcMdEquipKindDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdEquipKindDEM.deleteBatchTbcMdEquipKind.001*/  \n");
			sql.append(" TBC_MD_EQUIP_KIND \n");
			sql.append("  WHERE EQUIP_KIND_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdEquipKindDVO tbcMdEquipKindDVO = (TbcMdEquipKindDVO)tbcMdEquipKindDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdEquipKindDVO.getEquipKindCode());
						}
							public int getBatchSize() {
									return tbcMdEquipKindDVOList.size();
							}
					}
		);			
	}

	
}