package com.samsung.gmes2.md.mmdm.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractSVO;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import java.util.List;
import java.util.ArrayList;

/**
 * 기준 공통조직코드
 * @stereotype SVO
 * @author sjlee
 */
public class MdU713M01SVO extends AbstractSVO {

	@LocalName("기준 공통조직코드") 
	private TbcMdCommOrgDVO tbcMdCommOrgDVO;

	@LocalName("기준 공통조직코드 리스트") 
	private List<TbcMdCommOrgDVO> tbcMdCommOrgDVOList;


	/**
	 * 기준 공통조직코드 Getter Method
	 * 
	 * @return 기준 공통조직코드
	 */
	@LocalName("기준 공통조직코드 Getter Method")
	public TbcMdCommOrgDVO getTbcMdCommOrgDVO() {
		this.tbcMdCommOrgDVO = super.getValue("tbcMdCommOrgDVO");
		return this.tbcMdCommOrgDVO;
	}

	/**
	 * 기준 공통조직코드 Setter Method
	 * 
	 * @param TbcMdCommOrgDVO 기준 공통조직코드
	 */
	@LocalName("기준 공통조직코드 Setter Method")
	public void setTbcMdCommOrgDVO(TbcMdCommOrgDVO tbcMdCommOrgDVO) {
        super.setValue("tbcMdCommOrgDVO", tbcMdCommOrgDVO);
		this.tbcMdCommOrgDVO = tbcMdCommOrgDVO;
	}
	
	/**
	 * 기준 공통조직코드 리스트 Getter Method
	 * 
	 * @return 기준 공통조직코드 리스트
	 */
	@LocalName("기준 공통조직코드 리스트 Getter Method")
	public List<TbcMdCommOrgDVO> getTbcMdCommOrgDVOList() {
		this.tbcMdCommOrgDVOList = super.getValue("tbcMdCommOrgDVOList");
		return this.tbcMdCommOrgDVOList;
	}

	/**
	 * 기준 공통조직코드 리스트 Setter Method
	 * 
	 * @param List 기준 공통조직코드 리스트
	 */
	@LocalName("기준 공통조직코드 리스트 Setter Method")
	public void setTbcMdCommOrgDVOList(List<TbcMdCommOrgDVO> tbcMdCommOrgDVOList) {
	    super.setValue("tbcMdCommOrgDVOList", tbcMdCommOrgDVOList);
		this.tbcMdCommOrgDVOList = tbcMdCommOrgDVOList;
	}
	
}