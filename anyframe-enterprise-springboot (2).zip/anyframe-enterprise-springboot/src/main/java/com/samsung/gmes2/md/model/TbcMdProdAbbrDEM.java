package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_PROD_ABBR
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdProdAbbrDEM extends AbstractDAO {


/**
* insertTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return int
*/
	@LocalName("insertTbcMdProdAbbr")
	public int insertTbcMdProdAbbr (final TbcMdProdAbbrDVO tbcMdProdAbbrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.insertTbcMdProdAbbr.001*/  \n");
			sql.append(" TBC_MD_PROD_ABBR (   \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_NM , \n");
			sql.append("        PROD_KIND_CHG_BASIC_PRODC_QTY , \n");
			sql.append("        OUT_INSP_CLOSE_HMS , \n");
			sql.append("        MFG_PRCSS_COST_USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrNm());
							ps.setBigDecimal(psCount++, tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getOutInspCloseHms());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getMfgPrcssCostUseYn());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdProdAbbr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdProdAbbr Method")
	public int[][] updateBatchAllTbcMdProdAbbr (final List  tbcMdProdAbbrDVOList) {
		
		ArrayList updatetbcMdProdAbbrDVOList = new ArrayList();
		ArrayList insertttbcMdProdAbbrDVOList = new ArrayList();
		ArrayList deletetbcMdProdAbbrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdProdAbbrDVOList.size() ; i++) {
		  TbcMdProdAbbrDVO tbcMdProdAbbrDVO = (TbcMdProdAbbrDVO) tbcMdProdAbbrDVOList.get(i);
		  
		  if (tbcMdProdAbbrDVO.getSqlAction().equals("C"))
		      insertttbcMdProdAbbrDVOList.add(tbcMdProdAbbrDVO);
		  else if (tbcMdProdAbbrDVO.getSqlAction().equals("U"))
		      updatetbcMdProdAbbrDVOList.add(tbcMdProdAbbrDVO);
		  else if (tbcMdProdAbbrDVO.getSqlAction().equals("D"))
		      deletetbcMdProdAbbrDVOList.add(tbcMdProdAbbrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdProdAbbrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdProdAbbr(insertttbcMdProdAbbrDVOList);
          
      if (updatetbcMdProdAbbrDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdProdAbbr(updatetbcMdProdAbbrDVOList);
      
      if (deletetbcMdProdAbbrDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdProdAbbr(deletetbcMdProdAbbrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return int
*/
	@LocalName("updateTbcMdProdAbbr")
	public int updateTbcMdProdAbbr (final TbcMdProdAbbrDVO tbcMdProdAbbrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.updateTbcMdProdAbbr.001*/  \n");
			sql.append(" TBC_MD_PROD_ABBR \n");
			sql.append(" SET   \n");
			sql.append("        PROD_GRP_CODE = ? , \n");
			sql.append("        PROD_ABBR_NM = ? , \n");
			sql.append("        PROD_KIND_CHG_BASIC_PRODC_QTY = ? , \n");
			sql.append("        OUT_INSP_CLOSE_HMS = ? , \n");
			sql.append("        MFG_PRCSS_COST_USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_ABBR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrNm());
							ps.setBigDecimal(psCount++, tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getOutInspCloseHms());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getMfgPrcssCostUseYn());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
						}
					}
		);			
	}

/**
* deleteTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return int
*/
	@LocalName("deleteTbcMdProdAbbr")
	public int deleteTbcMdProdAbbr (final TbcMdProdAbbrDVO tbcMdProdAbbrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.deleteTbcMdProdAbbr.001*/  \n");
			sql.append(" TBC_MD_PROD_ABBR \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
						}
					}
		);			
	}

/**
* selectTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return TbcMdProdAbbrDVO 
*/
	@LocalName("selectTbcMdProdAbbr")
	public TbcMdProdAbbrDVO selectTbcMdProdAbbr (final TbcMdProdAbbrDVO tbcMdProdAbbrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.selectTbcMdProdAbbr.001*/  \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_NM , \n");
			sql.append("        PROD_KIND_CHG_BASIC_PRODC_QTY , \n");
			sql.append("        OUT_INSP_CLOSE_HMS , \n");
			sql.append("        MFG_PRCSS_COST_USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_PROD_ABBR \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");

		return (TbcMdProdAbbrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdProdAbbrDVO returnTbcMdProdAbbrDVO = new TbcMdProdAbbrDVO();
									returnTbcMdProdAbbrDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbcMdProdAbbrDVO.setProdGrpCode(resultSet.getString("PROD_GRP_CODE"));
									returnTbcMdProdAbbrDVO.setProdAbbrNm(resultSet.getString("PROD_ABBR_NM"));
									returnTbcMdProdAbbrDVO.setProdKindChgBasicProdcQty(resultSet.getBigDecimal("PROD_KIND_CHG_BASIC_PRODC_QTY"));
									returnTbcMdProdAbbrDVO.setOutInspCloseHms(resultSet.getString("OUT_INSP_CLOSE_HMS"));
									returnTbcMdProdAbbrDVO.setMfgPrcssCostUseYn(resultSet.getString("MFG_PRCSS_COST_USE_YN"));
									returnTbcMdProdAbbrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProdAbbrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProdAbbrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProdAbbrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProdAbbrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdProdAbbr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdProdAbbr Method")
	public int mergeTbcMdProdAbbr (final TbcMdProdAbbrDVO tbcMdProdAbbrDVO) {
		
		if ( selectTbcMdProdAbbr (tbcMdProdAbbrDVO) == null) {
			return insertTbcMdProdAbbr(tbcMdProdAbbrDVO);
		} else {
			return selectUpdateTbcMdProdAbbr (tbcMdProdAbbrDVO);
		}
	}

	/**
	 * selectUpdateTbcMdProdAbbr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdProdAbbr Method")
	public int selectUpdateTbcMdProdAbbr (final TbcMdProdAbbrDVO tbcMdProdAbbrDVO) {
		
		TbcMdProdAbbrDVO tmpTbcMdProdAbbrDVO =  selectTbcMdProdAbbr (tbcMdProdAbbrDVO);
		if ( tbcMdProdAbbrDVO.getProdAbbrCode() != null && !"".equals(tbcMdProdAbbrDVO.getProdAbbrCode()) ) {
			tmpTbcMdProdAbbrDVO.setProdAbbrCode(tbcMdProdAbbrDVO.getProdAbbrCode());
		}		
		if ( tbcMdProdAbbrDVO.getProdGrpCode() != null && !"".equals(tbcMdProdAbbrDVO.getProdGrpCode()) ) {
			tmpTbcMdProdAbbrDVO.setProdGrpCode(tbcMdProdAbbrDVO.getProdGrpCode());
		}		
		if ( tbcMdProdAbbrDVO.getProdAbbrNm() != null && !"".equals(tbcMdProdAbbrDVO.getProdAbbrNm()) ) {
			tmpTbcMdProdAbbrDVO.setProdAbbrNm(tbcMdProdAbbrDVO.getProdAbbrNm());
		}		
		if ( tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty() != null && !"".equals(tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty()) ) {
			tmpTbcMdProdAbbrDVO.setProdKindChgBasicProdcQty(tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty());
		}		
		if ( tbcMdProdAbbrDVO.getOutInspCloseHms() != null && !"".equals(tbcMdProdAbbrDVO.getOutInspCloseHms()) ) {
			tmpTbcMdProdAbbrDVO.setOutInspCloseHms(tbcMdProdAbbrDVO.getOutInspCloseHms());
		}		
		if ( tbcMdProdAbbrDVO.getMfgPrcssCostUseYn() != null && !"".equals(tbcMdProdAbbrDVO.getMfgPrcssCostUseYn()) ) {
			tmpTbcMdProdAbbrDVO.setMfgPrcssCostUseYn(tbcMdProdAbbrDVO.getMfgPrcssCostUseYn());
		}		
		if ( tbcMdProdAbbrDVO.getFstRegDt() != null && !"".equals(tbcMdProdAbbrDVO.getFstRegDt()) ) {
			tmpTbcMdProdAbbrDVO.setFstRegDt(tbcMdProdAbbrDVO.getFstRegDt());
		}		
		if ( tbcMdProdAbbrDVO.getFstRegerId() != null && !"".equals(tbcMdProdAbbrDVO.getFstRegerId()) ) {
			tmpTbcMdProdAbbrDVO.setFstRegerId(tbcMdProdAbbrDVO.getFstRegerId());
		}		
		if ( tbcMdProdAbbrDVO.getFnlUpdDt() != null && !"".equals(tbcMdProdAbbrDVO.getFnlUpdDt()) ) {
			tmpTbcMdProdAbbrDVO.setFnlUpdDt(tbcMdProdAbbrDVO.getFnlUpdDt());
		}		
		if ( tbcMdProdAbbrDVO.getFnlUpderId() != null && !"".equals(tbcMdProdAbbrDVO.getFnlUpderId()) ) {
			tmpTbcMdProdAbbrDVO.setFnlUpderId(tbcMdProdAbbrDVO.getFnlUpderId());
		}		
		return updateTbcMdProdAbbr (tmpTbcMdProdAbbrDVO);
	}

/**
* insertBatchTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return int[]
*/
	@LocalName("insertBatchTbcMdProdAbbr")
	public int[] insertBatchTbcMdProdAbbr (final List tbcMdProdAbbrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.insertBatchTbcMdProdAbbr.001*/  \n");
			sql.append(" TBC_MD_PROD_ABBR (   \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_NM , \n");
			sql.append("        PROD_KIND_CHG_BASIC_PRODC_QTY , \n");
			sql.append("        OUT_INSP_CLOSE_HMS , \n");
			sql.append("        MFG_PRCSS_COST_USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdAbbrDVO tbcMdProdAbbrDVO = (TbcMdProdAbbrDVO)tbcMdProdAbbrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrNm());
							ps.setBigDecimal(psCount++, tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getOutInspCloseHms());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getMfgPrcssCostUseYn());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdProdAbbrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return int[]
*/
	@LocalName("updateBatchTbcMdProdAbbr")
	public int[] updateBatchTbcMdProdAbbr (final List tbcMdProdAbbrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.updateBatchTbcMdProdAbbr.001*/  \n");
			sql.append(" TBC_MD_PROD_ABBR \n");
			sql.append(" SET   \n");
			sql.append("        PROD_GRP_CODE = ? , \n");
			sql.append("        PROD_ABBR_NM = ? , \n");
			sql.append("        PROD_KIND_CHG_BASIC_PRODC_QTY = ? , \n");
			sql.append("        OUT_INSP_CLOSE_HMS = ? , \n");
			sql.append("        MFG_PRCSS_COST_USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_ABBR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdAbbrDVO tbcMdProdAbbrDVO = (TbcMdProdAbbrDVO)tbcMdProdAbbrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrNm());
							ps.setBigDecimal(psCount++, tbcMdProdAbbrDVO.getProdKindChgBasicProdcQty());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getOutInspCloseHms());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getMfgPrcssCostUseYn());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdProdAbbrDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
						}
							public int getBatchSize() {
									return tbcMdProdAbbrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdProdAbbr Method
* 
* @ref_table TBC_MD_PROD_ABBR
* @return int[]
*/
	@LocalName("deleteBatchTbcMdProdAbbr")
	public int[] deleteBatchTbcMdProdAbbr (final List tbcMdProdAbbrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdProdAbbrDEM.deleteBatchTbcMdProdAbbr.001*/  \n");
			sql.append(" TBC_MD_PROD_ABBR \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdProdAbbrDVO tbcMdProdAbbrDVO = (TbcMdProdAbbrDVO)tbcMdProdAbbrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdProdAbbrDVO.getProdAbbrCode());
						}
							public int getBatchSize() {
									return tbcMdProdAbbrDVOList.size();
							}
					}
		);			
	}

	
}