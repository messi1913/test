package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdEquipKindDVO extends AbstractVo {

	@Length(30) 
	private String equipKindCode;

	@Length(500) 
	private String equipKindNm;

	@Length(30) 
	private String equipGrpCode;

	@Length(500) 
	private String equipGrpNm;

	@Length(1) 
	private String suppOperInfoAplyYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getEquipKindCode() {
		this.equipKindCode = super.getValue(0);
		return this.equipKindCode;
	}

	public void setEquipKindCode(String equipKindCode) {
        super.setValue(0, equipKindCode);
		this.equipKindCode = equipKindCode;
	}
	
	public String getEquipKindNm() {
		this.equipKindNm = super.getValue(1);
		return this.equipKindNm;
	}

	public void setEquipKindNm(String equipKindNm) {
        super.setValue(1, equipKindNm);
		this.equipKindNm = equipKindNm;
	}
	
	public String getEquipGrpCode() {
		this.equipGrpCode = super.getValue(2);
		return this.equipGrpCode;
	}

	public void setEquipGrpCode(String equipGrpCode) {
        super.setValue(2, equipGrpCode);
		this.equipGrpCode = equipGrpCode;
	}
	
	public String getEquipGrpNm() {
		this.equipGrpNm = super.getValue(3);
		return this.equipGrpNm;
	}

	public void setEquipGrpNm(String equipGrpNm) {
        super.setValue(3, equipGrpNm);
		this.equipGrpNm = equipGrpNm;
	}
	
	public String getSuppOperInfoAplyYn() {
		this.suppOperInfoAplyYn = super.getValue(4);
		return this.suppOperInfoAplyYn;
	}

	public void setSuppOperInfoAplyYn(String suppOperInfoAplyYn) {
        super.setValue(4, suppOperInfoAplyYn);
		this.suppOperInfoAplyYn = suppOperInfoAplyYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(5);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(5, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(6);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(6, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(7);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(7, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(8);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(8, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(9);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(9, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}