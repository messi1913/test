package com.samsung.gmes2.md.mmdm.app;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.samsung.gmes2.base.Constants;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.md.cmm.MdConstants;
import com.samsung.gmes2.md.mdm.biz.MdManageTbcMdCommOrgBiz;
import com.samsung.gmes2.md.mmdm.vo.MdU712M01DQM;
import com.samsung.gmes2.md.mmdm.vo.MdU712M01SVO;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;

/**
 * 권역코드
 * 
 * @author sjlee
 */
@Service
public class MdU712M01App
{
    private MdManageTbcMdCommOrgBiz mdManageTbcMdCommOrgBiz;

    public MdManageTbcMdCommOrgBiz getMdManageTbcMdCommOrgBiz( )
    {
        if ( mdManageTbcMdCommOrgBiz == null )
            mdManageTbcMdCommOrgBiz = BaseUtil.getBean( MdManageTbcMdCommOrgBiz.class );
        return mdManageTbcMdCommOrgBiz;
    }

    public void setMdManageTbcMdCommOrgBiz( MdManageTbcMdCommOrgBiz mdManageTbcMdCommOrgBiz )
    {
        this.mdManageTbcMdCommOrgBiz = mdManageTbcMdCommOrgBiz;
    }

    /**
     * 권역코드 리스트를 조회한다.
     * 
     * @name_ko 권역코드 조회
     */
    public MdU712M01SVO listRegionCode( MdU712M01SVO vo ) throws Exception
    {
        TbcMdCommOrgDVO dvo = vo.getTbcMdCommOrgDVO( );

        if ( dvo != null )
        {
            dvo.setCommOrgTypeCode( MdConstants.REGION_CODE );
        }

        Map<String, Object> map = BaseUtil.toMap( dvo );
        List<TbcMdCommOrgDVO> dvoList = BaseUtil.getBean( MdU712M01DQM.class ).dListRegionCode( map, 1, 3000 );

        if ( dvoList.size( ) > 0 )
        {
            vo.setTbcMdCommOrgDVOList( dvoList );
            return vo;
        }

        return null;
    }

    /**
     * 새로 등록하거나 수정한 권역코드를 저장한다.
     * 
     * @name_ko 권역코드 등록
     */
    public MdU712M01SVO saveRegionCode( MdU712M01SVO vo ) throws Exception
    {
        List<TbcMdCommOrgDVO> dvoList = vo.getTbcMdCommOrgDVOList( );
        for ( int i = 0; i < dvoList.size( ); i++ )
        {
            TbcMdCommOrgDVO dvo = new TbcMdCommOrgDVO( );
            BaseUtil.populate( dvoList.get( i ), dvo );
            if ( vo.getStringDVOList( ).get( i ).getValue( ).equals( Constants.INSERT_FLAG ) )
            {
                vo.setTbcMdCommOrgDVO( dvo );
                createRegionCode( vo );
            }
            else if ( vo.getStringDVOList( ).get( i ).getValue( ).equals( Constants.UPDATE_FLAG ) )
            {
                vo.setTbcMdCommOrgDVO( dvo );
                updateRegionCode( vo );
            }
        }

        return vo;
    }

    /**
     * 권역코드를 등록한다.
     * 
     * @name_ko 권역코드 등록
     */
    public MdU712M01SVO createRegionCode( MdU712M01SVO vo ) throws Exception
    {
        TbcMdCommOrgDVO dvo = vo.getTbcMdCommOrgDVO( );
        vo.setTbcMdCommOrgDVO( this.getMdManageTbcMdCommOrgBiz( ).createNewRegionCodeData( dvo ) );

        return vo;
    }

    /**
     * 권역코드 리스트를 수정한다.
     * 
     * @name_ko 권역코드 수정
     */
    public MdU712M01SVO updateRegionCode( MdU712M01SVO vo ) throws Exception
    {
        TbcMdCommOrgDVO dvo = vo.getTbcMdCommOrgDVO( );
        vo.setTbcMdCommOrgDVO( this.getMdManageTbcMdCommOrgBiz( ).updateTbcMdCommOrgRow( dvo ) );

        return vo;
    }
}
