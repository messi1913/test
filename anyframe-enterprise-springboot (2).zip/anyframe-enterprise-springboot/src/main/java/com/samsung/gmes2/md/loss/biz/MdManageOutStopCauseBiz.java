package com.samsung.gmes2.md.loss.biz;

public class MdManageOutStopCauseBiz {

	/**
	 * 출하중지원인코드 목록 조회
	 */
	public void listOutStopCauseCode(){}

	/**
	 * 출하중지원인코드 목록 저장
	 */
	public void saveOutStopCauseCode(){}

}
