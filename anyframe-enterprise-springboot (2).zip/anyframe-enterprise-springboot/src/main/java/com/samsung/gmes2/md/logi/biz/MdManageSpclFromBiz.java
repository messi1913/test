package com.samsung.gmes2.md.logi.biz;

public class MdManageSpclFromBiz {

	/**
	 * 특수형태정보 목록 조회
	 */
	public void listSpclForm(){}

	/**
	 * 특수형태정보 목록 저장
	 */
	public void saveSpclForm(){}

}
