package com.samsung.gmes2.bi.biu;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

import com.samsung.gmes2.bi.biu.vo.BiU456M0001DVO;

/**
* 
*
* @ref_table  
* @author kwjfresh
*/
@Stereotype(Stereotype.Dao) @LocalName("수율현황 조회")
public class BiU456M00DQM extends AbstractDAO {


/**
*
* select sector, gbm, product, plant, subcomponentNm as componentNm, total, date01, date02 , date03, date04, date05, date06, date07  
* from (  
*     select sector, gbm,  
*         decode(gbm,'total','  ',product) as product,  
*         decode(product,'total','  ',plant) as plant,  
*         substr(componentNm,2) as subcomponentNm, total, date01, date02 , date03, date04, date05, date06, date07  
*     from ( 
*         select sector, gbm, product, plant, componentNm, TOTAL,
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType)     , :dateType), qty, 0)) as date01,       
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 1 , :dateType), qty, 0)) as date02,      
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 2 , :dateType), qty, 0)) as date03,     
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 3 , :dateType), qty, 0)) as date04,       
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 4 , :dateType), qty, 0)) as date05,      
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 5 , :dateType), qty, 0)) as date06,     
*             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 6 , :dateType), qty, 0)) as date07     
*         from (    
*             SELECT sector, gbm, product, plant, componentNm, qty, TIMEPOINTVALUE, 
*                 DECODE(componentNm, :inspectQty, TOTALINSPECTQTY,DECODE(componentNm, :goodQty, TOTALGOODQTY, DECODE(componentNm, :ratio,TOTALRATIO))) AS TOTAL
*             FROM (
*                 select sector, gbm, product, plant, B.GUBUN as componentNm,   
*                     decode(B.GUBUN, :inspectQty, inspectqty, decode(B.GUBUN, :goodQty, goodqty,  decode(B.GUBUN, :ratio, ratio , 0))) as qty,  
*                     TIMEPOINTVALUE, TOTALINSPECTQTY, TOTALGOODQTY, TOTALRATIO
*                 FROM (
*                     SELECT sector,GBM, PRODUCT, PLANT, INSPECTQTY, GOODQTY, RATIO , TIMEPOINTVALUE, NUM,
*                         TOTALINSPECTQTY, TOTALGOODQTY, ROUND(TOTALGOODQTY / TOTALINSPECTQTY * 100,2) AS TOTALRATIO
*                     FROM (
*                         SELECT sector,GBM, PRODUCT, PLANT, INSPECTQTY, GOODQTY, ROUND(GOODQTY / INSPECTQTY *100,2) AS RATIO , TIMEPOINTVALUE, NUM,
*                             SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT) AS TOTALINSPECTQTY,
*                             SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT) AS TOTALGOODQTY
*                         FROM ( 
*                             SELECT sector,GBM, PRODUCT, PLANT, INSPECTQTY, GOODQTY, RATIO, TIMEPOINTVALUE, 
*                                 ROW_NUMBER() OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT||TIMEPOINTVALUE  ORDER BY PLANT) AS NUM 
*                             FROM ( 
*                                 select sector,GBM, PRODUCT, PLANT,  
*                                     decode(gbm,'total', SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||TIMEPOINTVALUE), 
*                                         decode(product,'total',SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||TIMEPOINTVALUE), 
*                                             decode(plant,'total', SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT||TIMEPOINTVALUE), 
*                                                 INSPECTQTY))) AS INSPECTQTY, 
*                                     decode(gbm,'total', SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||TIMEPOINTVALUE), 
*                                         decode(product,'total',SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||TIMEPOINTVALUE), 
*                                             decode(plant,'total', SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT||TIMEPOINTVALUE), 
*                                                 GOODQTY))) AS GOODQTY, '' AS RATIO, TIMEPOINTVALUE 
*                                 from ( 
*                                     select sector,  
*                                         decode(GUBUN1, 'A',  A2.gbm, decode(GUBUN1, 'B',  A2.gbm,  decode(GUBUN1, 'C',  A2.gbm,'total')))  as gbm, 
*                                         decode(GUBUN1, 'A',  A2.product, decode(GUBUN1, 'B',  A2.product,'total'))  as product, 
*                                         decode(GUBUN1, 'A',  A2.plant, 'total') as plant,   
*                                         INSPECTQTY, GOODQTY, TIMEPOINTVALUE 
*                                     from ( 
*                                         SELECT SECTOR, GBM, PRODUCT, PLANT,  
*                                             NVL(MAX( DECODE( COMPONENTNM, :inspectName, QTY )),'') AS INSPECTQTY,  
*                                             NVL(MAX( DECODE( COMPONENTNM, :goodName, QTY )),'') AS GOODQTY, TIMEPOINTVALUE  
*                                         FROM (  
*                                             SELECT SECTOR, GBM, PRODUCT, PLANT, COMPONENTNM, QTY, TIMEPOINTVALUE  
*                                             FROM(  
*                                                 SELECT 'SET' AS SECTOR, COMM.CODE_ATTR_1 AS GBM, 'VD' AS PRODUCT, COMM.COMM_CODE_NM AS PLANT,  
*                                                     CPN.COMPONENT_NM AS COMPONENTNM, CPND.COMPONENT_VALUE AS QTY,  
*                                                     CPND.TIMEPOINT_CLSF, CPND.TIMEPOINT_VALUE AS TIMEPOINTVALUE, CPND.LINE_CODE, IDC.IDC_CODE, IDCC.COMPONENT_CODE  
*                                                 FROM TBM_BI_IDC IDC, TBP_BI_IDC_COMPONENT IDCC, TBM_BI_COMPONENT CPN, TBP_BI_COMPONENT_DATA CPND, TBC_MD_COMM_CODE COMM  
*                                                 WHERE 1=1  
*                                                     AND IDC.IDC_CODE = IDCC.IDC_CODE  
*                                                     AND IDCC.COMPONENT_CODE = CPN.COMPONENT_CODE  
*                                                     AND CPN.COMPONENT_CODE = CPND.COMPONENT_CODE  
*                                                     AND COMM.COMM_CODE = CPND.PLANT_CODE  
*                                                     AND COMM.TYPE_CODE = 'PLANT_CODE'  
*                                                     AND IDC.IDC_CODE = '4.5.6'  
*                                                     AND IDCC.IDC_COMPONENT_CLSF_CODE = 'C'  
*                                                     AND CPND.TIMEPOINT_CLSF = :timePoint
*                                                     AND IDCC.COMPONENT_CODE IN (:lineCode1, :lineCode2) 
*                                                     AND CPND.TIMEPOINT_VALUE >= :fromDate   
*                                                     AND CPND.TIMEPOINT_VALUE <= :toDate   
*                                                 )  
*                                             )  
*                                             GROUP BY SECTOR, GBM, PRODUCT, PLANT, TIMEPOINTVALUE 
*                                         ) A2, (  
*                                         select 'A' as GUBUN1 from dual  
*                                         union all  
*                                         select 'B' as GUBUN1 from dual  
*                                         union all  
*                                         select 'C' as GUBUN1 from dual      
*                                         union all  
*                                         select 'D' as GUBUN1 from dual  
*                                         ) B2 
*                                     ) 
*                                 ) 
*                             ) 
*                             WHERE NUM = 1
*                         )
*                     )A, (  
*                     select :inspectQty as GUBUN from dual  
*                     union all  
*                     select :goodQty as GUBUN from dual  
*                     union all  
*                     select :ratio as GUBUN from dual  
*                     ) B
*                 )
*             )
*         group by sector, gbm, product, plant, componentNm, TOTAL
*     ) 
* order by sector desc, gbm desc, product desc, plant desc, componentNm   
* ) 
* 
* @ref_table 
* @return List
*
*/
	public List dListDetailList (final Map inputMap) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" select sector, gbm, product, plant, subcomponentNm as componentNm, total, date01, date02 , date03, date04, date05, date06, date07   \n");
			sql.append(" from (   \n");
			sql.append("     select sector, gbm,   \n");
			sql.append("         decode(gbm,'total','  ',product) as product,   \n");
			sql.append("         decode(product,'total','  ',plant) as plant,   \n");
			sql.append("         substr(componentNm,2) as subcomponentNm, total, date01, date02 , date03, date04, date05, date06, date07   \n");
			sql.append("     from (  \n");
			sql.append("         select sector, gbm, product, plant, componentNm, TOTAL, \n");
			if(inputMap.get("timePoint").equals("DAY")){
				sql.append(" 	sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType)     , :dateType), qty, 0)) as date01,   	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 1 , :dateType), qty, 0)) as date02,  	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 2 , :dateType), qty, 0)) as date03, 	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 3 , :dateType), qty, 0)) as date04,   	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 4 , :dateType), qty, 0)) as date05,  	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 5 , :dateType), qty, 0)) as date06, 	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 6 , :dateType), qty, 0)) as date07 		\n");
			}else if(inputMap.get("timePoint").equals("WEEK")){
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate    , qty, 0)) as date01,   	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate + 1, qty, 0)) as date02,  	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate + 2, qty, 0)) as date03, 	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate + 3, qty, 0)) as date04,   	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate + 4, qty, 0)) as date05,  	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate + 5, qty, 0)) as date06, 	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE, :fromDate + 6, qty, 0)) as date07 		\n");
			}else if(inputMap.get("timePoint").equals("MONTH")){
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),0), :dateType), qty, 0)) as date01,   	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),1), :dateType), qty, 0)) as date02,  	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),2), :dateType), qty, 0)) as date03, 	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),3), :dateType), qty, 0)) as date04,   	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),4), :dateType), qty, 0)) as date05,  	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),5), :dateType), qty, 0)) as date06, 	\n");
				sql.append("    sum(decode(TIMEPOINTVALUE,to_char(ADD_MONTHS(to_date(:fromDate, :dateType),6), :dateType), qty, 0)) as date07 		\n");
			}
			/*
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType)     , :dateType), qty, 0)) as date01,        \n");
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 1 , :dateType), qty, 0)) as date02,       \n");
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 2 , :dateType), qty, 0)) as date03,      \n");
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 3 , :dateType), qty, 0)) as date04,        \n");
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 4 , :dateType), qty, 0)) as date05,       \n");
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 5 , :dateType), qty, 0)) as date06,      \n");
			sql.append("             sum(decode(TIMEPOINTVALUE,to_char(to_date(:fromDate, :dateType) + 6 , :dateType), qty, 0)) as date07      \n");
			*/
			sql.append("         from (     \n");
			sql.append("             SELECT sector, gbm, product, plant, componentNm, qty, TIMEPOINTVALUE,  \n");
			sql.append("                 DECODE(componentNm, :inspectQty, TOTALINSPECTQTY,DECODE(componentNm, :goodQty, TOTALGOODQTY, DECODE(componentNm, :ratio,TOTALRATIO))) AS TOTAL \n");
			sql.append("             FROM ( \n");
			sql.append("                 select sector, gbm, product, plant, B.GUBUN as componentNm,    \n");
			sql.append("                     decode(B.GUBUN, :inspectQty, inspectqty, decode(B.GUBUN, :goodQty, goodqty,  decode(B.GUBUN, :ratio, ratio , 0))) as qty,   \n");
			sql.append("                     TIMEPOINTVALUE, TOTALINSPECTQTY, TOTALGOODQTY, TOTALRATIO \n");
			sql.append("                 FROM ( \n");
			sql.append("                     SELECT sector,GBM, PRODUCT, PLANT, INSPECTQTY, GOODQTY, RATIO , TIMEPOINTVALUE, NUM, \n");
			sql.append("                         TOTALINSPECTQTY, TOTALGOODQTY, ROUND(TOTALGOODQTY / TOTALINSPECTQTY * 100,2) AS TOTALRATIO \n");
			sql.append("                     FROM ( \n");
			sql.append("                         SELECT sector,GBM, PRODUCT, PLANT, INSPECTQTY, GOODQTY, ROUND(GOODQTY / INSPECTQTY *100,2) AS RATIO , TIMEPOINTVALUE, NUM, \n");
			sql.append("                             SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT) AS TOTALINSPECTQTY, \n");
			sql.append("                             SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT) AS TOTALGOODQTY \n");
			sql.append("                         FROM (  \n");
			sql.append("                             SELECT sector,GBM, PRODUCT, PLANT, INSPECTQTY, GOODQTY, RATIO, TIMEPOINTVALUE,  \n");
			sql.append("                                 ROW_NUMBER() OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT||TIMEPOINTVALUE  ORDER BY PLANT) AS NUM  \n");
			sql.append("                             FROM (  \n");
			sql.append("                                 select sector,GBM, PRODUCT, PLANT,   \n");
			sql.append("                                     decode(gbm,'total', SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||TIMEPOINTVALUE),  \n");
			sql.append("                                         decode(product,'total',SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||TIMEPOINTVALUE),  \n");
			sql.append("                                             decode(plant,'total', SUM(INSPECTQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT||TIMEPOINTVALUE),  \n");
			sql.append("                                                 INSPECTQTY))) AS INSPECTQTY,  \n");
			sql.append("                                     decode(gbm,'total', SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||TIMEPOINTVALUE),  \n");
			sql.append("                                         decode(product,'total',SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||TIMEPOINTVALUE),  \n");
			sql.append("                                             decode(plant,'total', SUM(GOODQTY) OVER( PARTITION BY SECTOR||GBM||PRODUCT||PLANT||TIMEPOINTVALUE),  \n");
			sql.append("                                                 GOODQTY))) AS GOODQTY, '' AS RATIO, TIMEPOINTVALUE  \n");
			sql.append("                                 from (  \n");
			sql.append("                                     select sector,   \n");
			sql.append("                                         decode(GUBUN1, 'A',  A2.gbm, decode(GUBUN1, 'B',  A2.gbm,  decode(GUBUN1, 'C',  A2.gbm,'total')))  as gbm,  \n");
			sql.append("                                         decode(GUBUN1, 'A',  A2.product, decode(GUBUN1, 'B',  A2.product,'total'))  as product,  \n");
			sql.append("                                         decode(GUBUN1, 'A',  A2.plant, 'total') as plant,    \n");
			sql.append("                                         INSPECTQTY, GOODQTY, TIMEPOINTVALUE  \n");
			sql.append("                                     from (  \n");
			sql.append("                                         SELECT SECTOR, GBM, PRODUCT, PLANT,   \n");
			sql.append("                                             NVL(MAX( DECODE( COMPONENTNM, :inspectName, QTY )),'') AS INSPECTQTY,   \n");
			sql.append("                                             NVL(MAX( DECODE( COMPONENTNM, :goodName, QTY )),'') AS GOODQTY, TIMEPOINTVALUE   \n");
			sql.append("                                         FROM (   \n");
			sql.append("                                             SELECT SECTOR, GBM, PRODUCT, PLANT, COMPONENTNM, QTY, TIMEPOINTVALUE   \n");
			sql.append("                                             FROM(   \n");
			sql.append("                                                 SELECT 'SET' AS SECTOR, COMM.CODE_ATTR_1 AS GBM, 'VD' AS PRODUCT, COMM.COMM_CODE_NM AS PLANT,   \n");
			sql.append("                                                     CPN.COMPONENT_NM AS COMPONENTNM, CPND.COMPONENT_VALUE AS QTY,   \n");
			sql.append("                                                     CPND.TIMEPOINT_CLSF, CPND.TIMEPOINT_VALUE AS TIMEPOINTVALUE, CPND.LINE_CODE, IDC.IDC_CODE, IDCC.COMPONENT_CODE   \n");
			sql.append("                                                 FROM TBM_BI_IDC IDC, TBP_BI_IDC_COMPONENT IDCC, TBM_BI_COMPONENT CPN, TBP_BI_COMPONENT_DATA CPND, TBC_MD_COMM_CODE COMM   \n");
			sql.append("                                                 WHERE 1=1   \n");
			sql.append("                                                     AND IDC.IDC_CODE = IDCC.IDC_CODE   \n");
			sql.append("                                                     AND IDCC.COMPONENT_CODE = CPN.COMPONENT_CODE   \n");
			sql.append("                                                     AND CPN.COMPONENT_CODE = CPND.COMPONENT_CODE   \n");
			sql.append("                                                     AND COMM.COMM_CODE = CPND.PLANT_CODE   \n");
			sql.append("                                                     AND COMM.TYPE_CODE = 'PLANT_CODE'   \n");
			sql.append("                                                     AND IDC.IDC_CODE = '4.5.6'   \n");
			sql.append("                                                     AND IDCC.IDC_COMPONENT_CLSF_CODE = 'C'   \n");
			sql.append("                                                     AND CPND.TIMEPOINT_CLSF = :timePoint \n");
			sql.append("                                                     AND IDCC.COMPONENT_CODE IN (:lineCode1, :lineCode2)  \n");
			sql.append("                                                     AND CPND.TIMEPOINT_VALUE >= :fromDate    \n");
			sql.append("                                                     AND CPND.TIMEPOINT_VALUE <= :toDate    \n");
			sql.append("                                                 )   \n");
			sql.append("                                             )   \n");
			sql.append("                                             GROUP BY SECTOR, GBM, PRODUCT, PLANT, TIMEPOINTVALUE  \n");
			sql.append("                                         ) A2, (   \n");
			sql.append("                                         select 'A' as GUBUN1 from dual   \n");
			sql.append("                                         union all   \n");
			sql.append("                                         select 'B' as GUBUN1 from dual   \n");
			sql.append("                                         union all   \n");
			sql.append("                                         select 'C' as GUBUN1 from dual       \n");
			sql.append("                                         union all   \n");
			sql.append("                                         select 'D' as GUBUN1 from dual   \n");
			sql.append("                                         ) B2  \n");
			sql.append("                                     )  \n");
			sql.append("                                 )  \n");
			sql.append("                             )  \n");
			sql.append("                             WHERE NUM = 1 \n");
			sql.append("                         ) \n");
			sql.append("                     )A, (   \n");
			sql.append("                     select :inspectQty as GUBUN from dual   \n");
			sql.append("                     union all   \n");
			sql.append("                     select :goodQty as GUBUN from dual   \n");
			sql.append("                     union all   \n");
			sql.append("                     select :ratio as GUBUN from dual   \n");
			sql.append("                     ) B \n");
			sql.append("                 ) \n");
			sql.append("             ) \n");
			sql.append("         group by sector, gbm, product, plant, componentNm, TOTAL \n");
			sql.append("     )  \n");
			sql.append(" order by sector desc, gbm desc, product desc, plant desc, componentNm    \n");
			sql.append(" )  \n");
		sql.append(" /* com.samsung.gmes2.bi.BIU456M00DQM.dListDetailList.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "fromDate", "toDate", "dateType", "inspectQty", "goodQty", "ratio", "inspectName", "goodName", "timePoint", "lineCode1", "lineCode2"});
			if (inputSize > 0) {
				if (inputMap.get("fromDate") != null && !"".equals(inputMap.get("fromDate"))) {	
					data.put("fromDate", inputMap.get("fromDate"));
				}
				if (inputMap.get("toDate") != null && !"".equals(inputMap.get("toDate"))) {	
					data.put("toDate", inputMap.get("toDate"));
				}
				if (inputMap.get("dateType") != null && !"".equals(inputMap.get("dateType"))) {	
					data.put("dateType", inputMap.get("dateType"));
				}
				if (inputMap.get("inspectQty") != null && !"".equals(inputMap.get("inspectQty"))) {	
					data.put("inspectQty", inputMap.get("inspectQty"));
				}
				if (inputMap.get("goodQty") != null && !"".equals(inputMap.get("goodQty"))) {	
					data.put("goodQty", inputMap.get("goodQty"));
				}
				if (inputMap.get("ratio") != null && !"".equals(inputMap.get("ratio"))) {	
					data.put("ratio", inputMap.get("ratio"));
				}
				if (inputMap.get("inspectName") != null && !"".equals(inputMap.get("inspectName"))) {	
					data.put("inspectName", inputMap.get("inspectName"));
				}
				if (inputMap.get("goodName") != null && !"".equals(inputMap.get("goodName"))) {	
					data.put("goodName", inputMap.get("goodName"));
				}
				if (inputMap.get("timePoint") != null && !"".equals(inputMap.get("timePoint"))) {	
					data.put("timePoint", inputMap.get("timePoint"));
				}
				if (inputMap.get("lineCode1") != null && !"".equals(inputMap.get("lineCode1"))) {	
					data.put("lineCode1", inputMap.get("lineCode1"));
				}
				if (inputMap.get("lineCode2") != null && !"".equals(inputMap.get("lineCode2"))) {	
					data.put("lineCode2", inputMap.get("lineCode2"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									BiU456M0001DVO returnBIYieldState02DVO = new BiU456M0001DVO();
									returnBIYieldState02DVO.setSector(resultSet.getString("SECTOR"));
									returnBIYieldState02DVO.setGbm(resultSet.getString("GBM"));
									returnBIYieldState02DVO.setProduct(resultSet.getString("PRODUCT"));
									returnBIYieldState02DVO.setPlant(resultSet.getString("PLANT"));
									returnBIYieldState02DVO.setComponentnm(resultSet.getString("COMPONENTNM"));
									returnBIYieldState02DVO.setTotal(resultSet.getBigDecimal("TOTAL"));
									returnBIYieldState02DVO.setDate01(resultSet.getBigDecimal("DATE01"));
									returnBIYieldState02DVO.setDate02(resultSet.getBigDecimal("DATE02"));
									returnBIYieldState02DVO.setDate03(resultSet.getBigDecimal("DATE03"));
									returnBIYieldState02DVO.setDate04(resultSet.getBigDecimal("DATE04"));
									returnBIYieldState02DVO.setDate05(resultSet.getBigDecimal("DATE05"));
									returnBIYieldState02DVO.setDate06(resultSet.getBigDecimal("DATE06"));
									returnBIYieldState02DVO.setDate07(resultSet.getBigDecimal("DATE07"));
									return returnBIYieldState02DVO;
					    	}
					    	
					   }
 		);
	}



}