package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_BRDN_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdBrdnCauseDEM extends AbstractDAO {


/**
* insertTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return int
*/
	@LocalName("insertTbcMdBrdnCause")
	public int insertTbcMdBrdnCause (final TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.insertTbcMdBrdnCause.001*/  \n");
			sql.append(" TBC_MD_BRDN_CAUSE (   \n");
			sql.append("        BRDN_CAUSE_CODE , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        BRDN_CAUSE_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseNm());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdBrdnCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdBrdnCause Method")
	public int[][] updateBatchAllTbcMdBrdnCause (final List  tbcMdBrdnCauseDVOList) {
		
		ArrayList updatetbcMdBrdnCauseDVOList = new ArrayList();
		ArrayList insertttbcMdBrdnCauseDVOList = new ArrayList();
		ArrayList deletetbcMdBrdnCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdBrdnCauseDVOList.size() ; i++) {
		  TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO = (TbcMdBrdnCauseDVO) tbcMdBrdnCauseDVOList.get(i);
		  
		  if (tbcMdBrdnCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdBrdnCauseDVOList.add(tbcMdBrdnCauseDVO);
		  else if (tbcMdBrdnCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdBrdnCauseDVOList.add(tbcMdBrdnCauseDVO);
		  else if (tbcMdBrdnCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdBrdnCauseDVOList.add(tbcMdBrdnCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdBrdnCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdBrdnCause(insertttbcMdBrdnCauseDVOList);
          
      if (updatetbcMdBrdnCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdBrdnCause(updatetbcMdBrdnCauseDVOList);
      
      if (deletetbcMdBrdnCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdBrdnCause(deletetbcMdBrdnCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return int
*/
	@LocalName("updateTbcMdBrdnCause")
	public int updateTbcMdBrdnCause (final TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.updateTbcMdBrdnCause.001*/  \n");
			sql.append(" TBC_MD_BRDN_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_CLSF_CODE = ? , \n");
			sql.append("        BRDN_CAUSE_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnCauseDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseNm());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdBrdnCause")
	public int deleteTbcMdBrdnCause (final TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.deleteTbcMdBrdnCause.001*/  \n");
			sql.append(" TBC_MD_BRDN_CAUSE \n");
			sql.append("  WHERE BRDN_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return TbcMdBrdnCauseDVO 
*/
	@LocalName("selectTbcMdBrdnCause")
	public TbcMdBrdnCauseDVO selectTbcMdBrdnCause (final TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.selectTbcMdBrdnCause.001*/  \n");
			sql.append("        BRDN_CAUSE_CODE , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        BRDN_CAUSE_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_BRDN_CAUSE \n");
			sql.append("  WHERE BRDN_CAUSE_CODE = ? \n");

		return (TbcMdBrdnCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdBrdnCauseDVO returnTbcMdBrdnCauseDVO = new TbcMdBrdnCauseDVO();
									returnTbcMdBrdnCauseDVO.setBrdnCauseCode(resultSet.getString("BRDN_CAUSE_CODE"));
									returnTbcMdBrdnCauseDVO.setEquipClsfCode(resultSet.getString("EQUIP_CLSF_CODE"));
									returnTbcMdBrdnCauseDVO.setBrdnCauseNm(resultSet.getString("BRDN_CAUSE_NM"));
									returnTbcMdBrdnCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdBrdnCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdBrdnCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdBrdnCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdBrdnCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdBrdnCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdBrdnCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdBrdnCause Method")
	public int mergeTbcMdBrdnCause (final TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO) {
		
		if ( selectTbcMdBrdnCause (tbcMdBrdnCauseDVO) == null) {
			return insertTbcMdBrdnCause(tbcMdBrdnCauseDVO);
		} else {
			return selectUpdateTbcMdBrdnCause (tbcMdBrdnCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdBrdnCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdBrdnCause Method")
	public int selectUpdateTbcMdBrdnCause (final TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO) {
		
		TbcMdBrdnCauseDVO tmpTbcMdBrdnCauseDVO =  selectTbcMdBrdnCause (tbcMdBrdnCauseDVO);
		if ( tbcMdBrdnCauseDVO.getBrdnCauseCode() != null && !"".equals(tbcMdBrdnCauseDVO.getBrdnCauseCode()) ) {
			tmpTbcMdBrdnCauseDVO.setBrdnCauseCode(tbcMdBrdnCauseDVO.getBrdnCauseCode());
		}		
		if ( tbcMdBrdnCauseDVO.getEquipClsfCode() != null && !"".equals(tbcMdBrdnCauseDVO.getEquipClsfCode()) ) {
			tmpTbcMdBrdnCauseDVO.setEquipClsfCode(tbcMdBrdnCauseDVO.getEquipClsfCode());
		}		
		if ( tbcMdBrdnCauseDVO.getBrdnCauseNm() != null && !"".equals(tbcMdBrdnCauseDVO.getBrdnCauseNm()) ) {
			tmpTbcMdBrdnCauseDVO.setBrdnCauseNm(tbcMdBrdnCauseDVO.getBrdnCauseNm());
		}		
		if ( tbcMdBrdnCauseDVO.getUseYn() != null && !"".equals(tbcMdBrdnCauseDVO.getUseYn()) ) {
			tmpTbcMdBrdnCauseDVO.setUseYn(tbcMdBrdnCauseDVO.getUseYn());
		}		
		if ( tbcMdBrdnCauseDVO.getFstRegDt() != null && !"".equals(tbcMdBrdnCauseDVO.getFstRegDt()) ) {
			tmpTbcMdBrdnCauseDVO.setFstRegDt(tbcMdBrdnCauseDVO.getFstRegDt());
		}		
		if ( tbcMdBrdnCauseDVO.getFstRegerId() != null && !"".equals(tbcMdBrdnCauseDVO.getFstRegerId()) ) {
			tmpTbcMdBrdnCauseDVO.setFstRegerId(tbcMdBrdnCauseDVO.getFstRegerId());
		}		
		if ( tbcMdBrdnCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdBrdnCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdBrdnCauseDVO.setFnlUpdDt(tbcMdBrdnCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdBrdnCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdBrdnCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdBrdnCauseDVO.setFnlUpderId(tbcMdBrdnCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdBrdnCause (tmpTbcMdBrdnCauseDVO);
	}

/**
* insertBatchTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdBrdnCause")
	public int[] insertBatchTbcMdBrdnCause (final List tbcMdBrdnCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.insertBatchTbcMdBrdnCause.001*/  \n");
			sql.append(" TBC_MD_BRDN_CAUSE (   \n");
			sql.append("        BRDN_CAUSE_CODE , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        BRDN_CAUSE_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO = (TbcMdBrdnCauseDVO)tbcMdBrdnCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseNm());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdBrdnCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdBrdnCause")
	public int[] updateBatchTbcMdBrdnCause (final List tbcMdBrdnCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.updateBatchTbcMdBrdnCause.001*/  \n");
			sql.append(" TBC_MD_BRDN_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_CLSF_CODE = ? , \n");
			sql.append("        BRDN_CAUSE_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO = (TbcMdBrdnCauseDVO)tbcMdBrdnCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnCauseDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseNm());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdBrdnCause Method
* 
* @ref_table TBC_MD_BRDN_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdBrdnCause")
	public int[] deleteBatchTbcMdBrdnCause (final List tbcMdBrdnCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnCauseDEM.deleteBatchTbcMdBrdnCause.001*/  \n");
			sql.append(" TBC_MD_BRDN_CAUSE \n");
			sql.append("  WHERE BRDN_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnCauseDVO tbcMdBrdnCauseDVO = (TbcMdBrdnCauseDVO)tbcMdBrdnCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnCauseDVO.getBrdnCauseCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnCauseDVOList.size();
							}
					}
		);			
	}

	
}