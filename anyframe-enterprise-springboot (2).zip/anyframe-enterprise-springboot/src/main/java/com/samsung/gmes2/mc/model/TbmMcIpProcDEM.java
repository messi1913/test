package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_IP_PROC
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcIpProcDEM extends AbstractDAO {


/**
* insertTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return int
*/
	@LocalName("insertTbmMcIpProc")
	public int insertTbmMcIpProc (final TbmMcIpProcDVO tbmMcIpProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.insertTbmMcIpProc.001*/  \n");
			sql.append(" TBM_MC_IP_PROC (   \n");
			sql.append("        IP , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        CELL_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        IP_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
							ps.setString(psCount++, tbmMcIpProcDVO.getCorpCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getLineCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getCellCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getIpDesc());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcIpProc Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcIpProc Method")
	public int[][] updateBatchAllTbmMcIpProc (final List  tbmMcIpProcDVOList) {
		
		ArrayList updatetbmMcIpProcDVOList = new ArrayList();
		ArrayList insertttbmMcIpProcDVOList = new ArrayList();
		ArrayList deletetbmMcIpProcDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcIpProcDVOList.size() ; i++) {
		  TbmMcIpProcDVO tbmMcIpProcDVO = (TbmMcIpProcDVO) tbmMcIpProcDVOList.get(i);
		  
		  if (tbmMcIpProcDVO.getSqlAction().equals("C"))
		      insertttbmMcIpProcDVOList.add(tbmMcIpProcDVO);
		  else if (tbmMcIpProcDVO.getSqlAction().equals("U"))
		      updatetbmMcIpProcDVOList.add(tbmMcIpProcDVO);
		  else if (tbmMcIpProcDVO.getSqlAction().equals("D"))
		      deletetbmMcIpProcDVOList.add(tbmMcIpProcDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcIpProcDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcIpProc(insertttbmMcIpProcDVOList);
          
      if (updatetbmMcIpProcDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcIpProc(updatetbmMcIpProcDVOList);
      
      if (deletetbmMcIpProcDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcIpProc(deletetbmMcIpProcDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return int
*/
	@LocalName("updateTbmMcIpProc")
	public int updateTbmMcIpProc (final TbmMcIpProcDVO tbmMcIpProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.updateTbmMcIpProc.001*/  \n");
			sql.append(" TBM_MC_IP_PROC \n");
			sql.append(" SET   \n");
			sql.append("        CORP_CODE = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        CELL_CODE = ? , \n");
			sql.append("        UNIT_PROC_CODE = ? , \n");
			sql.append("        IP_DESC = ? \n");
			sql.append(" WHERE IP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpProcDVO.getCorpCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getLineCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getCellCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getIpDesc());

							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
						}
					}
		);			
	}

/**
* deleteTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return int
*/
	@LocalName("deleteTbmMcIpProc")
	public int deleteTbmMcIpProc (final TbmMcIpProcDVO tbmMcIpProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.deleteTbmMcIpProc.001*/  \n");
			sql.append(" TBM_MC_IP_PROC \n");
			sql.append("  WHERE IP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
						}
					}
		);			
	}

/**
* selectTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return TbmMcIpProcDVO 
*/
	@LocalName("selectTbmMcIpProc")
	public TbmMcIpProcDVO selectTbmMcIpProc (final TbmMcIpProcDVO tbmMcIpProcDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.selectTbmMcIpProc.001*/  \n");
			sql.append("        IP , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        CELL_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        IP_DESC \n");
			sql.append("   FROM TBM_MC_IP_PROC \n");
			sql.append("  WHERE IP = ? \n");

		return (TbmMcIpProcDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcIpProcDVO returnTbmMcIpProcDVO = new TbmMcIpProcDVO();
									returnTbmMcIpProcDVO.setIp(resultSet.getString("IP"));
									returnTbmMcIpProcDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMcIpProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMcIpProcDVO.setCellCode(resultSet.getString("CELL_CODE"));
									returnTbmMcIpProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMcIpProcDVO.setIpDesc(resultSet.getString("IP_DESC"));
									return returnTbmMcIpProcDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcIpProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcIpProc Method")
	public int mergeTbmMcIpProc (final TbmMcIpProcDVO tbmMcIpProcDVO) {
		
		if ( selectTbmMcIpProc (tbmMcIpProcDVO) == null) {
			return insertTbmMcIpProc(tbmMcIpProcDVO);
		} else {
			return selectUpdateTbmMcIpProc (tbmMcIpProcDVO);
		}
	}

	/**
	 * selectUpdateTbmMcIpProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcIpProc Method")
	public int selectUpdateTbmMcIpProc (final TbmMcIpProcDVO tbmMcIpProcDVO) {
		
		TbmMcIpProcDVO tmpTbmMcIpProcDVO =  selectTbmMcIpProc (tbmMcIpProcDVO);
		if ( tbmMcIpProcDVO.getIp() != null && !"".equals(tbmMcIpProcDVO.getIp()) ) {
			tmpTbmMcIpProcDVO.setIp(tbmMcIpProcDVO.getIp());
		}		
		if ( tbmMcIpProcDVO.getCorpCode() != null && !"".equals(tbmMcIpProcDVO.getCorpCode()) ) {
			tmpTbmMcIpProcDVO.setCorpCode(tbmMcIpProcDVO.getCorpCode());
		}		
		if ( tbmMcIpProcDVO.getLineCode() != null && !"".equals(tbmMcIpProcDVO.getLineCode()) ) {
			tmpTbmMcIpProcDVO.setLineCode(tbmMcIpProcDVO.getLineCode());
		}		
		if ( tbmMcIpProcDVO.getCellCode() != null && !"".equals(tbmMcIpProcDVO.getCellCode()) ) {
			tmpTbmMcIpProcDVO.setCellCode(tbmMcIpProcDVO.getCellCode());
		}		
		if ( tbmMcIpProcDVO.getUnitProcCode() != null && !"".equals(tbmMcIpProcDVO.getUnitProcCode()) ) {
			tmpTbmMcIpProcDVO.setUnitProcCode(tbmMcIpProcDVO.getUnitProcCode());
		}		
		if ( tbmMcIpProcDVO.getIpDesc() != null && !"".equals(tbmMcIpProcDVO.getIpDesc()) ) {
			tmpTbmMcIpProcDVO.setIpDesc(tbmMcIpProcDVO.getIpDesc());
		}		
		return updateTbmMcIpProc (tmpTbmMcIpProcDVO);
	}

/**
* insertBatchTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return int[]
*/
	@LocalName("insertBatchTbmMcIpProc")
	public int[] insertBatchTbmMcIpProc (final List tbmMcIpProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.insertBatchTbmMcIpProc.001*/  \n");
			sql.append(" TBM_MC_IP_PROC (   \n");
			sql.append("        IP , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        CELL_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        IP_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcIpProcDVO tbmMcIpProcDVO = (TbmMcIpProcDVO)tbmMcIpProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
							ps.setString(psCount++, tbmMcIpProcDVO.getCorpCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getLineCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getCellCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getIpDesc());

						}
							public int getBatchSize() {
									return tbmMcIpProcDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return int[]
*/
	@LocalName("updateBatchTbmMcIpProc")
	public int[] updateBatchTbmMcIpProc (final List tbmMcIpProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.updateBatchTbmMcIpProc.001*/  \n");
			sql.append(" TBM_MC_IP_PROC \n");
			sql.append(" SET   \n");
			sql.append("        CORP_CODE = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        CELL_CODE = ? , \n");
			sql.append("        UNIT_PROC_CODE = ? , \n");
			sql.append("        IP_DESC = ? \n");
			sql.append(" WHERE IP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcIpProcDVO tbmMcIpProcDVO = (TbmMcIpProcDVO)tbmMcIpProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpProcDVO.getCorpCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getLineCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getCellCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMcIpProcDVO.getIpDesc());

							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
						}
							public int getBatchSize() {
									return tbmMcIpProcDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcIpProc Method
* 
* @ref_table TBM_MC_IP_PROC
* @return int[]
*/
	@LocalName("deleteBatchTbmMcIpProc")
	public int[] deleteBatchTbmMcIpProc (final List tbmMcIpProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcIpProcDEM.deleteBatchTbmMcIpProc.001*/  \n");
			sql.append(" TBM_MC_IP_PROC \n");
			sql.append("  WHERE IP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcIpProcDVO tbmMcIpProcDVO = (TbmMcIpProcDVO)tbmMcIpProcDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcIpProcDVO.getIp());
						}
							public int getBatchSize() {
									return tbmMcIpProcDVOList.size();
							}
					}
		);			
	}

	
}