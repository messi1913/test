package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_MATR
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMdMatrDEM extends AbstractDAO {


/**
* insertTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return int
*/
	@LocalName("insertTbhMdMatr")
	public int insertTbhMdMatr (final TbhMdMatrDVO tbhMdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdMatrDEM.insertTbhMdMatr.001*/  \n");
			sql.append(" TBH_MD_MATR (   \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        MATR_DESC , \n");
			sql.append("        MATR_SPEC_CONT , \n");
			sql.append("        PURC_GRADE_CODE , \n");
			sql.append("        QUAL_GRADE_CODE , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        LF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
							ps.setString(psCount++, tbhMdMatrDVO.getMatrDesc());
							ps.setString(psCount++, tbhMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbhMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbhMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbhMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdMatrDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdMatr Method")
	public int[][] updateBatchAllTbhMdMatr (final List  tbhMdMatrDVOList) {
		
		ArrayList updatetbhMdMatrDVOList = new ArrayList();
		ArrayList insertttbhMdMatrDVOList = new ArrayList();
		ArrayList deletetbhMdMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdMatrDVOList.size() ; i++) {
		  TbhMdMatrDVO tbhMdMatrDVO = (TbhMdMatrDVO) tbhMdMatrDVOList.get(i);
		  
		  if (tbhMdMatrDVO.getSqlAction().equals("C"))
		      insertttbhMdMatrDVOList.add(tbhMdMatrDVO);
		  else if (tbhMdMatrDVO.getSqlAction().equals("U"))
		      updatetbhMdMatrDVOList.add(tbhMdMatrDVO);
		  else if (tbhMdMatrDVO.getSqlAction().equals("D"))
		      deletetbhMdMatrDVOList.add(tbhMdMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdMatr(insertttbhMdMatrDVOList);
          
      if (updatetbhMdMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdMatr(updatetbhMdMatrDVOList);
      
      if (deletetbhMdMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdMatr(deletetbhMdMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return int
*/
	@LocalName("updateTbhMdMatr")
	public int updateTbhMdMatr (final TbhMdMatrDVO tbhMdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdMatrDEM.updateTbhMdMatr.001*/  \n");
			sql.append(" TBH_MD_MATR \n");
			sql.append(" SET   \n");
			sql.append("        MATR_DESC = ? , \n");
			sql.append("        MATR_SPEC_CONT = ? , \n");
			sql.append("        PURC_GRADE_CODE = ? , \n");
			sql.append("        QUAL_GRADE_CODE = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        LF_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE MATR_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdMatrDVO.getMatrDesc());
							ps.setString(psCount++, tbhMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbhMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbhMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbhMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdMatrDVO.getEvtNm());

							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return int
*/
	@LocalName("deleteTbhMdMatr")
	public int deleteTbhMdMatr (final TbhMdMatrDVO tbhMdMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdMatrDEM.deleteTbhMdMatr.001*/  \n");
			sql.append(" TBH_MD_MATR \n");
			sql.append("  WHERE MATR_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return TbhMdMatrDVO 
*/
	@LocalName("selectTbhMdMatr")
	public TbhMdMatrDVO selectTbhMdMatr (final TbhMdMatrDVO tbhMdMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdMatrDEM.selectTbhMdMatr.001*/  \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        MATR_DESC , \n");
			sql.append("        MATR_SPEC_CONT , \n");
			sql.append("        PURC_GRADE_CODE , \n");
			sql.append("        QUAL_GRADE_CODE , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        LF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBH_MD_MATR \n");
			sql.append("  WHERE MATR_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdMatrDVO returnTbhMdMatrDVO = new TbhMdMatrDVO();
									returnTbhMdMatrDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbhMdMatrDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdMatrDVO.setMatrDesc(resultSet.getString("MATR_DESC"));
									returnTbhMdMatrDVO.setMatrSpecCont(resultSet.getString("MATR_SPEC_CONT"));
									returnTbhMdMatrDVO.setPurcGradeCode(resultSet.getString("PURC_GRADE_CODE"));
									returnTbhMdMatrDVO.setQualGradeCode(resultSet.getString("QUAL_GRADE_CODE"));
									returnTbhMdMatrDVO.setUnitCode(resultSet.getString("UNIT_CODE"));
									returnTbhMdMatrDVO.setLfYn(resultSet.getString("LF_YN"));
									returnTbhMdMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbhMdMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbhMdMatrDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbhMdMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdMatr Method")
	public int mergeTbhMdMatr (final TbhMdMatrDVO tbhMdMatrDVO) {
		
		if ( selectTbhMdMatr (tbhMdMatrDVO) == null) {
			return insertTbhMdMatr(tbhMdMatrDVO);
		} else {
			return selectUpdateTbhMdMatr (tbhMdMatrDVO);
		}
	}

	/**
	 * selectUpdateTbhMdMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdMatr Method")
	public int selectUpdateTbhMdMatr (final TbhMdMatrDVO tbhMdMatrDVO) {
		
		TbhMdMatrDVO tmpTbhMdMatrDVO =  selectTbhMdMatr (tbhMdMatrDVO);
		if ( tbhMdMatrDVO.getMatrCode() != null && !"".equals(tbhMdMatrDVO.getMatrCode()) ) {
			tmpTbhMdMatrDVO.setMatrCode(tbhMdMatrDVO.getMatrCode());
		}		
		if ( tbhMdMatrDVO.getHistTsp() != null && !"".equals(tbhMdMatrDVO.getHistTsp()) ) {
			tmpTbhMdMatrDVO.setHistTsp(tbhMdMatrDVO.getHistTsp());
		}		
		if ( tbhMdMatrDVO.getMatrDesc() != null && !"".equals(tbhMdMatrDVO.getMatrDesc()) ) {
			tmpTbhMdMatrDVO.setMatrDesc(tbhMdMatrDVO.getMatrDesc());
		}		
		if ( tbhMdMatrDVO.getMatrSpecCont() != null && !"".equals(tbhMdMatrDVO.getMatrSpecCont()) ) {
			tmpTbhMdMatrDVO.setMatrSpecCont(tbhMdMatrDVO.getMatrSpecCont());
		}		
		if ( tbhMdMatrDVO.getPurcGradeCode() != null && !"".equals(tbhMdMatrDVO.getPurcGradeCode()) ) {
			tmpTbhMdMatrDVO.setPurcGradeCode(tbhMdMatrDVO.getPurcGradeCode());
		}		
		if ( tbhMdMatrDVO.getQualGradeCode() != null && !"".equals(tbhMdMatrDVO.getQualGradeCode()) ) {
			tmpTbhMdMatrDVO.setQualGradeCode(tbhMdMatrDVO.getQualGradeCode());
		}		
		if ( tbhMdMatrDVO.getUnitCode() != null && !"".equals(tbhMdMatrDVO.getUnitCode()) ) {
			tmpTbhMdMatrDVO.setUnitCode(tbhMdMatrDVO.getUnitCode());
		}		
		if ( tbhMdMatrDVO.getLfYn() != null && !"".equals(tbhMdMatrDVO.getLfYn()) ) {
			tmpTbhMdMatrDVO.setLfYn(tbhMdMatrDVO.getLfYn());
		}		
		if ( tbhMdMatrDVO.getUseYn() != null && !"".equals(tbhMdMatrDVO.getUseYn()) ) {
			tmpTbhMdMatrDVO.setUseYn(tbhMdMatrDVO.getUseYn());
		}		
		if ( tbhMdMatrDVO.getFstRegDt() != null && !"".equals(tbhMdMatrDVO.getFstRegDt()) ) {
			tmpTbhMdMatrDVO.setFstRegDt(tbhMdMatrDVO.getFstRegDt());
		}		
		if ( tbhMdMatrDVO.getFstRegerId() != null && !"".equals(tbhMdMatrDVO.getFstRegerId()) ) {
			tmpTbhMdMatrDVO.setFstRegerId(tbhMdMatrDVO.getFstRegerId());
		}		
		if ( tbhMdMatrDVO.getFnlUpdDt() != null && !"".equals(tbhMdMatrDVO.getFnlUpdDt()) ) {
			tmpTbhMdMatrDVO.setFnlUpdDt(tbhMdMatrDVO.getFnlUpdDt());
		}		
		if ( tbhMdMatrDVO.getFnlUpderId() != null && !"".equals(tbhMdMatrDVO.getFnlUpderId()) ) {
			tmpTbhMdMatrDVO.setFnlUpderId(tbhMdMatrDVO.getFnlUpderId());
		}		
		if ( tbhMdMatrDVO.getEvtNm() != null && !"".equals(tbhMdMatrDVO.getEvtNm()) ) {
			tmpTbhMdMatrDVO.setEvtNm(tbhMdMatrDVO.getEvtNm());
		}		
		return updateTbhMdMatr (tmpTbhMdMatrDVO);
	}

/**
* insertBatchTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return int[]
*/
	@LocalName("insertBatchTbhMdMatr")
	public int[] insertBatchTbhMdMatr (final List tbhMdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdMatrDEM.insertBatchTbhMdMatr.001*/  \n");
			sql.append(" TBH_MD_MATR (   \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        MATR_DESC , \n");
			sql.append("        MATR_SPEC_CONT , \n");
			sql.append("        PURC_GRADE_CODE , \n");
			sql.append("        QUAL_GRADE_CODE , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        LF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdMatrDVO tbhMdMatrDVO = (TbhMdMatrDVO)tbhMdMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
							ps.setString(psCount++, tbhMdMatrDVO.getMatrDesc());
							ps.setString(psCount++, tbhMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbhMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbhMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbhMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdMatrDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbhMdMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return int[]
*/
	@LocalName("updateBatchTbhMdMatr")
	public int[] updateBatchTbhMdMatr (final List tbhMdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdMatrDEM.updateBatchTbhMdMatr.001*/  \n");
			sql.append(" TBH_MD_MATR \n");
			sql.append(" SET   \n");
			sql.append("        MATR_DESC = ? , \n");
			sql.append("        MATR_SPEC_CONT = ? , \n");
			sql.append("        PURC_GRADE_CODE = ? , \n");
			sql.append("        QUAL_GRADE_CODE = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        LF_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE MATR_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdMatrDVO tbhMdMatrDVO = (TbhMdMatrDVO)tbhMdMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdMatrDVO.getMatrDesc());
							ps.setString(psCount++, tbhMdMatrDVO.getMatrSpecCont());
							ps.setString(psCount++, tbhMdMatrDVO.getPurcGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getQualGradeCode());
							ps.setString(psCount++, tbhMdMatrDVO.getUnitCode());
							ps.setString(psCount++, tbhMdMatrDVO.getLfYn());
							ps.setString(psCount++, tbhMdMatrDVO.getUseYn());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdMatrDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdMatrDVO.getEvtNm());

							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdMatr Method
* 
* @ref_table TBH_MD_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbhMdMatr")
	public int[] deleteBatchTbhMdMatr (final List tbhMdMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdMatrDEM.deleteBatchTbhMdMatr.001*/  \n");
			sql.append(" TBH_MD_MATR \n");
			sql.append("  WHERE MATR_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdMatrDVO tbhMdMatrDVO = (TbhMdMatrDVO)tbhMdMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdMatrDVO.getMatrCode());
							ps.setString(psCount++, tbhMdMatrDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdMatrDVOList.size();
							}
					}
		);			
	}

	
}