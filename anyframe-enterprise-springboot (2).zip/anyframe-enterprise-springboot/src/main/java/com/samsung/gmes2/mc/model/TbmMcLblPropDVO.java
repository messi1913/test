package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbmMcLblPropDVO extends AbstractVo {

	@Length(50) 
	private String propId;

	@Length(20) 
	private String divCode;

	@Length(500) 
	private String propNm;

	@Length(30) 
	private String propTypeCode;

	@Length(500) 
	private String tagtTabNm;

	@Length(500) 
	private String tagtCulmNm;

	@Length(500) 
	private String condCulmNm;

	@Length(500) 
	private String specAbbrNm;

	@Length(3) 
	private String paramTypeCode;

	@Length(3) 
	private String tagtValueTypeCode;


	public String getPropId() {
		this.propId = super.getValue(0);
		return this.propId;
	}

	public void setPropId(String propId) {
        super.setValue(0, propId);
		this.propId = propId;
	}
	
	public String getDivCode() {
		this.divCode = super.getValue(1);
		return this.divCode;
	}

	public void setDivCode(String divCode) {
        super.setValue(1, divCode);
		this.divCode = divCode;
	}
	
	public String getPropNm() {
		this.propNm = super.getValue(2);
		return this.propNm;
	}

	public void setPropNm(String propNm) {
        super.setValue(2, propNm);
		this.propNm = propNm;
	}
	
	public String getPropTypeCode() {
		this.propTypeCode = super.getValue(3);
		return this.propTypeCode;
	}

	public void setPropTypeCode(String propTypeCode) {
        super.setValue(3, propTypeCode);
		this.propTypeCode = propTypeCode;
	}
	
	public String getTagtTabNm() {
		this.tagtTabNm = super.getValue(4);
		return this.tagtTabNm;
	}

	public void setTagtTabNm(String tagtTabNm) {
        super.setValue(4, tagtTabNm);
		this.tagtTabNm = tagtTabNm;
	}
	
	public String getTagtCulmNm() {
		this.tagtCulmNm = super.getValue(5);
		return this.tagtCulmNm;
	}

	public void setTagtCulmNm(String tagtCulmNm) {
        super.setValue(5, tagtCulmNm);
		this.tagtCulmNm = tagtCulmNm;
	}
	
	public String getCondCulmNm() {
		this.condCulmNm = super.getValue(6);
		return this.condCulmNm;
	}

	public void setCondCulmNm(String condCulmNm) {
        super.setValue(6, condCulmNm);
		this.condCulmNm = condCulmNm;
	}
	
	public String getSpecAbbrNm() {
		this.specAbbrNm = super.getValue(7);
		return this.specAbbrNm;
	}

	public void setSpecAbbrNm(String specAbbrNm) {
        super.setValue(7, specAbbrNm);
		this.specAbbrNm = specAbbrNm;
	}
	
	public String getParamTypeCode() {
		this.paramTypeCode = super.getValue(8);
		return this.paramTypeCode;
	}

	public void setParamTypeCode(String paramTypeCode) {
        super.setValue(8, paramTypeCode);
		this.paramTypeCode = paramTypeCode;
	}
	
	public String getTagtValueTypeCode() {
		this.tagtValueTypeCode = super.getValue(9);
		return this.tagtValueTypeCode;
	}

	public void setTagtValueTypeCode(String tagtValueTypeCode) {
        super.setValue(9, tagtValueTypeCode);
		this.tagtValueTypeCode = tagtValueTypeCode;
	}
	
}