package com.samsung.gmes2.md.equipment.app;

public class MDU554M01App {

	/**
	 * Socket정보 목록 초기설정
	 */
	public void initSocketInfo(){}

	/**
	 * Socket정보 목록 조회
	 */
	public void listSocketInfo(){}

	/**
	 * Socket정보 목록 엑셀 다운로드
	 */
	public void excelSocketInfo(){}

	/**
	 * Socket정보 목록 등록/수정 초기설정
	 */
	public void editSocketInfo(){}

	/**
	 * Socket정보 목록 저장
	 */
	public void saveSocketInfo(){}

}
