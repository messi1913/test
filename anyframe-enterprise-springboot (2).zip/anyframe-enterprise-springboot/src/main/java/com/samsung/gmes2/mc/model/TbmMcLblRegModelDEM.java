package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* Reg Model에 대한 DEM
*
* @ref_table TBM_MC_LBL_REG_MODEL
* @author shim
*/
@Stereotype(Stereotype.Dao) @LocalName("Reg Model에 대한 DEM")
public class TbmMcLblRegModelDEM extends AbstractDAO {


/**
* insertTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return int
*/
	@LocalName("insertTbmMcLblRegModel")
	public int insertTbmMcLblRegModel (final TbmMcLblRegModelDVO tbmMcLblRegModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.insertTbmMcLblRegModel.001*/  \n");
			sql.append(" TBM_MC_LBL_REG_MODEL (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        APLY_LBL_VER , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        STATUS_CODE , \n");
			sql.append("        APRV_ID , \n");
			sql.append("        CFMER_ID , \n");
			sql.append("        CFM_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        REGER , \n");
			sql.append("        REG_DT , \n");
			sql.append("        PVIEW_IMG_FILE , \n");
			sql.append("        LABEL_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setBigDecimal(psCount++, tbmMcLblRegModelDVO.getAplyLblVer());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getStatusCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getAprvId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmerId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getUseYn());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getReger());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getRegDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPviewImgFile());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcLblRegModel Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcLblRegModel Method")
	public int[][] updateBatchAllTbmMcLblRegModel (final List  tbmMcLblRegModelDVOList) {
		
		ArrayList updatetbmMcLblRegModelDVOList = new ArrayList();
		ArrayList insertttbmMcLblRegModelDVOList = new ArrayList();
		ArrayList deletetbmMcLblRegModelDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcLblRegModelDVOList.size() ; i++) {
		  TbmMcLblRegModelDVO tbmMcLblRegModelDVO = (TbmMcLblRegModelDVO) tbmMcLblRegModelDVOList.get(i);
		  
		  if (tbmMcLblRegModelDVO.getSqlAction().equals("C"))
		      insertttbmMcLblRegModelDVOList.add(tbmMcLblRegModelDVO);
		  else if (tbmMcLblRegModelDVO.getSqlAction().equals("U"))
		      updatetbmMcLblRegModelDVOList.add(tbmMcLblRegModelDVO);
		  else if (tbmMcLblRegModelDVO.getSqlAction().equals("D"))
		      deletetbmMcLblRegModelDVOList.add(tbmMcLblRegModelDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcLblRegModelDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcLblRegModel(insertttbmMcLblRegModelDVOList);
          
      if (updatetbmMcLblRegModelDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcLblRegModel(updatetbmMcLblRegModelDVOList);
      
      if (deletetbmMcLblRegModelDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcLblRegModel(deletetbmMcLblRegModelDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return int
*/
	@LocalName("updateTbmMcLblRegModel")
	public int updateTbmMcLblRegModel (final TbmMcLblRegModelDVO tbmMcLblRegModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.updateTbmMcLblRegModel.001*/  \n");
			sql.append(" TBM_MC_LBL_REG_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        APLY_LBL_VER = ? , \n");
			sql.append("        DIV_CODE = ? , \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        STATUS_CODE = ? , \n");
			sql.append("        APRV_ID = ? , \n");
			sql.append("        CFMER_ID = ? , \n");
			sql.append("        CFM_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        REGER = ? , \n");
			sql.append("        REG_DT = ? , \n");
			sql.append("        PVIEW_IMG_FILE = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND LABEL_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMcLblRegModelDVO.getAplyLblVer());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getStatusCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getAprvId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmerId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getUseYn());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getReger());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getRegDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPviewImgFile());

							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());
						}
					}
		);			
	}

/**
* deleteTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return int
*/
	@LocalName("deleteTbmMcLblRegModel")
	public int deleteTbmMcLblRegModel (final TbmMcLblRegModelDVO tbmMcLblRegModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.deleteTbmMcLblRegModel.001*/  \n");
			sql.append(" TBM_MC_LBL_REG_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());
						}
					}
		);			
	}

/**
* selectTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return TbmMcLblRegModelDVO 
*/
	@LocalName("selectTbmMcLblRegModel")
	public TbmMcLblRegModelDVO selectTbmMcLblRegModel (final TbmMcLblRegModelDVO tbmMcLblRegModelDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.selectTbmMcLblRegModel.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        APLY_LBL_VER , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        STATUS_CODE , \n");
			sql.append("        APRV_ID , \n");
			sql.append("        CFMER_ID , \n");
			sql.append("        CFM_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        REGER , \n");
			sql.append("        REG_DT , \n");
			sql.append("        PVIEW_IMG_FILE , \n");
			sql.append("        LABEL_ID \n");
			sql.append("   FROM TBM_MC_LBL_REG_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");

		return (TbmMcLblRegModelDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcLblRegModelDVO returnTbmMcLblRegModelDVO = new TbmMcLblRegModelDVO();
									returnTbmMcLblRegModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMcLblRegModelDVO.setAplyLblVer(resultSet.getBigDecimal("APLY_LBL_VER"));
									returnTbmMcLblRegModelDVO.setDivCode(resultSet.getString("DIV_CODE"));
									returnTbmMcLblRegModelDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMcLblRegModelDVO.setStatusCode(resultSet.getString("STATUS_CODE"));
									returnTbmMcLblRegModelDVO.setAprvId(resultSet.getString("APRV_ID"));
									returnTbmMcLblRegModelDVO.setCfmerId(resultSet.getString("CFMER_ID"));
									returnTbmMcLblRegModelDVO.setCfmDt(resultSet.getString("CFM_DT"));
									returnTbmMcLblRegModelDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMcLblRegModelDVO.setReger(resultSet.getString("REGER"));
									returnTbmMcLblRegModelDVO.setRegDt(resultSet.getString("REG_DT"));
									returnTbmMcLblRegModelDVO.setPviewImgFile(resultSet.getString("PVIEW_IMG_FILE"));
									returnTbmMcLblRegModelDVO.setLabelId(resultSet.getString("LABEL_ID"));
									return returnTbmMcLblRegModelDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcLblRegModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcLblRegModel Method")
	public int mergeTbmMcLblRegModel (final TbmMcLblRegModelDVO tbmMcLblRegModelDVO) {
		
		if ( selectTbmMcLblRegModel (tbmMcLblRegModelDVO) == null) {
			return insertTbmMcLblRegModel(tbmMcLblRegModelDVO);
		} else {
			return selectUpdateTbmMcLblRegModel (tbmMcLblRegModelDVO);
		}
	}

	/**
	 * selectUpdateTbmMcLblRegModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcLblRegModel Method")
	public int selectUpdateTbmMcLblRegModel (final TbmMcLblRegModelDVO tbmMcLblRegModelDVO) {
		
		TbmMcLblRegModelDVO tmpTbmMcLblRegModelDVO =  selectTbmMcLblRegModel (tbmMcLblRegModelDVO);
		if ( tbmMcLblRegModelDVO.getModelCode() != null && !"".equals(tbmMcLblRegModelDVO.getModelCode()) ) {
			tmpTbmMcLblRegModelDVO.setModelCode(tbmMcLblRegModelDVO.getModelCode());
		}		
		if ( tbmMcLblRegModelDVO.getAplyLblVer() != null && !"".equals(tbmMcLblRegModelDVO.getAplyLblVer()) ) {
			tmpTbmMcLblRegModelDVO.setAplyLblVer(tbmMcLblRegModelDVO.getAplyLblVer());
		}		
		if ( tbmMcLblRegModelDVO.getDivCode() != null && !"".equals(tbmMcLblRegModelDVO.getDivCode()) ) {
			tmpTbmMcLblRegModelDVO.setDivCode(tbmMcLblRegModelDVO.getDivCode());
		}		
		if ( tbmMcLblRegModelDVO.getPlantCode() != null && !"".equals(tbmMcLblRegModelDVO.getPlantCode()) ) {
			tmpTbmMcLblRegModelDVO.setPlantCode(tbmMcLblRegModelDVO.getPlantCode());
		}		
		if ( tbmMcLblRegModelDVO.getStatusCode() != null && !"".equals(tbmMcLblRegModelDVO.getStatusCode()) ) {
			tmpTbmMcLblRegModelDVO.setStatusCode(tbmMcLblRegModelDVO.getStatusCode());
		}		
		if ( tbmMcLblRegModelDVO.getAprvId() != null && !"".equals(tbmMcLblRegModelDVO.getAprvId()) ) {
			tmpTbmMcLblRegModelDVO.setAprvId(tbmMcLblRegModelDVO.getAprvId());
		}		
		if ( tbmMcLblRegModelDVO.getCfmerId() != null && !"".equals(tbmMcLblRegModelDVO.getCfmerId()) ) {
			tmpTbmMcLblRegModelDVO.setCfmerId(tbmMcLblRegModelDVO.getCfmerId());
		}		
		if ( tbmMcLblRegModelDVO.getCfmDt() != null && !"".equals(tbmMcLblRegModelDVO.getCfmDt()) ) {
			tmpTbmMcLblRegModelDVO.setCfmDt(tbmMcLblRegModelDVO.getCfmDt());
		}		
		if ( tbmMcLblRegModelDVO.getUseYn() != null && !"".equals(tbmMcLblRegModelDVO.getUseYn()) ) {
			tmpTbmMcLblRegModelDVO.setUseYn(tbmMcLblRegModelDVO.getUseYn());
		}		
		if ( tbmMcLblRegModelDVO.getReger() != null && !"".equals(tbmMcLblRegModelDVO.getReger()) ) {
			tmpTbmMcLblRegModelDVO.setReger(tbmMcLblRegModelDVO.getReger());
		}		
		if ( tbmMcLblRegModelDVO.getRegDt() != null && !"".equals(tbmMcLblRegModelDVO.getRegDt()) ) {
			tmpTbmMcLblRegModelDVO.setRegDt(tbmMcLblRegModelDVO.getRegDt());
		}		
		if ( tbmMcLblRegModelDVO.getPviewImgFile() != null && !"".equals(tbmMcLblRegModelDVO.getPviewImgFile()) ) {
			tmpTbmMcLblRegModelDVO.setPviewImgFile(tbmMcLblRegModelDVO.getPviewImgFile());
		}		
		if ( tbmMcLblRegModelDVO.getLabelId() != null && !"".equals(tbmMcLblRegModelDVO.getLabelId()) ) {
			tmpTbmMcLblRegModelDVO.setLabelId(tbmMcLblRegModelDVO.getLabelId());
		}		
		return updateTbmMcLblRegModel (tmpTbmMcLblRegModelDVO);
	}

/**
* insertBatchTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return int[]
*/
	@LocalName("insertBatchTbmMcLblRegModel")
	public int[] insertBatchTbmMcLblRegModel (final List tbmMcLblRegModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.insertBatchTbmMcLblRegModel.001*/  \n");
			sql.append(" TBM_MC_LBL_REG_MODEL (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        APLY_LBL_VER , \n");
			sql.append("        DIV_CODE , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        STATUS_CODE , \n");
			sql.append("        APRV_ID , \n");
			sql.append("        CFMER_ID , \n");
			sql.append("        CFM_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        REGER , \n");
			sql.append("        REG_DT , \n");
			sql.append("        PVIEW_IMG_FILE , \n");
			sql.append("        LABEL_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblRegModelDVO tbmMcLblRegModelDVO = (TbmMcLblRegModelDVO)tbmMcLblRegModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setBigDecimal(psCount++, tbmMcLblRegModelDVO.getAplyLblVer());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getStatusCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getAprvId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmerId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getUseYn());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getReger());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getRegDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPviewImgFile());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());

						}
							public int getBatchSize() {
									return tbmMcLblRegModelDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return int[]
*/
	@LocalName("updateBatchTbmMcLblRegModel")
	public int[] updateBatchTbmMcLblRegModel (final List tbmMcLblRegModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.updateBatchTbmMcLblRegModel.001*/  \n");
			sql.append(" TBM_MC_LBL_REG_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        APLY_LBL_VER = ? , \n");
			sql.append("        DIV_CODE = ? , \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        STATUS_CODE = ? , \n");
			sql.append("        APRV_ID = ? , \n");
			sql.append("        CFMER_ID = ? , \n");
			sql.append("        CFM_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        REGER = ? , \n");
			sql.append("        REG_DT = ? , \n");
			sql.append("        PVIEW_IMG_FILE = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND LABEL_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblRegModelDVO tbmMcLblRegModelDVO = (TbmMcLblRegModelDVO)tbmMcLblRegModelDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMcLblRegModelDVO.getAplyLblVer());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getDivCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getStatusCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getAprvId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmerId());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getCfmDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getUseYn());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getReger());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getRegDt());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getPviewImgFile());

							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());
						}
							public int getBatchSize() {
									return tbmMcLblRegModelDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcLblRegModel Method
* 
* @ref_table TBM_MC_LBL_REG_MODEL
* @return int[]
*/
	@LocalName("deleteBatchTbmMcLblRegModel")
	public int[] deleteBatchTbmMcLblRegModel (final List tbmMcLblRegModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.mcu611p01.TbmMcLblRegModelDEM.deleteBatchTbmMcLblRegModel.001*/  \n");
			sql.append(" TBM_MC_LBL_REG_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND LABEL_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblRegModelDVO tbmMcLblRegModelDVO = (TbmMcLblRegModelDVO)tbmMcLblRegModelDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblRegModelDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblRegModelDVO.getLabelId());
						}
							public int getBatchSize() {
									return tbmMcLblRegModelDVOList.size();
							}
					}
		);			
	}

	
}