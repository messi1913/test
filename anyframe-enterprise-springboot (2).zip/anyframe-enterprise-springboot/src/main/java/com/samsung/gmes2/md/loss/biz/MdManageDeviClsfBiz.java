package com.samsung.gmes2.md.loss.biz;

public class MdManageDeviClsfBiz {

	/**
	 * 이탈분류코드 목록 조회
	 */
	public void listDeviClsfCode(){}

	/**
	 * 이탈분류코드 목록 저장
	 */
	public void saveDeviClsfCode(){}

}
