package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBD_MC_STAND_FRM
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbdMcStandFrmDEM extends AbstractDAO {


/**
* insertTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return int
*/
	@LocalName("insertTbdMcStandFrm")
	public int insertTbdMcStandFrm (final TbdMcStandFrmDVO tbdMcStandFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.insertTbdMcStandFrm.001*/  \n");
			sql.append(" TBD_MC_STAND_FRM (   \n");
			sql.append("        FRM_NO , \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        FRM_LENG , \n");
			sql.append("        FRM_HEIT \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmHeit());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbdMcStandFrm Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbdMcStandFrm Method")
	public int[][] updateBatchAllTbdMcStandFrm (final List  tbdMcStandFrmDVOList) {
		
		ArrayList updatetbdMcStandFrmDVOList = new ArrayList();
		ArrayList insertttbdMcStandFrmDVOList = new ArrayList();
		ArrayList deletetbdMcStandFrmDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbdMcStandFrmDVOList.size() ; i++) {
		  TbdMcStandFrmDVO tbdMcStandFrmDVO = (TbdMcStandFrmDVO) tbdMcStandFrmDVOList.get(i);
		  
		  if (tbdMcStandFrmDVO.getSqlAction().equals("C"))
		      insertttbdMcStandFrmDVOList.add(tbdMcStandFrmDVO);
		  else if (tbdMcStandFrmDVO.getSqlAction().equals("U"))
		      updatetbdMcStandFrmDVOList.add(tbdMcStandFrmDVO);
		  else if (tbdMcStandFrmDVO.getSqlAction().equals("D"))
		      deletetbdMcStandFrmDVOList.add(tbdMcStandFrmDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbdMcStandFrmDVOList.size() > 0) 
          resultValues[0] = insertBatchTbdMcStandFrm(insertttbdMcStandFrmDVOList);
          
      if (updatetbdMcStandFrmDVOList.size() >0)
          resultValues[1] = updateBatchTbdMcStandFrm(updatetbdMcStandFrmDVOList);
      
      if (deletetbdMcStandFrmDVOList.size() >0)
          resultValues[2] = deleteBatchTbdMcStandFrm(deletetbdMcStandFrmDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return int
*/
	@LocalName("updateTbdMcStandFrm")
	public int updateTbdMcStandFrm (final TbdMcStandFrmDVO tbdMcStandFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.updateTbdMcStandFrm.001*/  \n");
			sql.append(" TBD_MC_STAND_FRM \n");
			sql.append(" SET   \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        FRM_LENG = ? , \n");
			sql.append("        FRM_HEIT = ? \n");
			sql.append(" WHERE FRM_NO = ? \n");
			sql.append("   AND STAND_FRM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmHeit());

							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
						}
					}
		);			
	}

/**
* deleteTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return int
*/
	@LocalName("deleteTbdMcStandFrm")
	public int deleteTbdMcStandFrm (final TbdMcStandFrmDVO tbdMcStandFrmDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.deleteTbdMcStandFrm.001*/  \n");
			sql.append(" TBD_MC_STAND_FRM \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND STAND_FRM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
						}
					}
		);			
	}

/**
* selectTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return TbdMcStandFrmDVO 
*/
	@LocalName("selectTbdMcStandFrm")
	public TbdMcStandFrmDVO selectTbdMcStandFrm (final TbdMcStandFrmDVO tbdMcStandFrmDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.selectTbdMcStandFrm.001*/  \n");
			sql.append("        FRM_NO , \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        FRM_LENG , \n");
			sql.append("        FRM_HEIT \n");
			sql.append("   FROM TBD_MC_STAND_FRM \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND STAND_FRM_CODE = ? \n");

		return (TbdMcStandFrmDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbdMcStandFrmDVO returnTbdMcStandFrmDVO = new TbdMcStandFrmDVO();
									returnTbdMcStandFrmDVO.setFrmNo(resultSet.getString("FRM_NO"));
									returnTbdMcStandFrmDVO.setStandFrmCode(resultSet.getString("STAND_FRM_CODE"));
									returnTbdMcStandFrmDVO.setxValue(resultSet.getBigDecimal("X_VALUE"));
									returnTbdMcStandFrmDVO.setyValue(resultSet.getBigDecimal("Y_VALUE"));
									returnTbdMcStandFrmDVO.setFrmLeng(resultSet.getBigDecimal("FRM_LENG"));
									returnTbdMcStandFrmDVO.setFrmHeit(resultSet.getBigDecimal("FRM_HEIT"));
									return returnTbdMcStandFrmDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbdMcStandFrm Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbdMcStandFrm Method")
	public int mergeTbdMcStandFrm (final TbdMcStandFrmDVO tbdMcStandFrmDVO) {
		
		if ( selectTbdMcStandFrm (tbdMcStandFrmDVO) == null) {
			return insertTbdMcStandFrm(tbdMcStandFrmDVO);
		} else {
			return selectUpdateTbdMcStandFrm (tbdMcStandFrmDVO);
		}
	}

	/**
	 * selectUpdateTbdMcStandFrm Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbdMcStandFrm Method")
	public int selectUpdateTbdMcStandFrm (final TbdMcStandFrmDVO tbdMcStandFrmDVO) {
		
		TbdMcStandFrmDVO tmpTbdMcStandFrmDVO =  selectTbdMcStandFrm (tbdMcStandFrmDVO);
		if ( tbdMcStandFrmDVO.getFrmNo() != null && !"".equals(tbdMcStandFrmDVO.getFrmNo()) ) {
			tmpTbdMcStandFrmDVO.setFrmNo(tbdMcStandFrmDVO.getFrmNo());
		}		
		if ( tbdMcStandFrmDVO.getStandFrmCode() != null && !"".equals(tbdMcStandFrmDVO.getStandFrmCode()) ) {
			tmpTbdMcStandFrmDVO.setStandFrmCode(tbdMcStandFrmDVO.getStandFrmCode());
		}		
		if ( tbdMcStandFrmDVO.getxValue() != null && !"".equals(tbdMcStandFrmDVO.getxValue()) ) {
			tmpTbdMcStandFrmDVO.setxValue(tbdMcStandFrmDVO.getxValue());
		}		
		if ( tbdMcStandFrmDVO.getyValue() != null && !"".equals(tbdMcStandFrmDVO.getyValue()) ) {
			tmpTbdMcStandFrmDVO.setyValue(tbdMcStandFrmDVO.getyValue());
		}		
		if ( tbdMcStandFrmDVO.getFrmLeng() != null && !"".equals(tbdMcStandFrmDVO.getFrmLeng()) ) {
			tmpTbdMcStandFrmDVO.setFrmLeng(tbdMcStandFrmDVO.getFrmLeng());
		}		
		if ( tbdMcStandFrmDVO.getFrmHeit() != null && !"".equals(tbdMcStandFrmDVO.getFrmHeit()) ) {
			tmpTbdMcStandFrmDVO.setFrmHeit(tbdMcStandFrmDVO.getFrmHeit());
		}		
		return updateTbdMcStandFrm (tmpTbdMcStandFrmDVO);
	}

/**
* insertBatchTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return int[]
*/
	@LocalName("insertBatchTbdMcStandFrm")
	public int[] insertBatchTbdMcStandFrm (final List tbdMcStandFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.insertBatchTbdMcStandFrm.001*/  \n");
			sql.append(" TBD_MC_STAND_FRM (   \n");
			sql.append("        FRM_NO , \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        X_VALUE , \n");
			sql.append("        Y_VALUE , \n");
			sql.append("        FRM_LENG , \n");
			sql.append("        FRM_HEIT \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcStandFrmDVO tbdMcStandFrmDVO = (TbdMcStandFrmDVO)tbdMcStandFrmDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmHeit());

						}
							public int getBatchSize() {
									return tbdMcStandFrmDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return int[]
*/
	@LocalName("updateBatchTbdMcStandFrm")
	public int[] updateBatchTbdMcStandFrm (final List tbdMcStandFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.updateBatchTbdMcStandFrm.001*/  \n");
			sql.append(" TBD_MC_STAND_FRM \n");
			sql.append(" SET   \n");
			sql.append("        X_VALUE = ? , \n");
			sql.append("        Y_VALUE = ? , \n");
			sql.append("        FRM_LENG = ? , \n");
			sql.append("        FRM_HEIT = ? \n");
			sql.append(" WHERE FRM_NO = ? \n");
			sql.append("   AND STAND_FRM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcStandFrmDVO tbdMcStandFrmDVO = (TbdMcStandFrmDVO)tbdMcStandFrmDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getxValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getyValue());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmLeng());
							ps.setBigDecimal(psCount++, tbdMcStandFrmDVO.getFrmHeit());

							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
						}
							public int getBatchSize() {
									return tbdMcStandFrmDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbdMcStandFrm Method
* 
* @ref_table TBD_MC_STAND_FRM
* @return int[]
*/
	@LocalName("deleteBatchTbdMcStandFrm")
	public int[] deleteBatchTbdMcStandFrm (final List tbdMcStandFrmDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcStandFrmDEM.deleteBatchTbdMcStandFrm.001*/  \n");
			sql.append(" TBD_MC_STAND_FRM \n");
			sql.append("  WHERE FRM_NO = ? \n");
			sql.append("    AND STAND_FRM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcStandFrmDVO tbdMcStandFrmDVO = (TbdMcStandFrmDVO)tbdMcStandFrmDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbdMcStandFrmDVO.getFrmNo());
							ps.setString(psCount++, tbdMcStandFrmDVO.getStandFrmCode());
						}
							public int getBatchSize() {
									return tbdMcStandFrmDVOList.size();
							}
					}
		);			
	}

	
}