package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_UNITID
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdUnitidDEM extends AbstractDAO {


/**
* insertTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return int
*/
	@LocalName("insertTbmMdUnitid")
	public int insertTbmMdUnitid (final TbmMdUnitidDVO tbmMdUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.insertTbmMdUnitid.001*/  \n");
			sql.append(" TBM_MD_UNITID (   \n");
			sql.append("        UNITID , \n");
			sql.append("        UNITID_NM , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        MAIN_UNITID_YN , \n");
			sql.append("        SCAN_FORM_CODE , \n");
			sql.append("        PBA_YN , \n");
			sql.append("        LABEL_GUBUN_YN , \n");
			sql.append("        EPASS_GUBUN_YN , \n");
			sql.append("        BKND_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdUnitidDVO.getUnitidNm());
							ps.setString(psCount++, tbmMdUnitidDVO.getPrtYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getMainUnitidYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getScanFormCode());
							ps.setString(psCount++, tbmMdUnitidDVO.getPbaYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getLabelGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getEpassGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getBkndYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdUnitid Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdUnitid Method")
	public int[][] updateBatchAllTbmMdUnitid (final List  tbmMdUnitidDVOList) {
		
		ArrayList updatetbmMdUnitidDVOList = new ArrayList();
		ArrayList insertttbmMdUnitidDVOList = new ArrayList();
		ArrayList deletetbmMdUnitidDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdUnitidDVOList.size() ; i++) {
		  TbmMdUnitidDVO tbmMdUnitidDVO = (TbmMdUnitidDVO) tbmMdUnitidDVOList.get(i);
		  
		  if (tbmMdUnitidDVO.getSqlAction().equals("C"))
		      insertttbmMdUnitidDVOList.add(tbmMdUnitidDVO);
		  else if (tbmMdUnitidDVO.getSqlAction().equals("U"))
		      updatetbmMdUnitidDVOList.add(tbmMdUnitidDVO);
		  else if (tbmMdUnitidDVO.getSqlAction().equals("D"))
		      deletetbmMdUnitidDVOList.add(tbmMdUnitidDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdUnitidDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdUnitid(insertttbmMdUnitidDVOList);
          
      if (updatetbmMdUnitidDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdUnitid(updatetbmMdUnitidDVOList);
      
      if (deletetbmMdUnitidDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdUnitid(deletetbmMdUnitidDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return int
*/
	@LocalName("updateTbmMdUnitid")
	public int updateTbmMdUnitid (final TbmMdUnitidDVO tbmMdUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.updateTbmMdUnitid.001*/  \n");
			sql.append(" TBM_MD_UNITID \n");
			sql.append(" SET   \n");
			sql.append("        UNITID_NM = ? , \n");
			sql.append("        PRT_YN = ? , \n");
			sql.append("        MAIN_UNITID_YN = ? , \n");
			sql.append("        SCAN_FORM_CODE = ? , \n");
			sql.append("        PBA_YN = ? , \n");
			sql.append("        LABEL_GUBUN_YN = ? , \n");
			sql.append("        EPASS_GUBUN_YN = ? , \n");
			sql.append("        BKND_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE UNITID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdUnitidDVO.getUnitidNm());
							ps.setString(psCount++, tbmMdUnitidDVO.getPrtYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getMainUnitidYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getScanFormCode());
							ps.setString(psCount++, tbmMdUnitidDVO.getPbaYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getLabelGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getEpassGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getBkndYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
						}
					}
		);			
	}

/**
* deleteTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return int
*/
	@LocalName("deleteTbmMdUnitid")
	public int deleteTbmMdUnitid (final TbmMdUnitidDVO tbmMdUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.deleteTbmMdUnitid.001*/  \n");
			sql.append(" TBM_MD_UNITID \n");
			sql.append("  WHERE UNITID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
						}
					}
		);			
	}

/**
* selectTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return TbmMdUnitidDVO 
*/
	@LocalName("selectTbmMdUnitid")
	public TbmMdUnitidDVO selectTbmMdUnitid (final TbmMdUnitidDVO tbmMdUnitidDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.selectTbmMdUnitid.001*/  \n");
			sql.append("        UNITID , \n");
			sql.append("        UNITID_NM , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        MAIN_UNITID_YN , \n");
			sql.append("        SCAN_FORM_CODE , \n");
			sql.append("        PBA_YN , \n");
			sql.append("        LABEL_GUBUN_YN , \n");
			sql.append("        EPASS_GUBUN_YN , \n");
			sql.append("        BKND_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_UNITID \n");
			sql.append("  WHERE UNITID = ? \n");

		return (TbmMdUnitidDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdUnitidDVO returnTbmMdUnitidDVO = new TbmMdUnitidDVO();
									returnTbmMdUnitidDVO.setUnitid(resultSet.getString("UNITID"));
									returnTbmMdUnitidDVO.setUnitidNm(resultSet.getString("UNITID_NM"));
									returnTbmMdUnitidDVO.setPrtYn(resultSet.getString("PRT_YN"));
									returnTbmMdUnitidDVO.setMainUnitidYn(resultSet.getString("MAIN_UNITID_YN"));
									returnTbmMdUnitidDVO.setScanFormCode(resultSet.getString("SCAN_FORM_CODE"));
									returnTbmMdUnitidDVO.setPbaYn(resultSet.getString("PBA_YN"));
									returnTbmMdUnitidDVO.setLabelGubunYn(resultSet.getString("LABEL_GUBUN_YN"));
									returnTbmMdUnitidDVO.setEpassGubunYn(resultSet.getString("EPASS_GUBUN_YN"));
									returnTbmMdUnitidDVO.setBkndYn(resultSet.getString("BKND_YN"));
									returnTbmMdUnitidDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdUnitidDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdUnitidDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdUnitidDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdUnitidDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdUnitidDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdUnitid Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdUnitid Method")
	public int mergeTbmMdUnitid (final TbmMdUnitidDVO tbmMdUnitidDVO) {
		
		if ( selectTbmMdUnitid (tbmMdUnitidDVO) == null) {
			return insertTbmMdUnitid(tbmMdUnitidDVO);
		} else {
			return selectUpdateTbmMdUnitid (tbmMdUnitidDVO);
		}
	}

	/**
	 * selectUpdateTbmMdUnitid Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdUnitid Method")
	public int selectUpdateTbmMdUnitid (final TbmMdUnitidDVO tbmMdUnitidDVO) {
		
		TbmMdUnitidDVO tmpTbmMdUnitidDVO =  selectTbmMdUnitid (tbmMdUnitidDVO);
		if ( tbmMdUnitidDVO.getUnitid() != null && !"".equals(tbmMdUnitidDVO.getUnitid()) ) {
			tmpTbmMdUnitidDVO.setUnitid(tbmMdUnitidDVO.getUnitid());
		}		
		if ( tbmMdUnitidDVO.getUnitidNm() != null && !"".equals(tbmMdUnitidDVO.getUnitidNm()) ) {
			tmpTbmMdUnitidDVO.setUnitidNm(tbmMdUnitidDVO.getUnitidNm());
		}		
		if ( tbmMdUnitidDVO.getPrtYn() != null && !"".equals(tbmMdUnitidDVO.getPrtYn()) ) {
			tmpTbmMdUnitidDVO.setPrtYn(tbmMdUnitidDVO.getPrtYn());
		}		
		if ( tbmMdUnitidDVO.getMainUnitidYn() != null && !"".equals(tbmMdUnitidDVO.getMainUnitidYn()) ) {
			tmpTbmMdUnitidDVO.setMainUnitidYn(tbmMdUnitidDVO.getMainUnitidYn());
		}		
		if ( tbmMdUnitidDVO.getScanFormCode() != null && !"".equals(tbmMdUnitidDVO.getScanFormCode()) ) {
			tmpTbmMdUnitidDVO.setScanFormCode(tbmMdUnitidDVO.getScanFormCode());
		}		
		if ( tbmMdUnitidDVO.getPbaYn() != null && !"".equals(tbmMdUnitidDVO.getPbaYn()) ) {
			tmpTbmMdUnitidDVO.setPbaYn(tbmMdUnitidDVO.getPbaYn());
		}		
		if ( tbmMdUnitidDVO.getLabelGubunYn() != null && !"".equals(tbmMdUnitidDVO.getLabelGubunYn()) ) {
			tmpTbmMdUnitidDVO.setLabelGubunYn(tbmMdUnitidDVO.getLabelGubunYn());
		}		
		if ( tbmMdUnitidDVO.getEpassGubunYn() != null && !"".equals(tbmMdUnitidDVO.getEpassGubunYn()) ) {
			tmpTbmMdUnitidDVO.setEpassGubunYn(tbmMdUnitidDVO.getEpassGubunYn());
		}		
		if ( tbmMdUnitidDVO.getBkndYn() != null && !"".equals(tbmMdUnitidDVO.getBkndYn()) ) {
			tmpTbmMdUnitidDVO.setBkndYn(tbmMdUnitidDVO.getBkndYn());
		}		
		if ( tbmMdUnitidDVO.getUseYn() != null && !"".equals(tbmMdUnitidDVO.getUseYn()) ) {
			tmpTbmMdUnitidDVO.setUseYn(tbmMdUnitidDVO.getUseYn());
		}		
		if ( tbmMdUnitidDVO.getFstRegDt() != null && !"".equals(tbmMdUnitidDVO.getFstRegDt()) ) {
			tmpTbmMdUnitidDVO.setFstRegDt(tbmMdUnitidDVO.getFstRegDt());
		}		
		if ( tbmMdUnitidDVO.getFstRegerId() != null && !"".equals(tbmMdUnitidDVO.getFstRegerId()) ) {
			tmpTbmMdUnitidDVO.setFstRegerId(tbmMdUnitidDVO.getFstRegerId());
		}		
		if ( tbmMdUnitidDVO.getFnlUpdDt() != null && !"".equals(tbmMdUnitidDVO.getFnlUpdDt()) ) {
			tmpTbmMdUnitidDVO.setFnlUpdDt(tbmMdUnitidDVO.getFnlUpdDt());
		}		
		if ( tbmMdUnitidDVO.getFnlUpderId() != null && !"".equals(tbmMdUnitidDVO.getFnlUpderId()) ) {
			tmpTbmMdUnitidDVO.setFnlUpderId(tbmMdUnitidDVO.getFnlUpderId());
		}		
		return updateTbmMdUnitid (tmpTbmMdUnitidDVO);
	}

/**
* insertBatchTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return int[]
*/
	@LocalName("insertBatchTbmMdUnitid")
	public int[] insertBatchTbmMdUnitid (final List tbmMdUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.insertBatchTbmMdUnitid.001*/  \n");
			sql.append(" TBM_MD_UNITID (   \n");
			sql.append("        UNITID , \n");
			sql.append("        UNITID_NM , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        MAIN_UNITID_YN , \n");
			sql.append("        SCAN_FORM_CODE , \n");
			sql.append("        PBA_YN , \n");
			sql.append("        LABEL_GUBUN_YN , \n");
			sql.append("        EPASS_GUBUN_YN , \n");
			sql.append("        BKND_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdUnitidDVO tbmMdUnitidDVO = (TbmMdUnitidDVO)tbmMdUnitidDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdUnitidDVO.getUnitidNm());
							ps.setString(psCount++, tbmMdUnitidDVO.getPrtYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getMainUnitidYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getScanFormCode());
							ps.setString(psCount++, tbmMdUnitidDVO.getPbaYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getLabelGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getEpassGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getBkndYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdUnitidDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return int[]
*/
	@LocalName("updateBatchTbmMdUnitid")
	public int[] updateBatchTbmMdUnitid (final List tbmMdUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.updateBatchTbmMdUnitid.001*/  \n");
			sql.append(" TBM_MD_UNITID \n");
			sql.append(" SET   \n");
			sql.append("        UNITID_NM = ? , \n");
			sql.append("        PRT_YN = ? , \n");
			sql.append("        MAIN_UNITID_YN = ? , \n");
			sql.append("        SCAN_FORM_CODE = ? , \n");
			sql.append("        PBA_YN = ? , \n");
			sql.append("        LABEL_GUBUN_YN = ? , \n");
			sql.append("        EPASS_GUBUN_YN = ? , \n");
			sql.append("        BKND_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE UNITID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdUnitidDVO tbmMdUnitidDVO = (TbmMdUnitidDVO)tbmMdUnitidDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdUnitidDVO.getUnitidNm());
							ps.setString(psCount++, tbmMdUnitidDVO.getPrtYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getMainUnitidYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getScanFormCode());
							ps.setString(psCount++, tbmMdUnitidDVO.getPbaYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getLabelGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getEpassGubunYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getBkndYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdUnitidDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
						}
							public int getBatchSize() {
									return tbmMdUnitidDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdUnitid Method
* 
* @ref_table TBM_MD_UNITID
* @return int[]
*/
	@LocalName("deleteBatchTbmMdUnitid")
	public int[] deleteBatchTbmMdUnitid (final List tbmMdUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdUnitidDEM.deleteBatchTbmMdUnitid.001*/  \n");
			sql.append(" TBM_MD_UNITID \n");
			sql.append("  WHERE UNITID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdUnitidDVO tbmMdUnitidDVO = (TbmMdUnitidDVO)tbmMdUnitidDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdUnitidDVO.getUnitid());
						}
							public int getBatchSize() {
									return tbmMdUnitidDVOList.size();
							}
					}
		);			
	}

	
}