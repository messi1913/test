package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
public class TbcMdInspClsfDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String inspClsfCode;

	@Length(30) 
	private String inspLageClsfCode;

	@Length(30) 
	private String inspMidClsfCode;

	@Length(500) 
	private String inspClsfNm;

	@Length(1) 
	private String useYn;

	@Length(14) @NotNull
	private String fstRegDt;

	@Length(50) @NotNull
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getInspClsfCode() {
		this.inspClsfCode = super.getValue("inspClsfCode");
		return this.inspClsfCode;
	}

	public void setInspClsfCode(String inspClsfCode) {
        super.setValue("inspClsfCode", inspClsfCode);
		this.inspClsfCode = inspClsfCode;
	}
	
	public String getInspLageClsfCode() {
		this.inspLageClsfCode = super.getValue("inspLageClsfCode");
		return this.inspLageClsfCode;
	}

	public void setInspLageClsfCode(String inspLageClsfCode) {
        super.setValue("inspLageClsfCode", inspLageClsfCode);
		this.inspLageClsfCode = inspLageClsfCode;
	}
	
	public String getInspMidClsfCode() {
		this.inspMidClsfCode = super.getValue("inspMidClsfCode");
		return this.inspMidClsfCode;
	}

	public void setInspMidClsfCode(String inspMidClsfCode) {
        super.setValue("inspMidClsfCode", inspMidClsfCode);
		this.inspMidClsfCode = inspMidClsfCode;
	}
	
	public String getInspClsfNm() {
		this.inspClsfNm = super.getValue("inspClsfNm");
		return this.inspClsfNm;
	}

	public void setInspClsfNm(String inspClsfNm) {
        super.setValue("inspClsfNm", inspClsfNm);
		this.inspClsfNm = inspClsfNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}