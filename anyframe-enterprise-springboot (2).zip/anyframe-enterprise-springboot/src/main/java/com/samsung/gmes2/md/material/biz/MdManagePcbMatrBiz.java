package com.samsung.gmes2.md.material.biz;

public class MdManagePcbMatrBiz {

	/**
	 * PCB원판 목록 조회
	 */
	public void listPcbOrgn(){}

	/**
	 * 대표Assy코드 목록 조회(Combo용)
	 */
	public void listRprsAssyCode(){}

	/**
	 * PCB원판코드 목록 조회(Combo용)
	 */
	public void listPcbOrgnCode(){}

	/**
	 * PCB원판 목록 저장
	 */
	public void savePcbOrgn(){}

}
