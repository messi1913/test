package com.samsung.gmes2.md.cmm.biz;

public class MdMatrBaseBiz {

	/**
	 * 자재 대분류 리스트
	 */
	public void listMatrLageClsfBase(){}

	/**
	 * 자재 중분류 리스트
	 */
	public void listMatrMidClsfBase(){}

	/**
	 * 자재 소분류 리스트
	 */
	public void listMatrSmallClsfBase(){}

	/**
	 * 카테고리 리스트
	 */
	public void listMacatBase(){}

	/**
	 * 품명 리스트
	 */
	public void listManmBase(){}

	/**
	 * 자재 리스트
	 */
	public void listMatrCodeBase(){}

}
