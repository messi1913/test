package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
@LocalName("단위공정코드DVO")
public class TbcMdUnitProcDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String unitProcCode;

	@Length(30) @NotNull
	private String procGubunCode;

	@Length(30) @NotNull
	private String procTypeCode;

	@Length(30) @NotNull
	private String baseProcCode;

	@Length(500) @NotNull
	private String unitProcNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getUnitProcCode() {
		this.unitProcCode = super.getValue("unitProcCode");
		return this.unitProcCode;
	}

	public void setUnitProcCode(String unitProcCode) {
        super.setValue("unitProcCode", unitProcCode);
		this.unitProcCode = unitProcCode;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue("procGubunCode");
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue("procGubunCode", procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getProcTypeCode() {
		this.procTypeCode = super.getValue("procTypeCode");
		return this.procTypeCode;
	}

	public void setProcTypeCode(String procTypeCode) {
        super.setValue("procTypeCode", procTypeCode);
		this.procTypeCode = procTypeCode;
	}
	
	public String getBaseProcCode() {
		this.baseProcCode = super.getValue("baseProcCode");
		return this.baseProcCode;
	}

	public void setBaseProcCode(String baseProcCode) {
        super.setValue("baseProcCode", baseProcCode);
		this.baseProcCode = baseProcCode;
	}
	
	public String getUnitProcNm() {
		this.unitProcNm = super.getValue("unitProcNm");
		return this.unitProcNm;
	}

	public void setUnitProcNm(String unitProcNm) {
        super.setValue("unitProcNm", unitProcNm);
		this.unitProcNm = unitProcNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}