package com.samsung.gmes2.md.logi.app;

public class MDU862M01App {

	/**
	 * 모델별 Palletizing 목록 초기설정
	 */
	public void initPallInfo(){}

	/**
	 * 모델별 Palletizing 목록 조회
	 */
	public void listPallInfo(){}

	/**
	 * 모델별 Palletizing 목록 엑셀 다운로드
	 */
	public void excelPallInfo(){}

	/**
	 * 모델별 Palletizing 목록 저장
	 */
	public void savePallInfo(){}

}
