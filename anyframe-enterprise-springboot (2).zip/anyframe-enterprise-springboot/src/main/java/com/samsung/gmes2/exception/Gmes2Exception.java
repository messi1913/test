package com.samsung.gmes2.exception;

import java.lang.reflect.Field;

@SuppressWarnings("serial")
public class Gmes2Exception extends RuntimeException {
	public static final String CODE_DEFAULT = "SM-E-0000";
	private String userMessage;
	private String detailMessage;

	private static Field messageField;
	private Field getMessageField() {
		if (messageField == null) {
			try {
				messageField = Throwable.class.getDeclaredField("detailMessage");
				if (!messageField.isAccessible())
					messageField.setAccessible(true);
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			}
		}
		return messageField;
	}

	public Gmes2Exception() {
		super();
	}

	public Gmes2Exception(String message) {
		super(message);
	}

	public Gmes2Exception(Throwable cause) {
		super(cause);
	}

	public Gmes2Exception(String message, Throwable cause) {
		super(message, cause);
	}

	public String getCode() {
		return CODE_DEFAULT;
	}

	public void setMessage(String message) {
		try {
			getMessageField().set(this, message);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}

	public String getUserMessage() {
		return userMessage;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}
}
