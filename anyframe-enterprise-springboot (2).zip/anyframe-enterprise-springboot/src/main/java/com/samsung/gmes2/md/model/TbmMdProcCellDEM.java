package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PROC_CELL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdProcCellDEM extends AbstractDAO {


/**
* insertTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return int
*/
	@LocalName("insertTbmMdProcCell")
	public int insertTbmMdProcCell (final TbmMdProcCellDVO tbmMdProcCellDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.insertTbmMdProcCell.001*/  \n");
			sql.append(" TBM_MD_PROC_CELL (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        CELL_CODE , \n");
			sql.append("        CELL_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        BCR_ID , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellNm());
							ps.setString(psCount++, tbmMdProcCellDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellTypeCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getBcrId());
							ps.setString(psCount++, tbmMdProcCellDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdProcCell Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdProcCell Method")
	public int[][] updateBatchAllTbmMdProcCell (final List  tbmMdProcCellDVOList) {
		
		ArrayList updatetbmMdProcCellDVOList = new ArrayList();
		ArrayList insertttbmMdProcCellDVOList = new ArrayList();
		ArrayList deletetbmMdProcCellDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdProcCellDVOList.size() ; i++) {
		  TbmMdProcCellDVO tbmMdProcCellDVO = (TbmMdProcCellDVO) tbmMdProcCellDVOList.get(i);
		  
		  if (tbmMdProcCellDVO.getSqlAction().equals("C"))
		      insertttbmMdProcCellDVOList.add(tbmMdProcCellDVO);
		  else if (tbmMdProcCellDVO.getSqlAction().equals("U"))
		      updatetbmMdProcCellDVOList.add(tbmMdProcCellDVO);
		  else if (tbmMdProcCellDVO.getSqlAction().equals("D"))
		      deletetbmMdProcCellDVOList.add(tbmMdProcCellDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdProcCellDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdProcCell(insertttbmMdProcCellDVOList);
          
      if (updatetbmMdProcCellDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdProcCell(updatetbmMdProcCellDVOList);
      
      if (deletetbmMdProcCellDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdProcCell(deletetbmMdProcCellDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return int
*/
	@LocalName("updateTbmMdProcCell")
	public int updateTbmMdProcCell (final TbmMdProcCellDVO tbmMdProcCellDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.updateTbmMdProcCell.001*/  \n");
			sql.append(" TBM_MD_PROC_CELL \n");
			sql.append(" SET   \n");
			sql.append("        CELL_NM = ? , \n");
			sql.append("        MFG_PART_CODE = ? , \n");
			sql.append("        CELL_TYPE_CODE = ? , \n");
			sql.append("        BCR_ID = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND CELL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcCellDVO.getCellNm());
							ps.setString(psCount++, tbmMdProcCellDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellTypeCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getBcrId());
							ps.setString(psCount++, tbmMdProcCellDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
						}
					}
		);			
	}

/**
* deleteTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return int
*/
	@LocalName("deleteTbmMdProcCell")
	public int deleteTbmMdProcCell (final TbmMdProcCellDVO tbmMdProcCellDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.deleteTbmMdProcCell.001*/  \n");
			sql.append(" TBM_MD_PROC_CELL \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND CELL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
						}
					}
		);			
	}

/**
* selectTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return TbmMdProcCellDVO 
*/
	@LocalName("selectTbmMdProcCell")
	public TbmMdProcCellDVO selectTbmMdProcCell (final TbmMdProcCellDVO tbmMdProcCellDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.selectTbmMdProcCell.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        CELL_CODE , \n");
			sql.append("        CELL_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        BCR_ID , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PROC_CELL \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND CELL_CODE = ? \n");

		return (TbmMdProcCellDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdProcCellDVO returnTbmMdProcCellDVO = new TbmMdProcCellDVO();
									returnTbmMdProcCellDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdProcCellDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdProcCellDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdProcCellDVO.setCellCode(resultSet.getString("CELL_CODE"));
									returnTbmMdProcCellDVO.setCellNm(resultSet.getString("CELL_NM"));
									returnTbmMdProcCellDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdProcCellDVO.setCellTypeCode(resultSet.getString("CELL_TYPE_CODE"));
									returnTbmMdProcCellDVO.setBcrId(resultSet.getString("BCR_ID"));
									returnTbmMdProcCellDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProcCellDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProcCellDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProcCellDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProcCellDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdProcCellDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdProcCell Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdProcCell Method")
	public int mergeTbmMdProcCell (final TbmMdProcCellDVO tbmMdProcCellDVO) {
		
		if ( selectTbmMdProcCell (tbmMdProcCellDVO) == null) {
			return insertTbmMdProcCell(tbmMdProcCellDVO);
		} else {
			return selectUpdateTbmMdProcCell (tbmMdProcCellDVO);
		}
	}

	/**
	 * selectUpdateTbmMdProcCell Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdProcCell Method")
	public int selectUpdateTbmMdProcCell (final TbmMdProcCellDVO tbmMdProcCellDVO) {
		
		TbmMdProcCellDVO tmpTbmMdProcCellDVO =  selectTbmMdProcCell (tbmMdProcCellDVO);
		if ( tbmMdProcCellDVO.getFctCode() != null && !"".equals(tbmMdProcCellDVO.getFctCode()) ) {
			tmpTbmMdProcCellDVO.setFctCode(tbmMdProcCellDVO.getFctCode());
		}		
		if ( tbmMdProcCellDVO.getUnitProcCode() != null && !"".equals(tbmMdProcCellDVO.getUnitProcCode()) ) {
			tmpTbmMdProcCellDVO.setUnitProcCode(tbmMdProcCellDVO.getUnitProcCode());
		}		
		if ( tbmMdProcCellDVO.getLineCode() != null && !"".equals(tbmMdProcCellDVO.getLineCode()) ) {
			tmpTbmMdProcCellDVO.setLineCode(tbmMdProcCellDVO.getLineCode());
		}		
		if ( tbmMdProcCellDVO.getCellCode() != null && !"".equals(tbmMdProcCellDVO.getCellCode()) ) {
			tmpTbmMdProcCellDVO.setCellCode(tbmMdProcCellDVO.getCellCode());
		}		
		if ( tbmMdProcCellDVO.getCellNm() != null && !"".equals(tbmMdProcCellDVO.getCellNm()) ) {
			tmpTbmMdProcCellDVO.setCellNm(tbmMdProcCellDVO.getCellNm());
		}		
		if ( tbmMdProcCellDVO.getMfgPartCode() != null && !"".equals(tbmMdProcCellDVO.getMfgPartCode()) ) {
			tmpTbmMdProcCellDVO.setMfgPartCode(tbmMdProcCellDVO.getMfgPartCode());
		}		
		if ( tbmMdProcCellDVO.getCellTypeCode() != null && !"".equals(tbmMdProcCellDVO.getCellTypeCode()) ) {
			tmpTbmMdProcCellDVO.setCellTypeCode(tbmMdProcCellDVO.getCellTypeCode());
		}		
		if ( tbmMdProcCellDVO.getBcrId() != null && !"".equals(tbmMdProcCellDVO.getBcrId()) ) {
			tmpTbmMdProcCellDVO.setBcrId(tbmMdProcCellDVO.getBcrId());
		}		
		if ( tbmMdProcCellDVO.getUseYn() != null && !"".equals(tbmMdProcCellDVO.getUseYn()) ) {
			tmpTbmMdProcCellDVO.setUseYn(tbmMdProcCellDVO.getUseYn());
		}		
		if ( tbmMdProcCellDVO.getFstRegDt() != null && !"".equals(tbmMdProcCellDVO.getFstRegDt()) ) {
			tmpTbmMdProcCellDVO.setFstRegDt(tbmMdProcCellDVO.getFstRegDt());
		}		
		if ( tbmMdProcCellDVO.getFstRegerId() != null && !"".equals(tbmMdProcCellDVO.getFstRegerId()) ) {
			tmpTbmMdProcCellDVO.setFstRegerId(tbmMdProcCellDVO.getFstRegerId());
		}		
		if ( tbmMdProcCellDVO.getFnlUpdDt() != null && !"".equals(tbmMdProcCellDVO.getFnlUpdDt()) ) {
			tmpTbmMdProcCellDVO.setFnlUpdDt(tbmMdProcCellDVO.getFnlUpdDt());
		}		
		if ( tbmMdProcCellDVO.getFnlUpderId() != null && !"".equals(tbmMdProcCellDVO.getFnlUpderId()) ) {
			tmpTbmMdProcCellDVO.setFnlUpderId(tbmMdProcCellDVO.getFnlUpderId());
		}		
		return updateTbmMdProcCell (tmpTbmMdProcCellDVO);
	}

/**
* insertBatchTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return int[]
*/
	@LocalName("insertBatchTbmMdProcCell")
	public int[] insertBatchTbmMdProcCell (final List tbmMdProcCellDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.insertBatchTbmMdProcCell.001*/  \n");
			sql.append(" TBM_MD_PROC_CELL (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        CELL_CODE , \n");
			sql.append("        CELL_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        CELL_TYPE_CODE , \n");
			sql.append("        BCR_ID , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProcCellDVO tbmMdProcCellDVO = (TbmMdProcCellDVO)tbmMdProcCellDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellNm());
							ps.setString(psCount++, tbmMdProcCellDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellTypeCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getBcrId());
							ps.setString(psCount++, tbmMdProcCellDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdProcCellDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return int[]
*/
	@LocalName("updateBatchTbmMdProcCell")
	public int[] updateBatchTbmMdProcCell (final List tbmMdProcCellDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.updateBatchTbmMdProcCell.001*/  \n");
			sql.append(" TBM_MD_PROC_CELL \n");
			sql.append(" SET   \n");
			sql.append("        CELL_NM = ? , \n");
			sql.append("        MFG_PART_CODE = ? , \n");
			sql.append("        CELL_TYPE_CODE = ? , \n");
			sql.append("        BCR_ID = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND CELL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProcCellDVO tbmMdProcCellDVO = (TbmMdProcCellDVO)tbmMdProcCellDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcCellDVO.getCellNm());
							ps.setString(psCount++, tbmMdProcCellDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellTypeCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getBcrId());
							ps.setString(psCount++, tbmMdProcCellDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcCellDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
						}
							public int getBatchSize() {
									return tbmMdProcCellDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdProcCell Method
* 
* @ref_table TBM_MD_PROC_CELL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdProcCell")
	public int[] deleteBatchTbmMdProcCell (final List tbmMdProcCellDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdProcCellDEM.deleteBatchTbmMdProcCell.001*/  \n");
			sql.append(" TBM_MD_PROC_CELL \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND CELL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProcCellDVO tbmMdProcCellDVO = (TbmMdProcCellDVO)tbmMdProcCellDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdProcCellDVO.getFctCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcCellDVO.getCellCode());
						}
							public int getBatchSize() {
									return tbmMdProcCellDVOList.size();
							}
					}
		);			
	}

	
}