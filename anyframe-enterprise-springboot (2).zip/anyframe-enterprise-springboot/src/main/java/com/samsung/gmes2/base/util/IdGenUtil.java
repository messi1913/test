/**
 * <PRE>
 * System Name : SM
 * Business Name : L4명
 * Class Name : IdGenUtil.java
 * Description : 클래스 설명 기재
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------------------------------------------
 *    2011. 7. 26.      WiseBell   최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.base.util;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.UUID;


/**
 * MAC(12)-JVM(6)-DATETIME(14).MIL(3)-SEQ(3) 형태의 Unique한 Id를 생성. DATETIME, MIL을 제외한 나머지 값들은 36진수 값으로 표현.
 * 
 * @name_ko 아이디 생성 유틸 클래스
 * @author WiseBell
 */
public class IdGenUtil
{
    public static void main( String args[] ) throws UnknownHostException, SocketException
    {
        for ( int i = 0; i < 32867; i++ )
        {
            String id = IdGenUtil.generate( );
            if ( i > 32760 )
                System.out.println( id );
        }
        
        System.out.println(UUID.randomUUID( ).toString( ));
    }

    private static short      counter   = (short) 0;

    private static final char seperator = '-';

    private static final int  JVM       = (int) ( System.currentTimeMillis( ) >>> 8 );

    private static final int  IP;
    static
    {
        int ipadd;
        try
        {
            ipadd = toInt( InetAddress.getLocalHost( ).getAddress( ) );
        }
        catch ( Exception e )
        {
            ipadd = 0;
        }
        IP = ipadd;
    }

    private static final long MAC;
    static
    {
        long macadd;
        try
        {
            InetAddress ia = InetAddress.getLocalHost( );
            NetworkInterface ni = NetworkInterface.getByInetAddress( ia );
            macadd = toLong( ni.getHardwareAddress( ) );
        }
        catch ( Exception e )
        {
            macadd = 0;
        }
        MAC = macadd;
    }
    
    private static final String MACHINE;
    static {
        StringBuffer buf = new StringBuffer( );
        try
        {
            InetAddress ia = InetAddress.getLocalHost( );
            NetworkInterface ni = NetworkInterface.getByInetAddress( ia );
            byte[ ] mac = ni.getHardwareAddress( );

            for ( int i = 0; i < 6; i++ )
            {
                buf.append( String.format( "%02x" , mac[ i ] ) );
            }
        }
        catch ( Exception e )
        {
            buf = new StringBuffer( "000000000000" );
        }

        MACHINE = buf.toString( );
    }

    /**
     * Custom algorithm used to generate an int from a series of bytes.
     * <p/>
     * NOTE : this is different than interpreting the incoming bytes as an int value!
     * 
     * @param bytes
     *            The bytes to use in generating the int.
     * @return The generated int.
     */
    private static int toInt( byte[ ] bytes )
    {
        int result = 0;
        for ( int i = 0; i < 4; i++ )
        {
            result = ( result << 8 ) - Byte.MIN_VALUE + (int) bytes[ i ];
        }
        return result;
    }

    /**
     * Custom algorithm used to generate an long from a series of bytes.
     * <p/>
     * NOTE : this is different than interpreting the incoming bytes as an long value!
     * 
     * @param bytes
     *            The bytes to use in generating the long.
     * @return The generated long.
     */
    private static long toLong( byte[ ] bytes )
    {
        long result = 0;
        for ( int i = 0; i < 6; i++ )
        {
            result = ( result << 8 ) - Byte.MIN_VALUE + (int) bytes[ i ];
        }
        return result;
    }

    /**
     * Unique across JVMs on this machine (unless they load this class in the same quater second - very unlikely)
     */
    private static int getJVM( )
    {
        return JVM;
    }

    /**
     * Unique in a millisecond for this JVM instance (unless there are > Short.MAX_VALUE instances created in a millisecond)
     */
    private static short getCount( )
    {
        synchronized (IdGenUtil.class)
        {
            if ( counter < 0 )
            {
                counter = 0;
            }

            return counter++;
        }
    }

    /**
     * Unique in a local network
     */
    private static int getIP( )
    {
        return IP;
    }

    /**
     * Unique in a network
     */
    private static String getMachine( )
    {
        return MACHINE;
    }

    private static String format( int intValue )
    {
        String formatted = NumeralConverter.to36( intValue ).toLowerCase( );
        StringBuffer buf = new StringBuffer( "000000" );
        buf.replace( 6 - formatted.length( ), 6, formatted );
        return buf.toString( );
    }

    private static String format( short shortValue )
    {
        String formatted = NumeralConverter.to36( shortValue ).toLowerCase( );
        StringBuffer buf = new StringBuffer( "000" );
        buf.replace( 3 - formatted.length( ), 3, formatted );
        return buf.toString( );
    }

    private static String getTimestamp( )
    {
        String formatted = BaseUtil.toDateString( new Date( ), "yyyyMMddHHmmss.S" );
        StringBuffer buf = new StringBuffer( "00000000000000.000" );
        buf.replace( 0, formatted.length( ), formatted );
        return buf.toString( );
    }

    public static String generate( )
    {
        return generate( seperator );
    }

    public static String generate( char seperator )
    {
        StringBuffer buf = new StringBuffer( 36 );
        //buf.append( format( getIP( ) ) ).append( seperator );
        buf.append( getMachine( ) ).append( seperator );
        buf.append( format( getJVM( ) ) ).append( seperator );
        buf.append( getTimestamp( ) ).append( seperator );
        buf.append( format( getCount( ) ) );

        return buf.toString( );
        
        // 18a9058815d3-dpeowg-20110726171441.810-02q
    }
}
