/**
 * <PRE>
 * System Name : G-MES 2.0
 * Business Name : 개발템플릿 (TP) – 수율현황 조회
 * Class Name : BIU456M00App.java
 * Description : 공정별 세부 생산실적 현황 조회
 * Modification History
 * 			수정일			수정자          			수정내용
 * 		-------------     ---------    ---------------------------
 * 		2011.06.29			김우진          			최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.bi.biu;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.samsung.gmes2.bi.biu.vo.BiU456M00SVO;

/**
 * 한글명 : 수율현황 조회
 * 작성일 : 2011.06.29
 * 작성자 : 김우진
 * 작업상태 : 진행중
 * 개요 :
 * 공정별 세부 생산실적 현황 조회
 */
@Service("BiU456M00App")
public class BiU456M00App {
	
	
	public BiU456M00SVO getYieldList(BiU456M00SVO svo) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 변수 할당, 값 지정, 초기화
		 * @fd_id 0001
		 --------------------------------------------------*/
		
		BiU456M00DQM dao = new BiU456M00DQM();
		Map<String, Object> map = new HashMap<String, Object>();
		
		String lineCode1 = null;
		String lineCode2 = null;
		String inspectName = null;
		String inspectQty = null;
		String goodName = null;
		String goodQty = null;
		String ratio = null;
		
		//VoUtil.toMap(svo.getBiU456M0000DVO());
		/*--------------------------------------------------
		 * @fd_if 조회조건 CHECK(DAY)
		 * @fd_id 0003
		 * timePoint가 Day 일때
		 * fromDate, toDate 값 설정
		 --------------------------------------------------*/
		if(svo.getBiU456M0000DVO().getTimePoint().equals("DAY")){
			map.put("fromDate", svo.getBiU456M0000DVO().getFromDate());
			map.put("toDate", svo.getBiU456M0000DVO().getToDate());
			map.put("dateType", "YYYYMMDD");
		}
		/*--------------------------------------------------
		 * @fd_else_if 조건조건 CHECK(WEEK)
		 * @fd_id 0004
		 * timePoint가 WEEK 일때
		 * fromDate, toDate 값 설정
		 --------------------------------------------------*/
		else if(svo.getBiU456M0000DVO().getTimePoint().equals("WEEK")){
			map.put("fromDate", svo.getBiU456M0000DVO().getFromYear() + svo.getBiU456M0000DVO().getFromWeek());
			map.put("toDate", svo.getBiU456M0000DVO().getToYear() + svo.getBiU456M0000DVO().getToWeek());
		}
		/*--------------------------------------------------
		 * @fd_else_if 조회조건 CHECK(MONTH)
		 * @fd_id 0005
		 * timePoint가 MONTH 일때
		 * fromDate, toDate 값 설정
		 --------------------------------------------------*/
		else if(svo.getBiU456M0000DVO().getTimePoint().equals("MONTH")){
			map.put("fromDate", svo.getBiU456M0000DVO().getFromYear() + svo.getBiU456M0000DVO().getFromMonth());
			map.put("toDate", svo.getBiU456M0000DVO().getToYear() + svo.getBiU456M0000DVO().getToMonth());
			map.put("dateType", "YYYYMM");
		}
		/*--------------------------------------------------
		 * @fd_if 설비그룹 CHECK(SMD)
		 * @fd_id 0006
		 --------------------------------------------------*/
		if(svo.getBiU456M0000DVO().getLineCode().equals("SMD")){
			lineCode1 = "4.5.6CFG001";
			lineCode2 = "4.5.6CFG002";
			inspectName = "AOI_INSP_CNT";
			goodName = "AOI_OK_CNT";
			inspectQty = "1검사수";
			goodQty = "2양품수";
			ratio = "3수율";
		}
		/*--------------------------------------------------
		 * @fd_else 설비그룹 CHECK(비구면)
		 * @fd_id 0007
		 --------------------------------------------------*/
		else{
			lineCode1 = "4.5.6CFG003";
			lineCode2 = "4.5.6CFG004";
			inspectName = "INSERT_RESULT";
			goodName = "PROD_RESULT";
			inspectQty = "1투입실적";
			goodQty = "2생산실적";
			ratio = "3수율";
			/*  POSTATE가 없어서 일단 제외
			if(svo.getBiU456M0000DVO().getPoState().equals("1" )){
				poState = "???????????????????";
				map.put("poState", poState);
			}else{
				lineCode = "..................";
				map.put("poState", poState);
			}*/
		}
		
		map.put("timePoint", svo.getBiU456M0000DVO().getTimePoint());
		map.put("lineCode1", lineCode1);
		map.put("lineCode2", lineCode2);
		map.put("inspectName", inspectName);
		map.put("inspectQty", inspectQty);
		map.put("goodName", goodName);
		map.put("goodQty", goodQty);
		map.put("ratio", ratio);
		
		
		
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		
		
		/*--------------------------------------------------
		 * @fd_call_start 수율현황조회
		 * @fd_id 0002
		 --------------------------------------------------*/
		List dList000 = dao.dListDetailList(map);
		svo.setBiU456M0001DVOList(dList000);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
		
		return svo;
		
	}
}