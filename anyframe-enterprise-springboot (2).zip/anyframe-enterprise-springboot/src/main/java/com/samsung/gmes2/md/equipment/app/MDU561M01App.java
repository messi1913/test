package com.samsung.gmes2.md.equipment.app;

public class MDU561M01App {

	/**
	 * Robot P/G정보 목록 초기설정
	 */
	public void initRobotPgInfo(){}

	/**
	 * Robot P/G정보 목록 조회
	 */
	public void listRobotPgInfo(){}

	/**
	 * Robot P/G정보 목록 엑셀 다운로드
	 */
	public void excelRobotPgInfo(){}

	/**
	 * Robot P/G정보 목록 저장
	 */
	public void saveRobotPgmNo(){}

}
