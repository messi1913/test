package com.samsung.gmes2.md.logi.biz;

public class MdManageBinInfoBiz {

	/**
	 * Bin 목록 조회
	 */
	public void listBinInfo(){}

	/**
	 * Bin 목록 저장
	 */
	public void saveBinInfo(){}

}
