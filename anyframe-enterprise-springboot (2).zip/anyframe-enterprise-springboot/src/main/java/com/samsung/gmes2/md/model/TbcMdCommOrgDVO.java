package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author hkw
 */
public class TbcMdCommOrgDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String commOrgCode;

	@Length(30) 
	private String hrnkCommOrgCode;

	@Length(30) 
	private String commOrgTypeCode;

	@Length(500) 
	private String commOrgCodeNm;

	@Length(2000) 
	private String commOrgCodeDesc;

	@Length(15) 
	private BigDecimal codeSortPrior;

	@Length(30) 
	private String n1LabelWrtCode;

	@Length(30) 
	private String n2LabelWrtCode;

	@Length(30) 
	private String n3LabelWrtCode;

	@Length(30) 
	private String n4LabelWrtCode;

	@Length(30) 
	private String n5LabelWrtCode;

	@Length(2000) 
	private String n1CodeAttrCont;

	@Length(30) 
	private String cisMappCode;

	@Length(1) 
	private String useYn;

	@Length(14) @NotNull
	private String fstRegDt;

	@Length(50) @NotNull
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getCommOrgCode() {
		this.commOrgCode = super.getValue("commOrgCode");
		return this.commOrgCode;
	}

	public void setCommOrgCode(String commOrgCode) {
        super.setValue("commOrgCode", commOrgCode);
		this.commOrgCode = commOrgCode;
	}
	
	public String getHrnkCommOrgCode() {
		this.hrnkCommOrgCode = super.getValue("hrnkCommOrgCode");
		return this.hrnkCommOrgCode;
	}

	public void setHrnkCommOrgCode(String hrnkCommOrgCode) {
        super.setValue("hrnkCommOrgCode", hrnkCommOrgCode);
		this.hrnkCommOrgCode = hrnkCommOrgCode;
	}
	
	public String getCommOrgTypeCode() {
		this.commOrgTypeCode = super.getValue("commOrgTypeCode");
		return this.commOrgTypeCode;
	}

	public void setCommOrgTypeCode(String commOrgTypeCode) {
        super.setValue("commOrgTypeCode", commOrgTypeCode);
		this.commOrgTypeCode = commOrgTypeCode;
	}
	
	public String getCommOrgCodeNm() {
		this.commOrgCodeNm = super.getValue("commOrgCodeNm");
		return this.commOrgCodeNm;
	}

	public void setCommOrgCodeNm(String commOrgCodeNm) {
        super.setValue("commOrgCodeNm", commOrgCodeNm);
		this.commOrgCodeNm = commOrgCodeNm;
	}
	
	public String getCommOrgCodeDesc() {
		this.commOrgCodeDesc = super.getValue("commOrgCodeDesc");
		return this.commOrgCodeDesc;
	}

	public void setCommOrgCodeDesc(String commOrgCodeDesc) {
        super.setValue("commOrgCodeDesc", commOrgCodeDesc);
		this.commOrgCodeDesc = commOrgCodeDesc;
	}
	
	public BigDecimal getCodeSortPrior() {
		this.codeSortPrior = super.getValue("codeSortPrior");
		return this.codeSortPrior;
	}

	public void setCodeSortPrior(BigDecimal codeSortPrior) {
        super.setValue("codeSortPrior", codeSortPrior);
		this.codeSortPrior = codeSortPrior;
	}
	
	public String getN1LabelWrtCode() {
		this.n1LabelWrtCode = super.getValue("n1LabelWrtCode");
		return this.n1LabelWrtCode;
	}

	public void setN1LabelWrtCode(String n1LabelWrtCode) {
        super.setValue("n1LabelWrtCode", n1LabelWrtCode);
		this.n1LabelWrtCode = n1LabelWrtCode;
	}
	
	public String getN2LabelWrtCode() {
		this.n2LabelWrtCode = super.getValue("n2LabelWrtCode");
		return this.n2LabelWrtCode;
	}

	public void setN2LabelWrtCode(String n2LabelWrtCode) {
        super.setValue("n2LabelWrtCode", n2LabelWrtCode);
		this.n2LabelWrtCode = n2LabelWrtCode;
	}
	
	public String getN3LabelWrtCode() {
		this.n3LabelWrtCode = super.getValue("n3LabelWrtCode");
		return this.n3LabelWrtCode;
	}

	public void setN3LabelWrtCode(String n3LabelWrtCode) {
        super.setValue("n3LabelWrtCode", n3LabelWrtCode);
		this.n3LabelWrtCode = n3LabelWrtCode;
	}
	
	public String getN4LabelWrtCode() {
		this.n4LabelWrtCode = super.getValue("n4LabelWrtCode");
		return this.n4LabelWrtCode;
	}

	public void setN4LabelWrtCode(String n4LabelWrtCode) {
        super.setValue("n4LabelWrtCode", n4LabelWrtCode);
		this.n4LabelWrtCode = n4LabelWrtCode;
	}
	
	public String getN5LabelWrtCode() {
		this.n5LabelWrtCode = super.getValue("n5LabelWrtCode");
		return this.n5LabelWrtCode;
	}

	public void setN5LabelWrtCode(String n5LabelWrtCode) {
        super.setValue("n5LabelWrtCode", n5LabelWrtCode);
		this.n5LabelWrtCode = n5LabelWrtCode;
	}
	
	public String getN1CodeAttrCont() {
		this.n1CodeAttrCont = super.getValue("n1CodeAttrCont");
		return this.n1CodeAttrCont;
	}

	public void setN1CodeAttrCont(String n1CodeAttrCont) {
        super.setValue("n1CodeAttrCont", n1CodeAttrCont);
		this.n1CodeAttrCont = n1CodeAttrCont;
	}
	
	public String getCisMappCode() {
		this.cisMappCode = super.getValue("cisMappCode");
		return this.cisMappCode;
	}

	public void setCisMappCode(String cisMappCode) {
        super.setValue("cisMappCode", cisMappCode);
		this.cisMappCode = cisMappCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}