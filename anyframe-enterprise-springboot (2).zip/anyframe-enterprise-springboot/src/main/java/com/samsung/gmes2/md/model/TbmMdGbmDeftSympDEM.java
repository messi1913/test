package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdGbmDeftSympDEM extends AbstractDAO {


/**
* insertTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return int
*/
	@LocalName("insertTbmMdGbmDeftSymp")
	public int insertTbmMdGbmDeftSymp (final TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.insertTbmMdGbmDeftSymp.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_SYMP (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        DEFT_SYMP_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdGbmDeftSymp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdGbmDeftSymp Method")
	public int[][] updateBatchAllTbmMdGbmDeftSymp (final List  tbmMdGbmDeftSympDVOList) {
		
		ArrayList updatetbmMdGbmDeftSympDVOList = new ArrayList();
		ArrayList insertttbmMdGbmDeftSympDVOList = new ArrayList();
		ArrayList deletetbmMdGbmDeftSympDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdGbmDeftSympDVOList.size() ; i++) {
		  TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO = (TbmMdGbmDeftSympDVO) tbmMdGbmDeftSympDVOList.get(i);
		  
		  if (tbmMdGbmDeftSympDVO.getSqlAction().equals("C"))
		      insertttbmMdGbmDeftSympDVOList.add(tbmMdGbmDeftSympDVO);
		  else if (tbmMdGbmDeftSympDVO.getSqlAction().equals("U"))
		      updatetbmMdGbmDeftSympDVOList.add(tbmMdGbmDeftSympDVO);
		  else if (tbmMdGbmDeftSympDVO.getSqlAction().equals("D"))
		      deletetbmMdGbmDeftSympDVOList.add(tbmMdGbmDeftSympDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdGbmDeftSympDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdGbmDeftSymp(insertttbmMdGbmDeftSympDVOList);
          
      if (updatetbmMdGbmDeftSympDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdGbmDeftSymp(updatetbmMdGbmDeftSympDVOList);
      
      if (deletetbmMdGbmDeftSympDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdGbmDeftSymp(deletetbmMdGbmDeftSympDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return int
*/
	@LocalName("updateTbmMdGbmDeftSymp")
	public int updateTbmMdGbmDeftSymp (final TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.updateTbmMdGbmDeftSymp.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_SYMP \n");
			sql.append(" SET   \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND DEFT_SYMP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
						}
					}
		);			
	}

/**
* deleteTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return int
*/
	@LocalName("deleteTbmMdGbmDeftSymp")
	public int deleteTbmMdGbmDeftSymp (final TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.deleteTbmMdGbmDeftSymp.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_SYMP \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND DEFT_SYMP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
						}
					}
		);			
	}

/**
* selectTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return TbmMdGbmDeftSympDVO 
*/
	@LocalName("selectTbmMdGbmDeftSymp")
	public TbmMdGbmDeftSympDVO selectTbmMdGbmDeftSymp (final TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.selectTbmMdGbmDeftSymp.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        DEFT_SYMP_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_GBM_DEFT_SYMP \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND DEFT_SYMP_CODE = ? \n");

		return (TbmMdGbmDeftSympDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdGbmDeftSympDVO returnTbmMdGbmDeftSympDVO = new TbmMdGbmDeftSympDVO();
									returnTbmMdGbmDeftSympDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdGbmDeftSympDVO.setDeftSympCode(resultSet.getString("DEFT_SYMP_CODE"));
									returnTbmMdGbmDeftSympDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbmMdGbmDeftSympDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdGbmDeftSympDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdGbmDeftSympDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdGbmDeftSympDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdGbmDeftSympDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdGbmDeftSympDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdGbmDeftSymp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdGbmDeftSymp Method")
	public int mergeTbmMdGbmDeftSymp (final TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO) {
		
		if ( selectTbmMdGbmDeftSymp (tbmMdGbmDeftSympDVO) == null) {
			return insertTbmMdGbmDeftSymp(tbmMdGbmDeftSympDVO);
		} else {
			return selectUpdateTbmMdGbmDeftSymp (tbmMdGbmDeftSympDVO);
		}
	}

	/**
	 * selectUpdateTbmMdGbmDeftSymp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdGbmDeftSymp Method")
	public int selectUpdateTbmMdGbmDeftSymp (final TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO) {
		
		TbmMdGbmDeftSympDVO tmpTbmMdGbmDeftSympDVO =  selectTbmMdGbmDeftSymp (tbmMdGbmDeftSympDVO);
		if ( tbmMdGbmDeftSympDVO.getGbmCode() != null && !"".equals(tbmMdGbmDeftSympDVO.getGbmCode()) ) {
			tmpTbmMdGbmDeftSympDVO.setGbmCode(tbmMdGbmDeftSympDVO.getGbmCode());
		}		
		if ( tbmMdGbmDeftSympDVO.getDeftSympCode() != null && !"".equals(tbmMdGbmDeftSympDVO.getDeftSympCode()) ) {
			tmpTbmMdGbmDeftSympDVO.setDeftSympCode(tbmMdGbmDeftSympDVO.getDeftSympCode());
		}		
		if ( tbmMdGbmDeftSympDVO.getProcOutGubunCode() != null && !"".equals(tbmMdGbmDeftSympDVO.getProcOutGubunCode()) ) {
			tmpTbmMdGbmDeftSympDVO.setProcOutGubunCode(tbmMdGbmDeftSympDVO.getProcOutGubunCode());
		}		
		if ( tbmMdGbmDeftSympDVO.getUseYn() != null && !"".equals(tbmMdGbmDeftSympDVO.getUseYn()) ) {
			tmpTbmMdGbmDeftSympDVO.setUseYn(tbmMdGbmDeftSympDVO.getUseYn());
		}		
		if ( tbmMdGbmDeftSympDVO.getFstRegDt() != null && !"".equals(tbmMdGbmDeftSympDVO.getFstRegDt()) ) {
			tmpTbmMdGbmDeftSympDVO.setFstRegDt(tbmMdGbmDeftSympDVO.getFstRegDt());
		}		
		if ( tbmMdGbmDeftSympDVO.getFstRegerId() != null && !"".equals(tbmMdGbmDeftSympDVO.getFstRegerId()) ) {
			tmpTbmMdGbmDeftSympDVO.setFstRegerId(tbmMdGbmDeftSympDVO.getFstRegerId());
		}		
		if ( tbmMdGbmDeftSympDVO.getFnlUpdDt() != null && !"".equals(tbmMdGbmDeftSympDVO.getFnlUpdDt()) ) {
			tmpTbmMdGbmDeftSympDVO.setFnlUpdDt(tbmMdGbmDeftSympDVO.getFnlUpdDt());
		}		
		if ( tbmMdGbmDeftSympDVO.getFnlUpderId() != null && !"".equals(tbmMdGbmDeftSympDVO.getFnlUpderId()) ) {
			tmpTbmMdGbmDeftSympDVO.setFnlUpderId(tbmMdGbmDeftSympDVO.getFnlUpderId());
		}		
		return updateTbmMdGbmDeftSymp (tmpTbmMdGbmDeftSympDVO);
	}

/**
* insertBatchTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return int[]
*/
	@LocalName("insertBatchTbmMdGbmDeftSymp")
	public int[] insertBatchTbmMdGbmDeftSymp (final List tbmMdGbmDeftSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.insertBatchTbmMdGbmDeftSymp.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_SYMP (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        DEFT_SYMP_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO = (TbmMdGbmDeftSympDVO)tbmMdGbmDeftSympDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdGbmDeftSympDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return int[]
*/
	@LocalName("updateBatchTbmMdGbmDeftSymp")
	public int[] updateBatchTbmMdGbmDeftSymp (final List tbmMdGbmDeftSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.updateBatchTbmMdGbmDeftSymp.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_SYMP \n");
			sql.append(" SET   \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND DEFT_SYMP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO = (TbmMdGbmDeftSympDVO)tbmMdGbmDeftSympDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
						}
							public int getBatchSize() {
									return tbmMdGbmDeftSympDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdGbmDeftSymp Method
* 
* @ref_table TBM_MD_GBM_DEFT_SYMP
* @return int[]
*/
	@LocalName("deleteBatchTbmMdGbmDeftSymp")
	public int[] deleteBatchTbmMdGbmDeftSymp (final List tbmMdGbmDeftSympDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmDeftSympDEM.deleteBatchTbmMdGbmDeftSymp.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_SYMP \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND DEFT_SYMP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmDeftSympDVO tbmMdGbmDeftSympDVO = (TbmMdGbmDeftSympDVO)tbmMdGbmDeftSympDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftSympDVO.getDeftSympCode());
						}
							public int getBatchSize() {
									return tbmMdGbmDeftSympDVOList.size();
							}
					}
		);			
	}

	
}