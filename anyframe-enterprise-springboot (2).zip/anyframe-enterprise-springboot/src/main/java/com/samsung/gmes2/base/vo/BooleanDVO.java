package com.samsung.gmes2.base.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * @author myjung
 */
public class BooleanDVO extends AbstractVo
{

    private Boolean flag;

    public Boolean getFlag( )
    {
        this.flag = super.getValue( 0 );
        return this.flag;
    }

    public void setFlag( Boolean flag )
    {
        super.setValue( 0, flag );
        this.flag = flag;
    }

}