package com.samsung.gmes2.md.material.app;

public class MDU243M01App {

	/**
	 * 모델별 UNIT ID 목록 초기설정
	 */
	public void initModelUnitId(){}

	/**
	 * 모델별 UNIT ID 목록 조회
	 */
	public void listModelUnitId(){}

	/**
	 * 모델별 UNIT ID 목록 엑셀 다운로드
	 */
	public void excelModelUnitId(){}

	/**
	 * 모델별 UNIT ID 목록 등록/수정 초기설정
	 */
	public void editModelUnitId(){}

	/**
	 * 모델별 UNIT ID 목록 저장
	 */
	public void saveModelUnitId(){}

}
