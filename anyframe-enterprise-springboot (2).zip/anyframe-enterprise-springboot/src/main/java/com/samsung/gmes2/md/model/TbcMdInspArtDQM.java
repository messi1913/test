package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao) @LocalName("자동검사항목DQM")
public class TbcMdInspArtDQM extends AbstractDAO {


/**
* 
*
* SELECT 
* 	INSP_ART_CODE, 
* 	INSP_ART_NM, 
* 	INSP_CLSF_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_ART 
* WHERE 1=1 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtNm) 
* AND INSP_ART_NM = :inspArtNm 
* #end 
* #if($inspArtNmLike) 
* AND INSP_ART_NM like '%' || :inspArtNmLike || '%' 
* #end 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_ART_CODE,  \n");
			sql.append(" 	INSP_ART_NM,  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_ART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNm)  \n");
			sql.append(" AND INSP_ART_NM = :inspArtNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNmLike)  \n");
			sql.append(" AND INSP_ART_NM like '%' || :inspArtNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspArtDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspArtDVO returnTbcMdInspArtDVO = new TbcMdInspArtDVO();
									returnTbcMdInspArtDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdInspArtDVO.setInspArtNm(resultSet.getString("INSP_ART_NM"));
									returnTbcMdInspArtDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspArtDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	INSP_ART_CODE, 
* 	INSP_ART_NM, 
* 	INSP_CLSF_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_ART 
* WHERE 1=1 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtNm) 
* AND INSP_ART_NM = :inspArtNm 
* #end 
* #if($inspArtNmLike) 
* AND INSP_ART_NM like '%' || :inspArtNmLike || '%' 
* #end 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_ART_CODE,  \n");
			sql.append(" 	INSP_ART_NM,  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_ART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNm)  \n");
			sql.append(" AND INSP_ART_NM = :inspArtNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNmLike)  \n");
			sql.append(" AND INSP_ART_NM like '%' || :inspArtNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspArtDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspArtDVO returnTbcMdInspArtDVO = new TbcMdInspArtDVO();
									returnTbcMdInspArtDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdInspArtDVO.setInspArtNm(resultSet.getString("INSP_ART_NM"));
									returnTbcMdInspArtDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspArtDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	INSP_ART_CODE, 
* 	INSP_ART_NM, 
* 	INSP_CLSF_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_ART 
* WHERE 1=1 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtNm) 
* AND INSP_ART_NM = :inspArtNm 
* #end 
* #if($inspArtNmLike) 
* AND INSP_ART_NM like '%' || :inspArtNmLike || '%' 
* #end 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_ART_CODE,  \n");
			sql.append(" 	INSP_ART_NM,  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_ART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNm)  \n");
			sql.append(" AND INSP_ART_NM = :inspArtNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNmLike)  \n");
			sql.append(" AND INSP_ART_NM like '%' || :inspArtNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspArtDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspArtDVO returnTbcMdInspArtDVO = new TbcMdInspArtDVO();
									returnTbcMdInspArtDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdInspArtDVO.setInspArtNm(resultSet.getString("INSP_ART_NM"));
									returnTbcMdInspArtDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspArtDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
* 
*
* SELECT 
* 	INSP_ART_CODE, 
* 	INSP_ART_NM, 
* 	INSP_CLSF_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_ART 
* WHERE 1=1 
* #if($inspArtCode) 
* AND INSP_ART_CODE = :inspArtCode 
* #end 
* #if($inspArtNm) 
* AND INSP_ART_NM = :inspArtNm 
* #end 
* #if($inspArtNmLike) 
* AND INSP_ART_NM like '%' || :inspArtNmLike || '%' 
* #end 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_ART_CODE,  \n");
			sql.append(" 	INSP_ART_NM,  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_ART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspArtCode)  \n");
			sql.append(" AND INSP_ART_CODE = :inspArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNm)  \n");
			sql.append(" AND INSP_ART_NM = :inspArtNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspArtNmLike)  \n");
			sql.append(" AND INSP_ART_NM like '%' || :inspArtNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspArtDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspArtDVO returnTbcMdInspArtDVO = new TbcMdInspArtDVO();
									returnTbcMdInspArtDVO.setInspArtCode(resultSet.getString("INSP_ART_CODE"));
									returnTbcMdInspArtDVO.setInspArtNm(resultSet.getString("INSP_ART_NM"));
									returnTbcMdInspArtDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspArtDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}