package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbpMcLblIsuDirisuDVO extends AbstractVo {

	@Length(20) 
	private String modelCode;

	@Length(50) 
	private String labelId;

	@Length(14) 
	private String prtDt;

	@Length(20) 
	private String plantCode;

	@Length(50) 
	private String prterId;

	@Length(1) 
	private String rePrtYn;

	@Length(1000) 
	private String rePrtRsn;

	@Length(30) 
	private String lineCode;

	@Length(11) @Scale(5) 
	private BigDecimal prtQty;


	public String getModelCode() {
		this.modelCode = super.getValue(0);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(0, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue(1);
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue(1, labelId);
		this.labelId = labelId;
	}
	
	public String getPrtDt() {
		this.prtDt = super.getValue(2);
		return this.prtDt;
	}

	public void setPrtDt(String prtDt) {
        super.setValue(2, prtDt);
		this.prtDt = prtDt;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(3);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(3, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getPrterId() {
		this.prterId = super.getValue(4);
		return this.prterId;
	}

	public void setPrterId(String prterId) {
        super.setValue(4, prterId);
		this.prterId = prterId;
	}
	
	public String getRePrtYn() {
		this.rePrtYn = super.getValue(5);
		return this.rePrtYn;
	}

	public void setRePrtYn(String rePrtYn) {
        super.setValue(5, rePrtYn);
		this.rePrtYn = rePrtYn;
	}
	
	public String getRePrtRsn() {
		this.rePrtRsn = super.getValue(6);
		return this.rePrtRsn;
	}

	public void setRePrtRsn(String rePrtRsn) {
        super.setValue(6, rePrtRsn);
		this.rePrtRsn = rePrtRsn;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(7);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(7, lineCode);
		this.lineCode = lineCode;
	}
	
	public BigDecimal getPrtQty() {
		this.prtQty = super.getValue(8);
		return this.prtQty;
	}

	public void setPrtQty(BigDecimal prtQty) {
        super.setValue(8, prtQty);
		this.prtQty = prtQty;
	}
	
}