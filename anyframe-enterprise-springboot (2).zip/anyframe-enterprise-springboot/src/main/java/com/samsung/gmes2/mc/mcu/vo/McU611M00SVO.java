package com.samsung.gmes2.mc.mcu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractSVO;
import java.util.List;
import java.util.ArrayList;
import com.samsung.gmes2.sm.cod.vo.CodeDVO;

/**
 * 한글명 : 모델라벨 조회
 * 작성일 : 2011.06.29
 * 작성자 : 심 재 국
 * 작업상태 : 완료
 * 개요 :
 * 모델 조회 SVO
 * 모델 조회에 필요한 DVO와 SVO를 가진다
 * @stereotype SVO
 * @author shim
 */
@LocalName("라벨조회 SVO")
public class McU611M00SVO extends AbstractSVO {

    /**
     * 모델 코드의 값을 가진 DVO
     */
	@LocalName("모델 코드") 
	private McU611M0001DVO mcU611M0001DVO;

    /**
     * 조회 의 값을 List 가진 DVO
     */
	@LocalName("조회 값") 
	private McU611M0004DVO mcU611M0004DVO;

    /**
     * 모델 코드의 값을 List 가진 DVO
     */
	@LocalName("모델 코드 List") 
	private List<CodeDVO> mcU611M0001DVOList;

    /**
     * 상태 의 값을 List 가진 DVO
     */
	@LocalName("라벨 유형 List") 
	private List<CodeDVO> mcU611M0002DVOList;

    /**
     * 조회 의 값을 List 가진 DVO
     */
	@LocalName("상태 List") 
	private List<CodeDVO> mcU611M0003DVOList;

    /**
     * 모델 라벨 조회하기 위한 DVO
     */
	@LocalName("모델 라벨 조회") 
	private McU611M0008DVO mcU611M0008DVO;

    /**
     * 모델 라벨 조회하기 위한 DVO
     */
	@LocalName("모델라벨 조회") 
	private List<McU611M0008DVO> mcU611M0008DVOList;

    /**
     * TBM_MC_LBL_Reg 의 데이터 조회를하기 위한 DVO
     */
	@LocalName("Reg 정보 조회") 
	private McU611M0005DVO mcU611M0005DVO;

    /**
     * 모델 코드가 가지고있는 정보 조회를하기 위한 DVO
     */
	@LocalName("모델 코드 정보 조회") 
	private McU611M0006DVO mcU611M0006DVO;

    /**
     * TBM_MC_LBL_Reg 의 데이터 조회를하기 위한 DVO
     */
	@LocalName("Reg 정보 조회") 
	private List<McU611M0005DVO> mcU611M0005DVOList;

    /**
     * 모델 코드가 가지고있는 정보 조회를하기 위한 DVO
     */
	@LocalName("모델 코드 정보 조회") 
	private List<McU611M0006DVO> mcU611M0006DVOList;

    /**
     * 모델 코드만을 받기위한 DVO
     */
	@LocalName("모델 코드") 
	private McU611M0007DVO mcU611M0007DVO;


	/**
	 * 모델 코드 Getter Method
	 * 
	 * @return 모델 코드
	 */
	@LocalName("모델 코드 Getter Method")
	public McU611M0001DVO getMcU611M0001DVO() {
		this.mcU611M0001DVO = super.getValue("mcU611M0001DVO");
		return this.mcU611M0001DVO;
	}

	/**
	 * 모델 코드 Setter Method
	 * 
	 * @param McU611M0001DVO 모델 코드
	 */
	@LocalName("모델 코드 Setter Method")
	public void setMcU611M0001DVO(McU611M0001DVO mcU611M0001DVO) {
        super.setValue("mcU611M0001DVO", mcU611M0001DVO);
		this.mcU611M0001DVO = mcU611M0001DVO;
	}
	
	/**
	 * 조회 값 Getter Method
	 * 
	 * @return 조회 값
	 */
	@LocalName("조회 값 Getter Method")
	public McU611M0004DVO getMcU611M0004DVO() {
		this.mcU611M0004DVO = super.getValue("mcU611M0004DVO");
		return this.mcU611M0004DVO;
	}

	/**
	 * 조회 값 Setter Method
	 * 
	 * @param McU611M0004DVO 조회 값
	 */
	@LocalName("조회 값 Setter Method")
	public void setMcU611M0004DVO(McU611M0004DVO mcU611M0004DVO) {
        super.setValue("mcU611M0004DVO", mcU611M0004DVO);
		this.mcU611M0004DVO = mcU611M0004DVO;
	}
	
	/**
	 * 모델 코드 List Getter Method
	 * 
	 * @return 모델 코드 List
	 */
	@LocalName("모델 코드 List Getter Method")
	public List<CodeDVO> getMcU611M0001DVOList() {
		this.mcU611M0001DVOList = super.getValue("mcU611M0001DVOList");
		return this.mcU611M0001DVOList;
	}

	/**
	 * 모델 코드 List Setter Method
	 * 
	 * @param List 모델 코드 List
	 */
	@LocalName("모델 코드 List Setter Method")
	public void setMcU611M0001DVOList(List<CodeDVO> mcU611M0001DVOList) {
	    super.setValue("mcU611M0001DVOList", mcU611M0001DVOList);
		this.mcU611M0001DVOList = mcU611M0001DVOList;
	}
	
	/**
	 * 라벨 유형 List Getter Method
	 * 
	 * @return 라벨 유형 List
	 */
	@LocalName("라벨 유형 List Getter Method")
	public List<CodeDVO> getMcU611M0002DVOList() {
		this.mcU611M0002DVOList = super.getValue("mcU611M0002DVOList");
		return this.mcU611M0002DVOList;
	}

	/**
	 * 라벨 유형 List Setter Method
	 * 
	 * @param List 라벨 유형 List
	 */
	@LocalName("라벨 유형 List Setter Method")
	public void setMcU611M0002DVOList(List<CodeDVO> mcU611M0002DVOList) {
	    super.setValue("mcU611M0002DVOList", mcU611M0002DVOList);
		this.mcU611M0002DVOList = mcU611M0002DVOList;
	}
	
	/**
	 * 상태 List Getter Method
	 * 
	 * @return 상태 List
	 */
	@LocalName("상태 List Getter Method")
	public List<CodeDVO> getMcU611M0003DVOList() {
		this.mcU611M0003DVOList = super.getValue("mcU611M0003DVOList");
		return this.mcU611M0003DVOList;
	}

	/**
	 * 상태 List Setter Method
	 * 
	 * @param List 상태 List
	 */
	@LocalName("상태 List Setter Method")
	public void setMcU611M0003DVOList(List<CodeDVO> mcU611M0003DVOList) {
	    super.setValue("mcU611M0003DVOList", mcU611M0003DVOList);
		this.mcU611M0003DVOList = mcU611M0003DVOList;
	}
	
	/**
	 * 모델 라벨 조회 Getter Method
	 * 
	 * @return 모델 라벨 조회
	 */
	@LocalName("모델 라벨 조회 Getter Method")
	public McU611M0008DVO getMcU611M0008DVO() {
		this.mcU611M0008DVO = super.getValue("mcU611M0008DVO");
		return this.mcU611M0008DVO;
	}

	/**
	 * 모델 라벨 조회 Setter Method
	 * 
	 * @param McU611M0008DVO 모델 라벨 조회
	 */
	@LocalName("모델 라벨 조회 Setter Method")
	public void setMcU611M0008DVO(McU611M0008DVO mcU611M0008DVO) {
        super.setValue("mcU611M0008DVO", mcU611M0008DVO);
		this.mcU611M0008DVO = mcU611M0008DVO;
	}
	
	/**
	 * 모델라벨 조회 Getter Method
	 * 
	 * @return 모델라벨 조회
	 */
	@LocalName("모델라벨 조회 Getter Method")
	public List<McU611M0008DVO> getMcU611M0008DVOList() {
		this.mcU611M0008DVOList = super.getValue("mcU611M0008DVOList");
		return this.mcU611M0008DVOList;
	}

	/**
	 * 모델라벨 조회 Setter Method
	 * 
	 * @param List 모델라벨 조회
	 */
	@LocalName("모델라벨 조회 Setter Method")
	public void setMcU611M0008DVOList(List<McU611M0008DVO> mcU611M0008DVOList) {
	    super.setValue("mcU611M0008DVOList", mcU611M0008DVOList);
		this.mcU611M0008DVOList = mcU611M0008DVOList;
	}
	
	/**
	 * Reg 정보 조회 Getter Method
	 * 
	 * @return Reg 정보 조회
	 */
	@LocalName("Reg 정보 조회 Getter Method")
	public McU611M0005DVO getMcU611M0005DVO() {
		this.mcU611M0005DVO = super.getValue("mcU611M0005DVO");
		return this.mcU611M0005DVO;
	}

	/**
	 * Reg 정보 조회 Setter Method
	 * 
	 * @param McU611M0005DVO Reg 정보 조회
	 */
	@LocalName("Reg 정보 조회 Setter Method")
	public void setMcU611M0005DVO(McU611M0005DVO mcU611M0005DVO) {
        super.setValue("mcU611M0005DVO", mcU611M0005DVO);
		this.mcU611M0005DVO = mcU611M0005DVO;
	}
	
	/**
	 * 모델 코드 정보 조회 Getter Method
	 * 
	 * @return 모델 코드 정보 조회
	 */
	@LocalName("모델 코드 정보 조회 Getter Method")
	public McU611M0006DVO getMcU611M0006DVO() {
		this.mcU611M0006DVO = super.getValue("mcU611M0006DVO");
		return this.mcU611M0006DVO;
	}

	/**
	 * 모델 코드 정보 조회 Setter Method
	 * 
	 * @param McU611M0006DVO 모델 코드 정보 조회
	 */
	@LocalName("모델 코드 정보 조회 Setter Method")
	public void setMcU611M0006DVO(McU611M0006DVO mcU611M0006DVO) {
        super.setValue("mcU611M0006DVO", mcU611M0006DVO);
		this.mcU611M0006DVO = mcU611M0006DVO;
	}
	
	/**
	 * Reg 정보 조회 Getter Method
	 * 
	 * @return Reg 정보 조회
	 */
	@LocalName("Reg 정보 조회 Getter Method")
	public List<McU611M0005DVO> getMcU611M0005DVOList() {
		this.mcU611M0005DVOList = super.getValue("mcU611M0005DVOList");
		return this.mcU611M0005DVOList;
	}

	/**
	 * Reg 정보 조회 Setter Method
	 * 
	 * @param List Reg 정보 조회
	 */
	@LocalName("Reg 정보 조회 Setter Method")
	public void setMcU611M0005DVOList(List<McU611M0005DVO> mcU611M0005DVOList) {
	    super.setValue("mcU611M0005DVOList", mcU611M0005DVOList);
		this.mcU611M0005DVOList = mcU611M0005DVOList;
	}
	
	/**
	 * 모델 코드 정보 조회 Getter Method
	 * 
	 * @return 모델 코드 정보 조회
	 */
	@LocalName("모델 코드 정보 조회 Getter Method")
	public List<McU611M0006DVO> getMcU611M0006DVOList() {
		this.mcU611M0006DVOList = super.getValue("mcU611M0006DVOList");
		return this.mcU611M0006DVOList;
	}

	/**
	 * 모델 코드 정보 조회 Setter Method
	 * 
	 * @param List 모델 코드 정보 조회
	 */
	@LocalName("모델 코드 정보 조회 Setter Method")
	public void setMcU611M0006DVOList(List<McU611M0006DVO> mcU611M0006DVOList) {
	    super.setValue("mcU611M0006DVOList", mcU611M0006DVOList);
		this.mcU611M0006DVOList = mcU611M0006DVOList;
	}
	
	/**
	 * 모델 코드 Getter Method
	 * 
	 * @return 모델 코드
	 */
	@LocalName("모델 코드 Getter Method")
	public McU611M0007DVO getMcU611M0007DVO() {
		this.mcU611M0007DVO = super.getValue("mcU611M0007DVO");
		return this.mcU611M0007DVO;
	}

	/**
	 * 모델 코드 Setter Method
	 * 
	 * @param McU611M0007DVO 모델 코드
	 */
	@LocalName("모델 코드 Setter Method")
	public void setMcU611M0007DVO(McU611M0007DVO mcU611M0007DVO) {
        super.setValue("mcU611M0007DVO", mcU611M0007DVO);
		this.mcU611M0007DVO = mcU611M0007DVO;
	}
	
}