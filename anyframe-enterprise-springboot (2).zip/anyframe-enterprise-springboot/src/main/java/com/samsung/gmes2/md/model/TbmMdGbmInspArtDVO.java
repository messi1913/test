package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdGbmInspArtDVO extends AbstractVo {

	@Length(30) 
	private String gbmCode;

	@Length(30) 
	private String inspArtCode;

	@Length(30) 
	private String procOutGubunCode;

	@Length(30) 
	private String mfgGubunCode;

	@Length(30) 
	private String prodAbbrCode;

	@Length(14) 
	private String ifDt;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGbmCode() {
		this.gbmCode = super.getValue(0);
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue(0, gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getInspArtCode() {
		this.inspArtCode = super.getValue(1);
		return this.inspArtCode;
	}

	public void setInspArtCode(String inspArtCode) {
        super.setValue(1, inspArtCode);
		this.inspArtCode = inspArtCode;
	}
	
	public String getProcOutGubunCode() {
		this.procOutGubunCode = super.getValue(2);
		return this.procOutGubunCode;
	}

	public void setProcOutGubunCode(String procOutGubunCode) {
        super.setValue(2, procOutGubunCode);
		this.procOutGubunCode = procOutGubunCode;
	}
	
	public String getMfgGubunCode() {
		this.mfgGubunCode = super.getValue(3);
		return this.mfgGubunCode;
	}

	public void setMfgGubunCode(String mfgGubunCode) {
        super.setValue(3, mfgGubunCode);
		this.mfgGubunCode = mfgGubunCode;
	}
	
	public String getProdAbbrCode() {
		this.prodAbbrCode = super.getValue(4);
		return this.prodAbbrCode;
	}

	public void setProdAbbrCode(String prodAbbrCode) {
        super.setValue(4, prodAbbrCode);
		this.prodAbbrCode = prodAbbrCode;
	}
	
	public String getIfDt() {
		this.ifDt = super.getValue(5);
		return this.ifDt;
	}

	public void setIfDt(String ifDt) {
        super.setValue(5, ifDt);
		this.ifDt = ifDt;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(6);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(6, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(7);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(7, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(8);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(8, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(9);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(9, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(10);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(10, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}