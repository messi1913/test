package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 공통 코드를 가져오기 위한 DEM
 * @author shim
 */
public class TbmMcCommCdDVO extends AbstractVo {

	@Length(30) 
	private String comCode;

	@Length(20) 
	private String cateId;

	@Length(50) 
	private String codeNm;

	@Length(1) 
	private String useYn;

	@Length(200) 
	private String remark;


	public String getComCode() {
		this.comCode = super.getValue(0);
		return this.comCode;
	}

	public void setComCode(String comCode) {
        super.setValue(0, comCode);
		this.comCode = comCode;
	}
	
	public String getCateId() {
		this.cateId = super.getValue(1);
		return this.cateId;
	}

	public void setCateId(String cateId) {
        super.setValue(1, cateId);
		this.cateId = cateId;
	}
	
	public String getCodeNm() {
		this.codeNm = super.getValue(2);
		return this.codeNm;
	}

	public void setCodeNm(String codeNm) {
        super.setValue(2, codeNm);
		this.codeNm = codeNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(3);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(3, useYn);
		this.useYn = useYn;
	}
	
	public String getRemark() {
		this.remark = super.getValue(4);
		return this.remark;
	}

	public void setRemark(String remark) {
        super.setValue(4, remark);
		this.remark = remark;
	}
	
}