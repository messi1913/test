package com.samsung.gmes2.md.equipment.biz;

public class MdManageRobotPgmNoBiz {

	/**
	 * Robot P/G정보 목록 조회
	 */
	public void listRobotPgmNo(){}

	/**
	 * Robot P/G정보 목록 저장
	 */
	public void saveRobotPgmNo(){}

}
