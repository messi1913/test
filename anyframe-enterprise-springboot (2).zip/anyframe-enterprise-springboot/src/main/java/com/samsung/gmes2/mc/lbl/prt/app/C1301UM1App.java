/**
 * <PRE>
 * System Name : MC
 * Business Name : 라벨 발행
 * Class Name : MCU021M01App.java
 * Description : 라벨 발행 App. 클래스
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------------------------------------------
 *    2011. 7. 26.      kiho   최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.mc.lbl.prt.app;

import java.util.List;

/**
 * 라벨 발행 App. 클래스 
 *
 * @name_ko 라벨 발행 App. 클래스
 * @author  kiho
 */

public class C1301UM1App
{
    /**
     * 라벨유형코드 목록을 가져온다. (콤보박스 세팅용)
     * @return List<코드VO>   라벨유형코드 목록
     * @name_ko 라벨유형코드 리스트
     */
    public List<Object> listLabelTypeCode(){
    	/*--------------------------------------------------
    	 * @fd_call_start 라벨유형코드 컴포넌트 호출
    	 * @fd_id 0001
    	 * 라벨유형코드 호출(베이스 컴포넌트)
    	 * MCCMLabelCommBiz.listLabelTypeCode()
    	 --------------------------------------------------*/
    	//MCCMLabelCommBiz.listLabelTypeCode();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/

    	return null;
    }

    /**
     * 제품그룹(군) 코드 리스트 가져오기
     * @name_ko 제품그룹 코드 리스트
     */
    public List<Object> listProdgrpCode(){
    	/*--------------------------------------------------
    	 * @fd_call_start 제품그룹코드 컴포넌트 호출
    	 * @fd_id 0001
    	 * 제품그룹코드 호출(베이스 컴포넌트)
    	 * MCCMLabelCommBiz.listProdgrpCode()
    	 --------------------------------------------------*/
    	//MCCMLabelCommBiz.listProdgrpCode();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;

    }

    /**
     * 선택된 제품그룹에 해당하는 하위
     * 베이직 모델 목록 가져오기
     * @name_ko 베이직 모델 목록
     */
    public List<Object> listBasicModel(){
    	/*--------------------------------------------------
    	 * @fd_call_start 베이직 목록 가져오기
    	 * @fd_id 0001
    	 * 제품그룹에 해당하는 베이지 목록 가져오기
    	 * (베이스 컴포넌트 호출)
    	 * MCCMLabelCommBiz.listBasicModel()
    	 --------------------------------------------------*/
    	//MCCMLabelCommBiz.listBasicModel();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 선택된 베이직 목록에 해당하는
     * 모델코드 목록 가져오기
     * @name_ko 모델코드 목록
     */
    public List<Object> listModelCode(){
    	/*--------------------------------------------------
    	 * @fd_call_start 모델코드 목록 호출
    	 * @fd_id 0001
    	 * 베이직 모델의 하위 모델코드 목록 호출
    	 * (베이스 컴포넌트)
    	 * MCCMLabelCommBiz.listModelCode()
    	 --------------------------------------------------*/
    	//MCCMLabelCommBiz.listModelCode();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * PO기준 발행대상 목록 검색
     * @name_ko PO기준 발행대상 목록 검색
     */
    public List<Object> listPoPrtSrch(){
    	/*--------------------------------------------------
    	 * @fd_call_start PO기준 발행대상 목록 호출
    	 * @fd_id 0001
    	 * PO기준 발행대상 목록 검색 컴포넌트 호출
    	 * MCCMLabelPrtBiz.listPoPrtSrch()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listPoPrtSrch();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * PO기준 발행대상 상세 내역
     * @name_ko PO기준 발행대상 상세 내역
     */
    public List<Object> listPoPrtDtl(){
    	/*--------------------------------------------------
    	 * @fd_call_start PO기준 발행대상 상세내역 호출
    	 * @fd_id 0001
    	 * PO기준 발행대상 상세내역 컴포넌트 호출
    	 * MCCMLabelPrtBiz.listPoPrtDtl()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listPoPrtDtl();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 모델기준 발행대상 검색
     * @name_ko 모델기준 발행대상 검색
     */
    public List<Object> listModelPrtSrch(){
    	/*--------------------------------------------------
    	 * @fd_call_start 모델기준 발행대상 목록 호출
    	 * @fd_id 0001
    	 * 모델기준 발행대상 목록 컴포넌트 호출
    	 * MCCMLabelPrtBiz.listModelPrtSrch()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listModelPrtSrch();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 모델기준 발행대상 상세내역
     * @name_ko 모델기준 발행대상 상세내역
     */
    public List<Object> listModelPrtDtl(){
    	/*--------------------------------------------------
    	 * @fd_call_start 모델기준 발행대상 상세내역 호출
    	 * @fd_id 0001
    	 * 모델기준 발행대상 상세내역 컴포넌트 호출
    	 * MCCMLabelPrtBiz.listModelPrtDtl()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listModelPrtDtl();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 테스트 라벨에 인쇄할 정보 리턴
     * @name_ko 테스트 라벨 발행 정보
     */
    public List<Object> getLabelPrtTest(){
    	/*--------------------------------------------------
    	 * @fd_call_start 테스트 발행 라벨 변수 값 호출
    	 * @fd_id 0001
    	 * 테스트 발행 라벨 변수 값 컴포넌트 호출
    	 * MCCMLabelPrtBiz.listLabelPrtTestVal()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listLabelPrtTestVal();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 라벨 발행 시 인쇄될 변수 값 가져오기
     * @name_ko 라벨 발행 정보
     */
    public List<Object> getLabelPrtInfo(){
    	/*--------------------------------------------------
    	 * @fd_call_start 라벨발행 변수 값 목록
    	 * @fd_id 0001
    	 * 라벨발행 변수 값 컴포넌트 목록
    	 * MCCMLabelPrtBiz.listLabelPrtVal()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listLabelPrtVal();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 라벨 재발행 시 인쇄될 변수 값 가져오기
     * @name_ko 라벨 재발행 정보
     */
    public List<Object> getPreLabelPrtInfo(){
    	/*--------------------------------------------------
    	 * @fd_call_start 라벨 재발행 변수 값 목록 호출
    	 * @fd_id 0001
    	 * 라벨 재발행 시 변수 값 목록 컴포넌트 호출
    	 * MCCMLabelPrtBiz.listLabelPrtVal()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.listLabelPrtVal();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/
        return null;
    }

    /**
     * 채번된 라벨항목의 발행상태 업데이트
     * (미발행,발행,재발행)
     * @name_ko 라벨 발행상태 업데이트
     */
    public void updateLabelPrtStatus(){
    	/*--------------------------------------------------
    	 * @fd_call_start 라벨 (재)발행 상태 업데이트 호출
    	 * @fd_id 0001
    	 * 라벨 (재)발행 상태 업데이트 컴포넌트 호출
    	 * MCCMLabelPrtBiz.updateLabelPrtStatus()
    	 --------------------------------------------------*/
    	//MCCMLabelPrtBiz.updateLabelPrtStatus();

    	/*--------------------------------------------------
    	 * @fd_call_end 0001
    	 --------------------------------------------------*/

    }

}
