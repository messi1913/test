package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelKtngMatrDEM extends AbstractDAO {


/**
* insertTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return int
*/
	@LocalName("insertTbmMdModelKtngMatr")
	public int insertTbmMdModelKtngMatr (final TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.insertTbmMdModelKtngMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_KTNG_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        BOM_VER , \n");
			sql.append("        KTNG_MATR_SIZE , \n");
			sql.append("        KTNG_MATR_NQTY , \n");
			sql.append("        KTNG_TYPE_NM , \n");
			sql.append("        KTNG_MATR_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrSize());
							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrNqty());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngTypeNm());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrDesc());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelKtngMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelKtngMatr Method")
	public int[][] updateBatchAllTbmMdModelKtngMatr (final List  tbmMdModelKtngMatrDVOList) {
		
		ArrayList updatetbmMdModelKtngMatrDVOList = new ArrayList();
		ArrayList insertttbmMdModelKtngMatrDVOList = new ArrayList();
		ArrayList deletetbmMdModelKtngMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelKtngMatrDVOList.size() ; i++) {
		  TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO = (TbmMdModelKtngMatrDVO) tbmMdModelKtngMatrDVOList.get(i);
		  
		  if (tbmMdModelKtngMatrDVO.getSqlAction().equals("C"))
		      insertttbmMdModelKtngMatrDVOList.add(tbmMdModelKtngMatrDVO);
		  else if (tbmMdModelKtngMatrDVO.getSqlAction().equals("U"))
		      updatetbmMdModelKtngMatrDVOList.add(tbmMdModelKtngMatrDVO);
		  else if (tbmMdModelKtngMatrDVO.getSqlAction().equals("D"))
		      deletetbmMdModelKtngMatrDVOList.add(tbmMdModelKtngMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelKtngMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelKtngMatr(insertttbmMdModelKtngMatrDVOList);
          
      if (updatetbmMdModelKtngMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelKtngMatr(updatetbmMdModelKtngMatrDVOList);
      
      if (deletetbmMdModelKtngMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelKtngMatr(deletetbmMdModelKtngMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return int
*/
	@LocalName("updateTbmMdModelKtngMatr")
	public int updateTbmMdModelKtngMatr (final TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.updateTbmMdModelKtngMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_KTNG_MATR \n");
			sql.append(" SET   \n");
			sql.append("        KTNG_MATR_SIZE = ? , \n");
			sql.append("        KTNG_MATR_NQTY = ? , \n");
			sql.append("        KTNG_TYPE_NM = ? , \n");
			sql.append("        KTNG_MATR_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");
			sql.append("   AND BOM_VER = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrSize());
							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrNqty());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngTypeNm());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrDesc());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
						}
					}
		);			
	}

/**
* deleteTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return int
*/
	@LocalName("deleteTbmMdModelKtngMatr")
	public int deleteTbmMdModelKtngMatr (final TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.deleteTbmMdModelKtngMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_KTNG_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");
			sql.append("    AND BOM_VER = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
						}
					}
		);			
	}

/**
* selectTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return TbmMdModelKtngMatrDVO 
*/
	@LocalName("selectTbmMdModelKtngMatr")
	public TbmMdModelKtngMatrDVO selectTbmMdModelKtngMatr (final TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.selectTbmMdModelKtngMatr.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        BOM_VER , \n");
			sql.append("        KTNG_MATR_SIZE , \n");
			sql.append("        KTNG_MATR_NQTY , \n");
			sql.append("        KTNG_TYPE_NM , \n");
			sql.append("        KTNG_MATR_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_KTNG_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");
			sql.append("    AND BOM_VER = ? \n");

		return (TbmMdModelKtngMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelKtngMatrDVO returnTbmMdModelKtngMatrDVO = new TbmMdModelKtngMatrDVO();
									returnTbmMdModelKtngMatrDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdModelKtngMatrDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelKtngMatrDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdModelKtngMatrDVO.setBomVer(resultSet.getString("BOM_VER"));
									returnTbmMdModelKtngMatrDVO.setKtngMatrSize(resultSet.getBigDecimal("KTNG_MATR_SIZE"));
									returnTbmMdModelKtngMatrDVO.setKtngMatrNqty(resultSet.getBigDecimal("KTNG_MATR_NQTY"));
									returnTbmMdModelKtngMatrDVO.setKtngTypeNm(resultSet.getString("KTNG_TYPE_NM"));
									returnTbmMdModelKtngMatrDVO.setKtngMatrDesc(resultSet.getString("KTNG_MATR_DESC"));
									returnTbmMdModelKtngMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdModelKtngMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelKtngMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelKtngMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelKtngMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelKtngMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelKtngMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelKtngMatr Method")
	public int mergeTbmMdModelKtngMatr (final TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO) {
		
		if ( selectTbmMdModelKtngMatr (tbmMdModelKtngMatrDVO) == null) {
			return insertTbmMdModelKtngMatr(tbmMdModelKtngMatrDVO);
		} else {
			return selectUpdateTbmMdModelKtngMatr (tbmMdModelKtngMatrDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelKtngMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelKtngMatr Method")
	public int selectUpdateTbmMdModelKtngMatr (final TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO) {
		
		TbmMdModelKtngMatrDVO tmpTbmMdModelKtngMatrDVO =  selectTbmMdModelKtngMatr (tbmMdModelKtngMatrDVO);
		if ( tbmMdModelKtngMatrDVO.getPlantCode() != null && !"".equals(tbmMdModelKtngMatrDVO.getPlantCode()) ) {
			tmpTbmMdModelKtngMatrDVO.setPlantCode(tbmMdModelKtngMatrDVO.getPlantCode());
		}		
		if ( tbmMdModelKtngMatrDVO.getModelCode() != null && !"".equals(tbmMdModelKtngMatrDVO.getModelCode()) ) {
			tmpTbmMdModelKtngMatrDVO.setModelCode(tbmMdModelKtngMatrDVO.getModelCode());
		}		
		if ( tbmMdModelKtngMatrDVO.getMatrCode() != null && !"".equals(tbmMdModelKtngMatrDVO.getMatrCode()) ) {
			tmpTbmMdModelKtngMatrDVO.setMatrCode(tbmMdModelKtngMatrDVO.getMatrCode());
		}		
		if ( tbmMdModelKtngMatrDVO.getBomVer() != null && !"".equals(tbmMdModelKtngMatrDVO.getBomVer()) ) {
			tmpTbmMdModelKtngMatrDVO.setBomVer(tbmMdModelKtngMatrDVO.getBomVer());
		}		
		if ( tbmMdModelKtngMatrDVO.getKtngMatrSize() != null && !"".equals(tbmMdModelKtngMatrDVO.getKtngMatrSize()) ) {
			tmpTbmMdModelKtngMatrDVO.setKtngMatrSize(tbmMdModelKtngMatrDVO.getKtngMatrSize());
		}		
		if ( tbmMdModelKtngMatrDVO.getKtngMatrNqty() != null && !"".equals(tbmMdModelKtngMatrDVO.getKtngMatrNqty()) ) {
			tmpTbmMdModelKtngMatrDVO.setKtngMatrNqty(tbmMdModelKtngMatrDVO.getKtngMatrNqty());
		}		
		if ( tbmMdModelKtngMatrDVO.getKtngTypeNm() != null && !"".equals(tbmMdModelKtngMatrDVO.getKtngTypeNm()) ) {
			tmpTbmMdModelKtngMatrDVO.setKtngTypeNm(tbmMdModelKtngMatrDVO.getKtngTypeNm());
		}		
		if ( tbmMdModelKtngMatrDVO.getKtngMatrDesc() != null && !"".equals(tbmMdModelKtngMatrDVO.getKtngMatrDesc()) ) {
			tmpTbmMdModelKtngMatrDVO.setKtngMatrDesc(tbmMdModelKtngMatrDVO.getKtngMatrDesc());
		}		
		if ( tbmMdModelKtngMatrDVO.getUseYn() != null && !"".equals(tbmMdModelKtngMatrDVO.getUseYn()) ) {
			tmpTbmMdModelKtngMatrDVO.setUseYn(tbmMdModelKtngMatrDVO.getUseYn());
		}		
		if ( tbmMdModelKtngMatrDVO.getFstRegDt() != null && !"".equals(tbmMdModelKtngMatrDVO.getFstRegDt()) ) {
			tmpTbmMdModelKtngMatrDVO.setFstRegDt(tbmMdModelKtngMatrDVO.getFstRegDt());
		}		
		if ( tbmMdModelKtngMatrDVO.getFstRegerId() != null && !"".equals(tbmMdModelKtngMatrDVO.getFstRegerId()) ) {
			tmpTbmMdModelKtngMatrDVO.setFstRegerId(tbmMdModelKtngMatrDVO.getFstRegerId());
		}		
		if ( tbmMdModelKtngMatrDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelKtngMatrDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelKtngMatrDVO.setFnlUpdDt(tbmMdModelKtngMatrDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelKtngMatrDVO.getFnlUpderId() != null && !"".equals(tbmMdModelKtngMatrDVO.getFnlUpderId()) ) {
			tmpTbmMdModelKtngMatrDVO.setFnlUpderId(tbmMdModelKtngMatrDVO.getFnlUpderId());
		}		
		return updateTbmMdModelKtngMatr (tmpTbmMdModelKtngMatrDVO);
	}

/**
* insertBatchTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelKtngMatr")
	public int[] insertBatchTbmMdModelKtngMatr (final List tbmMdModelKtngMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.insertBatchTbmMdModelKtngMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_KTNG_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        BOM_VER , \n");
			sql.append("        KTNG_MATR_SIZE , \n");
			sql.append("        KTNG_MATR_NQTY , \n");
			sql.append("        KTNG_TYPE_NM , \n");
			sql.append("        KTNG_MATR_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO = (TbmMdModelKtngMatrDVO)tbmMdModelKtngMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrSize());
							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrNqty());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngTypeNm());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrDesc());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelKtngMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelKtngMatr")
	public int[] updateBatchTbmMdModelKtngMatr (final List tbmMdModelKtngMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.updateBatchTbmMdModelKtngMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_KTNG_MATR \n");
			sql.append(" SET   \n");
			sql.append("        KTNG_MATR_SIZE = ? , \n");
			sql.append("        KTNG_MATR_NQTY = ? , \n");
			sql.append("        KTNG_TYPE_NM = ? , \n");
			sql.append("        KTNG_MATR_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");
			sql.append("   AND BOM_VER = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO = (TbmMdModelKtngMatrDVO)tbmMdModelKtngMatrDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrSize());
							ps.setBigDecimal(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrNqty());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngTypeNm());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getKtngMatrDesc());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
						}
							public int getBatchSize() {
									return tbmMdModelKtngMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelKtngMatr Method
* 
* @ref_table TBM_MD_MODEL_KTNG_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelKtngMatr")
	public int[] deleteBatchTbmMdModelKtngMatr (final List tbmMdModelKtngMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelKtngMatrDEM.deleteBatchTbmMdModelKtngMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_KTNG_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");
			sql.append("    AND BOM_VER = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelKtngMatrDVO tbmMdModelKtngMatrDVO = (TbmMdModelKtngMatrDVO)tbmMdModelKtngMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelKtngMatrDVO.getBomVer());
						}
							public int getBatchSize() {
									return tbmMdModelKtngMatrDVOList.size();
							}
					}
		);			
	}

	
}