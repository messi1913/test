package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
@LocalName("증상분류코드DVO")
public class TbcMdDeftSympClsfDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String deftSympClsfCode;

	@Length(500) 
	private String deftSympClsfNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getDeftSympClsfCode() {
		this.deftSympClsfCode = super.getValue("deftSympClsfCode");
		return this.deftSympClsfCode;
	}

	public void setDeftSympClsfCode(String deftSympClsfCode) {
        super.setValue("deftSympClsfCode", deftSympClsfCode);
		this.deftSympClsfCode = deftSympClsfCode;
	}
	
	public String getDeftSympClsfNm() {
		this.deftSympClsfNm = super.getValue("deftSympClsfNm");
		return this.deftSympClsfNm;
	}

	public void setDeftSympClsfNm(String deftSympClsfNm) {
        super.setValue("deftSympClsfNm", deftSympClsfNm);
		this.deftSympClsfNm = deftSympClsfNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}