package com.samsung.gmes2.base.vo;

public class PageDVO
{
    int index = 1;

    int size  = 1000;

    public int getIndex( )
    {
        return index;
    }

    public void setIndex( int index )
    {
        this.index = index;
    }

    public int getSize( )
    {
        return size;
    }

    public void setSize( int size )
    {
        this.size = size;
    }
}
