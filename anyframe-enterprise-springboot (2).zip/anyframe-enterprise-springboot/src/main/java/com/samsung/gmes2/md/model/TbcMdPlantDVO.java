package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author sangminKim
 */
@LocalName("Plant코드조회DVO")
public class TbcMdPlantDVO extends AbstractDVO {

	@Length(20) @NotNull
	private String plantCode;

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String gbmCode;

	@Length(500) 
	private String plantNm;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String outsYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue("plantCode");
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue("plantCode", plantCode);
		this.plantCode = plantCode;
	}
	
	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getGbmCode() {
		this.gbmCode = super.getValue("gbmCode");
		return this.gbmCode;
	}

	public void setGbmCode(String gbmCode) {
        super.setValue("gbmCode", gbmCode);
		this.gbmCode = gbmCode;
	}
	
	public String getPlantNm() {
		this.plantNm = super.getValue("plantNm");
		return this.plantNm;
	}

	public void setPlantNm(String plantNm) {
        super.setValue("plantNm", plantNm);
		this.plantNm = plantNm;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue("fnlAcrsReflYn");
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue("fnlAcrsReflYn", fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getOutsYn() {
		this.outsYn = super.getValue("outsYn");
		return this.outsYn;
	}

	public void setOutsYn(String outsYn) {
        super.setValue("outsYn", outsYn);
		this.outsYn = outsYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}