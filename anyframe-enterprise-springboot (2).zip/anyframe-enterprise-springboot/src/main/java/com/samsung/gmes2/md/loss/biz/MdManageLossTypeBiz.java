package com.samsung.gmes2.md.loss.biz;

public class MdManageLossTypeBiz {

	/**
	 * 유실유형코드 목록 조회
	 */
	public void listLossTypeCode(){}

	/**
	 * 유실유형코드 목록 저장
	 */
	public void saveLossTypeCode(){}

}
