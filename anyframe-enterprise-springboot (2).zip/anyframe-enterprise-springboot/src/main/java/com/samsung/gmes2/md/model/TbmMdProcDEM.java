package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PROC
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbmMdProcDEM extends AbstractDAO {


/**
* insertTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return int
*/
	@LocalName("insertTbmMdProc")
	public int insertTbmMdProc (final TbmMdProcDVO tbmMdProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdProcDEM.insertTbmMdProc.001*/  \n");
			sql.append(" TBM_MD_PROC (   \n");
			sql.append("        PROC_NM , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        BCD_SUMR_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        OPER_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        AUTO_STOP_YN , \n");
			sql.append("        EARLY_ALRM_YN , \n");
			sql.append("        INLINE_GUBUN_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        FCT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcDVO.getProcNm());
							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbmMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdProcDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getOperYn());
							ps.setString(psCount++, tbmMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbmMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbmMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdProc Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdProc Method")
	public int[][] updateBatchAllTbmMdProc (final List  tbmMdProcDVOList) {
		
		ArrayList updatetbmMdProcDVOList = new ArrayList();
		ArrayList insertttbmMdProcDVOList = new ArrayList();
		ArrayList deletetbmMdProcDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdProcDVOList.size() ; i++) {
		  TbmMdProcDVO tbmMdProcDVO = (TbmMdProcDVO) tbmMdProcDVOList.get(i);
		  
		  if (tbmMdProcDVO.getSqlAction().equals("C"))
		      insertttbmMdProcDVOList.add(tbmMdProcDVO);
		  else if (tbmMdProcDVO.getSqlAction().equals("U"))
		      updatetbmMdProcDVOList.add(tbmMdProcDVO);
		  else if (tbmMdProcDVO.getSqlAction().equals("D"))
		      deletetbmMdProcDVOList.add(tbmMdProcDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdProcDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdProc(insertttbmMdProcDVOList);
          
      if (updatetbmMdProcDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdProc(updatetbmMdProcDVOList);
      
      if (deletetbmMdProcDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdProc(deletetbmMdProcDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return int
*/
	@LocalName("updateTbmMdProc")
	public int updateTbmMdProc (final TbmMdProcDVO tbmMdProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdProcDEM.updateTbmMdProc.001*/  \n");
			sql.append(" TBM_MD_PROC \n");
			sql.append(" SET   \n");
			sql.append("        PROC_NM = ? , \n");
			sql.append("        BCD_SUMR_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        OPER_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        AUTO_STOP_YN = ? , \n");
			sql.append("        EARLY_ALRM_YN = ? , \n");
			sql.append("        INLINE_GUBUN_CODE = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND FCT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcDVO.getProcNm());
							ps.setString(psCount++, tbmMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbmMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdProcDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getOperYn());
							ps.setString(psCount++, tbmMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbmMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbmMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());
						}
					}
		);			
	}

/**
* deleteTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return int
*/
	@LocalName("deleteTbmMdProc")
	public int deleteTbmMdProc (final TbmMdProcDVO tbmMdProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdProcDEM.deleteTbmMdProc.001*/  \n");
			sql.append(" TBM_MD_PROC \n");
			sql.append("  WHERE LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());
						}
					}
		);			
	}

/**
* selectTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return TbmMdProcDVO 
*/
	@LocalName("selectTbmMdProc")
	public TbmMdProcDVO selectTbmMdProc (final TbmMdProcDVO tbmMdProcDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdProcDEM.selectTbmMdProc.001*/  \n");
			sql.append("        PROC_NM , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        BCD_SUMR_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        OPER_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        AUTO_STOP_YN , \n");
			sql.append("        EARLY_ALRM_YN , \n");
			sql.append("        INLINE_GUBUN_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        FCT_CODE \n");
			sql.append("   FROM TBM_MD_PROC \n");
			sql.append("  WHERE LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");

		return (TbmMdProcDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdProcDVO returnTbmMdProcDVO = new TbmMdProcDVO();
									returnTbmMdProcDVO.setProcNm(resultSet.getString("PROC_NM"));
									returnTbmMdProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdProcDVO.setBcdSumrYn(resultSet.getString("BCD_SUMR_YN"));
									returnTbmMdProcDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProcDVO.setOperYn(resultSet.getString("OPER_YN"));
									returnTbmMdProcDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdProcDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdProcDVO.setAutoStopYn(resultSet.getString("AUTO_STOP_YN"));
									returnTbmMdProcDVO.setEarlyAlrmYn(resultSet.getString("EARLY_ALRM_YN"));
									returnTbmMdProcDVO.setInlineGubunCode(resultSet.getString("INLINE_GUBUN_CODE"));
									returnTbmMdProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbmMdProcDVO.setFctCode(resultSet.getString("FCT_CODE"));
									return returnTbmMdProcDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdProc Method")
	public int mergeTbmMdProc (final TbmMdProcDVO tbmMdProcDVO) {
		
		if ( selectTbmMdProc (tbmMdProcDVO) == null) {
			return insertTbmMdProc(tbmMdProcDVO);
		} else {
			return selectUpdateTbmMdProc (tbmMdProcDVO);
		}
	}

	/**
	 * selectUpdateTbmMdProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdProc Method")
	public int selectUpdateTbmMdProc (final TbmMdProcDVO tbmMdProcDVO) {
		
		TbmMdProcDVO tmpTbmMdProcDVO =  selectTbmMdProc (tbmMdProcDVO);
		if ( tbmMdProcDVO.getProcNm() != null && !"".equals(tbmMdProcDVO.getProcNm()) ) {
			tmpTbmMdProcDVO.setProcNm(tbmMdProcDVO.getProcNm());
		}		
		if ( tbmMdProcDVO.getLineCode() != null && !"".equals(tbmMdProcDVO.getLineCode()) ) {
			tmpTbmMdProcDVO.setLineCode(tbmMdProcDVO.getLineCode());
		}		
		if ( tbmMdProcDVO.getBcdSumrYn() != null && !"".equals(tbmMdProcDVO.getBcdSumrYn()) ) {
			tmpTbmMdProcDVO.setBcdSumrYn(tbmMdProcDVO.getBcdSumrYn());
		}		
		if ( tbmMdProcDVO.getFnlAcrsReflYn() != null && !"".equals(tbmMdProcDVO.getFnlAcrsReflYn()) ) {
			tmpTbmMdProcDVO.setFnlAcrsReflYn(tbmMdProcDVO.getFnlAcrsReflYn());
		}		
		if ( tbmMdProcDVO.getUseYn() != null && !"".equals(tbmMdProcDVO.getUseYn()) ) {
			tmpTbmMdProcDVO.setUseYn(tbmMdProcDVO.getUseYn());
		}		
		if ( tbmMdProcDVO.getOperYn() != null && !"".equals(tbmMdProcDVO.getOperYn()) ) {
			tmpTbmMdProcDVO.setOperYn(tbmMdProcDVO.getOperYn());
		}		
		if ( tbmMdProcDVO.getCatvUseYn() != null && !"".equals(tbmMdProcDVO.getCatvUseYn()) ) {
			tmpTbmMdProcDVO.setCatvUseYn(tbmMdProcDVO.getCatvUseYn());
		}		
		if ( tbmMdProcDVO.getBoardUseYn() != null && !"".equals(tbmMdProcDVO.getBoardUseYn()) ) {
			tmpTbmMdProcDVO.setBoardUseYn(tbmMdProcDVO.getBoardUseYn());
		}		
		if ( tbmMdProcDVO.getAutoStopYn() != null && !"".equals(tbmMdProcDVO.getAutoStopYn()) ) {
			tmpTbmMdProcDVO.setAutoStopYn(tbmMdProcDVO.getAutoStopYn());
		}		
		if ( tbmMdProcDVO.getEarlyAlrmYn() != null && !"".equals(tbmMdProcDVO.getEarlyAlrmYn()) ) {
			tmpTbmMdProcDVO.setEarlyAlrmYn(tbmMdProcDVO.getEarlyAlrmYn());
		}		
		if ( tbmMdProcDVO.getInlineGubunCode() != null && !"".equals(tbmMdProcDVO.getInlineGubunCode()) ) {
			tmpTbmMdProcDVO.setInlineGubunCode(tbmMdProcDVO.getInlineGubunCode());
		}		
		if ( tbmMdProcDVO.getUnitProcCode() != null && !"".equals(tbmMdProcDVO.getUnitProcCode()) ) {
			tmpTbmMdProcDVO.setUnitProcCode(tbmMdProcDVO.getUnitProcCode());
		}		
		if ( tbmMdProcDVO.getFstRegDt() != null && !"".equals(tbmMdProcDVO.getFstRegDt()) ) {
			tmpTbmMdProcDVO.setFstRegDt(tbmMdProcDVO.getFstRegDt());
		}		
		if ( tbmMdProcDVO.getFstRegerId() != null && !"".equals(tbmMdProcDVO.getFstRegerId()) ) {
			tmpTbmMdProcDVO.setFstRegerId(tbmMdProcDVO.getFstRegerId());
		}		
		if ( tbmMdProcDVO.getFnlUpdDt() != null && !"".equals(tbmMdProcDVO.getFnlUpdDt()) ) {
			tmpTbmMdProcDVO.setFnlUpdDt(tbmMdProcDVO.getFnlUpdDt());
		}		
		if ( tbmMdProcDVO.getFnlUpderId() != null && !"".equals(tbmMdProcDVO.getFnlUpderId()) ) {
			tmpTbmMdProcDVO.setFnlUpderId(tbmMdProcDVO.getFnlUpderId());
		}		
		if ( tbmMdProcDVO.getFctCode() != null && !"".equals(tbmMdProcDVO.getFctCode()) ) {
			tmpTbmMdProcDVO.setFctCode(tbmMdProcDVO.getFctCode());
		}		
		return updateTbmMdProc (tmpTbmMdProcDVO);
	}

/**
* insertBatchTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return int[]
*/
	@LocalName("insertBatchTbmMdProc")
	public int[] insertBatchTbmMdProc (final List tbmMdProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdProcDEM.insertBatchTbmMdProc.001*/  \n");
			sql.append(" TBM_MD_PROC (   \n");
			sql.append("        PROC_NM , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        BCD_SUMR_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        OPER_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        AUTO_STOP_YN , \n");
			sql.append("        EARLY_ALRM_YN , \n");
			sql.append("        INLINE_GUBUN_CODE , \n");
			sql.append("        UNIT_PROC_CODE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        FCT_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProcDVO tbmMdProcDVO = (TbmMdProcDVO)tbmMdProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcDVO.getProcNm());
							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbmMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdProcDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getOperYn());
							ps.setString(psCount++, tbmMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbmMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbmMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());

						}
							public int getBatchSize() {
									return tbmMdProcDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return int[]
*/
	@LocalName("updateBatchTbmMdProc")
	public int[] updateBatchTbmMdProc (final List tbmMdProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdProcDEM.updateBatchTbmMdProc.001*/  \n");
			sql.append(" TBM_MD_PROC \n");
			sql.append(" SET   \n");
			sql.append("        PROC_NM = ? , \n");
			sql.append("        BCD_SUMR_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        OPER_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        AUTO_STOP_YN = ? , \n");
			sql.append("        EARLY_ALRM_YN = ? , \n");
			sql.append("        INLINE_GUBUN_CODE = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE LINE_CODE = ? \n");
			sql.append("   AND UNIT_PROC_CODE = ? \n");
			sql.append("   AND FCT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProcDVO tbmMdProcDVO = (TbmMdProcDVO)tbmMdProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdProcDVO.getProcNm());
							ps.setString(psCount++, tbmMdProcDVO.getBcdSumrYn());
							ps.setString(psCount++, tbmMdProcDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdProcDVO.getUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getOperYn());
							ps.setString(psCount++, tbmMdProcDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdProcDVO.getAutoStopYn());
							ps.setString(psCount++, tbmMdProcDVO.getEarlyAlrmYn());
							ps.setString(psCount++, tbmMdProcDVO.getInlineGubunCode());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdProcDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdProcDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());
						}
							public int getBatchSize() {
									return tbmMdProcDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdProc Method
* 
* @ref_table TBM_MD_PROC
* @return int[]
*/
	@LocalName("deleteBatchTbmMdProc")
	public int[] deleteBatchTbmMdProc (final List tbmMdProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdProcDEM.deleteBatchTbmMdProc.001*/  \n");
			sql.append(" TBM_MD_PROC \n");
			sql.append("  WHERE LINE_CODE = ? \n");
			sql.append("    AND UNIT_PROC_CODE = ? \n");
			sql.append("    AND FCT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdProcDVO tbmMdProcDVO = (TbmMdProcDVO)tbmMdProcDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdProcDVO.getLineCode());
							ps.setString(psCount++, tbmMdProcDVO.getUnitProcCode());
							ps.setString(psCount++, tbmMdProcDVO.getFctCode());
						}
							public int getBatchSize() {
									return tbmMdProcDVOList.size();
							}
					}
		);			
	}

	
}