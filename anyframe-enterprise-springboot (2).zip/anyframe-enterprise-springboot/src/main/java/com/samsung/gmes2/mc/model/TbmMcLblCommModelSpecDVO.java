package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbmMcLblCommModelSpecDVO extends AbstractVo {

	@Length(20) 
	private String modelCode;

	@Length(500) 
	private String specAbbrNm;

	@Length(30) 
	private String specValue;


	public String getModelCode() {
		this.modelCode = super.getValue(0);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(0, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getSpecAbbrNm() {
		this.specAbbrNm = super.getValue(1);
		return this.specAbbrNm;
	}

	public void setSpecAbbrNm(String specAbbrNm) {
        super.setValue(1, specAbbrNm);
		this.specAbbrNm = specAbbrNm;
	}
	
	public String getSpecValue() {
		this.specValue = super.getValue(2);
		return this.specValue;
	}

	public void setSpecValue(String specValue) {
        super.setValue(2, specValue);
		this.specValue = specValue;
	}
	
}