package com.samsung.gmes2.md.loss.app;

public class MDU424M01App {

	/**
	 * 기준시간 목록 초기설정
	 */
	public void initBaseHmsInfo(){}

	/**
	 * 기준시간 목록 조회
	 */
	public void listBaseHmsInfo(){}

	/**
	 * 기준시간 목록 엑셀 다운로드
	 */
	public void excelBaseHmsInfo(){}

	/**
	 * 기준시간 목록 저장
	 */
	public void saveBaseHmsInfo(){}

	/**
	 * 법인별 제조파트 리스트 조회
	 */
	public void relationCorp(){}

	/**
	 * 제조파트별 라인 리스트 조회
	 */
	public void relationPart(){}

}
