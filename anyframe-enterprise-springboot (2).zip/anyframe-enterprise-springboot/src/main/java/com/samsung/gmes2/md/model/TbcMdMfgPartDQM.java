package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author hkw
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMfgPartDQM extends AbstractDAO {


/**
* 
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_PART_CODE, 
* 	MFG_TEAM_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_PART_NM, 
* 	PROC_GUBUN_CODE, 
* 	PROC_TYPE_CODE, 
* 	LABEL_WRT_CODE, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_PART 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgPartNm) 
* AND MFG_PART_NM = :mfgPartNm 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procTypeCode) 
* AND PROC_TYPE_CODE = :procTypeCode 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_PART_NM,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_TYPE_CODE,  \n");
			sql.append(" 	LABEL_WRT_CODE,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_PART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartNm)  \n");
			sql.append(" AND MFG_PART_NM = :mfgPartNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procTypeCode)  \n");
			sql.append(" AND PROC_TYPE_CODE = :procTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgPartDQM.dListPage000.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "fctCode", "mfgPartCode", "mfgTeamCode", "mfgGrpCode", "mfgPartNm", "procGubunCode", "procTypeCode", "labelWrtCode", "fnlAcrsReflYn", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("fctCode") != null && !"".equals(inputMap.get("fctCode"))) {	
					data.put("fctCode", inputMap.get("fctCode"));
				}
				if (inputMap.get("mfgPartCode") != null && !"".equals(inputMap.get("mfgPartCode"))) {	
					data.put("mfgPartCode", inputMap.get("mfgPartCode"));
				}
				if (inputMap.get("mfgTeamCode") != null && !"".equals(inputMap.get("mfgTeamCode"))) {	
					data.put("mfgTeamCode", inputMap.get("mfgTeamCode"));
				}
				if (inputMap.get("mfgGrpCode") != null && !"".equals(inputMap.get("mfgGrpCode"))) {	
					data.put("mfgGrpCode", inputMap.get("mfgGrpCode"));
				}
				if (inputMap.get("mfgPartNm") != null && !"".equals(inputMap.get("mfgPartNm"))) {	
					data.put("mfgPartNm", inputMap.get("mfgPartNm"));
				}
				if (inputMap.get("procGubunCode") != null && !"".equals(inputMap.get("procGubunCode"))) {	
					data.put("procGubunCode", inputMap.get("procGubunCode"));
				}
				if (inputMap.get("procTypeCode") != null && !"".equals(inputMap.get("procTypeCode"))) {	
					data.put("procTypeCode", inputMap.get("procTypeCode"));
				}
				if (inputMap.get("labelWrtCode") != null && !"".equals(inputMap.get("labelWrtCode"))) {	
					data.put("labelWrtCode", inputMap.get("labelWrtCode"));
				}
				if (inputMap.get("fnlAcrsReflYn") != null && !"".equals(inputMap.get("fnlAcrsReflYn"))) {	
					data.put("fnlAcrsReflYn", inputMap.get("fnlAcrsReflYn"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgPartDVO returnTbcMdMfgPartDVO = new TbcMdMfgPartDVO();
									returnTbcMdMfgPartDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbcMdMfgPartDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgPartDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartNm(resultSet.getString("MFG_PART_NM"));
									returnTbcMdMfgPartDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdMfgPartDVO.setProcTypeCode(resultSet.getString("PROC_TYPE_CODE"));
									returnTbcMdMfgPartDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbcMdMfgPartDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgPartDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgPartDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgPartDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgPartDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgPartDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgPartDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_PART_CODE, 
* 	MFG_TEAM_CODE, 
* 	MFG_GRP_CODE
* FROM TBC_MD_MFG_PART 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgPartNm) 
* AND MFG_PART_NM = :mfgPartNm 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procTypeCode) 
* AND PROC_TYPE_CODE = :procTypeCode 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE \n");
			sql.append(" FROM TBC_MD_MFG_PART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartNm)  \n");
			sql.append(" AND MFG_PART_NM = :mfgPartNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procTypeCode)  \n");
			sql.append(" AND PROC_TYPE_CODE = :procTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgPartDQM.dListPage001.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "fctCode", "mfgPartCode", "mfgTeamCode", "mfgGrpCode", "mfgPartNm", "procGubunCode", "procTypeCode", "labelWrtCode", "fnlAcrsReflYn", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("fctCode") != null && !"".equals(inputMap.get("fctCode"))) {	
					data.put("fctCode", inputMap.get("fctCode"));
				}
				if (inputMap.get("mfgPartCode") != null && !"".equals(inputMap.get("mfgPartCode"))) {	
					data.put("mfgPartCode", inputMap.get("mfgPartCode"));
				}
				if (inputMap.get("mfgTeamCode") != null && !"".equals(inputMap.get("mfgTeamCode"))) {	
					data.put("mfgTeamCode", inputMap.get("mfgTeamCode"));
				}
				if (inputMap.get("mfgGrpCode") != null && !"".equals(inputMap.get("mfgGrpCode"))) {	
					data.put("mfgGrpCode", inputMap.get("mfgGrpCode"));
				}
				if (inputMap.get("mfgPartNm") != null && !"".equals(inputMap.get("mfgPartNm"))) {	
					data.put("mfgPartNm", inputMap.get("mfgPartNm"));
				}
				if (inputMap.get("procGubunCode") != null && !"".equals(inputMap.get("procGubunCode"))) {	
					data.put("procGubunCode", inputMap.get("procGubunCode"));
				}
				if (inputMap.get("procTypeCode") != null && !"".equals(inputMap.get("procTypeCode"))) {	
					data.put("procTypeCode", inputMap.get("procTypeCode"));
				}
				if (inputMap.get("labelWrtCode") != null && !"".equals(inputMap.get("labelWrtCode"))) {	
					data.put("labelWrtCode", inputMap.get("labelWrtCode"));
				}
				if (inputMap.get("fnlAcrsReflYn") != null && !"".equals(inputMap.get("fnlAcrsReflYn"))) {	
					data.put("fnlAcrsReflYn", inputMap.get("fnlAcrsReflYn"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgPartDVO returnTbcMdMfgPartDVO = new TbcMdMfgPartDVO();
									returnTbcMdMfgPartDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbcMdMfgPartDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgPartDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									return returnTbcMdMfgPartDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_PART_CODE, 
* 	MFG_TEAM_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_PART_NM, 
* 	PROC_GUBUN_CODE, 
* 	PROC_TYPE_CODE, 
* 	LABEL_WRT_CODE, 
* 	FNL_ACRS_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_MFG_PART 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgPartNm) 
* AND MFG_PART_NM = :mfgPartNm 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procTypeCode) 
* AND PROC_TYPE_CODE = :procTypeCode 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_PART_NM,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_TYPE_CODE,  \n");
			sql.append(" 	LABEL_WRT_CODE,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_MFG_PART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartNm)  \n");
			sql.append(" AND MFG_PART_NM = :mfgPartNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procTypeCode)  \n");
			sql.append(" AND PROC_TYPE_CODE = :procTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgPartDQM.dListPageRowCount000.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "fctCode", "mfgPartCode", "mfgTeamCode", "mfgGrpCode", "mfgPartNm", "procGubunCode", "procTypeCode", "labelWrtCode", "fnlAcrsReflYn", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("fctCode") != null && !"".equals(inputMap.get("fctCode"))) {	
					data.put("fctCode", inputMap.get("fctCode"));
				}
				if (inputMap.get("mfgPartCode") != null && !"".equals(inputMap.get("mfgPartCode"))) {	
					data.put("mfgPartCode", inputMap.get("mfgPartCode"));
				}
				if (inputMap.get("mfgTeamCode") != null && !"".equals(inputMap.get("mfgTeamCode"))) {	
					data.put("mfgTeamCode", inputMap.get("mfgTeamCode"));
				}
				if (inputMap.get("mfgGrpCode") != null && !"".equals(inputMap.get("mfgGrpCode"))) {	
					data.put("mfgGrpCode", inputMap.get("mfgGrpCode"));
				}
				if (inputMap.get("mfgPartNm") != null && !"".equals(inputMap.get("mfgPartNm"))) {	
					data.put("mfgPartNm", inputMap.get("mfgPartNm"));
				}
				if (inputMap.get("procGubunCode") != null && !"".equals(inputMap.get("procGubunCode"))) {	
					data.put("procGubunCode", inputMap.get("procGubunCode"));
				}
				if (inputMap.get("procTypeCode") != null && !"".equals(inputMap.get("procTypeCode"))) {	
					data.put("procTypeCode", inputMap.get("procTypeCode"));
				}
				if (inputMap.get("labelWrtCode") != null && !"".equals(inputMap.get("labelWrtCode"))) {	
					data.put("labelWrtCode", inputMap.get("labelWrtCode"));
				}
				if (inputMap.get("fnlAcrsReflYn") != null && !"".equals(inputMap.get("fnlAcrsReflYn"))) {	
					data.put("fnlAcrsReflYn", inputMap.get("fnlAcrsReflYn"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgPartDVO returnTbcMdMfgPartDVO = new TbcMdMfgPartDVO();
									returnTbcMdMfgPartDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbcMdMfgPartDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgPartDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartNm(resultSet.getString("MFG_PART_NM"));
									returnTbcMdMfgPartDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdMfgPartDVO.setProcTypeCode(resultSet.getString("PROC_TYPE_CODE"));
									returnTbcMdMfgPartDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbcMdMfgPartDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgPartDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgPartDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgPartDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgPartDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgPartDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgPartDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
* 
*
* SELECT 
* 	FCT_CODE, 
* 	MFG_PART_CODE, 
* 	MFG_TEAM_CODE, 
* 	MFG_GRP_CODE, 
* 	MFG_PART_NM, 
* 	PROC_GUBUN_CODE, 
* 	PROC_TYPE_CODE, 
* 	LABEL_WRT_CODE	
* FROM TBC_MD_MFG_PART 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($mfgPartCode) 
* AND MFG_PART_CODE = :mfgPartCode 
* #end 
* #if($mfgTeamCode) 
* AND MFG_TEAM_CODE = :mfgTeamCode 
* #end 
* #if($mfgGrpCode) 
* AND MFG_GRP_CODE = :mfgGrpCode 
* #end 
* #if($mfgPartNm) 
* AND MFG_PART_NM = :mfgPartNm 
* #end 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procTypeCode) 
* AND PROC_TYPE_CODE = :procTypeCode 
* #end 
* #if($labelWrtCode) 
* AND LABEL_WRT_CODE = :labelWrtCode 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	MFG_PART_CODE,  \n");
			sql.append(" 	MFG_TEAM_CODE,  \n");
			sql.append(" 	MFG_GRP_CODE,  \n");
			sql.append(" 	MFG_PART_NM,  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_TYPE_CODE,  \n");
			sql.append(" 	LABEL_WRT_CODE	 \n");
			sql.append(" FROM TBC_MD_MFG_PART  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartCode)  \n");
			sql.append(" AND MFG_PART_CODE = :mfgPartCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgTeamCode)  \n");
			sql.append(" AND MFG_TEAM_CODE = :mfgTeamCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgGrpCode)  \n");
			sql.append(" AND MFG_GRP_CODE = :mfgGrpCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($mfgPartNm)  \n");
			sql.append(" AND MFG_PART_NM = :mfgPartNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procTypeCode)  \n");
			sql.append(" AND PROC_TYPE_CODE = :procTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($labelWrtCode)  \n");
			sql.append(" AND LABEL_WRT_CODE = :labelWrtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdMfgPartDQM.dListPageRowCount001.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "fctCode", "mfgPartCode", "mfgTeamCode", "mfgGrpCode", "mfgPartNm", "procGubunCode", "procTypeCode", "labelWrtCode", "fnlAcrsReflYn", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("fctCode") != null && !"".equals(inputMap.get("fctCode"))) {	
					data.put("fctCode", inputMap.get("fctCode"));
				}
				if (inputMap.get("mfgPartCode") != null && !"".equals(inputMap.get("mfgPartCode"))) {	
					data.put("mfgPartCode", inputMap.get("mfgPartCode"));
				}
				if (inputMap.get("mfgTeamCode") != null && !"".equals(inputMap.get("mfgTeamCode"))) {	
					data.put("mfgTeamCode", inputMap.get("mfgTeamCode"));
				}
				if (inputMap.get("mfgGrpCode") != null && !"".equals(inputMap.get("mfgGrpCode"))) {	
					data.put("mfgGrpCode", inputMap.get("mfgGrpCode"));
				}
				if (inputMap.get("mfgPartNm") != null && !"".equals(inputMap.get("mfgPartNm"))) {	
					data.put("mfgPartNm", inputMap.get("mfgPartNm"));
				}
				if (inputMap.get("procGubunCode") != null && !"".equals(inputMap.get("procGubunCode"))) {	
					data.put("procGubunCode", inputMap.get("procGubunCode"));
				}
				if (inputMap.get("procTypeCode") != null && !"".equals(inputMap.get("procTypeCode"))) {	
					data.put("procTypeCode", inputMap.get("procTypeCode"));
				}
				if (inputMap.get("labelWrtCode") != null && !"".equals(inputMap.get("labelWrtCode"))) {	
					data.put("labelWrtCode", inputMap.get("labelWrtCode"));
				}
				if (inputMap.get("fnlAcrsReflYn") != null && !"".equals(inputMap.get("fnlAcrsReflYn"))) {	
					data.put("fnlAcrsReflYn", inputMap.get("fnlAcrsReflYn"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdMfgPartDVO returnTbcMdMfgPartDVO = new TbcMdMfgPartDVO();
									returnTbcMdMfgPartDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbcMdMfgPartDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgPartDVO.setMfgGrpCode(resultSet.getString("MFG_GRP_CODE"));
									returnTbcMdMfgPartDVO.setMfgPartNm(resultSet.getString("MFG_PART_NM"));
									returnTbcMdMfgPartDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdMfgPartDVO.setProcTypeCode(resultSet.getString("PROC_TYPE_CODE"));
									returnTbcMdMfgPartDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									return returnTbcMdMfgPartDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}