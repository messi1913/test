package com.samsung.gmes2.md.logi.biz;

public class MdManageBcrPortInfoBiz {

	/**
	 * BCR Port 목록 조회
	 */
	public void listBcrPortInfo(){}

	/**
	 * BCR Port 목록 저장
	 */
	public void saveBcrPortInfo(){}

}
