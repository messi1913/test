package com.samsung.gmes2.mc.mcu.app;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.samsung.gmes2.mc.mcu.vo.McU611M0005DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M0006DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M0008DVO;

/**
* 
*
* @ref_table  
* @author shim
*/
@Stereotype(Stereotype.Dao) @LocalName("모델 코드 List를 가져오기")
public class McU611M00DQM extends AbstractDAO {


/**
*
* SELECT 
* 	M.MODEL_CODE, R.LBL_NM LABEL_NAME, R.LBL_VER,  R.LBL_TYPE_CODE, 
* 	M.PVIEW_IMG_FILE  pview_Img_File, M.STATUS_CODE STATUS_CODE, M.REGER ,
* 	M.REG_DT, M.CFMER_ID, M.CFM_DT ,R.LBL_ID LABEL_ID
* FROM TBM_MC_LBL_REG_MODEL M ,TBM_MC_LBL_REG R ,
* 		  TBM_MC_COMM_CD CD, TBM_MC_COMM_CD_CATE C
* WHERE 1=1
* AND M.LABEL_ID=R.LBL_ID 
* AND R.LBL_TYPE_CODE = CD.COM_CODE
* AND CD.CATE_ID = C.CATE_ID
* #if($modelCode)
* AND M.MODEL_CODE= :modelCode
* #end
* #if($comCode)
* AND CD.COM_CODE= :comCode
* #end
* #if($statusCode)
* AND M.STATUS_CODE= :statusCode
* #end
* ORDER BY R.LBL_ID ASC
* 
* @ref_table 
* @return List
*
*/
	public List dListMCU611M00DVO (final Map inputMap) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	M.MODEL_CODE, R.LBL_NM LABEL_NAME, R.LBL_VER,  R.LBL_TYPE_CODE,  \n");
			sql.append(" 	M.PVIEW_IMG_FILE  pview_Img_File, M.STATUS_CODE STATUS_CODE, M.REGER , \n");
			sql.append(" 	To_char(TO_DATE(reg_dt,'YYYYMMDD'),'YYYY-MM-DD') REG_DT, M.CFMER_ID, M.CFM_DT ,R.LBL_ID LABEL_ID \n");
			sql.append(" FROM TBM_MC_LBL_REG_MODEL M ,TBM_MC_LBL_REG R , \n");
			sql.append(" 		  TBM_MC_COMM_CD CD, TBM_MC_COMM_CD_CATE C \n");
			sql.append(" WHERE 1=1 \n");
			sql.append(" AND M.LABEL_ID=R.LBL_ID  \n");
			sql.append(" AND R.LBL_TYPE_CODE = CD.COM_CODE \n");
			sql.append(" AND CD.CATE_ID = C.CATE_ID \n");
			sql.append(" #if($modelCode) \n");
			sql.append(" AND M.MODEL_CODE= :modelCode \n");
			sql.append(" #end \n");
			sql.append(" #if($comCode) \n");
			sql.append(" AND CD.COM_CODE= :comCode \n");
			sql.append(" #end \n");
			// 추가 부분 TEST
			sql.append(" #if($startDay) \n");
			sql.append(" AND M.REG_DT >= :startDay \n");
			sql.append(" #end \n");
			sql.append(" #if($endDay) \n");
			sql.append(" AND M.REG_DT <= :endDay \n");
			sql.append(" #end \n");
			// 추가 부분 TEST END
			sql.append(" #if($statusCode) \n");
			sql.append(" AND M.STATUS_CODE= :statusCode \n");
			sql.append(" #end \n");
			sql.append(" ORDER BY R.LBL_ID ASC \n");
		sql.append(" /* com.samsung.gmes2.mc.mcu611m00.ListModelCodeInfo_DQM.dListModelCodeInfo.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "modelCode", "comCode", "startDay" ,"endDay", "statusCode"});
			if (inputSize > 0) {
				if (inputMap.get("modelCode") != null && !"".equals(inputMap.get("modelCode"))) {	
					data.put("modelCode", inputMap.get("modelCode"));
				}
				if (inputMap.get("comCode") != null && !"".equals(inputMap.get("comCode"))) {	
					data.put("comCode", inputMap.get("comCode"));
				}
				// 추가 부분
				if (inputMap.get("startDay") != null && !"".equals(inputMap.get("startDay"))) {	
					data.put("startDay", inputMap.get("startDay"));
				}
				if (inputMap.get("endDay") != null && !"".equals(inputMap.get("endDay"))) {	
					data.put("endDay", inputMap.get("endDay"));
				}
				// 추가 부분 끝
				if (inputMap.get("statusCode") != null && !"".equals(inputMap.get("statusCode"))) {	
					data.put("statusCode", inputMap.get("statusCode"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									McU611M0008DVO returnMCU611M00DVO = new McU611M0008DVO();
									returnMCU611M00DVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnMCU611M00DVO.setLabelName(resultSet.getString("LABEL_NAME"));
									returnMCU611M00DVO.setLblVer(resultSet.getBigDecimal("LBL_VER"));
									returnMCU611M00DVO.setLblTypeCode(resultSet.getString("LBL_TYPE_CODE"));
									returnMCU611M00DVO.setPviewImgFile(resultSet.getString("PVIEW_IMG_FILE"));
									returnMCU611M00DVO.setStatusCode(resultSet.getString("STATUS_CODE"));
									returnMCU611M00DVO.setReger(resultSet.getString("REGER"));
									returnMCU611M00DVO.setRegDt(resultSet.getString("REG_DT"));
									returnMCU611M00DVO.setCfmerId(resultSet.getString("CFMER_ID"));
									returnMCU611M00DVO.setCfmDt(resultSet.getString("CFM_DT"));
									returnMCU611M00DVO.setLabelId(resultSet.getString("LABEL_ID"));
									return returnMCU611M00DVO;
					    	}
					    	
					   }
 		);
	}
	
	// 붙여넣기
	
	public List dListAllLabelInfo (final Map inputMap) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" select  \n");
			sql.append(" 	r.lbl_id label_Id, r.lbl_nm label_Name, r.lbl_ver label_Ver, r.lbl_type_code label_Type_code \n");
			sql.append(" from tbm_mc_comm_cd cd , tbm_mc_lbl_reg r \n");
			sql.append(" where r.lbl_type_code=cd.com_code \n");
			sql.append(" and cate_id= :cateId \n");
			sql.append(" order by r.lbl_id asc \n");
		sql.append(" /* com.samsung.gmes2.mc.mcu611p01.LblRegInfoList_DQM.dListRegInfo.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "cateId"});
			if (inputSize > 0) {
				if (inputMap.get("cateId") != null && !"".equals(inputMap.get("cateId"))) {	
					data.put("cateId", inputMap.get("cateId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									McU611M0005DVO returnMcInq001DVO = new McU611M0005DVO();
									returnMcInq001DVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnMcInq001DVO.setLabelName(resultSet.getString("LABEL_NAME"));
									returnMcInq001DVO.setLabelVer(resultSet.getBigDecimal("LABEL_VER"));
									returnMcInq001DVO.setLabelTypeCode(resultSet.getString("LABEL_TYPE_CODE"));
									return returnMcInq001DVO;
					    	}
					    	
					   }
 		);
	}


	/**
	*
	* select 
	* 	r.lbl_id label_Id , 
	* 	r.lbl_nm label_Name , 
	* 	r.lbl_ver label_Ver , 
	* 	r.lbl_type_code label_Type_code ,
	* 	m.model_code
	* from tbm_mc_comm_cd cd , tbm_mc_lbl_reg r, tbm_mc_lbl_reg_model m
	* where r.lbl_type_code=cd.com_code
	* and m.label_Id=r.lbl_id
	* and cate_id= :cateId
	* #if($modelCode)
	* and m.model_code= :modelCode
	* #end
	* order by m.label_id asc
	* 
	* @ref_table 
	* @return List
	*
	*/
		public List dListModelCodeInfo (final Map inputMap) {

	     	StringBuffer sql = new StringBuffer();

				sql.append(" select  \n");
				sql.append(" 	r.lbl_id label_Id ,  \n");
				sql.append(" 	r.lbl_nm label_Name ,  \n");
				sql.append(" 	r.lbl_ver label_Ver ,  \n");
				sql.append(" 	r.lbl_type_code label_Type_code , \n");
				sql.append(" 	m.model_code \n");
				sql.append(" from tbm_mc_comm_cd cd , tbm_mc_lbl_reg r, tbm_mc_lbl_reg_model m \n");
				sql.append(" where r.lbl_type_code=cd.com_code \n");
				sql.append(" and m.label_Id=r.lbl_id \n");
				sql.append(" and cate_id= :cateId \n");
				sql.append(" #if($modelCode) \n");
				sql.append(" and m.model_code= :modelCode \n");
				sql.append(" #end \n");
				sql.append(" order by m.label_id asc \n");
			sql.append(" /* com.samsung.gmes2.mc.mcu.ModelCodeInfoListDQM.dListModelCodeInfo.001 */ \n");

			Properties  data =  new Properties();
			if ( inputMap != null) {
				int inputSize = countMap(inputMap , new String[] { "modelCode", "cateId"});
				if (inputSize > 0) {
					if (inputMap.get("modelCode") != null && !"".equals(inputMap.get("modelCode"))) {	
						data.put("modelCode", inputMap.get("modelCode"));
					}
					if (inputMap.get("cateId") != null && !"".equals(inputMap.get("cateId"))) {	
						data.put("cateId", inputMap.get("cateId"));
					}
	 			}	
			}
			String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
			sql.setLength(0);
			sql.append(dynamicQuery);

			return query(sql.toString() , data ,
							new RowMapper() {
						    	public Object mapRow(ResultSet resultSet, int row)
						    			throws SQLException {
						    			
										McU611M0006DVO returnMcInq002DVO = new McU611M0006DVO();
										returnMcInq002DVO.setLabelId(resultSet.getString("LABEL_ID"));
										returnMcInq002DVO.setLabelName(resultSet.getString("LABEL_NAME"));
										returnMcInq002DVO.setLabelVer(resultSet.getBigDecimal("LABEL_VER"));
										returnMcInq002DVO.setLabelTypeCode(resultSet.getString("LABEL_TYPE_CODE"));
										returnMcInq002DVO.setModelCode(resultSet.getString("MODEL_CODE"));
										return returnMcInq002DVO;
						    	}
						    	
						   }
	 		);
		}


}