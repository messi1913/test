package com.samsung.gmes2.md.material.biz;

public class MdManageProdUnitIdBiz {

	/**
	 * 제품별 UNIT ID 목록 조회
	 */
	public void listProdUnitId(){}

	/**
	 * 제품별 UNIT ID 목록 저장
	 */
	public void saveProdUnitId(){}

}
