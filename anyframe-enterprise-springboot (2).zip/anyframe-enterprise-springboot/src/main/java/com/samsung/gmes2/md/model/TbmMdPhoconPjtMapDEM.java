package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPhoconPjtMapDEM extends AbstractDAO {


/**
* insertTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return int
*/
	@LocalName("insertTbmMdPhoconPjtMap")
	public int insertTbmMdPhoconPjtMap (final TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.insertTbmMdPhoconPjtMap.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT_MAP (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        N2_PJT_GRP_NM , \n");
			sql.append("        GSCM_TYPE_CODE , \n");
			sql.append("        PJT_MAPP_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getGscmTypeCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPjtMappYn());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPhoconPjtMap Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPhoconPjtMap Method")
	public int[][] updateBatchAllTbmMdPhoconPjtMap (final List  tbmMdPhoconPjtMapDVOList) {
		
		ArrayList updatetbmMdPhoconPjtMapDVOList = new ArrayList();
		ArrayList insertttbmMdPhoconPjtMapDVOList = new ArrayList();
		ArrayList deletetbmMdPhoconPjtMapDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPhoconPjtMapDVOList.size() ; i++) {
		  TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO = (TbmMdPhoconPjtMapDVO) tbmMdPhoconPjtMapDVOList.get(i);
		  
		  if (tbmMdPhoconPjtMapDVO.getSqlAction().equals("C"))
		      insertttbmMdPhoconPjtMapDVOList.add(tbmMdPhoconPjtMapDVO);
		  else if (tbmMdPhoconPjtMapDVO.getSqlAction().equals("U"))
		      updatetbmMdPhoconPjtMapDVOList.add(tbmMdPhoconPjtMapDVO);
		  else if (tbmMdPhoconPjtMapDVO.getSqlAction().equals("D"))
		      deletetbmMdPhoconPjtMapDVOList.add(tbmMdPhoconPjtMapDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPhoconPjtMapDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPhoconPjtMap(insertttbmMdPhoconPjtMapDVOList);
          
      if (updatetbmMdPhoconPjtMapDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPhoconPjtMap(updatetbmMdPhoconPjtMapDVOList);
      
      if (deletetbmMdPhoconPjtMapDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPhoconPjtMap(deletetbmMdPhoconPjtMapDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return int
*/
	@LocalName("updateTbmMdPhoconPjtMap")
	public int updateTbmMdPhoconPjtMap (final TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.updateTbmMdPhoconPjtMap.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT_MAP \n");
			sql.append(" SET   \n");
			sql.append("        GSCM_TYPE_CODE = ? , \n");
			sql.append("        PJT_MAPP_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND N2_PJT_GRP_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getGscmTypeCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPjtMappYn());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
						}
					}
		);			
	}

/**
* deleteTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return int
*/
	@LocalName("deleteTbmMdPhoconPjtMap")
	public int deleteTbmMdPhoconPjtMap (final TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.deleteTbmMdPhoconPjtMap.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT_MAP \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND N2_PJT_GRP_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
						}
					}
		);			
	}

/**
* selectTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return TbmMdPhoconPjtMapDVO 
*/
	@LocalName("selectTbmMdPhoconPjtMap")
	public TbmMdPhoconPjtMapDVO selectTbmMdPhoconPjtMap (final TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.selectTbmMdPhoconPjtMap.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        N2_PJT_GRP_NM , \n");
			sql.append("        GSCM_TYPE_CODE , \n");
			sql.append("        PJT_MAPP_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PHOCON_PJT_MAP \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND N2_PJT_GRP_NM = ? \n");

		return (TbmMdPhoconPjtMapDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPhoconPjtMapDVO returnTbmMdPhoconPjtMapDVO = new TbmMdPhoconPjtMapDVO();
									returnTbmMdPhoconPjtMapDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPhoconPjtMapDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdPhoconPjtMapDVO.setN2PjtGrpNm(resultSet.getString("N2_PJT_GRP_NM"));
									returnTbmMdPhoconPjtMapDVO.setGscmTypeCode(resultSet.getString("GSCM_TYPE_CODE"));
									returnTbmMdPhoconPjtMapDVO.setPjtMappYn(resultSet.getString("PJT_MAPP_YN"));
									returnTbmMdPhoconPjtMapDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPhoconPjtMapDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPhoconPjtMapDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPhoconPjtMapDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPhoconPjtMapDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPhoconPjtMap Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPhoconPjtMap Method")
	public int mergeTbmMdPhoconPjtMap (final TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO) {
		
		if ( selectTbmMdPhoconPjtMap (tbmMdPhoconPjtMapDVO) == null) {
			return insertTbmMdPhoconPjtMap(tbmMdPhoconPjtMapDVO);
		} else {
			return selectUpdateTbmMdPhoconPjtMap (tbmMdPhoconPjtMapDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPhoconPjtMap Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPhoconPjtMap Method")
	public int selectUpdateTbmMdPhoconPjtMap (final TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO) {
		
		TbmMdPhoconPjtMapDVO tmpTbmMdPhoconPjtMapDVO =  selectTbmMdPhoconPjtMap (tbmMdPhoconPjtMapDVO);
		if ( tbmMdPhoconPjtMapDVO.getPlantCode() != null && !"".equals(tbmMdPhoconPjtMapDVO.getPlantCode()) ) {
			tmpTbmMdPhoconPjtMapDVO.setPlantCode(tbmMdPhoconPjtMapDVO.getPlantCode());
		}		
		if ( tbmMdPhoconPjtMapDVO.getModelCode() != null && !"".equals(tbmMdPhoconPjtMapDVO.getModelCode()) ) {
			tmpTbmMdPhoconPjtMapDVO.setModelCode(tbmMdPhoconPjtMapDVO.getModelCode());
		}		
		if ( tbmMdPhoconPjtMapDVO.getN2PjtGrpNm() != null && !"".equals(tbmMdPhoconPjtMapDVO.getN2PjtGrpNm()) ) {
			tmpTbmMdPhoconPjtMapDVO.setN2PjtGrpNm(tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
		}		
		if ( tbmMdPhoconPjtMapDVO.getGscmTypeCode() != null && !"".equals(tbmMdPhoconPjtMapDVO.getGscmTypeCode()) ) {
			tmpTbmMdPhoconPjtMapDVO.setGscmTypeCode(tbmMdPhoconPjtMapDVO.getGscmTypeCode());
		}		
		if ( tbmMdPhoconPjtMapDVO.getPjtMappYn() != null && !"".equals(tbmMdPhoconPjtMapDVO.getPjtMappYn()) ) {
			tmpTbmMdPhoconPjtMapDVO.setPjtMappYn(tbmMdPhoconPjtMapDVO.getPjtMappYn());
		}		
		if ( tbmMdPhoconPjtMapDVO.getFstRegDt() != null && !"".equals(tbmMdPhoconPjtMapDVO.getFstRegDt()) ) {
			tmpTbmMdPhoconPjtMapDVO.setFstRegDt(tbmMdPhoconPjtMapDVO.getFstRegDt());
		}		
		if ( tbmMdPhoconPjtMapDVO.getFstRegerId() != null && !"".equals(tbmMdPhoconPjtMapDVO.getFstRegerId()) ) {
			tmpTbmMdPhoconPjtMapDVO.setFstRegerId(tbmMdPhoconPjtMapDVO.getFstRegerId());
		}		
		if ( tbmMdPhoconPjtMapDVO.getFnlUpdDt() != null && !"".equals(tbmMdPhoconPjtMapDVO.getFnlUpdDt()) ) {
			tmpTbmMdPhoconPjtMapDVO.setFnlUpdDt(tbmMdPhoconPjtMapDVO.getFnlUpdDt());
		}		
		if ( tbmMdPhoconPjtMapDVO.getFnlUpderId() != null && !"".equals(tbmMdPhoconPjtMapDVO.getFnlUpderId()) ) {
			tmpTbmMdPhoconPjtMapDVO.setFnlUpderId(tbmMdPhoconPjtMapDVO.getFnlUpderId());
		}		
		return updateTbmMdPhoconPjtMap (tmpTbmMdPhoconPjtMapDVO);
	}

/**
* insertBatchTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return int[]
*/
	@LocalName("insertBatchTbmMdPhoconPjtMap")
	public int[] insertBatchTbmMdPhoconPjtMap (final List tbmMdPhoconPjtMapDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.insertBatchTbmMdPhoconPjtMap.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT_MAP (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        N2_PJT_GRP_NM , \n");
			sql.append("        GSCM_TYPE_CODE , \n");
			sql.append("        PJT_MAPP_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO = (TbmMdPhoconPjtMapDVO)tbmMdPhoconPjtMapDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getGscmTypeCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPjtMappYn());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPhoconPjtMapDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return int[]
*/
	@LocalName("updateBatchTbmMdPhoconPjtMap")
	public int[] updateBatchTbmMdPhoconPjtMap (final List tbmMdPhoconPjtMapDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.updateBatchTbmMdPhoconPjtMap.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT_MAP \n");
			sql.append(" SET   \n");
			sql.append("        GSCM_TYPE_CODE = ? , \n");
			sql.append("        PJT_MAPP_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND N2_PJT_GRP_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO = (TbmMdPhoconPjtMapDVO)tbmMdPhoconPjtMapDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getGscmTypeCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPjtMappYn());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
						}
							public int getBatchSize() {
									return tbmMdPhoconPjtMapDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPhoconPjtMap Method
* 
* @ref_table TBM_MD_PHOCON_PJT_MAP
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPhoconPjtMap")
	public int[] deleteBatchTbmMdPhoconPjtMap (final List tbmMdPhoconPjtMapDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPhoconPjtMapDEM.deleteBatchTbmMdPhoconPjtMap.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT_MAP \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND N2_PJT_GRP_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPhoconPjtMapDVO tbmMdPhoconPjtMapDVO = (TbmMdPhoconPjtMapDVO)tbmMdPhoconPjtMapDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getModelCode());
							ps.setString(psCount++, tbmMdPhoconPjtMapDVO.getN2PjtGrpNm());
						}
							public int getBatchSize() {
									return tbmMdPhoconPjtMapDVOList.size();
							}
					}
		);			
	}

	
}