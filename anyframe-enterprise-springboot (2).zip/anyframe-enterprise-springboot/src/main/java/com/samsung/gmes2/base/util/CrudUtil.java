package com.samsung.gmes2.base.util;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anyframe.core.vo.AbstractVo;
import com.anyframe.online.runtime.jdbc.AbstractDAO;
import com.samsung.gmes2.base.vo.DVO;
import com.samsung.gmes2.exception.Gmes2BugException;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.exception.Property;

public class CrudUtil
{
	private static Logger	logger	= LoggerFactory.getLogger( CrudUtil.class );

	@SuppressWarnings("unchecked")
	private static <D extends AbstractDAO, T extends AbstractVo> D getDEM( T voClass ) throws Exception
	{
		return (D) getDEM( voClass.getClass( ) );
	}

	@SuppressWarnings("unchecked")
	private static <D extends AbstractDAO, T extends AbstractVo> D getDEM( Class<T> voClass ) throws Exception
	{
		loadDao( voClass );
		return (D) BaseUtil.getBean( demClassMap.get( voClass ) );
	}

	@SuppressWarnings("unchecked")
	private static <D extends AbstractDAO, T extends AbstractVo> D getDQM( Class<T> voClass ) throws Exception
	{
		loadDao( voClass );
		return (D) BaseUtil.getBean( dqmClassMap.get( voClass ) );
	}

	private static <T extends AbstractVo> DaoMeta getDaoMeta( T voClass ) throws Exception
	{
		return getDaoMeta( voClass.getClass( ) );
	}

	private static <T extends AbstractVo> DaoMeta getDaoMeta( Class<T> voClass ) throws Exception
	{
		loadDao( voClass );
		return daoMetaMap.get( voClass );
	}

	private static Map<Class<? extends AbstractVo>, Class<? extends AbstractDAO>>	demClassMap	= Collections.synchronizedMap( new HashMap<Class<? extends AbstractVo>, Class<? extends AbstractDAO>>( ) );

	private static Map<Class<? extends AbstractVo>, Class<? extends AbstractDAO>>	dqmClassMap	= Collections.synchronizedMap( new HashMap<Class<? extends AbstractVo>, Class<? extends AbstractDAO>>( ) );

	private static Map<Class<? extends AbstractVo>, DaoMeta>						daoMetaMap	= Collections.synchronizedMap( new HashMap<Class<? extends AbstractVo>, DaoMeta>( ) );

	@SuppressWarnings("unchecked")
	private static <T extends AbstractVo, D extends AbstractDAO> void loadDao( Class<T> voClass ) throws Exception
	{
		if ( demClassMap.containsKey( voClass ) )
			return;

		String prefix = voClass.getName( ).substring( 0, voClass.getName( ).length( ) - 3 );
		String demName = new StringBuffer( prefix ).append( "DEM" ).toString( );
		synchronized (MonitorUtil.get( demName ))
		{
			try
			{
				if ( demClassMap.containsKey( voClass ) )
					return;

				if ( logger.isDebugEnabled( ) )
					logger.debug( new StringBuffer( "DAO loading: " ).append( voClass.getName( ) ).toString( ) );

				String objName = voClass.getSimpleName( ).substring( 0, voClass.getSimpleName( ).length( ) - 3 );
				Class<D> demClass = null;
				Class<D> dqmClass = null;
				DaoMeta daoMeta = null;
				try
				{
					demClass = (Class<D>) Class.forName( demName );
					try
					{
						String dqmName = new StringBuffer( prefix ).append( "DQM" ).toString( );
						dqmClass = (Class<D>) Class.forName( dqmName );
					}
					catch ( Exception e )
					{
						String _dqmName = new StringBuffer( prefix ).append( "_DQM" ).toString( );
						dqmClass = (Class<D>) Class.forName( _dqmName );
					}
					daoMeta = new DaoMeta( );
					daoMeta.setInsertMethod( demClass.getMethod( "insert" + objName, voClass ) );
					daoMeta.setSelectMethod( demClass.getMethod( "select" + objName, voClass ) );
					daoMeta.setListPage000Method( dqmClass.getMethod( "dListPage000", Map.class, int.class, int.class ) );
					daoMeta.setListPage001Method( dqmClass.getMethod( "dListPage001", Map.class, int.class, int.class ) );
					daoMeta.setUpdateMethod( demClass.getMethod( "update" + objName, voClass ) );
					daoMeta.setDeleteMethod( demClass.getMethod( "delete" + objName, voClass ) );
				}
				finally
				{
					daoMetaMap.put( voClass, daoMeta );
					dqmClassMap.put( voClass, dqmClass );
					demClassMap.put( voClass, demClass );
				}
			}
			finally
			{
				MonitorUtil.expire( demName );
			}
		}

		if ( logger.isDebugEnabled( ) )
			logger.debug( new StringBuffer( "DAO loaded: " ).append( voClass.getName( ) ).toString( ) );
	}

	public static <T extends AbstractVo> T create( T obj ) throws Exception
	{
		if ( obj == null )
			throw new Gmes2BugException( "obj is null." );
		BaseUtil.checkNotEmpty( obj );
		checkPkNotEmpty( obj );
		checkNotFound( obj );
		getDaoMeta( obj ).getDeleteMethod( ).invoke( getDEM( obj ), obj );
		getDaoMeta( obj ).getInsertMethod( ).invoke( getDEM( obj ), obj );
		return obj;
	}

	public static <T extends AbstractVo> T get( T condition ) throws Exception
	{
		return get( condition, false );
	}

	@SuppressWarnings("unchecked")
	public static <T extends AbstractVo> T get( T condition, boolean checkNotFound ) throws Exception
	{
		if ( condition == null )
			throw new Gmes2BugException( "condition is null." );
		List<String> pk = ReflectionUtil.getPKFieldNameList( condition );
		Map<String, Object> condMap = BaseUtil.toMap( condition );

		boolean select = false;
		if ( !BaseUtil.isEmpty( pk ) && pk.size( ) <= condMap.size( ) )
		{
			select = true;
			for ( String k : pk )
			{
				if ( condMap.containsKey( k ) )
					continue;
				select = false;
				break;
			}
		}

		if ( select )
		{
			T obj = (T) getDaoMeta( condition ).getSelectMethod( ).invoke( getDEM( condition ), condition );
			if ( isUsable( obj ) )
				return obj;
			if ( checkNotFound )
				throw new Gmes2LogicException( Gmes2LogicException.CODE_NOTFOUND, condition.getClass( ).getSimpleName( ) + " not found.", toConditionPropertyList( condition ) );
			return null;
		}
		else
		{
			appendUsableCondition( condition );
			List<T> list = (List<T>) list( condition.getClass( ), condMap, 1, 2 );
			if ( list.isEmpty( ) )
			{
				if ( checkNotFound )
					throw new Gmes2LogicException( Gmes2LogicException.CODE_NOTFOUND, condition.getClass( ).getSimpleName( ) + " not found.", toConditionPropertyList( condition ) );
				return null;
			}
			else if ( list.size( ) > 1 )
			{
				throw new Gmes2LogicException( Gmes2LogicException.CODE_NOTUNIQUE, condition.getClass( ).getSimpleName( ) + " not unique.", toConditionPropertyList( condition ) );
			}
			T obj = list.get( 0 );
			return obj;
		}

	}

	private static <T extends AbstractVo> boolean isUsable( T obj )
	{
		return !( obj == null || BaseUtil.isEqual( ReflectionUtil.getAnyFieldValue( obj, DVO.FIELD_USEYN ), "N" ) || BaseUtil.isEqual( ReflectionUtil.getAnyFieldValue( obj, DVO.FIELD_DELYN ), "Y" ) );
	}

	private static void appendUsableCondition( Object condition )
	{
		if ( condition instanceof Map )
		{
			@SuppressWarnings("unchecked")
			Map<String, Object> map = (Map<String, Object>) condition;
			map.put( DVO.FIELD_USEYN, "Y" );
			map.put( DVO.FIELD_DELYN, "N" );
		}
		else if ( condition instanceof AbstractVo )
		{
			AbstractVo vo = (AbstractVo) condition;
			Map<String, Integer> namedMap = vo.getProxy( ).getVoMeta( ).getNamedMap( );
			if ( namedMap.containsKey( DVO.FIELD_USEYN ) )
				vo.setValue( DVO.FIELD_USEYN, "Y" );
			if ( namedMap.containsKey( DVO.FIELD_DELYN ) )
				vo.setValue( DVO.FIELD_DELYN, "N" );
		}
	}

	public static <T extends AbstractVo> List<T> list( Class<T> clazz, T condition, int pageIndex, int pageSize ) throws Exception
	{
		return list( clazz, BaseUtil.toMap( condition ), pageIndex, pageSize );
	}

	public static <T extends AbstractVo> List<T> list( Class<T> clazz, Map<String, Object> condition, int pageIndex, int pageSize ) throws Exception
	{
		if ( clazz == null )
			throw new Gmes2BugException( "clazz is null." );
		if ( condition == null )
			condition = new HashMap<String, Object>( );
		appendUsableCondition( condition );
		@SuppressWarnings("unchecked")
		List<T> list = (List<T>) getDaoMeta( clazz ).getListPage001Method( ).invoke( getDQM( clazz ), condition, pageIndex, pageSize );
		return list;
	}

	public static <T extends AbstractVo> List<T> list0( Class<T> clazz, T condition, int pageIndex, int pageSize ) throws Exception
	{
		return list0( clazz, BaseUtil.toMap( condition ), pageIndex, pageSize );
	}

	public static <T extends AbstractVo> List<T> list0( Class<T> clazz, Map<String, Object> condition, int pageIndex, int pageSize ) throws Exception
	{
		if ( clazz == null )
			throw new Gmes2BugException( "clazz is null." );
		appendUsableCondition( condition );
		@SuppressWarnings("unchecked")
		List<T> list = (List<T>) getDaoMeta( clazz ).getListPage000Method( ).invoke( getDQM( clazz ), condition, pageIndex, pageSize );
		return list;
	}

	public static <T extends AbstractVo> T update( T obj ) throws Exception
	{
		if ( obj == null )
			throw new Gmes2BugException( "obj is null." );
		BaseUtil.checkNotEmpty( obj );
		checkPkNotEmpty( obj );
		checkFound( obj );
		getDaoMeta( obj ).getUpdateMethod( ).invoke( getDEM( obj ), obj );
		return obj;
	}

	public static <T extends AbstractVo> T delete( T obj ) throws Exception
	{
		if ( obj == null )
			throw new Gmes2BugException( "obj is null." );
		// TODO T delete(T obj)
		obj = get( obj, true );
		Map<String, Integer> namedMap = obj.getProxy( ).getVoMeta( ).getNamedMap( );
		if ( namedMap.containsKey( DVO.FIELD_USEYN ) )
		{
			obj.setValue( namedMap.get( DVO.FIELD_USEYN ), "N" );
			getDaoMeta( obj ).getUpdateMethod( ).invoke( getDEM( obj ), obj );
			return obj;
		}
		if ( namedMap.containsKey( DVO.FIELD_DELYN ) )
		{
			obj.setValue( namedMap.get( DVO.FIELD_DELYN ), "Y" );
			getDaoMeta( obj ).getUpdateMethod( ).invoke( getDEM( obj ), obj );
			return obj;
		}
		getDaoMeta( obj ).getDeleteMethod( ).invoke( getDEM( obj ), obj );
		return obj;
	}

	private static <T extends AbstractVo> void checkPkNotEmpty( T obj ) throws Exception
	{
		BaseUtil.checkNotEmpty( obj, ReflectionUtil.getPKFieldNameArray( obj ) );
	}

	public static <T extends AbstractVo> boolean isFound( T condition ) throws Exception
	{
		return isUsable( get( condition ) );
	}

	public static <T extends AbstractVo> boolean isNotFound( T condition ) throws Exception
	{
		return !isFound( condition );
	}

	public static <T extends AbstractVo> void checkFound( T condition ) throws Exception
	{
		if ( isNotFound( condition ) )
			throw new Gmes2LogicException( Gmes2LogicException.CODE_NOTFOUND, condition.getClass( ).getSimpleName( ) + " not found.", toConditionPropertyList( condition ) );
	}

	public static <T extends AbstractVo> void checkNotFound( T condition ) throws Exception
	{
		if ( isFound( condition ) )
			throw new Gmes2LogicException( Gmes2LogicException.CODE_FOUND, condition.getClass( ).getSimpleName( ) + " duplicated.", toConditionPropertyList( condition ) );
	}

	private static <T extends AbstractVo> Property[ ] toConditionPropertyList( T condition )
	{
		List<Property> propList = new ArrayList<Property>( );
		// TODO Property[] toConditionPropertyList(T condition)
		Property[ ] props = new Property[ propList.size( ) ];
		return propList.toArray( props );
	}

	/**
	 * @param <T>
	 * @param clazz
	 * @param condition
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 * @throws Exception
	 * @deprecated list 로 대체
	 */
	@Deprecated
	public static <T extends AbstractVo> List<T> search( Class<T> clazz, T condition, int pageIndex, int pageSize ) throws Exception
	{
		return list( clazz, condition, pageIndex, pageSize );
	}
}

class DaoMeta
{
	private Method	insertMethod;

	private Method	selectMethod;

	private Method	listPage000Method;

	private Method	listPage001Method;

	private Method	updateMethod;

	private Method	deleteMethod;

	public Method getInsertMethod( )
	{
		return insertMethod;
	}

	public void setInsertMethod( Method insert )
	{
		this.insertMethod = insert;
	}

	public Method getSelectMethod( )
	{
		return selectMethod;
	}

	public void setSelectMethod( Method selectMethod )
	{
		this.selectMethod = selectMethod;
	}

	public Method getListPage000Method( )
	{
		return listPage000Method;
	}

	public void setListPage000Method( Method listPage000 )
	{
		this.listPage000Method = listPage000;
	}

	public Method getListPage001Method( )
	{
		return listPage001Method;
	}

	public void setListPage001Method( Method listPage001 )
	{
		this.listPage001Method = listPage001;
	}

	public Method getUpdateMethod( )
	{
		return updateMethod;
	}

	public void setUpdateMethod( Method update )
	{
		this.updateMethod = update;
	}

	public Method getDeleteMethod( )
	{
		return deleteMethod;
	}

	public void setDeleteMethod( Method delete )
	{
		this.deleteMethod = delete;
	}
}
