package com.samsung.gmes2.md.logi.app;

public class MDU824M01App {

	/**
	 * Bin 운영정보 목록 초기설정
	 */
	public void initBinOpInfo(){}

	/**
	 * Bin운영정보 목록 조회
	 */
	public void listBinOpInfo(){}

	/**
	 * Bin운영정보 목록 엑셀 다운로드
	 */
	public void excelBinOpInfo(){}

	/**
	 * Bin운영정보 목록 등록/수정 초기설정
	 */
	public void editBinOpInfo(){}

	/**
	 * Bin운영정보 목록 저장
	 */
	public void saveBinOpInfo(){}

}
