package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_UNITID
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelUnitidDEM extends AbstractDAO {


/**
* insertTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return int
*/
	@LocalName("insertTbmMdModelUnitid")
	public int insertTbmMdModelUnitid (final TbmMdModelUnitidDVO tbmMdModelUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.insertTbmMdModelUnitid.001*/  \n");
			sql.append(" TBM_MD_MODEL_UNITID (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        UNITID , \n");
			sql.append("        BOM_VER , \n");
			sql.append("        NEED_QTY , \n");
			sql.append("        IF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
							ps.setBigDecimal(psCount++, tbmMdModelUnitidDVO.getNeedQty());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelUnitid Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelUnitid Method")
	public int[][] updateBatchAllTbmMdModelUnitid (final List  tbmMdModelUnitidDVOList) {
		
		ArrayList updatetbmMdModelUnitidDVOList = new ArrayList();
		ArrayList insertttbmMdModelUnitidDVOList = new ArrayList();
		ArrayList deletetbmMdModelUnitidDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelUnitidDVOList.size() ; i++) {
		  TbmMdModelUnitidDVO tbmMdModelUnitidDVO = (TbmMdModelUnitidDVO) tbmMdModelUnitidDVOList.get(i);
		  
		  if (tbmMdModelUnitidDVO.getSqlAction().equals("C"))
		      insertttbmMdModelUnitidDVOList.add(tbmMdModelUnitidDVO);
		  else if (tbmMdModelUnitidDVO.getSqlAction().equals("U"))
		      updatetbmMdModelUnitidDVOList.add(tbmMdModelUnitidDVO);
		  else if (tbmMdModelUnitidDVO.getSqlAction().equals("D"))
		      deletetbmMdModelUnitidDVOList.add(tbmMdModelUnitidDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelUnitidDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelUnitid(insertttbmMdModelUnitidDVOList);
          
      if (updatetbmMdModelUnitidDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelUnitid(updatetbmMdModelUnitidDVOList);
      
      if (deletetbmMdModelUnitidDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelUnitid(deletetbmMdModelUnitidDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return int
*/
	@LocalName("updateTbmMdModelUnitid")
	public int updateTbmMdModelUnitid (final TbmMdModelUnitidDVO tbmMdModelUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.updateTbmMdModelUnitid.001*/  \n");
			sql.append(" TBM_MD_MODEL_UNITID \n");
			sql.append(" SET   \n");
			sql.append("        NEED_QTY = ? , \n");
			sql.append("        IF_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");
			sql.append("   AND UNITID = ? \n");
			sql.append("   AND BOM_VER = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdModelUnitidDVO.getNeedQty());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
						}
					}
		);			
	}

/**
* deleteTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return int
*/
	@LocalName("deleteTbmMdModelUnitid")
	public int deleteTbmMdModelUnitid (final TbmMdModelUnitidDVO tbmMdModelUnitidDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.deleteTbmMdModelUnitid.001*/  \n");
			sql.append(" TBM_MD_MODEL_UNITID \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");
			sql.append("    AND UNITID = ? \n");
			sql.append("    AND BOM_VER = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
						}
					}
		);			
	}

/**
* selectTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return TbmMdModelUnitidDVO 
*/
	@LocalName("selectTbmMdModelUnitid")
	public TbmMdModelUnitidDVO selectTbmMdModelUnitid (final TbmMdModelUnitidDVO tbmMdModelUnitidDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.selectTbmMdModelUnitid.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        UNITID , \n");
			sql.append("        BOM_VER , \n");
			sql.append("        NEED_QTY , \n");
			sql.append("        IF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_UNITID \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");
			sql.append("    AND UNITID = ? \n");
			sql.append("    AND BOM_VER = ? \n");

		return (TbmMdModelUnitidDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelUnitidDVO returnTbmMdModelUnitidDVO = new TbmMdModelUnitidDVO();
									returnTbmMdModelUnitidDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelUnitidDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdModelUnitidDVO.setUnitid(resultSet.getString("UNITID"));
									returnTbmMdModelUnitidDVO.setBomVer(resultSet.getString("BOM_VER"));
									returnTbmMdModelUnitidDVO.setNeedQty(resultSet.getBigDecimal("NEED_QTY"));
									returnTbmMdModelUnitidDVO.setIfYn(resultSet.getString("IF_YN"));
									returnTbmMdModelUnitidDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdModelUnitidDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelUnitidDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelUnitidDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelUnitidDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelUnitidDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelUnitid Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelUnitid Method")
	public int mergeTbmMdModelUnitid (final TbmMdModelUnitidDVO tbmMdModelUnitidDVO) {
		
		if ( selectTbmMdModelUnitid (tbmMdModelUnitidDVO) == null) {
			return insertTbmMdModelUnitid(tbmMdModelUnitidDVO);
		} else {
			return selectUpdateTbmMdModelUnitid (tbmMdModelUnitidDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelUnitid Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelUnitid Method")
	public int selectUpdateTbmMdModelUnitid (final TbmMdModelUnitidDVO tbmMdModelUnitidDVO) {
		
		TbmMdModelUnitidDVO tmpTbmMdModelUnitidDVO =  selectTbmMdModelUnitid (tbmMdModelUnitidDVO);
		if ( tbmMdModelUnitidDVO.getModelCode() != null && !"".equals(tbmMdModelUnitidDVO.getModelCode()) ) {
			tmpTbmMdModelUnitidDVO.setModelCode(tbmMdModelUnitidDVO.getModelCode());
		}		
		if ( tbmMdModelUnitidDVO.getMatrCode() != null && !"".equals(tbmMdModelUnitidDVO.getMatrCode()) ) {
			tmpTbmMdModelUnitidDVO.setMatrCode(tbmMdModelUnitidDVO.getMatrCode());
		}		
		if ( tbmMdModelUnitidDVO.getUnitid() != null && !"".equals(tbmMdModelUnitidDVO.getUnitid()) ) {
			tmpTbmMdModelUnitidDVO.setUnitid(tbmMdModelUnitidDVO.getUnitid());
		}		
		if ( tbmMdModelUnitidDVO.getBomVer() != null && !"".equals(tbmMdModelUnitidDVO.getBomVer()) ) {
			tmpTbmMdModelUnitidDVO.setBomVer(tbmMdModelUnitidDVO.getBomVer());
		}		
		if ( tbmMdModelUnitidDVO.getNeedQty() != null && !"".equals(tbmMdModelUnitidDVO.getNeedQty()) ) {
			tmpTbmMdModelUnitidDVO.setNeedQty(tbmMdModelUnitidDVO.getNeedQty());
		}		
		if ( tbmMdModelUnitidDVO.getIfYn() != null && !"".equals(tbmMdModelUnitidDVO.getIfYn()) ) {
			tmpTbmMdModelUnitidDVO.setIfYn(tbmMdModelUnitidDVO.getIfYn());
		}		
		if ( tbmMdModelUnitidDVO.getUseYn() != null && !"".equals(tbmMdModelUnitidDVO.getUseYn()) ) {
			tmpTbmMdModelUnitidDVO.setUseYn(tbmMdModelUnitidDVO.getUseYn());
		}		
		if ( tbmMdModelUnitidDVO.getFstRegDt() != null && !"".equals(tbmMdModelUnitidDVO.getFstRegDt()) ) {
			tmpTbmMdModelUnitidDVO.setFstRegDt(tbmMdModelUnitidDVO.getFstRegDt());
		}		
		if ( tbmMdModelUnitidDVO.getFstRegerId() != null && !"".equals(tbmMdModelUnitidDVO.getFstRegerId()) ) {
			tmpTbmMdModelUnitidDVO.setFstRegerId(tbmMdModelUnitidDVO.getFstRegerId());
		}		
		if ( tbmMdModelUnitidDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelUnitidDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelUnitidDVO.setFnlUpdDt(tbmMdModelUnitidDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelUnitidDVO.getFnlUpderId() != null && !"".equals(tbmMdModelUnitidDVO.getFnlUpderId()) ) {
			tmpTbmMdModelUnitidDVO.setFnlUpderId(tbmMdModelUnitidDVO.getFnlUpderId());
		}		
		return updateTbmMdModelUnitid (tmpTbmMdModelUnitidDVO);
	}

/**
* insertBatchTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelUnitid")
	public int[] insertBatchTbmMdModelUnitid (final List tbmMdModelUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.insertBatchTbmMdModelUnitid.001*/  \n");
			sql.append(" TBM_MD_MODEL_UNITID (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        UNITID , \n");
			sql.append("        BOM_VER , \n");
			sql.append("        NEED_QTY , \n");
			sql.append("        IF_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelUnitidDVO tbmMdModelUnitidDVO = (TbmMdModelUnitidDVO)tbmMdModelUnitidDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
							ps.setBigDecimal(psCount++, tbmMdModelUnitidDVO.getNeedQty());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelUnitidDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelUnitid")
	public int[] updateBatchTbmMdModelUnitid (final List tbmMdModelUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.updateBatchTbmMdModelUnitid.001*/  \n");
			sql.append(" TBM_MD_MODEL_UNITID \n");
			sql.append(" SET   \n");
			sql.append("        NEED_QTY = ? , \n");
			sql.append("        IF_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");
			sql.append("   AND UNITID = ? \n");
			sql.append("   AND BOM_VER = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelUnitidDVO tbmMdModelUnitidDVO = (TbmMdModelUnitidDVO)tbmMdModelUnitidDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdModelUnitidDVO.getNeedQty());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getIfYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
						}
							public int getBatchSize() {
									return tbmMdModelUnitidDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelUnitid Method
* 
* @ref_table TBM_MD_MODEL_UNITID
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelUnitid")
	public int[] deleteBatchTbmMdModelUnitid (final List tbmMdModelUnitidDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelUnitidDEM.deleteBatchTbmMdModelUnitid.001*/  \n");
			sql.append(" TBM_MD_MODEL_UNITID \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");
			sql.append("    AND UNITID = ? \n");
			sql.append("    AND BOM_VER = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelUnitidDVO tbmMdModelUnitidDVO = (TbmMdModelUnitidDVO)tbmMdModelUnitidDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelUnitidDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getMatrCode());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getUnitid());
							ps.setString(psCount++, tbmMdModelUnitidDVO.getBomVer());
						}
							public int getBatchSize() {
									return tbmMdModelUnitidDVOList.size();
							}
					}
		);			
	}

	
}