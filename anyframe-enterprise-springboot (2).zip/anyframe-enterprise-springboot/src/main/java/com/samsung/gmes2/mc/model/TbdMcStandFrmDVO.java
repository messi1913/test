package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbdMcStandFrmDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String frmNo;

	@Length(50) @NotNull
	private String standFrmCode;

	@Length(11) @Scale(5) 
	private BigDecimal xValue;

	@Length(11) @Scale(5) 
	private BigDecimal yValue;

	@Length(11) @Scale(5) 
	private BigDecimal frmLeng;

	@Length(11) @Scale(5) 
	private BigDecimal frmHeit;


	public String getFrmNo() {
		this.frmNo = super.getValue("frmNo");
		return this.frmNo;
	}

	public void setFrmNo(String frmNo) {
        super.setValue("frmNo", frmNo);
		this.frmNo = frmNo;
	}
	
	public String getStandFrmCode() {
		this.standFrmCode = super.getValue("standFrmCode");
		return this.standFrmCode;
	}

	public void setStandFrmCode(String standFrmCode) {
        super.setValue("standFrmCode", standFrmCode);
		this.standFrmCode = standFrmCode;
	}
	
	public BigDecimal getxValue() {
		this.xValue = super.getValue("xValue");
		return this.xValue;
	}

	public void setxValue(BigDecimal xValue) {
        super.setValue("xValue", xValue);
		this.xValue = xValue;
	}
	
	public BigDecimal getyValue() {
		this.yValue = super.getValue("yValue");
		return this.yValue;
	}

	public void setyValue(BigDecimal yValue) {
        super.setValue("yValue", yValue);
		this.yValue = yValue;
	}
	
	public BigDecimal getFrmLeng() {
		this.frmLeng = super.getValue("frmLeng");
		return this.frmLeng;
	}

	public void setFrmLeng(BigDecimal frmLeng) {
        super.setValue("frmLeng", frmLeng);
		this.frmLeng = frmLeng;
	}
	
	public BigDecimal getFrmHeit() {
		this.frmHeit = super.getValue("frmHeit");
		return this.frmHeit;
	}

	public void setFrmHeit(BigDecimal frmHeit) {
        super.setValue("frmHeit", frmHeit);
		this.frmHeit = frmHeit;
	}
	
}