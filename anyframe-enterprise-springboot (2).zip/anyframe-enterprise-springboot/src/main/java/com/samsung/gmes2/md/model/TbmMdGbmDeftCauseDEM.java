package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdGbmDeftCauseDEM extends AbstractDAO {


/**
* insertTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return int
*/
	@LocalName("insertTbmMdGbmDeftCause")
	public int insertTbmMdGbmDeftCause (final TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.insertTbmMdGbmDeftCause.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_CAUSE (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        DEFT_CAUSE_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdGbmDeftCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdGbmDeftCause Method")
	public int[][] updateBatchAllTbmMdGbmDeftCause (final List  tbmMdGbmDeftCauseDVOList) {
		
		ArrayList updatetbmMdGbmDeftCauseDVOList = new ArrayList();
		ArrayList insertttbmMdGbmDeftCauseDVOList = new ArrayList();
		ArrayList deletetbmMdGbmDeftCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdGbmDeftCauseDVOList.size() ; i++) {
		  TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO = (TbmMdGbmDeftCauseDVO) tbmMdGbmDeftCauseDVOList.get(i);
		  
		  if (tbmMdGbmDeftCauseDVO.getSqlAction().equals("C"))
		      insertttbmMdGbmDeftCauseDVOList.add(tbmMdGbmDeftCauseDVO);
		  else if (tbmMdGbmDeftCauseDVO.getSqlAction().equals("U"))
		      updatetbmMdGbmDeftCauseDVOList.add(tbmMdGbmDeftCauseDVO);
		  else if (tbmMdGbmDeftCauseDVO.getSqlAction().equals("D"))
		      deletetbmMdGbmDeftCauseDVOList.add(tbmMdGbmDeftCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdGbmDeftCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdGbmDeftCause(insertttbmMdGbmDeftCauseDVOList);
          
      if (updatetbmMdGbmDeftCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdGbmDeftCause(updatetbmMdGbmDeftCauseDVOList);
      
      if (deletetbmMdGbmDeftCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdGbmDeftCause(deletetbmMdGbmDeftCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return int
*/
	@LocalName("updateTbmMdGbmDeftCause")
	public int updateTbmMdGbmDeftCause (final TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.updateTbmMdGbmDeftCause.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND DEFT_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
						}
					}
		);			
	}

/**
* deleteTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return int
*/
	@LocalName("deleteTbmMdGbmDeftCause")
	public int deleteTbmMdGbmDeftCause (final TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.deleteTbmMdGbmDeftCause.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_CAUSE \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND DEFT_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
						}
					}
		);			
	}

/**
* selectTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return TbmMdGbmDeftCauseDVO 
*/
	@LocalName("selectTbmMdGbmDeftCause")
	public TbmMdGbmDeftCauseDVO selectTbmMdGbmDeftCause (final TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.selectTbmMdGbmDeftCause.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        DEFT_CAUSE_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_GBM_DEFT_CAUSE \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND DEFT_CAUSE_CODE = ? \n");

		return (TbmMdGbmDeftCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdGbmDeftCauseDVO returnTbmMdGbmDeftCauseDVO = new TbmMdGbmDeftCauseDVO();
									returnTbmMdGbmDeftCauseDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdGbmDeftCauseDVO.setDeftCauseCode(resultSet.getString("DEFT_CAUSE_CODE"));
									returnTbmMdGbmDeftCauseDVO.setProcOutGubunCode(resultSet.getString("PROC_OUT_GUBUN_CODE"));
									returnTbmMdGbmDeftCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdGbmDeftCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdGbmDeftCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdGbmDeftCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdGbmDeftCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdGbmDeftCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdGbmDeftCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdGbmDeftCause Method")
	public int mergeTbmMdGbmDeftCause (final TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO) {
		
		if ( selectTbmMdGbmDeftCause (tbmMdGbmDeftCauseDVO) == null) {
			return insertTbmMdGbmDeftCause(tbmMdGbmDeftCauseDVO);
		} else {
			return selectUpdateTbmMdGbmDeftCause (tbmMdGbmDeftCauseDVO);
		}
	}

	/**
	 * selectUpdateTbmMdGbmDeftCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdGbmDeftCause Method")
	public int selectUpdateTbmMdGbmDeftCause (final TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO) {
		
		TbmMdGbmDeftCauseDVO tmpTbmMdGbmDeftCauseDVO =  selectTbmMdGbmDeftCause (tbmMdGbmDeftCauseDVO);
		if ( tbmMdGbmDeftCauseDVO.getGbmCode() != null && !"".equals(tbmMdGbmDeftCauseDVO.getGbmCode()) ) {
			tmpTbmMdGbmDeftCauseDVO.setGbmCode(tbmMdGbmDeftCauseDVO.getGbmCode());
		}		
		if ( tbmMdGbmDeftCauseDVO.getDeftCauseCode() != null && !"".equals(tbmMdGbmDeftCauseDVO.getDeftCauseCode()) ) {
			tmpTbmMdGbmDeftCauseDVO.setDeftCauseCode(tbmMdGbmDeftCauseDVO.getDeftCauseCode());
		}		
		if ( tbmMdGbmDeftCauseDVO.getProcOutGubunCode() != null && !"".equals(tbmMdGbmDeftCauseDVO.getProcOutGubunCode()) ) {
			tmpTbmMdGbmDeftCauseDVO.setProcOutGubunCode(tbmMdGbmDeftCauseDVO.getProcOutGubunCode());
		}		
		if ( tbmMdGbmDeftCauseDVO.getUseYn() != null && !"".equals(tbmMdGbmDeftCauseDVO.getUseYn()) ) {
			tmpTbmMdGbmDeftCauseDVO.setUseYn(tbmMdGbmDeftCauseDVO.getUseYn());
		}		
		if ( tbmMdGbmDeftCauseDVO.getFstRegDt() != null && !"".equals(tbmMdGbmDeftCauseDVO.getFstRegDt()) ) {
			tmpTbmMdGbmDeftCauseDVO.setFstRegDt(tbmMdGbmDeftCauseDVO.getFstRegDt());
		}		
		if ( tbmMdGbmDeftCauseDVO.getFstRegerId() != null && !"".equals(tbmMdGbmDeftCauseDVO.getFstRegerId()) ) {
			tmpTbmMdGbmDeftCauseDVO.setFstRegerId(tbmMdGbmDeftCauseDVO.getFstRegerId());
		}		
		if ( tbmMdGbmDeftCauseDVO.getFnlUpdDt() != null && !"".equals(tbmMdGbmDeftCauseDVO.getFnlUpdDt()) ) {
			tmpTbmMdGbmDeftCauseDVO.setFnlUpdDt(tbmMdGbmDeftCauseDVO.getFnlUpdDt());
		}		
		if ( tbmMdGbmDeftCauseDVO.getFnlUpderId() != null && !"".equals(tbmMdGbmDeftCauseDVO.getFnlUpderId()) ) {
			tmpTbmMdGbmDeftCauseDVO.setFnlUpderId(tbmMdGbmDeftCauseDVO.getFnlUpderId());
		}		
		return updateTbmMdGbmDeftCause (tmpTbmMdGbmDeftCauseDVO);
	}

/**
* insertBatchTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbmMdGbmDeftCause")
	public int[] insertBatchTbmMdGbmDeftCause (final List tbmMdGbmDeftCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.insertBatchTbmMdGbmDeftCause.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_CAUSE (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        DEFT_CAUSE_CODE , \n");
			sql.append("        PROC_OUT_GUBUN_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO = (TbmMdGbmDeftCauseDVO)tbmMdGbmDeftCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdGbmDeftCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbmMdGbmDeftCause")
	public int[] updateBatchTbmMdGbmDeftCause (final List tbmMdGbmDeftCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.updateBatchTbmMdGbmDeftCause.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        PROC_OUT_GUBUN_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND DEFT_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO = (TbmMdGbmDeftCauseDVO)tbmMdGbmDeftCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getProcOutGubunCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getUseYn());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
						}
							public int getBatchSize() {
									return tbmMdGbmDeftCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdGbmDeftCause Method
* 
* @ref_table TBM_MD_GBM_DEFT_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbmMdGbmDeftCause")
	public int[] deleteBatchTbmMdGbmDeftCause (final List tbmMdGbmDeftCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdGbmDeftCauseDEM.deleteBatchTbmMdGbmDeftCause.001*/  \n");
			sql.append(" TBM_MD_GBM_DEFT_CAUSE \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND DEFT_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdGbmDeftCauseDVO tbmMdGbmDeftCauseDVO = (TbmMdGbmDeftCauseDVO)tbmMdGbmDeftCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getGbmCode());
							ps.setString(psCount++, tbmMdGbmDeftCauseDVO.getDeftCauseCode());
						}
							public int getBatchSize() {
									return tbmMdGbmDeftCauseDVOList.size();
							}
					}
		);			
	}

	
}