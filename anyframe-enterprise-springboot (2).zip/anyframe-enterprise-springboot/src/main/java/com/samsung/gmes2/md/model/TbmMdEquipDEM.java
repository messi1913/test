package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_EQUIP
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdEquipDEM extends AbstractDAO {


/**
* insertTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return int
*/
	@LocalName("insertTbmMdEquip")
	public int insertTbmMdEquip (final TbmMdEquipDVO tbmMdEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdEquipDEM.insertTbmMdEquip.001*/  \n");
			sql.append(" TBM_MD_EQUIP (   \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        EQUIP_MODEL_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_TYPE_CODE , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbmMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbmMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdEquip Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdEquip Method")
	public int[][] updateBatchAllTbmMdEquip (final List  tbmMdEquipDVOList) {
		
		ArrayList updatetbmMdEquipDVOList = new ArrayList();
		ArrayList insertttbmMdEquipDVOList = new ArrayList();
		ArrayList deletetbmMdEquipDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdEquipDVOList.size() ; i++) {
		  TbmMdEquipDVO tbmMdEquipDVO = (TbmMdEquipDVO) tbmMdEquipDVOList.get(i);
		  
		  if (tbmMdEquipDVO.getSqlAction().equals("C"))
		      insertttbmMdEquipDVOList.add(tbmMdEquipDVO);
		  else if (tbmMdEquipDVO.getSqlAction().equals("U"))
		      updatetbmMdEquipDVOList.add(tbmMdEquipDVO);
		  else if (tbmMdEquipDVO.getSqlAction().equals("D"))
		      deletetbmMdEquipDVOList.add(tbmMdEquipDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdEquipDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdEquip(insertttbmMdEquipDVOList);
          
      if (updatetbmMdEquipDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdEquip(updatetbmMdEquipDVOList);
      
      if (deletetbmMdEquipDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdEquip(deletetbmMdEquipDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return int
*/
	@LocalName("updateTbmMdEquip")
	public int updateTbmMdEquip (final TbmMdEquipDVO tbmMdEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdEquipDEM.updateTbmMdEquip.001*/  \n");
			sql.append(" TBM_MD_EQUIP \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_MODEL_NM = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        EQUIP_KIND_CODE = ? , \n");
			sql.append("        EQUIP_TYPE_CODE = ? , \n");
			sql.append("        EQUIP_SPEC_CONT = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE EQUIP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbmMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbmMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
						}
					}
		);			
	}

/**
* deleteTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return int
*/
	@LocalName("deleteTbmMdEquip")
	public int deleteTbmMdEquip (final TbmMdEquipDVO tbmMdEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdEquipDEM.deleteTbmMdEquip.001*/  \n");
			sql.append(" TBM_MD_EQUIP \n");
			sql.append("  WHERE EQUIP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
						}
					}
		);			
	}

/**
* selectTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return TbmMdEquipDVO 
*/
	@LocalName("selectTbmMdEquip")
	public TbmMdEquipDVO selectTbmMdEquip (final TbmMdEquipDVO tbmMdEquipDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdEquipDEM.selectTbmMdEquip.001*/  \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        EQUIP_MODEL_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_TYPE_CODE , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_EQUIP \n");
			sql.append("  WHERE EQUIP_CODE = ? \n");

		return (TbmMdEquipDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdEquipDVO returnTbmMdEquipDVO = new TbmMdEquipDVO();
									returnTbmMdEquipDVO.setEquipCode(resultSet.getString("EQUIP_CODE"));
									returnTbmMdEquipDVO.setEquipModelNm(resultSet.getString("EQUIP_MODEL_NM"));
									returnTbmMdEquipDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdEquipDVO.setEquipKindCode(resultSet.getString("EQUIP_KIND_CODE"));
									returnTbmMdEquipDVO.setEquipTypeCode(resultSet.getString("EQUIP_TYPE_CODE"));
									returnTbmMdEquipDVO.setEquipSpecCont(resultSet.getString("EQUIP_SPEC_CONT"));
									returnTbmMdEquipDVO.setUnitCode(resultSet.getString("UNIT_CODE"));
									returnTbmMdEquipDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdEquipDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdEquipDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdEquipDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdEquipDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdEquipDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdEquip Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdEquip Method")
	public int mergeTbmMdEquip (final TbmMdEquipDVO tbmMdEquipDVO) {
		
		if ( selectTbmMdEquip (tbmMdEquipDVO) == null) {
			return insertTbmMdEquip(tbmMdEquipDVO);
		} else {
			return selectUpdateTbmMdEquip (tbmMdEquipDVO);
		}
	}

	/**
	 * selectUpdateTbmMdEquip Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdEquip Method")
	public int selectUpdateTbmMdEquip (final TbmMdEquipDVO tbmMdEquipDVO) {
		
		TbmMdEquipDVO tmpTbmMdEquipDVO =  selectTbmMdEquip (tbmMdEquipDVO);
		if ( tbmMdEquipDVO.getEquipCode() != null && !"".equals(tbmMdEquipDVO.getEquipCode()) ) {
			tmpTbmMdEquipDVO.setEquipCode(tbmMdEquipDVO.getEquipCode());
		}		
		if ( tbmMdEquipDVO.getEquipModelNm() != null && !"".equals(tbmMdEquipDVO.getEquipModelNm()) ) {
			tmpTbmMdEquipDVO.setEquipModelNm(tbmMdEquipDVO.getEquipModelNm());
		}		
		if ( tbmMdEquipDVO.getProcGubunCode() != null && !"".equals(tbmMdEquipDVO.getProcGubunCode()) ) {
			tmpTbmMdEquipDVO.setProcGubunCode(tbmMdEquipDVO.getProcGubunCode());
		}		
		if ( tbmMdEquipDVO.getEquipKindCode() != null && !"".equals(tbmMdEquipDVO.getEquipKindCode()) ) {
			tmpTbmMdEquipDVO.setEquipKindCode(tbmMdEquipDVO.getEquipKindCode());
		}		
		if ( tbmMdEquipDVO.getEquipTypeCode() != null && !"".equals(tbmMdEquipDVO.getEquipTypeCode()) ) {
			tmpTbmMdEquipDVO.setEquipTypeCode(tbmMdEquipDVO.getEquipTypeCode());
		}		
		if ( tbmMdEquipDVO.getEquipSpecCont() != null && !"".equals(tbmMdEquipDVO.getEquipSpecCont()) ) {
			tmpTbmMdEquipDVO.setEquipSpecCont(tbmMdEquipDVO.getEquipSpecCont());
		}		
		if ( tbmMdEquipDVO.getUnitCode() != null && !"".equals(tbmMdEquipDVO.getUnitCode()) ) {
			tmpTbmMdEquipDVO.setUnitCode(tbmMdEquipDVO.getUnitCode());
		}		
		if ( tbmMdEquipDVO.getUseYn() != null && !"".equals(tbmMdEquipDVO.getUseYn()) ) {
			tmpTbmMdEquipDVO.setUseYn(tbmMdEquipDVO.getUseYn());
		}		
		if ( tbmMdEquipDVO.getFstRegDt() != null && !"".equals(tbmMdEquipDVO.getFstRegDt()) ) {
			tmpTbmMdEquipDVO.setFstRegDt(tbmMdEquipDVO.getFstRegDt());
		}		
		if ( tbmMdEquipDVO.getFstRegerId() != null && !"".equals(tbmMdEquipDVO.getFstRegerId()) ) {
			tmpTbmMdEquipDVO.setFstRegerId(tbmMdEquipDVO.getFstRegerId());
		}		
		if ( tbmMdEquipDVO.getFnlUpdDt() != null && !"".equals(tbmMdEquipDVO.getFnlUpdDt()) ) {
			tmpTbmMdEquipDVO.setFnlUpdDt(tbmMdEquipDVO.getFnlUpdDt());
		}		
		if ( tbmMdEquipDVO.getFnlUpderId() != null && !"".equals(tbmMdEquipDVO.getFnlUpderId()) ) {
			tmpTbmMdEquipDVO.setFnlUpderId(tbmMdEquipDVO.getFnlUpderId());
		}		
		return updateTbmMdEquip (tmpTbmMdEquipDVO);
	}

/**
* insertBatchTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return int[]
*/
	@LocalName("insertBatchTbmMdEquip")
	public int[] insertBatchTbmMdEquip (final List tbmMdEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdEquipDEM.insertBatchTbmMdEquip.001*/  \n");
			sql.append(" TBM_MD_EQUIP (   \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        EQUIP_MODEL_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_TYPE_CODE , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdEquipDVO tbmMdEquipDVO = (TbmMdEquipDVO)tbmMdEquipDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbmMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbmMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdEquipDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return int[]
*/
	@LocalName("updateBatchTbmMdEquip")
	public int[] updateBatchTbmMdEquip (final List tbmMdEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdEquipDEM.updateBatchTbmMdEquip.001*/  \n");
			sql.append(" TBM_MD_EQUIP \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_MODEL_NM = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        EQUIP_KIND_CODE = ? , \n");
			sql.append("        EQUIP_TYPE_CODE = ? , \n");
			sql.append("        EQUIP_SPEC_CONT = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE EQUIP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdEquipDVO tbmMdEquipDVO = (TbmMdEquipDVO)tbmMdEquipDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbmMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbmMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbmMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdEquipDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
						}
							public int getBatchSize() {
									return tbmMdEquipDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdEquip Method
* 
* @ref_table TBM_MD_EQUIP
* @return int[]
*/
	@LocalName("deleteBatchTbmMdEquip")
	public int[] deleteBatchTbmMdEquip (final List tbmMdEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdEquipDEM.deleteBatchTbmMdEquip.001*/  \n");
			sql.append(" TBM_MD_EQUIP \n");
			sql.append("  WHERE EQUIP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdEquipDVO tbmMdEquipDVO = (TbmMdEquipDVO)tbmMdEquipDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdEquipDVO.getEquipCode());
						}
							public int getBatchSize() {
									return tbmMdEquipDVOList.size();
							}
					}
		);			
	}

	
}