package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_DOTK_ORG
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdDotkOrgDEM extends AbstractDAO {


/**
* insertTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return int
*/
	@LocalName("insertTbmMdDotkOrg")
	public int insertTbmMdDotkOrg (final TbmMdDotkOrgDVO tbmMdDotkOrgDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.insertTbmMdDotkOrg.001*/  \n");
			sql.append(" TBM_MD_DOTK_ORG (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        DOTK_CODE , \n");
			sql.append("        OPER_START_YMD , \n");
			sql.append("        OPER_FIN_YMD , \n");
			sql.append("        DOTK_NM , \n");
			sql.append("        LEADER_EMP_NO , \n");
			sql.append("        SLEADER_EMP_NO , \n");
			sql.append("        DOTK_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperFinYmd());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkNm());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getLeaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getSleaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkDesc());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdDotkOrg Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdDotkOrg Method")
	public int[][] updateBatchAllTbmMdDotkOrg (final List  tbmMdDotkOrgDVOList) {
		
		ArrayList updatetbmMdDotkOrgDVOList = new ArrayList();
		ArrayList insertttbmMdDotkOrgDVOList = new ArrayList();
		ArrayList deletetbmMdDotkOrgDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdDotkOrgDVOList.size() ; i++) {
		  TbmMdDotkOrgDVO tbmMdDotkOrgDVO = (TbmMdDotkOrgDVO) tbmMdDotkOrgDVOList.get(i);
		  
		  if (tbmMdDotkOrgDVO.getSqlAction().equals("C"))
		      insertttbmMdDotkOrgDVOList.add(tbmMdDotkOrgDVO);
		  else if (tbmMdDotkOrgDVO.getSqlAction().equals("U"))
		      updatetbmMdDotkOrgDVOList.add(tbmMdDotkOrgDVO);
		  else if (tbmMdDotkOrgDVO.getSqlAction().equals("D"))
		      deletetbmMdDotkOrgDVOList.add(tbmMdDotkOrgDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdDotkOrgDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdDotkOrg(insertttbmMdDotkOrgDVOList);
          
      if (updatetbmMdDotkOrgDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdDotkOrg(updatetbmMdDotkOrgDVOList);
      
      if (deletetbmMdDotkOrgDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdDotkOrg(deletetbmMdDotkOrgDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return int
*/
	@LocalName("updateTbmMdDotkOrg")
	public int updateTbmMdDotkOrg (final TbmMdDotkOrgDVO tbmMdDotkOrgDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.updateTbmMdDotkOrg.001*/  \n");
			sql.append(" TBM_MD_DOTK_ORG \n");
			sql.append(" SET   \n");
			sql.append("        OPER_FIN_YMD = ? , \n");
			sql.append("        DOTK_NM = ? , \n");
			sql.append("        LEADER_EMP_NO = ? , \n");
			sql.append("        SLEADER_EMP_NO = ? , \n");
			sql.append("        DOTK_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND DOTK_CODE = ? \n");
			sql.append("   AND OPER_START_YMD = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperFinYmd());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkNm());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getLeaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getSleaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkDesc());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
						}
					}
		);			
	}

/**
* deleteTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return int
*/
	@LocalName("deleteTbmMdDotkOrg")
	public int deleteTbmMdDotkOrg (final TbmMdDotkOrgDVO tbmMdDotkOrgDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.deleteTbmMdDotkOrg.001*/  \n");
			sql.append(" TBM_MD_DOTK_ORG \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND DOTK_CODE = ? \n");
			sql.append("    AND OPER_START_YMD = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
						}
					}
		);			
	}

/**
* selectTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return TbmMdDotkOrgDVO 
*/
	@LocalName("selectTbmMdDotkOrg")
	public TbmMdDotkOrgDVO selectTbmMdDotkOrg (final TbmMdDotkOrgDVO tbmMdDotkOrgDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.selectTbmMdDotkOrg.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        DOTK_CODE , \n");
			sql.append("        OPER_START_YMD , \n");
			sql.append("        OPER_FIN_YMD , \n");
			sql.append("        DOTK_NM , \n");
			sql.append("        LEADER_EMP_NO , \n");
			sql.append("        SLEADER_EMP_NO , \n");
			sql.append("        DOTK_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_DOTK_ORG \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND DOTK_CODE = ? \n");
			sql.append("    AND OPER_START_YMD = ? \n");

		return (TbmMdDotkOrgDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdDotkOrgDVO returnTbmMdDotkOrgDVO = new TbmMdDotkOrgDVO();
									returnTbmMdDotkOrgDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdDotkOrgDVO.setDotkCode(resultSet.getString("DOTK_CODE"));
									returnTbmMdDotkOrgDVO.setOperStartYmd(resultSet.getString("OPER_START_YMD"));
									returnTbmMdDotkOrgDVO.setOperFinYmd(resultSet.getString("OPER_FIN_YMD"));
									returnTbmMdDotkOrgDVO.setDotkNm(resultSet.getString("DOTK_NM"));
									returnTbmMdDotkOrgDVO.setLeaderEmpNo(resultSet.getString("LEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setSleaderEmpNo(resultSet.getString("SLEADER_EMP_NO"));
									returnTbmMdDotkOrgDVO.setDotkDesc(resultSet.getString("DOTK_DESC"));
									returnTbmMdDotkOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdDotkOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdDotkOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdDotkOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdDotkOrgDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdDotkOrg Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdDotkOrg Method")
	public int mergeTbmMdDotkOrg (final TbmMdDotkOrgDVO tbmMdDotkOrgDVO) {
		
		if ( selectTbmMdDotkOrg (tbmMdDotkOrgDVO) == null) {
			return insertTbmMdDotkOrg(tbmMdDotkOrgDVO);
		} else {
			return selectUpdateTbmMdDotkOrg (tbmMdDotkOrgDVO);
		}
	}

	/**
	 * selectUpdateTbmMdDotkOrg Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdDotkOrg Method")
	public int selectUpdateTbmMdDotkOrg (final TbmMdDotkOrgDVO tbmMdDotkOrgDVO) {
		
		TbmMdDotkOrgDVO tmpTbmMdDotkOrgDVO =  selectTbmMdDotkOrg (tbmMdDotkOrgDVO);
		if ( tbmMdDotkOrgDVO.getFctCode() != null && !"".equals(tbmMdDotkOrgDVO.getFctCode()) ) {
			tmpTbmMdDotkOrgDVO.setFctCode(tbmMdDotkOrgDVO.getFctCode());
		}		
		if ( tbmMdDotkOrgDVO.getDotkCode() != null && !"".equals(tbmMdDotkOrgDVO.getDotkCode()) ) {
			tmpTbmMdDotkOrgDVO.setDotkCode(tbmMdDotkOrgDVO.getDotkCode());
		}		
		if ( tbmMdDotkOrgDVO.getOperStartYmd() != null && !"".equals(tbmMdDotkOrgDVO.getOperStartYmd()) ) {
			tmpTbmMdDotkOrgDVO.setOperStartYmd(tbmMdDotkOrgDVO.getOperStartYmd());
		}		
		if ( tbmMdDotkOrgDVO.getOperFinYmd() != null && !"".equals(tbmMdDotkOrgDVO.getOperFinYmd()) ) {
			tmpTbmMdDotkOrgDVO.setOperFinYmd(tbmMdDotkOrgDVO.getOperFinYmd());
		}		
		if ( tbmMdDotkOrgDVO.getDotkNm() != null && !"".equals(tbmMdDotkOrgDVO.getDotkNm()) ) {
			tmpTbmMdDotkOrgDVO.setDotkNm(tbmMdDotkOrgDVO.getDotkNm());
		}		
		if ( tbmMdDotkOrgDVO.getLeaderEmpNo() != null && !"".equals(tbmMdDotkOrgDVO.getLeaderEmpNo()) ) {
			tmpTbmMdDotkOrgDVO.setLeaderEmpNo(tbmMdDotkOrgDVO.getLeaderEmpNo());
		}		
		if ( tbmMdDotkOrgDVO.getSleaderEmpNo() != null && !"".equals(tbmMdDotkOrgDVO.getSleaderEmpNo()) ) {
			tmpTbmMdDotkOrgDVO.setSleaderEmpNo(tbmMdDotkOrgDVO.getSleaderEmpNo());
		}		
		if ( tbmMdDotkOrgDVO.getDotkDesc() != null && !"".equals(tbmMdDotkOrgDVO.getDotkDesc()) ) {
			tmpTbmMdDotkOrgDVO.setDotkDesc(tbmMdDotkOrgDVO.getDotkDesc());
		}		
		if ( tbmMdDotkOrgDVO.getFstRegDt() != null && !"".equals(tbmMdDotkOrgDVO.getFstRegDt()) ) {
			tmpTbmMdDotkOrgDVO.setFstRegDt(tbmMdDotkOrgDVO.getFstRegDt());
		}		
		if ( tbmMdDotkOrgDVO.getFstRegerId() != null && !"".equals(tbmMdDotkOrgDVO.getFstRegerId()) ) {
			tmpTbmMdDotkOrgDVO.setFstRegerId(tbmMdDotkOrgDVO.getFstRegerId());
		}		
		if ( tbmMdDotkOrgDVO.getFnlUpdDt() != null && !"".equals(tbmMdDotkOrgDVO.getFnlUpdDt()) ) {
			tmpTbmMdDotkOrgDVO.setFnlUpdDt(tbmMdDotkOrgDVO.getFnlUpdDt());
		}		
		if ( tbmMdDotkOrgDVO.getFnlUpderId() != null && !"".equals(tbmMdDotkOrgDVO.getFnlUpderId()) ) {
			tmpTbmMdDotkOrgDVO.setFnlUpderId(tbmMdDotkOrgDVO.getFnlUpderId());
		}		
		return updateTbmMdDotkOrg (tmpTbmMdDotkOrgDVO);
	}

/**
* insertBatchTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return int[]
*/
	@LocalName("insertBatchTbmMdDotkOrg")
	public int[] insertBatchTbmMdDotkOrg (final List tbmMdDotkOrgDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.insertBatchTbmMdDotkOrg.001*/  \n");
			sql.append(" TBM_MD_DOTK_ORG (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        DOTK_CODE , \n");
			sql.append("        OPER_START_YMD , \n");
			sql.append("        OPER_FIN_YMD , \n");
			sql.append("        DOTK_NM , \n");
			sql.append("        LEADER_EMP_NO , \n");
			sql.append("        SLEADER_EMP_NO , \n");
			sql.append("        DOTK_DESC , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdDotkOrgDVO tbmMdDotkOrgDVO = (TbmMdDotkOrgDVO)tbmMdDotkOrgDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperFinYmd());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkNm());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getLeaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getSleaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkDesc());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdDotkOrgDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return int[]
*/
	@LocalName("updateBatchTbmMdDotkOrg")
	public int[] updateBatchTbmMdDotkOrg (final List tbmMdDotkOrgDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.updateBatchTbmMdDotkOrg.001*/  \n");
			sql.append(" TBM_MD_DOTK_ORG \n");
			sql.append(" SET   \n");
			sql.append("        OPER_FIN_YMD = ? , \n");
			sql.append("        DOTK_NM = ? , \n");
			sql.append("        LEADER_EMP_NO = ? , \n");
			sql.append("        SLEADER_EMP_NO = ? , \n");
			sql.append("        DOTK_DESC = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND DOTK_CODE = ? \n");
			sql.append("   AND OPER_START_YMD = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdDotkOrgDVO tbmMdDotkOrgDVO = (TbmMdDotkOrgDVO)tbmMdDotkOrgDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperFinYmd());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkNm());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getLeaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getSleaderEmpNo());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkDesc());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
						}
							public int getBatchSize() {
									return tbmMdDotkOrgDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdDotkOrg Method
* 
* @ref_table TBM_MD_DOTK_ORG
* @return int[]
*/
	@LocalName("deleteBatchTbmMdDotkOrg")
	public int[] deleteBatchTbmMdDotkOrg (final List tbmMdDotkOrgDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdDotkOrgDEM.deleteBatchTbmMdDotkOrg.001*/  \n");
			sql.append(" TBM_MD_DOTK_ORG \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND DOTK_CODE = ? \n");
			sql.append("    AND OPER_START_YMD = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdDotkOrgDVO tbmMdDotkOrgDVO = (TbmMdDotkOrgDVO)tbmMdDotkOrgDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdDotkOrgDVO.getFctCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getDotkCode());
							ps.setString(psCount++, tbmMdDotkOrgDVO.getOperStartYmd());
						}
							public int getBatchSize() {
									return tbmMdDotkOrgDVOList.size();
							}
					}
		);			
	}

	
}