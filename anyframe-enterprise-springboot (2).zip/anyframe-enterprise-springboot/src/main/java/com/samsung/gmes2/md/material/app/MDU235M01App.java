package com.samsung.gmes2.md.material.app;

public class MDU235M01App {

	/**
	 * 모델별Kitting 목록 초기설정
	 */
	public void initModelKitting(){}

	/**
	 * 모델별Kitting 목록 조회
	 */
	public void listModelKitting(){}

	/**
	 * 모델별Kitting 목록 엑셀 다운로드
	 */
	public void excelModelKitting(){}

	/**
	 * 모델별Kitting 목록 등록/수정 초기설정
	 */
	public void editModelKitting(){}

	/**
	 * 모델별Kitting 목록 저장
	 */
	public void saveModelKitting(){}

}
