package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdUnitidDVO extends AbstractVo {

	@Length(50) 
	private String unitid;

	@Length(500) 
	private String unitidNm;

	@Length(1) 
	private String prtYn;

	@Length(1) 
	private String mainUnitidYn;

	@Length(30) 
	private String scanFormCode;

	@Length(1) 
	private String pbaYn;

	@Length(1) 
	private String labelGubunYn;

	@Length(1) 
	private String epassGubunYn;

	@Length(1) 
	private String bkndYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getUnitid() {
		this.unitid = super.getValue(0);
		return this.unitid;
	}

	public void setUnitid(String unitid) {
        super.setValue(0, unitid);
		this.unitid = unitid;
	}
	
	public String getUnitidNm() {
		this.unitidNm = super.getValue(1);
		return this.unitidNm;
	}

	public void setUnitidNm(String unitidNm) {
        super.setValue(1, unitidNm);
		this.unitidNm = unitidNm;
	}
	
	public String getPrtYn() {
		this.prtYn = super.getValue(2);
		return this.prtYn;
	}

	public void setPrtYn(String prtYn) {
        super.setValue(2, prtYn);
		this.prtYn = prtYn;
	}
	
	public String getMainUnitidYn() {
		this.mainUnitidYn = super.getValue(3);
		return this.mainUnitidYn;
	}

	public void setMainUnitidYn(String mainUnitidYn) {
        super.setValue(3, mainUnitidYn);
		this.mainUnitidYn = mainUnitidYn;
	}
	
	public String getScanFormCode() {
		this.scanFormCode = super.getValue(4);
		return this.scanFormCode;
	}

	public void setScanFormCode(String scanFormCode) {
        super.setValue(4, scanFormCode);
		this.scanFormCode = scanFormCode;
	}
	
	public String getPbaYn() {
		this.pbaYn = super.getValue(5);
		return this.pbaYn;
	}

	public void setPbaYn(String pbaYn) {
        super.setValue(5, pbaYn);
		this.pbaYn = pbaYn;
	}
	
	public String getLabelGubunYn() {
		this.labelGubunYn = super.getValue(6);
		return this.labelGubunYn;
	}

	public void setLabelGubunYn(String labelGubunYn) {
        super.setValue(6, labelGubunYn);
		this.labelGubunYn = labelGubunYn;
	}
	
	public String getEpassGubunYn() {
		this.epassGubunYn = super.getValue(7);
		return this.epassGubunYn;
	}

	public void setEpassGubunYn(String epassGubunYn) {
        super.setValue(7, epassGubunYn);
		this.epassGubunYn = epassGubunYn;
	}
	
	public String getBkndYn() {
		this.bkndYn = super.getValue(8);
		return this.bkndYn;
	}

	public void setBkndYn(String bkndYn) {
        super.setValue(8, bkndYn);
		this.bkndYn = bkndYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(9);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(9, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(10);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(10, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(11);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(11, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(12);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(12, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(13);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(13, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}