package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_MODEL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbhMdModelDEM extends AbstractDAO {


/**
* insertTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return int
*/
	@LocalName("insertTbhMdModel")
	public int insertTbhMdModel (final TbhMdModelDVO tbhMdModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdModelDEM.insertTbhMdModel.001*/  \n");
			sql.append(" TBH_MD_MODEL (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_TYPE_CODE , \n");
			sql.append("        MODEL_DESC , \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        DEV_TASK_CODE , \n");
			sql.append("        REV_VER , \n");
			sql.append("        SEG_CODE , \n");
			sql.append("        BASIC_MODEL_CODE , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        EAN_CODE , \n");
			sql.append("        UPC_CODE , \n");
			sql.append("        KAN_CODE , \n");
			sql.append("        DOM_EXP_GUBUN_CODE , \n");
			sql.append("        OEM_YN , \n");
			sql.append("        BUYER_INSP_YN , \n");
			sql.append("        DISUSE_YN , \n");
			sql.append("        COLOR_NM , \n");
			sql.append("        PROD_TOTAL_WEIT , \n");
			sql.append("        PROD_ACTU_WEIT , \n");
			sql.append("        PROD_SIZE , \n");
			sql.append("        CHASSIS_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
							ps.setString(psCount++, tbhMdModelDVO.getProdCode());
							ps.setString(psCount++, tbhMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbhMdModelDVO.getModelDesc());
							ps.setString(psCount++, tbhMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbhMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbhMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getRevVer());
							ps.setString(psCount++, tbhMdModelDVO.getSegCode());
							ps.setString(psCount++, tbhMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getEanCode());
							ps.setString(psCount++, tbhMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbhMdModelDVO.getKanCode());
							ps.setString(psCount++, tbhMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbhMdModelDVO.getOemYn());
							ps.setString(psCount++, tbhMdModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbhMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbhMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdSize());
							ps.setString(psCount++, tbhMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbhMdModelDVO.getUseYn());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdModelDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdModel Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdModel Method")
	public int[][] updateBatchAllTbhMdModel (final List  tbhMdModelDVOList) {
		
		ArrayList updatetbhMdModelDVOList = new ArrayList();
		ArrayList insertttbhMdModelDVOList = new ArrayList();
		ArrayList deletetbhMdModelDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdModelDVOList.size() ; i++) {
		  TbhMdModelDVO tbhMdModelDVO = (TbhMdModelDVO) tbhMdModelDVOList.get(i);
		  
		  if (tbhMdModelDVO.getSqlAction().equals("C"))
		      insertttbhMdModelDVOList.add(tbhMdModelDVO);
		  else if (tbhMdModelDVO.getSqlAction().equals("U"))
		      updatetbhMdModelDVOList.add(tbhMdModelDVO);
		  else if (tbhMdModelDVO.getSqlAction().equals("D"))
		      deletetbhMdModelDVOList.add(tbhMdModelDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdModelDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdModel(insertttbhMdModelDVOList);
          
      if (updatetbhMdModelDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdModel(updatetbhMdModelDVOList);
      
      if (deletetbhMdModelDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdModel(deletetbhMdModelDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return int
*/
	@LocalName("updateTbhMdModel")
	public int updateTbhMdModel (final TbhMdModelDVO tbhMdModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdModelDEM.updateTbhMdModel.001*/  \n");
			sql.append(" TBH_MD_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        PROD_CODE = ? , \n");
			sql.append("        PROD_TYPE_CODE = ? , \n");
			sql.append("        MODEL_DESC = ? , \n");
			sql.append("        MODEL_GRP_CODE = ? , \n");
			sql.append("        PJT_CODE = ? , \n");
			sql.append("        DEV_TASK_CODE = ? , \n");
			sql.append("        REV_VER = ? , \n");
			sql.append("        SEG_CODE = ? , \n");
			sql.append("        BASIC_MODEL_CODE = ? , \n");
			sql.append("        SAL_MODEL_CODE = ? , \n");
			sql.append("        EAN_CODE = ? , \n");
			sql.append("        UPC_CODE = ? , \n");
			sql.append("        KAN_CODE = ? , \n");
			sql.append("        DOM_EXP_GUBUN_CODE = ? , \n");
			sql.append("        OEM_YN = ? , \n");
			sql.append("        BUYER_INSP_YN = ? , \n");
			sql.append("        DISUSE_YN = ? , \n");
			sql.append("        COLOR_NM = ? , \n");
			sql.append("        PROD_TOTAL_WEIT = ? , \n");
			sql.append("        PROD_ACTU_WEIT = ? , \n");
			sql.append("        PROD_SIZE = ? , \n");
			sql.append("        CHASSIS_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdModelDVO.getProdCode());
							ps.setString(psCount++, tbhMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbhMdModelDVO.getModelDesc());
							ps.setString(psCount++, tbhMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbhMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbhMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getRevVer());
							ps.setString(psCount++, tbhMdModelDVO.getSegCode());
							ps.setString(psCount++, tbhMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getEanCode());
							ps.setString(psCount++, tbhMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbhMdModelDVO.getKanCode());
							ps.setString(psCount++, tbhMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbhMdModelDVO.getOemYn());
							ps.setString(psCount++, tbhMdModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbhMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbhMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdSize());
							ps.setString(psCount++, tbhMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbhMdModelDVO.getUseYn());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdModelDVO.getEvtNm());

							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return int
*/
	@LocalName("deleteTbhMdModel")
	public int deleteTbhMdModel (final TbhMdModelDVO tbhMdModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdModelDEM.deleteTbhMdModel.001*/  \n");
			sql.append(" TBH_MD_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return TbhMdModelDVO 
*/
	@LocalName("selectTbhMdModel")
	public TbhMdModelDVO selectTbhMdModel (final TbhMdModelDVO tbhMdModelDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdModelDEM.selectTbhMdModel.001*/  \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_TYPE_CODE , \n");
			sql.append("        MODEL_DESC , \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        DEV_TASK_CODE , \n");
			sql.append("        REV_VER , \n");
			sql.append("        SEG_CODE , \n");
			sql.append("        BASIC_MODEL_CODE , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        EAN_CODE , \n");
			sql.append("        UPC_CODE , \n");
			sql.append("        KAN_CODE , \n");
			sql.append("        DOM_EXP_GUBUN_CODE , \n");
			sql.append("        OEM_YN , \n");
			sql.append("        BUYER_INSP_YN , \n");
			sql.append("        DISUSE_YN , \n");
			sql.append("        COLOR_NM , \n");
			sql.append("        PROD_TOTAL_WEIT , \n");
			sql.append("        PROD_ACTU_WEIT , \n");
			sql.append("        PROD_SIZE , \n");
			sql.append("        CHASSIS_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBH_MD_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdModelDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdModelDVO returnTbhMdModelDVO = new TbhMdModelDVO();
									returnTbhMdModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbhMdModelDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdModelDVO.setProdCode(resultSet.getString("PROD_CODE"));
									returnTbhMdModelDVO.setProdTypeCode(resultSet.getString("PROD_TYPE_CODE"));
									returnTbhMdModelDVO.setModelDesc(resultSet.getString("MODEL_DESC"));
									returnTbhMdModelDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbhMdModelDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbhMdModelDVO.setDevTaskCode(resultSet.getString("DEV_TASK_CODE"));
									returnTbhMdModelDVO.setRevVer(resultSet.getBigDecimal("REV_VER"));
									returnTbhMdModelDVO.setSegCode(resultSet.getString("SEG_CODE"));
									returnTbhMdModelDVO.setBasicModelCode(resultSet.getString("BASIC_MODEL_CODE"));
									returnTbhMdModelDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbhMdModelDVO.setEanCode(resultSet.getString("EAN_CODE"));
									returnTbhMdModelDVO.setUpcCode(resultSet.getString("UPC_CODE"));
									returnTbhMdModelDVO.setKanCode(resultSet.getString("KAN_CODE"));
									returnTbhMdModelDVO.setDomExpGubunCode(resultSet.getString("DOM_EXP_GUBUN_CODE"));
									returnTbhMdModelDVO.setOemYn(resultSet.getString("OEM_YN"));
									returnTbhMdModelDVO.setBuyerInspYn(resultSet.getString("BUYER_INSP_YN"));
									returnTbhMdModelDVO.setDisuseYn(resultSet.getString("DISUSE_YN"));
									returnTbhMdModelDVO.setColorNm(resultSet.getString("COLOR_NM"));
									returnTbhMdModelDVO.setProdTotalWeit(resultSet.getBigDecimal("PROD_TOTAL_WEIT"));
									returnTbhMdModelDVO.setProdActuWeit(resultSet.getBigDecimal("PROD_ACTU_WEIT"));
									returnTbhMdModelDVO.setProdSize(resultSet.getBigDecimal("PROD_SIZE"));
									returnTbhMdModelDVO.setChassisNm(resultSet.getString("CHASSIS_NM"));
									returnTbhMdModelDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbhMdModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbhMdModelDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbhMdModelDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdModel Method")
	public int mergeTbhMdModel (final TbhMdModelDVO tbhMdModelDVO) {
		
		if ( selectTbhMdModel (tbhMdModelDVO) == null) {
			return insertTbhMdModel(tbhMdModelDVO);
		} else {
			return selectUpdateTbhMdModel (tbhMdModelDVO);
		}
	}

	/**
	 * selectUpdateTbhMdModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdModel Method")
	public int selectUpdateTbhMdModel (final TbhMdModelDVO tbhMdModelDVO) {
		
		TbhMdModelDVO tmpTbhMdModelDVO =  selectTbhMdModel (tbhMdModelDVO);
		if ( tbhMdModelDVO.getModelCode() != null && !"".equals(tbhMdModelDVO.getModelCode()) ) {
			tmpTbhMdModelDVO.setModelCode(tbhMdModelDVO.getModelCode());
		}		
		if ( tbhMdModelDVO.getHistTsp() != null && !"".equals(tbhMdModelDVO.getHistTsp()) ) {
			tmpTbhMdModelDVO.setHistTsp(tbhMdModelDVO.getHistTsp());
		}		
		if ( tbhMdModelDVO.getProdCode() != null && !"".equals(tbhMdModelDVO.getProdCode()) ) {
			tmpTbhMdModelDVO.setProdCode(tbhMdModelDVO.getProdCode());
		}		
		if ( tbhMdModelDVO.getProdTypeCode() != null && !"".equals(tbhMdModelDVO.getProdTypeCode()) ) {
			tmpTbhMdModelDVO.setProdTypeCode(tbhMdModelDVO.getProdTypeCode());
		}		
		if ( tbhMdModelDVO.getModelDesc() != null && !"".equals(tbhMdModelDVO.getModelDesc()) ) {
			tmpTbhMdModelDVO.setModelDesc(tbhMdModelDVO.getModelDesc());
		}		
		if ( tbhMdModelDVO.getModelGrpCode() != null && !"".equals(tbhMdModelDVO.getModelGrpCode()) ) {
			tmpTbhMdModelDVO.setModelGrpCode(tbhMdModelDVO.getModelGrpCode());
		}		
		if ( tbhMdModelDVO.getPjtCode() != null && !"".equals(tbhMdModelDVO.getPjtCode()) ) {
			tmpTbhMdModelDVO.setPjtCode(tbhMdModelDVO.getPjtCode());
		}		
		if ( tbhMdModelDVO.getDevTaskCode() != null && !"".equals(tbhMdModelDVO.getDevTaskCode()) ) {
			tmpTbhMdModelDVO.setDevTaskCode(tbhMdModelDVO.getDevTaskCode());
		}		
		if ( tbhMdModelDVO.getRevVer() != null && !"".equals(tbhMdModelDVO.getRevVer()) ) {
			tmpTbhMdModelDVO.setRevVer(tbhMdModelDVO.getRevVer());
		}		
		if ( tbhMdModelDVO.getSegCode() != null && !"".equals(tbhMdModelDVO.getSegCode()) ) {
			tmpTbhMdModelDVO.setSegCode(tbhMdModelDVO.getSegCode());
		}		
		if ( tbhMdModelDVO.getBasicModelCode() != null && !"".equals(tbhMdModelDVO.getBasicModelCode()) ) {
			tmpTbhMdModelDVO.setBasicModelCode(tbhMdModelDVO.getBasicModelCode());
		}		
		if ( tbhMdModelDVO.getSalModelCode() != null && !"".equals(tbhMdModelDVO.getSalModelCode()) ) {
			tmpTbhMdModelDVO.setSalModelCode(tbhMdModelDVO.getSalModelCode());
		}		
		if ( tbhMdModelDVO.getEanCode() != null && !"".equals(tbhMdModelDVO.getEanCode()) ) {
			tmpTbhMdModelDVO.setEanCode(tbhMdModelDVO.getEanCode());
		}		
		if ( tbhMdModelDVO.getUpcCode() != null && !"".equals(tbhMdModelDVO.getUpcCode()) ) {
			tmpTbhMdModelDVO.setUpcCode(tbhMdModelDVO.getUpcCode());
		}		
		if ( tbhMdModelDVO.getKanCode() != null && !"".equals(tbhMdModelDVO.getKanCode()) ) {
			tmpTbhMdModelDVO.setKanCode(tbhMdModelDVO.getKanCode());
		}		
		if ( tbhMdModelDVO.getDomExpGubunCode() != null && !"".equals(tbhMdModelDVO.getDomExpGubunCode()) ) {
			tmpTbhMdModelDVO.setDomExpGubunCode(tbhMdModelDVO.getDomExpGubunCode());
		}		
		if ( tbhMdModelDVO.getOemYn() != null && !"".equals(tbhMdModelDVO.getOemYn()) ) {
			tmpTbhMdModelDVO.setOemYn(tbhMdModelDVO.getOemYn());
		}		
		if ( tbhMdModelDVO.getBuyerInspYn() != null && !"".equals(tbhMdModelDVO.getBuyerInspYn()) ) {
			tmpTbhMdModelDVO.setBuyerInspYn(tbhMdModelDVO.getBuyerInspYn());
		}		
		if ( tbhMdModelDVO.getDisuseYn() != null && !"".equals(tbhMdModelDVO.getDisuseYn()) ) {
			tmpTbhMdModelDVO.setDisuseYn(tbhMdModelDVO.getDisuseYn());
		}		
		if ( tbhMdModelDVO.getColorNm() != null && !"".equals(tbhMdModelDVO.getColorNm()) ) {
			tmpTbhMdModelDVO.setColorNm(tbhMdModelDVO.getColorNm());
		}		
		if ( tbhMdModelDVO.getProdTotalWeit() != null && !"".equals(tbhMdModelDVO.getProdTotalWeit()) ) {
			tmpTbhMdModelDVO.setProdTotalWeit(tbhMdModelDVO.getProdTotalWeit());
		}		
		if ( tbhMdModelDVO.getProdActuWeit() != null && !"".equals(tbhMdModelDVO.getProdActuWeit()) ) {
			tmpTbhMdModelDVO.setProdActuWeit(tbhMdModelDVO.getProdActuWeit());
		}		
		if ( tbhMdModelDVO.getProdSize() != null && !"".equals(tbhMdModelDVO.getProdSize()) ) {
			tmpTbhMdModelDVO.setProdSize(tbhMdModelDVO.getProdSize());
		}		
		if ( tbhMdModelDVO.getChassisNm() != null && !"".equals(tbhMdModelDVO.getChassisNm()) ) {
			tmpTbhMdModelDVO.setChassisNm(tbhMdModelDVO.getChassisNm());
		}		
		if ( tbhMdModelDVO.getUseYn() != null && !"".equals(tbhMdModelDVO.getUseYn()) ) {
			tmpTbhMdModelDVO.setUseYn(tbhMdModelDVO.getUseYn());
		}		
		if ( tbhMdModelDVO.getFstRegDt() != null && !"".equals(tbhMdModelDVO.getFstRegDt()) ) {
			tmpTbhMdModelDVO.setFstRegDt(tbhMdModelDVO.getFstRegDt());
		}		
		if ( tbhMdModelDVO.getFstRegerId() != null && !"".equals(tbhMdModelDVO.getFstRegerId()) ) {
			tmpTbhMdModelDVO.setFstRegerId(tbhMdModelDVO.getFstRegerId());
		}		
		if ( tbhMdModelDVO.getFnlUpdDt() != null && !"".equals(tbhMdModelDVO.getFnlUpdDt()) ) {
			tmpTbhMdModelDVO.setFnlUpdDt(tbhMdModelDVO.getFnlUpdDt());
		}		
		if ( tbhMdModelDVO.getFnlUpderId() != null && !"".equals(tbhMdModelDVO.getFnlUpderId()) ) {
			tmpTbhMdModelDVO.setFnlUpderId(tbhMdModelDVO.getFnlUpderId());
		}		
		if ( tbhMdModelDVO.getEvtNm() != null && !"".equals(tbhMdModelDVO.getEvtNm()) ) {
			tmpTbhMdModelDVO.setEvtNm(tbhMdModelDVO.getEvtNm());
		}		
		return updateTbhMdModel (tmpTbhMdModelDVO);
	}

/**
* insertBatchTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return int[]
*/
	@LocalName("insertBatchTbhMdModel")
	public int[] insertBatchTbhMdModel (final List tbhMdModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdModelDEM.insertBatchTbhMdModel.001*/  \n");
			sql.append(" TBH_MD_MODEL (   \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        PROD_CODE , \n");
			sql.append("        PROD_TYPE_CODE , \n");
			sql.append("        MODEL_DESC , \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        DEV_TASK_CODE , \n");
			sql.append("        REV_VER , \n");
			sql.append("        SEG_CODE , \n");
			sql.append("        BASIC_MODEL_CODE , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        EAN_CODE , \n");
			sql.append("        UPC_CODE , \n");
			sql.append("        KAN_CODE , \n");
			sql.append("        DOM_EXP_GUBUN_CODE , \n");
			sql.append("        OEM_YN , \n");
			sql.append("        BUYER_INSP_YN , \n");
			sql.append("        DISUSE_YN , \n");
			sql.append("        COLOR_NM , \n");
			sql.append("        PROD_TOTAL_WEIT , \n");
			sql.append("        PROD_ACTU_WEIT , \n");
			sql.append("        PROD_SIZE , \n");
			sql.append("        CHASSIS_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdModelDVO tbhMdModelDVO = (TbhMdModelDVO)tbhMdModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
							ps.setString(psCount++, tbhMdModelDVO.getProdCode());
							ps.setString(psCount++, tbhMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbhMdModelDVO.getModelDesc());
							ps.setString(psCount++, tbhMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbhMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbhMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getRevVer());
							ps.setString(psCount++, tbhMdModelDVO.getSegCode());
							ps.setString(psCount++, tbhMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getEanCode());
							ps.setString(psCount++, tbhMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbhMdModelDVO.getKanCode());
							ps.setString(psCount++, tbhMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbhMdModelDVO.getOemYn());
							ps.setString(psCount++, tbhMdModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbhMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbhMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdSize());
							ps.setString(psCount++, tbhMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbhMdModelDVO.getUseYn());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdModelDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbhMdModelDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return int[]
*/
	@LocalName("updateBatchTbhMdModel")
	public int[] updateBatchTbhMdModel (final List tbhMdModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdModelDEM.updateBatchTbhMdModel.001*/  \n");
			sql.append(" TBH_MD_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        PROD_CODE = ? , \n");
			sql.append("        PROD_TYPE_CODE = ? , \n");
			sql.append("        MODEL_DESC = ? , \n");
			sql.append("        MODEL_GRP_CODE = ? , \n");
			sql.append("        PJT_CODE = ? , \n");
			sql.append("        DEV_TASK_CODE = ? , \n");
			sql.append("        REV_VER = ? , \n");
			sql.append("        SEG_CODE = ? , \n");
			sql.append("        BASIC_MODEL_CODE = ? , \n");
			sql.append("        SAL_MODEL_CODE = ? , \n");
			sql.append("        EAN_CODE = ? , \n");
			sql.append("        UPC_CODE = ? , \n");
			sql.append("        KAN_CODE = ? , \n");
			sql.append("        DOM_EXP_GUBUN_CODE = ? , \n");
			sql.append("        OEM_YN = ? , \n");
			sql.append("        BUYER_INSP_YN = ? , \n");
			sql.append("        DISUSE_YN = ? , \n");
			sql.append("        COLOR_NM = ? , \n");
			sql.append("        PROD_TOTAL_WEIT = ? , \n");
			sql.append("        PROD_ACTU_WEIT = ? , \n");
			sql.append("        PROD_SIZE = ? , \n");
			sql.append("        CHASSIS_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE MODEL_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdModelDVO tbhMdModelDVO = (TbhMdModelDVO)tbhMdModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdModelDVO.getProdCode());
							ps.setString(psCount++, tbhMdModelDVO.getProdTypeCode());
							ps.setString(psCount++, tbhMdModelDVO.getModelDesc());
							ps.setString(psCount++, tbhMdModelDVO.getModelGrpCode());
							ps.setString(psCount++, tbhMdModelDVO.getPjtCode());
							ps.setString(psCount++, tbhMdModelDVO.getDevTaskCode());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getRevVer());
							ps.setString(psCount++, tbhMdModelDVO.getSegCode());
							ps.setString(psCount++, tbhMdModelDVO.getBasicModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getSalModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getEanCode());
							ps.setString(psCount++, tbhMdModelDVO.getUpcCode());
							ps.setString(psCount++, tbhMdModelDVO.getKanCode());
							ps.setString(psCount++, tbhMdModelDVO.getDomExpGubunCode());
							ps.setString(psCount++, tbhMdModelDVO.getOemYn());
							ps.setString(psCount++, tbhMdModelDVO.getBuyerInspYn());
							ps.setString(psCount++, tbhMdModelDVO.getDisuseYn());
							ps.setString(psCount++, tbhMdModelDVO.getColorNm());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdTotalWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdActuWeit());
							ps.setBigDecimal(psCount++, tbhMdModelDVO.getProdSize());
							ps.setString(psCount++, tbhMdModelDVO.getChassisNm());
							ps.setString(psCount++, tbhMdModelDVO.getUseYn());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdModelDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdModelDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdModelDVO.getEvtNm());

							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdModelDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdModel Method
* 
* @ref_table TBH_MD_MODEL
* @return int[]
*/
	@LocalName("deleteBatchTbhMdModel")
	public int[] deleteBatchTbhMdModel (final List tbhMdModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdModelDEM.deleteBatchTbhMdModel.001*/  \n");
			sql.append(" TBH_MD_MODEL \n");
			sql.append("  WHERE MODEL_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdModelDVO tbhMdModelDVO = (TbhMdModelDVO)tbhMdModelDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdModelDVO.getModelCode());
							ps.setString(psCount++, tbhMdModelDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdModelDVOList.size();
							}
					}
		);			
	}

	
}