package com.samsung.gmes2.md.loss.biz;

public class MdManageLossDutyPicBiz {

	/**
	 * 책임부서 목록 조회
	 */
	public void listLossDutyPic(){}

	/**
	 * 책임부서 목록 저장
	 */
	public void saveLossDutyPic(){}

	/**
	 * 유실책임그룹 리스트
	 */
	public void listLossDutyGrp(){}

	/**
	 * 유실책임파트 리스트
	 */
	public void listLossDutyPart(){}

	/**
	 * 책임자 정보 조회(팝업)
	 */
	public void getDutyUser(){}

}
