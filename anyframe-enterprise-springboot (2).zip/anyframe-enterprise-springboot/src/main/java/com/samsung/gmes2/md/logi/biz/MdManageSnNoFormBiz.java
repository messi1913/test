package com.samsung.gmes2.md.logi.biz;

public class MdManageSnNoFormBiz {

	/**
	 * 시리얼형태 목록 조회
	 */
	public void listSnNoForm(){}

	/**
	 * 시리얼형태 목록 저장
	 */
	public void saveSnNoForm(){}

}
