package com.samsung.gmes2.md.loss.biz;

public class MdManageFxPrblmCauseBiz {

	/**
	 * 정시정량차질원인코드 목록 조회
	 */
	public void listFxPrblmCauseCode(){}

	/**
	 * 정시정량차질원인코드 목록 저장
	 */
	public void saveFxPrblmCauseCode(){}

}
