package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_BASE_PROC
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbcMdBaseProcDEM extends AbstractDAO {


/**
* insertTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return int
*/
	@LocalName("insertTbcMdBaseProc")
	public int insertTbcMdBaseProc (final TbcMdBaseProcDVO tbcMdBaseProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.insertTbcMdBaseProc.001*/  \n");
			sql.append(" TBC_MD_BASE_PROC (   \n");
			sql.append("        BASE_PROC_CODE , \n");
			sql.append("        BASE_PROC_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcNm());
							ps.setString(psCount++, tbcMdBaseProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdBaseProc Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdBaseProc Method")
	public int[][] updateBatchAllTbcMdBaseProc (final List  tbcMdBaseProcDVOList) {
		
		ArrayList updatetbcMdBaseProcDVOList = new ArrayList();
		ArrayList insertttbcMdBaseProcDVOList = new ArrayList();
		ArrayList deletetbcMdBaseProcDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdBaseProcDVOList.size() ; i++) {
		  TbcMdBaseProcDVO tbcMdBaseProcDVO = (TbcMdBaseProcDVO) tbcMdBaseProcDVOList.get(i);
		  
		  if (tbcMdBaseProcDVO.getSqlAction().equals("C"))
		      insertttbcMdBaseProcDVOList.add(tbcMdBaseProcDVO);
		  else if (tbcMdBaseProcDVO.getSqlAction().equals("U"))
		      updatetbcMdBaseProcDVOList.add(tbcMdBaseProcDVO);
		  else if (tbcMdBaseProcDVO.getSqlAction().equals("D"))
		      deletetbcMdBaseProcDVOList.add(tbcMdBaseProcDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdBaseProcDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdBaseProc(insertttbcMdBaseProcDVOList);
          
      if (updatetbcMdBaseProcDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdBaseProc(updatetbcMdBaseProcDVOList);
      
      if (deletetbcMdBaseProcDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdBaseProc(deletetbcMdBaseProcDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return int
*/
	@LocalName("updateTbcMdBaseProc")
	public int updateTbcMdBaseProc (final TbcMdBaseProcDVO tbcMdBaseProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.updateTbcMdBaseProc.001*/  \n");
			sql.append(" TBC_MD_BASE_PROC \n");
			sql.append(" SET   \n");
			sql.append("        BASE_PROC_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BASE_PROC_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcNm());
							ps.setString(psCount++, tbcMdBaseProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
						}
					}
		);			
	}

/**
* deleteTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return int
*/
	@LocalName("deleteTbcMdBaseProc")
	public int deleteTbcMdBaseProc (final TbcMdBaseProcDVO tbcMdBaseProcDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.deleteTbcMdBaseProc.001*/  \n");
			sql.append(" TBC_MD_BASE_PROC \n");
			sql.append("  WHERE BASE_PROC_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
						}
					}
		);			
	}

/**
* selectTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return TbcMdBaseProcDVO 
*/
	@LocalName("selectTbcMdBaseProc")
	public TbcMdBaseProcDVO selectTbcMdBaseProc (final TbcMdBaseProcDVO tbcMdBaseProcDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.selectTbcMdBaseProc.001*/  \n");
			sql.append("        BASE_PROC_CODE , \n");
			sql.append("        BASE_PROC_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_BASE_PROC \n");
			sql.append("  WHERE BASE_PROC_CODE = ? \n");

		return (TbcMdBaseProcDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdBaseProcDVO returnTbcMdBaseProcDVO = new TbcMdBaseProcDVO();
									returnTbcMdBaseProcDVO.setBaseProcCode(resultSet.getString("BASE_PROC_CODE"));
									returnTbcMdBaseProcDVO.setBaseProcNm(resultSet.getString("BASE_PROC_NM"));
									returnTbcMdBaseProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdBaseProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdBaseProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdBaseProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdBaseProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdBaseProcDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdBaseProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdBaseProc Method")
	public int mergeTbcMdBaseProc (final TbcMdBaseProcDVO tbcMdBaseProcDVO) {
		
		if ( selectTbcMdBaseProc (tbcMdBaseProcDVO) == null) {
			return insertTbcMdBaseProc(tbcMdBaseProcDVO);
		} else {
			return selectUpdateTbcMdBaseProc (tbcMdBaseProcDVO);
		}
	}

	/**
	 * selectUpdateTbcMdBaseProc Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdBaseProc Method")
	public int selectUpdateTbcMdBaseProc (final TbcMdBaseProcDVO tbcMdBaseProcDVO) {
		
		TbcMdBaseProcDVO tmpTbcMdBaseProcDVO =  selectTbcMdBaseProc (tbcMdBaseProcDVO);
		if ( tbcMdBaseProcDVO.getBaseProcCode() != null && !"".equals(tbcMdBaseProcDVO.getBaseProcCode()) ) {
			tmpTbcMdBaseProcDVO.setBaseProcCode(tbcMdBaseProcDVO.getBaseProcCode());
		}		
		if ( tbcMdBaseProcDVO.getBaseProcNm() != null && !"".equals(tbcMdBaseProcDVO.getBaseProcNm()) ) {
			tmpTbcMdBaseProcDVO.setBaseProcNm(tbcMdBaseProcDVO.getBaseProcNm());
		}		
		if ( tbcMdBaseProcDVO.getUseYn() != null && !"".equals(tbcMdBaseProcDVO.getUseYn()) ) {
			tmpTbcMdBaseProcDVO.setUseYn(tbcMdBaseProcDVO.getUseYn());
		}		
		if ( tbcMdBaseProcDVO.getFstRegDt() != null && !"".equals(tbcMdBaseProcDVO.getFstRegDt()) ) {
			tmpTbcMdBaseProcDVO.setFstRegDt(tbcMdBaseProcDVO.getFstRegDt());
		}		
		if ( tbcMdBaseProcDVO.getFstRegerId() != null && !"".equals(tbcMdBaseProcDVO.getFstRegerId()) ) {
			tmpTbcMdBaseProcDVO.setFstRegerId(tbcMdBaseProcDVO.getFstRegerId());
		}		
		if ( tbcMdBaseProcDVO.getFnlUpdDt() != null && !"".equals(tbcMdBaseProcDVO.getFnlUpdDt()) ) {
			tmpTbcMdBaseProcDVO.setFnlUpdDt(tbcMdBaseProcDVO.getFnlUpdDt());
		}		
		if ( tbcMdBaseProcDVO.getFnlUpderId() != null && !"".equals(tbcMdBaseProcDVO.getFnlUpderId()) ) {
			tmpTbcMdBaseProcDVO.setFnlUpderId(tbcMdBaseProcDVO.getFnlUpderId());
		}		
		return updateTbcMdBaseProc (tmpTbcMdBaseProcDVO);
	}

/**
* insertBatchTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return int[]
*/
	@LocalName("insertBatchTbcMdBaseProc")
	public int[] insertBatchTbcMdBaseProc (final List tbcMdBaseProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.insertBatchTbcMdBaseProc.001*/  \n");
			sql.append(" TBC_MD_BASE_PROC (   \n");
			sql.append("        BASE_PROC_CODE , \n");
			sql.append("        BASE_PROC_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBaseProcDVO tbcMdBaseProcDVO = (TbcMdBaseProcDVO)tbcMdBaseProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcNm());
							ps.setString(psCount++, tbcMdBaseProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdBaseProcDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return int[]
*/
	@LocalName("updateBatchTbcMdBaseProc")
	public int[] updateBatchTbcMdBaseProc (final List tbcMdBaseProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.updateBatchTbcMdBaseProc.001*/  \n");
			sql.append(" TBC_MD_BASE_PROC \n");
			sql.append(" SET   \n");
			sql.append("        BASE_PROC_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BASE_PROC_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBaseProcDVO tbcMdBaseProcDVO = (TbcMdBaseProcDVO)tbcMdBaseProcDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcNm());
							ps.setString(psCount++, tbcMdBaseProcDVO.getUseYn());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBaseProcDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
						}
							public int getBatchSize() {
									return tbcMdBaseProcDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdBaseProc Method
* 
* @ref_table TBC_MD_BASE_PROC
* @return int[]
*/
	@LocalName("deleteBatchTbcMdBaseProc")
	public int[] deleteBatchTbcMdBaseProc (final List tbcMdBaseProcDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBaseProcDEM.deleteBatchTbcMdBaseProc.001*/  \n");
			sql.append(" TBC_MD_BASE_PROC \n");
			sql.append("  WHERE BASE_PROC_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBaseProcDVO tbcMdBaseProcDVO = (TbcMdBaseProcDVO)tbcMdBaseProcDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdBaseProcDVO.getBaseProcCode());
						}
							public int getBatchSize() {
									return tbcMdBaseProcDVOList.size();
							}
					}
		);			
	}

	
}