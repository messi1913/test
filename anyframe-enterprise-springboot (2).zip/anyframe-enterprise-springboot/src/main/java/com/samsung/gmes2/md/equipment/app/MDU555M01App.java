package com.samsung.gmes2.md.equipment.app;

public class MDU555M01App {

	/**
	 * Spare Parts정보 목록 초기설정
	 */
	public void initSparePartsInfo(){}

	/**
	 * Spare Parts정보 목록 조회
	 */
	public void listSparePartsInfo(){}

	/**
	 * Spare Parts정보 목록 엑셀 다운로드
	 */
	public void excelSparePartsInfo(){}

	/**
	 * Spare Parts정보 목록 등록/수정 초기설정
	 */
	public void editSparePartsInfo(){}

	/**
	 * Spare Parts정보 목록 저장
	 */
	public void saveSparePartsInfo(){}

}
