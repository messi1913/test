package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdAuditEstiClsfDEM extends AbstractDAO {


/**
* insertTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return int
*/
	@LocalName("insertTbmMdAuditEstiClsf")
	public int insertTbmMdAuditEstiClsf (final TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.insertTbmMdAuditEstiClsf.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_CLSF (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        ESTI_CLSF_CODE , \n");
			sql.append("        ESTI_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfNm());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdAuditEstiClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdAuditEstiClsf Method")
	public int[][] updateBatchAllTbmMdAuditEstiClsf (final List  tbmMdAuditEstiClsfDVOList) {
		
		ArrayList updatetbmMdAuditEstiClsfDVOList = new ArrayList();
		ArrayList insertttbmMdAuditEstiClsfDVOList = new ArrayList();
		ArrayList deletetbmMdAuditEstiClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdAuditEstiClsfDVOList.size() ; i++) {
		  TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO = (TbmMdAuditEstiClsfDVO) tbmMdAuditEstiClsfDVOList.get(i);
		  
		  if (tbmMdAuditEstiClsfDVO.getSqlAction().equals("C"))
		      insertttbmMdAuditEstiClsfDVOList.add(tbmMdAuditEstiClsfDVO);
		  else if (tbmMdAuditEstiClsfDVO.getSqlAction().equals("U"))
		      updatetbmMdAuditEstiClsfDVOList.add(tbmMdAuditEstiClsfDVO);
		  else if (tbmMdAuditEstiClsfDVO.getSqlAction().equals("D"))
		      deletetbmMdAuditEstiClsfDVOList.add(tbmMdAuditEstiClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdAuditEstiClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdAuditEstiClsf(insertttbmMdAuditEstiClsfDVOList);
          
      if (updatetbmMdAuditEstiClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdAuditEstiClsf(updatetbmMdAuditEstiClsfDVOList);
      
      if (deletetbmMdAuditEstiClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdAuditEstiClsf(deletetbmMdAuditEstiClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return int
*/
	@LocalName("updateTbmMdAuditEstiClsf")
	public int updateTbmMdAuditEstiClsf (final TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.updateTbmMdAuditEstiClsf.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        ESTI_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND PROC_GUBUN_CODE = ? \n");
			sql.append("   AND ESTI_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfNm());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
						}
					}
		);			
	}

/**
* deleteTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return int
*/
	@LocalName("deleteTbmMdAuditEstiClsf")
	public int deleteTbmMdAuditEstiClsf (final TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.deleteTbmMdAuditEstiClsf.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_CLSF \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND PROC_GUBUN_CODE = ? \n");
			sql.append("    AND ESTI_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
						}
					}
		);			
	}

/**
* selectTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return TbmMdAuditEstiClsfDVO 
*/
	@LocalName("selectTbmMdAuditEstiClsf")
	public TbmMdAuditEstiClsfDVO selectTbmMdAuditEstiClsf (final TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.selectTbmMdAuditEstiClsf.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        ESTI_CLSF_CODE , \n");
			sql.append("        ESTI_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_AUDIT_ESTI_CLSF \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND PROC_GUBUN_CODE = ? \n");
			sql.append("    AND ESTI_CLSF_CODE = ? \n");

		return (TbmMdAuditEstiClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdAuditEstiClsfDVO returnTbmMdAuditEstiClsfDVO = new TbmMdAuditEstiClsfDVO();
									returnTbmMdAuditEstiClsfDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdAuditEstiClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdAuditEstiClsfDVO.setEstiClsfCode(resultSet.getString("ESTI_CLSF_CODE"));
									returnTbmMdAuditEstiClsfDVO.setEstiClsfNm(resultSet.getString("ESTI_CLSF_NM"));
									returnTbmMdAuditEstiClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdAuditEstiClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdAuditEstiClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdAuditEstiClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdAuditEstiClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdAuditEstiClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdAuditEstiClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdAuditEstiClsf Method")
	public int mergeTbmMdAuditEstiClsf (final TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO) {
		
		if ( selectTbmMdAuditEstiClsf (tbmMdAuditEstiClsfDVO) == null) {
			return insertTbmMdAuditEstiClsf(tbmMdAuditEstiClsfDVO);
		} else {
			return selectUpdateTbmMdAuditEstiClsf (tbmMdAuditEstiClsfDVO);
		}
	}

	/**
	 * selectUpdateTbmMdAuditEstiClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdAuditEstiClsf Method")
	public int selectUpdateTbmMdAuditEstiClsf (final TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO) {
		
		TbmMdAuditEstiClsfDVO tmpTbmMdAuditEstiClsfDVO =  selectTbmMdAuditEstiClsf (tbmMdAuditEstiClsfDVO);
		if ( tbmMdAuditEstiClsfDVO.getGbmCode() != null && !"".equals(tbmMdAuditEstiClsfDVO.getGbmCode()) ) {
			tmpTbmMdAuditEstiClsfDVO.setGbmCode(tbmMdAuditEstiClsfDVO.getGbmCode());
		}		
		if ( tbmMdAuditEstiClsfDVO.getProcGubunCode() != null && !"".equals(tbmMdAuditEstiClsfDVO.getProcGubunCode()) ) {
			tmpTbmMdAuditEstiClsfDVO.setProcGubunCode(tbmMdAuditEstiClsfDVO.getProcGubunCode());
		}		
		if ( tbmMdAuditEstiClsfDVO.getEstiClsfCode() != null && !"".equals(tbmMdAuditEstiClsfDVO.getEstiClsfCode()) ) {
			tmpTbmMdAuditEstiClsfDVO.setEstiClsfCode(tbmMdAuditEstiClsfDVO.getEstiClsfCode());
		}		
		if ( tbmMdAuditEstiClsfDVO.getEstiClsfNm() != null && !"".equals(tbmMdAuditEstiClsfDVO.getEstiClsfNm()) ) {
			tmpTbmMdAuditEstiClsfDVO.setEstiClsfNm(tbmMdAuditEstiClsfDVO.getEstiClsfNm());
		}		
		if ( tbmMdAuditEstiClsfDVO.getUseYn() != null && !"".equals(tbmMdAuditEstiClsfDVO.getUseYn()) ) {
			tmpTbmMdAuditEstiClsfDVO.setUseYn(tbmMdAuditEstiClsfDVO.getUseYn());
		}		
		if ( tbmMdAuditEstiClsfDVO.getFstRegDt() != null && !"".equals(tbmMdAuditEstiClsfDVO.getFstRegDt()) ) {
			tmpTbmMdAuditEstiClsfDVO.setFstRegDt(tbmMdAuditEstiClsfDVO.getFstRegDt());
		}		
		if ( tbmMdAuditEstiClsfDVO.getFstRegerId() != null && !"".equals(tbmMdAuditEstiClsfDVO.getFstRegerId()) ) {
			tmpTbmMdAuditEstiClsfDVO.setFstRegerId(tbmMdAuditEstiClsfDVO.getFstRegerId());
		}		
		if ( tbmMdAuditEstiClsfDVO.getFnlUpdDt() != null && !"".equals(tbmMdAuditEstiClsfDVO.getFnlUpdDt()) ) {
			tmpTbmMdAuditEstiClsfDVO.setFnlUpdDt(tbmMdAuditEstiClsfDVO.getFnlUpdDt());
		}		
		if ( tbmMdAuditEstiClsfDVO.getFnlUpderId() != null && !"".equals(tbmMdAuditEstiClsfDVO.getFnlUpderId()) ) {
			tmpTbmMdAuditEstiClsfDVO.setFnlUpderId(tbmMdAuditEstiClsfDVO.getFnlUpderId());
		}		
		return updateTbmMdAuditEstiClsf (tmpTbmMdAuditEstiClsfDVO);
	}

/**
* insertBatchTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbmMdAuditEstiClsf")
	public int[] insertBatchTbmMdAuditEstiClsf (final List tbmMdAuditEstiClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.insertBatchTbmMdAuditEstiClsf.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_CLSF (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        ESTI_CLSF_CODE , \n");
			sql.append("        ESTI_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO = (TbmMdAuditEstiClsfDVO)tbmMdAuditEstiClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfNm());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdAuditEstiClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbmMdAuditEstiClsf")
	public int[] updateBatchTbmMdAuditEstiClsf (final List tbmMdAuditEstiClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.updateBatchTbmMdAuditEstiClsf.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        ESTI_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND PROC_GUBUN_CODE = ? \n");
			sql.append("   AND ESTI_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO = (TbmMdAuditEstiClsfDVO)tbmMdAuditEstiClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfNm());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getUseYn());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
						}
							public int getBatchSize() {
									return tbmMdAuditEstiClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdAuditEstiClsf Method
* 
* @ref_table TBM_MD_AUDIT_ESTI_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbmMdAuditEstiClsf")
	public int[] deleteBatchTbmMdAuditEstiClsf (final List tbmMdAuditEstiClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdAuditEstiClsfDEM.deleteBatchTbmMdAuditEstiClsf.001*/  \n");
			sql.append(" TBM_MD_AUDIT_ESTI_CLSF \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND PROC_GUBUN_CODE = ? \n");
			sql.append("    AND ESTI_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdAuditEstiClsfDVO tbmMdAuditEstiClsfDVO = (TbmMdAuditEstiClsfDVO)tbmMdAuditEstiClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getGbmCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdAuditEstiClsfDVO.getEstiClsfCode());
						}
							public int getBatchSize() {
									return tbmMdAuditEstiClsfDVOList.size();
							}
					}
		);			
	}

	
}