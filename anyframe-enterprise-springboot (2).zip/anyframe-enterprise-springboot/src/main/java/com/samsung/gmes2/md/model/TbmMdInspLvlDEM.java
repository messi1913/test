package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_INSP_LVL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdInspLvlDEM extends AbstractDAO {


/**
* insertTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return int
*/
	@LocalName("insertTbmMdInspLvl")
	public int insertTbmMdInspLvl (final TbmMdInspLvlDVO tbmMdInspLvlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.insertTbmMdInspLvl.001*/  \n");
			sql.append(" TBM_MD_INSP_LVL (   \n");
			sql.append("        INSP_LVL_CODE , \n");
			sql.append("        SMPL_CHAR_CODE , \n");
			sql.append("        MIN_SIZE , \n");
			sql.append("        MAX_SIZE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMinSize());
							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMaxSize());
							ps.setString(psCount++, tbmMdInspLvlDVO.getUseYn());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdInspLvl Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdInspLvl Method")
	public int[][] updateBatchAllTbmMdInspLvl (final List  tbmMdInspLvlDVOList) {
		
		ArrayList updatetbmMdInspLvlDVOList = new ArrayList();
		ArrayList insertttbmMdInspLvlDVOList = new ArrayList();
		ArrayList deletetbmMdInspLvlDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdInspLvlDVOList.size() ; i++) {
		  TbmMdInspLvlDVO tbmMdInspLvlDVO = (TbmMdInspLvlDVO) tbmMdInspLvlDVOList.get(i);
		  
		  if (tbmMdInspLvlDVO.getSqlAction().equals("C"))
		      insertttbmMdInspLvlDVOList.add(tbmMdInspLvlDVO);
		  else if (tbmMdInspLvlDVO.getSqlAction().equals("U"))
		      updatetbmMdInspLvlDVOList.add(tbmMdInspLvlDVO);
		  else if (tbmMdInspLvlDVO.getSqlAction().equals("D"))
		      deletetbmMdInspLvlDVOList.add(tbmMdInspLvlDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdInspLvlDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdInspLvl(insertttbmMdInspLvlDVOList);
          
      if (updatetbmMdInspLvlDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdInspLvl(updatetbmMdInspLvlDVOList);
      
      if (deletetbmMdInspLvlDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdInspLvl(deletetbmMdInspLvlDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return int
*/
	@LocalName("updateTbmMdInspLvl")
	public int updateTbmMdInspLvl (final TbmMdInspLvlDVO tbmMdInspLvlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.updateTbmMdInspLvl.001*/  \n");
			sql.append(" TBM_MD_INSP_LVL \n");
			sql.append(" SET   \n");
			sql.append("        MIN_SIZE = ? , \n");
			sql.append("        MAX_SIZE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE INSP_LVL_CODE = ? \n");
			sql.append("   AND SMPL_CHAR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMinSize());
							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMaxSize());
							ps.setString(psCount++, tbmMdInspLvlDVO.getUseYn());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
						}
					}
		);			
	}

/**
* deleteTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return int
*/
	@LocalName("deleteTbmMdInspLvl")
	public int deleteTbmMdInspLvl (final TbmMdInspLvlDVO tbmMdInspLvlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.deleteTbmMdInspLvl.001*/  \n");
			sql.append(" TBM_MD_INSP_LVL \n");
			sql.append("  WHERE INSP_LVL_CODE = ? \n");
			sql.append("    AND SMPL_CHAR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
						}
					}
		);			
	}

/**
* selectTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return TbmMdInspLvlDVO 
*/
	@LocalName("selectTbmMdInspLvl")
	public TbmMdInspLvlDVO selectTbmMdInspLvl (final TbmMdInspLvlDVO tbmMdInspLvlDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.selectTbmMdInspLvl.001*/  \n");
			sql.append("        INSP_LVL_CODE , \n");
			sql.append("        SMPL_CHAR_CODE , \n");
			sql.append("        MIN_SIZE , \n");
			sql.append("        MAX_SIZE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_INSP_LVL \n");
			sql.append("  WHERE INSP_LVL_CODE = ? \n");
			sql.append("    AND SMPL_CHAR_CODE = ? \n");

		return (TbmMdInspLvlDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdInspLvlDVO returnTbmMdInspLvlDVO = new TbmMdInspLvlDVO();
									returnTbmMdInspLvlDVO.setInspLvlCode(resultSet.getString("INSP_LVL_CODE"));
									returnTbmMdInspLvlDVO.setSmplCharCode(resultSet.getString("SMPL_CHAR_CODE"));
									returnTbmMdInspLvlDVO.setMinSize(resultSet.getBigDecimal("MIN_SIZE"));
									returnTbmMdInspLvlDVO.setMaxSize(resultSet.getBigDecimal("MAX_SIZE"));
									returnTbmMdInspLvlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdInspLvlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdInspLvlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdInspLvlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdInspLvlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdInspLvlDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdInspLvl Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdInspLvl Method")
	public int mergeTbmMdInspLvl (final TbmMdInspLvlDVO tbmMdInspLvlDVO) {
		
		if ( selectTbmMdInspLvl (tbmMdInspLvlDVO) == null) {
			return insertTbmMdInspLvl(tbmMdInspLvlDVO);
		} else {
			return selectUpdateTbmMdInspLvl (tbmMdInspLvlDVO);
		}
	}

	/**
	 * selectUpdateTbmMdInspLvl Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdInspLvl Method")
	public int selectUpdateTbmMdInspLvl (final TbmMdInspLvlDVO tbmMdInspLvlDVO) {
		
		TbmMdInspLvlDVO tmpTbmMdInspLvlDVO =  selectTbmMdInspLvl (tbmMdInspLvlDVO);
		if ( tbmMdInspLvlDVO.getInspLvlCode() != null && !"".equals(tbmMdInspLvlDVO.getInspLvlCode()) ) {
			tmpTbmMdInspLvlDVO.setInspLvlCode(tbmMdInspLvlDVO.getInspLvlCode());
		}		
		if ( tbmMdInspLvlDVO.getSmplCharCode() != null && !"".equals(tbmMdInspLvlDVO.getSmplCharCode()) ) {
			tmpTbmMdInspLvlDVO.setSmplCharCode(tbmMdInspLvlDVO.getSmplCharCode());
		}		
		if ( tbmMdInspLvlDVO.getMinSize() != null && !"".equals(tbmMdInspLvlDVO.getMinSize()) ) {
			tmpTbmMdInspLvlDVO.setMinSize(tbmMdInspLvlDVO.getMinSize());
		}		
		if ( tbmMdInspLvlDVO.getMaxSize() != null && !"".equals(tbmMdInspLvlDVO.getMaxSize()) ) {
			tmpTbmMdInspLvlDVO.setMaxSize(tbmMdInspLvlDVO.getMaxSize());
		}		
		if ( tbmMdInspLvlDVO.getUseYn() != null && !"".equals(tbmMdInspLvlDVO.getUseYn()) ) {
			tmpTbmMdInspLvlDVO.setUseYn(tbmMdInspLvlDVO.getUseYn());
		}		
		if ( tbmMdInspLvlDVO.getFstRegDt() != null && !"".equals(tbmMdInspLvlDVO.getFstRegDt()) ) {
			tmpTbmMdInspLvlDVO.setFstRegDt(tbmMdInspLvlDVO.getFstRegDt());
		}		
		if ( tbmMdInspLvlDVO.getFstRegerId() != null && !"".equals(tbmMdInspLvlDVO.getFstRegerId()) ) {
			tmpTbmMdInspLvlDVO.setFstRegerId(tbmMdInspLvlDVO.getFstRegerId());
		}		
		if ( tbmMdInspLvlDVO.getFnlUpdDt() != null && !"".equals(tbmMdInspLvlDVO.getFnlUpdDt()) ) {
			tmpTbmMdInspLvlDVO.setFnlUpdDt(tbmMdInspLvlDVO.getFnlUpdDt());
		}		
		if ( tbmMdInspLvlDVO.getFnlUpderId() != null && !"".equals(tbmMdInspLvlDVO.getFnlUpderId()) ) {
			tmpTbmMdInspLvlDVO.setFnlUpderId(tbmMdInspLvlDVO.getFnlUpderId());
		}		
		return updateTbmMdInspLvl (tmpTbmMdInspLvlDVO);
	}

/**
* insertBatchTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return int[]
*/
	@LocalName("insertBatchTbmMdInspLvl")
	public int[] insertBatchTbmMdInspLvl (final List tbmMdInspLvlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.insertBatchTbmMdInspLvl.001*/  \n");
			sql.append(" TBM_MD_INSP_LVL (   \n");
			sql.append("        INSP_LVL_CODE , \n");
			sql.append("        SMPL_CHAR_CODE , \n");
			sql.append("        MIN_SIZE , \n");
			sql.append("        MAX_SIZE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdInspLvlDVO tbmMdInspLvlDVO = (TbmMdInspLvlDVO)tbmMdInspLvlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMinSize());
							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMaxSize());
							ps.setString(psCount++, tbmMdInspLvlDVO.getUseYn());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdInspLvlDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return int[]
*/
	@LocalName("updateBatchTbmMdInspLvl")
	public int[] updateBatchTbmMdInspLvl (final List tbmMdInspLvlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.updateBatchTbmMdInspLvl.001*/  \n");
			sql.append(" TBM_MD_INSP_LVL \n");
			sql.append(" SET   \n");
			sql.append("        MIN_SIZE = ? , \n");
			sql.append("        MAX_SIZE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE INSP_LVL_CODE = ? \n");
			sql.append("   AND SMPL_CHAR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdInspLvlDVO tbmMdInspLvlDVO = (TbmMdInspLvlDVO)tbmMdInspLvlDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMinSize());
							ps.setBigDecimal(psCount++, tbmMdInspLvlDVO.getMaxSize());
							ps.setString(psCount++, tbmMdInspLvlDVO.getUseYn());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdInspLvlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
						}
							public int getBatchSize() {
									return tbmMdInspLvlDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdInspLvl Method
* 
* @ref_table TBM_MD_INSP_LVL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdInspLvl")
	public int[] deleteBatchTbmMdInspLvl (final List tbmMdInspLvlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdInspLvlDEM.deleteBatchTbmMdInspLvl.001*/  \n");
			sql.append(" TBM_MD_INSP_LVL \n");
			sql.append("  WHERE INSP_LVL_CODE = ? \n");
			sql.append("    AND SMPL_CHAR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdInspLvlDVO tbmMdInspLvlDVO = (TbmMdInspLvlDVO)tbmMdInspLvlDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdInspLvlDVO.getInspLvlCode());
							ps.setString(psCount++, tbmMdInspLvlDVO.getSmplCharCode());
						}
							public int getBatchSize() {
									return tbmMdInspLvlDVOList.size();
							}
					}
		);			
	}

	
}