package com.samsung.gmes2.md.equipment.app;

public class MDU531M01App {

	/**
	 * 설비운영정보 목록 초기설정
	 */
	public void initEquipIdInfo(){}

	/**
	 * 설비운영정보 목록 조회
	 */
	public void listEquipIdInfo(){}

	/**
	 * 설비운영정보 목록 엑셀 다운로드
	 */
	public void excelEquipIdInfo(){}

	/**
	 * 설비운영정보 목록 저장
	 */
	public void saveEquipIdInfo(){}

}
