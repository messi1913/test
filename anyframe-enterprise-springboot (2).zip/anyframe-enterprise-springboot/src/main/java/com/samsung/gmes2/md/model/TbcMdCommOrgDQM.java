package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author hkw
*/
@Stereotype(Stereotype.Dao)
public class TbcMdCommOrgDQM extends AbstractDAO {


/**
* 
*
* SELECT 
* 	COMM_ORG_CODE, 
* 	HRNK_COMM_ORG_CODE, 
* 	COMM_ORG_TYPE_CODE, 
* 	COMM_ORG_CODE_NM, 
* 	COMM_ORG_CODE_DESC, 
* 	CODE_SORT_PRIOR, 
* 	N1_CODE_ATTR_CONT, 
* 	CIS_MAPP_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_ORG 
* WHERE 1=1 
* #if($commOrgCode) 
* AND COMM_ORG_CODE = :commOrgCode 
* #end
* #if($hrnkCommOrgCode) 
* AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode 
* #end 
* #if($commOrgTypeCode) 
* AND COMM_ORG_TYPE_CODE = :commOrgTypeCode 
* #end 
* #if($commOrgCodeNm) 
* AND COMM_ORG_CODE_NM = :commOrgCodeNm 
* #end 
* #if($commOrgCodeDesc) 
* AND COMM_ORG_CODE_DESC = :commOrgCodeDesc 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($n1CodeAttrCont) 
* AND N1_CODE_ATTR_CONT = :n1CodeAttrCont 
* #end 
* #if($cisMappCode) 
* AND CIS_MAPP_CODE = :cisMappCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	COMM_ORG_CODE,  \n");
			sql.append(" 	HRNK_COMM_ORG_CODE,  \n");
			sql.append(" 	COMM_ORG_TYPE_CODE,  \n");
			sql.append(" 	COMM_ORG_CODE_NM,  \n");
			sql.append(" 	COMM_ORG_CODE_DESC,  \n");
			sql.append(" 	CODE_SORT_PRIOR,  \n");
			sql.append(" 	N1_CODE_ATTR_CONT,  \n");
			sql.append(" 	CIS_MAPP_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($commOrgCode)  \n");
			sql.append(" AND COMM_ORG_CODE = :commOrgCode  \n");
			sql.append(" #end \n");
			sql.append(" #if($hrnkCommOrgCode)  \n");
			sql.append(" AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgTypeCode)  \n");
			sql.append(" AND COMM_ORG_TYPE_CODE = :commOrgTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeNm)  \n");
			sql.append(" AND COMM_ORG_CODE_NM = :commOrgCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeDesc)  \n");
			sql.append(" AND COMM_ORG_CODE_DESC = :commOrgCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($n1CodeAttrCont)  \n");
			sql.append(" AND N1_CODE_ATTR_CONT = :n1CodeAttrCont  \n");
			sql.append(" #end  \n");
			sql.append(" #if($cisMappCode)  \n");
			sql.append(" AND CIS_MAPP_CODE = :cisMappCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdCommOrgDQM.dListPage000.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "commOrgCode", "hrnkCommOrgCode", "commOrgTypeCode", "commOrgCodeNm", "commOrgCodeDesc", "codeSortPrior", "n1CodeAttrCont", "cisMappCode", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("commOrgCode") != null && !"".equals(inputMap.get("commOrgCode"))) {	
					data.put("commOrgCode", inputMap.get("commOrgCode"));
				}
				if (inputMap.get("hrnkCommOrgCode") != null && !"".equals(inputMap.get("hrnkCommOrgCode"))) {	
					data.put("hrnkCommOrgCode", inputMap.get("hrnkCommOrgCode"));
				}
				if (inputMap.get("commOrgTypeCode") != null && !"".equals(inputMap.get("commOrgTypeCode"))) {	
					data.put("commOrgTypeCode", inputMap.get("commOrgTypeCode"));
				}
				if (inputMap.get("commOrgCodeNm") != null && !"".equals(inputMap.get("commOrgCodeNm"))) {	
					data.put("commOrgCodeNm", inputMap.get("commOrgCodeNm"));
				}
				if (inputMap.get("commOrgCodeDesc") != null && !"".equals(inputMap.get("commOrgCodeDesc"))) {	
					data.put("commOrgCodeDesc", inputMap.get("commOrgCodeDesc"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("n1CodeAttrCont") != null && !"".equals(inputMap.get("n1CodeAttrCont"))) {	
					data.put("n1CodeAttrCont", inputMap.get("n1CodeAttrCont"));
				}
				if (inputMap.get("cisMappCode") != null && !"".equals(inputMap.get("cisMappCode"))) {	
					data.put("cisMappCode", inputMap.get("cisMappCode"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommOrgDVO returnTbcMdCommOrgDVO = new TbcMdCommOrgDVO();
									returnTbcMdCommOrgDVO.setCommOrgCode(resultSet.getString("COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setHrnkCommOrgCode(resultSet.getString("HRNK_COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgTypeCode(resultSet.getString("COMM_ORG_TYPE_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgCodeNm(resultSet.getString("COMM_ORG_CODE_NM"));
									returnTbcMdCommOrgDVO.setCommOrgCodeDesc(resultSet.getString("COMM_ORG_CODE_DESC"));
									returnTbcMdCommOrgDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommOrgDVO.setN1CodeAttrCont(resultSet.getString("N1_CODE_ATTR_CONT"));
									returnTbcMdCommOrgDVO.setCisMappCode(resultSet.getString("CIS_MAPP_CODE"));
									returnTbcMdCommOrgDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	COMM_ORG_CODE, 
* 	HRNK_COMM_ORG_CODE, 
* 	COMM_ORG_TYPE_CODE, 
* 	COMM_ORG_CODE_NM, 
* 	CIS_MAPP_CODE, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_ORG 
* WHERE 1=1 
* #if($commOrgCode) 
* AND COMM_ORG_CODE = :commOrgCode 
* #end
* #if($hrnkCommOrgCode) 
* AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode 
* #end 
* #if($commOrgTypeCode) 
* AND COMM_ORG_TYPE_CODE = :commOrgTypeCode 
* #end 
* #if($commOrgCodeNm) 
* AND COMM_ORG_CODE_NM = :commOrgCodeNm 
* #end 
* #if($commOrgCodeDesc) 
* AND COMM_ORG_CODE_DESC = :commOrgCodeDesc 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($n1CodeAttrCont) 
* AND N1_CODE_ATTR_CONT = :n1CodeAttrCont 
* #end 
* #if($cisMappCode) 
* AND CIS_MAPP_CODE = :cisMappCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	COMM_ORG_CODE,  \n");
			sql.append(" 	HRNK_COMM_ORG_CODE,  \n");
			sql.append(" 	COMM_ORG_TYPE_CODE,  \n");
			sql.append(" 	COMM_ORG_CODE_NM,  \n");
			sql.append(" 	CIS_MAPP_CODE,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($commOrgCode)  \n");
			sql.append(" AND COMM_ORG_CODE = :commOrgCode  \n");
			sql.append(" #end \n");
			sql.append(" #if($hrnkCommOrgCode)  \n");
			sql.append(" AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgTypeCode)  \n");
			sql.append(" AND COMM_ORG_TYPE_CODE = :commOrgTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeNm)  \n");
			sql.append(" AND COMM_ORG_CODE_NM = :commOrgCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeDesc)  \n");
			sql.append(" AND COMM_ORG_CODE_DESC = :commOrgCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($n1CodeAttrCont)  \n");
			sql.append(" AND N1_CODE_ATTR_CONT = :n1CodeAttrCont  \n");
			sql.append(" #end  \n");
			sql.append(" #if($cisMappCode)  \n");
			sql.append(" AND CIS_MAPP_CODE = :cisMappCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdCommOrgDQM.dListPage001.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "commOrgCode", "hrnkCommOrgCode", "commOrgTypeCode", "commOrgCodeNm", "commOrgCodeDesc", "codeSortPrior", "n1CodeAttrCont", "cisMappCode", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("commOrgCode") != null && !"".equals(inputMap.get("commOrgCode"))) {	
					data.put("commOrgCode", inputMap.get("commOrgCode"));
				}
				if (inputMap.get("hrnkCommOrgCode") != null && !"".equals(inputMap.get("hrnkCommOrgCode"))) {	
					data.put("hrnkCommOrgCode", inputMap.get("hrnkCommOrgCode"));
				}
				if (inputMap.get("commOrgTypeCode") != null && !"".equals(inputMap.get("commOrgTypeCode"))) {	
					data.put("commOrgTypeCode", inputMap.get("commOrgTypeCode"));
				}
				if (inputMap.get("commOrgCodeNm") != null && !"".equals(inputMap.get("commOrgCodeNm"))) {	
					data.put("commOrgCodeNm", inputMap.get("commOrgCodeNm"));
				}
				if (inputMap.get("commOrgCodeDesc") != null && !"".equals(inputMap.get("commOrgCodeDesc"))) {	
					data.put("commOrgCodeDesc", inputMap.get("commOrgCodeDesc"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("n1CodeAttrCont") != null && !"".equals(inputMap.get("n1CodeAttrCont"))) {	
					data.put("n1CodeAttrCont", inputMap.get("n1CodeAttrCont"));
				}
				if (inputMap.get("cisMappCode") != null && !"".equals(inputMap.get("cisMappCode"))) {	
					data.put("cisMappCode", inputMap.get("cisMappCode"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommOrgDVO returnTbcMdCommOrgDVO = new TbcMdCommOrgDVO();
									returnTbcMdCommOrgDVO.setCommOrgCode(resultSet.getString("COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setHrnkCommOrgCode(resultSet.getString("HRNK_COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgTypeCode(resultSet.getString("COMM_ORG_TYPE_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgCodeNm(resultSet.getString("COMM_ORG_CODE_NM"));
									returnTbcMdCommOrgDVO.setCisMappCode(resultSet.getString("CIS_MAPP_CODE"));
									returnTbcMdCommOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
* 
*
* SELECT 
* 	COMM_ORG_CODE, 
* 	HRNK_COMM_ORG_CODE, 
* 	COMM_ORG_TYPE_CODE, 
* 	COMM_ORG_CODE_NM, 
* 	COMM_ORG_CODE_DESC, 
* 	CODE_SORT_PRIOR, 
* 	N1_CODE_ATTR_CONT, 
* 	CIS_MAPP_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_ORG 
* WHERE 1=1 
* #if($commOrgCode) 
* AND COMM_ORG_CODE = :commOrgCode 
* #end
* #if($hrnkCommOrgCode) 
* AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode 
* #end 
* #if($commOrgTypeCode) 
* AND COMM_ORG_TYPE_CODE = :commOrgTypeCode 
* #end 
* #if($commOrgCodeNm) 
* AND COMM_ORG_CODE_NM = :commOrgCodeNm 
* #end 
* #if($commOrgCodeDesc) 
* AND COMM_ORG_CODE_DESC = :commOrgCodeDesc 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($n1CodeAttrCont) 
* AND N1_CODE_ATTR_CONT = :n1CodeAttrCont 
* #end 
* #if($cisMappCode) 
* AND CIS_MAPP_CODE = :cisMappCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	COMM_ORG_CODE,  \n");
			sql.append(" 	HRNK_COMM_ORG_CODE,  \n");
			sql.append(" 	COMM_ORG_TYPE_CODE,  \n");
			sql.append(" 	COMM_ORG_CODE_NM,  \n");
			sql.append(" 	COMM_ORG_CODE_DESC,  \n");
			sql.append(" 	CODE_SORT_PRIOR,  \n");
			sql.append(" 	N1_CODE_ATTR_CONT,  \n");
			sql.append(" 	CIS_MAPP_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($commOrgCode)  \n");
			sql.append(" AND COMM_ORG_CODE = :commOrgCode  \n");
			sql.append(" #end \n");
			sql.append(" #if($hrnkCommOrgCode)  \n");
			sql.append(" AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgTypeCode)  \n");
			sql.append(" AND COMM_ORG_TYPE_CODE = :commOrgTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeNm)  \n");
			sql.append(" AND COMM_ORG_CODE_NM = :commOrgCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeDesc)  \n");
			sql.append(" AND COMM_ORG_CODE_DESC = :commOrgCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($n1CodeAttrCont)  \n");
			sql.append(" AND N1_CODE_ATTR_CONT = :n1CodeAttrCont  \n");
			sql.append(" #end  \n");
			sql.append(" #if($cisMappCode)  \n");
			sql.append(" AND CIS_MAPP_CODE = :cisMappCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdCommOrgDQM.dListPageRowCount000.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "commOrgCode", "hrnkCommOrgCode", "commOrgTypeCode", "commOrgCodeNm", "commOrgCodeDesc", "codeSortPrior", "n1CodeAttrCont", "cisMappCode", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("commOrgCode") != null && !"".equals(inputMap.get("commOrgCode"))) {	
					data.put("commOrgCode", inputMap.get("commOrgCode"));
				}
				if (inputMap.get("hrnkCommOrgCode") != null && !"".equals(inputMap.get("hrnkCommOrgCode"))) {	
					data.put("hrnkCommOrgCode", inputMap.get("hrnkCommOrgCode"));
				}
				if (inputMap.get("commOrgTypeCode") != null && !"".equals(inputMap.get("commOrgTypeCode"))) {	
					data.put("commOrgTypeCode", inputMap.get("commOrgTypeCode"));
				}
				if (inputMap.get("commOrgCodeNm") != null && !"".equals(inputMap.get("commOrgCodeNm"))) {	
					data.put("commOrgCodeNm", inputMap.get("commOrgCodeNm"));
				}
				if (inputMap.get("commOrgCodeDesc") != null && !"".equals(inputMap.get("commOrgCodeDesc"))) {	
					data.put("commOrgCodeDesc", inputMap.get("commOrgCodeDesc"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("n1CodeAttrCont") != null && !"".equals(inputMap.get("n1CodeAttrCont"))) {	
					data.put("n1CodeAttrCont", inputMap.get("n1CodeAttrCont"));
				}
				if (inputMap.get("cisMappCode") != null && !"".equals(inputMap.get("cisMappCode"))) {	
					data.put("cisMappCode", inputMap.get("cisMappCode"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommOrgDVO returnTbcMdCommOrgDVO = new TbcMdCommOrgDVO();
									returnTbcMdCommOrgDVO.setCommOrgCode(resultSet.getString("COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setHrnkCommOrgCode(resultSet.getString("HRNK_COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgTypeCode(resultSet.getString("COMM_ORG_TYPE_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgCodeNm(resultSet.getString("COMM_ORG_CODE_NM"));
									returnTbcMdCommOrgDVO.setCommOrgCodeDesc(resultSet.getString("COMM_ORG_CODE_DESC"));
									returnTbcMdCommOrgDVO.setCodeSortPrior(resultSet.getBigDecimal("CODE_SORT_PRIOR"));
									returnTbcMdCommOrgDVO.setN1CodeAttrCont(resultSet.getString("N1_CODE_ATTR_CONT"));
									returnTbcMdCommOrgDVO.setCisMappCode(resultSet.getString("CIS_MAPP_CODE"));
									returnTbcMdCommOrgDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdCommOrgDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdCommOrgDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdCommOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
* 
*
* SELECT 
* 	COMM_ORG_CODE, 
* 	HRNK_COMM_ORG_CODE, 
* 	COMM_ORG_TYPE_CODE, 
* 	COMM_ORG_CODE_NM, 
* 	CIS_MAPP_CODE, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_COMM_ORG 
* WHERE 1=1 
* #if($commOrgCode) 
* AND COMM_ORG_CODE = :commOrgCode 
* #end
* #if($hrnkCommOrgCode) 
* AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode 
* #end 
* #if($commOrgTypeCode) 
* AND COMM_ORG_TYPE_CODE = :commOrgTypeCode 
* #end 
* #if($commOrgCodeNm) 
* AND COMM_ORG_CODE_NM = :commOrgCodeNm 
* #end 
* #if($commOrgCodeDesc) 
* AND COMM_ORG_CODE_DESC = :commOrgCodeDesc 
* #end 
* #if($codeSortPrior) 
* AND CODE_SORT_PRIOR = :codeSortPrior 
* #end 
* #if($n1CodeAttrCont) 
* AND N1_CODE_ATTR_CONT = :n1CodeAttrCont 
* #end 
* #if($cisMappCode) 
* AND CIS_MAPP_CODE = :cisMappCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	COMM_ORG_CODE,  \n");
			sql.append(" 	HRNK_COMM_ORG_CODE,  \n");
			sql.append(" 	COMM_ORG_TYPE_CODE,  \n");
			sql.append(" 	COMM_ORG_CODE_NM,  \n");
			sql.append(" 	CIS_MAPP_CODE,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_COMM_ORG  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($commOrgCode)  \n");
			sql.append(" AND COMM_ORG_CODE = :commOrgCode  \n");
			sql.append(" #end \n");
			sql.append(" #if($hrnkCommOrgCode)  \n");
			sql.append(" AND HRNK_COMM_ORG_CODE = :hrnkCommOrgCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgTypeCode)  \n");
			sql.append(" AND COMM_ORG_TYPE_CODE = :commOrgTypeCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeNm)  \n");
			sql.append(" AND COMM_ORG_CODE_NM = :commOrgCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($commOrgCodeDesc)  \n");
			sql.append(" AND COMM_ORG_CODE_DESC = :commOrgCodeDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($codeSortPrior)  \n");
			sql.append(" AND CODE_SORT_PRIOR = :codeSortPrior  \n");
			sql.append(" #end  \n");
			sql.append(" #if($n1CodeAttrCont)  \n");
			sql.append(" AND N1_CODE_ATTR_CONT = :n1CodeAttrCont  \n");
			sql.append(" #end  \n");
			sql.append(" #if($cisMappCode)  \n");
			sql.append(" AND CIS_MAPP_CODE = :cisMappCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdCommOrgDQM.dListPageRowCount001.001 */ \n");

		Properties  data =  new Properties();
		if ( inputMap != null) {
			int inputSize = countMap(inputMap , new String[] { "commOrgCode", "hrnkCommOrgCode", "commOrgTypeCode", "commOrgCodeNm", "commOrgCodeDesc", "codeSortPrior", "n1CodeAttrCont", "cisMappCode", "useYn", "fstRegDt", "fstRegerId", "fnlUpdDt", "fnlUpderId"});
			if (inputSize > 0) {
				if (inputMap.get("commOrgCode") != null && !"".equals(inputMap.get("commOrgCode"))) {	
					data.put("commOrgCode", inputMap.get("commOrgCode"));
				}
				if (inputMap.get("hrnkCommOrgCode") != null && !"".equals(inputMap.get("hrnkCommOrgCode"))) {	
					data.put("hrnkCommOrgCode", inputMap.get("hrnkCommOrgCode"));
				}
				if (inputMap.get("commOrgTypeCode") != null && !"".equals(inputMap.get("commOrgTypeCode"))) {	
					data.put("commOrgTypeCode", inputMap.get("commOrgTypeCode"));
				}
				if (inputMap.get("commOrgCodeNm") != null && !"".equals(inputMap.get("commOrgCodeNm"))) {	
					data.put("commOrgCodeNm", inputMap.get("commOrgCodeNm"));
				}
				if (inputMap.get("commOrgCodeDesc") != null && !"".equals(inputMap.get("commOrgCodeDesc"))) {	
					data.put("commOrgCodeDesc", inputMap.get("commOrgCodeDesc"));
				}
				if (inputMap.get("codeSortPrior") != null && !"".equals(inputMap.get("codeSortPrior"))) {	
					data.put("codeSortPrior", inputMap.get("codeSortPrior"));
				}
				if (inputMap.get("n1CodeAttrCont") != null && !"".equals(inputMap.get("n1CodeAttrCont"))) {	
					data.put("n1CodeAttrCont", inputMap.get("n1CodeAttrCont"));
				}
				if (inputMap.get("cisMappCode") != null && !"".equals(inputMap.get("cisMappCode"))) {	
					data.put("cisMappCode", inputMap.get("cisMappCode"));
				}
				if (inputMap.get("useYn") != null && !"".equals(inputMap.get("useYn"))) {	
					data.put("useYn", inputMap.get("useYn"));
				}
				if (inputMap.get("fstRegDt") != null && !"".equals(inputMap.get("fstRegDt"))) {	
					data.put("fstRegDt", inputMap.get("fstRegDt"));
				}
				if (inputMap.get("fstRegerId") != null && !"".equals(inputMap.get("fstRegerId"))) {	
					data.put("fstRegerId", inputMap.get("fstRegerId"));
				}
				if (inputMap.get("fnlUpdDt") != null && !"".equals(inputMap.get("fnlUpdDt"))) {	
					data.put("fnlUpdDt", inputMap.get("fnlUpdDt"));
				}
				if (inputMap.get("fnlUpderId") != null && !"".equals(inputMap.get("fnlUpderId"))) {	
					data.put("fnlUpderId", inputMap.get("fnlUpderId"));
				}
 			}	
		}
		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , data);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , data ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdCommOrgDVO returnTbcMdCommOrgDVO = new TbcMdCommOrgDVO();
									returnTbcMdCommOrgDVO.setCommOrgCode(resultSet.getString("COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setHrnkCommOrgCode(resultSet.getString("HRNK_COMM_ORG_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgTypeCode(resultSet.getString("COMM_ORG_TYPE_CODE"));
									returnTbcMdCommOrgDVO.setCommOrgCodeNm(resultSet.getString("COMM_ORG_CODE_NM"));
									returnTbcMdCommOrgDVO.setCisMappCode(resultSet.getString("CIS_MAPP_CODE"));
									returnTbcMdCommOrgDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdCommOrgDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdCommOrgDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}