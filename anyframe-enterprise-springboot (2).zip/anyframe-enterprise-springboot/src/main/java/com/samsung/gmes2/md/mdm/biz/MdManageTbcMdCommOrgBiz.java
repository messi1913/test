/**
 * <PRE>
 * System Name : MD
 * Business Name : MDM
 * Class Name : MdManageTbcMdCommOrgBiz.java
 * Description : 마스터 테이블 TbcMdCommCode에 대한 CRUD 컴포넌트
 * Modification History
 *          수정일              수정자          수정내용
 *    -----------------------------------------------------
 *    2011.07.21                호건웅           최초 생성    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;
import com.samsung.gmes2.md.cmm.MdConstants;

/**
 * MdManageTbcMdCommOrgBiz - 테이블 TbcMdCommOrg에서 권역, 국가, 법인, 사업장, GBM 코드 데이터에 대한 CRUD연산을 수행 - 권역코드: REGION 국가코드: NATION 법인코드: CORP 사업장코드: FCT GBM코드: GBM
 * 
 * @name_ko 공통 조직 비즈 클래스
 * @author 호건웅
 */

public class MdManageTbcMdCommOrgBiz
{

    /**
     * 각 코드별 정보를 생성하기 위한 공통 메서드.
     * 
     * @name_ko 각 코드별 정보 생성
     * @param 생성하려는
     *            각 코드별 정보
     * @return 생성된 각 코드별 정보
     */
    private TbcMdCommOrgDVO createNewTbcMdCommOrgRow( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_do_start 참조 무결성 검사
         * @fd_id 0001
         --------------------------------------------------*/
        //TODO

        // 무결성 위반이 있을 경우 예외 발생

        checkIntegrityConstraint( inputDvo );
        /*--------------------------------------------------
         * @fd_do_end 0001
         --------------------------------------------------*/
        // 아니면 데이터 생성		
        return CrudUtil.create( inputDvo );
    }

    /**
     * 권역 코드데이터 정보를 생성한다.
     * 
     * @name_ko 권역 코드데이터 정보 생성
     * @param 생성할
     *            권역 코드데이터 정보
     * @return 생성된 권역 코드데이터 정보
     */
    public TbcMdCommOrgDVO createNewRegionCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * 
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 권역 코드로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.REGION_CODE );
        }
        return createNewTbcMdCommOrgRow( inputDvo );
    }

    /**
     * 국가 코드데이터 정보를 생성한다.
     * 
     * @name_ko 국가 코드데이터 정보 생성
     * @param 생성할
     *            국가 코드데이터 정보
     * @return 생성된 국가 코드데이터 정보
     */
    public TbcMdCommOrgDVO createNewNationCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {

        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 국가 코드로 setting		 
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.NATION_CODE );
        }
        return createNewTbcMdCommOrgRow( inputDvo );
    }

    /**
     * 법인 코드데이터 정보를 생성한다.
     * 
     * @name_ko 법인 코드데이터 정보 생성
     * @param 생성할
     *            법인 코드데이터 정보
     * @return 생성된 법인 코드데이터 정보
     */
    public TbcMdCommOrgDVO createNewCorpCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 법인 코드로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.CORP_CODE );
        }
        return createNewTbcMdCommOrgRow( inputDvo );
    }

    /**
     * 사업장 코드데이터 정보를 생성한다.
     * 
     * @name_ko 사업장 코드데이터 정보 생성
     * @param 생성할
     *            사업장 코드데이터 정보
     * @return 생성된 사업장 코드데이터 정보
     */
    public TbcMdCommOrgDVO createNewFctCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 사업장 코드로 setting		
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.FCT_CODE );
        }
        return createNewTbcMdCommOrgRow( inputDvo );
    }

    /**
     * GBM 코드데이터 정보를 생성한다.
     * 
     * @name_ko GBM 코드데이터 정보 생성
     * @param 생성할
     *            GBM 코드데이터 정보
     * @return 생성된 GBM 코드데이터 정보
     */
    public TbcMdCommOrgDVO createNewGbmCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 GBM으로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.GBM_CODE );
        }
        return createNewTbcMdCommOrgRow( inputDvo );
    }

    /**
     * 코드데이터 정보를 삭제한다.
     * 
     * @name_ko 코드데이터 정보 삭제
     * @param 삭제할
     *            코드데이터 정보
     * @return 삭제된 코드데이터 정보
     */
    public TbcMdCommOrgDVO deleteTbcMdCommOrgRow( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        return CrudUtil.delete( inputDvo );
    }

    /**
     * 코드데이터 정보를 수정한다.
     * 
     * @name_ko 코드데이터 정보 수정
     * @param 수정할
     *            코드데이터 정보
     * @return 수정된 코드데이터 정보
     */
    public TbcMdCommOrgDVO updateTbcMdCommOrgRow( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_do_start 참조 무결성 검사
         * 무결성 위반이 있을 경우 예외 발생		
         * @fd_id 0001
         --------------------------------------------------*/
        //TODO
        checkIntegrityConstraint( inputDvo );
        /*--------------------------------------------------
         * @fd_do_end 0001
         --------------------------------------------------*/
        // 아니면 데이터 수정
        return CrudUtil.update( inputDvo );
    }

    /**
     * 코드데이터 정보를 한건 조회한다.
     * 
     * @name_ko 코드데이터 정보 단건 조회
     * @param 단건
     *            조회할 코드데이터 정보
     * @return 단건 조회된 코드데이터 정보
     */
    public TbcMdCommOrgDVO getTbcMdCommOrgRow( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        return CrudUtil.get( inputDvo );
    }

    /**
     * 전체 코드데이터 정보를 조회한다.
     * 
     * @name_ko 전체 코드데이터 정보 조회
     * @param 전체
     *            코드데이터 정보
     * @return 전체 코드데이터 정보 list
     */
    public List<TbcMdCommOrgDVO> listTbcMdCommOrg( ) throws Exception
    {
        return listCodeDataByCommOrgTypeCode( null );
    }

    /**
     * 국가 코드데이터 정보를 조회한다.
     * 
     * @name_ko 국가 코드데이터 정보 조회
     * @param 국가
     *            코드데이터 정보
     * @return 국가 코드데이터 정보 list
     */
    public List listNationCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 국가 코드로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.NATION_CODE );
        }
        return listCodeDataByCommOrgTypeCode( inputDvo );
    }

    /**
     * 권역 코드데이터 정보를 조회한다.
     * 
     * @name_ko 권역 코드데이터 정보 조회
     * @param 권역
     *            코드데이터 정보
     * @return 권역 코드데이터 정보 list
     */
    public List listRegionCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 권역 코드로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.REGION_CODE );
        }
        return listCodeDataByCommOrgTypeCode( inputDvo );
    }

    /**
     * 법인 코드데이터 정보를 조회한다.
     * 
     * @name_ko 법인 코드데이터 정보 조회
     * @param 법인
     *            코드데이터 정보
     * @return 법인 코드데이터 정보 list
     */
    public List listCorpCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 법인 코드로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.CORP_CODE );
        }
        return listCodeDataByCommOrgTypeCode( inputDvo );
    }

    /**
     * 사업장 코드데이터 정보를 조회한다.
     * 
     * @name_ko 사업장 코드데이터 정보 조회
     * @param 사업장
     *            코드데이터 정보
     * @return 사업장 코드데이터 정보 list
     */
    public List listFctCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 사업장 코드로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.FCT_CODE );
        }
        return listCodeDataByCommOrgTypeCode( inputDvo );
    }

    /**
     * GBM 코드데이터 정보를 조회한다.
     * 
     * @name_ko GBM 코드데이터 정보 조회
     * @param GBM
     *            코드데이터 정보 조건
     * @return GBM 코드데이터 정보 list
     */
    public List listGbmCodeData( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*--------------------------------------------------
         * @fd_if null 데이터가 입력됬다면 CrudUtil에서 예외처리,
         * null 데이터가 아니면 typeCode를 GBM으로 setting
         * @fd_id 0001
         --------------------------------------------------*/
        if ( inputDvo != null )
        {
            inputDvo.setCommOrgTypeCode( MdConstants.GBM_CODE );
        }
        return listCodeDataByCommOrgTypeCode( inputDvo );
    }

    /**
     * 코드데이터 정보를 조회를 위한 공통 메서드.
     * 
     * @name_ko 코드데이터 정보를 조회를 위한 공통 메서드
     * @param 코드데이터
     *            조회 조건
     * @return 코드데이터 정보 list
     */
    private List<TbcMdCommOrgDVO> listCodeDataByCommOrgTypeCode( TbcMdCommOrgDVO inputDvo ) throws Exception
    {
        /*
         * 조회 결과 리스트의 사이즈가 0이면 null 값을, 0보다 크면 리스트를 리턴
         */
        List resultList = CrudUtil.list0( TbcMdCommOrgDVO.class, inputDvo, 0, 0 );
        if ( resultList.size( ) > 0 )
        {
            return resultList;
        }
        return null;
    }

    /**
     * 참조 무결성을 체크하기 위한 메서드.
     * 
     * @name_ko TbcMdCommOrgDVO가 참조하는 테이블과 무결성 제약 위반 여부를 판단하는 메서드
     * @param 입력
     *            (수정) 코드 데이터
     * @return 없음
     */
    private void checkIntegrityConstraint( TbcMdCommOrgDVO inputDvo ) throws Exception
    {

        TbcMdCommOrgDVO tbcMdCommOrgDVO = new TbcMdCommOrgDVO( );
        TbcMdCommCodeDVO tbcMdCommCodeDVO = new TbcMdCommCodeDVO( );
        /*
         * 등록(수정)하려는 데이터 중 상위 공통 조직 코드는 테이블 TbcMdCommOrg의 공통 조직 코드에 기 등록되있어야 한다
         *  
         */
        BaseUtil.populate( inputDvo, tbcMdCommOrgDVO, "hrnkCommOrgCode:commOrgCode" );
        BaseUtil.checkFound( tbcMdCommOrgDVO );
        /*
         * 등록(수정)하려는 데이터 중 공통 조직 유형 코드는 데이블TbcMdCommCode의 공통 조직 유형 코드에 기 등록되있어야 한다
         *  
         */
        BaseUtil.populate( inputDvo, tbcMdCommCodeDVO, "commOrgTypeCode:typeCode" );
        BaseUtil.checkFound( tbcMdCommCodeDVO );
    }
}