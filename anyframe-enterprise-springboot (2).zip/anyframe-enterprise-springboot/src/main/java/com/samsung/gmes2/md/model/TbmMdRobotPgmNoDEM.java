package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_ROBOT_PGM_NO
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdRobotPgmNoDEM extends AbstractDAO {


/**
* insertTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return int
*/
	@LocalName("insertTbmMdRobotPgmNo")
	public int insertTbmMdRobotPgmNo (final TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.insertTbmMdRobotPgmNo.001*/  \n");
			sql.append(" TBM_MD_ROBOT_PGM_NO (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        PGM_NO , \n");
			sql.append("        MAC_LABEL_PRT_YN , \n");
			sql.append("        BUYER_OUTP_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPgmNo());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMacLabelPrtYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getBuyerOutpYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getUseYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdRobotPgmNo Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdRobotPgmNo Method")
	public int[][] updateBatchAllTbmMdRobotPgmNo (final List  tbmMdRobotPgmNoDVOList) {
		
		ArrayList updatetbmMdRobotPgmNoDVOList = new ArrayList();
		ArrayList insertttbmMdRobotPgmNoDVOList = new ArrayList();
		ArrayList deletetbmMdRobotPgmNoDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdRobotPgmNoDVOList.size() ; i++) {
		  TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO = (TbmMdRobotPgmNoDVO) tbmMdRobotPgmNoDVOList.get(i);
		  
		  if (tbmMdRobotPgmNoDVO.getSqlAction().equals("C"))
		      insertttbmMdRobotPgmNoDVOList.add(tbmMdRobotPgmNoDVO);
		  else if (tbmMdRobotPgmNoDVO.getSqlAction().equals("U"))
		      updatetbmMdRobotPgmNoDVOList.add(tbmMdRobotPgmNoDVO);
		  else if (tbmMdRobotPgmNoDVO.getSqlAction().equals("D"))
		      deletetbmMdRobotPgmNoDVOList.add(tbmMdRobotPgmNoDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdRobotPgmNoDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdRobotPgmNo(insertttbmMdRobotPgmNoDVOList);
          
      if (updatetbmMdRobotPgmNoDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdRobotPgmNo(updatetbmMdRobotPgmNoDVOList);
      
      if (deletetbmMdRobotPgmNoDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdRobotPgmNo(deletetbmMdRobotPgmNoDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return int
*/
	@LocalName("updateTbmMdRobotPgmNo")
	public int updateTbmMdRobotPgmNo (final TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.updateTbmMdRobotPgmNo.001*/  \n");
			sql.append(" TBM_MD_ROBOT_PGM_NO \n");
			sql.append(" SET   \n");
			sql.append("        PGM_NO = ? , \n");
			sql.append("        MAC_LABEL_PRT_YN = ? , \n");
			sql.append("        BUYER_OUTP_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND PLANT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPgmNo());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMacLabelPrtYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getBuyerOutpYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getUseYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
						}
					}
		);			
	}

/**
* deleteTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return int
*/
	@LocalName("deleteTbmMdRobotPgmNo")
	public int deleteTbmMdRobotPgmNo (final TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.deleteTbmMdRobotPgmNo.001*/  \n");
			sql.append(" TBM_MD_ROBOT_PGM_NO \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
						}
					}
		);			
	}

/**
* selectTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return TbmMdRobotPgmNoDVO 
*/
	@LocalName("selectTbmMdRobotPgmNo")
	public TbmMdRobotPgmNoDVO selectTbmMdRobotPgmNo (final TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.selectTbmMdRobotPgmNo.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        PGM_NO , \n");
			sql.append("        MAC_LABEL_PRT_YN , \n");
			sql.append("        BUYER_OUTP_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_ROBOT_PGM_NO \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return (TbmMdRobotPgmNoDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdRobotPgmNoDVO returnTbmMdRobotPgmNoDVO = new TbmMdRobotPgmNoDVO();
									returnTbmMdRobotPgmNoDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdRobotPgmNoDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdRobotPgmNoDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdRobotPgmNoDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdRobotPgmNoDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdRobotPgmNoDVO.setPgmNo(resultSet.getString("PGM_NO"));
									returnTbmMdRobotPgmNoDVO.setMacLabelPrtYn(resultSet.getString("MAC_LABEL_PRT_YN"));
									returnTbmMdRobotPgmNoDVO.setBuyerOutpYn(resultSet.getString("BUYER_OUTP_YN"));
									returnTbmMdRobotPgmNoDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdRobotPgmNoDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdRobotPgmNoDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdRobotPgmNoDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdRobotPgmNoDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdRobotPgmNoDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdRobotPgmNo Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdRobotPgmNo Method")
	public int mergeTbmMdRobotPgmNo (final TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO) {
		
		if ( selectTbmMdRobotPgmNo (tbmMdRobotPgmNoDVO) == null) {
			return insertTbmMdRobotPgmNo(tbmMdRobotPgmNoDVO);
		} else {
			return selectUpdateTbmMdRobotPgmNo (tbmMdRobotPgmNoDVO);
		}
	}

	/**
	 * selectUpdateTbmMdRobotPgmNo Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdRobotPgmNo Method")
	public int selectUpdateTbmMdRobotPgmNo (final TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO) {
		
		TbmMdRobotPgmNoDVO tmpTbmMdRobotPgmNoDVO =  selectTbmMdRobotPgmNo (tbmMdRobotPgmNoDVO);
		if ( tbmMdRobotPgmNoDVO.getFctCode() != null && !"".equals(tbmMdRobotPgmNoDVO.getFctCode()) ) {
			tmpTbmMdRobotPgmNoDVO.setFctCode(tbmMdRobotPgmNoDVO.getFctCode());
		}		
		if ( tbmMdRobotPgmNoDVO.getPlantCode() != null && !"".equals(tbmMdRobotPgmNoDVO.getPlantCode()) ) {
			tmpTbmMdRobotPgmNoDVO.setPlantCode(tbmMdRobotPgmNoDVO.getPlantCode());
		}		
		if ( tbmMdRobotPgmNoDVO.getLineCode() != null && !"".equals(tbmMdRobotPgmNoDVO.getLineCode()) ) {
			tmpTbmMdRobotPgmNoDVO.setLineCode(tbmMdRobotPgmNoDVO.getLineCode());
		}		
		if ( tbmMdRobotPgmNoDVO.getModelCode() != null && !"".equals(tbmMdRobotPgmNoDVO.getModelCode()) ) {
			tmpTbmMdRobotPgmNoDVO.setModelCode(tbmMdRobotPgmNoDVO.getModelCode());
		}		
		if ( tbmMdRobotPgmNoDVO.getMatrCode() != null && !"".equals(tbmMdRobotPgmNoDVO.getMatrCode()) ) {
			tmpTbmMdRobotPgmNoDVO.setMatrCode(tbmMdRobotPgmNoDVO.getMatrCode());
		}		
		if ( tbmMdRobotPgmNoDVO.getPgmNo() != null && !"".equals(tbmMdRobotPgmNoDVO.getPgmNo()) ) {
			tmpTbmMdRobotPgmNoDVO.setPgmNo(tbmMdRobotPgmNoDVO.getPgmNo());
		}		
		if ( tbmMdRobotPgmNoDVO.getMacLabelPrtYn() != null && !"".equals(tbmMdRobotPgmNoDVO.getMacLabelPrtYn()) ) {
			tmpTbmMdRobotPgmNoDVO.setMacLabelPrtYn(tbmMdRobotPgmNoDVO.getMacLabelPrtYn());
		}		
		if ( tbmMdRobotPgmNoDVO.getBuyerOutpYn() != null && !"".equals(tbmMdRobotPgmNoDVO.getBuyerOutpYn()) ) {
			tmpTbmMdRobotPgmNoDVO.setBuyerOutpYn(tbmMdRobotPgmNoDVO.getBuyerOutpYn());
		}		
		if ( tbmMdRobotPgmNoDVO.getUseYn() != null && !"".equals(tbmMdRobotPgmNoDVO.getUseYn()) ) {
			tmpTbmMdRobotPgmNoDVO.setUseYn(tbmMdRobotPgmNoDVO.getUseYn());
		}		
		if ( tbmMdRobotPgmNoDVO.getFstRegDt() != null && !"".equals(tbmMdRobotPgmNoDVO.getFstRegDt()) ) {
			tmpTbmMdRobotPgmNoDVO.setFstRegDt(tbmMdRobotPgmNoDVO.getFstRegDt());
		}		
		if ( tbmMdRobotPgmNoDVO.getFstRegerId() != null && !"".equals(tbmMdRobotPgmNoDVO.getFstRegerId()) ) {
			tmpTbmMdRobotPgmNoDVO.setFstRegerId(tbmMdRobotPgmNoDVO.getFstRegerId());
		}		
		if ( tbmMdRobotPgmNoDVO.getFnlUpdDt() != null && !"".equals(tbmMdRobotPgmNoDVO.getFnlUpdDt()) ) {
			tmpTbmMdRobotPgmNoDVO.setFnlUpdDt(tbmMdRobotPgmNoDVO.getFnlUpdDt());
		}		
		if ( tbmMdRobotPgmNoDVO.getFnlUpderId() != null && !"".equals(tbmMdRobotPgmNoDVO.getFnlUpderId()) ) {
			tmpTbmMdRobotPgmNoDVO.setFnlUpderId(tbmMdRobotPgmNoDVO.getFnlUpderId());
		}		
		return updateTbmMdRobotPgmNo (tmpTbmMdRobotPgmNoDVO);
	}

/**
* insertBatchTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return int[]
*/
	@LocalName("insertBatchTbmMdRobotPgmNo")
	public int[] insertBatchTbmMdRobotPgmNo (final List tbmMdRobotPgmNoDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.insertBatchTbmMdRobotPgmNo.001*/  \n");
			sql.append(" TBM_MD_ROBOT_PGM_NO (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        PGM_NO , \n");
			sql.append("        MAC_LABEL_PRT_YN , \n");
			sql.append("        BUYER_OUTP_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO = (TbmMdRobotPgmNoDVO)tbmMdRobotPgmNoDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPgmNo());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMacLabelPrtYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getBuyerOutpYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getUseYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdRobotPgmNoDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return int[]
*/
	@LocalName("updateBatchTbmMdRobotPgmNo")
	public int[] updateBatchTbmMdRobotPgmNo (final List tbmMdRobotPgmNoDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.updateBatchTbmMdRobotPgmNo.001*/  \n");
			sql.append(" TBM_MD_ROBOT_PGM_NO \n");
			sql.append(" SET   \n");
			sql.append("        PGM_NO = ? , \n");
			sql.append("        MAC_LABEL_PRT_YN = ? , \n");
			sql.append("        BUYER_OUTP_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND PLANT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO = (TbmMdRobotPgmNoDVO)tbmMdRobotPgmNoDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPgmNo());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMacLabelPrtYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getBuyerOutpYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getUseYn());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdRobotPgmNoDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdRobotPgmNo Method
* 
* @ref_table TBM_MD_ROBOT_PGM_NO
* @return int[]
*/
	@LocalName("deleteBatchTbmMdRobotPgmNo")
	public int[] deleteBatchTbmMdRobotPgmNo (final List tbmMdRobotPgmNoDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdRobotPgmNoDEM.deleteBatchTbmMdRobotPgmNo.001*/  \n");
			sql.append(" TBM_MD_ROBOT_PGM_NO \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND PLANT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdRobotPgmNoDVO tbmMdRobotPgmNoDVO = (TbmMdRobotPgmNoDVO)tbmMdRobotPgmNoDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getFctCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getPlantCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getLineCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getModelCode());
							ps.setString(psCount++, tbmMdRobotPgmNoDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdRobotPgmNoDVOList.size();
							}
					}
		);			
	}

	
}