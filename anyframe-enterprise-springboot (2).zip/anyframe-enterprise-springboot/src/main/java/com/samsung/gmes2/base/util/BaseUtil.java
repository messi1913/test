/**
 * <PRE>
 * System Name : G-MES 2.0
 * Business Name : BaseUtil
 * Class Name : BaseUtil.java
 * Description : 어디서나 공통으로 사용할 수 있는 Util 을 모아놓은 클래스
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------------------------------------------
 *    2011.6.24.    정문영            최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.base.util;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.math.util.MathUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.format.number.NumberFormatter;
import org.springframework.util.StringUtils;

import com.anyframe.core.vo.AbstractVo;
import com.anyframe.core.vo.meta.FieldMeta;
import com.anyframe.core.vo.meta.VoMeta;
import com.anyframe.online.runtime.jdbc.AbstractDAO;
import com.samsung.gmes2.base.vo.DVO;
import com.samsung.gmes2.exception.Gmes2BugException;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.exception.Property;
import com.samsung.gmes2.sm.cod.vo.CodeDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;
import com.samsung.gmes2.sm.model.TbmSmMsgGlobDEM;
import com.samsung.gmes2.sm.model.TbmSmMsgGlobDVO;

public class BaseUtil
{
	public static final String				DATEFORMAT_DATESHORT		= "yyyyMMdd";

	public static final String				DATEFORMAT_DATETIME			= "yyyy-MM-dd HH:mm:ss";

	public static final String				DATEFORMAT_DATETIMESHORT	= "yyyyMMddHHmmss";

	public static final String				DATEFORMAT_DATETIMEDETAIL	= "yyyy-MM-dd HH:mm:ss.S";

	public static final String				DATEFORMAT_TIME				= "HH:mm:ss";

	public static final String				DATEFORMAT_TIMESHORT		= "HHmmss";

	public static final int					ROUND_UP					= BigDecimal.ROUND_UP;

	public static final int					ROUND_HALF_UP				= BigDecimal.ROUND_HALF_UP;

	public static final int					ROUND_DOWN					= BigDecimal.ROUND_DOWN;

	public static final int					UNIT_SECOND					= Calendar.SECOND;

	public static final int					UNIT_MINUTE					= Calendar.MINUTE;

	public static final char				PADDIRECTION_LEFT			= 'L';

	public static final char				PADDIRECTION_RIGHT			= 'R';

	private static Logger					logger						= LoggerFactory.getLogger( BaseUtil.class );

	private static List<DateFormatter>		DATEFORMATTERLIST			= new ArrayList<DateFormatter>( );

	private static List<NumberFormatter>	NUMBERFORMATTERLIST			= new ArrayList<NumberFormatter>( );
	static
	{
		for ( Field field : BaseUtil.class.getFields( ) )
		{
			if ( !Modifier.isStatic( field.getModifiers( ) ) )
				continue;
			String name = field.getName( );
			if ( name.startsWith( "DATEFORMAT_" ) )
			{
				try
				{
					DATEFORMATTERLIST.add( new DateFormatter( (String) field.get( null ) ) );
				}
				catch ( IllegalArgumentException e )
				{
					logger.error( e.getMessage( ), e );
				}
				catch ( IllegalAccessException e )
				{
					logger.error( e.getMessage( ), e );
				}
			}
			else if ( name.startsWith( "NUMBERFORMAT_" ) )
			{
				try
				{
					NUMBERFORMATTERLIST.add( new NumberFormatter( (String) field.get( null ) ) );
				}
				catch ( IllegalArgumentException e )
				{
					logger.error( e.getMessage( ), e );
				}
				catch ( IllegalAccessException e )
				{
					logger.error( e.getMessage( ), e );
				}
			}
		}
	}

	/**
	 * clazz 유형의 DAO 를 얻습니다.<br/>
	 * <code>
	 * <pre>
	 * TbSmMMsgDVO msg;
	 * msg.setName("0001");
	 * ...
	 * Base.getDAO(TbSmMMsgDEM.class).insertTbSmMMsg(msg);
	 * </pre>
	 * </code>
	 * 
	 * @param <T>
	 * @param clazz
	 * @return
	 * @deprecated getBean(Class<T> clazz) 으로 대체
	 */
	@Deprecated
	public static <T extends AbstractDAO> T getDAO( Class<T> clazz )
	{
		return BeanUtil.get( clazz );
	}

	/**
	 * clazz 유형의 Bean 을 얻습니다. <code>
	 * <pre>
	 * MessageSVO vo = new MessageSVO();
	 * TbSmMMsgDVO msg = new TbSmMMsgDVO();
	 * vo.setMsg(msg);
	 * msg.setName("0001");
	 * ...
	 * vo = Base.getBean(MessageApp.class).getMessage(vo);
	 * </pre>
	 * </code>
	 * 
	 * @param <T>
	 * @param clazz
	 * @return
	 */
	public static <T> T getBean( Class<T> clazz )
	{
		return BeanUtil.get( clazz );
	}

	/**
	 * 현재 세션의 사용자 아이디를 조회합니다.
	 * 
	 * @return
	 */
	public static String getUsername( )
	{
		// TODO String getUsername()
		return "anonymous";
	}

	/**
	 * 현재 세션의 사용자 위치를 조회합니다.
	 * 
	 * @return
	 */
	public static Locale getLocale( )
	{
		// TODO Locale getLocale()
		return Locale.KOREA;
	}

	/**
	 * 현재 세션의 사용자 언어를 조회합니다.
	 * 
	 * @return
	 */
	public static String getLanguage( )
	{
		// TODO String getLanguage()
		return Locale.ENGLISH.getLanguage( );
	}

	/**
	 * 현재 세션의 사용자 플랜트를 조회합니다.
	 * 
	 * @return
	 */
	public static String getPlant( )
	{
		// TODO String getPlant()
		return "seda";
	}

	/**
	 * 아이디가 name 인 메시지를 조회합니다. 현재 설정된 언어에 맞는 메시지가 조회됩니다.
	 * 
	 * @param name
	 * @return
	 * @throws Exception
	 */
	public static String getMessage( String name ) throws Exception
	{
		return getMessage( name, null, null );
	}

	/**
	 * 
	 * 언어가 langCode이고 아이디가 name인 메시지 내용을 조회
	 * 
	 * @param name 메시지 ID
	 * @param langCode 언어코드
	 * @return 메시지 내용
	 */
	public static String getMessage( String name, String langCode ) throws Exception
	{
		return getMessage( name, langCode, null );
	}

	private static TbmSmMsgGlobDEM	tbmSmMsgGlobDEM;

	private static TbmSmMsgGlobDEM getTbmSmMsgGlobDEM( )
	{
		if ( tbmSmMsgGlobDEM == null )
			tbmSmMsgGlobDEM = BaseUtil.getBean( TbmSmMsgGlobDEM.class );
		return tbmSmMsgGlobDEM;
	}

	/**
	 * 언어가 langCode이고 아이디가 name 인 메시지를 조회합니다.<br/>
	 * 메시지 중에 나오는 속성 값을 props 값으로 대체하여 조회됩니다.<br/>
	 * 
	 * @param name
	 * @param props
	 * @return
	 */
	public static String getMessage( String name, Properties props )
	{
		return getMessage( name, null, props );
	}

	/**
     * 아이디가 name 인 메시지를 조회합니다.<br/>
     * 메시지 중에 나오는 속성 값을 props 값으로 대체하여 조회됩니다.<br/>
     * 현재 설정된 언어에 맞는 메시지가 조회됩니다.
     * 
     * @param name
     * @param langCode
     * @param props
     * @return
     */
	public static String getMessage( String name, String langCode, Properties props )
	{
		langCode = toString( langCode, getLanguage( ) );
		TbmSmMsgGlobDVO msg = new TbmSmMsgGlobDVO( );
		msg.setMsgId( name );
		msg.setLangCode( langCode );
		msg = getTbmSmMsgGlobDEM( ).selectTbmSmMsgGlob( msg );
		if ( msg == null || isEmpty( msg.getMsgCont( ) ) )
		{
			if ( Locale.ENGLISH.getLanguage( ).equals( langCode ) )
				return name;
			msg = new TbmSmMsgGlobDVO( );
			msg.setMsgId( name );
			msg.setLangCode( Locale.ENGLISH.getLanguage( ) );
			msg = getTbmSmMsgGlobDEM( ).selectTbmSmMsgGlob( msg );
			if ( msg == null || isEmpty( msg.getMsgCont( ) ) )
				return name;
		}
		return completeMessage( msg.getMsgCont( ), props );
	}

    /**
     * 메시지 중에 나오는 속성 값을 props 값으로 대체하여 완성된 메시지를 만듭니다.<br/>
     * 
     * @param message
     * @param props
     * @return
     */
	public static String completeMessage( String message, Properties props )
	{
		if ( isEmpty( props ) || isEmpty( message ) || !message.contains( "${" ) )
			return message;
		for ( Object keyObj : props.keySet( ) )
		{
			String key = new StringBuffer( "${" ).append( keyObj ).append( "}" ).toString( );
			if ( !message.contains( key ) )
				continue;
			String value = props.getProperty( (String) keyObj );
			message = replaceAll( message, key, value );
		}
		return message;
	}

	/**
	 * 타입코드가 typeCode 인 코드 목록을 조회합니다.
	 * 
	 * @param typeCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static List<CodeDVO> getCodeList( String typeCode ) throws Exception
	{
		if ( isEmpty( typeCode ) )
			return new ArrayList<CodeDVO>( );

		// Cache 에 있으면 바로 반환
		List<CodeDVO> list = (List<CodeDVO>) CacheUtil.get( "CodeDVOList", typeCode );
		if ( list != null )
			return list;

		// Code 조회
		list = new ArrayList<CodeDVO>( );
		Map<String, Object> inputMap = new HashMap<String, Object>( );
		inputMap.put( "typeCode", typeCode );
		List<TbcMdCommCodeDVO> cCodeList = CrudUtil.list( TbcMdCommCodeDVO.class, inputMap, 0, 0 );
		if ( isEmpty( cCodeList ) )
			return list;
		for ( TbcMdCommCodeDVO cCode : cCodeList )
			list.add( populate( cCode, new CodeDVO( ) ) );

		// Cache 에 남김
		CacheUtil.put( "CodeDVOList", typeCode, list );

		return list;
	}

    /**
     * condition 조건에 해당하는 데이터가 DB 에 이미 있는지 확인합니다.<br/>
     * 있으면 true, 없으면 false를 리턴
     * 
     * @param <T>
     * @return 있으면 true, 없으면 false를 리턴
     * @throws Exception
     */	
	public static <T extends AbstractVo> boolean isFound( T condition ) throws Exception
	{
		return CrudUtil.isFound( condition );
	}

    /**
     * condition 조건에 해당하는 데이터가 DB 에 아직 없는지 확인합니다.<br/>
     * 없으면 true, 있으면 false를 리턴
     * 
     * @param <T>
     * @return 있으면 true, 없으면 false를 리턴
     * @throws Exception
     */ 	
	public static <T extends AbstractVo> boolean isNotFound( T condition ) throws Exception
	{
		return CrudUtil.isNotFound( condition );
	}

	/**
	 * condition 조건에 해당하는 데이터가 DB 에 이미 있는지 확인합니다.<br/>
	 * DB 에 없으면 에러가 발생합니다.
	 * 
	 * @param <T>
	 * @param condition
	 * @throws Exception
	 */
	public static <T extends AbstractVo> void checkFound( T condition ) throws Exception
	{
		CrudUtil.checkFound( condition );
	}

	/**
	 * condition 조건에 해당하는 데이터가 DB 에 아직 없는지 확인합니다.<br/>
	 * DB 에 이미 있으면 에러가 발생합니다.
	 * 
	 * @param <T>
	 * @param obj
	 * @throws Exception
	 */
	public static <T extends AbstractVo> void checkNotFound( T obj ) throws Exception
	{
		CrudUtil.checkNotFound( obj );
	}

    /**
     * VO data 의 NotEmpty 필드의 값이 빈 값인지를 확인하여 빈 값인 경우 에러를 반환합니다.<br/>
     * 
     * @param data
     * @throws Exception
     */	
	public static void checkNotEmpty( AbstractVo data ) throws Exception
	{
		if ( data == null )
			return;
		String[ ] fieldName = ReflectionUtil.getNotEmptyFieldNameArray( data );
		if ( isEmpty( fieldName ) )
			return;
		checkNotEmpty( data, fieldName );
	}

	/**
	 * VO data 의 fieldName에 해당하는 필드 값이 빈 값인지를 확인하여 빈 값인 경우 에러를 반환합니다.
	 * 
	 * @param data
	 * @param fieldName
	 * @throws Exception
	 */
	public static void checkNotEmpty( AbstractVo data, String... fieldName ) throws Exception
	{
		if ( data == null )
			return;
		List<Property> property = populateEmptyProperty( new ArrayList<Property>( ), data, fieldName );
		if ( isEmpty( property ) )
			return;
		throw new Gmes2LogicException( Gmes2LogicException.CODE_EMPTY, "Has some empty fields.", property.toArray( new Property[ property.size( ) ] ) );
	}

    /**
     * VO data 의 fieldName에 해당하는 필드 값이 빈 값인지를 확인하여 빈 값인 경우 에러를 반환합니다.
     * 
     * @param fieldName
     * @param data
     * @throws Exception
     */	
	public static void checkNotEmpty( String fieldName, AbstractVo data )
	{
		if ( isEmpty( data ) )
			throw new Gmes2LogicException( Gmes2LogicException.CODE_EMPTY, "Has some empty fields.", new Property( fieldName ) );
	}

    /**
     * data가 pattern 데이트 포맷에 맞는지 확인
     * 
     * @param data
     * @param fieldName
     * @throws Exception
     */	
	public static void checkDateFormat( String fiedName, String data, String pattern ) throws Gmes2LogicException
	{
		try
		{
			new SimpleDateFormat( pattern ).parse( data );
		}
		catch ( ParseException e )
		{
			throw new Gmes2LogicException( Gmes2LogicException.CODE_INVALIDDATA, "Invalid date formate", e, new Property( fiedName, data ) );
		}
	}

	private static List<Property> populateEmptyProperty( List<Property> property, AbstractVo obj, String... field ) throws Exception
	{
		if ( isEmpty( field ) )
			return property;
		for ( String f : field )
		{
			if ( f.contains( "," ) )
			{
				populateEmptyProperty( property, obj, StringUtils.tokenizeToStringArray( f, "," ) );
				continue;
			}
			if ( isEmpty( ReflectionUtil.getFieldValue( obj, f ) ) )
				property.add( new Property( f ) );
		}
		return property;
	}

	/**
	 * data 가 빈 값인지 여부를 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static boolean isEmpty( Object data )
	{
		if ( data == null )
		{
			return true;
		}
		else if ( data instanceof String )
		{
			String str = data.toString( ).trim( );
			return str.isEmpty( ) || str.equals( "null" );
		}
		else if ( data instanceof Object[ ] )
		{
			return ( (Object[ ]) data ).length == 0;
		}
		else if ( data instanceof Collection<?> )
		{
			return ( (Collection<?>) data ).isEmpty( );
		}
		else if ( data instanceof Map<?, ?> )
		{
			return ( (Map<?, ?>) data ).isEmpty( );
		}
		return false;
	}

	/**
	 * data 가 빈 값인지 여부를 반환합니다. emptyValue 도 빈 값으로 인식합니다.
	 * 
	 * @param data
	 * @param emptyValue
	 * @return
	 */
	public static boolean isEmpty( Object data, int emptyValue )
	{
		if ( data instanceof Integer )
		{
			return data.equals( emptyValue );
		}
		else if ( data instanceof BigDecimal )
		{
			return data.equals( new BigDecimal( emptyValue ) );
		}
		else if ( data instanceof Long )
		{
			return data.equals( new Long( emptyValue ) );
		}
		else if ( data instanceof Float )
		{
			return data.equals( new Float( emptyValue ) );
		}
		else if ( data instanceof Double )
		{
			return data.equals( new Double( emptyValue ) );
		}
		return data == null || isEmpty( data ) ? true : data.toString( ).equals( emptyValue + "" );
	}

	/**
	 * data 가 빈 값이 아닌지 여부를 반환합니다. !isEmpty(data)
	 * 
	 * @param data
	 * @return
	 */
	public static boolean isNotEmpty( Object data )
	{
		return !isEmpty( data );
	}

	/**
	 * data 가 빈 값이 아닌지 여부를 반환합니다. !isEmpty(data, emptyValue)
	 * 
	 * @param data
	 * @param emptyValue
	 * @return
	 */
	public static boolean isNotEmpty( Object data, int emptyValue )
	{
		return !isEmpty( data, emptyValue );
	}

	/**
	 * a 와 b 가 같은 값인지 여부를 반환합니다.
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static boolean isEqual( Object a, Object b )
	{
		if ( a == null && b == null )
			return true;
		if ( a == null || b == null )
			return false;
		return a.equals( b );
	}

	/**
	 * a 와 b 가 다른 값인지 여부를 반환합니다. !isEqual(a, b)
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static boolean isNotEqual( Object a, Object b )
	{
		return !isEqual( a, b );
	}

	@Deprecated
	public static boolean isNumeric( Object data )
	{
		return isNumber( data );
	}

	/**
	 * data 가 숫자 값인지 여부를 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static boolean isNumber( Object data )
	{
		if ( data == null )
			return false;
		if ( data instanceof Integer || data instanceof BigDecimal || data instanceof Long || data instanceof Float || data instanceof Double )
			return true;
		return NumberUtils.isNumber( data.toString( ) );
	}

    /**
     * data 가 숫자 값이 아닌지 여부를 반환합니다.
     * 
     * @param data
     * @return
     */
	public static boolean isNotNumber( Object data )
	{
		return !isNumber( data );
	}

    /**
     * 모든 테이블 모델 업데이트 전에 수정시간, 수정자ID를 갱신하는데 이 값을 초기화한다. 
     * 
     * @param <T>
     * @return
     */	
	public static <T extends AbstractVo> T initForUpdate( T obj ) throws Exception
	{
		if ( obj == null )
			return null;
		Map<String, Integer> namedMap = obj.getProxy( ).getVoMeta( ).getNamedMap( );
		if ( namedMap.containsKey( DVO.FIELD_FNLUPDERID ) )
			obj.setValue( DVO.FIELD_FNLUPDERID, null );
		if ( namedMap.containsKey( DVO.FIELD_FNLUPDDT ) )
			obj.setValue( DVO.FIELD_FNLUPDDT, null );
		return obj;
	}

	/**
	 * from 객체에서 to 객체로 필드 값을 복사합니다.<br/>
	 * 이름이 겹치는 전체 필드를 복사합니다.
	 * 
	 * @param <F>
	 * @param <T>
	 * @param from
	 * @param to
	 * @return
	 * @throws Exception
	 */
	public static <F extends AbstractVo, T extends AbstractVo> T populate( F from, T to ) throws Exception
	{
		return populate( from, to, (Map<String, String>) null );
	}

	/**
	 * from 객체에서 to 객체로 필드 값을 복사합니다.<br/>
	 * 이름이 겹치거나 fromToFieldMap 에 매핑된 필드를 복사합니다.
	 * 
	 * @param <F>
	 * @param <T>
	 * @param from
	 * @param to
	 * @param fromToFieldMap
	 * @return
	 * @throws Exception
	 */
	public static <F extends AbstractVo, T extends AbstractVo> T populate( F from, T to, Map<String, String> fromToFieldMap ) throws Exception
	{
		VoMeta tvoMeta = to.getProxy( ).getVoMeta( );
		if ( isEmpty( tvoMeta.getFields( ) ) )
			return to;

		Map<String, String> toFromFieldMap = new HashMap<String, String>( );
		if ( isNotEmpty( fromToFieldMap ) )
		{
			for ( String key : fromToFieldMap.keySet( ) )
				toFromFieldMap.put( fromToFieldMap.get( key ), key );
		}

		int i = -1;
		VoMeta fvoMeta = from.getProxy( ).getVoMeta( );
		Map<String, Integer> fnamedMap = fvoMeta.getNamedMap( );
		for ( FieldMeta tfMeta : tvoMeta.getFields( ) )
		{
			i++;
			String toName = tfMeta.getFieldName( );
			String fname = toName;
			if ( toFromFieldMap.containsKey( toName ) )
			{
				fname = toFromFieldMap.get( toName );
				if ( !fnamedMap.containsKey( fname ) )
					throw new Gmes2BugException( "Unknown field: " + from.getClass( ).getSimpleName( ) + "." + fname );
				toFromFieldMap.remove( toName );
			}
			else if ( !fnamedMap.containsKey( fname ) )
			{
				continue;
			}
			to.setValue( i, to( from.getValue( fnamedMap.get( fname ) ), tfMeta.getFieldClass( ) ) );
		}
		if ( isNotEmpty( toFromFieldMap ) )
		{
			int j = 0;
			StringBuffer buf = new StringBuffer( );
			for ( String key : toFromFieldMap.keySet( ) )
				buf.append( j++ == 0 ? "" : "," ).append( key );
			throw new Gmes2BugException( "Unknown field: " + from.getClass( ).getSimpleName( ) + "." + buf );
		}
		return to;
	}

	/**
	 * from 객체에서 to 객체로 필드 값을 복사합니다.<br/>
	 * fieldName 매개변수가 넘어오지 않으면 이름이 겹치는 전체 필드를 복사합니다.<br/>
	 * fieldName 매개변수가 넘어오면 해당 필드만 복사합니다.<br/>
	 * fieldName 매개변수가 넘어온 경우 from 객체, to 객체 중에 해당 필드가 하나라도 없으면 에러가 발생합니다.<br/>
	 * 필드명이 다른 필드 간의 복사는 ':' 으로 구분된 두 필드명에 따라 복사합니다.<br/>
	 * <code>
	 * <pre>
	 * MessageSVO vo = new MessageSVO();
	 * vo.setMsg(populate(msg, new TbSmMMsgDVO(), "name", "ln"));
	 * vo = Base.getBean(MessageApp.class).getMessage(vo);
	 * </pre>
	 * </code>
	 * 
	 * @param <F>
	 * @param <T>
	 * @param from
	 * @param to
	 * @param fieldName
	 * @return
	 * @throws Exception
	 */
	public static <F extends AbstractVo, T extends AbstractVo> T populate( F from, T to, String... fieldName ) throws Exception
	{
		if ( isEmpty( fieldName ) )
			return populate( from, to );

		Map<String, Integer> fnamedMap = from.getProxy( ).getVoMeta( ).getNamedMap( );
		VoMeta tvoMeta = to.getProxy( ).getVoMeta( );
		Map<String, Integer> tnamedMap = tvoMeta.getNamedMap( );
		for ( String fn : fieldName )
		{
			if ( fn.contains( "," ) )
			{
				populate( from, to, StringUtils.tokenizeToStringArray( fn, "," ) );
				continue;
			}
			String ffn = fn;
			String tfn = fn;
			if ( fn.contains( ":" ) )
			{
				String[ ] ftfn = StringUtils.tokenizeToStringArray( fn, ":" );
				ffn = ftfn[ 0 ];
				tfn = ftfn[ 1 ];
			}
			if ( !fnamedMap.containsKey( ffn ) )
				throw new Gmes2BugException( "Unknown field: " + from.getClass( ).getSimpleName( ) + "." + ffn );
			if ( !tnamedMap.containsKey( tfn ) )
				throw new Gmes2BugException( "Unknown field: " + from.getClass( ).getSimpleName( ) + "." + tfn );
			to.setValue( tnamedMap.get( tfn ), to( from.getValue( fnamedMap.get( ffn ) ), tvoMeta.getFieldMeta( tfn ).getFieldClass( ) ) );
		}
		return to;
	}

	/**
	 * data 를 len 길이에 맞춰 direction 방향에 빈 값을 채웁니다. direction 은 PADDIRECTION_LEFT 또는 PADDIRECTION_RIGHT 입니다.
	 * 
	 * @param data
	 * @param len
	 * @param direction
	 * @return
	 * @throws Exception
	 */
	public static String pad( Object data, int len, char direction ) throws Exception
	{
		return pad( data, len, direction, ' ' );
	}

	/**
	 * data 를 len 길이에 맞춰 direction 방향에 pad 값을 채웁니다. direction 은 PADDIRECTION_LEFT 또는 PADDIRECTION_RIGHT 입니다.
	 * 
	 * @param data
	 * @param len
	 * @param direction
	 * @param pad
	 * @return
	 * @throws Exception
	 */
	public static String pad( Object data, int len, char direction, char pad ) throws Exception
	{
		if ( direction != PADDIRECTION_LEFT && direction != PADDIRECTION_RIGHT )
			throw new Gmes2BugException( "Unknown direction: " + direction );
		String str = toNotNull( data ).trim( );
		int lenToPop = len - str.length( );
		if ( lenToPop <= 0 )
			return str;
		// else if (lenToPop < 0)
		// return str.substring(0, len);
		StringBuffer buf = new StringBuffer( );
		if ( direction == PADDIRECTION_RIGHT )
			buf.append( str );
		for ( int i = 0; i < lenToPop; i++ )
			buf.append( pad );
		if ( direction == PADDIRECTION_LEFT )
			buf.append( str );
		return buf.toString( );
	}

	@SuppressWarnings("unchecked")
	private static <T> T to( Object data, Class<T> type ) throws Exception
	{
		if ( data == null || type == null )
			return null;
		if ( type.isAssignableFrom( data.getClass( ) ) )
		{
			return (T) data;
		}
		else if ( data instanceof List )
		{
			List<?> list = (List<?>) data;
			if ( list.isEmpty( ) || type.isAssignableFrom( list.get( 0 ).getClass( ) ) )
				return (T) data;
		}
		else if ( type == String.class )
		{
			return (T) data.toString( );
		}
		else if ( type == Integer.class || type == int.class )
		{
			if ( data instanceof Integer )
				return (T) data;
			return (T) new Integer( data.toString( ) );
		}
		else if ( type == BigDecimal.class )
		{
			if ( data instanceof BigDecimal )
				return (T) data;
			return (T) new BigDecimal( data.toString( ) );
		}
		else if ( type == Long.class || type == long.class )
		{
			if ( data instanceof Long )
				return (T) data;
			return (T) new Long( data.toString( ) );
		}
		else if ( type == Float.class || type == float.class )
		{
			if ( data instanceof Float )
				return (T) data;
			return (T) new Float( data.toString( ) );
		}
		else if ( type == Double.class || type == double.class )
		{
			if ( data instanceof Double )
				return (T) data;
			return (T) new Double( data.toString( ) );
		}
		else if ( type == Boolean.class || type == boolean.class )
		{
			if ( data instanceof Boolean )
				return (T) data;
			return (T) new Boolean( data.toString( ) );
		}
		else if ( type == Date.class )
		{
			if ( data instanceof Date )
				return (T) data;
			return (T) toDate( data.toString( ) );
		}
		throw new Gmes2BugException( "Uncastable data type: " + type );
	}

	/**
	 * data 를 String 유형으로 변환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static String toString( Object data )
	{
		return toString( data, null );
	}

	/**
	 * data 를 String 유형으로 변환합니다.<br/>
	 * data 가 빈 값이면 기본 값을 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static String toString( Object data, String defaultValue )
	{
		if ( data == null )
			return defaultValue;
		if ( data instanceof BigDecimal )
		{
			BigDecimal bd = (BigDecimal) data;
			return bd.toPlainString( );
		}
		else if ( data instanceof Date )
		{
			return toDateString( data );
		}
		return data == null || (isEmpty(data) && defaultValue != null) ? defaultValue : data.toString( );
	}

    /**
     * data 를  String 값으로 반환합니다.<br/>
     * data 가 null 인 경우 null 값을 반환합니다.
     * 
     * @param data
     * @return
     */
	public static String toNull( Object data )
	{
		return toString( data, null );
	}

	/**
	 * data 를 null 이 아닌 String 값으로 반환합니다.<br/>
	 * data 가 null 인 경우 빈 값 ("") 을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static String toNotNull( Object data )
	{
		return toString( data, "" );
	}

	/**
	 * data 를 Integer 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Integer toInteger( Object data )
	{
		return toInteger( data, null );
	}

	/**
	 * 데이터를 Integer 형으로 반환합니다.<br/>
	 * data 가 null인 경우 defaultValue 를 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static Integer toInteger( Object data, Integer defaultValue )
	{
		if ( isEmpty( data ) )
			return defaultValue;
		if ( data instanceof Integer )
			return (Integer) data;
		return toNumber( data ).intValue( );
	}

	/**
	 * data 를 Integer 형으로 반환합니다.<br/>
	 * data 가 null인 경우 0 을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Integer toIntegerNotNull( Object data )
	{
		return toInteger( data, 0 );
	}

	/**
	 * 데이터를 BigDecimal 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static BigDecimal toBigDecimal( Object data )
	{
		return toBigDecimal( data, null );
	}

	/**
	 * data 를 BigDecimal 형으로 반환합니다.<br/>
	 * data 가 null인 경우 defaultValue 를 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static BigDecimal toBigDecimal( Object data, BigDecimal defaultValue )
	{
		if ( isEmpty( data ) )
			return defaultValue;
		if ( data instanceof BigDecimal )
			return (BigDecimal) data;
		return new BigDecimal( toNumber( data ).toString( ) );
	}

	/**
	 * data 를 BigDecimal 형으로 반환합니다.<br/>
	 * data 가 null인 경우 0 을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static BigDecimal toBigDecimalNotNull( Object data )
	{
		return toBigDecimal( data, new BigDecimal( 0 ) );
	}

	/**
	 * data 를 Long 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Long toLong( Object data )
	{
		return toLong( data, null );
	}

	/**
	 * data 를 Long 형으로 반환합니다.<br/>
	 * data 가 빈 값이면 기본 값을 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static Long toLong( Object data, Long defaultValue )
	{
		if ( isEmpty( data ) )
			return defaultValue;
		if ( data instanceof Long )
			return (Long) data;
		return toNumber( data ).longValue( );
	}

	/**
	 * data 를 Long 형으로 반환합니다.<br/>
	 * data 가 null인 경우 0 을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Long toLongNotNull( Object data )
	{
		return toLong( data, new Long( 0 ) );
	}

	/**
	 * data 를 Float 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Float toFloat( Object data )
	{
		return toFloat( data, null );
	}

	/**
	 * data 를 Float 형으로 반환합니다.<br/>
	 * data 가 빈 값이면 기본 값을 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static Float toFloat( Object data, Float defaultValue )
	{
		if ( isEmpty( data ) )
			return defaultValue;
		if ( data instanceof Float )
			return (Float) data;
		return toNumber( data ).floatValue( );
	}

	/**
	 * data 를 Float 형으로 반환합니다.<br/>
	 * data 가 null 인 경우 빈 값 ("") 을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Float toFloatNotNull( Object data )
	{
		return toFloat( data, new Float( 0 ) );
	}

	/**
	 * data 를 Double 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Double toDouble( Object data )
	{
		return toDouble( data, null );
	}

	/**
	 * data 를 Double 형으로 반환합니다.<br/>
	 * data 가 빈 값이면 기본 값을 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static Double toDouble( Object data, Double defaultValue )
	{
		if ( isEmpty( data ) )
			return defaultValue;
		if ( data instanceof Double )
			return (Double) data;
		return toNumber( data ).doubleValue( );
	}

	/**
	 * data 를 Double 형으로 반환합니다.<br/>
	 * data 가 null 인 경우 빈 값 ("") 을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Double toDoubleNotNull( Object data )
	{
		return toDouble( data, new Double( 0 ) );
	}

	/**
	 * data 를 Number 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	private static Number toNumber( Object data )
	{
		// TODO Number toNumber(Object data)
		try
		{
			return NumberFormat.getInstance( ).parse( data.toString( ) );
		}
		catch ( ParseException e )
		{
			throw new Gmes2BugException( "Unsupported number pattern" );
		}
		// for (NumberFormatter formatter : NUMBERFORMATTERLIST) {
		// try {
		// return formatter.parse(data.toString(), getLocale());
		// } catch (ParseException e1) {
		// }
		// }
		// throw new Gmes2BugException("Unsupported number pattern");
	}

	/**
	 * data 를 Boolean 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Boolean toBoolean( Object data )
	{
		return toBoolean( data, null );
	}

	/**
	 * data 를 Boolean 형으로 반환합니다. data 가 빈 값이면 기본 값을 반환합니다.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return
	 */
	public static Boolean toBoolean( Object data, Boolean defaultValue )
	{
		if ( isEmpty( data ) )
			return defaultValue;
		if ( data instanceof Boolean )
			return (Boolean) data;
		String str = data.toString( );
		if ( str.equalsIgnoreCase( "T" ) || str.equalsIgnoreCase( "Y" ) || str.equalsIgnoreCase( "true" ) )
			return true;
		return false;
	}

	/**
	 * data 를 Boolean 형으로 반환합니다. data 가 빈 값이면 false 를 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Boolean toBooleanNotNull( Object data )
	{
		return toBoolean( data, false );
	}

	/**
	 * data 를 Date 형으로 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static Date toDate( Object data )
	{
		if ( isEmpty( data ) )
			return null;
		if ( data instanceof Date )
			return (Date) data;
		for ( DateFormatter formatter : DATEFORMATTERLIST )
		{
			try
			{
				return formatter.parse( data.toString( ), getLocale( ) );
			}
			catch ( ParseException e )
			{
			}
			catch ( Exception e )
			{
			}
		}
		if ( isNumeric( data ) )
			return new Date( new Long( data.toString( ) ) );
		throw new Gmes2BugException( "Unsupported date pattern" );
	}

	/**
	 * data 를 pattern 에 따라 Date 형으로 변환하여 반환합니다.
	 * 
	 * @param data
	 * @param pattern
	 * @return
	 * @throws Exception
	 */
	public static Date toDate( String data, String pattern ) throws Exception
	{
		return new SimpleDateFormat( pattern ).parse( data );
	}

	private static final String	colorDigits	= "0123456789ABCDEF";

	/**
	 * data 를 awt Color 형으로 반환합니다.
	 * 
	 * @param webColor
	 * @return
	 * @throws Exception
	 */
	public static Color toColor( String webColor ) throws Exception
	{
		return toColor( webColor, 255 );
	}

	/**
	 * data 를 awt Color 형으로 반환합니다.
	 * 
	 * @param webColor
	 * @param alpha
	 * @return
	 * @throws Exception
	 */
	public static Color toColor( String webColor, int alpha ) throws Exception
	{
		if ( isEmpty( webColor, 0 ) )
			return Color.BLACK;
		if ( isNumeric( webColor ) )
			return new Color( toInteger( webColor ) );
		int len = webColor.length( );
		int i;
		for ( i = 0; i < len; )
		{
			i++;
			if ( colorDigits.contains( webColor.charAt( len - i ) + "" ) )
				continue;
			i--;
			break;
		}
		if ( i < 6 )
			return Color.BLACK;
		webColor = new StringBuffer( "0x" ).append( from10to16( alpha ) ).append( webColor.substring( len - 6 ) ).toString( );
		return new Color( toInteger( webColor ) );
	}

	/**
	 * 배열을 집합 (Set) 객체로 변환합니다.
	 * 
	 * @param <T>
	 * @param data
	 * @return
	 */
	public static <T> Set<T> toSet( T... data )
	{
		return (Set<T>) populate( new HashSet<T>( ), data );
	}

    /**
     * 배열을 집합 (Map) 객체로 변환합니다.
     * 
     * @param data
     * @return
     */	
	public static Map<String, String> toMap( String... data )
	{
		return populateMap( new HashMap<String, String>( ), data );
	}

    /**
     * 배열을 집합 (toProperties) 객체로 변환합니다.
     * 
     * @param data
     * @return
     */ 	
	public static Properties toProperties( String... data )
	{
		return populateMap( new Properties( ), data );
	}
	
	private static <T> T populateMap( T t, String... data )
	{
		@SuppressWarnings("unchecked")
		Map<String, String> map = (Map<String, String>) t;
		for ( String d : data )
		{
			if ( !d.contains( ":" ) )
			{
				map.put( d, d );
				continue;
			}
			String[ ] ds = split( d, ":" );
			map.put( ds[ 0 ], ds[ 1 ] );
		}
		return t;
	}

	/**
	 * 배열을 목록 (List) 객체로 변환합니다.
	 * 
	 * @param <T>
	 * @param data
	 * @return
	 */
	public static <T> List<T> toList( T... data )
	{
		return (List<T>) populate( new ArrayList<T>( ), data );
	}

	public static <T> String[ ] toStringArray( Collection<T> col )
	{
		if ( isEmpty( col ) )
			return new String[ 0 ];
		String[ ] array = new String[ col.size( ) ];
		int i = 0;
		for ( T obj : col )
			array[ i++ ] = toString( obj );
		return array;
	}

	private static <T> Collection<T> populate( Collection<T> col, T[ ] data )
	{
		if ( isEmpty( data ) )
			return col;
		for ( T d : data )
			col.add( d );
		return col;
	}

	/**
	 * obj 의 필드 값 중에 null 이 아닌 값에 대해 Map 에 담아 반환합니다.
	 * 
	 * @param <T>
	 * @param obj
	 * @return
	 */
	public static <T extends AbstractVo> Map<String, Object> toMap( T obj )
	{
		Map<String, Object> map = new HashMap<String, Object>( );
		if ( obj == null )
			return map;
		int i = -1;
		for ( FieldMeta fMeta : obj.getProxy( ).getVoMeta( ).getFields( ) )
		{
			i++;
			if ( isEmpty( obj.getValue( i ) ) )
				continue;
			map.put( fMeta.getFieldName( ), obj.getValue( i ) );
		}
		return map;
	}

	/**
	 * obj 의 필드 값을 Map 형으로 반환합니다.<br/>
	 * fieldName 매개변수가 넘어오지 않으면 null 이 아닌 null 이 아닌 모든 값에 대해 Map 에 담습니다.<br/>
	 * fieldName 매개변수가 넘어오면 해당 필드를 모두 Map 에 담습니다.
	 * 
	 * @param <T>
	 * @param obj
	 * @return
	 */
	public static <T extends AbstractVo> Map<String, Object> toMap( T obj, String... fieldName )
	{
		if ( isEmpty( fieldName ) )
			return toMap( obj );

		Map<String, Object> map = new HashMap<String, Object>( );
		if ( obj == null )
			return map;
		Map<String, Integer> fnamedMap = obj.getProxy( ).getVoMeta( ).getNamedMap( );
		for ( String fn : fieldName )
		{
			String ffn = fn;
			String tfn = fn;
			if ( fn.contains( ":" ) )
			{
				String[ ] fns = StringUtils.tokenizeToStringArray( fn, ":" );
				ffn = fns[ 0 ];
				tfn = fns[ 1 ];
			}
			if ( !fnamedMap.containsKey( ffn ) )
				throw new Gmes2BugException( "Unknown field: " + obj.getClass( ).getSimpleName( ) + "." + fn );
			map.put( tfn, obj.getValue( ffn ) );
		}
		return map;
	}

	/**
	 * value 를 delimiter 로 쪼개어 반환합니다.
	 * 
	 * @param value
	 * @param delimiter
	 * @return
	 * @throws Exception
	 */
	public static String[ ] split( String value, String delimiter )
	{
		return StringUtils.tokenizeToStringArray( value, delimiter );
	}

    /**
     * map에서 fromKey를 toKey로 교체
     * 
     * @param map
     * @param fromKey
     * @param toKey
     * @return
     */
	public static void replaceKey( Map<String, Object> map, String fromKey, String toKey )
	{
		if ( isEmpty( map ) || isEmpty( fromKey ) || isEmpty( toKey ) || !map.containsKey( fromKey ) )
			return;
		map.put( toKey, map.get(fromKey) );
		map.remove( fromKey );
	}

	/**
	 * value 안에 있는 oldPattern 을 모두 없앱니다.
	 * 
	 * @param value
	 * @param oldPattern
	 * @param newPattern
	 * @return
	 */
	public static String removeAll( String value, String oldPattern )
	{
		return replaceAll( value, oldPattern, "" );
	}

	/**
	 * value 안에 있는 모든 oldPattern 을 newPattern 으로 변경합니다.
	 * 
	 * @param value
	 * @param oldPattern
	 * @param newPattern
	 * @return
	 */
	public static String replaceAll( String value, String oldPattern, String newPattern )
	{
		return StringUtils.replace( value, oldPattern, newPattern );
	}

	/**
	 * 현재 날짜 및 시간을 생성하는 메써드 입니다.<br/>
	 * 날짜 값을 생성할 때에는 표준시 적용이 필요하므로, 이 함수를 통해 생성합니다.
	 * 
	 * @return
	 */
	public static Date newDate( ) throws Exception
	{
		// TODO Date newDate()
		return new Date( );
	}
	
    /**
     * 현재 날짜 및 시간을 생성하고 문자열로 반환합니다.<br/>
     * 
     * @return
     */
	public static String getDateString( ) throws Exception
	{
		return toDateString( newDate( ), DATEFORMAT_DATETIMESHORT );
	}

    /**
     * 현재 날짜 및 시간을 pattern 형식으로 생성하고 문자열로 반환합니다.<br/>
     * 
     * @param pattern
     * @return
     */	
	public static String getDateString( String pattern ) throws Exception
	{
		return toDateString( newDate( ), pattern );
	}

    /**
     * data를 날짜 및 시간 문자열로 반환합니다.<br/>
     * 
     * @param pattern
     * @return
     */
	public static String toDateString( Object data )
	{
		return toDateString( data, null );
	}

    /**
     * data를 pattern 형식의 날짜 및 시간 문자열로 반환합니다.<br/>
     * 
     * @param data
     * @param pattern
     * @return
     */	
	public static String toDateString( Object data, String pattern )
	{
		if ( isEmpty( pattern ) )
			pattern = DATEFORMAT_DATETIMESHORT;
		else if ( pattern.length( ) < 3 )
			pattern = new StringBuffer( "yyyy" ).append( pattern ).append( "MM" ).append( pattern ).append( "dd HH" ).append( pattern ).append( "mm" ).append( pattern ).append( "ss" ).toString( );
		return new DateFormatter( pattern ).print( toDate( data ), getLocale( ) );
	}

    /**
     * 현재 날짜 및 시간 문자열로 반환합니다.<br/>
     * 
     * @return
     */ 
	public static String getTimeString( ) throws Exception
	{
		return getTimeString( DATEFORMAT_TIME );
	}

    /**
     * 현재 날짜 및 시간 문자열로 반환합니다.<br/>
     * 
     * @param pattern
     * @return
     * @throws
     */
	public static String getTimeString( String pattern ) throws Exception
	{
		if ( isEmpty( pattern ) )
			pattern = DATEFORMAT_TIMESHORT;
		else if ( pattern.length( ) < 3 )
			pattern = new StringBuffer( "HH" ).append( pattern ).append( "mm" ).append( pattern ).append( "ss" ).toString( );
		return toDateString( newDate( ), pattern );
	}

    /**
     * data를 시간 단위 unit에 맞춰 날짜 및 시간 문자열로 반환합니다.<br/>
     * 
     * @param data
     * @param unit
     * @return
     * @throws
     */	
	public static String toTimeString( int data, int unit ) throws Exception
	{
		long time = data;
		switch( unit )
		{
			case UNIT_SECOND:
				time *= 1000;
			break;
			case UNIT_MINUTE:
				time *= 60000;
			break;
			default:
				throw new Gmes2BugException( "Not supported time unit." );
		}
		return toString( new Date( time ), DATEFORMAT_TIME );
	}

    /**
     * data를 시간 단위 unit에 맞춰 day time 형식의 문자열로 반환합니다.<br/>
     * 
     * @param data
     * @param unit
     * @return
     * @throws
     */	
	public static String toDayTimeString( int data, int unit ) throws Exception
	{
		String timeStr = toTimeString( data, unit );
		int hour = Integer.parseInt( split( timeStr, ":" )[ 0 ] );
		if ( hour < 24 )
			return new StringBuffer( "0D " ).append( timeStr ).toString( );
		return new StringBuffer( ).append( hour / 24 ).append( "D " ).append( hour % 24 ).append( ":" ).append( timeStr.substring( timeStr.indexOf( ":" ) + 1 ) ).toString( );
	}

    /**
     * 현재 월을 문자형으로 반환
     * 
     * @return
     */ 	
	public static String getMonthString( ) throws Exception
	{
		Calendar cal = Calendar.getInstance( );
		cal.setTime( newDate( ) );
		switch( cal.get( Calendar.MONTH ) )
		{
			case Calendar.JANUARY:
				return "Jan";
			case Calendar.FEBRUARY:
				return "Feb";
			case Calendar.MARCH:
				return "Mar";
			case Calendar.APRIL:
				return "Apr";
			case Calendar.MAY:
				return "May";
			case Calendar.JUNE:
				return "Jun";
			case Calendar.JULY:
				return "Jul";
			case Calendar.AUGUST:
				return "Aug";
			case Calendar.SEPTEMBER:
				return "Sep";
			case Calendar.OCTOBER:
				return "Oct";
			case Calendar.NOVEMBER:
				return "Nov";
			case Calendar.DECEMBER:
				return "Dec";
		}
		return null;
	}

	/**
	 * data 를 pattern 에 맞는 String 으로 반환합니다.
	 * 
	 * @param data
	 * @param pattern
	 * @return
	 * @throws Exception
	 */
	public static String toNumberString( Object data, String pattern ) throws Exception
	{
		return new DecimalFormat( pattern ).format( toDouble( data ) );
	}

	/**
	 * date 에서 field 값을 amout 만큼 더해서 반환합니다.
	 * 
	 * @param date
	 * @param field
	 * @param amount
	 * @return
	 * @throws Exception
	 */
	public static Date addDate( Date date, int field, int amount ) throws Exception
	{
		if ( date == null )
			throw new Gmes2BugException( "date is null" );
		Calendar cal = Calendar.getInstance( );
		cal.setTime( date );
		cal.add( field, amount );
		date.setTime( cal.getTimeInMillis( ) );
		return date;
	}

	/**
	 * from 과 to 간의 시간 차를 millisecond 값으로 반환합니다.
	 * 
	 * @param from
	 * @param to
	 * @return
	 */
	public static long compare( Date from, Date to )
	{
		if ( from == null )
		{
			if ( to == null )
				return 0;
			return -to.getTime( );
		}
		else if ( to == null )
		{
			return from.getTime( );
		}
		return from.getTime( ) - to.getTime( );
	}

	/**
	 * data 를 scale 소숫점 자리에서 올림합니다.
	 * 
	 * @param data
	 * @param scale
	 * @return
	 */
	public static double roundUp( double data, int scale )
	{
		return MathUtils.round( data, scale, ROUND_UP );
	}

	/**
	 * data 를 scale 소숫점 자리에서 반올림합니다.
	 * 
	 * @param data
	 * @param scale
	 * @return
	 */
	public static double roundHalfUp( double data, int scale )
	{
		return MathUtils.round( data, scale, ROUND_HALF_UP );
	}

	/**
	 * data 를 scale 소숫점 자리에서 내림합니다.
	 * 
	 * @param data
	 * @param scale
	 * @return
	 */
	public static double roundDown( double data, int scale )
	{
		return MathUtils.round( data, scale, ROUND_DOWN );
	}

	/**
	 * 데이터의 절대 값을 반환합니다.
	 * 
	 * @param data
	 * @return
	 */
	public static double abs( double data )
	{
		return Math.abs( data );
	}

	private static double	invsqrt2pi	= 0.3989422804014327;

	private static double	b1			= 0.31938153;

	private static double	b2			= -0.356563782;

	private static double	b3			= 1.781477937;

	private static double	b4			= -1.821255978;

	private static double	b5			= 1.330274429;

	private static double	p			= 0.2316419;

	/**
	 * 엑셀 normsdist 함수 java 버전 입니다.
	 * 
	 * @param x
	 * @return
	 */
	public static double normsdist( double x )
	{
		double ax = abs( x );
		double t = 1.0 / ( 1.0 + p * ax );
		double area = invsqrt2pi * Math.exp( -0.5 * x * x ) * t * ( b1 + t * ( b2 + t * ( b3 + t * ( b4 + t * b5 ) ) ) );
		if ( x > 0.0 )
			area = 1.0 - area;
		return area;
	}

	/**
	 * 엑셀 normsdist 역함수(normsinv) java 버전 입니다.
	 * 
	 * @param y
	 * @return
	 */
	public static double invnormsdist( double y )
	{
		if ( y < 1.0e-20 )
			return -5.0;
		if ( y >= 1.0 )
			return 5.0;
		double x = 0.0;
		double incr = y - 0.5;
		while (abs( incr ) > 0.0000001)
		{
			if ( abs( incr ) < 0.0001 && ( x <= -5.0 || x >= 5.0 ) )
				break;
			x += incr;
			double tst = normsdist( x );
			if ( ( tst > y && incr > 0. ) || ( tst < y && incr < 0. ) )
				incr *= -0.5;
		}
		return x;
	}

	/**
	 * List 의 내용을 sortField 값에 따라 정렬합니다.
	 * 
	 * @param list
	 * @param sortField
	 * @throws Exception
	 */
	public static <T extends AbstractVo> List<T> sort( List<T> list, String sortField ) throws Exception
	{
		if ( isEmpty( list ) )
			return list;

		// SortedMap을 선언한다.
		SortedMap<Object, T> map = new TreeMap<Object, T>( );

		for ( T obj : list )
			map.put( obj.getValue( sortField ), obj );

		// // className의 class를 선언한다.
		// Class<?> clazz = list.get(0).getClass();
		//
		// // method (sortKeyField의 get 함수) 를 선언한다.
		// Method m = clazz.getMethod(sortField, new Class[] {});
		//
		// Method txnCodeMethod = clazz.getMethod("getTxnCode", new Class[] {});
		//
		// Method lastEventTime = clazz.getMethod("getLastEventTime", new
		// Class[] {});
		//
		// // 넘어온 list 만큼 loop를 수행한다.
		// for (T obj : list) {
		// Object result;
		//
		// String tempTxnCode = "Z";
		//
		// // sortKeyField의 getMethod로 key : object 의 맵을 생성한다.
		// result = m.invoke(obj, new Object[] {});
		//
		// Object txnCode = txnCodeMethod.invoke(obj, new Object[] {});
		//
		// // txnCode가 null 인경우는 Z
		// // 이 이유는 txnCode 형태가
		// // 0 : create, 1 : modify, 2 : remove..... 이 순서로 되어 있으므로,
		// // 같은 소트 조건(id, name, position)으로는 modify 보다는 create가 remove 보다는
		// // modify가 먼저 수행이 되어야 함
		//
		// // 2009.11.10 이종범 - txnCode 주는 부분 수정
		// if (txnCode == null) {
		// tempTxnCode = "Z";
		// } else {
		// tempTxnCode = txnCode + "";
		// }
		//
		// // 2009.12.16 이종범 - key delimiter를 /t -> \t로 변경
		// result = result + "\t" + lastEventTime
		// + "\t" + tempTxnCode;
		//
		// // map에 put 할때 이미 key로 오름차순 정렬이 되어 있음..
		// map.put(result, obj);
		// }

		// return list를 설정한다.
		List<T> returnList = new ArrayList<T>( );
		for ( Object key : map.keySet( ) )
			returnList.add( map.get( key ) );
		return returnList;
	}

	/**
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public static String from10to16( int value ) throws Exception
	{
		return NumeralConverter.to( value, 16 );
	}

	/**
	 * 10진수 값을 16진수로 변환합니다.
	 * 
	 * @param list
	 * @return
	 */
	public static List<String> from10to16( List<Integer> list ) throws Exception
	{
		return from10( list, 16 );
	}

	/**
	 * 16진수 값을 10진수로 변환합니다.
	 * 
	 * @param list
	 * @return
	 */
	public static List<Integer> from16To10( List<String> list ) throws Exception
	{
		return to10( list, 16 );
	}

	/**
	 * 10진수 값 목록을 다른 진수로 변환합니다.
	 * 
	 * @param list
	 * @param to
	 * @return
	 * @throws Exception
	 */
	private static List<String> from10( List<Integer> list, int to ) throws Exception
	{
		List<String> resultList = new ArrayList<String>( );
		if ( isEmpty( list ) )
			return resultList;
		for ( Integer value : list )
			resultList.add( NumeralConverter.to( value, to ) );
		return resultList;
	}

	/**
	 * 다른 진수 값 목록을 10진수로 변환합니다.
	 * 
	 * @param list
	 * @param from
	 * @return
	 * @throws Exception
	 */
	private static List<Integer> to10( List<String> list, int from ) throws Exception
	{
		List<Integer> resultList = new ArrayList<Integer>( );
		if ( isEmpty( list ) )
			return resultList;
		for ( String value : list )
			resultList.add( NumeralConverter.to10( value, from ) );
		return resultList;
	}

	public static String fromXtoY( String value, int from, int to ) throws Exception
	{
		return NumeralConverter.to( NumeralConverter.to10( value, from ), to );
	}

	/**
	 * X진수를 Y진수로 변환합니다.
	 * 
	 * @param list
	 * @param from
	 * @param to
	 * @return
	 * @throws Exception
	 */
	public static List<String> fromXtoY( List<String> list, int from, int to ) throws Exception
	{
		List<String> resultList = new ArrayList<String>( );
		if ( isEmpty( list ) )
			return resultList;
		for ( String value : list )
			resultList.add( fromXtoY( value, from, to ) );
		return resultList;
	}
}
