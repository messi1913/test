package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_MATR
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelMatrDEM extends AbstractDAO {


/**
* insertTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return int
*/
	@LocalName("insertTbmMdModelMatr")
	public int insertTbmMdModelMatr (final TbmMdModelMatrDVO tbmMdModelMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.insertTbmMdModelMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_MATR (   \n");
			sql.append("        MODEL_MATR_CODE , \n");
			sql.append("        MODEL_MATR_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrDesc());
							ps.setString(psCount++, tbmMdModelMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelMatr Method")
	public int[][] updateBatchAllTbmMdModelMatr (final List  tbmMdModelMatrDVOList) {
		
		ArrayList updatetbmMdModelMatrDVOList = new ArrayList();
		ArrayList insertttbmMdModelMatrDVOList = new ArrayList();
		ArrayList deletetbmMdModelMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelMatrDVOList.size() ; i++) {
		  TbmMdModelMatrDVO tbmMdModelMatrDVO = (TbmMdModelMatrDVO) tbmMdModelMatrDVOList.get(i);
		  
		  if (tbmMdModelMatrDVO.getSqlAction().equals("C"))
		      insertttbmMdModelMatrDVOList.add(tbmMdModelMatrDVO);
		  else if (tbmMdModelMatrDVO.getSqlAction().equals("U"))
		      updatetbmMdModelMatrDVOList.add(tbmMdModelMatrDVO);
		  else if (tbmMdModelMatrDVO.getSqlAction().equals("D"))
		      deletetbmMdModelMatrDVOList.add(tbmMdModelMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelMatr(insertttbmMdModelMatrDVOList);
          
      if (updatetbmMdModelMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelMatr(updatetbmMdModelMatrDVOList);
      
      if (deletetbmMdModelMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelMatr(deletetbmMdModelMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return int
*/
	@LocalName("updateTbmMdModelMatr")
	public int updateTbmMdModelMatr (final TbmMdModelMatrDVO tbmMdModelMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.updateTbmMdModelMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_MATR \n");
			sql.append(" SET   \n");
			sql.append("        MODEL_MATR_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrDesc());
							ps.setString(psCount++, tbmMdModelMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
						}
					}
		);			
	}

/**
* deleteTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return int
*/
	@LocalName("deleteTbmMdModelMatr")
	public int deleteTbmMdModelMatr (final TbmMdModelMatrDVO tbmMdModelMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.deleteTbmMdModelMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_MATR \n");
			sql.append("  WHERE MODEL_MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
						}
					}
		);			
	}

/**
* selectTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return TbmMdModelMatrDVO 
*/
	@LocalName("selectTbmMdModelMatr")
	public TbmMdModelMatrDVO selectTbmMdModelMatr (final TbmMdModelMatrDVO tbmMdModelMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.selectTbmMdModelMatr.001*/  \n");
			sql.append("        MODEL_MATR_CODE , \n");
			sql.append("        MODEL_MATR_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_MATR \n");
			sql.append("  WHERE MODEL_MATR_CODE = ? \n");

		return (TbmMdModelMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelMatrDVO returnTbmMdModelMatrDVO = new TbmMdModelMatrDVO();
									returnTbmMdModelMatrDVO.setModelMatrCode(resultSet.getString("MODEL_MATR_CODE"));
									returnTbmMdModelMatrDVO.setModelMatrDesc(resultSet.getString("MODEL_MATR_DESC"));
									returnTbmMdModelMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdModelMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelMatr Method")
	public int mergeTbmMdModelMatr (final TbmMdModelMatrDVO tbmMdModelMatrDVO) {
		
		if ( selectTbmMdModelMatr (tbmMdModelMatrDVO) == null) {
			return insertTbmMdModelMatr(tbmMdModelMatrDVO);
		} else {
			return selectUpdateTbmMdModelMatr (tbmMdModelMatrDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelMatr Method")
	public int selectUpdateTbmMdModelMatr (final TbmMdModelMatrDVO tbmMdModelMatrDVO) {
		
		TbmMdModelMatrDVO tmpTbmMdModelMatrDVO =  selectTbmMdModelMatr (tbmMdModelMatrDVO);
		if ( tbmMdModelMatrDVO.getModelMatrCode() != null && !"".equals(tbmMdModelMatrDVO.getModelMatrCode()) ) {
			tmpTbmMdModelMatrDVO.setModelMatrCode(tbmMdModelMatrDVO.getModelMatrCode());
		}		
		if ( tbmMdModelMatrDVO.getModelMatrDesc() != null && !"".equals(tbmMdModelMatrDVO.getModelMatrDesc()) ) {
			tmpTbmMdModelMatrDVO.setModelMatrDesc(tbmMdModelMatrDVO.getModelMatrDesc());
		}		
		if ( tbmMdModelMatrDVO.getUseYn() != null && !"".equals(tbmMdModelMatrDVO.getUseYn()) ) {
			tmpTbmMdModelMatrDVO.setUseYn(tbmMdModelMatrDVO.getUseYn());
		}		
		if ( tbmMdModelMatrDVO.getFstRegDt() != null && !"".equals(tbmMdModelMatrDVO.getFstRegDt()) ) {
			tmpTbmMdModelMatrDVO.setFstRegDt(tbmMdModelMatrDVO.getFstRegDt());
		}		
		if ( tbmMdModelMatrDVO.getFstRegerId() != null && !"".equals(tbmMdModelMatrDVO.getFstRegerId()) ) {
			tmpTbmMdModelMatrDVO.setFstRegerId(tbmMdModelMatrDVO.getFstRegerId());
		}		
		if ( tbmMdModelMatrDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelMatrDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelMatrDVO.setFnlUpdDt(tbmMdModelMatrDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelMatrDVO.getFnlUpderId() != null && !"".equals(tbmMdModelMatrDVO.getFnlUpderId()) ) {
			tmpTbmMdModelMatrDVO.setFnlUpderId(tbmMdModelMatrDVO.getFnlUpderId());
		}		
		return updateTbmMdModelMatr (tmpTbmMdModelMatrDVO);
	}

/**
* insertBatchTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelMatr")
	public int[] insertBatchTbmMdModelMatr (final List tbmMdModelMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.insertBatchTbmMdModelMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_MATR (   \n");
			sql.append("        MODEL_MATR_CODE , \n");
			sql.append("        MODEL_MATR_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelMatrDVO tbmMdModelMatrDVO = (TbmMdModelMatrDVO)tbmMdModelMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrDesc());
							ps.setString(psCount++, tbmMdModelMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelMatr")
	public int[] updateBatchTbmMdModelMatr (final List tbmMdModelMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.updateBatchTbmMdModelMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_MATR \n");
			sql.append(" SET   \n");
			sql.append("        MODEL_MATR_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelMatrDVO tbmMdModelMatrDVO = (TbmMdModelMatrDVO)tbmMdModelMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrDesc());
							ps.setString(psCount++, tbmMdModelMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
						}
							public int getBatchSize() {
									return tbmMdModelMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelMatr Method
* 
* @ref_table TBM_MD_MODEL_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelMatr")
	public int[] deleteBatchTbmMdModelMatr (final List tbmMdModelMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelMatrDEM.deleteBatchTbmMdModelMatr.001*/  \n");
			sql.append(" TBM_MD_MODEL_MATR \n");
			sql.append("  WHERE MODEL_MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelMatrDVO tbmMdModelMatrDVO = (TbmMdModelMatrDVO)tbmMdModelMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelMatrDVO.getModelMatrCode());
						}
							public int getBatchSize() {
									return tbmMdModelMatrDVOList.size();
							}
					}
		);			
	}

	
}