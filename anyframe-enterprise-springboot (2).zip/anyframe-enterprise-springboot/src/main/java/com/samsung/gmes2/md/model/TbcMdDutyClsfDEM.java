package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DUTY_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDutyClsfDEM extends AbstractDAO {


/**
* insertTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return int
*/
	@LocalName("insertTbcMdDutyClsf")
	public int insertTbcMdDutyClsf (final TbcMdDutyClsfDVO tbcMdDutyClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.insertTbcMdDutyClsf.001*/  \n");
			sql.append(" TBC_MD_DUTY_CLSF (   \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        DUTY_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfNm());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDutyClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDutyClsf Method")
	public int[][] updateBatchAllTbcMdDutyClsf (final List  tbcMdDutyClsfDVOList) {
		
		ArrayList updatetbcMdDutyClsfDVOList = new ArrayList();
		ArrayList insertttbcMdDutyClsfDVOList = new ArrayList();
		ArrayList deletetbcMdDutyClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDutyClsfDVOList.size() ; i++) {
		  TbcMdDutyClsfDVO tbcMdDutyClsfDVO = (TbcMdDutyClsfDVO) tbcMdDutyClsfDVOList.get(i);
		  
		  if (tbcMdDutyClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdDutyClsfDVOList.add(tbcMdDutyClsfDVO);
		  else if (tbcMdDutyClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdDutyClsfDVOList.add(tbcMdDutyClsfDVO);
		  else if (tbcMdDutyClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdDutyClsfDVOList.add(tbcMdDutyClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDutyClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDutyClsf(insertttbcMdDutyClsfDVOList);
          
      if (updatetbcMdDutyClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDutyClsf(updatetbcMdDutyClsfDVOList);
      
      if (deletetbcMdDutyClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDutyClsf(deletetbcMdDutyClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return int
*/
	@LocalName("updateTbcMdDutyClsf")
	public int updateTbcMdDutyClsf (final TbcMdDutyClsfDVO tbcMdDutyClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.updateTbcMdDutyClsf.001*/  \n");
			sql.append(" TBC_MD_DUTY_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        DUTY_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DUTY_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfNm());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return int
*/
	@LocalName("deleteTbcMdDutyClsf")
	public int deleteTbcMdDutyClsf (final TbcMdDutyClsfDVO tbcMdDutyClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.deleteTbcMdDutyClsf.001*/  \n");
			sql.append(" TBC_MD_DUTY_CLSF \n");
			sql.append("  WHERE DUTY_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return TbcMdDutyClsfDVO 
*/
	@LocalName("selectTbcMdDutyClsf")
	public TbcMdDutyClsfDVO selectTbcMdDutyClsf (final TbcMdDutyClsfDVO tbcMdDutyClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.selectTbcMdDutyClsf.001*/  \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        DUTY_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DUTY_CLSF \n");
			sql.append("  WHERE DUTY_CLSF_CODE = ? \n");

		return (TbcMdDutyClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDutyClsfDVO returnTbcMdDutyClsfDVO = new TbcMdDutyClsfDVO();
									returnTbcMdDutyClsfDVO.setDutyClsfCode(resultSet.getString("DUTY_CLSF_CODE"));
									returnTbcMdDutyClsfDVO.setDutyClsfNm(resultSet.getString("DUTY_CLSF_NM"));
									returnTbcMdDutyClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDutyClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDutyClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDutyClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDutyClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDutyClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDutyClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDutyClsf Method")
	public int mergeTbcMdDutyClsf (final TbcMdDutyClsfDVO tbcMdDutyClsfDVO) {
		
		if ( selectTbcMdDutyClsf (tbcMdDutyClsfDVO) == null) {
			return insertTbcMdDutyClsf(tbcMdDutyClsfDVO);
		} else {
			return selectUpdateTbcMdDutyClsf (tbcMdDutyClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDutyClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDutyClsf Method")
	public int selectUpdateTbcMdDutyClsf (final TbcMdDutyClsfDVO tbcMdDutyClsfDVO) {
		
		TbcMdDutyClsfDVO tmpTbcMdDutyClsfDVO =  selectTbcMdDutyClsf (tbcMdDutyClsfDVO);
		if ( tbcMdDutyClsfDVO.getDutyClsfCode() != null && !"".equals(tbcMdDutyClsfDVO.getDutyClsfCode()) ) {
			tmpTbcMdDutyClsfDVO.setDutyClsfCode(tbcMdDutyClsfDVO.getDutyClsfCode());
		}		
		if ( tbcMdDutyClsfDVO.getDutyClsfNm() != null && !"".equals(tbcMdDutyClsfDVO.getDutyClsfNm()) ) {
			tmpTbcMdDutyClsfDVO.setDutyClsfNm(tbcMdDutyClsfDVO.getDutyClsfNm());
		}		
		if ( tbcMdDutyClsfDVO.getUseYn() != null && !"".equals(tbcMdDutyClsfDVO.getUseYn()) ) {
			tmpTbcMdDutyClsfDVO.setUseYn(tbcMdDutyClsfDVO.getUseYn());
		}		
		if ( tbcMdDutyClsfDVO.getFstRegDt() != null && !"".equals(tbcMdDutyClsfDVO.getFstRegDt()) ) {
			tmpTbcMdDutyClsfDVO.setFstRegDt(tbcMdDutyClsfDVO.getFstRegDt());
		}		
		if ( tbcMdDutyClsfDVO.getFstRegerId() != null && !"".equals(tbcMdDutyClsfDVO.getFstRegerId()) ) {
			tmpTbcMdDutyClsfDVO.setFstRegerId(tbcMdDutyClsfDVO.getFstRegerId());
		}		
		if ( tbcMdDutyClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdDutyClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdDutyClsfDVO.setFnlUpdDt(tbcMdDutyClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdDutyClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdDutyClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdDutyClsfDVO.setFnlUpderId(tbcMdDutyClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdDutyClsf (tmpTbcMdDutyClsfDVO);
	}

/**
* insertBatchTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdDutyClsf")
	public int[] insertBatchTbcMdDutyClsf (final List tbcMdDutyClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.insertBatchTbcMdDutyClsf.001*/  \n");
			sql.append(" TBC_MD_DUTY_CLSF (   \n");
			sql.append("        DUTY_CLSF_CODE , \n");
			sql.append("        DUTY_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDutyClsfDVO tbcMdDutyClsfDVO = (TbcMdDutyClsfDVO)tbcMdDutyClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfNm());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDutyClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdDutyClsf")
	public int[] updateBatchTbcMdDutyClsf (final List tbcMdDutyClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.updateBatchTbcMdDutyClsf.001*/  \n");
			sql.append(" TBC_MD_DUTY_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        DUTY_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DUTY_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDutyClsfDVO tbcMdDutyClsfDVO = (TbcMdDutyClsfDVO)tbcMdDutyClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfNm());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDutyClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDutyClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDutyClsf Method
* 
* @ref_table TBC_MD_DUTY_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDutyClsf")
	public int[] deleteBatchTbcMdDutyClsf (final List tbcMdDutyClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDutyClsfDEM.deleteBatchTbcMdDutyClsf.001*/  \n");
			sql.append(" TBC_MD_DUTY_CLSF \n");
			sql.append("  WHERE DUTY_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDutyClsfDVO tbcMdDutyClsfDVO = (TbcMdDutyClsfDVO)tbcMdDutyClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDutyClsfDVO.getDutyClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDutyClsfDVOList.size();
							}
					}
		);			
	}

	
}