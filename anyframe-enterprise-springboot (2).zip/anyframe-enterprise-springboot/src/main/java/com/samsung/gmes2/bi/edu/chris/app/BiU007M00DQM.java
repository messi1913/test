package com.samsung.gmes2.bi.edu.chris.app;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

import com.samsung.gmes2.bi.edu.chris.vo.EmpInfoDVO;

/**
* 교육 후 삭제 합니다..
*
* @ref_table  
* @author Chris
*/
@Stereotype(Stereotype.Dao) @LocalName("교육용")
public class BiU007M00DQM extends AbstractDAO {


/**
* 
*
* SELECT *
* FROM EMP_INFO
* WHERE 1=1
* #if($empAge) 
* AND EMP_AGE > :empAge 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dList000 (final Map inputMap) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT * \n");
			sql.append(" FROM EMP_INFO \n");
			sql.append(" WHERE 1=1 \n");
			sql.append(" #if($empAge)  \n");
			sql.append(" AND EMP_AGE > :empAge  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.bi.edu.chris.app.BiU007M00DQM.dList000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									EmpInfoDVO returnEmpInfoDVO = new EmpInfoDVO();
									returnEmpInfoDVO.setEmpNo(resultSet.getString("EMP_NO"));
									returnEmpInfoDVO.setEmpName(resultSet.getString("EMP_NAME"));
									returnEmpInfoDVO.setEmpAge(resultSet.getBigDecimal("EMP_AGE"));
									returnEmpInfoDVO.setDeptCode(resultSet.getString("DEPT_CODE"));
									returnEmpInfoDVO.setTitleCode(resultSet.getString("TITLE_CODE"));
									returnEmpInfoDVO.setMailAddr(resultSet.getString("MAIL_ADDR"));
									return returnEmpInfoDVO;
					    	}
					    	
					   }
 		);
	}



}