package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbpMcLabelPrtPreprtDEM extends AbstractDAO {


/**
* insertTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return int
*/
	@LocalName("insertTbpMcLabelPrtPreprt")
	public int insertTbpMcLabelPrtPreprt (final TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.insertTbpMcLabelPrtPreprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_PREPRT (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtRsn());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbpMcLabelPrtPreprt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbpMcLabelPrtPreprt Method")
	public int[][] updateBatchAllTbpMcLabelPrtPreprt (final List  tbpMcLabelPrtPreprtDVOList) {
		
		ArrayList updatetbpMcLabelPrtPreprtDVOList = new ArrayList();
		ArrayList insertttbpMcLabelPrtPreprtDVOList = new ArrayList();
		ArrayList deletetbpMcLabelPrtPreprtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbpMcLabelPrtPreprtDVOList.size() ; i++) {
		  TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO = (TbpMcLabelPrtPreprtDVO) tbpMcLabelPrtPreprtDVOList.get(i);
		  
		  if (tbpMcLabelPrtPreprtDVO.getSqlAction().equals("C"))
		      insertttbpMcLabelPrtPreprtDVOList.add(tbpMcLabelPrtPreprtDVO);
		  else if (tbpMcLabelPrtPreprtDVO.getSqlAction().equals("U"))
		      updatetbpMcLabelPrtPreprtDVOList.add(tbpMcLabelPrtPreprtDVO);
		  else if (tbpMcLabelPrtPreprtDVO.getSqlAction().equals("D"))
		      deletetbpMcLabelPrtPreprtDVOList.add(tbpMcLabelPrtPreprtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbpMcLabelPrtPreprtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbpMcLabelPrtPreprt(insertttbpMcLabelPrtPreprtDVOList);
          
      if (updatetbpMcLabelPrtPreprtDVOList.size() >0)
          resultValues[1] = updateBatchTbpMcLabelPrtPreprt(updatetbpMcLabelPrtPreprtDVOList);
      
      if (deletetbpMcLabelPrtPreprtDVOList.size() >0)
          resultValues[2] = deleteBatchTbpMcLabelPrtPreprt(deletetbpMcLabelPrtPreprtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return int
*/
	@LocalName("updateTbpMcLabelPrtPreprt")
	public int updateTbpMcLabelPrtPreprt (final TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.updateTbpMcLabelPrtPreprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_PREPRT \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND NMG_SEQ = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtRsn());

							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
						}
					}
		);			
	}

/**
* deleteTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return int
*/
	@LocalName("deleteTbpMcLabelPrtPreprt")
	public int deleteTbpMcLabelPrtPreprt (final TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.deleteTbpMcLabelPrtPreprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_PREPRT \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
						}
					}
		);			
	}

/**
* selectTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return TbpMcLabelPrtPreprtDVO 
*/
	@LocalName("selectTbpMcLabelPrtPreprt")
	public TbpMcLabelPrtPreprtDVO selectTbpMcLabelPrtPreprt (final TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.selectTbpMcLabelPrtPreprt.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN \n");
			sql.append("   FROM TBP_MC_LABEL_PRT_PREPRT \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return (TbpMcLabelPrtPreprtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbpMcLabelPrtPreprtDVO returnTbpMcLabelPrtPreprtDVO = new TbpMcLabelPrtPreprtDVO();
									returnTbpMcLabelPrtPreprtDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbpMcLabelPrtPreprtDVO.setNmgSeq(resultSet.getBigDecimal("NMG_SEQ"));
									returnTbpMcLabelPrtPreprtDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbpMcLabelPrtPreprtDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbpMcLabelPrtPreprtDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbpMcLabelPrtPreprtDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbpMcLabelPrtPreprtDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbpMcLabelPrtPreprtDVO.setRePrtYn(resultSet.getString("RE_PRT_YN"));
									returnTbpMcLabelPrtPreprtDVO.setRePrtRsn(resultSet.getString("RE_PRT_RSN"));
									return returnTbpMcLabelPrtPreprtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbpMcLabelPrtPreprt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbpMcLabelPrtPreprt Method")
	public int mergeTbpMcLabelPrtPreprt (final TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO) {
		
		if ( selectTbpMcLabelPrtPreprt (tbpMcLabelPrtPreprtDVO) == null) {
			return insertTbpMcLabelPrtPreprt(tbpMcLabelPrtPreprtDVO);
		} else {
			return selectUpdateTbpMcLabelPrtPreprt (tbpMcLabelPrtPreprtDVO);
		}
	}

	/**
	 * selectUpdateTbpMcLabelPrtPreprt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbpMcLabelPrtPreprt Method")
	public int selectUpdateTbpMcLabelPrtPreprt (final TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO) {
		
		TbpMcLabelPrtPreprtDVO tmpTbpMcLabelPrtPreprtDVO =  selectTbpMcLabelPrtPreprt (tbpMcLabelPrtPreprtDVO);
		if ( tbpMcLabelPrtPreprtDVO.getNmgId() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getNmgId()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setNmgId(tbpMcLabelPrtPreprtDVO.getNmgId());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getNmgSeq() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getNmgSeq()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setNmgSeq(tbpMcLabelPrtPreprtDVO.getNmgSeq());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getPrtDt() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getPrtDt()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setPrtDt(tbpMcLabelPrtPreprtDVO.getPrtDt());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getPlantCode() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getPlantCode()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setPlantCode(tbpMcLabelPrtPreprtDVO.getPlantCode());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getModelCode() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getModelCode()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setModelCode(tbpMcLabelPrtPreprtDVO.getModelCode());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getLabelId() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getLabelId()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setLabelId(tbpMcLabelPrtPreprtDVO.getLabelId());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getPrterId() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getPrterId()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setPrterId(tbpMcLabelPrtPreprtDVO.getPrterId());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getRePrtYn() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getRePrtYn()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setRePrtYn(tbpMcLabelPrtPreprtDVO.getRePrtYn());
		}		
		if ( tbpMcLabelPrtPreprtDVO.getRePrtRsn() != null && !"".equals(tbpMcLabelPrtPreprtDVO.getRePrtRsn()) ) {
			tmpTbpMcLabelPrtPreprtDVO.setRePrtRsn(tbpMcLabelPrtPreprtDVO.getRePrtRsn());
		}		
		return updateTbpMcLabelPrtPreprt (tmpTbpMcLabelPrtPreprtDVO);
	}

/**
* insertBatchTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return int[]
*/
	@LocalName("insertBatchTbpMcLabelPrtPreprt")
	public int[] insertBatchTbpMcLabelPrtPreprt (final List tbpMcLabelPrtPreprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.insertBatchTbpMcLabelPrtPreprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_PREPRT (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        NMG_SEQ , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        RE_PRT_YN , \n");
			sql.append("        RE_PRT_RSN \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO = (TbpMcLabelPrtPreprtDVO)tbpMcLabelPrtPreprtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtRsn());

						}
							public int getBatchSize() {
									return tbpMcLabelPrtPreprtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return int[]
*/
	@LocalName("updateBatchTbpMcLabelPrtPreprt")
	public int[] updateBatchTbpMcLabelPrtPreprt (final List tbpMcLabelPrtPreprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.updateBatchTbpMcLabelPrtPreprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_PREPRT \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        RE_PRT_YN = ? , \n");
			sql.append("        RE_PRT_RSN = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");
			sql.append("   AND NMG_SEQ = ? \n");
			sql.append("   AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO = (TbpMcLabelPrtPreprtDVO)tbpMcLabelPrtPreprtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPlantCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getModelCode());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getLabelId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrterId());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtYn());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getRePrtRsn());

							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLabelPrtPreprtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbpMcLabelPrtPreprt Method
* 
* @ref_table TBP_MC_LABEL_PRT_PREPRT
* @return int[]
*/
	@LocalName("deleteBatchTbpMcLabelPrtPreprt")
	public int[] deleteBatchTbpMcLabelPrtPreprt (final List tbpMcLabelPrtPreprtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbpMcLabelPrtPreprtDEM.deleteBatchTbpMcLabelPrtPreprt.001*/  \n");
			sql.append(" TBP_MC_LABEL_PRT_PREPRT \n");
			sql.append("  WHERE NMG_ID = ? \n");
			sql.append("    AND NMG_SEQ = ? \n");
			sql.append("    AND PRT_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbpMcLabelPrtPreprtDVO tbpMcLabelPrtPreprtDVO = (TbpMcLabelPrtPreprtDVO)tbpMcLabelPrtPreprtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getNmgId());
							ps.setBigDecimal(psCount++, tbpMcLabelPrtPreprtDVO.getNmgSeq());
							ps.setString(psCount++, tbpMcLabelPrtPreprtDVO.getPrtDt());
						}
							public int getBatchSize() {
									return tbpMcLabelPrtPreprtDVOList.size();
							}
					}
		);			
	}

	
}