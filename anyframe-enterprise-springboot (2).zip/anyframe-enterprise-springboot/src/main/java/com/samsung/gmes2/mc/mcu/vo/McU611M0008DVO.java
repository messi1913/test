package com.samsung.gmes2.mc.mcu.vo;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 한글명 : 모델라벨 조회
 * 작성일 : 2011.06.29
 * 작성자 : 심 재 국
 * 작업상태 : 완료
 * 개요 :
 * 모델 라벨 조회하기 위한 DVO
 * @stereotype DAOVO
 * @author shim
 */
@LocalName("모델 라벨 조회")
public class McU611M0008DVO extends AbstractDVO {

    /**
     * 모델코드
     */
	@LocalName("모델코드") @Length(20) 
	private String modelCode;

    /**
     * 라벨명
     */
	@LocalName("라벨명") @Length(20) 
	private String labelName;

    /**
     * 라벨버전
     */
	@LocalName("라벨버전") @Length(5) @Scale(2) 
	private BigDecimal lblVer;

    /**
     * 라벨유형
     */
	@LocalName("라벨유형") @Length(30) 
	private String lblTypeCode;

    /**
     * 라벨 디자인 미리보기 이미지 파일
     */
	@LocalName("미리보기이미지파일") @Length(50) 
	private String pviewImgFile;

    /**
     * 상태
     */
	@LocalName("상태") @Length(50) 
	private String statusCode;

    /**
     * 등록자
     */
	@LocalName("등록자") @Length(10) 
	private String reger;

    /**
     * 등록일자
     */
	@LocalName("등록일자") @Length(10) 
	private String regDt;

    /**
     * 승인자
     */
	@LocalName("승인자") @Length(50) 
	private String cfmerId;

    /**
     * 승인일시
     */
	@LocalName("승인일시") @Length(14) 
	private String cfmDt;

    /**
     * 라벨 ID
     */
	@LocalName("라벨 ID") @Length(20) 
	private String labelId;


	/**
	 * 모델코드 Getter Method
	 * 
	 * @return 모델코드
	 */
	@LocalName("모델코드 Getter Method")
	public String getModelCode() {
		this.modelCode = super.getValue("modelCode");
		return this.modelCode;
	}

	/**
	 * 모델코드 Setter Method
	 * 
	 * @param String 모델코드
	 */
	@LocalName("모델코드 Setter Method")
	public void setModelCode(String modelCode) {
        super.setValue("modelCode", modelCode);
		this.modelCode = modelCode;
	}
	
	/**
	 * 라벨명 Getter Method
	 * 
	 * @return 라벨명
	 */
	@LocalName("라벨명 Getter Method")
	public String getLabelName() {
		this.labelName = super.getValue("labelName");
		return this.labelName;
	}

	/**
	 * 라벨명 Setter Method
	 * 
	 * @param String 라벨명
	 */
	@LocalName("라벨명 Setter Method")
	public void setLabelName(String labelName) {
        super.setValue("labelName", labelName);
		this.labelName = labelName;
	}
	
	/**
	 * 라벨버전 Getter Method
	 * 
	 * @return 라벨버전
	 */
	@LocalName("라벨버전 Getter Method")
	public BigDecimal getLblVer() {
		this.lblVer = super.getValue("lblVer");
		return this.lblVer;
	}

	/**
	 * 라벨버전 Setter Method
	 * 
	 * @param BigDecimal 라벨버전
	 */
	@LocalName("라벨버전 Setter Method")
	public void setLblVer(BigDecimal lblVer) {
        super.setValue("lblVer", lblVer);
		this.lblVer = lblVer;
	}
	
	/**
	 * 라벨유형 Getter Method
	 * 
	 * @return 라벨유형
	 */
	@LocalName("라벨유형 Getter Method")
	public String getLblTypeCode() {
		this.lblTypeCode = super.getValue("lblTypeCode");
		return this.lblTypeCode;
	}

	/**
	 * 라벨유형 Setter Method
	 * 
	 * @param String 라벨유형
	 */
	@LocalName("라벨유형 Setter Method")
	public void setLblTypeCode(String lblTypeCode) {
        super.setValue("lblTypeCode", lblTypeCode);
		this.lblTypeCode = lblTypeCode;
	}
	
	/**
	 * 미리보기이미지파일 Getter Method
	 * 
	 * @return 미리보기이미지파일
	 */
	@LocalName("미리보기이미지파일 Getter Method")
	public String getPviewImgFile() {
		this.pviewImgFile = super.getValue("pviewImgFile");
		return this.pviewImgFile;
	}

	/**
	 * 미리보기이미지파일 Setter Method
	 * 
	 * @param String 미리보기이미지파일
	 */
	@LocalName("미리보기이미지파일 Setter Method")
	public void setPviewImgFile(String pviewImgFile) {
        super.setValue("pviewImgFile", pviewImgFile);
		this.pviewImgFile = pviewImgFile;
	}
	
	/**
	 * 상태 Getter Method
	 * 
	 * @return 상태
	 */
	@LocalName("상태 Getter Method")
	public String getStatusCode() {
		this.statusCode = super.getValue("statusCode");
		return this.statusCode;
	}

	/**
	 * 상태 Setter Method
	 * 
	 * @param String 상태
	 */
	@LocalName("상태 Setter Method")
	public void setStatusCode(String statusCode) {
        super.setValue("statusCode", statusCode);
		this.statusCode = statusCode;
	}
	
	/**
	 * 등록자 Getter Method
	 * 
	 * @return 등록자
	 */
	@LocalName("등록자 Getter Method")
	public String getReger() {
		this.reger = super.getValue("reger");
		return this.reger;
	}

	/**
	 * 등록자 Setter Method
	 * 
	 * @param String 등록자
	 */
	@LocalName("등록자 Setter Method")
	public void setReger(String reger) {
        super.setValue("reger", reger);
		this.reger = reger;
	}
	
	/**
	 * 등록일자 Getter Method
	 * 
	 * @return 등록일자
	 */
	@LocalName("등록일자 Getter Method")
	public String getRegDt() {
		this.regDt = super.getValue("regDt");
		return this.regDt;
	}

	/**
	 * 등록일자 Setter Method
	 * 
	 * @param String 등록일자
	 */
	@LocalName("등록일자 Setter Method")
	public void setRegDt(String regDt) {
        super.setValue("regDt", regDt);
		this.regDt = regDt;
	}
	
	/**
	 * 승인자 Getter Method
	 * 
	 * @return 승인자
	 */
	@LocalName("승인자 Getter Method")
	public String getCfmerId() {
		this.cfmerId = super.getValue("cfmerId");
		return this.cfmerId;
	}

	/**
	 * 승인자 Setter Method
	 * 
	 * @param String 승인자
	 */
	@LocalName("승인자 Setter Method")
	public void setCfmerId(String cfmerId) {
        super.setValue("cfmerId", cfmerId);
		this.cfmerId = cfmerId;
	}
	
	/**
	 * 승인일시 Getter Method
	 * 
	 * @return 승인일시
	 */
	@LocalName("승인일시 Getter Method")
	public String getCfmDt() {
		this.cfmDt = super.getValue("cfmDt");
		return this.cfmDt;
	}

	/**
	 * 승인일시 Setter Method
	 * 
	 * @param String 승인일시
	 */
	@LocalName("승인일시 Setter Method")
	public void setCfmDt(String cfmDt) {
        super.setValue("cfmDt", cfmDt);
		this.cfmDt = cfmDt;
	}
	
	/**
	 * 라벨 ID Getter Method
	 * 
	 * @return 라벨 ID
	 */
	@LocalName("라벨 ID Getter Method")
	public String getLabelId() {
		this.labelId = super.getValue("labelId");
		return this.labelId;
	}

	/**
	 * 라벨 ID Setter Method
	 * 
	 * @param String 라벨 ID
	 */
	@LocalName("라벨 ID Setter Method")
	public void setLabelId(String labelId) {
        super.setValue("labelId", labelId);
		this.labelId = labelId;
	}
	
}