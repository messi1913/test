/**
 * <PRE>
 * System Name : MD
 * Business Name : 마스터 데이터
 * Class Name : MdManageTbmMdProcBiz.java
 * Description : 테이블 TbmMdProc에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.19          심재국          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbmMdLineDVO;
import com.samsung.gmes2.md.model.TbmMdProcDVO;
import com.samsung.gmes2.sm.model.TbcMdCommCodeDVO;

public class MdManageTbmMdProcBiz{
	/**
	 * TbmMdProc table에서
	 * 다른 table의 참조키를 check
	 * 하는 공통 로직
	 */
	public void common(TbmMdProcDVO tbmMdProcDVO)
			throws Exception {
		//BaseUtil.checkNotEmpty(tbmMdProcDVO);
		
		
		// TbmMdLine의 참조키가 되는 fctCode 와 lineCode 값이 있는지를 체크
		TbmMdLineDVO tbmMdLineDVO = new TbmMdLineDVO();
		BaseUtil.populate(tbmMdProcDVO, tbmMdLineDVO, "fctCode,lineCode");
		BaseUtil.checkFound(tbmMdLineDVO);
		//TbcMdCommCode 참조키가 되는 InlineGubunCode 값이 있는지를 체크
		
		TbcMdCommCodeDVO tbcMdCommCodeDVO = new TbcMdCommCodeDVO();
		BaseUtil.populate(tbmMdProcDVO, tbcMdCommCodeDVO, "inlineGubunCode:commCode");
		BaseUtil.checkFound(tbcMdCommCodeDVO);

	}
	/**
	 * TbmMdProc 등록을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdProcDVO 값을 넣어준다
	 */
	public TbmMdProcDVO createTbmMdProc(TbmMdProcDVO tbmMdProcDVO)
			throws Exception {
		
		common(tbmMdProcDVO);
		return CrudUtil.create(tbmMdProcDVO);

	}

	/**
	 * TbmMdProc 삭제을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdProcDVO 값을 넣어준다
	 */
	public TbmMdProcDVO deleteTbmMdProc(TbmMdProcDVO tbmMdProcDVO)
			throws Exception {
		common(tbmMdProcDVO);
		return CrudUtil.delete(tbmMdProcDVO);
	}

	/**
	 * TbmMdProc 수정을 하기위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdProcDVO 값을 넣어준다
	 */
	public TbmMdProcDVO updateTbmMdProc(TbmMdProcDVO tbmMdProcDVO)
			throws Exception {
		common(tbmMdProcDVO);
		return CrudUtil.update(tbmMdProcDVO);
	}

	/**
	 * TbmMdProc 정보를 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdProcDVO 값을 넣어준다
	 * 단건 조회
	 */
	public TbmMdProcDVO getTbmMdProc(TbmMdProcDVO tbmMdProcDVO)
			throws Exception {
		//BaseUtil.checkNotEmpty(tbmMdProcDVO);
		return CrudUtil.get(tbmMdProcDVO);
	}

	/**
	 * TbmMdProc 정보 List를 얻어 오기 위한 메서드
	 * CrudUtil 을 사용 하여 TbmMdProcDVO 값을 넣어준다
	 * 다건 조회
	 * @param tbmMdProcDVO
	 * @return
	 */
	public List<TbmMdProcDVO> listTbmMdProc(TbmMdProcDVO tbmMdProcDVO)
			throws Exception {
		
		return CrudUtil.list0(TbmMdProcDVO.class, tbmMdProcDVO, 0, 0);
	}
}
