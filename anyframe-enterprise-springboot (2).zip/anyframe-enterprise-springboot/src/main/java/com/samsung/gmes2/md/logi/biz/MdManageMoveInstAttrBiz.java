package com.samsung.gmes2.md.logi.biz;

public class MdManageMoveInstAttrBiz {

	/**
	 * 이동지시속성 목록 조회
	 */
	public void listMoveInstAttr(){}

	/**
	 * 이동지시속성 목록 저장
	 */
	public void saveMoveInstAttr(){}

}
