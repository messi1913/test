package com.samsung.gmes2.aop;

import java.lang.reflect.Method;
import java.util.Set;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.samsung.gmes2.base.util.BeanUtil;
import com.samsung.gmes2.base.util.ReflectionUtil;

public class TransactionAdvice extends AbstractAdvice
{
	private static Set<String>			readOnlyPrefixSet	= toSet( "get" );

	private PlatformTransactionManager	transactionManager;

	private int							transactionTimeout	= 20000;

	public PlatformTransactionManager getTransactionManager( )
	{
		if ( transactionManager == null )
			transactionManager = (PlatformTransactionManager) BeanUtil.get( "transactionManager" );
		return transactionManager;
	}

	public void setTransactionManager( PlatformTransactionManager transactionManager )
	{
		this.transactionManager = transactionManager;
	}

	public int getTransactionTimeout( )
	{
		return transactionTimeout;
	}

	public void setTransactionTimeout( int transactionTimeout )
	{
		this.transactionTimeout = transactionTimeout;
	}

	public Object invoke( ProceedingJoinPoint call ) throws Throwable
	{
		/**
		 * Meta-Info
		 */
		Signature signature = call.getSignature( );
		String methodName = signature.getName( );
		Method method = ReflectionUtil.getMethod( signature );
		Transactional tran = method == null ? null : method.getAnnotation( Transactional.class );

		/**
		 * Begin Tran
		 */
		DefaultTransactionDefinition definition = new DefaultTransactionDefinition( );
		// set name
		Service svcAnn = call.getTarget( ).getClass( ).getAnnotation( Service.class );
		if ( svcAnn != null )
			definition.setName( new StringBuffer( svcAnn.value( ) ).append( "." ).append( methodName ).toString( ) );
		// set propagation
		definition.setPropagationBehavior( tran == null ? TransactionDefinition.PROPAGATION_REQUIRED : tran.propagation( ).value( ) );
		// set readOnly
		for ( String prefix : readOnlyPrefixSet )
		{
			if ( methodName.startsWith( prefix ) )
				definition.setReadOnly( true );
		}
		// set timeout
		definition.setTimeout( transactionTimeout );
		TransactionStatus status = getTransactionManager( ).getTransaction( definition );

		Object res = null;
		try
		{
			res = call.proceed( );
			getTransactionManager( ).commit( status );
		}
		catch ( Throwable t )
		{
			if ( !status.isCompleted( ) )
				getTransactionManager( ).rollback( status );
			throw t;
		}
		return res;
	}
}
