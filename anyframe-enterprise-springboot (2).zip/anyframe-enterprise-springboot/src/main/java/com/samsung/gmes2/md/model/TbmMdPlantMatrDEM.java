package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PLANT_MATR
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPlantMatrDEM extends AbstractDAO {


/**
* insertTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return int
*/
	@LocalName("insertTbmMdPlantMatr")
	public int insertTbmMdPlantMatr (final TbmMdPlantMatrDVO tbmMdPlantMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.insertTbmMdPlantMatr.001*/  \n");
			sql.append(" TBM_MD_PLANT_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPlantMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPlantMatr Method")
	public int[][] updateBatchAllTbmMdPlantMatr (final List  tbmMdPlantMatrDVOList) {
		
		ArrayList updatetbmMdPlantMatrDVOList = new ArrayList();
		ArrayList insertttbmMdPlantMatrDVOList = new ArrayList();
		ArrayList deletetbmMdPlantMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPlantMatrDVOList.size() ; i++) {
		  TbmMdPlantMatrDVO tbmMdPlantMatrDVO = (TbmMdPlantMatrDVO) tbmMdPlantMatrDVOList.get(i);
		  
		  if (tbmMdPlantMatrDVO.getSqlAction().equals("C"))
		      insertttbmMdPlantMatrDVOList.add(tbmMdPlantMatrDVO);
		  else if (tbmMdPlantMatrDVO.getSqlAction().equals("U"))
		      updatetbmMdPlantMatrDVOList.add(tbmMdPlantMatrDVO);
		  else if (tbmMdPlantMatrDVO.getSqlAction().equals("D"))
		      deletetbmMdPlantMatrDVOList.add(tbmMdPlantMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPlantMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPlantMatr(insertttbmMdPlantMatrDVOList);
          
      if (updatetbmMdPlantMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPlantMatr(updatetbmMdPlantMatrDVOList);
      
      if (deletetbmMdPlantMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPlantMatr(deletetbmMdPlantMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return int
*/
	@LocalName("updateTbmMdPlantMatr")
	public int updateTbmMdPlantMatr (final TbmMdPlantMatrDVO tbmMdPlantMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.updateTbmMdPlantMatr.001*/  \n");
			sql.append(" TBM_MD_PLANT_MATR \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantMatrDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* deleteTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return int
*/
	@LocalName("deleteTbmMdPlantMatr")
	public int deleteTbmMdPlantMatr (final TbmMdPlantMatrDVO tbmMdPlantMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.deleteTbmMdPlantMatr.001*/  \n");
			sql.append(" TBM_MD_PLANT_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* selectTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return TbmMdPlantMatrDVO 
*/
	@LocalName("selectTbmMdPlantMatr")
	public TbmMdPlantMatrDVO selectTbmMdPlantMatr (final TbmMdPlantMatrDVO tbmMdPlantMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.selectTbmMdPlantMatr.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PLANT_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return (TbmMdPlantMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPlantMatrDVO returnTbmMdPlantMatrDVO = new TbmMdPlantMatrDVO();
									returnTbmMdPlantMatrDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPlantMatrDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdPlantMatrDVO.setIfDt(resultSet.getString("IF_DT"));
									returnTbmMdPlantMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdPlantMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPlantMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPlantMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPlantMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPlantMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPlantMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPlantMatr Method")
	public int mergeTbmMdPlantMatr (final TbmMdPlantMatrDVO tbmMdPlantMatrDVO) {
		
		if ( selectTbmMdPlantMatr (tbmMdPlantMatrDVO) == null) {
			return insertTbmMdPlantMatr(tbmMdPlantMatrDVO);
		} else {
			return selectUpdateTbmMdPlantMatr (tbmMdPlantMatrDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPlantMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPlantMatr Method")
	public int selectUpdateTbmMdPlantMatr (final TbmMdPlantMatrDVO tbmMdPlantMatrDVO) {
		
		TbmMdPlantMatrDVO tmpTbmMdPlantMatrDVO =  selectTbmMdPlantMatr (tbmMdPlantMatrDVO);
		if ( tbmMdPlantMatrDVO.getPlantCode() != null && !"".equals(tbmMdPlantMatrDVO.getPlantCode()) ) {
			tmpTbmMdPlantMatrDVO.setPlantCode(tbmMdPlantMatrDVO.getPlantCode());
		}		
		if ( tbmMdPlantMatrDVO.getMatrCode() != null && !"".equals(tbmMdPlantMatrDVO.getMatrCode()) ) {
			tmpTbmMdPlantMatrDVO.setMatrCode(tbmMdPlantMatrDVO.getMatrCode());
		}		
		if ( tbmMdPlantMatrDVO.getIfDt() != null && !"".equals(tbmMdPlantMatrDVO.getIfDt()) ) {
			tmpTbmMdPlantMatrDVO.setIfDt(tbmMdPlantMatrDVO.getIfDt());
		}		
		if ( tbmMdPlantMatrDVO.getUseYn() != null && !"".equals(tbmMdPlantMatrDVO.getUseYn()) ) {
			tmpTbmMdPlantMatrDVO.setUseYn(tbmMdPlantMatrDVO.getUseYn());
		}		
		if ( tbmMdPlantMatrDVO.getFstRegDt() != null && !"".equals(tbmMdPlantMatrDVO.getFstRegDt()) ) {
			tmpTbmMdPlantMatrDVO.setFstRegDt(tbmMdPlantMatrDVO.getFstRegDt());
		}		
		if ( tbmMdPlantMatrDVO.getFstRegerId() != null && !"".equals(tbmMdPlantMatrDVO.getFstRegerId()) ) {
			tmpTbmMdPlantMatrDVO.setFstRegerId(tbmMdPlantMatrDVO.getFstRegerId());
		}		
		if ( tbmMdPlantMatrDVO.getFnlUpdDt() != null && !"".equals(tbmMdPlantMatrDVO.getFnlUpdDt()) ) {
			tmpTbmMdPlantMatrDVO.setFnlUpdDt(tbmMdPlantMatrDVO.getFnlUpdDt());
		}		
		if ( tbmMdPlantMatrDVO.getFnlUpderId() != null && !"".equals(tbmMdPlantMatrDVO.getFnlUpderId()) ) {
			tmpTbmMdPlantMatrDVO.setFnlUpderId(tbmMdPlantMatrDVO.getFnlUpderId());
		}		
		return updateTbmMdPlantMatr (tmpTbmMdPlantMatrDVO);
	}

/**
* insertBatchTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return int[]
*/
	@LocalName("insertBatchTbmMdPlantMatr")
	public int[] insertBatchTbmMdPlantMatr (final List tbmMdPlantMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.insertBatchTbmMdPlantMatr.001*/  \n");
			sql.append(" TBM_MD_PLANT_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantMatrDVO tbmMdPlantMatrDVO = (TbmMdPlantMatrDVO)tbmMdPlantMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPlantMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return int[]
*/
	@LocalName("updateBatchTbmMdPlantMatr")
	public int[] updateBatchTbmMdPlantMatr (final List tbmMdPlantMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.updateBatchTbmMdPlantMatr.001*/  \n");
			sql.append(" TBM_MD_PLANT_MATR \n");
			sql.append(" SET   \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantMatrDVO tbmMdPlantMatrDVO = (TbmMdPlantMatrDVO)tbmMdPlantMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantMatrDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdPlantMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPlantMatr Method
* 
* @ref_table TBM_MD_PLANT_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPlantMatr")
	public int[] deleteBatchTbmMdPlantMatr (final List tbmMdPlantMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantMatrDEM.deleteBatchTbmMdPlantMatr.001*/  \n");
			sql.append(" TBM_MD_PLANT_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantMatrDVO tbmMdPlantMatrDVO = (TbmMdPlantMatrDVO)tbmMdPlantMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdPlantMatrDVOList.size();
							}
					}
		);			
	}

	
}