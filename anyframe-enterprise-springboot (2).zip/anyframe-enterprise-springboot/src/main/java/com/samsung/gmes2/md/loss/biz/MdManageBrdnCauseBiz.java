package com.samsung.gmes2.md.loss.biz;

public class MdManageBrdnCauseBiz {

	/**
	 * 고장원인코드 목록 조회
	 */
	public void listBrdnCauseCode(){}

	/**
	 * 고장원인코드 목록 저장
	 */
	public void saveBrdnCauseCode(){}

}
