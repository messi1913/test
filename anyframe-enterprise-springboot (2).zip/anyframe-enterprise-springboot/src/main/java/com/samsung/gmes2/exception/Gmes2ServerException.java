package com.samsung.gmes2.exception;

@SuppressWarnings("serial")
public class Gmes2ServerException extends Gmes2Exception {
	public static final String CODE_SERVER = "SM-E-SERV";
	public Gmes2ServerException() {
		super();
	}
	public Gmes2ServerException(String message) {
		super(message);
	}
	public Gmes2ServerException(Throwable cause) {
		super(cause);
	}
	public Gmes2ServerException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getCode() {
		return CODE_SERVER;
	}
}
