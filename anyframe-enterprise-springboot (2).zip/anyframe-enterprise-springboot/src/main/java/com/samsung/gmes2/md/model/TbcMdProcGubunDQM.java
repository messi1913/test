package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdProcGubunDQM extends AbstractDAO {


/**
*
* SELECT 
* 	PROC_GUBUN_CODE, 
* 	PROC_GUBUN_CODE_NM, 
* 	PROC_GUBUN_DESC, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PROC_GUBUN 
* WHERE 1=1 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procGubunCodeNm) 
* AND PROC_GUBUN_CODE_NM = :procGubunCodeNm 
* #end 
* #if($procGubunDesc) 
* AND PROC_GUBUN_DESC = :procGubunDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE_NM,  \n");
			sql.append(" 	PROC_GUBUN_DESC,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PROC_GUBUN  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCodeNm)  \n");
			sql.append(" AND PROC_GUBUN_CODE_NM = :procGubunCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunDesc)  \n");
			sql.append(" AND PROC_GUBUN_DESC = :procGubunDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProcGubunDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProcGubunDVO returnTbcMdProcGubunDVO = new TbcMdProcGubunDVO();
									returnTbcMdProcGubunDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdProcGubunDVO.setProcGubunCodeNm(resultSet.getString("PROC_GUBUN_CODE_NM"));
									returnTbcMdProcGubunDVO.setProcGubunDesc(resultSet.getString("PROC_GUBUN_DESC"));
									returnTbcMdProcGubunDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProcGubunDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProcGubunDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProcGubunDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProcGubunDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	PROC_GUBUN_CODE, 
* 	PROC_GUBUN_CODE_NM, 
* 	PROC_GUBUN_DESC
* FROM TBC_MD_PROC_GUBUN 
* WHERE 1=1 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procGubunCodeNm) 
* AND PROC_GUBUN_CODE_NM = :procGubunCodeNm 
* #end 
* #if($procGubunDesc) 
* AND PROC_GUBUN_DESC = :procGubunDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE_NM,  \n");
			sql.append(" 	PROC_GUBUN_DESC \n");
			sql.append(" FROM TBC_MD_PROC_GUBUN  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCodeNm)  \n");
			sql.append(" AND PROC_GUBUN_CODE_NM = :procGubunCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunDesc)  \n");
			sql.append(" AND PROC_GUBUN_DESC = :procGubunDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProcGubunDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProcGubunDVO returnTbcMdProcGubunDVO = new TbcMdProcGubunDVO();
									returnTbcMdProcGubunDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdProcGubunDVO.setProcGubunCodeNm(resultSet.getString("PROC_GUBUN_CODE_NM"));
									returnTbcMdProcGubunDVO.setProcGubunDesc(resultSet.getString("PROC_GUBUN_DESC"));
									return returnTbcMdProcGubunDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	PROC_GUBUN_CODE, 
* 	PROC_GUBUN_CODE_NM, 
* 	PROC_GUBUN_DESC, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PROC_GUBUN 
* WHERE 1=1 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procGubunCodeNm) 
* AND PROC_GUBUN_CODE_NM = :procGubunCodeNm 
* #end 
* #if($procGubunDesc) 
* AND PROC_GUBUN_DESC = :procGubunDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE_NM,  \n");
			sql.append(" 	PROC_GUBUN_DESC,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PROC_GUBUN  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCodeNm)  \n");
			sql.append(" AND PROC_GUBUN_CODE_NM = :procGubunCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunDesc)  \n");
			sql.append(" AND PROC_GUBUN_DESC = :procGubunDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProcGubunDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProcGubunDVO returnTbcMdProcGubunDVO = new TbcMdProcGubunDVO();
									returnTbcMdProcGubunDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdProcGubunDVO.setProcGubunCodeNm(resultSet.getString("PROC_GUBUN_CODE_NM"));
									returnTbcMdProcGubunDVO.setProcGubunDesc(resultSet.getString("PROC_GUBUN_DESC"));
									returnTbcMdProcGubunDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdProcGubunDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdProcGubunDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdProcGubunDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdProcGubunDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	PROC_GUBUN_CODE, 
* 	PROC_GUBUN_CODE_NM, 
* 	PROC_GUBUN_DESC
* FROM TBC_MD_PROC_GUBUN 
* WHERE 1=1 
* #if($procGubunCode) 
* AND PROC_GUBUN_CODE = :procGubunCode 
* #end 
* #if($procGubunCodeNm) 
* AND PROC_GUBUN_CODE_NM = :procGubunCodeNm 
* #end 
* #if($procGubunDesc) 
* AND PROC_GUBUN_DESC = :procGubunDesc 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PROC_GUBUN_CODE,  \n");
			sql.append(" 	PROC_GUBUN_CODE_NM,  \n");
			sql.append(" 	PROC_GUBUN_DESC \n");
			sql.append(" FROM TBC_MD_PROC_GUBUN  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($procGubunCode)  \n");
			sql.append(" AND PROC_GUBUN_CODE = :procGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunCodeNm)  \n");
			sql.append(" AND PROC_GUBUN_CODE_NM = :procGubunCodeNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procGubunDesc)  \n");
			sql.append(" AND PROC_GUBUN_DESC = :procGubunDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdProcGubunDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdProcGubunDVO returnTbcMdProcGubunDVO = new TbcMdProcGubunDVO();
									returnTbcMdProcGubunDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdProcGubunDVO.setProcGubunCodeNm(resultSet.getString("PROC_GUBUN_CODE_NM"));
									returnTbcMdProcGubunDVO.setProcGubunDesc(resultSet.getString("PROC_GUBUN_DESC"));
									return returnTbcMdProcGubunDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}