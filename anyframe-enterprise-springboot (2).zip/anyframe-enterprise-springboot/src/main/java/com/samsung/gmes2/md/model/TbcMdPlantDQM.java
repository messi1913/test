package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* Plant 코드 조회 DQM
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao) @LocalName("Plant 코드 조회 DQM")
public class TbcMdPlantDQM extends AbstractDAO {


/**
*
* SELECT 
* 	PLANT_CODE, 
* 	FCT_CODE, 
* 	GBM_CODE, 
* 	PLANT_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	OUTS_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PLANT 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($plantNm) 
* AND PLANT_NM = :plantNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	PLANT_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PLANT  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($plantNm)  \n");
			sql.append(" AND PLANT_NM = :plantNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdPlantDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdPlantDVO returnTbcMdPlantDVO = new TbcMdPlantDVO();
									returnTbcMdPlantDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbcMdPlantDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdPlantDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdPlantDVO.setPlantNm(resultSet.getString("PLANT_NM"));
									returnTbcMdPlantDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdPlantDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdPlantDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdPlantDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdPlantDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdPlantDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdPlantDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdPlantDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	PLANT_CODE, 
* 	FCT_CODE, 
* 	GBM_CODE, 
* 	PLANT_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	OUTS_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PLANT 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($plantNm) 
* AND PLANT_NM = :plantNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	PLANT_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PLANT  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($plantNm)  \n");
			sql.append(" AND PLANT_NM = :plantNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdPlantDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdPlantDVO returnTbcMdPlantDVO = new TbcMdPlantDVO();
									returnTbcMdPlantDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbcMdPlantDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdPlantDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdPlantDVO.setPlantNm(resultSet.getString("PLANT_NM"));
									returnTbcMdPlantDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdPlantDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdPlantDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdPlantDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdPlantDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdPlantDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdPlantDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdPlantDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	PLANT_CODE, 
* 	FCT_CODE, 
* 	GBM_CODE, 
* 	PLANT_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	OUTS_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PLANT 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($plantNm) 
* AND PLANT_NM = :plantNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	PLANT_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PLANT  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($plantNm)  \n");
			sql.append(" AND PLANT_NM = :plantNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdPlantDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdPlantDVO returnTbcMdPlantDVO = new TbcMdPlantDVO();
									returnTbcMdPlantDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbcMdPlantDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdPlantDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdPlantDVO.setPlantNm(resultSet.getString("PLANT_NM"));
									returnTbcMdPlantDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdPlantDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdPlantDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdPlantDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdPlantDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdPlantDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdPlantDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdPlantDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	PLANT_CODE, 
* 	FCT_CODE, 
* 	GBM_CODE, 
* 	PLANT_NM, 
* 	FNL_ACRS_REFL_YN, 
* 	OUTS_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_PLANT 
* WHERE 1=1 
* #if($plantCode) 
* AND PLANT_CODE = :plantCode 
* #end 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($gbmCode) 
* AND GBM_CODE = :gbmCode 
* #end 
* #if($plantNm) 
* AND PLANT_NM = :plantNm 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($outsYn) 
* AND OUTS_YN = :outsYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	PLANT_CODE,  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	GBM_CODE,  \n");
			sql.append(" 	PLANT_NM,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OUTS_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_PLANT  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($plantCode)  \n");
			sql.append(" AND PLANT_CODE = :plantCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($gbmCode)  \n");
			sql.append(" AND GBM_CODE = :gbmCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($plantNm)  \n");
			sql.append(" AND PLANT_NM = :plantNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($outsYn)  \n");
			sql.append(" AND OUTS_YN = :outsYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdPlantDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdPlantDVO returnTbcMdPlantDVO = new TbcMdPlantDVO();
									returnTbcMdPlantDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbcMdPlantDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdPlantDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbcMdPlantDVO.setPlantNm(resultSet.getString("PLANT_NM"));
									returnTbcMdPlantDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdPlantDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbcMdPlantDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdPlantDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdPlantDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdPlantDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdPlantDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdPlantDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}