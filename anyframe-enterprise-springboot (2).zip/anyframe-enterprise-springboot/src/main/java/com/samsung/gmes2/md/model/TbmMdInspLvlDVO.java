package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdInspLvlDVO extends AbstractVo {

	@Length(30) 
	private String inspLvlCode;

	@Length(30) 
	private String smplCharCode;

	@Length(11) @Scale(5) 
	private BigDecimal minSize;

	@Length(11) @Scale(5) 
	private BigDecimal maxSize;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getInspLvlCode() {
		this.inspLvlCode = super.getValue(0);
		return this.inspLvlCode;
	}

	public void setInspLvlCode(String inspLvlCode) {
        super.setValue(0, inspLvlCode);
		this.inspLvlCode = inspLvlCode;
	}
	
	public String getSmplCharCode() {
		this.smplCharCode = super.getValue(1);
		return this.smplCharCode;
	}

	public void setSmplCharCode(String smplCharCode) {
        super.setValue(1, smplCharCode);
		this.smplCharCode = smplCharCode;
	}
	
	public BigDecimal getMinSize() {
		this.minSize = super.getValue(2);
		return this.minSize;
	}

	public void setMinSize(BigDecimal minSize) {
        super.setValue(2, minSize);
		this.minSize = minSize;
	}
	
	public BigDecimal getMaxSize() {
		this.maxSize = super.getValue(3);
		return this.maxSize;
	}

	public void setMaxSize(BigDecimal maxSize) {
        super.setValue(3, maxSize);
		this.maxSize = maxSize;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(4);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(4, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(5);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(5, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(6);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(6, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(7);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(7, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(8);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(8, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}