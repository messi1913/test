package com.samsung.gmes2.md.loss.app;

public class MDU441M01App {

	/**
	 * 정시정량차질원인코드 목록 초기설정
	 */
	public void initFxPrblmCauseCode(){}

	/**
	 * 정시정량차질원인코드 목록 조회
	 */
	public void listFxPrblmCauseCode(){}

	/**
	 * 정시정량차질원인코드 목록 엑셀 다운로드
	 */
	public void excelFxPrblmCauseCode(){}

	/**
	 * 정시정량차질원인코드 목록 저장
	 */
	public void saveFxPrblmCauseCode(){}

}
