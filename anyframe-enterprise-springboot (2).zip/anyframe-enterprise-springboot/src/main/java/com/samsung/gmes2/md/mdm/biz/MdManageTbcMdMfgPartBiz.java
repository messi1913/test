/**
 * <PRE>
 * System Name : MD
 * Business Name : MDM
 * Class Name : MdManageTbcMdMfgPartBiz.java
 * Description : 테이블 TbcMdMfgPart에대한 CRUD 기능을 담당하는 컴포넌트
 * Modification History
 *          수정일                  수정자          수정내용
 *    --------------------------------------------------------
 *    2011.07.19                    호건웅          최초 생성
 *    
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */

package com.samsung.gmes2.md.mdm.biz;

import java.text.SimpleDateFormat;
import java.util.List;

import com.anyframe.core.vo.VoUtil;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.exception.Gmes2LogicException;
import com.samsung.gmes2.md.model.TbcMdCommOrgDVO;
import com.samsung.gmes2.md.model.TbcMdMfgGrpDVO;
import com.samsung.gmes2.md.model.TbcMdMfgPartDEM;
import com.samsung.gmes2.md.model.TbcMdMfgPartDQM;
import com.samsung.gmes2.md.model.TbcMdMfgPartDVO;
import com.samsung.gmes2.md.model.TbcMdMfgTeamDVO;
import com.samsung.gmes2.md.model.TbcMdProcGubunDVO;
import com.samsung.gmes2.md.model.TbcMdProcTypeDVO;

public class MdManageTbcMdMfgPartBiz {
	
	/**
	 * 제조 파트 정보 생성을 수행한다
	 * @name_ko 제조 파트 정보 생성 메서드
	 */
	public TbcMdMfgPartDVO createNewTbcMdMfgPartRow(TbcMdMfgPartDVO inputDvo) throws Exception {
		/*--------------------------------------------------
		 * @fd_do_start 생성하려는 정보가 무결성 제약을 위반했는지를 판단
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

		
		return CrudUtil.create( inputDvo );
	}

	/**
	 * 제조 파트 정보를 삭제를 수행한다
	 * @name_ko 제조 파트 정보 삭제 메서드
	 */
	public TbcMdMfgPartDVO deleteTbcMdMfgPartRow(TbcMdMfgPartDVO inputDvo) throws Exception {
		return CrudUtil.delete( inputDvo );
	}

	/**
	 * 제조 파트 정보를 수정을 수행한다
	 * @name_ko 제조 파트 정보 수정 메서드
	 */
	public TbcMdMfgPartDVO updateTbcMdMfgPartRow(TbcMdMfgPartDVO inputDvo) throws Exception {
		/*--------------------------------------------------
		 * @fd_do_start 수정하려는 정보가 무결성 제약을 위반했는지를 체크
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		checkIntegrityConstraint( inputDvo );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

		
		return CrudUtil.update( inputDvo );
	}

	/**
	 * 제조 파트 정보에 대하여 단건 조회를 수행한다
	 * @name_ko 제조 파트 단건 조회 메서드
	 */
	public TbcMdMfgPartDVO getTbcMdMfgPartRow(TbcMdMfgPartDVO inputDvo) throws Exception {
		return CrudUtil.get( inputDvo );
		
	}

	

	/**
	 * 제조 파트 정보에 대해 다건 조회를 수행한다
	 * @name_ko 제조 파트 다건 조회 메서드
	 */
	public List<TbcMdMfgPartDVO> listTbcMdMfgPart(TbcMdMfgPartDVO inputDvo) throws Exception {
		
		

		List resultList = CrudUtil.list0(TbcMdMfgPartDVO.class, inputDvo, 0, 0);
		/*--------------------------------------------------
		 * @fd_if 다건 조회 결과가 있으면 조회 결과를 받은 리스트를 리턴
		 * @fd_id 0001
		 --------------------------------------------------*/
		if ( resultList.size() > 0 ) {
			return resultList;
		}
		// 아니면 null값을 리턴
		return null;
	}
	/**
	 * 수정, 생성 시 참조 무결성 위반 여부를 판단한다
	 * @name_ko 참조 무결성 확인 메서드
	 */
	private void checkIntegrityConstraint( TbcMdMfgPartDVO inputDvo ) throws Exception{
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 정보는 테이블 TBC_MD_MFG_GRP의 FCT_CODE에 기 등록 되어있어야 한다 
		 * @fd_id 0001
		 --------------------------------------------------*/
		//TODO
		TbcMdMfgGrpDVO tbcMdMfgGrpDVO = new TbcMdMfgGrpDVO();
		BaseUtil.populate( inputDvo, tbcMdMfgGrpDVO, "fctCode:fctCode" );
		BaseUtil.checkFound( tbcMdMfgGrpDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 정보는 테이블 TBC_MD_MFG_TEAM의 MFG_TEAM_CODE에 기 등록 되어있어야 한다
		 * @fd_id 0002
		 --------------------------------------------------*/
		//TODO
		TbcMdMfgTeamDVO tbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
		BaseUtil.populate( inputDvo, tbcMdMfgTeamDVO, "mfgTeamCode:mfgTeamCode" );
		BaseUtil.checkFound( tbcMdMfgTeamDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0002
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 정보는 테이블 TBC_MD_MFG_GRP의 MFG_GRP_CODE에 기 등록 되어있어야 한다
		 * @fd_id 0003
		 --------------------------------------------------*/
		//TODO
		TbcMdMfgGrpDVO tbcMdMfgGrpDVO2 = new TbcMdMfgGrpDVO();
		BaseUtil.populate( inputDvo, tbcMdMfgGrpDVO2, "mfgGrpCode:mfgGrpCode" );
		BaseUtil.checkFound( tbcMdMfgGrpDVO2 );
		/*--------------------------------------------------
		 * @fd_do_end 0003
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 정보는 테이블 TBC_MD_PROC_GUBUN의 PROC_GUBUN_CODE에 기 등록 되어있어야 한다
		 * @fd_id 0004
		 --------------------------------------------------*/
		//TODO
		TbcMdProcGubunDVO tbcMdProcGubunDVO = new TbcMdProcGubunDVO();
		BaseUtil.populate( inputDvo, tbcMdProcGubunDVO, "procGubunCode:procGubunCode" );
		BaseUtil.checkFound( tbcMdProcGubunDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0004
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_do_start 등록(수정)하려는 정보는 테이블 TBC_MD_PROC_TYPE의 PROC_TYPE_CODE에 기 등록 되어있어야 한다
		 * @fd_id 0005
		 --------------------------------------------------*/
		//TODO
		TbcMdProcTypeDVO tbcMdProcTypeDVO = new TbcMdProcTypeDVO();
		BaseUtil.populate( inputDvo, tbcMdProcTypeDVO, "procTypeCode:procTypeCode" );
		BaseUtil.checkFound( tbcMdProcTypeDVO );
		/*--------------------------------------------------
		 * @fd_do_end 0005
		 --------------------------------------------------*/

		
		
	}
}
