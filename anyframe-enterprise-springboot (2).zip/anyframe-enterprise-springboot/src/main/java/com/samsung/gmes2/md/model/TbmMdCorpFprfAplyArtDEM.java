package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdCorpFprfAplyArtDEM extends AbstractDAO {


/**
* insertTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return int
*/
	@LocalName("insertTbmMdCorpFprfAplyArt")
	public int insertTbmMdCorpFprfAplyArt (final TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.insertTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append(" TBM_MD_CORP_FPRF_APLY_ART (   \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FPRF_APLY_ART_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdCorpFprfAplyArt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdCorpFprfAplyArt Method")
	public int[][] updateBatchAllTbmMdCorpFprfAplyArt (final List  tbmMdCorpFprfAplyArtDVOList) {
		
		ArrayList updatetbmMdCorpFprfAplyArtDVOList = new ArrayList();
		ArrayList insertttbmMdCorpFprfAplyArtDVOList = new ArrayList();
		ArrayList deletetbmMdCorpFprfAplyArtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdCorpFprfAplyArtDVOList.size() ; i++) {
		  TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO = (TbmMdCorpFprfAplyArtDVO) tbmMdCorpFprfAplyArtDVOList.get(i);
		  
		  if (tbmMdCorpFprfAplyArtDVO.getSqlAction().equals("C"))
		      insertttbmMdCorpFprfAplyArtDVOList.add(tbmMdCorpFprfAplyArtDVO);
		  else if (tbmMdCorpFprfAplyArtDVO.getSqlAction().equals("U"))
		      updatetbmMdCorpFprfAplyArtDVOList.add(tbmMdCorpFprfAplyArtDVO);
		  else if (tbmMdCorpFprfAplyArtDVO.getSqlAction().equals("D"))
		      deletetbmMdCorpFprfAplyArtDVOList.add(tbmMdCorpFprfAplyArtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdCorpFprfAplyArtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdCorpFprfAplyArt(insertttbmMdCorpFprfAplyArtDVOList);
          
      if (updatetbmMdCorpFprfAplyArtDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdCorpFprfAplyArt(updatetbmMdCorpFprfAplyArtDVOList);
      
      if (deletetbmMdCorpFprfAplyArtDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdCorpFprfAplyArt(deletetbmMdCorpFprfAplyArtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return int
*/
	@LocalName("updateTbmMdCorpFprfAplyArt")
	public int updateTbmMdCorpFprfAplyArt (final TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.updateTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append(" TBM_MD_CORP_FPRF_APLY_ART \n");
			sql.append(" SET   \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE CORP_CODE = ? \n");
			sql.append("   AND FPRF_APLY_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
						}
					}
		);			
	}

/**
* deleteTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return int
*/
	@LocalName("deleteTbmMdCorpFprfAplyArt")
	public int deleteTbmMdCorpFprfAplyArt (final TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.deleteTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append(" TBM_MD_CORP_FPRF_APLY_ART \n");
			sql.append("  WHERE CORP_CODE = ? \n");
			sql.append("    AND FPRF_APLY_ART_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
						}
					}
		);			
	}

/**
* selectTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return TbmMdCorpFprfAplyArtDVO 
*/
	@LocalName("selectTbmMdCorpFprfAplyArt")
	public TbmMdCorpFprfAplyArtDVO selectTbmMdCorpFprfAplyArt (final TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.selectTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FPRF_APLY_ART_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_CORP_FPRF_APLY_ART \n");
			sql.append("  WHERE CORP_CODE = ? \n");
			sql.append("    AND FPRF_APLY_ART_CODE = ? \n");

		return (TbmMdCorpFprfAplyArtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdCorpFprfAplyArtDVO returnTbmMdCorpFprfAplyArtDVO = new TbmMdCorpFprfAplyArtDVO();
									returnTbmMdCorpFprfAplyArtDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMdCorpFprfAplyArtDVO.setFprfAplyArtCode(resultSet.getString("FPRF_APLY_ART_CODE"));
									returnTbmMdCorpFprfAplyArtDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdCorpFprfAplyArtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdCorpFprfAplyArtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdCorpFprfAplyArtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdCorpFprfAplyArtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdCorpFprfAplyArtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdCorpFprfAplyArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdCorpFprfAplyArt Method")
	public int mergeTbmMdCorpFprfAplyArt (final TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO) {
		
		if ( selectTbmMdCorpFprfAplyArt (tbmMdCorpFprfAplyArtDVO) == null) {
			return insertTbmMdCorpFprfAplyArt(tbmMdCorpFprfAplyArtDVO);
		} else {
			return selectUpdateTbmMdCorpFprfAplyArt (tbmMdCorpFprfAplyArtDVO);
		}
	}

	/**
	 * selectUpdateTbmMdCorpFprfAplyArt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdCorpFprfAplyArt Method")
	public int selectUpdateTbmMdCorpFprfAplyArt (final TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO) {
		
		TbmMdCorpFprfAplyArtDVO tmpTbmMdCorpFprfAplyArtDVO =  selectTbmMdCorpFprfAplyArt (tbmMdCorpFprfAplyArtDVO);
		if ( tbmMdCorpFprfAplyArtDVO.getCorpCode() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getCorpCode()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setCorpCode(tbmMdCorpFprfAplyArtDVO.getCorpCode());
		}		
		if ( tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setFprfAplyArtCode(tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
		}		
		if ( tbmMdCorpFprfAplyArtDVO.getUseYn() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getUseYn()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setUseYn(tbmMdCorpFprfAplyArtDVO.getUseYn());
		}		
		if ( tbmMdCorpFprfAplyArtDVO.getFstRegDt() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getFstRegDt()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setFstRegDt(tbmMdCorpFprfAplyArtDVO.getFstRegDt());
		}		
		if ( tbmMdCorpFprfAplyArtDVO.getFstRegerId() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getFstRegerId()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setFstRegerId(tbmMdCorpFprfAplyArtDVO.getFstRegerId());
		}		
		if ( tbmMdCorpFprfAplyArtDVO.getFnlUpdDt() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getFnlUpdDt()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setFnlUpdDt(tbmMdCorpFprfAplyArtDVO.getFnlUpdDt());
		}		
		if ( tbmMdCorpFprfAplyArtDVO.getFnlUpderId() != null && !"".equals(tbmMdCorpFprfAplyArtDVO.getFnlUpderId()) ) {
			tmpTbmMdCorpFprfAplyArtDVO.setFnlUpderId(tbmMdCorpFprfAplyArtDVO.getFnlUpderId());
		}		
		return updateTbmMdCorpFprfAplyArt (tmpTbmMdCorpFprfAplyArtDVO);
	}

/**
* insertBatchTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return int[]
*/
	@LocalName("insertBatchTbmMdCorpFprfAplyArt")
	public int[] insertBatchTbmMdCorpFprfAplyArt (final List tbmMdCorpFprfAplyArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.insertBatchTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append(" TBM_MD_CORP_FPRF_APLY_ART (   \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        FPRF_APLY_ART_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO = (TbmMdCorpFprfAplyArtDVO)tbmMdCorpFprfAplyArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdCorpFprfAplyArtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return int[]
*/
	@LocalName("updateBatchTbmMdCorpFprfAplyArt")
	public int[] updateBatchTbmMdCorpFprfAplyArt (final List tbmMdCorpFprfAplyArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.updateBatchTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append(" TBM_MD_CORP_FPRF_APLY_ART \n");
			sql.append(" SET   \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE CORP_CODE = ? \n");
			sql.append("   AND FPRF_APLY_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO = (TbmMdCorpFprfAplyArtDVO)tbmMdCorpFprfAplyArtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getUseYn());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
						}
							public int getBatchSize() {
									return tbmMdCorpFprfAplyArtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdCorpFprfAplyArt Method
* 
* @ref_table TBM_MD_CORP_FPRF_APLY_ART
* @return int[]
*/
	@LocalName("deleteBatchTbmMdCorpFprfAplyArt")
	public int[] deleteBatchTbmMdCorpFprfAplyArt (final List tbmMdCorpFprfAplyArtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdCorpFprfAplyArtDEM.deleteBatchTbmMdCorpFprfAplyArt.001*/  \n");
			sql.append(" TBM_MD_CORP_FPRF_APLY_ART \n");
			sql.append("  WHERE CORP_CODE = ? \n");
			sql.append("    AND FPRF_APLY_ART_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdCorpFprfAplyArtDVO tbmMdCorpFprfAplyArtDVO = (TbmMdCorpFprfAplyArtDVO)tbmMdCorpFprfAplyArtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getCorpCode());
							ps.setString(psCount++, tbmMdCorpFprfAplyArtDVO.getFprfAplyArtCode());
						}
							public int getBatchSize() {
									return tbmMdCorpFprfAplyArtDVOList.size();
							}
					}
		);			
	}

	
}