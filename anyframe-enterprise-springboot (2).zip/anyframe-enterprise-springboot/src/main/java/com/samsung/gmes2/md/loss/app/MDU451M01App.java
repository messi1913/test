package com.samsung.gmes2.md.loss.app;

public class MDU451M01App {

	/**
	 * 설비분류코드 목록 초기설정
	 */
	public void initEquipClsfCode(){}

	/**
	 * 설비분류코드 목록 조회
	 */
	public void listEquipClsfCode(){}

	/**
	 * 설비분류코드 목록 엑셀 다운로드
	 */
	public void excelEquipClsfCode(){}

	/**
	 * 설비분류코드 목록 저장
	 */
	public void saveEquipClsfCode(){}

}
