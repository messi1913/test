package com.samsung.gmes2.bi.biu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author kwjfresh
 */
@LocalName("수율현황 상세조회")
public class BiU456M0001DVO extends AbstractVo {

	@LocalName("sector") @Length(10) 
	private String sector;

	@LocalName("gbm") @Length(10) 
	private String gbm;

	@LocalName("product") @Length(10) 
	private String product;

	@LocalName("plant") @Length(10) 
	private String plant;

	@LocalName("componentnm") @Length(10) 
	private String componentnm;

	@LocalName("날짜1") @Length(17) 
	private BigDecimal date01;

	@LocalName("날짜2") @Length(17) 
	private BigDecimal date02;

	@LocalName("날짜3") @Length(17) 
	private BigDecimal date03;

	@LocalName("날짜4") @Length(17) 
	private BigDecimal date04;

	@LocalName("날짜5") @Length(17) 
	private BigDecimal date05;

	@LocalName("날짜6") @Length(17) 
	private BigDecimal date06;

	@LocalName("날짜7") @Length(17) 
	private BigDecimal date07;

	@LocalName("합계") @Length(17) 
	private BigDecimal total;


	/**
	 * sector Getter Method
	 * 
	 * @return sector
	 */
	@LocalName("sector Getter Method")
	public String getSector() {
		this.sector = super.getValue(0);
		return this.sector;
	}

	/**
	 * sector Setter Method
	 * 
	 * @param String sector
	 */
	@LocalName("sector Setter Method")
	public void setSector(String sector) {
        super.setValue(0, sector);
		this.sector = sector;
	}
	
	/**
	 * gbm Getter Method
	 * 
	 * @return gbm
	 */
	@LocalName("gbm Getter Method")
	public String getGbm() {
		this.gbm = super.getValue(1);
		return this.gbm;
	}

	/**
	 * gbm Setter Method
	 * 
	 * @param String gbm
	 */
	@LocalName("gbm Setter Method")
	public void setGbm(String gbm) {
        super.setValue(1, gbm);
		this.gbm = gbm;
	}
	
	/**
	 * product Getter Method
	 * 
	 * @return product
	 */
	@LocalName("product Getter Method")
	public String getProduct() {
		this.product = super.getValue(2);
		return this.product;
	}

	/**
	 * product Setter Method
	 * 
	 * @param String product
	 */
	@LocalName("product Setter Method")
	public void setProduct(String product) {
        super.setValue(2, product);
		this.product = product;
	}
	
	/**
	 * plant Getter Method
	 * 
	 * @return plant
	 */
	@LocalName("plant Getter Method")
	public String getPlant() {
		this.plant = super.getValue(3);
		return this.plant;
	}

	/**
	 * plant Setter Method
	 * 
	 * @param String plant
	 */
	@LocalName("plant Setter Method")
	public void setPlant(String plant) {
        super.setValue(3, plant);
		this.plant = plant;
	}
	
	/**
	 * componentnm Getter Method
	 * 
	 * @return componentnm
	 */
	@LocalName("componentnm Getter Method")
	public String getComponentnm() {
		this.componentnm = super.getValue(4);
		return this.componentnm;
	}

	/**
	 * componentnm Setter Method
	 * 
	 * @param String componentnm
	 */
	@LocalName("componentnm Setter Method")
	public void setComponentnm(String componentnm) {
        super.setValue(4, componentnm);
		this.componentnm = componentnm;
	}
	
	/**
	 * 날짜1 Getter Method
	 * 
	 * @return 날짜1
	 */
	@LocalName("날짜1 Getter Method")
	public BigDecimal getDate01() {
		this.date01 = super.getValue(5);
		return this.date01;
	}

	/**
	 * 날짜1 Setter Method
	 * 
	 * @param BigDecimal 날짜1
	 */
	@LocalName("날짜1 Setter Method")
	public void setDate01(BigDecimal date01) {
        super.setValue(5, date01);
		this.date01 = date01;
	}
	
	/**
	 * 날짜2 Getter Method
	 * 
	 * @return 날짜2
	 */
	@LocalName("날짜2 Getter Method")
	public BigDecimal getDate02() {
		this.date02 = super.getValue(6);
		return this.date02;
	}

	/**
	 * 날짜2 Setter Method
	 * 
	 * @param BigDecimal 날짜2
	 */
	@LocalName("날짜2 Setter Method")
	public void setDate02(BigDecimal date02) {
        super.setValue(6, date02);
		this.date02 = date02;
	}
	
	/**
	 * 날짜3 Getter Method
	 * 
	 * @return 날짜3
	 */
	@LocalName("날짜3 Getter Method")
	public BigDecimal getDate03() {
		this.date03 = super.getValue(7);
		return this.date03;
	}

	/**
	 * 날짜3 Setter Method
	 * 
	 * @param BigDecimal 날짜3
	 */
	@LocalName("날짜3 Setter Method")
	public void setDate03(BigDecimal date03) {
        super.setValue(7, date03);
		this.date03 = date03;
	}
	
	/**
	 * 날짜4 Getter Method
	 * 
	 * @return 날짜4
	 */
	@LocalName("날짜4 Getter Method")
	public BigDecimal getDate04() {
		this.date04 = super.getValue(8);
		return this.date04;
	}

	/**
	 * 날짜4 Setter Method
	 * 
	 * @param BigDecimal 날짜4
	 */
	@LocalName("날짜4 Setter Method")
	public void setDate04(BigDecimal date04) {
        super.setValue(8, date04);
		this.date04 = date04;
	}
	
	/**
	 * 날짜5 Getter Method
	 * 
	 * @return 날짜5
	 */
	@LocalName("날짜5 Getter Method")
	public BigDecimal getDate05() {
		this.date05 = super.getValue(9);
		return this.date05;
	}

	/**
	 * 날짜5 Setter Method
	 * 
	 * @param BigDecimal 날짜5
	 */
	@LocalName("날짜5 Setter Method")
	public void setDate05(BigDecimal date05) {
        super.setValue(9, date05);
		this.date05 = date05;
	}
	
	/**
	 * 날짜6 Getter Method
	 * 
	 * @return 날짜6
	 */
	@LocalName("날짜6 Getter Method")
	public BigDecimal getDate06() {
		this.date06 = super.getValue(10);
		return this.date06;
	}

	/**
	 * 날짜6 Setter Method
	 * 
	 * @param BigDecimal 날짜6
	 */
	@LocalName("날짜6 Setter Method")
	public void setDate06(BigDecimal date06) {
        super.setValue(10, date06);
		this.date06 = date06;
	}
	
	/**
	 * 날짜7 Getter Method
	 * 
	 * @return 날짜7
	 */
	@LocalName("날짜7 Getter Method")
	public BigDecimal getDate07() {
		this.date07 = super.getValue(11);
		return this.date07;
	}

	/**
	 * 날짜7 Setter Method
	 * 
	 * @param BigDecimal 날짜7
	 */
	@LocalName("날짜7 Setter Method")
	public void setDate07(BigDecimal date07) {
        super.setValue(11, date07);
		this.date07 = date07;
	}
	
	/**
	 * 합계 Getter Method
	 * 
	 * @return 합계
	 */
	@LocalName("합계 Getter Method")
	public BigDecimal getTotal() {
		this.total = super.getValue(12);
		return this.total;
	}

	/**
	 * 합계 Setter Method
	 * 
	 * @param BigDecimal 합계
	 */
	@LocalName("합계 Setter Method")
	public void setTotal(BigDecimal total) {
        super.setValue(12, total);
		this.total = total;
	}
	
}