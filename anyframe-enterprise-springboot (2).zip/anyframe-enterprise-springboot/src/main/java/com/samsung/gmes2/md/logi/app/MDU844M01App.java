package com.samsung.gmes2.md.logi.app;

public class MDU844M01App {

	/**
	 * Buyer 목록 초기설정
	 */
	public void initBuyerInfo(){}

	/**
	 * Buyer 목록 조회
	 */
	public void listBuyerInfo(){}

	/**
	 * Buyer 목록 엑셀 다운로드
	 */
	public void excelBuyerInfo(){}

	/**
	 * Buyer 목록 저장
	 */
	public void saveBuyerInfo(){}

}
