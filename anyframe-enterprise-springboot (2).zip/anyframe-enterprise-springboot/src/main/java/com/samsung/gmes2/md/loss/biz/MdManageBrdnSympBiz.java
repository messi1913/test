package com.samsung.gmes2.md.loss.biz;

public class MdManageBrdnSympBiz {

	/**
	 * 고장증상코드 목록 조회
	 */
	public void listBrdnSympCode(){}

	/**
	 * 고장증상코드 목록 저장
	 */
	public void saveBrdnSympCode(){}

}
