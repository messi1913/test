package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_IP_OI
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcIpOiDEM extends AbstractDAO {


/**
* insertTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return int
*/
	@LocalName("insertTbmMcIpOi")
	public int insertTbmMcIpOi (final TbmMcIpOiDVO tbmMcIpOiDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.insertTbmMcIpOi.001*/  \n");
			sql.append(" TBM_MC_IP_OI (   \n");
			sql.append("        IP , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        DFLT_YN , \n");
			sql.append("        IP_OI_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
							ps.setString(psCount++, tbmMcIpOiDVO.getDfltYn());
							ps.setString(psCount++, tbmMcIpOiDVO.getIpOiDesc());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcIpOi Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcIpOi Method")
	public int[][] updateBatchAllTbmMcIpOi (final List  tbmMcIpOiDVOList) {
		
		ArrayList updatetbmMcIpOiDVOList = new ArrayList();
		ArrayList insertttbmMcIpOiDVOList = new ArrayList();
		ArrayList deletetbmMcIpOiDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcIpOiDVOList.size() ; i++) {
		  TbmMcIpOiDVO tbmMcIpOiDVO = (TbmMcIpOiDVO) tbmMcIpOiDVOList.get(i);
		  
		  if (tbmMcIpOiDVO.getSqlAction().equals("C"))
		      insertttbmMcIpOiDVOList.add(tbmMcIpOiDVO);
		  else if (tbmMcIpOiDVO.getSqlAction().equals("U"))
		      updatetbmMcIpOiDVOList.add(tbmMcIpOiDVO);
		  else if (tbmMcIpOiDVO.getSqlAction().equals("D"))
		      deletetbmMcIpOiDVOList.add(tbmMcIpOiDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcIpOiDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcIpOi(insertttbmMcIpOiDVOList);
          
      if (updatetbmMcIpOiDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcIpOi(updatetbmMcIpOiDVOList);
      
      if (deletetbmMcIpOiDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcIpOi(deletetbmMcIpOiDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return int
*/
	@LocalName("updateTbmMcIpOi")
	public int updateTbmMcIpOi (final TbmMcIpOiDVO tbmMcIpOiDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.updateTbmMcIpOi.001*/  \n");
			sql.append(" TBM_MC_IP_OI \n");
			sql.append(" SET   \n");
			sql.append("        DFLT_YN = ? , \n");
			sql.append("        IP_OI_DESC = ? \n");
			sql.append(" WHERE IP = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpOiDVO.getDfltYn());
							ps.setString(psCount++, tbmMcIpOiDVO.getIpOiDesc());

							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
						}
					}
		);			
	}

/**
* deleteTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return int
*/
	@LocalName("deleteTbmMcIpOi")
	public int deleteTbmMcIpOi (final TbmMcIpOiDVO tbmMcIpOiDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.deleteTbmMcIpOi.001*/  \n");
			sql.append(" TBM_MC_IP_OI \n");
			sql.append("  WHERE IP = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
						}
					}
		);			
	}

/**
* selectTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return TbmMcIpOiDVO 
*/
	@LocalName("selectTbmMcIpOi")
	public TbmMcIpOiDVO selectTbmMcIpOi (final TbmMcIpOiDVO tbmMcIpOiDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.selectTbmMcIpOi.001*/  \n");
			sql.append("        IP , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        DFLT_YN , \n");
			sql.append("        IP_OI_DESC \n");
			sql.append("   FROM TBM_MC_IP_OI \n");
			sql.append("  WHERE IP = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return (TbmMcIpOiDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcIpOiDVO returnTbmMcIpOiDVO = new TbmMcIpOiDVO();
									returnTbmMcIpOiDVO.setIp(resultSet.getString("IP"));
									returnTbmMcIpOiDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbmMcIpOiDVO.setDfltYn(resultSet.getString("DFLT_YN"));
									returnTbmMcIpOiDVO.setIpOiDesc(resultSet.getString("IP_OI_DESC"));
									return returnTbmMcIpOiDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcIpOi Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcIpOi Method")
	public int mergeTbmMcIpOi (final TbmMcIpOiDVO tbmMcIpOiDVO) {
		
		if ( selectTbmMcIpOi (tbmMcIpOiDVO) == null) {
			return insertTbmMcIpOi(tbmMcIpOiDVO);
		} else {
			return selectUpdateTbmMcIpOi (tbmMcIpOiDVO);
		}
	}

	/**
	 * selectUpdateTbmMcIpOi Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcIpOi Method")
	public int selectUpdateTbmMcIpOi (final TbmMcIpOiDVO tbmMcIpOiDVO) {
		
		TbmMcIpOiDVO tmpTbmMcIpOiDVO =  selectTbmMcIpOi (tbmMcIpOiDVO);
		if ( tbmMcIpOiDVO.getIp() != null && !"".equals(tbmMcIpOiDVO.getIp()) ) {
			tmpTbmMcIpOiDVO.setIp(tbmMcIpOiDVO.getIp());
		}		
		if ( tbmMcIpOiDVO.getPgmCode() != null && !"".equals(tbmMcIpOiDVO.getPgmCode()) ) {
			tmpTbmMcIpOiDVO.setPgmCode(tbmMcIpOiDVO.getPgmCode());
		}		
		if ( tbmMcIpOiDVO.getDfltYn() != null && !"".equals(tbmMcIpOiDVO.getDfltYn()) ) {
			tmpTbmMcIpOiDVO.setDfltYn(tbmMcIpOiDVO.getDfltYn());
		}		
		if ( tbmMcIpOiDVO.getIpOiDesc() != null && !"".equals(tbmMcIpOiDVO.getIpOiDesc()) ) {
			tmpTbmMcIpOiDVO.setIpOiDesc(tbmMcIpOiDVO.getIpOiDesc());
		}		
		return updateTbmMcIpOi (tmpTbmMcIpOiDVO);
	}

/**
* insertBatchTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return int[]
*/
	@LocalName("insertBatchTbmMcIpOi")
	public int[] insertBatchTbmMcIpOi (final List tbmMcIpOiDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.insertBatchTbmMcIpOi.001*/  \n");
			sql.append(" TBM_MC_IP_OI (   \n");
			sql.append("        IP , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        DFLT_YN , \n");
			sql.append("        IP_OI_DESC \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcIpOiDVO tbmMcIpOiDVO = (TbmMcIpOiDVO)tbmMcIpOiDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
							ps.setString(psCount++, tbmMcIpOiDVO.getDfltYn());
							ps.setString(psCount++, tbmMcIpOiDVO.getIpOiDesc());

						}
							public int getBatchSize() {
									return tbmMcIpOiDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return int[]
*/
	@LocalName("updateBatchTbmMcIpOi")
	public int[] updateBatchTbmMcIpOi (final List tbmMcIpOiDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.updateBatchTbmMcIpOi.001*/  \n");
			sql.append(" TBM_MC_IP_OI \n");
			sql.append(" SET   \n");
			sql.append("        DFLT_YN = ? , \n");
			sql.append("        IP_OI_DESC = ? \n");
			sql.append(" WHERE IP = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcIpOiDVO tbmMcIpOiDVO = (TbmMcIpOiDVO)tbmMcIpOiDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcIpOiDVO.getDfltYn());
							ps.setString(psCount++, tbmMcIpOiDVO.getIpOiDesc());

							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbmMcIpOiDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcIpOi Method
* 
* @ref_table TBM_MC_IP_OI
* @return int[]
*/
	@LocalName("deleteBatchTbmMcIpOi")
	public int[] deleteBatchTbmMcIpOi (final List tbmMcIpOiDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcIpOiDEM.deleteBatchTbmMcIpOi.001*/  \n");
			sql.append(" TBM_MC_IP_OI \n");
			sql.append("  WHERE IP = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcIpOiDVO tbmMcIpOiDVO = (TbmMcIpOiDVO)tbmMcIpOiDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcIpOiDVO.getIp());
							ps.setString(psCount++, tbmMcIpOiDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbmMcIpOiDVOList.size();
							}
					}
		);			
	}

	
}