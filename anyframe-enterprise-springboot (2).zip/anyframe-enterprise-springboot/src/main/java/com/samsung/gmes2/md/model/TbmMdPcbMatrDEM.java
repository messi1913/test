package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PCB_MATR
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPcbMatrDEM extends AbstractDAO {


/**
* insertTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return int
*/
	@LocalName("insertTbmMdPcbMatr")
	public int insertTbmMdPcbMatr (final TbmMdPcbMatrDVO tbmMdPcbMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.insertTbmMdPcbMatr.001*/  \n");
			sql.append(" TBM_MD_PCB_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        PCB_ARRAY_VALUE , \n");
			sql.append("        N1_PROC_NM , \n");
			sql.append("        N2_PROC_NM , \n");
			sql.append("        N3_PROC_NM , \n");
			sql.append("        PCB_DTL_DESC , \n");
			sql.append("        RCGPNT_NO , \n");
			sql.append("        X_RCGPNT_VALUE , \n");
			sql.append("        Y_RCGPNT_VALUE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getPcbArrayValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN1ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN2ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN3ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getPcbDtlDesc());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getRcgpntNo());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getxRcgpntValue());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getyRcgpntValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPcbMatr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPcbMatr Method")
	public int[][] updateBatchAllTbmMdPcbMatr (final List  tbmMdPcbMatrDVOList) {
		
		ArrayList updatetbmMdPcbMatrDVOList = new ArrayList();
		ArrayList insertttbmMdPcbMatrDVOList = new ArrayList();
		ArrayList deletetbmMdPcbMatrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPcbMatrDVOList.size() ; i++) {
		  TbmMdPcbMatrDVO tbmMdPcbMatrDVO = (TbmMdPcbMatrDVO) tbmMdPcbMatrDVOList.get(i);
		  
		  if (tbmMdPcbMatrDVO.getSqlAction().equals("C"))
		      insertttbmMdPcbMatrDVOList.add(tbmMdPcbMatrDVO);
		  else if (tbmMdPcbMatrDVO.getSqlAction().equals("U"))
		      updatetbmMdPcbMatrDVOList.add(tbmMdPcbMatrDVO);
		  else if (tbmMdPcbMatrDVO.getSqlAction().equals("D"))
		      deletetbmMdPcbMatrDVOList.add(tbmMdPcbMatrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPcbMatrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPcbMatr(insertttbmMdPcbMatrDVOList);
          
      if (updatetbmMdPcbMatrDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPcbMatr(updatetbmMdPcbMatrDVOList);
      
      if (deletetbmMdPcbMatrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPcbMatr(deletetbmMdPcbMatrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return int
*/
	@LocalName("updateTbmMdPcbMatr")
	public int updateTbmMdPcbMatr (final TbmMdPcbMatrDVO tbmMdPcbMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.updateTbmMdPcbMatr.001*/  \n");
			sql.append(" TBM_MD_PCB_MATR \n");
			sql.append(" SET   \n");
			sql.append("        PCB_ARRAY_VALUE = ? , \n");
			sql.append("        N1_PROC_NM = ? , \n");
			sql.append("        N2_PROC_NM = ? , \n");
			sql.append("        N3_PROC_NM = ? , \n");
			sql.append("        PCB_DTL_DESC = ? , \n");
			sql.append("        RCGPNT_NO = ? , \n");
			sql.append("        X_RCGPNT_VALUE = ? , \n");
			sql.append("        Y_RCGPNT_VALUE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getPcbArrayValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN1ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN2ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN3ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getPcbDtlDesc());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getRcgpntNo());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getxRcgpntValue());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getyRcgpntValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* deleteTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return int
*/
	@LocalName("deleteTbmMdPcbMatr")
	public int deleteTbmMdPcbMatr (final TbmMdPcbMatrDVO tbmMdPcbMatrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.deleteTbmMdPcbMatr.001*/  \n");
			sql.append(" TBM_MD_PCB_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
						}
					}
		);			
	}

/**
* selectTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return TbmMdPcbMatrDVO 
*/
	@LocalName("selectTbmMdPcbMatr")
	public TbmMdPcbMatrDVO selectTbmMdPcbMatr (final TbmMdPcbMatrDVO tbmMdPcbMatrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.selectTbmMdPcbMatr.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        PCB_ARRAY_VALUE , \n");
			sql.append("        N1_PROC_NM , \n");
			sql.append("        N2_PROC_NM , \n");
			sql.append("        N3_PROC_NM , \n");
			sql.append("        PCB_DTL_DESC , \n");
			sql.append("        RCGPNT_NO , \n");
			sql.append("        X_RCGPNT_VALUE , \n");
			sql.append("        Y_RCGPNT_VALUE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PCB_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return (TbmMdPcbMatrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPcbMatrDVO returnTbmMdPcbMatrDVO = new TbmMdPcbMatrDVO();
									returnTbmMdPcbMatrDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPcbMatrDVO.setMatrCode(resultSet.getString("MATR_CODE"));
									returnTbmMdPcbMatrDVO.setPcbArrayValue(resultSet.getBigDecimal("PCB_ARRAY_VALUE"));
									returnTbmMdPcbMatrDVO.setN1ProcNm(resultSet.getString("N1_PROC_NM"));
									returnTbmMdPcbMatrDVO.setN2ProcNm(resultSet.getString("N2_PROC_NM"));
									returnTbmMdPcbMatrDVO.setN3ProcNm(resultSet.getString("N3_PROC_NM"));
									returnTbmMdPcbMatrDVO.setPcbDtlDesc(resultSet.getString("PCB_DTL_DESC"));
									returnTbmMdPcbMatrDVO.setRcgpntNo(resultSet.getString("RCGPNT_NO"));
									returnTbmMdPcbMatrDVO.setxRcgpntValue(resultSet.getBigDecimal("X_RCGPNT_VALUE"));
									returnTbmMdPcbMatrDVO.setyRcgpntValue(resultSet.getBigDecimal("Y_RCGPNT_VALUE"));
									returnTbmMdPcbMatrDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdPcbMatrDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPcbMatrDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPcbMatrDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPcbMatrDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPcbMatrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPcbMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPcbMatr Method")
	public int mergeTbmMdPcbMatr (final TbmMdPcbMatrDVO tbmMdPcbMatrDVO) {
		
		if ( selectTbmMdPcbMatr (tbmMdPcbMatrDVO) == null) {
			return insertTbmMdPcbMatr(tbmMdPcbMatrDVO);
		} else {
			return selectUpdateTbmMdPcbMatr (tbmMdPcbMatrDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPcbMatr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPcbMatr Method")
	public int selectUpdateTbmMdPcbMatr (final TbmMdPcbMatrDVO tbmMdPcbMatrDVO) {
		
		TbmMdPcbMatrDVO tmpTbmMdPcbMatrDVO =  selectTbmMdPcbMatr (tbmMdPcbMatrDVO);
		if ( tbmMdPcbMatrDVO.getPlantCode() != null && !"".equals(tbmMdPcbMatrDVO.getPlantCode()) ) {
			tmpTbmMdPcbMatrDVO.setPlantCode(tbmMdPcbMatrDVO.getPlantCode());
		}		
		if ( tbmMdPcbMatrDVO.getMatrCode() != null && !"".equals(tbmMdPcbMatrDVO.getMatrCode()) ) {
			tmpTbmMdPcbMatrDVO.setMatrCode(tbmMdPcbMatrDVO.getMatrCode());
		}		
		if ( tbmMdPcbMatrDVO.getPcbArrayValue() != null && !"".equals(tbmMdPcbMatrDVO.getPcbArrayValue()) ) {
			tmpTbmMdPcbMatrDVO.setPcbArrayValue(tbmMdPcbMatrDVO.getPcbArrayValue());
		}		
		if ( tbmMdPcbMatrDVO.getN1ProcNm() != null && !"".equals(tbmMdPcbMatrDVO.getN1ProcNm()) ) {
			tmpTbmMdPcbMatrDVO.setN1ProcNm(tbmMdPcbMatrDVO.getN1ProcNm());
		}		
		if ( tbmMdPcbMatrDVO.getN2ProcNm() != null && !"".equals(tbmMdPcbMatrDVO.getN2ProcNm()) ) {
			tmpTbmMdPcbMatrDVO.setN2ProcNm(tbmMdPcbMatrDVO.getN2ProcNm());
		}		
		if ( tbmMdPcbMatrDVO.getN3ProcNm() != null && !"".equals(tbmMdPcbMatrDVO.getN3ProcNm()) ) {
			tmpTbmMdPcbMatrDVO.setN3ProcNm(tbmMdPcbMatrDVO.getN3ProcNm());
		}		
		if ( tbmMdPcbMatrDVO.getPcbDtlDesc() != null && !"".equals(tbmMdPcbMatrDVO.getPcbDtlDesc()) ) {
			tmpTbmMdPcbMatrDVO.setPcbDtlDesc(tbmMdPcbMatrDVO.getPcbDtlDesc());
		}		
		if ( tbmMdPcbMatrDVO.getRcgpntNo() != null && !"".equals(tbmMdPcbMatrDVO.getRcgpntNo()) ) {
			tmpTbmMdPcbMatrDVO.setRcgpntNo(tbmMdPcbMatrDVO.getRcgpntNo());
		}		
		if ( tbmMdPcbMatrDVO.getxRcgpntValue() != null && !"".equals(tbmMdPcbMatrDVO.getxRcgpntValue()) ) {
			tmpTbmMdPcbMatrDVO.setxRcgpntValue(tbmMdPcbMatrDVO.getxRcgpntValue());
		}		
		if ( tbmMdPcbMatrDVO.getyRcgpntValue() != null && !"".equals(tbmMdPcbMatrDVO.getyRcgpntValue()) ) {
			tmpTbmMdPcbMatrDVO.setyRcgpntValue(tbmMdPcbMatrDVO.getyRcgpntValue());
		}		
		if ( tbmMdPcbMatrDVO.getUseYn() != null && !"".equals(tbmMdPcbMatrDVO.getUseYn()) ) {
			tmpTbmMdPcbMatrDVO.setUseYn(tbmMdPcbMatrDVO.getUseYn());
		}		
		if ( tbmMdPcbMatrDVO.getFstRegDt() != null && !"".equals(tbmMdPcbMatrDVO.getFstRegDt()) ) {
			tmpTbmMdPcbMatrDVO.setFstRegDt(tbmMdPcbMatrDVO.getFstRegDt());
		}		
		if ( tbmMdPcbMatrDVO.getFstRegerId() != null && !"".equals(tbmMdPcbMatrDVO.getFstRegerId()) ) {
			tmpTbmMdPcbMatrDVO.setFstRegerId(tbmMdPcbMatrDVO.getFstRegerId());
		}		
		if ( tbmMdPcbMatrDVO.getFnlUpdDt() != null && !"".equals(tbmMdPcbMatrDVO.getFnlUpdDt()) ) {
			tmpTbmMdPcbMatrDVO.setFnlUpdDt(tbmMdPcbMatrDVO.getFnlUpdDt());
		}		
		if ( tbmMdPcbMatrDVO.getFnlUpderId() != null && !"".equals(tbmMdPcbMatrDVO.getFnlUpderId()) ) {
			tmpTbmMdPcbMatrDVO.setFnlUpderId(tbmMdPcbMatrDVO.getFnlUpderId());
		}		
		return updateTbmMdPcbMatr (tmpTbmMdPcbMatrDVO);
	}

/**
* insertBatchTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return int[]
*/
	@LocalName("insertBatchTbmMdPcbMatr")
	public int[] insertBatchTbmMdPcbMatr (final List tbmMdPcbMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.insertBatchTbmMdPcbMatr.001*/  \n");
			sql.append(" TBM_MD_PCB_MATR (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MATR_CODE , \n");
			sql.append("        PCB_ARRAY_VALUE , \n");
			sql.append("        N1_PROC_NM , \n");
			sql.append("        N2_PROC_NM , \n");
			sql.append("        N3_PROC_NM , \n");
			sql.append("        PCB_DTL_DESC , \n");
			sql.append("        RCGPNT_NO , \n");
			sql.append("        X_RCGPNT_VALUE , \n");
			sql.append("        Y_RCGPNT_VALUE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPcbMatrDVO tbmMdPcbMatrDVO = (TbmMdPcbMatrDVO)tbmMdPcbMatrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getPcbArrayValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN1ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN2ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN3ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getPcbDtlDesc());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getRcgpntNo());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getxRcgpntValue());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getyRcgpntValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPcbMatrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return int[]
*/
	@LocalName("updateBatchTbmMdPcbMatr")
	public int[] updateBatchTbmMdPcbMatr (final List tbmMdPcbMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.updateBatchTbmMdPcbMatr.001*/  \n");
			sql.append(" TBM_MD_PCB_MATR \n");
			sql.append(" SET   \n");
			sql.append("        PCB_ARRAY_VALUE = ? , \n");
			sql.append("        N1_PROC_NM = ? , \n");
			sql.append("        N2_PROC_NM = ? , \n");
			sql.append("        N3_PROC_NM = ? , \n");
			sql.append("        PCB_DTL_DESC = ? , \n");
			sql.append("        RCGPNT_NO = ? , \n");
			sql.append("        X_RCGPNT_VALUE = ? , \n");
			sql.append("        Y_RCGPNT_VALUE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPcbMatrDVO tbmMdPcbMatrDVO = (TbmMdPcbMatrDVO)tbmMdPcbMatrDVOList.get(i);

							int psCount = 1;

							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getPcbArrayValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN1ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN2ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getN3ProcNm());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getPcbDtlDesc());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getRcgpntNo());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getxRcgpntValue());
							ps.setBigDecimal(psCount++, tbmMdPcbMatrDVO.getyRcgpntValue());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getUseYn());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdPcbMatrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPcbMatr Method
* 
* @ref_table TBM_MD_PCB_MATR
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPcbMatr")
	public int[] deleteBatchTbmMdPcbMatr (final List tbmMdPcbMatrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPcbMatrDEM.deleteBatchTbmMdPcbMatr.001*/  \n");
			sql.append(" TBM_MD_PCB_MATR \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MATR_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPcbMatrDVO tbmMdPcbMatrDVO = (TbmMdPcbMatrDVO)tbmMdPcbMatrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPcbMatrDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPcbMatrDVO.getMatrCode());
						}
							public int getBatchSize() {
									return tbmMdPcbMatrDVOList.size();
							}
					}
		);			
	}

	
}