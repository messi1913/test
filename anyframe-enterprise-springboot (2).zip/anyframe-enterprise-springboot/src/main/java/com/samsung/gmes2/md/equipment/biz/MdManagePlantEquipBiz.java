package com.samsung.gmes2.md.equipment.biz;

public class MdManagePlantEquipBiz {

	/**
	 * Plant별 설비코드 목록 조회
	 */
	public void listPlantEquip(){}

	/**
	 * Plant별 설비코드 목록 저장
	 */
	public void savePlantEquip(){}

}
