package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdBaseHmsDVO extends AbstractVo {

	@Length(30) 
	private String fctCode;

	@Length(30) 
	private String lineCode;

	@Length(30) 
	private String mfgPartCode;

	@Length(14) 
	private String aplyStartDt;

	@Length(14) 
	private String aplyFinDt;

	@Length(10) @Scale(3) 
	private BigDecimal montStopAplySsop;

	@Length(10) @Scale(3) 
	private BigDecimal lineStopAplySsop;

	@Length(11) @Scale(5) 
	private BigDecimal atstProdcNum;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue(0);
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue(0, fctCode);
		this.fctCode = fctCode;
	}
	
	public String getLineCode() {
		this.lineCode = super.getValue(1);
		return this.lineCode;
	}

	public void setLineCode(String lineCode) {
        super.setValue(1, lineCode);
		this.lineCode = lineCode;
	}
	
	public String getMfgPartCode() {
		this.mfgPartCode = super.getValue(2);
		return this.mfgPartCode;
	}

	public void setMfgPartCode(String mfgPartCode) {
        super.setValue(2, mfgPartCode);
		this.mfgPartCode = mfgPartCode;
	}
	
	public String getAplyStartDt() {
		this.aplyStartDt = super.getValue(3);
		return this.aplyStartDt;
	}

	public void setAplyStartDt(String aplyStartDt) {
        super.setValue(3, aplyStartDt);
		this.aplyStartDt = aplyStartDt;
	}
	
	public String getAplyFinDt() {
		this.aplyFinDt = super.getValue(4);
		return this.aplyFinDt;
	}

	public void setAplyFinDt(String aplyFinDt) {
        super.setValue(4, aplyFinDt);
		this.aplyFinDt = aplyFinDt;
	}
	
	public BigDecimal getMontStopAplySsop() {
		this.montStopAplySsop = super.getValue(5);
		return this.montStopAplySsop;
	}

	public void setMontStopAplySsop(BigDecimal montStopAplySsop) {
        super.setValue(5, montStopAplySsop);
		this.montStopAplySsop = montStopAplySsop;
	}
	
	public BigDecimal getLineStopAplySsop() {
		this.lineStopAplySsop = super.getValue(6);
		return this.lineStopAplySsop;
	}

	public void setLineStopAplySsop(BigDecimal lineStopAplySsop) {
        super.setValue(6, lineStopAplySsop);
		this.lineStopAplySsop = lineStopAplySsop;
	}
	
	public BigDecimal getAtstProdcNum() {
		this.atstProdcNum = super.getValue(7);
		return this.atstProdcNum;
	}

	public void setAtstProdcNum(BigDecimal atstProdcNum) {
        super.setValue(7, atstProdcNum);
		this.atstProdcNum = atstProdcNum;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(8);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(8, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(9);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(9, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(10);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(10, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(11);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(11, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(12);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(12, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}