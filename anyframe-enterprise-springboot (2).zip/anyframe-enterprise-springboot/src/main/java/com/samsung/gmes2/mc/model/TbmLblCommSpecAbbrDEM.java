package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmLblCommSpecAbbrDEM extends AbstractDAO {


/**
* insertTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return int
*/
	@LocalName("insertTbmLblCommSpecAbbr")
	public int insertTbmLblCommSpecAbbr (final TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.insertTbmLblCommSpecAbbr.001*/  \n");
			sql.append(" TBM_LBL_COMM_SPEC_ABBR (   \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        SPEC_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmLblCommSpecAbbr Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmLblCommSpecAbbr Method")
	public int[][] updateBatchAllTbmLblCommSpecAbbr (final List  tbmLblCommSpecAbbrDVOList) {
		
		ArrayList updatetbmLblCommSpecAbbrDVOList = new ArrayList();
		ArrayList insertttbmLblCommSpecAbbrDVOList = new ArrayList();
		ArrayList deletetbmLblCommSpecAbbrDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmLblCommSpecAbbrDVOList.size() ; i++) {
		  TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO = (TbmLblCommSpecAbbrDVO) tbmLblCommSpecAbbrDVOList.get(i);
		  
		  if (tbmLblCommSpecAbbrDVO.getSqlAction().equals("C"))
		      insertttbmLblCommSpecAbbrDVOList.add(tbmLblCommSpecAbbrDVO);
		  else if (tbmLblCommSpecAbbrDVO.getSqlAction().equals("U"))
		      updatetbmLblCommSpecAbbrDVOList.add(tbmLblCommSpecAbbrDVO);
		  else if (tbmLblCommSpecAbbrDVO.getSqlAction().equals("D"))
		      deletetbmLblCommSpecAbbrDVOList.add(tbmLblCommSpecAbbrDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmLblCommSpecAbbrDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmLblCommSpecAbbr(insertttbmLblCommSpecAbbrDVOList);
          
      if (updatetbmLblCommSpecAbbrDVOList.size() >0)
          resultValues[1] = updateBatchTbmLblCommSpecAbbr(updatetbmLblCommSpecAbbrDVOList);
      
      if (deletetbmLblCommSpecAbbrDVOList.size() >0)
          resultValues[2] = deleteBatchTbmLblCommSpecAbbr(deletetbmLblCommSpecAbbrDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return int
*/
	@LocalName("updateTbmLblCommSpecAbbr")
	public int updateTbmLblCommSpecAbbr (final TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.updateTbmLblCommSpecAbbr.001*/  \n");
			sql.append(" TBM_LBL_COMM_SPEC_ABBR \n");
			sql.append(" SET   \n");
			sql.append("        SPEC_NM = ? \n");
			sql.append(" WHERE SPEC_ABBR_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecNm());

							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
						}
					}
		);			
	}

/**
* deleteTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return int
*/
	@LocalName("deleteTbmLblCommSpecAbbr")
	public int deleteTbmLblCommSpecAbbr (final TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.deleteTbmLblCommSpecAbbr.001*/  \n");
			sql.append(" TBM_LBL_COMM_SPEC_ABBR \n");
			sql.append("  WHERE SPEC_ABBR_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
						}
					}
		);			
	}

/**
* selectTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return TbmLblCommSpecAbbrDVO 
*/
	@LocalName("selectTbmLblCommSpecAbbr")
	public TbmLblCommSpecAbbrDVO selectTbmLblCommSpecAbbr (final TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.selectTbmLblCommSpecAbbr.001*/  \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        SPEC_NM \n");
			sql.append("   FROM TBM_LBL_COMM_SPEC_ABBR \n");
			sql.append("  WHERE SPEC_ABBR_NM = ? \n");

		return (TbmLblCommSpecAbbrDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmLblCommSpecAbbrDVO returnTbmLblCommSpecAbbrDVO = new TbmLblCommSpecAbbrDVO();
									returnTbmLblCommSpecAbbrDVO.setSpecAbbrNm(resultSet.getString("SPEC_ABBR_NM"));
									returnTbmLblCommSpecAbbrDVO.setSpecNm(resultSet.getString("SPEC_NM"));
									return returnTbmLblCommSpecAbbrDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmLblCommSpecAbbr Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmLblCommSpecAbbr Method")
	public int mergeTbmLblCommSpecAbbr (final TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO) {
		
		if ( selectTbmLblCommSpecAbbr (tbmLblCommSpecAbbrDVO) == null) {
			return insertTbmLblCommSpecAbbr(tbmLblCommSpecAbbrDVO);
		} else {
			return selectUpdateTbmLblCommSpecAbbr (tbmLblCommSpecAbbrDVO);
		}
	}

	/**
	 * selectUpdateTbmLblCommSpecAbbr Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmLblCommSpecAbbr Method")
	public int selectUpdateTbmLblCommSpecAbbr (final TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO) {
		
		TbmLblCommSpecAbbrDVO tmpTbmLblCommSpecAbbrDVO =  selectTbmLblCommSpecAbbr (tbmLblCommSpecAbbrDVO);
		if ( tbmLblCommSpecAbbrDVO.getSpecAbbrNm() != null && !"".equals(tbmLblCommSpecAbbrDVO.getSpecAbbrNm()) ) {
			tmpTbmLblCommSpecAbbrDVO.setSpecAbbrNm(tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
		}		
		if ( tbmLblCommSpecAbbrDVO.getSpecNm() != null && !"".equals(tbmLblCommSpecAbbrDVO.getSpecNm()) ) {
			tmpTbmLblCommSpecAbbrDVO.setSpecNm(tbmLblCommSpecAbbrDVO.getSpecNm());
		}		
		return updateTbmLblCommSpecAbbr (tmpTbmLblCommSpecAbbrDVO);
	}

/**
* insertBatchTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return int[]
*/
	@LocalName("insertBatchTbmLblCommSpecAbbr")
	public int[] insertBatchTbmLblCommSpecAbbr (final List tbmLblCommSpecAbbrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.insertBatchTbmLblCommSpecAbbr.001*/  \n");
			sql.append(" TBM_LBL_COMM_SPEC_ABBR (   \n");
			sql.append("        SPEC_ABBR_NM , \n");
			sql.append("        SPEC_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO = (TbmLblCommSpecAbbrDVO)tbmLblCommSpecAbbrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecNm());

						}
							public int getBatchSize() {
									return tbmLblCommSpecAbbrDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return int[]
*/
	@LocalName("updateBatchTbmLblCommSpecAbbr")
	public int[] updateBatchTbmLblCommSpecAbbr (final List tbmLblCommSpecAbbrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.updateBatchTbmLblCommSpecAbbr.001*/  \n");
			sql.append(" TBM_LBL_COMM_SPEC_ABBR \n");
			sql.append(" SET   \n");
			sql.append("        SPEC_NM = ? \n");
			sql.append(" WHERE SPEC_ABBR_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO = (TbmLblCommSpecAbbrDVO)tbmLblCommSpecAbbrDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecNm());

							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
						}
							public int getBatchSize() {
									return tbmLblCommSpecAbbrDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmLblCommSpecAbbr Method
* 
* @ref_table TBM_LBL_COMM_SPEC_ABBR
* @return int[]
*/
	@LocalName("deleteBatchTbmLblCommSpecAbbr")
	public int[] deleteBatchTbmLblCommSpecAbbr (final List tbmLblCommSpecAbbrDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmLblCommSpecAbbrDEM.deleteBatchTbmLblCommSpecAbbr.001*/  \n");
			sql.append(" TBM_LBL_COMM_SPEC_ABBR \n");
			sql.append("  WHERE SPEC_ABBR_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmLblCommSpecAbbrDVO tbmLblCommSpecAbbrDVO = (TbmLblCommSpecAbbrDVO)tbmLblCommSpecAbbrDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmLblCommSpecAbbrDVO.getSpecAbbrNm());
						}
							public int getBatchSize() {
									return tbmLblCommSpecAbbrDVOList.size();
							}
					}
		);			
	}

	
}