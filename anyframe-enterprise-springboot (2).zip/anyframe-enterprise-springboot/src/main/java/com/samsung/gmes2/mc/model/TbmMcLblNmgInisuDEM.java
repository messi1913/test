package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MC_LBL_NMG_INISU
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbmMcLblNmgInisuDEM extends AbstractDAO {


/**
* insertTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return int
*/
	@LocalName("insertTbmMcLblNmgInisu")
	public int insertTbmMcLblNmgInisu (final TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.insertTbmMcLblNmgInisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_INISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PO_NO , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRODC_PLAN_YMD , \n");
			sql.append("        NMG_APLY_YMD , \n");
			sql.append("        NMG_DESC , \n");
			sql.append("        NMG_NO , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        PRT_CNT , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        LAST_PRTER_ID , \n");
			sql.append("        LAST_PRT_DT \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgAplyYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgDesc());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbmMcLblNmgInisuDVO.getPrtCnt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtDt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrtDt());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMcLblNmgInisu Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMcLblNmgInisu Method")
	public int[][] updateBatchAllTbmMcLblNmgInisu (final List  tbmMcLblNmgInisuDVOList) {
		
		ArrayList updatetbmMcLblNmgInisuDVOList = new ArrayList();
		ArrayList insertttbmMcLblNmgInisuDVOList = new ArrayList();
		ArrayList deletetbmMcLblNmgInisuDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMcLblNmgInisuDVOList.size() ; i++) {
		  TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO = (TbmMcLblNmgInisuDVO) tbmMcLblNmgInisuDVOList.get(i);
		  
		  if (tbmMcLblNmgInisuDVO.getSqlAction().equals("C"))
		      insertttbmMcLblNmgInisuDVOList.add(tbmMcLblNmgInisuDVO);
		  else if (tbmMcLblNmgInisuDVO.getSqlAction().equals("U"))
		      updatetbmMcLblNmgInisuDVOList.add(tbmMcLblNmgInisuDVO);
		  else if (tbmMcLblNmgInisuDVO.getSqlAction().equals("D"))
		      deletetbmMcLblNmgInisuDVOList.add(tbmMcLblNmgInisuDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMcLblNmgInisuDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMcLblNmgInisu(insertttbmMcLblNmgInisuDVOList);
          
      if (updatetbmMcLblNmgInisuDVOList.size() >0)
          resultValues[1] = updateBatchTbmMcLblNmgInisu(updatetbmMcLblNmgInisuDVOList);
      
      if (deletetbmMcLblNmgInisuDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMcLblNmgInisu(deletetbmMcLblNmgInisuDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return int
*/
	@LocalName("updateTbmMcLblNmgInisu")
	public int updateTbmMcLblNmgInisu (final TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.updateTbmMcLblNmgInisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_INISU \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        NMG_ART_ID = ? , \n");
			sql.append("        NMG_KEY_VALUE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PO_NO = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        PRODC_PLAN_YMD = ? , \n");
			sql.append("        NMG_APLY_YMD = ? , \n");
			sql.append("        NMG_DESC = ? , \n");
			sql.append("        NMG_NO = ? , \n");
			sql.append("        PRT_YN = ? , \n");
			sql.append("        PRT_CNT = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        PRT_DT = ? , \n");
			sql.append("        LAST_PRTER_ID = ? , \n");
			sql.append("        LAST_PRT_DT = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgAplyYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgDesc());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbmMcLblNmgInisuDVO.getPrtCnt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtDt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrtDt());

							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
						}
					}
		);			
	}

/**
* deleteTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return int
*/
	@LocalName("deleteTbmMcLblNmgInisu")
	public int deleteTbmMcLblNmgInisu (final TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.deleteTbmMcLblNmgInisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_INISU \n");
			sql.append("  WHERE NMG_ID = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
						}
					}
		);			
	}

/**
* selectTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return TbmMcLblNmgInisuDVO 
*/
	@LocalName("selectTbmMcLblNmgInisu")
	public TbmMcLblNmgInisuDVO selectTbmMcLblNmgInisu (final TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.selectTbmMcLblNmgInisu.001*/  \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PO_NO , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRODC_PLAN_YMD , \n");
			sql.append("        NMG_APLY_YMD , \n");
			sql.append("        NMG_DESC , \n");
			sql.append("        NMG_NO , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        PRT_CNT , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        LAST_PRTER_ID , \n");
			sql.append("        LAST_PRT_DT \n");
			sql.append("   FROM TBM_MC_LBL_NMG_INISU \n");
			sql.append("  WHERE NMG_ID = ? \n");

		return (TbmMcLblNmgInisuDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMcLblNmgInisuDVO returnTbmMcLblNmgInisuDVO = new TbmMcLblNmgInisuDVO();
									returnTbmMcLblNmgInisuDVO.setNmgId(resultSet.getString("NMG_ID"));
									returnTbmMcLblNmgInisuDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMcLblNmgInisuDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMcLblNmgInisuDVO.setNmgArtId(resultSet.getString("NMG_ART_ID"));
									returnTbmMcLblNmgInisuDVO.setNmgKeyValue(resultSet.getString("NMG_KEY_VALUE"));
									returnTbmMcLblNmgInisuDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbmMcLblNmgInisuDVO.setPoNo(resultSet.getString("PO_NO"));
									returnTbmMcLblNmgInisuDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMcLblNmgInisuDVO.setProdcPlanYmd(resultSet.getString("PRODC_PLAN_YMD"));
									returnTbmMcLblNmgInisuDVO.setNmgAplyYmd(resultSet.getString("NMG_APLY_YMD"));
									returnTbmMcLblNmgInisuDVO.setNmgDesc(resultSet.getString("NMG_DESC"));
									returnTbmMcLblNmgInisuDVO.setNmgNo(resultSet.getString("NMG_NO"));
									returnTbmMcLblNmgInisuDVO.setPrtYn(resultSet.getString("PRT_YN"));
									returnTbmMcLblNmgInisuDVO.setPrtCnt(resultSet.getBigDecimal("PRT_CNT"));
									returnTbmMcLblNmgInisuDVO.setPrterId(resultSet.getString("PRTER_ID"));
									returnTbmMcLblNmgInisuDVO.setPrtDt(resultSet.getString("PRT_DT"));
									returnTbmMcLblNmgInisuDVO.setLastPrterId(resultSet.getString("LAST_PRTER_ID"));
									returnTbmMcLblNmgInisuDVO.setLastPrtDt(resultSet.getString("LAST_PRT_DT"));
									return returnTbmMcLblNmgInisuDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMcLblNmgInisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMcLblNmgInisu Method")
	public int mergeTbmMcLblNmgInisu (final TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO) {
		
		if ( selectTbmMcLblNmgInisu (tbmMcLblNmgInisuDVO) == null) {
			return insertTbmMcLblNmgInisu(tbmMcLblNmgInisuDVO);
		} else {
			return selectUpdateTbmMcLblNmgInisu (tbmMcLblNmgInisuDVO);
		}
	}

	/**
	 * selectUpdateTbmMcLblNmgInisu Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMcLblNmgInisu Method")
	public int selectUpdateTbmMcLblNmgInisu (final TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO) {
		
		TbmMcLblNmgInisuDVO tmpTbmMcLblNmgInisuDVO =  selectTbmMcLblNmgInisu (tbmMcLblNmgInisuDVO);
		if ( tbmMcLblNmgInisuDVO.getNmgId() != null && !"".equals(tbmMcLblNmgInisuDVO.getNmgId()) ) {
			tmpTbmMcLblNmgInisuDVO.setNmgId(tbmMcLblNmgInisuDVO.getNmgId());
		}		
		if ( tbmMcLblNmgInisuDVO.getPlantCode() != null && !"".equals(tbmMcLblNmgInisuDVO.getPlantCode()) ) {
			tmpTbmMcLblNmgInisuDVO.setPlantCode(tbmMcLblNmgInisuDVO.getPlantCode());
		}		
		if ( tbmMcLblNmgInisuDVO.getModelCode() != null && !"".equals(tbmMcLblNmgInisuDVO.getModelCode()) ) {
			tmpTbmMcLblNmgInisuDVO.setModelCode(tbmMcLblNmgInisuDVO.getModelCode());
		}		
		if ( tbmMcLblNmgInisuDVO.getNmgArtId() != null && !"".equals(tbmMcLblNmgInisuDVO.getNmgArtId()) ) {
			tmpTbmMcLblNmgInisuDVO.setNmgArtId(tbmMcLblNmgInisuDVO.getNmgArtId());
		}		
		if ( tbmMcLblNmgInisuDVO.getNmgKeyValue() != null && !"".equals(tbmMcLblNmgInisuDVO.getNmgKeyValue()) ) {
			tmpTbmMcLblNmgInisuDVO.setNmgKeyValue(tbmMcLblNmgInisuDVO.getNmgKeyValue());
		}		
		if ( tbmMcLblNmgInisuDVO.getLabelId() != null && !"".equals(tbmMcLblNmgInisuDVO.getLabelId()) ) {
			tmpTbmMcLblNmgInisuDVO.setLabelId(tbmMcLblNmgInisuDVO.getLabelId());
		}		
		if ( tbmMcLblNmgInisuDVO.getPoNo() != null && !"".equals(tbmMcLblNmgInisuDVO.getPoNo()) ) {
			tmpTbmMcLblNmgInisuDVO.setPoNo(tbmMcLblNmgInisuDVO.getPoNo());
		}		
		if ( tbmMcLblNmgInisuDVO.getLineCode() != null && !"".equals(tbmMcLblNmgInisuDVO.getLineCode()) ) {
			tmpTbmMcLblNmgInisuDVO.setLineCode(tbmMcLblNmgInisuDVO.getLineCode());
		}		
		if ( tbmMcLblNmgInisuDVO.getProdcPlanYmd() != null && !"".equals(tbmMcLblNmgInisuDVO.getProdcPlanYmd()) ) {
			tmpTbmMcLblNmgInisuDVO.setProdcPlanYmd(tbmMcLblNmgInisuDVO.getProdcPlanYmd());
		}		
		if ( tbmMcLblNmgInisuDVO.getNmgAplyYmd() != null && !"".equals(tbmMcLblNmgInisuDVO.getNmgAplyYmd()) ) {
			tmpTbmMcLblNmgInisuDVO.setNmgAplyYmd(tbmMcLblNmgInisuDVO.getNmgAplyYmd());
		}		
		if ( tbmMcLblNmgInisuDVO.getNmgDesc() != null && !"".equals(tbmMcLblNmgInisuDVO.getNmgDesc()) ) {
			tmpTbmMcLblNmgInisuDVO.setNmgDesc(tbmMcLblNmgInisuDVO.getNmgDesc());
		}		
		if ( tbmMcLblNmgInisuDVO.getNmgNo() != null && !"".equals(tbmMcLblNmgInisuDVO.getNmgNo()) ) {
			tmpTbmMcLblNmgInisuDVO.setNmgNo(tbmMcLblNmgInisuDVO.getNmgNo());
		}		
		if ( tbmMcLblNmgInisuDVO.getPrtYn() != null && !"".equals(tbmMcLblNmgInisuDVO.getPrtYn()) ) {
			tmpTbmMcLblNmgInisuDVO.setPrtYn(tbmMcLblNmgInisuDVO.getPrtYn());
		}		
		if ( tbmMcLblNmgInisuDVO.getPrtCnt() != null && !"".equals(tbmMcLblNmgInisuDVO.getPrtCnt()) ) {
			tmpTbmMcLblNmgInisuDVO.setPrtCnt(tbmMcLblNmgInisuDVO.getPrtCnt());
		}		
		if ( tbmMcLblNmgInisuDVO.getPrterId() != null && !"".equals(tbmMcLblNmgInisuDVO.getPrterId()) ) {
			tmpTbmMcLblNmgInisuDVO.setPrterId(tbmMcLblNmgInisuDVO.getPrterId());
		}		
		if ( tbmMcLblNmgInisuDVO.getPrtDt() != null && !"".equals(tbmMcLblNmgInisuDVO.getPrtDt()) ) {
			tmpTbmMcLblNmgInisuDVO.setPrtDt(tbmMcLblNmgInisuDVO.getPrtDt());
		}		
		if ( tbmMcLblNmgInisuDVO.getLastPrterId() != null && !"".equals(tbmMcLblNmgInisuDVO.getLastPrterId()) ) {
			tmpTbmMcLblNmgInisuDVO.setLastPrterId(tbmMcLblNmgInisuDVO.getLastPrterId());
		}		
		if ( tbmMcLblNmgInisuDVO.getLastPrtDt() != null && !"".equals(tbmMcLblNmgInisuDVO.getLastPrtDt()) ) {
			tmpTbmMcLblNmgInisuDVO.setLastPrtDt(tbmMcLblNmgInisuDVO.getLastPrtDt());
		}		
		return updateTbmMcLblNmgInisu (tmpTbmMcLblNmgInisuDVO);
	}

/**
* insertBatchTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return int[]
*/
	@LocalName("insertBatchTbmMcLblNmgInisu")
	public int[] insertBatchTbmMcLblNmgInisu (final List tbmMcLblNmgInisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.insertBatchTbmMcLblNmgInisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_INISU (   \n");
			sql.append("        NMG_ID , \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        NMG_ART_ID , \n");
			sql.append("        NMG_KEY_VALUE , \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        PO_NO , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        PRODC_PLAN_YMD , \n");
			sql.append("        NMG_APLY_YMD , \n");
			sql.append("        NMG_DESC , \n");
			sql.append("        NMG_NO , \n");
			sql.append("        PRT_YN , \n");
			sql.append("        PRT_CNT , \n");
			sql.append("        PRTER_ID , \n");
			sql.append("        PRT_DT , \n");
			sql.append("        LAST_PRTER_ID , \n");
			sql.append("        LAST_PRT_DT \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO = (TbmMcLblNmgInisuDVO)tbmMcLblNmgInisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgAplyYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgDesc());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbmMcLblNmgInisuDVO.getPrtCnt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtDt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrtDt());

						}
							public int getBatchSize() {
									return tbmMcLblNmgInisuDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return int[]
*/
	@LocalName("updateBatchTbmMcLblNmgInisu")
	public int[] updateBatchTbmMcLblNmgInisu (final List tbmMcLblNmgInisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.updateBatchTbmMcLblNmgInisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_INISU \n");
			sql.append(" SET   \n");
			sql.append("        PLANT_CODE = ? , \n");
			sql.append("        MODEL_CODE = ? , \n");
			sql.append("        NMG_ART_ID = ? , \n");
			sql.append("        NMG_KEY_VALUE = ? , \n");
			sql.append("        LABEL_ID = ? , \n");
			sql.append("        PO_NO = ? , \n");
			sql.append("        LINE_CODE = ? , \n");
			sql.append("        PRODC_PLAN_YMD = ? , \n");
			sql.append("        NMG_APLY_YMD = ? , \n");
			sql.append("        NMG_DESC = ? , \n");
			sql.append("        NMG_NO = ? , \n");
			sql.append("        PRT_YN = ? , \n");
			sql.append("        PRT_CNT = ? , \n");
			sql.append("        PRTER_ID = ? , \n");
			sql.append("        PRT_DT = ? , \n");
			sql.append("        LAST_PRTER_ID = ? , \n");
			sql.append("        LAST_PRT_DT = ? \n");
			sql.append(" WHERE NMG_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO = (TbmMcLblNmgInisuDVO)tbmMcLblNmgInisuDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPlantCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getModelCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgArtId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgKeyValue());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLabelId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPoNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLineCode());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getProdcPlanYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgAplyYmd());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgDesc());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgNo());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtYn());
							ps.setBigDecimal(psCount++, tbmMcLblNmgInisuDVO.getPrtCnt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getPrtDt());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrterId());
							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getLastPrtDt());

							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
						}
							public int getBatchSize() {
									return tbmMcLblNmgInisuDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMcLblNmgInisu Method
* 
* @ref_table TBM_MC_LBL_NMG_INISU
* @return int[]
*/
	@LocalName("deleteBatchTbmMcLblNmgInisu")
	public int[] deleteBatchTbmMcLblNmgInisu (final List tbmMcLblNmgInisuDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbmMcLblNmgInisuDEM.deleteBatchTbmMcLblNmgInisu.001*/  \n");
			sql.append(" TBM_MC_LBL_NMG_INISU \n");
			sql.append("  WHERE NMG_ID = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMcLblNmgInisuDVO tbmMcLblNmgInisuDVO = (TbmMcLblNmgInisuDVO)tbmMcLblNmgInisuDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMcLblNmgInisuDVO.getNmgId());
						}
							public int getBatchSize() {
									return tbmMcLblNmgInisuDVOList.size();
							}
					}
		);			
	}

	
}