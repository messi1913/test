package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdPlantModelDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(20) 
	private String modelCode;

	@Length(14) 
	private String ifDt;

	@Length(30) 
	private String labelWrtCode;

	@Length(30) 
	private String matrTypeCode;

	@Length(30) 
	private String buyerCode;

	@Length(1) 
	private String buyerInspYn;

	@Length(500) 
	private String salRegnNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(1);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(1, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getIfDt() {
		this.ifDt = super.getValue(2);
		return this.ifDt;
	}

	public void setIfDt(String ifDt) {
        super.setValue(2, ifDt);
		this.ifDt = ifDt;
	}
	
	public String getLabelWrtCode() {
		this.labelWrtCode = super.getValue(3);
		return this.labelWrtCode;
	}

	public void setLabelWrtCode(String labelWrtCode) {
        super.setValue(3, labelWrtCode);
		this.labelWrtCode = labelWrtCode;
	}
	
	public String getMatrTypeCode() {
		this.matrTypeCode = super.getValue(4);
		return this.matrTypeCode;
	}

	public void setMatrTypeCode(String matrTypeCode) {
        super.setValue(4, matrTypeCode);
		this.matrTypeCode = matrTypeCode;
	}
	
	public String getBuyerCode() {
		this.buyerCode = super.getValue(5);
		return this.buyerCode;
	}

	public void setBuyerCode(String buyerCode) {
        super.setValue(5, buyerCode);
		this.buyerCode = buyerCode;
	}
	
	public String getBuyerInspYn() {
		this.buyerInspYn = super.getValue(6);
		return this.buyerInspYn;
	}

	public void setBuyerInspYn(String buyerInspYn) {
        super.setValue(6, buyerInspYn);
		this.buyerInspYn = buyerInspYn;
	}
	
	public String getSalRegnNm() {
		this.salRegnNm = super.getValue(7);
		return this.salRegnNm;
	}

	public void setSalRegnNm(String salRegnNm) {
        super.setValue(7, salRegnNm);
		this.salRegnNm = salRegnNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(8);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(8, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(9);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(9, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(10);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(10, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(11);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(11, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(12);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(12, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}