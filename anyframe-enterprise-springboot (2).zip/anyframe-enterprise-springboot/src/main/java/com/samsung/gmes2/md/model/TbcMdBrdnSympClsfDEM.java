package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdBrdnSympClsfDEM extends AbstractDAO {


/**
* insertTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return int
*/
	@LocalName("insertTbcMdBrdnSympClsf")
	public int insertTbcMdBrdnSympClsf (final TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.insertTbcMdBrdnSympClsf.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP_CLSF (   \n");
			sql.append("        BRDN_SYMP_CLSF_CODE , \n");
			sql.append("        BRDN_SYMP_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdBrdnSympClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdBrdnSympClsf Method")
	public int[][] updateBatchAllTbcMdBrdnSympClsf (final List  tbcMdBrdnSympClsfDVOList) {
		
		ArrayList updatetbcMdBrdnSympClsfDVOList = new ArrayList();
		ArrayList insertttbcMdBrdnSympClsfDVOList = new ArrayList();
		ArrayList deletetbcMdBrdnSympClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdBrdnSympClsfDVOList.size() ; i++) {
		  TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO = (TbcMdBrdnSympClsfDVO) tbcMdBrdnSympClsfDVOList.get(i);
		  
		  if (tbcMdBrdnSympClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdBrdnSympClsfDVOList.add(tbcMdBrdnSympClsfDVO);
		  else if (tbcMdBrdnSympClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdBrdnSympClsfDVOList.add(tbcMdBrdnSympClsfDVO);
		  else if (tbcMdBrdnSympClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdBrdnSympClsfDVOList.add(tbcMdBrdnSympClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdBrdnSympClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdBrdnSympClsf(insertttbcMdBrdnSympClsfDVOList);
          
      if (updatetbcMdBrdnSympClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdBrdnSympClsf(updatetbcMdBrdnSympClsfDVOList);
      
      if (deletetbcMdBrdnSympClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdBrdnSympClsf(deletetbcMdBrdnSympClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return int
*/
	@LocalName("updateTbcMdBrdnSympClsf")
	public int updateTbcMdBrdnSympClsf (final TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.updateTbcMdBrdnSympClsf.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        BRDN_SYMP_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_SYMP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return int
*/
	@LocalName("deleteTbcMdBrdnSympClsf")
	public int deleteTbcMdBrdnSympClsf (final TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.deleteTbcMdBrdnSympClsf.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP_CLSF \n");
			sql.append("  WHERE BRDN_SYMP_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return TbcMdBrdnSympClsfDVO 
*/
	@LocalName("selectTbcMdBrdnSympClsf")
	public TbcMdBrdnSympClsfDVO selectTbcMdBrdnSympClsf (final TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.selectTbcMdBrdnSympClsf.001*/  \n");
			sql.append("        BRDN_SYMP_CLSF_CODE , \n");
			sql.append("        BRDN_SYMP_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_BRDN_SYMP_CLSF \n");
			sql.append("  WHERE BRDN_SYMP_CLSF_CODE = ? \n");

		return (TbcMdBrdnSympClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdBrdnSympClsfDVO returnTbcMdBrdnSympClsfDVO = new TbcMdBrdnSympClsfDVO();
									returnTbcMdBrdnSympClsfDVO.setBrdnSympClsfCode(resultSet.getString("BRDN_SYMP_CLSF_CODE"));
									returnTbcMdBrdnSympClsfDVO.setBrdnSympClsfNm(resultSet.getString("BRDN_SYMP_CLSF_NM"));
									returnTbcMdBrdnSympClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdBrdnSympClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdBrdnSympClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdBrdnSympClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdBrdnSympClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdBrdnSympClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdBrdnSympClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdBrdnSympClsf Method")
	public int mergeTbcMdBrdnSympClsf (final TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO) {
		
		if ( selectTbcMdBrdnSympClsf (tbcMdBrdnSympClsfDVO) == null) {
			return insertTbcMdBrdnSympClsf(tbcMdBrdnSympClsfDVO);
		} else {
			return selectUpdateTbcMdBrdnSympClsf (tbcMdBrdnSympClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdBrdnSympClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdBrdnSympClsf Method")
	public int selectUpdateTbcMdBrdnSympClsf (final TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO) {
		
		TbcMdBrdnSympClsfDVO tmpTbcMdBrdnSympClsfDVO =  selectTbcMdBrdnSympClsf (tbcMdBrdnSympClsfDVO);
		if ( tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode() != null && !"".equals(tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode()) ) {
			tmpTbcMdBrdnSympClsfDVO.setBrdnSympClsfCode(tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
		}		
		if ( tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm() != null && !"".equals(tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm()) ) {
			tmpTbcMdBrdnSympClsfDVO.setBrdnSympClsfNm(tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm());
		}		
		if ( tbcMdBrdnSympClsfDVO.getUseYn() != null && !"".equals(tbcMdBrdnSympClsfDVO.getUseYn()) ) {
			tmpTbcMdBrdnSympClsfDVO.setUseYn(tbcMdBrdnSympClsfDVO.getUseYn());
		}		
		if ( tbcMdBrdnSympClsfDVO.getFstRegDt() != null && !"".equals(tbcMdBrdnSympClsfDVO.getFstRegDt()) ) {
			tmpTbcMdBrdnSympClsfDVO.setFstRegDt(tbcMdBrdnSympClsfDVO.getFstRegDt());
		}		
		if ( tbcMdBrdnSympClsfDVO.getFstRegerId() != null && !"".equals(tbcMdBrdnSympClsfDVO.getFstRegerId()) ) {
			tmpTbcMdBrdnSympClsfDVO.setFstRegerId(tbcMdBrdnSympClsfDVO.getFstRegerId());
		}		
		if ( tbcMdBrdnSympClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdBrdnSympClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdBrdnSympClsfDVO.setFnlUpdDt(tbcMdBrdnSympClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdBrdnSympClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdBrdnSympClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdBrdnSympClsfDVO.setFnlUpderId(tbcMdBrdnSympClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdBrdnSympClsf (tmpTbcMdBrdnSympClsfDVO);
	}

/**
* insertBatchTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdBrdnSympClsf")
	public int[] insertBatchTbcMdBrdnSympClsf (final List tbcMdBrdnSympClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.insertBatchTbcMdBrdnSympClsf.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP_CLSF (   \n");
			sql.append("        BRDN_SYMP_CLSF_CODE , \n");
			sql.append("        BRDN_SYMP_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO = (TbcMdBrdnSympClsfDVO)tbcMdBrdnSympClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdBrdnSympClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdBrdnSympClsf")
	public int[] updateBatchTbcMdBrdnSympClsf (final List tbcMdBrdnSympClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.updateBatchTbcMdBrdnSympClsf.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        BRDN_SYMP_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_SYMP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO = (TbcMdBrdnSympClsfDVO)tbcMdBrdnSympClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfNm());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnSympClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdBrdnSympClsf Method
* 
* @ref_table TBC_MD_BRDN_SYMP_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdBrdnSympClsf")
	public int[] deleteBatchTbcMdBrdnSympClsf (final List tbcMdBrdnSympClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnSympClsfDEM.deleteBatchTbcMdBrdnSympClsf.001*/  \n");
			sql.append(" TBC_MD_BRDN_SYMP_CLSF \n");
			sql.append("  WHERE BRDN_SYMP_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnSympClsfDVO tbcMdBrdnSympClsfDVO = (TbcMdBrdnSympClsfDVO)tbcMdBrdnSympClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnSympClsfDVO.getBrdnSympClsfCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnSympClsfDVOList.size();
							}
					}
		);			
	}

	
}