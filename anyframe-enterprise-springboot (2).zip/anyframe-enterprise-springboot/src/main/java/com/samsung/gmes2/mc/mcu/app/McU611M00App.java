/**
 * <PRE>

 * System Name : G-MES 2.0
 * Business Name : 개발템플릿 (MC) – 라벨모델 조회/등록
 * Class Name : McU611M00App.java
 * Description : 라벨모델 조회를 위한 조건들을 검색해 해당 조건에 맞는 정보를 보여주고,
 * 				라벨모델을 선택하여 새로운 라벨을 등록하거나 삭제 할 수 있다.
 * Modification History
 *       수정일            		   수정자          		 수정내용
 *    -------------     ---------    ---------------------------
 *    2011.06.30    	   심재국           	 최초 생성
 *    2011.07.14		   심재국			 Refactoring
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */

package com.samsung.gmes2.mc.mcu.app;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.anyframe.core.vo.VoUtil;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.mc.mcu.biz.McManageTbmMcLblRegModelBiz;
import com.samsung.gmes2.mc.mcu.vo.McU611M0005DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M0006DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M0008DVO;
import com.samsung.gmes2.mc.mcu.vo.McU611M00SVO;
import com.samsung.gmes2.sm.cod.vo.CodeDVO;

/**
 * 한글명 : 라벨모델 조회 작성일 : 2011.06.30 작성자 : 심 재 국 작업상태 : 완료 개요 : 라벨모델 조회를 위한 조건들을
 * 검색해 해당 조건에 맞는 정보를 보여주고, 라벨모델을 선택하여 새로운 라벨을 등록하거나 삭제 할 수 있다.
 * 
 * @name_ko 라벨모델 조회 업무
 */
@Service
public class McU611M00App {

	private static final Logger logger = LoggerFactory
			.getLogger(McU611M00App.class);

	//
	public McU611M00SVO getModelCodeList(McU611M00SVO svo) {
		/*--------------------------------------------------
		 * @fd_do_start 모델 코드 조회
		 * @fd_id 0001
		 * 조회 버튼 클릭시 
		 * 모델 코드의 정보를 조회 하는 코드
		 --------------------------------------------------*/
		// TODO
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
		logger.debug(" getModelCodeList... svo : " + svo);
		logger.debug("=================================================");

		// logger.debug(VoUtil.toMap(svo.getMcU611M0004DVO().getStatusCode()));

		// McU611M00DQM listModelCodeInfoDQM = new McU611M00DQM();
		McU611M00DQM listModelCodeInfoDQM = BaseUtil
				.getBean(McU611M00DQM.class);

		List<McU611M0008DVO> returnList = listModelCodeInfoDQM
				.dListMCU611M00DVO(VoUtil.toMap(svo.getMcU611M0004DVO()));

		McU611M00SVO mcu611m00svo = new McU611M00SVO();
		mcu611m00svo.setMcU611M0008DVOList(returnList);
		// System.out.println(mcu611m00svo);
		return mcu611m00svo;

	}

	// select box에 내용을 보여주기 위한 메서드

	public McU611M00SVO getCommonInfo(McU611M00SVO svo) {
		/*--------------------------------------------------
		 * @fd_do_start 검색 조건 조회
		 * @fd_id 0004
		 * 검색 조건 조회를 하기위하여
		 * 
		 * 3가지의 검색 조건을 콤보 박스로 보여준다
		 --------------------------------------------------*/
		// TODO
		/*--------------------------------------------------
		 * @fd_do_end 0004
		 --------------------------------------------------*/
		try {
			// modelCode
			List<CodeDVO> codeList1 = BaseUtil.getCodeList(svo
					.getMcU611M0001DVO().getCate3Type());
			svo.setMcU611M0001DVOList(codeList1);
			// labelType
			List<CodeDVO> codeList2 = BaseUtil.getCodeList(svo
					.getMcU611M0001DVO().getCate1Type());
			svo.setMcU611M0002DVOList(codeList2);
			// status
			List<CodeDVO> codeList3 = BaseUtil.getCodeList(svo
					.getMcU611M0001DVO().getCate2Type());
			svo.setMcU611M0003DVOList(codeList3);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return svo;
	}

	// main 화면 에서 클릭후 delete
	// McMcuFacade 를 호출
	// McMcuFacade 에서 McManageTbmMcLblRegModelBiz().deleteModelCode호출
	public McU611M00SVO delelteModelCode(McU611M00SVO svo) {
		/*--------------------------------------------------
		 * @fd_do_start 모델 코드 삭제
		 * @fd_id 0001
		 * 체크에 해당하는 모델 코드를 삭제한다.
		 --------------------------------------------------*/
		// TODO
		
			svo = BaseUtil.getBean(McManageTbmMcLblRegModelBiz.class).delelteModelCode(svo);
		return svo;
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/
	}

	// refactoring 시
	// 합치기해서 붙여 넣은부분
	// Pilot 진행시 만든 logic
	// 이것 또한 개발시는 BaseUtil.getCodeList를 이용하면 됨

	public McU611M00SVO getLblRegInfoList(McU611M00SVO svo) {
		/*--------------------------------------------------
		 * @fd_do_start 라벨 정보 List
		 * @fd_id 0001
		 * 모든 라벨의 정보를 가져와서
		 * 그리드에 보여준다.
		 --------------------------------------------------*/
		// TODO

		logger.debug(" getLblRegInfoList... svo : " + svo);
		// cateId 에 CAT00001 setting
		Map input = new HashMap();
		input.put("cateId", "CAT00001");

		// McU611M00DQM lblRegInfoListDQM = new McU611M00DQM();
		McU611M00DQM lblRegInfoListDQM = BaseUtil.getBean(McU611M00DQM.class);

		List<McU611M0005DVO> mCLabelInfo00DVOList = lblRegInfoListDQM
				.dListAllLabelInfo(input);

		svo.setMcU611M0005DVOList(mCLabelInfo00DVOList);
		return svo;
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

	}

	public McU611M00SVO getModelCodeInfoList(McU611M00SVO svo) {
		/*--------------------------------------------------
		 * @fd_do_start 모델 라벨 정보 List
		 * @fd_id 0001
		 * 모델 코드가 현재 가지고 있는 
		 * 라벨 정보를 보여준다.
		 --------------------------------------------------*/
		// TODO
		logger.debug(" getModelCodeInfoList... svo : " + svo);
		// logger.debug("<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		// logger.debug("modelCode ++++++++++++++++++++++++++++++++++++++++++++"+svo.getMCModelCd01DVO().getModelCode());
		// cateId 에 setting CAT00001
		// modelCode 에 svo 의 모델 코드 세팅
		Map input = new HashMap();
		input.put("cateId", "CAT00001");
		input.put("modelCode", svo.getMcU611M0007DVO().getComCode());

		// McU611M00DQM mcu611m00dqm = new McU611M00DQM();
		McU611M00DQM mcu611m00dqm = BaseUtil.getBean(McU611M00DQM.class);

		List<McU611M0006DVO> mCModelLabelInfo00DVOList = mcu611m00dqm
				.dListModelCodeInfo(input);

		svo.setMcU611M0006DVOList(mCModelLabelInfo00DVOList);

		return svo;
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

	}

	public McU611M00SVO saveTbmMcLblRegModel(McU611M00SVO svo) {
		/*--------------------------------------------------
		 * @fd_do_start McMcuFacade의 saveTbmMcLblRegModel 를 호출
		 * @fd_id 0001
		 * McMcuFacade의 saveTbmMcLblRegModel 를 호출한다.
		 --------------------------------------------------*/
		// TODO
		BaseUtil.getBean(McManageTbmMcLblRegModelBiz.class)
				.saveTbmMcLblRegModel(svo.getMcU611M0006DVOList());

		return svo;
		/*--------------------------------------------------
		 * @fd_do_end 0001
		 --------------------------------------------------*/

	}

}
