package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdDeftCauseClsfDEM extends AbstractDAO {


/**
* insertTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return int
*/
	@LocalName("insertTbcMdDeftCauseClsf")
	public int insertTbcMdDeftCauseClsf (final TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.insertTbcMdDeftCauseClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE_CLSF (   \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        DEFT_CAUSE_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdDeftCauseClsf Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdDeftCauseClsf Method")
	public int[][] updateBatchAllTbcMdDeftCauseClsf (final List  tbcMdDeftCauseClsfDVOList) {
		
		ArrayList updatetbcMdDeftCauseClsfDVOList = new ArrayList();
		ArrayList insertttbcMdDeftCauseClsfDVOList = new ArrayList();
		ArrayList deletetbcMdDeftCauseClsfDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdDeftCauseClsfDVOList.size() ; i++) {
		  TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO = (TbcMdDeftCauseClsfDVO) tbcMdDeftCauseClsfDVOList.get(i);
		  
		  if (tbcMdDeftCauseClsfDVO.getSqlAction().equals("C"))
		      insertttbcMdDeftCauseClsfDVOList.add(tbcMdDeftCauseClsfDVO);
		  else if (tbcMdDeftCauseClsfDVO.getSqlAction().equals("U"))
		      updatetbcMdDeftCauseClsfDVOList.add(tbcMdDeftCauseClsfDVO);
		  else if (tbcMdDeftCauseClsfDVO.getSqlAction().equals("D"))
		      deletetbcMdDeftCauseClsfDVOList.add(tbcMdDeftCauseClsfDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdDeftCauseClsfDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdDeftCauseClsf(insertttbcMdDeftCauseClsfDVOList);
          
      if (updatetbcMdDeftCauseClsfDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdDeftCauseClsf(updatetbcMdDeftCauseClsfDVOList);
      
      if (deletetbcMdDeftCauseClsfDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdDeftCauseClsf(deletetbcMdDeftCauseClsfDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return int
*/
	@LocalName("updateTbcMdDeftCauseClsf")
	public int updateTbcMdDeftCauseClsf (final TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.updateTbcMdDeftCauseClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        DEFT_CAUSE_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_CAUSE_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
						}
					}
		);			
	}

/**
* deleteTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return int
*/
	@LocalName("deleteTbcMdDeftCauseClsf")
	public int deleteTbcMdDeftCauseClsf (final TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.deleteTbcMdDeftCauseClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE_CLSF \n");
			sql.append("  WHERE DEFT_CAUSE_CLSF_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
						}
					}
		);			
	}

/**
* selectTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return TbcMdDeftCauseClsfDVO 
*/
	@LocalName("selectTbcMdDeftCauseClsf")
	public TbcMdDeftCauseClsfDVO selectTbcMdDeftCauseClsf (final TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.selectTbcMdDeftCauseClsf.001*/  \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        DEFT_CAUSE_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_DEFT_CAUSE_CLSF \n");
			sql.append("  WHERE DEFT_CAUSE_CLSF_CODE = ? \n");

		return (TbcMdDeftCauseClsfDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdDeftCauseClsfDVO returnTbcMdDeftCauseClsfDVO = new TbcMdDeftCauseClsfDVO();
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(resultSet.getString("DEFT_CAUSE_CLSF_CODE"));
									returnTbcMdDeftCauseClsfDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(resultSet.getString("DEFT_CAUSE_CLSF_NM"));
									returnTbcMdDeftCauseClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdDeftCauseClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdDeftCauseClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdDeftCauseClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdDeftCauseClsfDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdDeftCauseClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdDeftCauseClsf Method")
	public int mergeTbcMdDeftCauseClsf (final TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) {
		
		if ( selectTbcMdDeftCauseClsf (tbcMdDeftCauseClsfDVO) == null) {
			return insertTbcMdDeftCauseClsf(tbcMdDeftCauseClsfDVO);
		} else {
			return selectUpdateTbcMdDeftCauseClsf (tbcMdDeftCauseClsfDVO);
		}
	}

	/**
	 * selectUpdateTbcMdDeftCauseClsf Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdDeftCauseClsf Method")
	public int selectUpdateTbcMdDeftCauseClsf (final TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO) {
		
		TbcMdDeftCauseClsfDVO tmpTbcMdDeftCauseClsfDVO =  selectTbcMdDeftCauseClsf (tbcMdDeftCauseClsfDVO);
		if ( tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode() != null && !"".equals(tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode()) ) {
			tmpTbcMdDeftCauseClsfDVO.setDeftCauseClsfCode(tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
		}		
		if ( tbcMdDeftCauseClsfDVO.getProcGubunCode() != null && !"".equals(tbcMdDeftCauseClsfDVO.getProcGubunCode()) ) {
			tmpTbcMdDeftCauseClsfDVO.setProcGubunCode(tbcMdDeftCauseClsfDVO.getProcGubunCode());
		}		
		if ( tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm() != null && !"".equals(tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm()) ) {
			tmpTbcMdDeftCauseClsfDVO.setDeftCauseClsfNm(tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm());
		}		
		if ( tbcMdDeftCauseClsfDVO.getUseYn() != null && !"".equals(tbcMdDeftCauseClsfDVO.getUseYn()) ) {
			tmpTbcMdDeftCauseClsfDVO.setUseYn(tbcMdDeftCauseClsfDVO.getUseYn());
		}		
		if ( tbcMdDeftCauseClsfDVO.getFstRegDt() != null && !"".equals(tbcMdDeftCauseClsfDVO.getFstRegDt()) ) {
			tmpTbcMdDeftCauseClsfDVO.setFstRegDt(tbcMdDeftCauseClsfDVO.getFstRegDt());
		}		
		if ( tbcMdDeftCauseClsfDVO.getFstRegerId() != null && !"".equals(tbcMdDeftCauseClsfDVO.getFstRegerId()) ) {
			tmpTbcMdDeftCauseClsfDVO.setFstRegerId(tbcMdDeftCauseClsfDVO.getFstRegerId());
		}		
		if ( tbcMdDeftCauseClsfDVO.getFnlUpdDt() != null && !"".equals(tbcMdDeftCauseClsfDVO.getFnlUpdDt()) ) {
			tmpTbcMdDeftCauseClsfDVO.setFnlUpdDt(tbcMdDeftCauseClsfDVO.getFnlUpdDt());
		}		
		if ( tbcMdDeftCauseClsfDVO.getFnlUpderId() != null && !"".equals(tbcMdDeftCauseClsfDVO.getFnlUpderId()) ) {
			tmpTbcMdDeftCauseClsfDVO.setFnlUpderId(tbcMdDeftCauseClsfDVO.getFnlUpderId());
		}		
		return updateTbcMdDeftCauseClsf (tmpTbcMdDeftCauseClsfDVO);
	}

/**
* insertBatchTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return int[]
*/
	@LocalName("insertBatchTbcMdDeftCauseClsf")
	public int[] insertBatchTbcMdDeftCauseClsf (final List tbcMdDeftCauseClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.insertBatchTbcMdDeftCauseClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE_CLSF (   \n");
			sql.append("        DEFT_CAUSE_CLSF_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        DEFT_CAUSE_CLSF_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO = (TbcMdDeftCauseClsfDVO)tbcMdDeftCauseClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdDeftCauseClsfDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return int[]
*/
	@LocalName("updateBatchTbcMdDeftCauseClsf")
	public int[] updateBatchTbcMdDeftCauseClsf (final List tbcMdDeftCauseClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.updateBatchTbcMdDeftCauseClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE_CLSF \n");
			sql.append(" SET   \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        DEFT_CAUSE_CLSF_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE DEFT_CAUSE_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO = (TbcMdDeftCauseClsfDVO)tbcMdDeftCauseClsfDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getProcGubunCode());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfNm());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getUseYn());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDeftCauseClsfDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdDeftCauseClsf Method
* 
* @ref_table TBC_MD_DEFT_CAUSE_CLSF
* @return int[]
*/
	@LocalName("deleteBatchTbcMdDeftCauseClsf")
	public int[] deleteBatchTbcMdDeftCauseClsf (final List tbcMdDeftCauseClsfDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdDeftCauseClsfDEM.deleteBatchTbcMdDeftCauseClsf.001*/  \n");
			sql.append(" TBC_MD_DEFT_CAUSE_CLSF \n");
			sql.append("  WHERE DEFT_CAUSE_CLSF_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdDeftCauseClsfDVO tbcMdDeftCauseClsfDVO = (TbcMdDeftCauseClsfDVO)tbcMdDeftCauseClsfDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdDeftCauseClsfDVO.getDeftCauseClsfCode());
						}
							public int getBatchSize() {
									return tbcMdDeftCauseClsfDVOList.size();
							}
					}
		);			
	}

	
}