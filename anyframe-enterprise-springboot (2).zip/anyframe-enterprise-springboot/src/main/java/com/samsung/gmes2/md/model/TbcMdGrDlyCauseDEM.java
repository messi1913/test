package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_GR_DLY_CAUSE
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdGrDlyCauseDEM extends AbstractDAO {


/**
* insertTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return int
*/
	@LocalName("insertTbcMdGrDlyCause")
	public int insertTbcMdGrDlyCause (final TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.insertTbcMdGrDlyCause.001*/  \n");
			sql.append(" TBC_MD_GR_DLY_CAUSE (   \n");
			sql.append("        GR_DLY_CAUSE_CODE , \n");
			sql.append("        GR_DLY_CAUSE_NM , \n");
			sql.append("        REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseNm());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdGrDlyCause Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdGrDlyCause Method")
	public int[][] updateBatchAllTbcMdGrDlyCause (final List  tbcMdGrDlyCauseDVOList) {
		
		ArrayList updatetbcMdGrDlyCauseDVOList = new ArrayList();
		ArrayList insertttbcMdGrDlyCauseDVOList = new ArrayList();
		ArrayList deletetbcMdGrDlyCauseDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdGrDlyCauseDVOList.size() ; i++) {
		  TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO = (TbcMdGrDlyCauseDVO) tbcMdGrDlyCauseDVOList.get(i);
		  
		  if (tbcMdGrDlyCauseDVO.getSqlAction().equals("C"))
		      insertttbcMdGrDlyCauseDVOList.add(tbcMdGrDlyCauseDVO);
		  else if (tbcMdGrDlyCauseDVO.getSqlAction().equals("U"))
		      updatetbcMdGrDlyCauseDVOList.add(tbcMdGrDlyCauseDVO);
		  else if (tbcMdGrDlyCauseDVO.getSqlAction().equals("D"))
		      deletetbcMdGrDlyCauseDVOList.add(tbcMdGrDlyCauseDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdGrDlyCauseDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdGrDlyCause(insertttbcMdGrDlyCauseDVOList);
          
      if (updatetbcMdGrDlyCauseDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdGrDlyCause(updatetbcMdGrDlyCauseDVOList);
      
      if (deletetbcMdGrDlyCauseDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdGrDlyCause(deletetbcMdGrDlyCauseDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return int
*/
	@LocalName("updateTbcMdGrDlyCause")
	public int updateTbcMdGrDlyCause (final TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.updateTbcMdGrDlyCause.001*/  \n");
			sql.append(" TBC_MD_GR_DLY_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        GR_DLY_CAUSE_NM = ? , \n");
			sql.append("        REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GR_DLY_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseNm());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
						}
					}
		);			
	}

/**
* deleteTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return int
*/
	@LocalName("deleteTbcMdGrDlyCause")
	public int deleteTbcMdGrDlyCause (final TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.deleteTbcMdGrDlyCause.001*/  \n");
			sql.append(" TBC_MD_GR_DLY_CAUSE \n");
			sql.append("  WHERE GR_DLY_CAUSE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
						}
					}
		);			
	}

/**
* selectTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return TbcMdGrDlyCauseDVO 
*/
	@LocalName("selectTbcMdGrDlyCause")
	public TbcMdGrDlyCauseDVO selectTbcMdGrDlyCause (final TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.selectTbcMdGrDlyCause.001*/  \n");
			sql.append("        GR_DLY_CAUSE_CODE , \n");
			sql.append("        GR_DLY_CAUSE_NM , \n");
			sql.append("        REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_GR_DLY_CAUSE \n");
			sql.append("  WHERE GR_DLY_CAUSE_CODE = ? \n");

		return (TbcMdGrDlyCauseDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdGrDlyCauseDVO returnTbcMdGrDlyCauseDVO = new TbcMdGrDlyCauseDVO();
									returnTbcMdGrDlyCauseDVO.setGrDlyCauseCode(resultSet.getString("GR_DLY_CAUSE_CODE"));
									returnTbcMdGrDlyCauseDVO.setGrDlyCauseNm(resultSet.getString("GR_DLY_CAUSE_NM"));
									returnTbcMdGrDlyCauseDVO.setReflYn(resultSet.getString("REFL_YN"));
									returnTbcMdGrDlyCauseDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdGrDlyCauseDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdGrDlyCauseDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdGrDlyCauseDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdGrDlyCauseDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdGrDlyCauseDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdGrDlyCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdGrDlyCause Method")
	public int mergeTbcMdGrDlyCause (final TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO) {
		
		if ( selectTbcMdGrDlyCause (tbcMdGrDlyCauseDVO) == null) {
			return insertTbcMdGrDlyCause(tbcMdGrDlyCauseDVO);
		} else {
			return selectUpdateTbcMdGrDlyCause (tbcMdGrDlyCauseDVO);
		}
	}

	/**
	 * selectUpdateTbcMdGrDlyCause Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdGrDlyCause Method")
	public int selectUpdateTbcMdGrDlyCause (final TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO) {
		
		TbcMdGrDlyCauseDVO tmpTbcMdGrDlyCauseDVO =  selectTbcMdGrDlyCause (tbcMdGrDlyCauseDVO);
		if ( tbcMdGrDlyCauseDVO.getGrDlyCauseCode() != null && !"".equals(tbcMdGrDlyCauseDVO.getGrDlyCauseCode()) ) {
			tmpTbcMdGrDlyCauseDVO.setGrDlyCauseCode(tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
		}		
		if ( tbcMdGrDlyCauseDVO.getGrDlyCauseNm() != null && !"".equals(tbcMdGrDlyCauseDVO.getGrDlyCauseNm()) ) {
			tmpTbcMdGrDlyCauseDVO.setGrDlyCauseNm(tbcMdGrDlyCauseDVO.getGrDlyCauseNm());
		}		
		if ( tbcMdGrDlyCauseDVO.getReflYn() != null && !"".equals(tbcMdGrDlyCauseDVO.getReflYn()) ) {
			tmpTbcMdGrDlyCauseDVO.setReflYn(tbcMdGrDlyCauseDVO.getReflYn());
		}		
		if ( tbcMdGrDlyCauseDVO.getUseYn() != null && !"".equals(tbcMdGrDlyCauseDVO.getUseYn()) ) {
			tmpTbcMdGrDlyCauseDVO.setUseYn(tbcMdGrDlyCauseDVO.getUseYn());
		}		
		if ( tbcMdGrDlyCauseDVO.getFstRegDt() != null && !"".equals(tbcMdGrDlyCauseDVO.getFstRegDt()) ) {
			tmpTbcMdGrDlyCauseDVO.setFstRegDt(tbcMdGrDlyCauseDVO.getFstRegDt());
		}		
		if ( tbcMdGrDlyCauseDVO.getFstRegerId() != null && !"".equals(tbcMdGrDlyCauseDVO.getFstRegerId()) ) {
			tmpTbcMdGrDlyCauseDVO.setFstRegerId(tbcMdGrDlyCauseDVO.getFstRegerId());
		}		
		if ( tbcMdGrDlyCauseDVO.getFnlUpdDt() != null && !"".equals(tbcMdGrDlyCauseDVO.getFnlUpdDt()) ) {
			tmpTbcMdGrDlyCauseDVO.setFnlUpdDt(tbcMdGrDlyCauseDVO.getFnlUpdDt());
		}		
		if ( tbcMdGrDlyCauseDVO.getFnlUpderId() != null && !"".equals(tbcMdGrDlyCauseDVO.getFnlUpderId()) ) {
			tmpTbcMdGrDlyCauseDVO.setFnlUpderId(tbcMdGrDlyCauseDVO.getFnlUpderId());
		}		
		return updateTbcMdGrDlyCause (tmpTbcMdGrDlyCauseDVO);
	}

/**
* insertBatchTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return int[]
*/
	@LocalName("insertBatchTbcMdGrDlyCause")
	public int[] insertBatchTbcMdGrDlyCause (final List tbcMdGrDlyCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.insertBatchTbcMdGrDlyCause.001*/  \n");
			sql.append(" TBC_MD_GR_DLY_CAUSE (   \n");
			sql.append("        GR_DLY_CAUSE_CODE , \n");
			sql.append("        GR_DLY_CAUSE_NM , \n");
			sql.append("        REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO = (TbcMdGrDlyCauseDVO)tbcMdGrDlyCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseNm());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdGrDlyCauseDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return int[]
*/
	@LocalName("updateBatchTbcMdGrDlyCause")
	public int[] updateBatchTbcMdGrDlyCause (final List tbcMdGrDlyCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.updateBatchTbcMdGrDlyCause.001*/  \n");
			sql.append(" TBC_MD_GR_DLY_CAUSE \n");
			sql.append(" SET   \n");
			sql.append("        GR_DLY_CAUSE_NM = ? , \n");
			sql.append("        REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GR_DLY_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO = (TbcMdGrDlyCauseDVO)tbcMdGrDlyCauseDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseNm());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getReflYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getUseYn());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
						}
							public int getBatchSize() {
									return tbcMdGrDlyCauseDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdGrDlyCause Method
* 
* @ref_table TBC_MD_GR_DLY_CAUSE
* @return int[]
*/
	@LocalName("deleteBatchTbcMdGrDlyCause")
	public int[] deleteBatchTbcMdGrDlyCause (final List tbcMdGrDlyCauseDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdGrDlyCauseDEM.deleteBatchTbcMdGrDlyCause.001*/  \n");
			sql.append(" TBC_MD_GR_DLY_CAUSE \n");
			sql.append("  WHERE GR_DLY_CAUSE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdGrDlyCauseDVO tbcMdGrDlyCauseDVO = (TbcMdGrDlyCauseDVO)tbcMdGrDlyCauseDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdGrDlyCauseDVO.getGrDlyCauseCode());
						}
							public int getBatchSize() {
									return tbcMdGrDlyCauseDVOList.size();
							}
					}
		);			
	}

	
}