package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdPjtDVO extends AbstractVo {

	@Length(30) 
	private String pjtCode;

	@Length(30) 
	private String prodGrpCode;

	@Length(500) 
	private String pjtNm;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPjtCode() {
		this.pjtCode = super.getValue(0);
		return this.pjtCode;
	}

	public void setPjtCode(String pjtCode) {
        super.setValue(0, pjtCode);
		this.pjtCode = pjtCode;
	}
	
	public String getProdGrpCode() {
		this.prodGrpCode = super.getValue(1);
		return this.prodGrpCode;
	}

	public void setProdGrpCode(String prodGrpCode) {
        super.setValue(1, prodGrpCode);
		this.prodGrpCode = prodGrpCode;
	}
	
	public String getPjtNm() {
		this.pjtNm = super.getValue(2);
		return this.pjtNm;
	}

	public void setPjtNm(String pjtNm) {
        super.setValue(2, pjtNm);
		this.pjtNm = pjtNm;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(3);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(3, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(4);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(4, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(5);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(5, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(6);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(6, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(7);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(7, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}