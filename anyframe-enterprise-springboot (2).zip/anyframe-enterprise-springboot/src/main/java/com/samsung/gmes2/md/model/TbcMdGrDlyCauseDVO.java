package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbcMdGrDlyCauseDVO extends AbstractVo {

	@Length(30) 
	private String grDlyCauseCode;

	@Length(500) 
	private String grDlyCauseNm;

	@Length(1) 
	private String reflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getGrDlyCauseCode() {
		this.grDlyCauseCode = super.getValue(0);
		return this.grDlyCauseCode;
	}

	public void setGrDlyCauseCode(String grDlyCauseCode) {
        super.setValue(0, grDlyCauseCode);
		this.grDlyCauseCode = grDlyCauseCode;
	}
	
	public String getGrDlyCauseNm() {
		this.grDlyCauseNm = super.getValue(1);
		return this.grDlyCauseNm;
	}

	public void setGrDlyCauseNm(String grDlyCauseNm) {
        super.setValue(1, grDlyCauseNm);
		this.grDlyCauseNm = grDlyCauseNm;
	}
	
	public String getReflYn() {
		this.reflYn = super.getValue(2);
		return this.reflYn;
	}

	public void setReflYn(String reflYn) {
        super.setValue(2, reflYn);
		this.reflYn = reflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(3);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(3, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(4);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(4, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(5);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(5, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(6);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(6, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(7);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(7, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}