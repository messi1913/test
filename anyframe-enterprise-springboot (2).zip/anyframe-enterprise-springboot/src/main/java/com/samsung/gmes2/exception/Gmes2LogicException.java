package com.samsung.gmes2.exception;

import java.util.ArrayList;
import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.system.security.Gmes2SecurityExceptionCode;

@SuppressWarnings("serial")
public class Gmes2LogicException extends Gmes2Exception {
	public static final String CODE_EMPTY = "SM-E-0001";
	public static final String CODE_NOTFOUND = "SM-E-0004";
	public static final String CODE_FOUND = "SM-E-0005";
	public static final String CODE_NOTUNIQUE = "SM-E-0006";
	public static final String CODE_INVALIDDATA = "SM-E-0007";
	
	/**
	 * @deprecated replaced by Gmes2SecurityExceptionCode.AUTH_LOGIC
	 */
	@Deprecated
	public static final String CODE_SECURITY = Gmes2SecurityExceptionCode.AUTH_LOGIC;
	/**
	 * @deprecated replaced by Gmes2SecurityExceptionCode.AUTH_BAD_CREDENTIALS
	 */
	@Deprecated
	public static final String CODE_INVALID_PASSWORD = Gmes2SecurityExceptionCode.AUTH_BAD_CREDENTIALS;
	
	private String code;
	private List<Property> property;
	public Gmes2LogicException(String code) {
		this.code = code;
	}
	public Gmes2LogicException(String code, Property... property) {
		this(code);
		this.property = BaseUtil.toList(property);
	}
	public Gmes2LogicException(String code, String message) {
		super(message);
		this.code = code;
	}
	public Gmes2LogicException(String code, String message, Property... property) {
		this(code, message);
		this.property = BaseUtil.toList(property);
	}
	public Gmes2LogicException(String code, Throwable cause) {
		super(cause);
		this.code = code;
	}
	public Gmes2LogicException(String code, Throwable cause, Property... property) {
		this(code, cause);
		this.property = BaseUtil.toList(property);
	}
	public Gmes2LogicException(String code, String message, Throwable cause) {
		super(message, cause);
		this.code = code;
	}
	public Gmes2LogicException(String code, String message, Throwable cause, Property... property) {
		this(code, message, cause);
		this.property = BaseUtil.toList(property);
	}
	@Override
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<Property> getProperty() {
		return property;
	}
	public void setProperty(List<Property> property) {
		this.property = property;
	}
	public Property addProperty(Property property) {
		if (this.property == null)
			this.property = new ArrayList<Property>();
		this.property.add(property);
		return property;
	}
}
