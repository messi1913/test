package com.samsung.gmes2.md.loss.biz;

public class MdManageLossCauseBiz {

	/**
	 * 유실원인코드 목록 조회
	 */
	public void listLossCauseCode(){}

	/**
	 * 유실원인코드 목록 저장
	 */
	public void saveLossCauseCode(){}

}
