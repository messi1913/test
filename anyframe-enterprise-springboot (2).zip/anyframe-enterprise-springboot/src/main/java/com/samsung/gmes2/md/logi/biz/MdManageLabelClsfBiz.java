package com.samsung.gmes2.md.logi.biz;

public class MdManageLabelClsfBiz {

	/**
	 * 라벨분류코드 목록 조회
	 */
	public void listLabelClsf(){}

	/**
	 * 라벨분류코드 목록 저장
	 */
	public void saveLabelClsf(){}

}
