package com.samsung.gmes2.md.logi.app;

public class MDU842M01App {

	/**
	 * 선사 목록 초기설정
	 */
	public void initSorInfo(){}

	/**
	 * 선사 목록 조회
	 */
	public void listSorInfo(){}

	/**
	 * 선사 목록 엑셀 다운로드
	 */
	public void excelSorInfo(){}

	/**
	 * 선사 목록 저장
	 */
	public void saveSorInfo(){}

}
