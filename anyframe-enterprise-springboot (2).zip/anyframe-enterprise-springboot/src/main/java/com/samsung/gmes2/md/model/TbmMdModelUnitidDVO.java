package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdModelUnitidDVO extends AbstractVo {

	@Length(20) 
	private String modelCode;

	@Length(30) 
	private String matrCode;

	@Length(50) 
	private String unitid;

	@Length(30) 
	private String bomVer;

	@Length(11) @Scale(5) 
	private BigDecimal needQty;

	@Length(1) 
	private String ifYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getModelCode() {
		this.modelCode = super.getValue(0);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(0, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getMatrCode() {
		this.matrCode = super.getValue(1);
		return this.matrCode;
	}

	public void setMatrCode(String matrCode) {
        super.setValue(1, matrCode);
		this.matrCode = matrCode;
	}
	
	public String getUnitid() {
		this.unitid = super.getValue(2);
		return this.unitid;
	}

	public void setUnitid(String unitid) {
        super.setValue(2, unitid);
		this.unitid = unitid;
	}
	
	public String getBomVer() {
		this.bomVer = super.getValue(3);
		return this.bomVer;
	}

	public void setBomVer(String bomVer) {
        super.setValue(3, bomVer);
		this.bomVer = bomVer;
	}
	
	public BigDecimal getNeedQty() {
		this.needQty = super.getValue(4);
		return this.needQty;
	}

	public void setNeedQty(BigDecimal needQty) {
        super.setValue(4, needQty);
		this.needQty = needQty;
	}
	
	public String getIfYn() {
		this.ifYn = super.getValue(5);
		return this.ifYn;
	}

	public void setIfYn(String ifYn) {
        super.setValue(5, ifYn);
		this.ifYn = ifYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(6);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(6, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(7);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(7, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(8);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(8, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(9);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(9, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(10);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(10, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}