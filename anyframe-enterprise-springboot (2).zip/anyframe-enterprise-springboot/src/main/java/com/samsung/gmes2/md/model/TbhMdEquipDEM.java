package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MD_EQUIP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMdEquipDEM extends AbstractDAO {


/**
* insertTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return int
*/
	@LocalName("insertTbhMdEquip")
	public int insertTbhMdEquip (final TbhMdEquipDVO tbhMdEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdEquipDEM.insertTbhMdEquip.001*/  \n");
			sql.append(" TBH_MD_EQUIP (   \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        EQUIP_MODEL_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_TYPE_CODE , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbhMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbhMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbhMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdEquipDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMdEquip Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMdEquip Method")
	public int[][] updateBatchAllTbhMdEquip (final List  tbhMdEquipDVOList) {
		
		ArrayList updatetbhMdEquipDVOList = new ArrayList();
		ArrayList insertttbhMdEquipDVOList = new ArrayList();
		ArrayList deletetbhMdEquipDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMdEquipDVOList.size() ; i++) {
		  TbhMdEquipDVO tbhMdEquipDVO = (TbhMdEquipDVO) tbhMdEquipDVOList.get(i);
		  
		  if (tbhMdEquipDVO.getSqlAction().equals("C"))
		      insertttbhMdEquipDVOList.add(tbhMdEquipDVO);
		  else if (tbhMdEquipDVO.getSqlAction().equals("U"))
		      updatetbhMdEquipDVOList.add(tbhMdEquipDVO);
		  else if (tbhMdEquipDVO.getSqlAction().equals("D"))
		      deletetbhMdEquipDVOList.add(tbhMdEquipDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMdEquipDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMdEquip(insertttbhMdEquipDVOList);
          
      if (updatetbhMdEquipDVOList.size() >0)
          resultValues[1] = updateBatchTbhMdEquip(updatetbhMdEquipDVOList);
      
      if (deletetbhMdEquipDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMdEquip(deletetbhMdEquipDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return int
*/
	@LocalName("updateTbhMdEquip")
	public int updateTbhMdEquip (final TbhMdEquipDVO tbhMdEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdEquipDEM.updateTbhMdEquip.001*/  \n");
			sql.append(" TBH_MD_EQUIP \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_MODEL_NM = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        EQUIP_KIND_CODE = ? , \n");
			sql.append("        EQUIP_TYPE_CODE = ? , \n");
			sql.append("        EQUIP_SPEC_CONT = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE EQUIP_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbhMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbhMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbhMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdEquipDVO.getEvtNm());

							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return int
*/
	@LocalName("deleteTbhMdEquip")
	public int deleteTbhMdEquip (final TbhMdEquipDVO tbhMdEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdEquipDEM.deleteTbhMdEquip.001*/  \n");
			sql.append(" TBH_MD_EQUIP \n");
			sql.append("  WHERE EQUIP_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return TbhMdEquipDVO 
*/
	@LocalName("selectTbhMdEquip")
	public TbhMdEquipDVO selectTbhMdEquip (final TbhMdEquipDVO tbhMdEquipDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbhMdEquipDEM.selectTbhMdEquip.001*/  \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        EQUIP_MODEL_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_TYPE_CODE , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBH_MD_EQUIP \n");
			sql.append("  WHERE EQUIP_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbhMdEquipDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMdEquipDVO returnTbhMdEquipDVO = new TbhMdEquipDVO();
									returnTbhMdEquipDVO.setEquipCode(resultSet.getString("EQUIP_CODE"));
									returnTbhMdEquipDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbhMdEquipDVO.setEquipModelNm(resultSet.getString("EQUIP_MODEL_NM"));
									returnTbhMdEquipDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbhMdEquipDVO.setEquipKindCode(resultSet.getString("EQUIP_KIND_CODE"));
									returnTbhMdEquipDVO.setEquipTypeCode(resultSet.getString("EQUIP_TYPE_CODE"));
									returnTbhMdEquipDVO.setEquipSpecCont(resultSet.getString("EQUIP_SPEC_CONT"));
									returnTbhMdEquipDVO.setUnitCode(resultSet.getString("UNIT_CODE"));
									returnTbhMdEquipDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbhMdEquipDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbhMdEquipDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbhMdEquipDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbhMdEquipDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbhMdEquipDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbhMdEquipDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMdEquip Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMdEquip Method")
	public int mergeTbhMdEquip (final TbhMdEquipDVO tbhMdEquipDVO) {
		
		if ( selectTbhMdEquip (tbhMdEquipDVO) == null) {
			return insertTbhMdEquip(tbhMdEquipDVO);
		} else {
			return selectUpdateTbhMdEquip (tbhMdEquipDVO);
		}
	}

	/**
	 * selectUpdateTbhMdEquip Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMdEquip Method")
	public int selectUpdateTbhMdEquip (final TbhMdEquipDVO tbhMdEquipDVO) {
		
		TbhMdEquipDVO tmpTbhMdEquipDVO =  selectTbhMdEquip (tbhMdEquipDVO);
		if ( tbhMdEquipDVO.getEquipCode() != null && !"".equals(tbhMdEquipDVO.getEquipCode()) ) {
			tmpTbhMdEquipDVO.setEquipCode(tbhMdEquipDVO.getEquipCode());
		}		
		if ( tbhMdEquipDVO.getHistTsp() != null && !"".equals(tbhMdEquipDVO.getHistTsp()) ) {
			tmpTbhMdEquipDVO.setHistTsp(tbhMdEquipDVO.getHistTsp());
		}		
		if ( tbhMdEquipDVO.getEquipModelNm() != null && !"".equals(tbhMdEquipDVO.getEquipModelNm()) ) {
			tmpTbhMdEquipDVO.setEquipModelNm(tbhMdEquipDVO.getEquipModelNm());
		}		
		if ( tbhMdEquipDVO.getProcGubunCode() != null && !"".equals(tbhMdEquipDVO.getProcGubunCode()) ) {
			tmpTbhMdEquipDVO.setProcGubunCode(tbhMdEquipDVO.getProcGubunCode());
		}		
		if ( tbhMdEquipDVO.getEquipKindCode() != null && !"".equals(tbhMdEquipDVO.getEquipKindCode()) ) {
			tmpTbhMdEquipDVO.setEquipKindCode(tbhMdEquipDVO.getEquipKindCode());
		}		
		if ( tbhMdEquipDVO.getEquipTypeCode() != null && !"".equals(tbhMdEquipDVO.getEquipTypeCode()) ) {
			tmpTbhMdEquipDVO.setEquipTypeCode(tbhMdEquipDVO.getEquipTypeCode());
		}		
		if ( tbhMdEquipDVO.getEquipSpecCont() != null && !"".equals(tbhMdEquipDVO.getEquipSpecCont()) ) {
			tmpTbhMdEquipDVO.setEquipSpecCont(tbhMdEquipDVO.getEquipSpecCont());
		}		
		if ( tbhMdEquipDVO.getUnitCode() != null && !"".equals(tbhMdEquipDVO.getUnitCode()) ) {
			tmpTbhMdEquipDVO.setUnitCode(tbhMdEquipDVO.getUnitCode());
		}		
		if ( tbhMdEquipDVO.getUseYn() != null && !"".equals(tbhMdEquipDVO.getUseYn()) ) {
			tmpTbhMdEquipDVO.setUseYn(tbhMdEquipDVO.getUseYn());
		}		
		if ( tbhMdEquipDVO.getFstRegDt() != null && !"".equals(tbhMdEquipDVO.getFstRegDt()) ) {
			tmpTbhMdEquipDVO.setFstRegDt(tbhMdEquipDVO.getFstRegDt());
		}		
		if ( tbhMdEquipDVO.getFstRegerId() != null && !"".equals(tbhMdEquipDVO.getFstRegerId()) ) {
			tmpTbhMdEquipDVO.setFstRegerId(tbhMdEquipDVO.getFstRegerId());
		}		
		if ( tbhMdEquipDVO.getFnlUpdDt() != null && !"".equals(tbhMdEquipDVO.getFnlUpdDt()) ) {
			tmpTbhMdEquipDVO.setFnlUpdDt(tbhMdEquipDVO.getFnlUpdDt());
		}		
		if ( tbhMdEquipDVO.getFnlUpderId() != null && !"".equals(tbhMdEquipDVO.getFnlUpderId()) ) {
			tmpTbhMdEquipDVO.setFnlUpderId(tbhMdEquipDVO.getFnlUpderId());
		}		
		if ( tbhMdEquipDVO.getEvtNm() != null && !"".equals(tbhMdEquipDVO.getEvtNm()) ) {
			tmpTbhMdEquipDVO.setEvtNm(tbhMdEquipDVO.getEvtNm());
		}		
		return updateTbhMdEquip (tmpTbhMdEquipDVO);
	}

/**
* insertBatchTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return int[]
*/
	@LocalName("insertBatchTbhMdEquip")
	public int[] insertBatchTbhMdEquip (final List tbhMdEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbhMdEquipDEM.insertBatchTbhMdEquip.001*/  \n");
			sql.append(" TBH_MD_EQUIP (   \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        EQUIP_MODEL_NM , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        EQUIP_KIND_CODE , \n");
			sql.append("        EQUIP_TYPE_CODE , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        UNIT_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdEquipDVO tbhMdEquipDVO = (TbhMdEquipDVO)tbhMdEquipDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbhMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbhMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbhMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdEquipDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbhMdEquipDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return int[]
*/
	@LocalName("updateBatchTbhMdEquip")
	public int[] updateBatchTbhMdEquip (final List tbhMdEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbhMdEquipDEM.updateBatchTbhMdEquip.001*/  \n");
			sql.append(" TBH_MD_EQUIP \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_MODEL_NM = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        EQUIP_KIND_CODE = ? , \n");
			sql.append("        EQUIP_TYPE_CODE = ? , \n");
			sql.append("        EQUIP_SPEC_CONT = ? , \n");
			sql.append("        UNIT_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE EQUIP_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdEquipDVO tbhMdEquipDVO = (TbhMdEquipDVO)tbhMdEquipDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMdEquipDVO.getEquipModelNm());
							ps.setString(psCount++, tbhMdEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipKindCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipTypeCode());
							ps.setString(psCount++, tbhMdEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbhMdEquipDVO.getUnitCode());
							ps.setString(psCount++, tbhMdEquipDVO.getUseYn());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbhMdEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbhMdEquipDVO.getEvtNm());

							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdEquipDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMdEquip Method
* 
* @ref_table TBH_MD_EQUIP
* @return int[]
*/
	@LocalName("deleteBatchTbhMdEquip")
	public int[] deleteBatchTbhMdEquip (final List tbhMdEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbhMdEquipDEM.deleteBatchTbhMdEquip.001*/  \n");
			sql.append(" TBH_MD_EQUIP \n");
			sql.append("  WHERE EQUIP_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMdEquipDVO tbhMdEquipDVO = (TbhMdEquipDVO)tbhMdEquipDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMdEquipDVO.getEquipCode());
							ps.setString(psCount++, tbhMdEquipDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbhMdEquipDVOList.size();
							}
					}
		);			
	}

	
}