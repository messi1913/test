package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbhMcOiRelsDVO extends AbstractDVO {

	@Length(20) @NotNull
	private String plantCode;

	@Length(20) @NotNull
	private String divCode;

	@Length(50) @NotNull
	private String revNo;

	@Length(50) @NotNull
	private String pgmCode;

	@Length(14) 
	private String relsDt;

	@Length(1000) 
	private String relsHistDesc;


	public String getPlantCode() {
		this.plantCode = super.getValue("plantCode");
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue("plantCode", plantCode);
		this.plantCode = plantCode;
	}
	
	public String getDivCode() {
		this.divCode = super.getValue("divCode");
		return this.divCode;
	}

	public void setDivCode(String divCode) {
        super.setValue("divCode", divCode);
		this.divCode = divCode;
	}
	
	public String getRevNo() {
		this.revNo = super.getValue("revNo");
		return this.revNo;
	}

	public void setRevNo(String revNo) {
        super.setValue("revNo", revNo);
		this.revNo = revNo;
	}
	
	public String getPgmCode() {
		this.pgmCode = super.getValue("pgmCode");
		return this.pgmCode;
	}

	public void setPgmCode(String pgmCode) {
        super.setValue("pgmCode", pgmCode);
		this.pgmCode = pgmCode;
	}
	
	public String getRelsDt() {
		this.relsDt = super.getValue("relsDt");
		return this.relsDt;
	}

	public void setRelsDt(String relsDt) {
        super.setValue("relsDt", relsDt);
		this.relsDt = relsDt;
	}
	
	public String getRelsHistDesc() {
		this.relsHistDesc = super.getValue("relsHistDesc");
		return this.relsHistDesc;
	}

	public void setRelsHistDesc(String relsHistDesc) {
        super.setValue("relsHistDesc", relsHistDesc);
		this.relsHistDesc = relsHistDesc;
	}
	
}