package com.samsung.gmes2.md.loss.app;

public class MDU421M01App {

	/**
	 * 유실유형코드 목록 초기설정
	 */
	public void initLossTypeCode(){}

	/**
	 * 유실유형코드 목록 조회
	 */
	public void listLossTypeCode(){}

	/**
	 * 유실유형코드 목록 엑셀 다운로드
	 */
	public void excelLossTypeCode(){}

	/**
	 * 유실유형코드 목록 저장
	 */
	public void saveLossTypeCode(){}

}
