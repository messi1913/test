package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_OPTN_MODEL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdOptnModelDEM extends AbstractDAO {


/**
* insertTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return int
*/
	@LocalName("insertTbmMdOptnModel")
	public int insertTbmMdOptnModel (final TbmMdOptnModelDVO tbmMdOptnModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.insertTbmMdOptnModel.001*/  \n");
			sql.append(" TBM_MD_OPTN_MODEL (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        OPTN_MODEL_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getOptnModelDesc());
							ps.setString(psCount++, tbmMdOptnModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdOptnModel Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdOptnModel Method")
	public int[][] updateBatchAllTbmMdOptnModel (final List  tbmMdOptnModelDVOList) {
		
		ArrayList updatetbmMdOptnModelDVOList = new ArrayList();
		ArrayList insertttbmMdOptnModelDVOList = new ArrayList();
		ArrayList deletetbmMdOptnModelDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdOptnModelDVOList.size() ; i++) {
		  TbmMdOptnModelDVO tbmMdOptnModelDVO = (TbmMdOptnModelDVO) tbmMdOptnModelDVOList.get(i);
		  
		  if (tbmMdOptnModelDVO.getSqlAction().equals("C"))
		      insertttbmMdOptnModelDVOList.add(tbmMdOptnModelDVO);
		  else if (tbmMdOptnModelDVO.getSqlAction().equals("U"))
		      updatetbmMdOptnModelDVOList.add(tbmMdOptnModelDVO);
		  else if (tbmMdOptnModelDVO.getSqlAction().equals("D"))
		      deletetbmMdOptnModelDVOList.add(tbmMdOptnModelDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdOptnModelDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdOptnModel(insertttbmMdOptnModelDVOList);
          
      if (updatetbmMdOptnModelDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdOptnModel(updatetbmMdOptnModelDVOList);
      
      if (deletetbmMdOptnModelDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdOptnModel(deletetbmMdOptnModelDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return int
*/
	@LocalName("updateTbmMdOptnModel")
	public int updateTbmMdOptnModel (final TbmMdOptnModelDVO tbmMdOptnModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.updateTbmMdOptnModel.001*/  \n");
			sql.append(" TBM_MD_OPTN_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        OPTN_MODEL_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdOptnModelDVO.getOptnModelDesc());
							ps.setString(psCount++, tbmMdOptnModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
						}
					}
		);			
	}

/**
* deleteTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return int
*/
	@LocalName("deleteTbmMdOptnModel")
	public int deleteTbmMdOptnModel (final TbmMdOptnModelDVO tbmMdOptnModelDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.deleteTbmMdOptnModel.001*/  \n");
			sql.append(" TBM_MD_OPTN_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
						}
					}
		);			
	}

/**
* selectTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return TbmMdOptnModelDVO 
*/
	@LocalName("selectTbmMdOptnModel")
	public TbmMdOptnModelDVO selectTbmMdOptnModel (final TbmMdOptnModelDVO tbmMdOptnModelDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.selectTbmMdOptnModel.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        OPTN_MODEL_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_OPTN_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return (TbmMdOptnModelDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdOptnModelDVO returnTbmMdOptnModelDVO = new TbmMdOptnModelDVO();
									returnTbmMdOptnModelDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdOptnModelDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdOptnModelDVO.setOptnModelDesc(resultSet.getString("OPTN_MODEL_DESC"));
									returnTbmMdOptnModelDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdOptnModelDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdOptnModelDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdOptnModelDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdOptnModelDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdOptnModelDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdOptnModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdOptnModel Method")
	public int mergeTbmMdOptnModel (final TbmMdOptnModelDVO tbmMdOptnModelDVO) {
		
		if ( selectTbmMdOptnModel (tbmMdOptnModelDVO) == null) {
			return insertTbmMdOptnModel(tbmMdOptnModelDVO);
		} else {
			return selectUpdateTbmMdOptnModel (tbmMdOptnModelDVO);
		}
	}

	/**
	 * selectUpdateTbmMdOptnModel Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdOptnModel Method")
	public int selectUpdateTbmMdOptnModel (final TbmMdOptnModelDVO tbmMdOptnModelDVO) {
		
		TbmMdOptnModelDVO tmpTbmMdOptnModelDVO =  selectTbmMdOptnModel (tbmMdOptnModelDVO);
		if ( tbmMdOptnModelDVO.getPlantCode() != null && !"".equals(tbmMdOptnModelDVO.getPlantCode()) ) {
			tmpTbmMdOptnModelDVO.setPlantCode(tbmMdOptnModelDVO.getPlantCode());
		}		
		if ( tbmMdOptnModelDVO.getModelCode() != null && !"".equals(tbmMdOptnModelDVO.getModelCode()) ) {
			tmpTbmMdOptnModelDVO.setModelCode(tbmMdOptnModelDVO.getModelCode());
		}		
		if ( tbmMdOptnModelDVO.getOptnModelDesc() != null && !"".equals(tbmMdOptnModelDVO.getOptnModelDesc()) ) {
			tmpTbmMdOptnModelDVO.setOptnModelDesc(tbmMdOptnModelDVO.getOptnModelDesc());
		}		
		if ( tbmMdOptnModelDVO.getUseYn() != null && !"".equals(tbmMdOptnModelDVO.getUseYn()) ) {
			tmpTbmMdOptnModelDVO.setUseYn(tbmMdOptnModelDVO.getUseYn());
		}		
		if ( tbmMdOptnModelDVO.getFstRegDt() != null && !"".equals(tbmMdOptnModelDVO.getFstRegDt()) ) {
			tmpTbmMdOptnModelDVO.setFstRegDt(tbmMdOptnModelDVO.getFstRegDt());
		}		
		if ( tbmMdOptnModelDVO.getFstRegerId() != null && !"".equals(tbmMdOptnModelDVO.getFstRegerId()) ) {
			tmpTbmMdOptnModelDVO.setFstRegerId(tbmMdOptnModelDVO.getFstRegerId());
		}		
		if ( tbmMdOptnModelDVO.getFnlUpdDt() != null && !"".equals(tbmMdOptnModelDVO.getFnlUpdDt()) ) {
			tmpTbmMdOptnModelDVO.setFnlUpdDt(tbmMdOptnModelDVO.getFnlUpdDt());
		}		
		if ( tbmMdOptnModelDVO.getFnlUpderId() != null && !"".equals(tbmMdOptnModelDVO.getFnlUpderId()) ) {
			tmpTbmMdOptnModelDVO.setFnlUpderId(tbmMdOptnModelDVO.getFnlUpderId());
		}		
		return updateTbmMdOptnModel (tmpTbmMdOptnModelDVO);
	}

/**
* insertBatchTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return int[]
*/
	@LocalName("insertBatchTbmMdOptnModel")
	public int[] insertBatchTbmMdOptnModel (final List tbmMdOptnModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.insertBatchTbmMdOptnModel.001*/  \n");
			sql.append(" TBM_MD_OPTN_MODEL (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        OPTN_MODEL_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdOptnModelDVO tbmMdOptnModelDVO = (TbmMdOptnModelDVO)tbmMdOptnModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getOptnModelDesc());
							ps.setString(psCount++, tbmMdOptnModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdOptnModelDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return int[]
*/
	@LocalName("updateBatchTbmMdOptnModel")
	public int[] updateBatchTbmMdOptnModel (final List tbmMdOptnModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.updateBatchTbmMdOptnModel.001*/  \n");
			sql.append(" TBM_MD_OPTN_MODEL \n");
			sql.append(" SET   \n");
			sql.append("        OPTN_MODEL_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdOptnModelDVO tbmMdOptnModelDVO = (TbmMdOptnModelDVO)tbmMdOptnModelDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdOptnModelDVO.getOptnModelDesc());
							ps.setString(psCount++, tbmMdOptnModelDVO.getUseYn());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdOptnModelDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdOptnModelDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdOptnModel Method
* 
* @ref_table TBM_MD_OPTN_MODEL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdOptnModel")
	public int[] deleteBatchTbmMdOptnModel (final List tbmMdOptnModelDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdOptnModelDEM.deleteBatchTbmMdOptnModel.001*/  \n");
			sql.append(" TBM_MD_OPTN_MODEL \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdOptnModelDVO tbmMdOptnModelDVO = (TbmMdOptnModelDVO)tbmMdOptnModelDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdOptnModelDVO.getPlantCode());
							ps.setString(psCount++, tbmMdOptnModelDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdOptnModelDVOList.size();
							}
					}
		);			
	}

	
}