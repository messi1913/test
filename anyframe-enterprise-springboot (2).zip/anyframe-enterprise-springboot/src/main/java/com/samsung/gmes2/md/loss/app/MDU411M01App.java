package com.samsung.gmes2.md.loss.app;

public class MDU411M01App {

	/**
	 * 이탈분류코드 목록 초기설정
	 */
	public void initDeviClsfCode(){}

	/**
	 * 이탈분류코드 목록 조회
	 */
	public void listDeviClsfCode(){}

	/**
	 * 이탈분류코드 목록 엑셀 다운로드
	 */
	public void excelDeviClsfCode(){}

	/**
	 * 이탈분류코드 목록 저장
	 */
	public void saveDeviClsfCode(){}

}
