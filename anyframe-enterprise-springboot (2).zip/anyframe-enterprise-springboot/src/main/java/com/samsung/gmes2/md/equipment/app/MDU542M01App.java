package com.samsung.gmes2.md.equipment.app;

public class MDU542M01App {

	/**
	 * 금형정보 목록 초기설정
	 */
	public void initMoldInfo(){}

	/**
	 * 금형정보 목록 조회
	 */
	public void listMoldInfo(){}

	/**
	 * 금형정보 목록 엑셀 다운로드
	 */
	public void excelMoldInfo(){}

}
