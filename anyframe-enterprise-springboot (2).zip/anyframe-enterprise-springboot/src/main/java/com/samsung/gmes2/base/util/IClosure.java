package com.samsung.gmes2.base.util;

public interface IClosure
{
    public Object execute( Object... param ) throws Exception;
}
