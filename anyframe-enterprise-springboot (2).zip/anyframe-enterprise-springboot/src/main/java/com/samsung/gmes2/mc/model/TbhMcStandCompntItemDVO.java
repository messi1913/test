package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Scale;
import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;
import java.math.BigDecimal;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbhMcStandCompntItemDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String revNo;

	@Length(50) @NotNull
	private String standCompntCode;

	@Length(50) @NotNull
	private String itemNo;

	@Length(1000) 
	private String labelCont;

	@Length(11) @Scale(5) 
	private BigDecimal xValue;

	@Length(11) @Scale(5) 
	private BigDecimal yValue;

	@Length(11) @Scale(5) 
	private BigDecimal itemLeng;

	@Length(11) @Scale(5) 
	private BigDecimal itemHeit;

	@Length(500) 
	private String fontNm;

	@Length(11) @Scale(5) 
	private BigDecimal fontValue;

	@Length(11) @Scale(5) 
	private BigDecimal frclorValue;

	@Length(11) @Scale(5) 
	private BigDecimal bckclorValue;


	public String getRevNo() {
		this.revNo = super.getValue("revNo");
		return this.revNo;
	}

	public void setRevNo(String revNo) {
        super.setValue("revNo", revNo);
		this.revNo = revNo;
	}
	
	public String getStandCompntCode() {
		this.standCompntCode = super.getValue("standCompntCode");
		return this.standCompntCode;
	}

	public void setStandCompntCode(String standCompntCode) {
        super.setValue("standCompntCode", standCompntCode);
		this.standCompntCode = standCompntCode;
	}
	
	public String getItemNo() {
		this.itemNo = super.getValue("itemNo");
		return this.itemNo;
	}

	public void setItemNo(String itemNo) {
        super.setValue("itemNo", itemNo);
		this.itemNo = itemNo;
	}
	
	public String getLabelCont() {
		this.labelCont = super.getValue("labelCont");
		return this.labelCont;
	}

	public void setLabelCont(String labelCont) {
        super.setValue("labelCont", labelCont);
		this.labelCont = labelCont;
	}
	
	public BigDecimal getxValue() {
		this.xValue = super.getValue("xValue");
		return this.xValue;
	}

	public void setxValue(BigDecimal xValue) {
        super.setValue("xValue", xValue);
		this.xValue = xValue;
	}
	
	public BigDecimal getyValue() {
		this.yValue = super.getValue("yValue");
		return this.yValue;
	}

	public void setyValue(BigDecimal yValue) {
        super.setValue("yValue", yValue);
		this.yValue = yValue;
	}
	
	public BigDecimal getItemLeng() {
		this.itemLeng = super.getValue("itemLeng");
		return this.itemLeng;
	}

	public void setItemLeng(BigDecimal itemLeng) {
        super.setValue("itemLeng", itemLeng);
		this.itemLeng = itemLeng;
	}
	
	public BigDecimal getItemHeit() {
		this.itemHeit = super.getValue("itemHeit");
		return this.itemHeit;
	}

	public void setItemHeit(BigDecimal itemHeit) {
        super.setValue("itemHeit", itemHeit);
		this.itemHeit = itemHeit;
	}
	
	public String getFontNm() {
		this.fontNm = super.getValue("fontNm");
		return this.fontNm;
	}

	public void setFontNm(String fontNm) {
        super.setValue("fontNm", fontNm);
		this.fontNm = fontNm;
	}
	
	public BigDecimal getFontValue() {
		this.fontValue = super.getValue("fontValue");
		return this.fontValue;
	}

	public void setFontValue(BigDecimal fontValue) {
        super.setValue("fontValue", fontValue);
		this.fontValue = fontValue;
	}
	
	public BigDecimal getFrclorValue() {
		this.frclorValue = super.getValue("frclorValue");
		return this.frclorValue;
	}

	public void setFrclorValue(BigDecimal frclorValue) {
        super.setValue("frclorValue", frclorValue);
		this.frclorValue = frclorValue;
	}
	
	public BigDecimal getBckclorValue() {
		this.bckclorValue = super.getValue("bckclorValue");
		return this.bckclorValue;
	}

	public void setBckclorValue(BigDecimal bckclorValue) {
        super.setValue("bckclorValue", bckclorValue);
		this.bckclorValue = bckclorValue;
	}
	
}