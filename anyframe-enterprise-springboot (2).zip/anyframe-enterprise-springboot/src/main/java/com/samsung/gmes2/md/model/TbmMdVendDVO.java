package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author KYJ
 */
public class TbmMdVendDVO extends AbstractDVO {

	@Length(20) @NotNull
	private String plantCode;

	@Length(30) @NotNull
	private String vendCode;

	@Length(30) @NotNull
	private String vendGubunCode;

	@Length(500) 
	private String vendNm;

	@Length(30) 
	private String vendCtracCode;

	@Length(1000) 
	private String vendAddr;

	@Length(500) 
	private String dlgrNm;

	@Length(50) 
	private String contctNo;

	@Length(30) 
	private String vendTypeCode;

	@Length(30) 
	private String prodGubunCode;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue("plantCode");
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue("plantCode", plantCode);
		this.plantCode = plantCode;
	}
	
	public String getVendCode() {
		this.vendCode = super.getValue("vendCode");
		return this.vendCode;
	}

	public void setVendCode(String vendCode) {
        super.setValue("vendCode", vendCode);
		this.vendCode = vendCode;
	}
	
	public String getVendGubunCode() {
		this.vendGubunCode = super.getValue("vendGubunCode");
		return this.vendGubunCode;
	}

	public void setVendGubunCode(String vendGubunCode) {
        super.setValue("vendGubunCode", vendGubunCode);
		this.vendGubunCode = vendGubunCode;
	}
	
	public String getVendNm() {
		this.vendNm = super.getValue("vendNm");
		return this.vendNm;
	}

	public void setVendNm(String vendNm) {
        super.setValue("vendNm", vendNm);
		this.vendNm = vendNm;
	}
	
	public String getVendCtracCode() {
		this.vendCtracCode = super.getValue("vendCtracCode");
		return this.vendCtracCode;
	}

	public void setVendCtracCode(String vendCtracCode) {
        super.setValue("vendCtracCode", vendCtracCode);
		this.vendCtracCode = vendCtracCode;
	}
	
	public String getVendAddr() {
		this.vendAddr = super.getValue("vendAddr");
		return this.vendAddr;
	}

	public void setVendAddr(String vendAddr) {
        super.setValue("vendAddr", vendAddr);
		this.vendAddr = vendAddr;
	}
	
	public String getDlgrNm() {
		this.dlgrNm = super.getValue("dlgrNm");
		return this.dlgrNm;
	}

	public void setDlgrNm(String dlgrNm) {
        super.setValue("dlgrNm", dlgrNm);
		this.dlgrNm = dlgrNm;
	}
	
	public String getContctNo() {
		this.contctNo = super.getValue("contctNo");
		return this.contctNo;
	}

	public void setContctNo(String contctNo) {
        super.setValue("contctNo", contctNo);
		this.contctNo = contctNo;
	}
	
	public String getVendTypeCode() {
		this.vendTypeCode = super.getValue("vendTypeCode");
		return this.vendTypeCode;
	}

	public void setVendTypeCode(String vendTypeCode) {
        super.setValue("vendTypeCode", vendTypeCode);
		this.vendTypeCode = vendTypeCode;
	}
	
	public String getProdGubunCode() {
		this.prodGubunCode = super.getValue("prodGubunCode");
		return this.prodGubunCode;
	}

	public void setProdGubunCode(String prodGubunCode) {
        super.setValue("prodGubunCode", prodGubunCode);
		this.prodGubunCode = prodGubunCode;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}