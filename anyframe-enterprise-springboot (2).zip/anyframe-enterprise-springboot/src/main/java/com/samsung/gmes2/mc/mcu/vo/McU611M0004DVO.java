package com.samsung.gmes2.mc.mcu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 한글명 : 모델라벨 조회
 * 작성일 : 2011.06.29
 * 작성자 : 심 재 국
 * 작업상태 : 완료
 * 개요 :
 * 조회 의 값을 List 가진 DVO
 * @stereotype DAOVO
 * @author shim
 */
@LocalName("조회 값")
public class McU611M0004DVO extends AbstractDVO {

	@LocalName("모델 코드") @Length(30) 
	private String modelCode;

	@LocalName("라벨유형") @Length(30) 
	private String comCode;

	@LocalName("조회 시작일") @Length(10) 
	private String startDay;

	@LocalName("조회 끝나는 일") @Length(10) 
	private String endDay;

	@LocalName("상태") @Length(50) 
	private String statusCode;


	/**
	 * 모델 코드 Getter Method
	 * 
	 * @return 모델 코드
	 */
	@LocalName("모델 코드 Getter Method")
	public String getModelCode() {
		this.modelCode = super.getValue("modelCode");
		return this.modelCode;
	}

	/**
	 * 모델 코드 Setter Method
	 * 
	 * @param String 모델 코드
	 */
	@LocalName("모델 코드 Setter Method")
	public void setModelCode(String modelCode) {
        super.setValue("modelCode", modelCode);
		this.modelCode = modelCode;
	}
	
	/**
	 * 라벨유형 Getter Method
	 * 
	 * @return 라벨유형
	 */
	@LocalName("라벨유형 Getter Method")
	public String getComCode() {
		this.comCode = super.getValue("comCode");
		return this.comCode;
	}

	/**
	 * 라벨유형 Setter Method
	 * 
	 * @param String 라벨유형
	 */
	@LocalName("라벨유형 Setter Method")
	public void setComCode(String comCode) {
        super.setValue("comCode", comCode);
		this.comCode = comCode;
	}
	
	/**
	 * 조회 시작일 Getter Method
	 * 
	 * @return 조회 시작일
	 */
	@LocalName("조회 시작일 Getter Method")
	public String getStartDay() {
		this.startDay = super.getValue("startDay");
		return this.startDay;
	}

	/**
	 * 조회 시작일 Setter Method
	 * 
	 * @param String 조회 시작일
	 */
	@LocalName("조회 시작일 Setter Method")
	public void setStartDay(String startDay) {
        super.setValue("startDay", startDay);
		this.startDay = startDay;
	}
	
	/**
	 * 조회 끝나는 일 Getter Method
	 * 
	 * @return 조회 끝나는 일
	 */
	@LocalName("조회 끝나는 일 Getter Method")
	public String getEndDay() {
		this.endDay = super.getValue("endDay");
		return this.endDay;
	}

	/**
	 * 조회 끝나는 일 Setter Method
	 * 
	 * @param String 조회 끝나는 일
	 */
	@LocalName("조회 끝나는 일 Setter Method")
	public void setEndDay(String endDay) {
        super.setValue("endDay", endDay);
		this.endDay = endDay;
	}
	
	/**
	 * 상태 Getter Method
	 * 
	 * @return 상태
	 */
	@LocalName("상태 Getter Method")
	public String getStatusCode() {
		this.statusCode = super.getValue("statusCode");
		return this.statusCode;
	}

	/**
	 * 상태 Setter Method
	 * 
	 * @param String 상태
	 */
	@LocalName("상태 Setter Method")
	public void setStatusCode(String statusCode) {
        super.setValue("statusCode", statusCode);
		this.statusCode = statusCode;
	}
	
}