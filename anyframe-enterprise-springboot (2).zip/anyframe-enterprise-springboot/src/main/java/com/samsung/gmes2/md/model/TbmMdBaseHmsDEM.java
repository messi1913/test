package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_BASE_HMS
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdBaseHmsDEM extends AbstractDAO {


/**
* insertTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return int
*/
	@LocalName("insertTbmMdBaseHms")
	public int insertTbmMdBaseHms (final TbmMdBaseHmsDVO tbmMdBaseHmsDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.insertTbmMdBaseHms.001*/  \n");
			sql.append(" TBM_MD_BASE_HMS (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        APLY_START_DT , \n");
			sql.append("        APLY_FIN_DT , \n");
			sql.append("        MONT_STOP_APLY_SSOP , \n");
			sql.append("        LINE_STOP_APLY_SSOP , \n");
			sql.append("        ATST_PRODC_NUM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyFinDt());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getMontStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getLineStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getAtstProdcNum());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getUseYn());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdBaseHms Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdBaseHms Method")
	public int[][] updateBatchAllTbmMdBaseHms (final List  tbmMdBaseHmsDVOList) {
		
		ArrayList updatetbmMdBaseHmsDVOList = new ArrayList();
		ArrayList insertttbmMdBaseHmsDVOList = new ArrayList();
		ArrayList deletetbmMdBaseHmsDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdBaseHmsDVOList.size() ; i++) {
		  TbmMdBaseHmsDVO tbmMdBaseHmsDVO = (TbmMdBaseHmsDVO) tbmMdBaseHmsDVOList.get(i);
		  
		  if (tbmMdBaseHmsDVO.getSqlAction().equals("C"))
		      insertttbmMdBaseHmsDVOList.add(tbmMdBaseHmsDVO);
		  else if (tbmMdBaseHmsDVO.getSqlAction().equals("U"))
		      updatetbmMdBaseHmsDVOList.add(tbmMdBaseHmsDVO);
		  else if (tbmMdBaseHmsDVO.getSqlAction().equals("D"))
		      deletetbmMdBaseHmsDVOList.add(tbmMdBaseHmsDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdBaseHmsDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdBaseHms(insertttbmMdBaseHmsDVOList);
          
      if (updatetbmMdBaseHmsDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdBaseHms(updatetbmMdBaseHmsDVOList);
      
      if (deletetbmMdBaseHmsDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdBaseHms(deletetbmMdBaseHmsDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return int
*/
	@LocalName("updateTbmMdBaseHms")
	public int updateTbmMdBaseHms (final TbmMdBaseHmsDVO tbmMdBaseHmsDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.updateTbmMdBaseHms.001*/  \n");
			sql.append(" TBM_MD_BASE_HMS \n");
			sql.append(" SET   \n");
			sql.append("        APLY_FIN_DT = ? , \n");
			sql.append("        MONT_STOP_APLY_SSOP = ? , \n");
			sql.append("        LINE_STOP_APLY_SSOP = ? , \n");
			sql.append("        ATST_PRODC_NUM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND MFG_PART_CODE = ? \n");
			sql.append("   AND APLY_START_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyFinDt());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getMontStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getLineStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getAtstProdcNum());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getUseYn());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
						}
					}
		);			
	}

/**
* deleteTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return int
*/
	@LocalName("deleteTbmMdBaseHms")
	public int deleteTbmMdBaseHms (final TbmMdBaseHmsDVO tbmMdBaseHmsDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.deleteTbmMdBaseHms.001*/  \n");
			sql.append(" TBM_MD_BASE_HMS \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");
			sql.append("    AND APLY_START_DT = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
						}
					}
		);			
	}

/**
* selectTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return TbmMdBaseHmsDVO 
*/
	@LocalName("selectTbmMdBaseHms")
	public TbmMdBaseHmsDVO selectTbmMdBaseHms (final TbmMdBaseHmsDVO tbmMdBaseHmsDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.selectTbmMdBaseHms.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        APLY_START_DT , \n");
			sql.append("        APLY_FIN_DT , \n");
			sql.append("        MONT_STOP_APLY_SSOP , \n");
			sql.append("        LINE_STOP_APLY_SSOP , \n");
			sql.append("        ATST_PRODC_NUM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_BASE_HMS \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");
			sql.append("    AND APLY_START_DT = ? \n");

		return (TbmMdBaseHmsDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdBaseHmsDVO returnTbmMdBaseHmsDVO = new TbmMdBaseHmsDVO();
									returnTbmMdBaseHmsDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdBaseHmsDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdBaseHmsDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdBaseHmsDVO.setAplyStartDt(resultSet.getString("APLY_START_DT"));
									returnTbmMdBaseHmsDVO.setAplyFinDt(resultSet.getString("APLY_FIN_DT"));
									returnTbmMdBaseHmsDVO.setMontStopAplySsop(resultSet.getBigDecimal("MONT_STOP_APLY_SSOP"));
									returnTbmMdBaseHmsDVO.setLineStopAplySsop(resultSet.getBigDecimal("LINE_STOP_APLY_SSOP"));
									returnTbmMdBaseHmsDVO.setAtstProdcNum(resultSet.getBigDecimal("ATST_PRODC_NUM"));
									returnTbmMdBaseHmsDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdBaseHmsDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdBaseHmsDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdBaseHmsDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdBaseHmsDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdBaseHmsDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdBaseHms Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdBaseHms Method")
	public int mergeTbmMdBaseHms (final TbmMdBaseHmsDVO tbmMdBaseHmsDVO) {
		
		if ( selectTbmMdBaseHms (tbmMdBaseHmsDVO) == null) {
			return insertTbmMdBaseHms(tbmMdBaseHmsDVO);
		} else {
			return selectUpdateTbmMdBaseHms (tbmMdBaseHmsDVO);
		}
	}

	/**
	 * selectUpdateTbmMdBaseHms Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdBaseHms Method")
	public int selectUpdateTbmMdBaseHms (final TbmMdBaseHmsDVO tbmMdBaseHmsDVO) {
		
		TbmMdBaseHmsDVO tmpTbmMdBaseHmsDVO =  selectTbmMdBaseHms (tbmMdBaseHmsDVO);
		if ( tbmMdBaseHmsDVO.getFctCode() != null && !"".equals(tbmMdBaseHmsDVO.getFctCode()) ) {
			tmpTbmMdBaseHmsDVO.setFctCode(tbmMdBaseHmsDVO.getFctCode());
		}		
		if ( tbmMdBaseHmsDVO.getLineCode() != null && !"".equals(tbmMdBaseHmsDVO.getLineCode()) ) {
			tmpTbmMdBaseHmsDVO.setLineCode(tbmMdBaseHmsDVO.getLineCode());
		}		
		if ( tbmMdBaseHmsDVO.getMfgPartCode() != null && !"".equals(tbmMdBaseHmsDVO.getMfgPartCode()) ) {
			tmpTbmMdBaseHmsDVO.setMfgPartCode(tbmMdBaseHmsDVO.getMfgPartCode());
		}		
		if ( tbmMdBaseHmsDVO.getAplyStartDt() != null && !"".equals(tbmMdBaseHmsDVO.getAplyStartDt()) ) {
			tmpTbmMdBaseHmsDVO.setAplyStartDt(tbmMdBaseHmsDVO.getAplyStartDt());
		}		
		if ( tbmMdBaseHmsDVO.getAplyFinDt() != null && !"".equals(tbmMdBaseHmsDVO.getAplyFinDt()) ) {
			tmpTbmMdBaseHmsDVO.setAplyFinDt(tbmMdBaseHmsDVO.getAplyFinDt());
		}		
		if ( tbmMdBaseHmsDVO.getMontStopAplySsop() != null && !"".equals(tbmMdBaseHmsDVO.getMontStopAplySsop()) ) {
			tmpTbmMdBaseHmsDVO.setMontStopAplySsop(tbmMdBaseHmsDVO.getMontStopAplySsop());
		}		
		if ( tbmMdBaseHmsDVO.getLineStopAplySsop() != null && !"".equals(tbmMdBaseHmsDVO.getLineStopAplySsop()) ) {
			tmpTbmMdBaseHmsDVO.setLineStopAplySsop(tbmMdBaseHmsDVO.getLineStopAplySsop());
		}		
		if ( tbmMdBaseHmsDVO.getAtstProdcNum() != null && !"".equals(tbmMdBaseHmsDVO.getAtstProdcNum()) ) {
			tmpTbmMdBaseHmsDVO.setAtstProdcNum(tbmMdBaseHmsDVO.getAtstProdcNum());
		}		
		if ( tbmMdBaseHmsDVO.getUseYn() != null && !"".equals(tbmMdBaseHmsDVO.getUseYn()) ) {
			tmpTbmMdBaseHmsDVO.setUseYn(tbmMdBaseHmsDVO.getUseYn());
		}		
		if ( tbmMdBaseHmsDVO.getFstRegDt() != null && !"".equals(tbmMdBaseHmsDVO.getFstRegDt()) ) {
			tmpTbmMdBaseHmsDVO.setFstRegDt(tbmMdBaseHmsDVO.getFstRegDt());
		}		
		if ( tbmMdBaseHmsDVO.getFstRegerId() != null && !"".equals(tbmMdBaseHmsDVO.getFstRegerId()) ) {
			tmpTbmMdBaseHmsDVO.setFstRegerId(tbmMdBaseHmsDVO.getFstRegerId());
		}		
		if ( tbmMdBaseHmsDVO.getFnlUpdDt() != null && !"".equals(tbmMdBaseHmsDVO.getFnlUpdDt()) ) {
			tmpTbmMdBaseHmsDVO.setFnlUpdDt(tbmMdBaseHmsDVO.getFnlUpdDt());
		}		
		if ( tbmMdBaseHmsDVO.getFnlUpderId() != null && !"".equals(tbmMdBaseHmsDVO.getFnlUpderId()) ) {
			tmpTbmMdBaseHmsDVO.setFnlUpderId(tbmMdBaseHmsDVO.getFnlUpderId());
		}		
		return updateTbmMdBaseHms (tmpTbmMdBaseHmsDVO);
	}

/**
* insertBatchTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return int[]
*/
	@LocalName("insertBatchTbmMdBaseHms")
	public int[] insertBatchTbmMdBaseHms (final List tbmMdBaseHmsDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.insertBatchTbmMdBaseHms.001*/  \n");
			sql.append(" TBM_MD_BASE_HMS (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        APLY_START_DT , \n");
			sql.append("        APLY_FIN_DT , \n");
			sql.append("        MONT_STOP_APLY_SSOP , \n");
			sql.append("        LINE_STOP_APLY_SSOP , \n");
			sql.append("        ATST_PRODC_NUM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdBaseHmsDVO tbmMdBaseHmsDVO = (TbmMdBaseHmsDVO)tbmMdBaseHmsDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyFinDt());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getMontStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getLineStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getAtstProdcNum());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getUseYn());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdBaseHmsDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return int[]
*/
	@LocalName("updateBatchTbmMdBaseHms")
	public int[] updateBatchTbmMdBaseHms (final List tbmMdBaseHmsDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.updateBatchTbmMdBaseHms.001*/  \n");
			sql.append(" TBM_MD_BASE_HMS \n");
			sql.append(" SET   \n");
			sql.append("        APLY_FIN_DT = ? , \n");
			sql.append("        MONT_STOP_APLY_SSOP = ? , \n");
			sql.append("        LINE_STOP_APLY_SSOP = ? , \n");
			sql.append("        ATST_PRODC_NUM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");
			sql.append("   AND MFG_PART_CODE = ? \n");
			sql.append("   AND APLY_START_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdBaseHmsDVO tbmMdBaseHmsDVO = (TbmMdBaseHmsDVO)tbmMdBaseHmsDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyFinDt());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getMontStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getLineStopAplySsop());
							ps.setBigDecimal(psCount++, tbmMdBaseHmsDVO.getAtstProdcNum());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getUseYn());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
						}
							public int getBatchSize() {
									return tbmMdBaseHmsDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdBaseHms Method
* 
* @ref_table TBM_MD_BASE_HMS
* @return int[]
*/
	@LocalName("deleteBatchTbmMdBaseHms")
	public int[] deleteBatchTbmMdBaseHms (final List tbmMdBaseHmsDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdBaseHmsDEM.deleteBatchTbmMdBaseHms.001*/  \n");
			sql.append(" TBM_MD_BASE_HMS \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");
			sql.append("    AND MFG_PART_CODE = ? \n");
			sql.append("    AND APLY_START_DT = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdBaseHmsDVO tbmMdBaseHmsDVO = (TbmMdBaseHmsDVO)tbmMdBaseHmsDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdBaseHmsDVO.getFctCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getLineCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdBaseHmsDVO.getAplyStartDt());
						}
							public int getBatchSize() {
									return tbmMdBaseHmsDVOList.size();
							}
					}
		);			
	}

	
}