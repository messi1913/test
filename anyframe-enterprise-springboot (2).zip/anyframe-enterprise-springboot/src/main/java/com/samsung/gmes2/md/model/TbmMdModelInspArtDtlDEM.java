package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelInspArtDtlDEM extends AbstractDAO {


/**
* insertTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return int
*/
	@LocalName("insertTbmMdModelInspArtDtl")
	public int insertTbmMdModelInspArtDtl (final TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.insertTbmMdModelInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_MODEL_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPEC_ULIMIT_VALUE , \n");
			sql.append("        SPEC_LLIMIT_VALUE , \n");
			sql.append("        MAGT_ULIMIT_VALUE , \n");
			sql.append("        MAGT_LLIMIT_VALUE , \n");
			sql.append("        FIX_YN , \n");
			sql.append("        MODEL_INSP_ART_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getSpecUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getSpecLlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtLlimitValue());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFixYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelInspArtDesc());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelInspArtDtl Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelInspArtDtl Method")
	public int[][] updateBatchAllTbmMdModelInspArtDtl (final List  tbmMdModelInspArtDtlDVOList) {
		
		ArrayList updatetbmMdModelInspArtDtlDVOList = new ArrayList();
		ArrayList insertttbmMdModelInspArtDtlDVOList = new ArrayList();
		ArrayList deletetbmMdModelInspArtDtlDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelInspArtDtlDVOList.size() ; i++) {
		  TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO = (TbmMdModelInspArtDtlDVO) tbmMdModelInspArtDtlDVOList.get(i);
		  
		  if (tbmMdModelInspArtDtlDVO.getSqlAction().equals("C"))
		      insertttbmMdModelInspArtDtlDVOList.add(tbmMdModelInspArtDtlDVO);
		  else if (tbmMdModelInspArtDtlDVO.getSqlAction().equals("U"))
		      updatetbmMdModelInspArtDtlDVOList.add(tbmMdModelInspArtDtlDVO);
		  else if (tbmMdModelInspArtDtlDVO.getSqlAction().equals("D"))
		      deletetbmMdModelInspArtDtlDVOList.add(tbmMdModelInspArtDtlDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelInspArtDtlDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelInspArtDtl(insertttbmMdModelInspArtDtlDVOList);
          
      if (updatetbmMdModelInspArtDtlDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelInspArtDtl(updatetbmMdModelInspArtDtlDVOList);
      
      if (deletetbmMdModelInspArtDtlDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelInspArtDtl(deletetbmMdModelInspArtDtlDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return int
*/
	@LocalName("updateTbmMdModelInspArtDtl")
	public int updateTbmMdModelInspArtDtl (final TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.updateTbmMdModelInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_MODEL_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        SPEC_ULIMIT_VALUE = ? , \n");
			sql.append("        SPEC_LLIMIT_VALUE = ? , \n");
			sql.append("        MAGT_ULIMIT_VALUE = ? , \n");
			sql.append("        MAGT_LLIMIT_VALUE = ? , \n");
			sql.append("        FIX_YN = ? , \n");
			sql.append("        MODEL_INSP_ART_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");
			sql.append("   AND PROD_GRP_CODE = ? \n");
			sql.append("   AND PROD_ABBR_CODE = ? \n");
			sql.append("   AND PJT_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getSpecUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getSpecLlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtLlimitValue());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFixYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelInspArtDesc());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
						}
					}
		);			
	}

/**
* deleteTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return int
*/
	@LocalName("deleteTbmMdModelInspArtDtl")
	public int deleteTbmMdModelInspArtDtl (final TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.deleteTbmMdModelInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_MODEL_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND PROD_GRP_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND PJT_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
						}
					}
		);			
	}

/**
* selectTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return TbmMdModelInspArtDtlDVO 
*/
	@LocalName("selectTbmMdModelInspArtDtl")
	public TbmMdModelInspArtDtlDVO selectTbmMdModelInspArtDtl (final TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.selectTbmMdModelInspArtDtl.001*/  \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPEC_ULIMIT_VALUE , \n");
			sql.append("        SPEC_LLIMIT_VALUE , \n");
			sql.append("        MAGT_ULIMIT_VALUE , \n");
			sql.append("        MAGT_LLIMIT_VALUE , \n");
			sql.append("        FIX_YN , \n");
			sql.append("        MODEL_INSP_ART_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND PROD_GRP_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND PJT_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return (TbmMdModelInspArtDtlDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelInspArtDtlDVO returnTbmMdModelInspArtDtlDVO = new TbmMdModelInspArtDtlDVO();
									returnTbmMdModelInspArtDtlDVO.setGbmCode(resultSet.getString("GBM_CODE"));
									returnTbmMdModelInspArtDtlDVO.setCorpCode(resultSet.getString("CORP_CODE"));
									returnTbmMdModelInspArtDtlDVO.setProdGrpCode(resultSet.getString("PROD_GRP_CODE"));
									returnTbmMdModelInspArtDtlDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbmMdModelInspArtDtlDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdModelInspArtDtlDVO.setInspArtDtlCode(resultSet.getString("INSP_ART_DTL_CODE"));
									returnTbmMdModelInspArtDtlDVO.setModelCode(resultSet.getString("MODEL_CODE"));
									returnTbmMdModelInspArtDtlDVO.setSpecUlimitValue(resultSet.getString("SPEC_ULIMIT_VALUE"));
									returnTbmMdModelInspArtDtlDVO.setSpecLlimitValue(resultSet.getBigDecimal("SPEC_LLIMIT_VALUE"));
									returnTbmMdModelInspArtDtlDVO.setMagtUlimitValue(resultSet.getBigDecimal("MAGT_ULIMIT_VALUE"));
									returnTbmMdModelInspArtDtlDVO.setMagtLlimitValue(resultSet.getBigDecimal("MAGT_LLIMIT_VALUE"));
									returnTbmMdModelInspArtDtlDVO.setFixYn(resultSet.getString("FIX_YN"));
									returnTbmMdModelInspArtDtlDVO.setModelInspArtDesc(resultSet.getString("MODEL_INSP_ART_DESC"));
									returnTbmMdModelInspArtDtlDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdModelInspArtDtlDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelInspArtDtlDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelInspArtDtlDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelInspArtDtlDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelInspArtDtlDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelInspArtDtl Method")
	public int mergeTbmMdModelInspArtDtl (final TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO) {
		
		if ( selectTbmMdModelInspArtDtl (tbmMdModelInspArtDtlDVO) == null) {
			return insertTbmMdModelInspArtDtl(tbmMdModelInspArtDtlDVO);
		} else {
			return selectUpdateTbmMdModelInspArtDtl (tbmMdModelInspArtDtlDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelInspArtDtl Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelInspArtDtl Method")
	public int selectUpdateTbmMdModelInspArtDtl (final TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO) {
		
		TbmMdModelInspArtDtlDVO tmpTbmMdModelInspArtDtlDVO =  selectTbmMdModelInspArtDtl (tbmMdModelInspArtDtlDVO);
		if ( tbmMdModelInspArtDtlDVO.getGbmCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getGbmCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setGbmCode(tbmMdModelInspArtDtlDVO.getGbmCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getCorpCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getCorpCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setCorpCode(tbmMdModelInspArtDtlDVO.getCorpCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getProdGrpCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getProdGrpCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setProdGrpCode(tbmMdModelInspArtDtlDVO.getProdGrpCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getProdAbbrCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getProdAbbrCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setProdAbbrCode(tbmMdModelInspArtDtlDVO.getProdAbbrCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getPjtCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getPjtCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setPjtCode(tbmMdModelInspArtDtlDVO.getPjtCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getInspArtDtlCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getInspArtDtlCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setInspArtDtlCode(tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getModelCode() != null && !"".equals(tbmMdModelInspArtDtlDVO.getModelCode()) ) {
			tmpTbmMdModelInspArtDtlDVO.setModelCode(tbmMdModelInspArtDtlDVO.getModelCode());
		}		
		if ( tbmMdModelInspArtDtlDVO.getSpecUlimitValue() != null && !"".equals(tbmMdModelInspArtDtlDVO.getSpecUlimitValue()) ) {
			tmpTbmMdModelInspArtDtlDVO.setSpecUlimitValue(tbmMdModelInspArtDtlDVO.getSpecUlimitValue());
		}		
		if ( tbmMdModelInspArtDtlDVO.getSpecLlimitValue() != null && !"".equals(tbmMdModelInspArtDtlDVO.getSpecLlimitValue()) ) {
			tmpTbmMdModelInspArtDtlDVO.setSpecLlimitValue(tbmMdModelInspArtDtlDVO.getSpecLlimitValue());
		}		
		if ( tbmMdModelInspArtDtlDVO.getMagtUlimitValue() != null && !"".equals(tbmMdModelInspArtDtlDVO.getMagtUlimitValue()) ) {
			tmpTbmMdModelInspArtDtlDVO.setMagtUlimitValue(tbmMdModelInspArtDtlDVO.getMagtUlimitValue());
		}		
		if ( tbmMdModelInspArtDtlDVO.getMagtLlimitValue() != null && !"".equals(tbmMdModelInspArtDtlDVO.getMagtLlimitValue()) ) {
			tmpTbmMdModelInspArtDtlDVO.setMagtLlimitValue(tbmMdModelInspArtDtlDVO.getMagtLlimitValue());
		}		
		if ( tbmMdModelInspArtDtlDVO.getFixYn() != null && !"".equals(tbmMdModelInspArtDtlDVO.getFixYn()) ) {
			tmpTbmMdModelInspArtDtlDVO.setFixYn(tbmMdModelInspArtDtlDVO.getFixYn());
		}		
		if ( tbmMdModelInspArtDtlDVO.getModelInspArtDesc() != null && !"".equals(tbmMdModelInspArtDtlDVO.getModelInspArtDesc()) ) {
			tmpTbmMdModelInspArtDtlDVO.setModelInspArtDesc(tbmMdModelInspArtDtlDVO.getModelInspArtDesc());
		}		
		if ( tbmMdModelInspArtDtlDVO.getUseYn() != null && !"".equals(tbmMdModelInspArtDtlDVO.getUseYn()) ) {
			tmpTbmMdModelInspArtDtlDVO.setUseYn(tbmMdModelInspArtDtlDVO.getUseYn());
		}		
		if ( tbmMdModelInspArtDtlDVO.getFstRegDt() != null && !"".equals(tbmMdModelInspArtDtlDVO.getFstRegDt()) ) {
			tmpTbmMdModelInspArtDtlDVO.setFstRegDt(tbmMdModelInspArtDtlDVO.getFstRegDt());
		}		
		if ( tbmMdModelInspArtDtlDVO.getFstRegerId() != null && !"".equals(tbmMdModelInspArtDtlDVO.getFstRegerId()) ) {
			tmpTbmMdModelInspArtDtlDVO.setFstRegerId(tbmMdModelInspArtDtlDVO.getFstRegerId());
		}		
		if ( tbmMdModelInspArtDtlDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelInspArtDtlDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelInspArtDtlDVO.setFnlUpdDt(tbmMdModelInspArtDtlDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelInspArtDtlDVO.getFnlUpderId() != null && !"".equals(tbmMdModelInspArtDtlDVO.getFnlUpderId()) ) {
			tmpTbmMdModelInspArtDtlDVO.setFnlUpderId(tbmMdModelInspArtDtlDVO.getFnlUpderId());
		}		
		return updateTbmMdModelInspArtDtl (tmpTbmMdModelInspArtDtlDVO);
	}

/**
* insertBatchTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelInspArtDtl")
	public int[] insertBatchTbmMdModelInspArtDtl (final List tbmMdModelInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.insertBatchTbmMdModelInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_MODEL_INSP_ART_DTL (   \n");
			sql.append("        GBM_CODE , \n");
			sql.append("        CORP_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        INSP_ART_DTL_CODE , \n");
			sql.append("        MODEL_CODE , \n");
			sql.append("        SPEC_ULIMIT_VALUE , \n");
			sql.append("        SPEC_LLIMIT_VALUE , \n");
			sql.append("        MAGT_ULIMIT_VALUE , \n");
			sql.append("        MAGT_LLIMIT_VALUE , \n");
			sql.append("        FIX_YN , \n");
			sql.append("        MODEL_INSP_ART_DESC , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO = (TbmMdModelInspArtDtlDVO)tbmMdModelInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getSpecUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getSpecLlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtLlimitValue());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFixYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelInspArtDesc());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelInspArtDtl")
	public int[] updateBatchTbmMdModelInspArtDtl (final List tbmMdModelInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.updateBatchTbmMdModelInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_MODEL_INSP_ART_DTL \n");
			sql.append(" SET   \n");
			sql.append("        SPEC_ULIMIT_VALUE = ? , \n");
			sql.append("        SPEC_LLIMIT_VALUE = ? , \n");
			sql.append("        MAGT_ULIMIT_VALUE = ? , \n");
			sql.append("        MAGT_LLIMIT_VALUE = ? , \n");
			sql.append("        FIX_YN = ? , \n");
			sql.append("        MODEL_INSP_ART_DESC = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE GBM_CODE = ? \n");
			sql.append("   AND CORP_CODE = ? \n");
			sql.append("   AND PROD_GRP_CODE = ? \n");
			sql.append("   AND PROD_ABBR_CODE = ? \n");
			sql.append("   AND PJT_CODE = ? \n");
			sql.append("   AND INSP_ART_DTL_CODE = ? \n");
			sql.append("   AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO = (TbmMdModelInspArtDtlDVO)tbmMdModelInspArtDtlDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getSpecUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getSpecLlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtUlimitValue());
							ps.setBigDecimal(psCount++, tbmMdModelInspArtDtlDVO.getMagtLlimitValue());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFixYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelInspArtDesc());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getUseYn());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdModelInspArtDtlDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelInspArtDtl Method
* 
* @ref_table TBM_MD_MODEL_INSP_ART_DTL
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelInspArtDtl")
	public int[] deleteBatchTbmMdModelInspArtDtl (final List tbmMdModelInspArtDtlDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelInspArtDtlDEM.deleteBatchTbmMdModelInspArtDtl.001*/  \n");
			sql.append(" TBM_MD_MODEL_INSP_ART_DTL \n");
			sql.append("  WHERE GBM_CODE = ? \n");
			sql.append("    AND CORP_CODE = ? \n");
			sql.append("    AND PROD_GRP_CODE = ? \n");
			sql.append("    AND PROD_ABBR_CODE = ? \n");
			sql.append("    AND PJT_CODE = ? \n");
			sql.append("    AND INSP_ART_DTL_CODE = ? \n");
			sql.append("    AND MODEL_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelInspArtDtlDVO tbmMdModelInspArtDtlDVO = (TbmMdModelInspArtDtlDVO)tbmMdModelInspArtDtlDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getGbmCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getCorpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdGrpCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getPjtCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getInspArtDtlCode());
							ps.setString(psCount++, tbmMdModelInspArtDtlDVO.getModelCode());
						}
							public int getBatchSize() {
									return tbmMdModelInspArtDtlDVOList.size();
							}
					}
		);			
	}

	
}