package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBD_MC_LABEL_REG_VAR
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbdMcLabelRegVarDEM extends AbstractDAO {


/**
* insertTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return int
*/
	@LocalName("insertTbdMcLabelRegVar")
	public int insertTbdMcLabelRegVar (final TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.insertTbdMcLabelRegVar.001*/  \n");
			sql.append(" TBD_MC_LABEL_REG_VAR (   \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        LABEL_VER , \n");
			sql.append("        VAR_NM , \n");
			sql.append("        PROP_ID , \n");
			sql.append("        VAR_VALUE_TYPE_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getPropId());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarValueTypeCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbdMcLabelRegVar Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbdMcLabelRegVar Method")
	public int[][] updateBatchAllTbdMcLabelRegVar (final List  tbdMcLabelRegVarDVOList) {
		
		ArrayList updatetbdMcLabelRegVarDVOList = new ArrayList();
		ArrayList insertttbdMcLabelRegVarDVOList = new ArrayList();
		ArrayList deletetbdMcLabelRegVarDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbdMcLabelRegVarDVOList.size() ; i++) {
		  TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO = (TbdMcLabelRegVarDVO) tbdMcLabelRegVarDVOList.get(i);
		  
		  if (tbdMcLabelRegVarDVO.getSqlAction().equals("C"))
		      insertttbdMcLabelRegVarDVOList.add(tbdMcLabelRegVarDVO);
		  else if (tbdMcLabelRegVarDVO.getSqlAction().equals("U"))
		      updatetbdMcLabelRegVarDVOList.add(tbdMcLabelRegVarDVO);
		  else if (tbdMcLabelRegVarDVO.getSqlAction().equals("D"))
		      deletetbdMcLabelRegVarDVOList.add(tbdMcLabelRegVarDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbdMcLabelRegVarDVOList.size() > 0) 
          resultValues[0] = insertBatchTbdMcLabelRegVar(insertttbdMcLabelRegVarDVOList);
          
      if (updatetbdMcLabelRegVarDVOList.size() >0)
          resultValues[1] = updateBatchTbdMcLabelRegVar(updatetbdMcLabelRegVarDVOList);
      
      if (deletetbdMcLabelRegVarDVOList.size() >0)
          resultValues[2] = deleteBatchTbdMcLabelRegVar(deletetbdMcLabelRegVarDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return int
*/
	@LocalName("updateTbdMcLabelRegVar")
	public int updateTbdMcLabelRegVar (final TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.updateTbdMcLabelRegVar.001*/  \n");
			sql.append(" TBD_MC_LABEL_REG_VAR \n");
			sql.append(" SET   \n");
			sql.append("        PROP_ID = ? , \n");
			sql.append("        VAR_VALUE_TYPE_CODE = ? \n");
			sql.append(" WHERE LABEL_ID = ? \n");
			sql.append("   AND LABEL_VER = ? \n");
			sql.append("   AND VAR_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbdMcLabelRegVarDVO.getPropId());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarValueTypeCode());

							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
						}
					}
		);			
	}

/**
* deleteTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return int
*/
	@LocalName("deleteTbdMcLabelRegVar")
	public int deleteTbdMcLabelRegVar (final TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.deleteTbdMcLabelRegVar.001*/  \n");
			sql.append(" TBD_MC_LABEL_REG_VAR \n");
			sql.append("  WHERE LABEL_ID = ? \n");
			sql.append("    AND LABEL_VER = ? \n");
			sql.append("    AND VAR_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
						}
					}
		);			
	}

/**
* selectTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return TbdMcLabelRegVarDVO 
*/
	@LocalName("selectTbdMcLabelRegVar")
	public TbdMcLabelRegVarDVO selectTbdMcLabelRegVar (final TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.selectTbdMcLabelRegVar.001*/  \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        LABEL_VER , \n");
			sql.append("        VAR_NM , \n");
			sql.append("        PROP_ID , \n");
			sql.append("        VAR_VALUE_TYPE_CODE \n");
			sql.append("   FROM TBD_MC_LABEL_REG_VAR \n");
			sql.append("  WHERE LABEL_ID = ? \n");
			sql.append("    AND LABEL_VER = ? \n");
			sql.append("    AND VAR_NM = ? \n");

		return (TbdMcLabelRegVarDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbdMcLabelRegVarDVO returnTbdMcLabelRegVarDVO = new TbdMcLabelRegVarDVO();
									returnTbdMcLabelRegVarDVO.setLabelId(resultSet.getString("LABEL_ID"));
									returnTbdMcLabelRegVarDVO.setLabelVer(resultSet.getBigDecimal("LABEL_VER"));
									returnTbdMcLabelRegVarDVO.setVarNm(resultSet.getString("VAR_NM"));
									returnTbdMcLabelRegVarDVO.setPropId(resultSet.getString("PROP_ID"));
									returnTbdMcLabelRegVarDVO.setVarValueTypeCode(resultSet.getString("VAR_VALUE_TYPE_CODE"));
									return returnTbdMcLabelRegVarDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbdMcLabelRegVar Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbdMcLabelRegVar Method")
	public int mergeTbdMcLabelRegVar (final TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO) {
		
		if ( selectTbdMcLabelRegVar (tbdMcLabelRegVarDVO) == null) {
			return insertTbdMcLabelRegVar(tbdMcLabelRegVarDVO);
		} else {
			return selectUpdateTbdMcLabelRegVar (tbdMcLabelRegVarDVO);
		}
	}

	/**
	 * selectUpdateTbdMcLabelRegVar Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbdMcLabelRegVar Method")
	public int selectUpdateTbdMcLabelRegVar (final TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO) {
		
		TbdMcLabelRegVarDVO tmpTbdMcLabelRegVarDVO =  selectTbdMcLabelRegVar (tbdMcLabelRegVarDVO);
		if ( tbdMcLabelRegVarDVO.getLabelId() != null && !"".equals(tbdMcLabelRegVarDVO.getLabelId()) ) {
			tmpTbdMcLabelRegVarDVO.setLabelId(tbdMcLabelRegVarDVO.getLabelId());
		}		
		if ( tbdMcLabelRegVarDVO.getLabelVer() != null && !"".equals(tbdMcLabelRegVarDVO.getLabelVer()) ) {
			tmpTbdMcLabelRegVarDVO.setLabelVer(tbdMcLabelRegVarDVO.getLabelVer());
		}		
		if ( tbdMcLabelRegVarDVO.getVarNm() != null && !"".equals(tbdMcLabelRegVarDVO.getVarNm()) ) {
			tmpTbdMcLabelRegVarDVO.setVarNm(tbdMcLabelRegVarDVO.getVarNm());
		}		
		if ( tbdMcLabelRegVarDVO.getPropId() != null && !"".equals(tbdMcLabelRegVarDVO.getPropId()) ) {
			tmpTbdMcLabelRegVarDVO.setPropId(tbdMcLabelRegVarDVO.getPropId());
		}		
		if ( tbdMcLabelRegVarDVO.getVarValueTypeCode() != null && !"".equals(tbdMcLabelRegVarDVO.getVarValueTypeCode()) ) {
			tmpTbdMcLabelRegVarDVO.setVarValueTypeCode(tbdMcLabelRegVarDVO.getVarValueTypeCode());
		}		
		return updateTbdMcLabelRegVar (tmpTbdMcLabelRegVarDVO);
	}

/**
* insertBatchTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return int[]
*/
	@LocalName("insertBatchTbdMcLabelRegVar")
	public int[] insertBatchTbdMcLabelRegVar (final List tbdMcLabelRegVarDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.insertBatchTbdMcLabelRegVar.001*/  \n");
			sql.append(" TBD_MC_LABEL_REG_VAR (   \n");
			sql.append("        LABEL_ID , \n");
			sql.append("        LABEL_VER , \n");
			sql.append("        VAR_NM , \n");
			sql.append("        PROP_ID , \n");
			sql.append("        VAR_VALUE_TYPE_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO = (TbdMcLabelRegVarDVO)tbdMcLabelRegVarDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getPropId());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarValueTypeCode());

						}
							public int getBatchSize() {
									return tbdMcLabelRegVarDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return int[]
*/
	@LocalName("updateBatchTbdMcLabelRegVar")
	public int[] updateBatchTbdMcLabelRegVar (final List tbdMcLabelRegVarDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.updateBatchTbdMcLabelRegVar.001*/  \n");
			sql.append(" TBD_MC_LABEL_REG_VAR \n");
			sql.append(" SET   \n");
			sql.append("        PROP_ID = ? , \n");
			sql.append("        VAR_VALUE_TYPE_CODE = ? \n");
			sql.append(" WHERE LABEL_ID = ? \n");
			sql.append("   AND LABEL_VER = ? \n");
			sql.append("   AND VAR_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO = (TbdMcLabelRegVarDVO)tbdMcLabelRegVarDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbdMcLabelRegVarDVO.getPropId());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarValueTypeCode());

							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
						}
							public int getBatchSize() {
									return tbdMcLabelRegVarDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbdMcLabelRegVar Method
* 
* @ref_table TBD_MC_LABEL_REG_VAR
* @return int[]
*/
	@LocalName("deleteBatchTbdMcLabelRegVar")
	public int[] deleteBatchTbdMcLabelRegVar (final List tbdMcLabelRegVarDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbdMcLabelRegVarDEM.deleteBatchTbdMcLabelRegVar.001*/  \n");
			sql.append(" TBD_MC_LABEL_REG_VAR \n");
			sql.append("  WHERE LABEL_ID = ? \n");
			sql.append("    AND LABEL_VER = ? \n");
			sql.append("    AND VAR_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbdMcLabelRegVarDVO tbdMcLabelRegVarDVO = (TbdMcLabelRegVarDVO)tbdMcLabelRegVarDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbdMcLabelRegVarDVO.getLabelId());
							ps.setBigDecimal(psCount++, tbdMcLabelRegVarDVO.getLabelVer());
							ps.setString(psCount++, tbdMcLabelRegVarDVO.getVarNm());
						}
							public int getBatchSize() {
									return tbdMcLabelRegVarDVOList.size();
							}
					}
		);			
	}

	
}