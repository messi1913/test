/**
 * <PRE>
 * System Name : MD
 * Business Name : MDM
 * Class Name : MdManageTbcMdCommCodeType.java
 * Description : 클래스 설명
 * Modification History
 *          수정일        수정자          수정내용
 *    -------------------------------------------------
 *    2011.07.25          호건웅           최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */
package com.samsung.gmes2.md.mdm.biz;
import java.util.List;

import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdCommCodeTypeDVO;
public class MdManageTbcMdCommCodeTypeBiz {
	/**
	 * 공통 코드 유형 정보를 생성한다
	 * @name_ko 공통 코드 유형 정보 생성 메서드
	 */
	public TbcMdCommCodeTypeDVO createNewTbcMdCommCodeTypeRow( TbcMdCommCodeTypeDVO inputDvo ) throws Exception{
		return CrudUtil.create( inputDvo );		
	}
	
	public TbcMdCommCodeTypeDVO createNewTbcMdCommCodeTypeRows( TbcMdCommCodeTypeDVO inputDvo ) throws Exception{
		return CrudUtil.create( inputDvo );		
	}
	/**
	 * 공통 코드 유형 정보에 대한 단건 조회를 수행한다
	 * @name_ko 공통 코드 유형 정보에 대한 단건 조회 메서드
	 */
	public TbcMdCommCodeTypeDVO getTbcMdCommCodeTypeRow( TbcMdCommCodeTypeDVO inputDvo ) throws Exception{
		return CrudUtil.get( inputDvo );
	}
	/**
	 * 공통 코드 유형 정보 수정을 수행한다
	 * @name_ko 공통 코드 유형 정보 수정 메서드
	 */
	public TbcMdCommCodeTypeDVO updateTbcMdCommCodeTypeRow( TbcMdCommCodeTypeDVO inputDvo ) throws Exception{
		return CrudUtil.update( inputDvo );
	}
	/**
	 * 공통 코드 유형 정보 삭제를 수행한다
	 * @name_ko 공통 코드 유형 정보 삭제 메서드
	 */
	public TbcMdCommCodeTypeDVO deleteTbcMdCommCodeTypeRow( TbcMdCommCodeTypeDVO inputDvo ) throws Exception{
		return CrudUtil.delete( inputDvo );
	}
	/**
	 * 공통 코드 유형 정보에 대해 다건 조회를 수행한다
	 * @name_ko 공통 코드 유형 정보 다건 조회 메서드
	 */
	public List listTbcMdCommCodeType( TbcMdCommCodeTypeDVO inputDvo ) throws Exception{
		List resultList = CrudUtil.list0( TbcMdCommCodeTypeDVO.class, inputDvo,0, 0);
		/*--------------------------------------------------
		 * @fd_if 조회 결과가 없으면 널을, 조회 결과가 없으면 조회 결과를 
		 * 받은 리스트를 리턴
		 * @fd_id 0001
		 --------------------------------------------------*/
		if( resultList.size() > 0 ){
			return resultList;
		}
		return null;
	}
}
