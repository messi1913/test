package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdLossCauseDQM extends AbstractDAO {


/**
*
* SELECT 
* 	LOSS_CAUSE_CODE, 
* 	LOSS_NM, 
* 	LOSS_CAUSE_DESC, 
* 	LOSS_ART_CODE, 
* 	DUTY_CLSF_CODE, 
* 	PRTY_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_LOSS_CAUSE 
* WHERE 1=1 
* #if($lossCauseCode) 
* AND LOSS_CAUSE_CODE = :lossCauseCode 
* #end 
* #if($lossNm) 
* AND LOSS_NM = :lossNm 
* #end 
* #if($lossNmLike) 
* AND LOSS_NM like '%' || :lossNmLike || '%' 
* #end 
* #if($lossCauseDesc) 
* AND LOSS_CAUSE_DESC = :lossCauseDesc 
* #end 
* #if($lossArtCode) 
* AND LOSS_ART_CODE = :lossArtCode 
* #end 
* #if($dutyClsfCode) 
* AND DUTY_CLSF_CODE = :dutyClsfCode 
* #end 
* #if($prtyReflYn) 
* AND PRTY_REFL_YN = :prtyReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	LOSS_CAUSE_CODE,  \n");
			sql.append(" 	LOSS_NM,  \n");
			sql.append(" 	LOSS_CAUSE_DESC,  \n");
			sql.append(" 	LOSS_ART_CODE,  \n");
			sql.append(" 	DUTY_CLSF_CODE,  \n");
			sql.append(" 	PRTY_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_LOSS_CAUSE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($lossCauseCode)  \n");
			sql.append(" AND LOSS_CAUSE_CODE = :lossCauseCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNm)  \n");
			sql.append(" AND LOSS_NM = :lossNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNmLike)  \n");
			sql.append(" AND LOSS_NM like '%' || :lossNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossCauseDesc)  \n");
			sql.append(" AND LOSS_CAUSE_DESC = :lossCauseDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossArtCode)  \n");
			sql.append(" AND LOSS_ART_CODE = :lossArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dutyClsfCode)  \n");
			sql.append(" AND DUTY_CLSF_CODE = :dutyClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prtyReflYn)  \n");
			sql.append(" AND PRTY_REFL_YN = :prtyReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdLossCauseDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdLossCauseDVO returnTbcMdLossCauseDVO = new TbcMdLossCauseDVO();
									return returnTbcMdLossCauseDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	LOSS_CAUSE_CODE, 
* 	LOSS_NM, 
* 	LOSS_CAUSE_DESC
* FROM TBC_MD_LOSS_CAUSE 
* WHERE 1=1 
* #if($lossCauseCode) 
* AND LOSS_CAUSE_CODE = :lossCauseCode 
* #end 
* #if($lossNm) 
* AND LOSS_NM = :lossNm 
* #end 
* #if($lossNmLike) 
* AND LOSS_NM like '%' || :lossNmLike || '%' 
* #end 
* #if($lossCauseDesc) 
* AND LOSS_CAUSE_DESC = :lossCauseDesc 
* #end 
* #if($lossArtCode) 
* AND LOSS_ART_CODE = :lossArtCode 
* #end 
* #if($dutyClsfCode) 
* AND DUTY_CLSF_CODE = :dutyClsfCode 
* #end 
* #if($prtyReflYn) 
* AND PRTY_REFL_YN = :prtyReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	LOSS_CAUSE_CODE,  \n");
			sql.append(" 	LOSS_NM,  \n");
			sql.append(" 	LOSS_CAUSE_DESC \n");
			sql.append(" FROM TBC_MD_LOSS_CAUSE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($lossCauseCode)  \n");
			sql.append(" AND LOSS_CAUSE_CODE = :lossCauseCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNm)  \n");
			sql.append(" AND LOSS_NM = :lossNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNmLike)  \n");
			sql.append(" AND LOSS_NM like '%' || :lossNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossCauseDesc)  \n");
			sql.append(" AND LOSS_CAUSE_DESC = :lossCauseDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossArtCode)  \n");
			sql.append(" AND LOSS_ART_CODE = :lossArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dutyClsfCode)  \n");
			sql.append(" AND DUTY_CLSF_CODE = :dutyClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prtyReflYn)  \n");
			sql.append(" AND PRTY_REFL_YN = :prtyReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdLossCauseDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdLossCauseDVO returnTbcMdLossCauseDVO = new TbcMdLossCauseDVO();
									return returnTbcMdLossCauseDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	LOSS_CAUSE_CODE, 
* 	LOSS_NM, 
* 	LOSS_CAUSE_DESC, 
* 	LOSS_ART_CODE, 
* 	DUTY_CLSF_CODE, 
* 	PRTY_REFL_YN, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_LOSS_CAUSE 
* WHERE 1=1 
* #if($lossCauseCode) 
* AND LOSS_CAUSE_CODE = :lossCauseCode 
* #end 
* #if($lossNm) 
* AND LOSS_NM = :lossNm 
* #end 
* #if($lossNmLike) 
* AND LOSS_NM like '%' || :lossNmLike || '%' 
* #end 
* #if($lossCauseDesc) 
* AND LOSS_CAUSE_DESC = :lossCauseDesc 
* #end 
* #if($lossArtCode) 
* AND LOSS_ART_CODE = :lossArtCode 
* #end 
* #if($dutyClsfCode) 
* AND DUTY_CLSF_CODE = :dutyClsfCode 
* #end 
* #if($prtyReflYn) 
* AND PRTY_REFL_YN = :prtyReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	LOSS_CAUSE_CODE,  \n");
			sql.append(" 	LOSS_NM,  \n");
			sql.append(" 	LOSS_CAUSE_DESC,  \n");
			sql.append(" 	LOSS_ART_CODE,  \n");
			sql.append(" 	DUTY_CLSF_CODE,  \n");
			sql.append(" 	PRTY_REFL_YN,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_LOSS_CAUSE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($lossCauseCode)  \n");
			sql.append(" AND LOSS_CAUSE_CODE = :lossCauseCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNm)  \n");
			sql.append(" AND LOSS_NM = :lossNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNmLike)  \n");
			sql.append(" AND LOSS_NM like '%' || :lossNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossCauseDesc)  \n");
			sql.append(" AND LOSS_CAUSE_DESC = :lossCauseDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossArtCode)  \n");
			sql.append(" AND LOSS_ART_CODE = :lossArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dutyClsfCode)  \n");
			sql.append(" AND DUTY_CLSF_CODE = :dutyClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prtyReflYn)  \n");
			sql.append(" AND PRTY_REFL_YN = :prtyReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdLossCauseDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdLossCauseDVO returnTbcMdLossCauseDVO = new TbcMdLossCauseDVO();
									return returnTbcMdLossCauseDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	LOSS_CAUSE_CODE, 
* 	LOSS_NM, 
* 	LOSS_CAUSE_DESC
* FROM TBC_MD_LOSS_CAUSE 
* WHERE 1=1 
* #if($lossCauseCode) 
* AND LOSS_CAUSE_CODE = :lossCauseCode 
* #end 
* #if($lossNm) 
* AND LOSS_NM = :lossNm 
* #end 
* #if($lossNmLike) 
* AND LOSS_NM like '%' || :lossNmLike || '%' 
* #end 
* #if($lossCauseDesc) 
* AND LOSS_CAUSE_DESC = :lossCauseDesc 
* #end 
* #if($lossArtCode) 
* AND LOSS_ART_CODE = :lossArtCode 
* #end 
* #if($dutyClsfCode) 
* AND DUTY_CLSF_CODE = :dutyClsfCode 
* #end 
* #if($prtyReflYn) 
* AND PRTY_REFL_YN = :prtyReflYn 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	LOSS_CAUSE_CODE,  \n");
			sql.append(" 	LOSS_NM,  \n");
			sql.append(" 	LOSS_CAUSE_DESC \n");
			sql.append(" FROM TBC_MD_LOSS_CAUSE  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($lossCauseCode)  \n");
			sql.append(" AND LOSS_CAUSE_CODE = :lossCauseCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNm)  \n");
			sql.append(" AND LOSS_NM = :lossNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossNmLike)  \n");
			sql.append(" AND LOSS_NM like '%' || :lossNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossCauseDesc)  \n");
			sql.append(" AND LOSS_CAUSE_DESC = :lossCauseDesc  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lossArtCode)  \n");
			sql.append(" AND LOSS_ART_CODE = :lossArtCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($dutyClsfCode)  \n");
			sql.append(" AND DUTY_CLSF_CODE = :dutyClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($prtyReflYn)  \n");
			sql.append(" AND PRTY_REFL_YN = :prtyReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdLossCauseDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdLossCauseDVO returnTbcMdLossCauseDVO = new TbcMdLossCauseDVO();
									return returnTbcMdLossCauseDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}