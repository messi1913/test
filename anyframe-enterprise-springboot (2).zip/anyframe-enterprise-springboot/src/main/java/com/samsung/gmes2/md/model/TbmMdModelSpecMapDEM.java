package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdModelSpecMapDEM extends AbstractDAO {


/**
* insertTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return int
*/
	@LocalName("insertTbmMdModelSpecMap")
	public int insertTbmMdModelSpecMap (final TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.insertTbmMdModelSpecMap.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC_MAP (   \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        FLD_GUBUN_CODE , \n");
			sql.append("        ATTR_LVL_NM , \n");
			sql.append("        ATTR_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrLvlNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdModelSpecMap Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdModelSpecMap Method")
	public int[][] updateBatchAllTbmMdModelSpecMap (final List  tbmMdModelSpecMapDVOList) {
		
		ArrayList updatetbmMdModelSpecMapDVOList = new ArrayList();
		ArrayList insertttbmMdModelSpecMapDVOList = new ArrayList();
		ArrayList deletetbmMdModelSpecMapDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdModelSpecMapDVOList.size() ; i++) {
		  TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO = (TbmMdModelSpecMapDVO) tbmMdModelSpecMapDVOList.get(i);
		  
		  if (tbmMdModelSpecMapDVO.getSqlAction().equals("C"))
		      insertttbmMdModelSpecMapDVOList.add(tbmMdModelSpecMapDVO);
		  else if (tbmMdModelSpecMapDVO.getSqlAction().equals("U"))
		      updatetbmMdModelSpecMapDVOList.add(tbmMdModelSpecMapDVO);
		  else if (tbmMdModelSpecMapDVO.getSqlAction().equals("D"))
		      deletetbmMdModelSpecMapDVOList.add(tbmMdModelSpecMapDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdModelSpecMapDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdModelSpecMap(insertttbmMdModelSpecMapDVOList);
          
      if (updatetbmMdModelSpecMapDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdModelSpecMap(updatetbmMdModelSpecMapDVOList);
      
      if (deletetbmMdModelSpecMapDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdModelSpecMap(deletetbmMdModelSpecMapDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return int
*/
	@LocalName("updateTbmMdModelSpecMap")
	public int updateTbmMdModelSpecMap (final TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.updateTbmMdModelSpecMap.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC_MAP \n");
			sql.append(" SET   \n");
			sql.append("        ATTR_LVL_NM = ? , \n");
			sql.append("        ATTR_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_ABBR_CODE = ? \n");
			sql.append("   AND FLD_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrLvlNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
						}
					}
		);			
	}

/**
* deleteTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return int
*/
	@LocalName("deleteTbmMdModelSpecMap")
	public int deleteTbmMdModelSpecMap (final TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.deleteTbmMdModelSpecMap.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC_MAP \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");
			sql.append("    AND FLD_GUBUN_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
						}
					}
		);			
	}

/**
* selectTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return TbmMdModelSpecMapDVO 
*/
	@LocalName("selectTbmMdModelSpecMap")
	public TbmMdModelSpecMapDVO selectTbmMdModelSpecMap (final TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.selectTbmMdModelSpecMap.001*/  \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        FLD_GUBUN_CODE , \n");
			sql.append("        ATTR_LVL_NM , \n");
			sql.append("        ATTR_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_MODEL_SPEC_MAP \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");
			sql.append("    AND FLD_GUBUN_CODE = ? \n");

		return (TbmMdModelSpecMapDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdModelSpecMapDVO returnTbmMdModelSpecMapDVO = new TbmMdModelSpecMapDVO();
									returnTbmMdModelSpecMapDVO.setProdAbbrCode(resultSet.getString("PROD_ABBR_CODE"));
									returnTbmMdModelSpecMapDVO.setFldGubunCode(resultSet.getString("FLD_GUBUN_CODE"));
									returnTbmMdModelSpecMapDVO.setAttrLvlNm(resultSet.getString("ATTR_LVL_NM"));
									returnTbmMdModelSpecMapDVO.setAttrNm(resultSet.getString("ATTR_NM"));
									returnTbmMdModelSpecMapDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdModelSpecMapDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdModelSpecMapDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdModelSpecMapDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdModelSpecMapDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdModelSpecMap Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdModelSpecMap Method")
	public int mergeTbmMdModelSpecMap (final TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO) {
		
		if ( selectTbmMdModelSpecMap (tbmMdModelSpecMapDVO) == null) {
			return insertTbmMdModelSpecMap(tbmMdModelSpecMapDVO);
		} else {
			return selectUpdateTbmMdModelSpecMap (tbmMdModelSpecMapDVO);
		}
	}

	/**
	 * selectUpdateTbmMdModelSpecMap Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdModelSpecMap Method")
	public int selectUpdateTbmMdModelSpecMap (final TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO) {
		
		TbmMdModelSpecMapDVO tmpTbmMdModelSpecMapDVO =  selectTbmMdModelSpecMap (tbmMdModelSpecMapDVO);
		if ( tbmMdModelSpecMapDVO.getProdAbbrCode() != null && !"".equals(tbmMdModelSpecMapDVO.getProdAbbrCode()) ) {
			tmpTbmMdModelSpecMapDVO.setProdAbbrCode(tbmMdModelSpecMapDVO.getProdAbbrCode());
		}		
		if ( tbmMdModelSpecMapDVO.getFldGubunCode() != null && !"".equals(tbmMdModelSpecMapDVO.getFldGubunCode()) ) {
			tmpTbmMdModelSpecMapDVO.setFldGubunCode(tbmMdModelSpecMapDVO.getFldGubunCode());
		}		
		if ( tbmMdModelSpecMapDVO.getAttrLvlNm() != null && !"".equals(tbmMdModelSpecMapDVO.getAttrLvlNm()) ) {
			tmpTbmMdModelSpecMapDVO.setAttrLvlNm(tbmMdModelSpecMapDVO.getAttrLvlNm());
		}		
		if ( tbmMdModelSpecMapDVO.getAttrNm() != null && !"".equals(tbmMdModelSpecMapDVO.getAttrNm()) ) {
			tmpTbmMdModelSpecMapDVO.setAttrNm(tbmMdModelSpecMapDVO.getAttrNm());
		}		
		if ( tbmMdModelSpecMapDVO.getFstRegDt() != null && !"".equals(tbmMdModelSpecMapDVO.getFstRegDt()) ) {
			tmpTbmMdModelSpecMapDVO.setFstRegDt(tbmMdModelSpecMapDVO.getFstRegDt());
		}		
		if ( tbmMdModelSpecMapDVO.getFstRegerId() != null && !"".equals(tbmMdModelSpecMapDVO.getFstRegerId()) ) {
			tmpTbmMdModelSpecMapDVO.setFstRegerId(tbmMdModelSpecMapDVO.getFstRegerId());
		}		
		if ( tbmMdModelSpecMapDVO.getFnlUpdDt() != null && !"".equals(tbmMdModelSpecMapDVO.getFnlUpdDt()) ) {
			tmpTbmMdModelSpecMapDVO.setFnlUpdDt(tbmMdModelSpecMapDVO.getFnlUpdDt());
		}		
		if ( tbmMdModelSpecMapDVO.getFnlUpderId() != null && !"".equals(tbmMdModelSpecMapDVO.getFnlUpderId()) ) {
			tmpTbmMdModelSpecMapDVO.setFnlUpderId(tbmMdModelSpecMapDVO.getFnlUpderId());
		}		
		return updateTbmMdModelSpecMap (tmpTbmMdModelSpecMapDVO);
	}

/**
* insertBatchTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return int[]
*/
	@LocalName("insertBatchTbmMdModelSpecMap")
	public int[] insertBatchTbmMdModelSpecMap (final List tbmMdModelSpecMapDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.insertBatchTbmMdModelSpecMap.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC_MAP (   \n");
			sql.append("        PROD_ABBR_CODE , \n");
			sql.append("        FLD_GUBUN_CODE , \n");
			sql.append("        ATTR_LVL_NM , \n");
			sql.append("        ATTR_NM , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO = (TbmMdModelSpecMapDVO)tbmMdModelSpecMapDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrLvlNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdModelSpecMapDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return int[]
*/
	@LocalName("updateBatchTbmMdModelSpecMap")
	public int[] updateBatchTbmMdModelSpecMap (final List tbmMdModelSpecMapDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.updateBatchTbmMdModelSpecMap.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC_MAP \n");
			sql.append(" SET   \n");
			sql.append("        ATTR_LVL_NM = ? , \n");
			sql.append("        ATTR_NM = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PROD_ABBR_CODE = ? \n");
			sql.append("   AND FLD_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO = (TbmMdModelSpecMapDVO)tbmMdModelSpecMapDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrLvlNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getAttrNm());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
						}
							public int getBatchSize() {
									return tbmMdModelSpecMapDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdModelSpecMap Method
* 
* @ref_table TBM_MD_MODEL_SPEC_MAP
* @return int[]
*/
	@LocalName("deleteBatchTbmMdModelSpecMap")
	public int[] deleteBatchTbmMdModelSpecMap (final List tbmMdModelSpecMapDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdModelSpecMapDEM.deleteBatchTbmMdModelSpecMap.001*/  \n");
			sql.append(" TBM_MD_MODEL_SPEC_MAP \n");
			sql.append("  WHERE PROD_ABBR_CODE = ? \n");
			sql.append("    AND FLD_GUBUN_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdModelSpecMapDVO tbmMdModelSpecMapDVO = (TbmMdModelSpecMapDVO)tbmMdModelSpecMapDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdModelSpecMapDVO.getProdAbbrCode());
							ps.setString(psCount++, tbmMdModelSpecMapDVO.getFldGubunCode());
						}
							public int getBatchSize() {
									return tbmMdModelSpecMapDVOList.size();
							}
					}
		);			
	}

	
}