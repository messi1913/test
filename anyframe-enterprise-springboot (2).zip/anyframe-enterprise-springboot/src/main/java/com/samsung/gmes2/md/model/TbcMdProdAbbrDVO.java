package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author shim
 */
public class TbcMdProdAbbrDVO extends AbstractVo {

	@Length(30) 
	private String prodAbbrCode;

	@Length(30) 
	private String prodGrpCode;

	@Length(500) 
	private String prodAbbrNm;

	@Length(11) @Scale(5) 
	private BigDecimal prodKindChgBasicProdcQty;

	@Length(6) 
	private String outInspCloseHms;

	@Length(1) 
	private String mfgPrcssCostUseYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getProdAbbrCode() {
		this.prodAbbrCode = super.getValue(0);
		return this.prodAbbrCode;
	}

	public void setProdAbbrCode(String prodAbbrCode) {
        super.setValue(0, prodAbbrCode);
		this.prodAbbrCode = prodAbbrCode;
	}
	
	public String getProdGrpCode() {
		this.prodGrpCode = super.getValue(1);
		return this.prodGrpCode;
	}

	public void setProdGrpCode(String prodGrpCode) {
        super.setValue(1, prodGrpCode);
		this.prodGrpCode = prodGrpCode;
	}
	
	public String getProdAbbrNm() {
		this.prodAbbrNm = super.getValue(2);
		return this.prodAbbrNm;
	}

	public void setProdAbbrNm(String prodAbbrNm) {
        super.setValue(2, prodAbbrNm);
		this.prodAbbrNm = prodAbbrNm;
	}
	
	public BigDecimal getProdKindChgBasicProdcQty() {
		this.prodKindChgBasicProdcQty = super.getValue(3);
		return this.prodKindChgBasicProdcQty;
	}

	public void setProdKindChgBasicProdcQty(BigDecimal prodKindChgBasicProdcQty) {
        super.setValue(3, prodKindChgBasicProdcQty);
		this.prodKindChgBasicProdcQty = prodKindChgBasicProdcQty;
	}
	
	public String getOutInspCloseHms() {
		this.outInspCloseHms = super.getValue(4);
		return this.outInspCloseHms;
	}

	public void setOutInspCloseHms(String outInspCloseHms) {
        super.setValue(4, outInspCloseHms);
		this.outInspCloseHms = outInspCloseHms;
	}
	
	public String getMfgPrcssCostUseYn() {
		this.mfgPrcssCostUseYn = super.getValue(5);
		return this.mfgPrcssCostUseYn;
	}

	public void setMfgPrcssCostUseYn(String mfgPrcssCostUseYn) {
        super.setValue(5, mfgPrcssCostUseYn);
		this.mfgPrcssCostUseYn = mfgPrcssCostUseYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(6);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(6, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(7);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(7, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(8);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(8, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(9);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(9, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}