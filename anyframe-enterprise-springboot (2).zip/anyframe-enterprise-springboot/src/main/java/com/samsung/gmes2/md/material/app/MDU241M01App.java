package com.samsung.gmes2.md.material.app;

public class MDU241M01App {

	/**
	 * UNIT ID 목록 초기설정
	 */
	public void initUnitId(){}

	/**
	 * UNIT ID 목록 조회
	 */
	public void listUnitId(){}

	/**
	 * UNIT ID 목록 엑셀 다운로드
	 */
	public void excelUnitId(){}

	/**
	 * UNIT ID 목록 등록/수정 초기설정
	 */
	public void editUnitId(){}

	/**
	 * UNIT ID 목록 저장
	 */
	public void saveUnitId(){}

}
