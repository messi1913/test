package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PLANT_EQUIP
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPlantEquipDEM extends AbstractDAO {


/**
* insertTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return int
*/
	@LocalName("insertTbmMdPlantEquip")
	public int insertTbmMdPlantEquip (final TbmMdPlantEquipDVO tbmMdPlantEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.insertTbmMdPlantEquip.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        EQUIP_NM , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        EQUIP_GUBUN_CODE , \n");
			sql.append("        MATR_GUBUN_CODE , \n");
			sql.append("        MATR_TYPE_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        AUTOM_YN , \n");
			sql.append("        EQUIP_SIZE , \n");
			sql.append("        SUPPLY_VEND_PN_NM , \n");
			sql.append("        SUPPLY_VEND_NM , \n");
			sql.append("        PURC_NO , \n");
			sql.append("        DF_GUBUN_CODE , \n");
			sql.append("        MOLD_NUM , \n");
			sql.append("        FAMILY_NUM , \n");
			sql.append("        CAVITY_NUM , \n");
			sql.append("        MOLD_YLD , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        REV_NO , \n");
			sql.append("        LOCAL_EQUIP_DESC , \n");
			sql.append("        ALTER_MANM , \n");
			sql.append("        ALTER_VEND_CODE , \n");
			sql.append("        CALIB_TERM_HOP , \n");
			sql.append("        CALIB_YN , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        CALIB_APLY_YN , \n");
			sql.append("        DEFT_SUMR_YN , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAutomYn());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getEquipSize());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendPnNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getPurcNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDfGubunCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getFamilyNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCavityNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldYld());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getRevNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getLocalEquipDesc());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterManm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterVendCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCalibTermHop());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDeftSumrYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEvtNm());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPlantEquip Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPlantEquip Method")
	public int[][] updateBatchAllTbmMdPlantEquip (final List  tbmMdPlantEquipDVOList) {
		
		ArrayList updatetbmMdPlantEquipDVOList = new ArrayList();
		ArrayList insertttbmMdPlantEquipDVOList = new ArrayList();
		ArrayList deletetbmMdPlantEquipDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPlantEquipDVOList.size() ; i++) {
		  TbmMdPlantEquipDVO tbmMdPlantEquipDVO = (TbmMdPlantEquipDVO) tbmMdPlantEquipDVOList.get(i);
		  
		  if (tbmMdPlantEquipDVO.getSqlAction().equals("C"))
		      insertttbmMdPlantEquipDVOList.add(tbmMdPlantEquipDVO);
		  else if (tbmMdPlantEquipDVO.getSqlAction().equals("U"))
		      updatetbmMdPlantEquipDVOList.add(tbmMdPlantEquipDVO);
		  else if (tbmMdPlantEquipDVO.getSqlAction().equals("D"))
		      deletetbmMdPlantEquipDVOList.add(tbmMdPlantEquipDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPlantEquipDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPlantEquip(insertttbmMdPlantEquipDVOList);
          
      if (updatetbmMdPlantEquipDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPlantEquip(updatetbmMdPlantEquipDVOList);
      
      if (deletetbmMdPlantEquipDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPlantEquip(deletetbmMdPlantEquipDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return int
*/
	@LocalName("updateTbmMdPlantEquip")
	public int updateTbmMdPlantEquip (final TbmMdPlantEquipDVO tbmMdPlantEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.updateTbmMdPlantEquip.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_NM = ? , \n");
			sql.append("        EQUIP_SPEC_CONT = ? , \n");
			sql.append("        EQUIP_GUBUN_CODE = ? , \n");
			sql.append("        MATR_GUBUN_CODE = ? , \n");
			sql.append("        MATR_TYPE_CODE = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        AUTOM_YN = ? , \n");
			sql.append("        EQUIP_SIZE = ? , \n");
			sql.append("        SUPPLY_VEND_PN_NM = ? , \n");
			sql.append("        SUPPLY_VEND_NM = ? , \n");
			sql.append("        PURC_NO = ? , \n");
			sql.append("        DF_GUBUN_CODE = ? , \n");
			sql.append("        MOLD_NUM = ? , \n");
			sql.append("        FAMILY_NUM = ? , \n");
			sql.append("        CAVITY_NUM = ? , \n");
			sql.append("        MOLD_YLD = ? , \n");
			sql.append("        SAL_MODEL_CODE = ? , \n");
			sql.append("        REV_NO = ? , \n");
			sql.append("        LOCAL_EQUIP_DESC = ? , \n");
			sql.append("        ALTER_MANM = ? , \n");
			sql.append("        ALTER_VEND_CODE = ? , \n");
			sql.append("        CALIB_TERM_HOP = ? , \n");
			sql.append("        CALIB_YN = ? , \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        CALIB_APLY_YN = ? , \n");
			sql.append("        DEFT_SUMR_YN = ? , \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND EQUIP_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAutomYn());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getEquipSize());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendPnNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getPurcNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDfGubunCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getFamilyNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCavityNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldYld());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getRevNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getLocalEquipDesc());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterManm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterVendCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCalibTermHop());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDeftSumrYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEvtNm());

							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
						}
					}
		);			
	}

/**
* deleteTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return int
*/
	@LocalName("deleteTbmMdPlantEquip")
	public int deleteTbmMdPlantEquip (final TbmMdPlantEquipDVO tbmMdPlantEquipDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.deleteTbmMdPlantEquip.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND EQUIP_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
						}
					}
		);			
	}

/**
* selectTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return TbmMdPlantEquipDVO 
*/
	@LocalName("selectTbmMdPlantEquip")
	public TbmMdPlantEquipDVO selectTbmMdPlantEquip (final TbmMdPlantEquipDVO tbmMdPlantEquipDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.selectTbmMdPlantEquip.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        EQUIP_NM , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        EQUIP_GUBUN_CODE , \n");
			sql.append("        MATR_GUBUN_CODE , \n");
			sql.append("        MATR_TYPE_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        AUTOM_YN , \n");
			sql.append("        EQUIP_SIZE , \n");
			sql.append("        SUPPLY_VEND_PN_NM , \n");
			sql.append("        SUPPLY_VEND_NM , \n");
			sql.append("        PURC_NO , \n");
			sql.append("        DF_GUBUN_CODE , \n");
			sql.append("        MOLD_NUM , \n");
			sql.append("        FAMILY_NUM , \n");
			sql.append("        CAVITY_NUM , \n");
			sql.append("        MOLD_YLD , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        REV_NO , \n");
			sql.append("        LOCAL_EQUIP_DESC , \n");
			sql.append("        ALTER_MANM , \n");
			sql.append("        ALTER_VEND_CODE , \n");
			sql.append("        CALIB_TERM_HOP , \n");
			sql.append("        CALIB_YN , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        CALIB_APLY_YN , \n");
			sql.append("        DEFT_SUMR_YN , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append("   FROM TBM_MD_PLANT_EQUIP \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND EQUIP_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return (TbmMdPlantEquipDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPlantEquipDVO returnTbmMdPlantEquipDVO = new TbmMdPlantEquipDVO();
									returnTbmMdPlantEquipDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPlantEquipDVO.setEquipCode(resultSet.getString("EQUIP_CODE"));
									returnTbmMdPlantEquipDVO.setHistTsp(resultSet.getString("HIST_TSP"));
									returnTbmMdPlantEquipDVO.setEquipNm(resultSet.getString("EQUIP_NM"));
									returnTbmMdPlantEquipDVO.setEquipSpecCont(resultSet.getString("EQUIP_SPEC_CONT"));
									returnTbmMdPlantEquipDVO.setEquipGubunCode(resultSet.getString("EQUIP_GUBUN_CODE"));
									returnTbmMdPlantEquipDVO.setMatrGubunCode(resultSet.getString("MATR_GUBUN_CODE"));
									returnTbmMdPlantEquipDVO.setMatrTypeCode(resultSet.getString("MATR_TYPE_CODE"));
									returnTbmMdPlantEquipDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdPlantEquipDVO.setAutomYn(resultSet.getString("AUTOM_YN"));
									returnTbmMdPlantEquipDVO.setEquipSize(resultSet.getBigDecimal("EQUIP_SIZE"));
									returnTbmMdPlantEquipDVO.setSupplyVendPnNm(resultSet.getString("SUPPLY_VEND_PN_NM"));
									returnTbmMdPlantEquipDVO.setSupplyVendNm(resultSet.getString("SUPPLY_VEND_NM"));
									returnTbmMdPlantEquipDVO.setPurcNo(resultSet.getString("PURC_NO"));
									returnTbmMdPlantEquipDVO.setDfGubunCode(resultSet.getString("DF_GUBUN_CODE"));
									returnTbmMdPlantEquipDVO.setMoldNum(resultSet.getBigDecimal("MOLD_NUM"));
									returnTbmMdPlantEquipDVO.setFamilyNum(resultSet.getBigDecimal("FAMILY_NUM"));
									returnTbmMdPlantEquipDVO.setCavityNum(resultSet.getBigDecimal("CAVITY_NUM"));
									returnTbmMdPlantEquipDVO.setMoldYld(resultSet.getBigDecimal("MOLD_YLD"));
									returnTbmMdPlantEquipDVO.setSalModelCode(resultSet.getString("SAL_MODEL_CODE"));
									returnTbmMdPlantEquipDVO.setRevNo(resultSet.getString("REV_NO"));
									returnTbmMdPlantEquipDVO.setLocalEquipDesc(resultSet.getString("LOCAL_EQUIP_DESC"));
									returnTbmMdPlantEquipDVO.setAlterManm(resultSet.getString("ALTER_MANM"));
									returnTbmMdPlantEquipDVO.setAlterVendCode(resultSet.getString("ALTER_VEND_CODE"));
									returnTbmMdPlantEquipDVO.setCalibTermHop(resultSet.getBigDecimal("CALIB_TERM_HOP"));
									returnTbmMdPlantEquipDVO.setCalibYn(resultSet.getString("CALIB_YN"));
									returnTbmMdPlantEquipDVO.setFprfAplyYn(resultSet.getString("FPRF_APLY_YN"));
									returnTbmMdPlantEquipDVO.setCalibAplyYn(resultSet.getString("CALIB_APLY_YN"));
									returnTbmMdPlantEquipDVO.setDeftSumrYn(resultSet.getString("DEFT_SUMR_YN"));
									returnTbmMdPlantEquipDVO.setIfDt(resultSet.getString("IF_DT"));
									returnTbmMdPlantEquipDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdPlantEquipDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPlantEquipDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPlantEquipDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPlantEquipDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbmMdPlantEquipDVO.setEvtNm(resultSet.getString("EVT_NM"));
									return returnTbmMdPlantEquipDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPlantEquip Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPlantEquip Method")
	public int mergeTbmMdPlantEquip (final TbmMdPlantEquipDVO tbmMdPlantEquipDVO) {
		
		if ( selectTbmMdPlantEquip (tbmMdPlantEquipDVO) == null) {
			return insertTbmMdPlantEquip(tbmMdPlantEquipDVO);
		} else {
			return selectUpdateTbmMdPlantEquip (tbmMdPlantEquipDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPlantEquip Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPlantEquip Method")
	public int selectUpdateTbmMdPlantEquip (final TbmMdPlantEquipDVO tbmMdPlantEquipDVO) {
		
		TbmMdPlantEquipDVO tmpTbmMdPlantEquipDVO =  selectTbmMdPlantEquip (tbmMdPlantEquipDVO);
		if ( tbmMdPlantEquipDVO.getPlantCode() != null && !"".equals(tbmMdPlantEquipDVO.getPlantCode()) ) {
			tmpTbmMdPlantEquipDVO.setPlantCode(tbmMdPlantEquipDVO.getPlantCode());
		}		
		if ( tbmMdPlantEquipDVO.getEquipCode() != null && !"".equals(tbmMdPlantEquipDVO.getEquipCode()) ) {
			tmpTbmMdPlantEquipDVO.setEquipCode(tbmMdPlantEquipDVO.getEquipCode());
		}		
		if ( tbmMdPlantEquipDVO.getHistTsp() != null && !"".equals(tbmMdPlantEquipDVO.getHistTsp()) ) {
			tmpTbmMdPlantEquipDVO.setHistTsp(tbmMdPlantEquipDVO.getHistTsp());
		}		
		if ( tbmMdPlantEquipDVO.getEquipNm() != null && !"".equals(tbmMdPlantEquipDVO.getEquipNm()) ) {
			tmpTbmMdPlantEquipDVO.setEquipNm(tbmMdPlantEquipDVO.getEquipNm());
		}		
		if ( tbmMdPlantEquipDVO.getEquipSpecCont() != null && !"".equals(tbmMdPlantEquipDVO.getEquipSpecCont()) ) {
			tmpTbmMdPlantEquipDVO.setEquipSpecCont(tbmMdPlantEquipDVO.getEquipSpecCont());
		}		
		if ( tbmMdPlantEquipDVO.getEquipGubunCode() != null && !"".equals(tbmMdPlantEquipDVO.getEquipGubunCode()) ) {
			tmpTbmMdPlantEquipDVO.setEquipGubunCode(tbmMdPlantEquipDVO.getEquipGubunCode());
		}		
		if ( tbmMdPlantEquipDVO.getMatrGubunCode() != null && !"".equals(tbmMdPlantEquipDVO.getMatrGubunCode()) ) {
			tmpTbmMdPlantEquipDVO.setMatrGubunCode(tbmMdPlantEquipDVO.getMatrGubunCode());
		}		
		if ( tbmMdPlantEquipDVO.getMatrTypeCode() != null && !"".equals(tbmMdPlantEquipDVO.getMatrTypeCode()) ) {
			tmpTbmMdPlantEquipDVO.setMatrTypeCode(tbmMdPlantEquipDVO.getMatrTypeCode());
		}		
		if ( tbmMdPlantEquipDVO.getProcGubunCode() != null && !"".equals(tbmMdPlantEquipDVO.getProcGubunCode()) ) {
			tmpTbmMdPlantEquipDVO.setProcGubunCode(tbmMdPlantEquipDVO.getProcGubunCode());
		}		
		if ( tbmMdPlantEquipDVO.getAutomYn() != null && !"".equals(tbmMdPlantEquipDVO.getAutomYn()) ) {
			tmpTbmMdPlantEquipDVO.setAutomYn(tbmMdPlantEquipDVO.getAutomYn());
		}		
		if ( tbmMdPlantEquipDVO.getEquipSize() != null && !"".equals(tbmMdPlantEquipDVO.getEquipSize()) ) {
			tmpTbmMdPlantEquipDVO.setEquipSize(tbmMdPlantEquipDVO.getEquipSize());
		}		
		if ( tbmMdPlantEquipDVO.getSupplyVendPnNm() != null && !"".equals(tbmMdPlantEquipDVO.getSupplyVendPnNm()) ) {
			tmpTbmMdPlantEquipDVO.setSupplyVendPnNm(tbmMdPlantEquipDVO.getSupplyVendPnNm());
		}		
		if ( tbmMdPlantEquipDVO.getSupplyVendNm() != null && !"".equals(tbmMdPlantEquipDVO.getSupplyVendNm()) ) {
			tmpTbmMdPlantEquipDVO.setSupplyVendNm(tbmMdPlantEquipDVO.getSupplyVendNm());
		}		
		if ( tbmMdPlantEquipDVO.getPurcNo() != null && !"".equals(tbmMdPlantEquipDVO.getPurcNo()) ) {
			tmpTbmMdPlantEquipDVO.setPurcNo(tbmMdPlantEquipDVO.getPurcNo());
		}		
		if ( tbmMdPlantEquipDVO.getDfGubunCode() != null && !"".equals(tbmMdPlantEquipDVO.getDfGubunCode()) ) {
			tmpTbmMdPlantEquipDVO.setDfGubunCode(tbmMdPlantEquipDVO.getDfGubunCode());
		}		
		if ( tbmMdPlantEquipDVO.getMoldNum() != null && !"".equals(tbmMdPlantEquipDVO.getMoldNum()) ) {
			tmpTbmMdPlantEquipDVO.setMoldNum(tbmMdPlantEquipDVO.getMoldNum());
		}		
		if ( tbmMdPlantEquipDVO.getFamilyNum() != null && !"".equals(tbmMdPlantEquipDVO.getFamilyNum()) ) {
			tmpTbmMdPlantEquipDVO.setFamilyNum(tbmMdPlantEquipDVO.getFamilyNum());
		}		
		if ( tbmMdPlantEquipDVO.getCavityNum() != null && !"".equals(tbmMdPlantEquipDVO.getCavityNum()) ) {
			tmpTbmMdPlantEquipDVO.setCavityNum(tbmMdPlantEquipDVO.getCavityNum());
		}		
		if ( tbmMdPlantEquipDVO.getMoldYld() != null && !"".equals(tbmMdPlantEquipDVO.getMoldYld()) ) {
			tmpTbmMdPlantEquipDVO.setMoldYld(tbmMdPlantEquipDVO.getMoldYld());
		}		
		if ( tbmMdPlantEquipDVO.getSalModelCode() != null && !"".equals(tbmMdPlantEquipDVO.getSalModelCode()) ) {
			tmpTbmMdPlantEquipDVO.setSalModelCode(tbmMdPlantEquipDVO.getSalModelCode());
		}		
		if ( tbmMdPlantEquipDVO.getRevNo() != null && !"".equals(tbmMdPlantEquipDVO.getRevNo()) ) {
			tmpTbmMdPlantEquipDVO.setRevNo(tbmMdPlantEquipDVO.getRevNo());
		}		
		if ( tbmMdPlantEquipDVO.getLocalEquipDesc() != null && !"".equals(tbmMdPlantEquipDVO.getLocalEquipDesc()) ) {
			tmpTbmMdPlantEquipDVO.setLocalEquipDesc(tbmMdPlantEquipDVO.getLocalEquipDesc());
		}		
		if ( tbmMdPlantEquipDVO.getAlterManm() != null && !"".equals(tbmMdPlantEquipDVO.getAlterManm()) ) {
			tmpTbmMdPlantEquipDVO.setAlterManm(tbmMdPlantEquipDVO.getAlterManm());
		}		
		if ( tbmMdPlantEquipDVO.getAlterVendCode() != null && !"".equals(tbmMdPlantEquipDVO.getAlterVendCode()) ) {
			tmpTbmMdPlantEquipDVO.setAlterVendCode(tbmMdPlantEquipDVO.getAlterVendCode());
		}		
		if ( tbmMdPlantEquipDVO.getCalibTermHop() != null && !"".equals(tbmMdPlantEquipDVO.getCalibTermHop()) ) {
			tmpTbmMdPlantEquipDVO.setCalibTermHop(tbmMdPlantEquipDVO.getCalibTermHop());
		}		
		if ( tbmMdPlantEquipDVO.getCalibYn() != null && !"".equals(tbmMdPlantEquipDVO.getCalibYn()) ) {
			tmpTbmMdPlantEquipDVO.setCalibYn(tbmMdPlantEquipDVO.getCalibYn());
		}		
		if ( tbmMdPlantEquipDVO.getFprfAplyYn() != null && !"".equals(tbmMdPlantEquipDVO.getFprfAplyYn()) ) {
			tmpTbmMdPlantEquipDVO.setFprfAplyYn(tbmMdPlantEquipDVO.getFprfAplyYn());
		}		
		if ( tbmMdPlantEquipDVO.getCalibAplyYn() != null && !"".equals(tbmMdPlantEquipDVO.getCalibAplyYn()) ) {
			tmpTbmMdPlantEquipDVO.setCalibAplyYn(tbmMdPlantEquipDVO.getCalibAplyYn());
		}		
		if ( tbmMdPlantEquipDVO.getDeftSumrYn() != null && !"".equals(tbmMdPlantEquipDVO.getDeftSumrYn()) ) {
			tmpTbmMdPlantEquipDVO.setDeftSumrYn(tbmMdPlantEquipDVO.getDeftSumrYn());
		}		
		if ( tbmMdPlantEquipDVO.getIfDt() != null && !"".equals(tbmMdPlantEquipDVO.getIfDt()) ) {
			tmpTbmMdPlantEquipDVO.setIfDt(tbmMdPlantEquipDVO.getIfDt());
		}		
		if ( tbmMdPlantEquipDVO.getUseYn() != null && !"".equals(tbmMdPlantEquipDVO.getUseYn()) ) {
			tmpTbmMdPlantEquipDVO.setUseYn(tbmMdPlantEquipDVO.getUseYn());
		}		
		if ( tbmMdPlantEquipDVO.getFstRegDt() != null && !"".equals(tbmMdPlantEquipDVO.getFstRegDt()) ) {
			tmpTbmMdPlantEquipDVO.setFstRegDt(tbmMdPlantEquipDVO.getFstRegDt());
		}		
		if ( tbmMdPlantEquipDVO.getFstRegerId() != null && !"".equals(tbmMdPlantEquipDVO.getFstRegerId()) ) {
			tmpTbmMdPlantEquipDVO.setFstRegerId(tbmMdPlantEquipDVO.getFstRegerId());
		}		
		if ( tbmMdPlantEquipDVO.getFnlUpdDt() != null && !"".equals(tbmMdPlantEquipDVO.getFnlUpdDt()) ) {
			tmpTbmMdPlantEquipDVO.setFnlUpdDt(tbmMdPlantEquipDVO.getFnlUpdDt());
		}		
		if ( tbmMdPlantEquipDVO.getFnlUpderId() != null && !"".equals(tbmMdPlantEquipDVO.getFnlUpderId()) ) {
			tmpTbmMdPlantEquipDVO.setFnlUpderId(tbmMdPlantEquipDVO.getFnlUpderId());
		}		
		if ( tbmMdPlantEquipDVO.getEvtNm() != null && !"".equals(tbmMdPlantEquipDVO.getEvtNm()) ) {
			tmpTbmMdPlantEquipDVO.setEvtNm(tbmMdPlantEquipDVO.getEvtNm());
		}		
		return updateTbmMdPlantEquip (tmpTbmMdPlantEquipDVO);
	}

/**
* insertBatchTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return int[]
*/
	@LocalName("insertBatchTbmMdPlantEquip")
	public int[] insertBatchTbmMdPlantEquip (final List tbmMdPlantEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.insertBatchTbmMdPlantEquip.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        EQUIP_CODE , \n");
			sql.append("        HIST_TSP , \n");
			sql.append("        EQUIP_NM , \n");
			sql.append("        EQUIP_SPEC_CONT , \n");
			sql.append("        EQUIP_GUBUN_CODE , \n");
			sql.append("        MATR_GUBUN_CODE , \n");
			sql.append("        MATR_TYPE_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        AUTOM_YN , \n");
			sql.append("        EQUIP_SIZE , \n");
			sql.append("        SUPPLY_VEND_PN_NM , \n");
			sql.append("        SUPPLY_VEND_NM , \n");
			sql.append("        PURC_NO , \n");
			sql.append("        DF_GUBUN_CODE , \n");
			sql.append("        MOLD_NUM , \n");
			sql.append("        FAMILY_NUM , \n");
			sql.append("        CAVITY_NUM , \n");
			sql.append("        MOLD_YLD , \n");
			sql.append("        SAL_MODEL_CODE , \n");
			sql.append("        REV_NO , \n");
			sql.append("        LOCAL_EQUIP_DESC , \n");
			sql.append("        ALTER_MANM , \n");
			sql.append("        ALTER_VEND_CODE , \n");
			sql.append("        CALIB_TERM_HOP , \n");
			sql.append("        CALIB_YN , \n");
			sql.append("        FPRF_APLY_YN , \n");
			sql.append("        CALIB_APLY_YN , \n");
			sql.append("        DEFT_SUMR_YN , \n");
			sql.append("        IF_DT , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        EVT_NM \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantEquipDVO tbmMdPlantEquipDVO = (TbmMdPlantEquipDVO)tbmMdPlantEquipDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAutomYn());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getEquipSize());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendPnNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getPurcNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDfGubunCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getFamilyNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCavityNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldYld());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getRevNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getLocalEquipDesc());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterManm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterVendCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCalibTermHop());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDeftSumrYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEvtNm());

						}
							public int getBatchSize() {
									return tbmMdPlantEquipDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return int[]
*/
	@LocalName("updateBatchTbmMdPlantEquip")
	public int[] updateBatchTbmMdPlantEquip (final List tbmMdPlantEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.updateBatchTbmMdPlantEquip.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP \n");
			sql.append(" SET   \n");
			sql.append("        EQUIP_NM = ? , \n");
			sql.append("        EQUIP_SPEC_CONT = ? , \n");
			sql.append("        EQUIP_GUBUN_CODE = ? , \n");
			sql.append("        MATR_GUBUN_CODE = ? , \n");
			sql.append("        MATR_TYPE_CODE = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        AUTOM_YN = ? , \n");
			sql.append("        EQUIP_SIZE = ? , \n");
			sql.append("        SUPPLY_VEND_PN_NM = ? , \n");
			sql.append("        SUPPLY_VEND_NM = ? , \n");
			sql.append("        PURC_NO = ? , \n");
			sql.append("        DF_GUBUN_CODE = ? , \n");
			sql.append("        MOLD_NUM = ? , \n");
			sql.append("        FAMILY_NUM = ? , \n");
			sql.append("        CAVITY_NUM = ? , \n");
			sql.append("        MOLD_YLD = ? , \n");
			sql.append("        SAL_MODEL_CODE = ? , \n");
			sql.append("        REV_NO = ? , \n");
			sql.append("        LOCAL_EQUIP_DESC = ? , \n");
			sql.append("        ALTER_MANM = ? , \n");
			sql.append("        ALTER_VEND_CODE = ? , \n");
			sql.append("        CALIB_TERM_HOP = ? , \n");
			sql.append("        CALIB_YN = ? , \n");
			sql.append("        FPRF_APLY_YN = ? , \n");
			sql.append("        CALIB_APLY_YN = ? , \n");
			sql.append("        DEFT_SUMR_YN = ? , \n");
			sql.append("        IF_DT = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        EVT_NM = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND EQUIP_CODE = ? \n");
			sql.append("   AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantEquipDVO tbmMdPlantEquipDVO = (TbmMdPlantEquipDVO)tbmMdPlantEquipDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipSpecCont());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getMatrTypeCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAutomYn());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getEquipSize());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendPnNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSupplyVendNm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getPurcNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDfGubunCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getFamilyNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCavityNum());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getMoldYld());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getSalModelCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getRevNo());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getLocalEquipDesc());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterManm());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getAlterVendCode());
							ps.setBigDecimal(psCount++, tbmMdPlantEquipDVO.getCalibTermHop());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFprfAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getCalibAplyYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getDeftSumrYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getIfDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getUseYn());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEvtNm());

							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbmMdPlantEquipDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPlantEquip Method
* 
* @ref_table TBM_MD_PLANT_EQUIP
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPlantEquip")
	public int[] deleteBatchTbmMdPlantEquip (final List tbmMdPlantEquipDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPlantEquipDEM.deleteBatchTbmMdPlantEquip.001*/  \n");
			sql.append(" TBM_MD_PLANT_EQUIP \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND EQUIP_CODE = ? \n");
			sql.append("    AND HIST_TSP = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPlantEquipDVO tbmMdPlantEquipDVO = (TbmMdPlantEquipDVO)tbmMdPlantEquipDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPlantEquipDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getEquipCode());
							ps.setString(psCount++, tbmMdPlantEquipDVO.getHistTsp());
						}
							public int getBatchSize() {
									return tbmMdPlantEquipDVOList.size();
							}
					}
		);			
	}

	
}