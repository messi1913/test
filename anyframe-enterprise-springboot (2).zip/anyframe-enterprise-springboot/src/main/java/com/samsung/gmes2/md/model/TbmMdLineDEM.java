package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_LINE
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbmMdLineDEM extends AbstractDAO {


/**
* insertTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return int
*/
	@LocalName("insertTbmMdLine")
	public int insertTbmMdLine (final TbmMdLineDVO tbmMdLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdLineDEM.insertTbmMdLine.001*/  \n");
			sql.append(" TBM_MD_LINE (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        LINE_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        LINE_FORM_CODE , \n");
			sql.append("        LINE_LOC_DESC , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        TB_GUBUN_CODE , \n");
			sql.append("        PLAN_MANUAL_CRE_YN , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        WORK_START_HMS , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        RPRS_CELL_TYPE_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineNm());
							ps.setString(psCount++, tbmMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbmMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbmMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbmMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbmMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbmMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbmMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdLineDVO.getRprsCellTypeCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdLine Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdLine Method")
	public int[][] updateBatchAllTbmMdLine (final List  tbmMdLineDVOList) {
		
		ArrayList updatetbmMdLineDVOList = new ArrayList();
		ArrayList insertttbmMdLineDVOList = new ArrayList();
		ArrayList deletetbmMdLineDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdLineDVOList.size() ; i++) {
		  TbmMdLineDVO tbmMdLineDVO = (TbmMdLineDVO) tbmMdLineDVOList.get(i);
		  
		  if (tbmMdLineDVO.getSqlAction().equals("C"))
		      insertttbmMdLineDVOList.add(tbmMdLineDVO);
		  else if (tbmMdLineDVO.getSqlAction().equals("U"))
		      updatetbmMdLineDVOList.add(tbmMdLineDVO);
		  else if (tbmMdLineDVO.getSqlAction().equals("D"))
		      deletetbmMdLineDVOList.add(tbmMdLineDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdLineDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdLine(insertttbmMdLineDVOList);
          
      if (updatetbmMdLineDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdLine(updatetbmMdLineDVOList);
      
      if (deletetbmMdLineDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdLine(deletetbmMdLineDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return int
*/
	@LocalName("updateTbmMdLine")
	public int updateTbmMdLine (final TbmMdLineDVO tbmMdLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdLineDEM.updateTbmMdLine.001*/  \n");
			sql.append(" TBM_MD_LINE \n");
			sql.append(" SET   \n");
			sql.append("        LINE_NM = ? , \n");
			sql.append("        MFG_PART_CODE = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        LINE_FORM_CODE = ? , \n");
			sql.append("        LINE_LOC_DESC = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        TB_GUBUN_CODE = ? , \n");
			sql.append("        PLAN_MANUAL_CRE_YN = ? , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        WORK_START_HMS = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        TT_CALC_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        RPRS_CELL_TYPE_CODE = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdLineDVO.getLineNm());
							ps.setString(psCount++, tbmMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbmMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbmMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbmMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbmMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbmMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbmMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdLineDVO.getRprsCellTypeCode());

							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
						}
					}
		);			
	}

/**
* deleteTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return int
*/
	@LocalName("deleteTbmMdLine")
	public int deleteTbmMdLine (final TbmMdLineDVO tbmMdLineDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdLineDEM.deleteTbmMdLine.001*/  \n");
			sql.append(" TBM_MD_LINE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
						}
					}
		);			
	}

/**
* selectTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return TbmMdLineDVO 
*/
	@LocalName("selectTbmMdLine")
	public TbmMdLineDVO selectTbmMdLine (final TbmMdLineDVO tbmMdLineDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdLineDEM.selectTbmMdLine.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        LINE_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        LINE_FORM_CODE , \n");
			sql.append("        LINE_LOC_DESC , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        TB_GUBUN_CODE , \n");
			sql.append("        PLAN_MANUAL_CRE_YN , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        WORK_START_HMS , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        RPRS_CELL_TYPE_CODE \n");
			sql.append("   FROM TBM_MD_LINE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");

		return (TbmMdLineDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdLineDVO returnTbmMdLineDVO = new TbmMdLineDVO();
									returnTbmMdLineDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdLineDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdLineDVO.setLineNm(resultSet.getString("LINE_NM"));
									returnTbmMdLineDVO.setMfgPartCode(resultSet.getString("MFG_PART_CODE"));
									returnTbmMdLineDVO.setProcGubunCode(resultSet.getString("PROC_GUBUN_CODE"));
									returnTbmMdLineDVO.setLineFormCode(resultSet.getString("LINE_FORM_CODE"));
									returnTbmMdLineDVO.setLineLocDesc(resultSet.getString("LINE_LOC_DESC"));
									returnTbmMdLineDVO.setOutsYn(resultSet.getString("OUTS_YN"));
									returnTbmMdLineDVO.setTbGubunCode(resultSet.getString("TB_GUBUN_CODE"));
									returnTbmMdLineDVO.setPlanManualCreYn(resultSet.getString("PLAN_MANUAL_CRE_YN"));
									returnTbmMdLineDVO.setMainPackLineInlineYn(resultSet.getString("MAIN_PACK_LINE_INLINE_YN"));
									returnTbmMdLineDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdLineDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdLineDVO.setWorkStartHms(resultSet.getString("WORK_START_HMS"));
									returnTbmMdLineDVO.setLabelWrtCode(resultSet.getString("LABEL_WRT_CODE"));
									returnTbmMdLineDVO.setTtCalcYn(resultSet.getString("TT_CALC_YN"));
									returnTbmMdLineDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdLineDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdLineDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdLineDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdLineDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdLineDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									returnTbmMdLineDVO.setRprsCellTypeCode(resultSet.getString("RPRS_CELL_TYPE_CODE"));
									return returnTbmMdLineDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdLine Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdLine Method")
	public int mergeTbmMdLine (final TbmMdLineDVO tbmMdLineDVO) {
		
		if ( selectTbmMdLine (tbmMdLineDVO) == null) {
			return insertTbmMdLine(tbmMdLineDVO);
		} else {
			return selectUpdateTbmMdLine (tbmMdLineDVO);
		}
	}

	/**
	 * selectUpdateTbmMdLine Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdLine Method")
	public int selectUpdateTbmMdLine (final TbmMdLineDVO tbmMdLineDVO) {
		
		TbmMdLineDVO tmpTbmMdLineDVO =  selectTbmMdLine (tbmMdLineDVO);
		if ( tbmMdLineDVO.getFctCode() != null && !"".equals(tbmMdLineDVO.getFctCode()) ) {
			tmpTbmMdLineDVO.setFctCode(tbmMdLineDVO.getFctCode());
		}		
		if ( tbmMdLineDVO.getLineCode() != null && !"".equals(tbmMdLineDVO.getLineCode()) ) {
			tmpTbmMdLineDVO.setLineCode(tbmMdLineDVO.getLineCode());
		}		
		if ( tbmMdLineDVO.getLineNm() != null && !"".equals(tbmMdLineDVO.getLineNm()) ) {
			tmpTbmMdLineDVO.setLineNm(tbmMdLineDVO.getLineNm());
		}		
		if ( tbmMdLineDVO.getMfgPartCode() != null && !"".equals(tbmMdLineDVO.getMfgPartCode()) ) {
			tmpTbmMdLineDVO.setMfgPartCode(tbmMdLineDVO.getMfgPartCode());
		}		
		if ( tbmMdLineDVO.getProcGubunCode() != null && !"".equals(tbmMdLineDVO.getProcGubunCode()) ) {
			tmpTbmMdLineDVO.setProcGubunCode(tbmMdLineDVO.getProcGubunCode());
		}		
		if ( tbmMdLineDVO.getLineFormCode() != null && !"".equals(tbmMdLineDVO.getLineFormCode()) ) {
			tmpTbmMdLineDVO.setLineFormCode(tbmMdLineDVO.getLineFormCode());
		}		
		if ( tbmMdLineDVO.getLineLocDesc() != null && !"".equals(tbmMdLineDVO.getLineLocDesc()) ) {
			tmpTbmMdLineDVO.setLineLocDesc(tbmMdLineDVO.getLineLocDesc());
		}		
		if ( tbmMdLineDVO.getOutsYn() != null && !"".equals(tbmMdLineDVO.getOutsYn()) ) {
			tmpTbmMdLineDVO.setOutsYn(tbmMdLineDVO.getOutsYn());
		}		
		if ( tbmMdLineDVO.getTbGubunCode() != null && !"".equals(tbmMdLineDVO.getTbGubunCode()) ) {
			tmpTbmMdLineDVO.setTbGubunCode(tbmMdLineDVO.getTbGubunCode());
		}		
		if ( tbmMdLineDVO.getPlanManualCreYn() != null && !"".equals(tbmMdLineDVO.getPlanManualCreYn()) ) {
			tmpTbmMdLineDVO.setPlanManualCreYn(tbmMdLineDVO.getPlanManualCreYn());
		}		
		if ( tbmMdLineDVO.getMainPackLineInlineYn() != null && !"".equals(tbmMdLineDVO.getMainPackLineInlineYn()) ) {
			tmpTbmMdLineDVO.setMainPackLineInlineYn(tbmMdLineDVO.getMainPackLineInlineYn());
		}		
		if ( tbmMdLineDVO.getCatvUseYn() != null && !"".equals(tbmMdLineDVO.getCatvUseYn()) ) {
			tmpTbmMdLineDVO.setCatvUseYn(tbmMdLineDVO.getCatvUseYn());
		}		
		if ( tbmMdLineDVO.getBoardUseYn() != null && !"".equals(tbmMdLineDVO.getBoardUseYn()) ) {
			tmpTbmMdLineDVO.setBoardUseYn(tbmMdLineDVO.getBoardUseYn());
		}		
		if ( tbmMdLineDVO.getWorkStartHms() != null && !"".equals(tbmMdLineDVO.getWorkStartHms()) ) {
			tmpTbmMdLineDVO.setWorkStartHms(tbmMdLineDVO.getWorkStartHms());
		}		
		if ( tbmMdLineDVO.getLabelWrtCode() != null && !"".equals(tbmMdLineDVO.getLabelWrtCode()) ) {
			tmpTbmMdLineDVO.setLabelWrtCode(tbmMdLineDVO.getLabelWrtCode());
		}		
		if ( tbmMdLineDVO.getTtCalcYn() != null && !"".equals(tbmMdLineDVO.getTtCalcYn()) ) {
			tmpTbmMdLineDVO.setTtCalcYn(tbmMdLineDVO.getTtCalcYn());
		}		
		if ( tbmMdLineDVO.getFnlAcrsReflYn() != null && !"".equals(tbmMdLineDVO.getFnlAcrsReflYn()) ) {
			tmpTbmMdLineDVO.setFnlAcrsReflYn(tbmMdLineDVO.getFnlAcrsReflYn());
		}		
		if ( tbmMdLineDVO.getUseYn() != null && !"".equals(tbmMdLineDVO.getUseYn()) ) {
			tmpTbmMdLineDVO.setUseYn(tbmMdLineDVO.getUseYn());
		}		
		if ( tbmMdLineDVO.getFstRegDt() != null && !"".equals(tbmMdLineDVO.getFstRegDt()) ) {
			tmpTbmMdLineDVO.setFstRegDt(tbmMdLineDVO.getFstRegDt());
		}		
		if ( tbmMdLineDVO.getFstRegerId() != null && !"".equals(tbmMdLineDVO.getFstRegerId()) ) {
			tmpTbmMdLineDVO.setFstRegerId(tbmMdLineDVO.getFstRegerId());
		}		
		if ( tbmMdLineDVO.getFnlUpdDt() != null && !"".equals(tbmMdLineDVO.getFnlUpdDt()) ) {
			tmpTbmMdLineDVO.setFnlUpdDt(tbmMdLineDVO.getFnlUpdDt());
		}		
		if ( tbmMdLineDVO.getFnlUpderId() != null && !"".equals(tbmMdLineDVO.getFnlUpderId()) ) {
			tmpTbmMdLineDVO.setFnlUpderId(tbmMdLineDVO.getFnlUpderId());
		}		
		if ( tbmMdLineDVO.getRprsCellTypeCode() != null && !"".equals(tbmMdLineDVO.getRprsCellTypeCode()) ) {
			tmpTbmMdLineDVO.setRprsCellTypeCode(tbmMdLineDVO.getRprsCellTypeCode());
		}		
		return updateTbmMdLine (tmpTbmMdLineDVO);
	}

/**
* insertBatchTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return int[]
*/
	@LocalName("insertBatchTbmMdLine")
	public int[] insertBatchTbmMdLine (final List tbmMdLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdLineDEM.insertBatchTbmMdLine.001*/  \n");
			sql.append(" TBM_MD_LINE (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        LINE_CODE , \n");
			sql.append("        LINE_NM , \n");
			sql.append("        MFG_PART_CODE , \n");
			sql.append("        PROC_GUBUN_CODE , \n");
			sql.append("        LINE_FORM_CODE , \n");
			sql.append("        LINE_LOC_DESC , \n");
			sql.append("        OUTS_YN , \n");
			sql.append("        TB_GUBUN_CODE , \n");
			sql.append("        PLAN_MANUAL_CRE_YN , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN , \n");
			sql.append("        CATV_USE_YN , \n");
			sql.append("        BOARD_USE_YN , \n");
			sql.append("        WORK_START_HMS , \n");
			sql.append("        LABEL_WRT_CODE , \n");
			sql.append("        TT_CALC_YN , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID , \n");
			sql.append("        RPRS_CELL_TYPE_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdLineDVO tbmMdLineDVO = (TbmMdLineDVO)tbmMdLineDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineNm());
							ps.setString(psCount++, tbmMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbmMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbmMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbmMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbmMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbmMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbmMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdLineDVO.getRprsCellTypeCode());

						}
							public int getBatchSize() {
									return tbmMdLineDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return int[]
*/
	@LocalName("updateBatchTbmMdLine")
	public int[] updateBatchTbmMdLine (final List tbmMdLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdLineDEM.updateBatchTbmMdLine.001*/  \n");
			sql.append(" TBM_MD_LINE \n");
			sql.append(" SET   \n");
			sql.append("        LINE_NM = ? , \n");
			sql.append("        MFG_PART_CODE = ? , \n");
			sql.append("        PROC_GUBUN_CODE = ? , \n");
			sql.append("        LINE_FORM_CODE = ? , \n");
			sql.append("        LINE_LOC_DESC = ? , \n");
			sql.append("        OUTS_YN = ? , \n");
			sql.append("        TB_GUBUN_CODE = ? , \n");
			sql.append("        PLAN_MANUAL_CRE_YN = ? , \n");
			sql.append("        MAIN_PACK_LINE_INLINE_YN = ? , \n");
			sql.append("        CATV_USE_YN = ? , \n");
			sql.append("        BOARD_USE_YN = ? , \n");
			sql.append("        WORK_START_HMS = ? , \n");
			sql.append("        LABEL_WRT_CODE = ? , \n");
			sql.append("        TT_CALC_YN = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? , \n");
			sql.append("        RPRS_CELL_TYPE_CODE = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND LINE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdLineDVO tbmMdLineDVO = (TbmMdLineDVO)tbmMdLineDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdLineDVO.getLineNm());
							ps.setString(psCount++, tbmMdLineDVO.getMfgPartCode());
							ps.setString(psCount++, tbmMdLineDVO.getProcGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineFormCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineLocDesc());
							ps.setString(psCount++, tbmMdLineDVO.getOutsYn());
							ps.setString(psCount++, tbmMdLineDVO.getTbGubunCode());
							ps.setString(psCount++, tbmMdLineDVO.getPlanManualCreYn());
							ps.setString(psCount++, tbmMdLineDVO.getMainPackLineInlineYn());
							ps.setString(psCount++, tbmMdLineDVO.getCatvUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getBoardUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getWorkStartHms());
							ps.setString(psCount++, tbmMdLineDVO.getLabelWrtCode());
							ps.setString(psCount++, tbmMdLineDVO.getTtCalcYn());
							ps.setString(psCount++, tbmMdLineDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbmMdLineDVO.getUseYn());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdLineDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdLineDVO.getFnlUpderId());
							ps.setString(psCount++, tbmMdLineDVO.getRprsCellTypeCode());

							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
						}
							public int getBatchSize() {
									return tbmMdLineDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdLine Method
* 
* @ref_table TBM_MD_LINE
* @return int[]
*/
	@LocalName("deleteBatchTbmMdLine")
	public int[] deleteBatchTbmMdLine (final List tbmMdLineDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdLineDEM.deleteBatchTbmMdLine.001*/  \n");
			sql.append(" TBM_MD_LINE \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND LINE_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdLineDVO tbmMdLineDVO = (TbmMdLineDVO)tbmMdLineDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdLineDVO.getFctCode());
							ps.setString(psCount++, tbmMdLineDVO.getLineCode());
						}
							public int getBatchSize() {
									return tbmMdLineDVOList.size();
							}
					}
		);			
	}

	
}