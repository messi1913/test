package com.samsung.gmes2.md.material.biz;

public class MdManagePhoconPjtBiz {

	/**
	 * 현상기Project 목록 조회
	 */
	public void listPhoconPjt(){}

	/**
	 * Project Alias 목록 조회(Combo용)
	 */
	public void listPjtAlias(){}

	/**
	 * 현상기Project 목록 저장
	 */
	public void savePhoconPjt(){}

}
