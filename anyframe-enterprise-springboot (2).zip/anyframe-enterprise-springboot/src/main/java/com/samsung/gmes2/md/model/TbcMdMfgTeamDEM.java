package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MFG_TEAM
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbcMdMfgTeamDEM extends AbstractDAO {


/**
* insertTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return int
*/
	@LocalName("insertTbcMdMfgTeam")
	public int insertTbcMdMfgTeam (final TbcMdMfgTeamDVO tbcMdMfgTeamDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.insertTbcMdMfgTeam.001*/  \n");
			sql.append(" TBC_MD_MFG_TEAM (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        PID_EMP_NO , \n");
			sql.append("        MFG_TEAM_NM , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getPidEmpNo());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamNm());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdMfgTeam Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdMfgTeam Method")
	public int[][] updateBatchAllTbcMdMfgTeam (final List  tbcMdMfgTeamDVOList) {
		
		ArrayList updatetbcMdMfgTeamDVOList = new ArrayList();
		ArrayList insertttbcMdMfgTeamDVOList = new ArrayList();
		ArrayList deletetbcMdMfgTeamDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdMfgTeamDVOList.size() ; i++) {
		  TbcMdMfgTeamDVO tbcMdMfgTeamDVO = (TbcMdMfgTeamDVO) tbcMdMfgTeamDVOList.get(i);
		  
		  if (tbcMdMfgTeamDVO.getSqlAction().equals("C"))
		      insertttbcMdMfgTeamDVOList.add(tbcMdMfgTeamDVO);
		  else if (tbcMdMfgTeamDVO.getSqlAction().equals("U"))
		      updatetbcMdMfgTeamDVOList.add(tbcMdMfgTeamDVO);
		  else if (tbcMdMfgTeamDVO.getSqlAction().equals("D"))
		      deletetbcMdMfgTeamDVOList.add(tbcMdMfgTeamDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdMfgTeamDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdMfgTeam(insertttbcMdMfgTeamDVOList);
          
      if (updatetbcMdMfgTeamDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdMfgTeam(updatetbcMdMfgTeamDVOList);
      
      if (deletetbcMdMfgTeamDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdMfgTeam(deletetbcMdMfgTeamDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return int
*/
	@LocalName("updateTbcMdMfgTeam")
	public int updateTbcMdMfgTeam (final TbcMdMfgTeamDVO tbcMdMfgTeamDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.updateTbcMdMfgTeam.001*/  \n");
			sql.append(" TBC_MD_MFG_TEAM \n");
			sql.append(" SET   \n");
			sql.append("        PID_EMP_NO = ? , \n");
			sql.append("        MFG_TEAM_NM = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_TEAM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgTeamDVO.getPidEmpNo());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamNm());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
						}
					}
		);			
	}

/**
* deleteTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return int
*/
	@LocalName("deleteTbcMdMfgTeam")
	public int deleteTbcMdMfgTeam (final TbcMdMfgTeamDVO tbcMdMfgTeamDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.deleteTbcMdMfgTeam.001*/  \n");
			sql.append(" TBC_MD_MFG_TEAM \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_TEAM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
						}
					}
		);			
	}

/**
* selectTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return TbcMdMfgTeamDVO 
*/
	@LocalName("selectTbcMdMfgTeam")
	public TbcMdMfgTeamDVO selectTbcMdMfgTeam (final TbcMdMfgTeamDVO tbcMdMfgTeamDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.selectTbcMdMfgTeam.001*/  \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        PID_EMP_NO , \n");
			sql.append("        MFG_TEAM_NM , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MFG_TEAM \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_TEAM_CODE = ? \n");

		return (TbcMdMfgTeamDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdMfgTeamDVO returnTbcMdMfgTeamDVO = new TbcMdMfgTeamDVO();
									returnTbcMdMfgTeamDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbcMdMfgTeamDVO.setMfgTeamCode(resultSet.getString("MFG_TEAM_CODE"));
									returnTbcMdMfgTeamDVO.setPidEmpNo(resultSet.getString("PID_EMP_NO"));
									returnTbcMdMfgTeamDVO.setMfgTeamNm(resultSet.getString("MFG_TEAM_NM"));
									returnTbcMdMfgTeamDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbcMdMfgTeamDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdMfgTeamDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdMfgTeamDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdMfgTeamDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdMfgTeamDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdMfgTeamDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdMfgTeam Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdMfgTeam Method")
	public int mergeTbcMdMfgTeam (final TbcMdMfgTeamDVO tbcMdMfgTeamDVO) {
		
		if ( selectTbcMdMfgTeam (tbcMdMfgTeamDVO) == null) {
			return insertTbcMdMfgTeam(tbcMdMfgTeamDVO);
		} else {
			return selectUpdateTbcMdMfgTeam (tbcMdMfgTeamDVO);
		}
	}

	/**
	 * selectUpdateTbcMdMfgTeam Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdMfgTeam Method")
	public int selectUpdateTbcMdMfgTeam (final TbcMdMfgTeamDVO tbcMdMfgTeamDVO) {
		
		TbcMdMfgTeamDVO tmpTbcMdMfgTeamDVO =  selectTbcMdMfgTeam (tbcMdMfgTeamDVO);
		if ( tbcMdMfgTeamDVO.getFctCode() != null && !"".equals(tbcMdMfgTeamDVO.getFctCode()) ) {
			tmpTbcMdMfgTeamDVO.setFctCode(tbcMdMfgTeamDVO.getFctCode());
		}		
		if ( tbcMdMfgTeamDVO.getMfgTeamCode() != null && !"".equals(tbcMdMfgTeamDVO.getMfgTeamCode()) ) {
			tmpTbcMdMfgTeamDVO.setMfgTeamCode(tbcMdMfgTeamDVO.getMfgTeamCode());
		}		
		if ( tbcMdMfgTeamDVO.getPidEmpNo() != null && !"".equals(tbcMdMfgTeamDVO.getPidEmpNo()) ) {
			tmpTbcMdMfgTeamDVO.setPidEmpNo(tbcMdMfgTeamDVO.getPidEmpNo());
		}		
		if ( tbcMdMfgTeamDVO.getMfgTeamNm() != null && !"".equals(tbcMdMfgTeamDVO.getMfgTeamNm()) ) {
			tmpTbcMdMfgTeamDVO.setMfgTeamNm(tbcMdMfgTeamDVO.getMfgTeamNm());
		}		
		if ( tbcMdMfgTeamDVO.getFnlAcrsReflYn() != null && !"".equals(tbcMdMfgTeamDVO.getFnlAcrsReflYn()) ) {
			tmpTbcMdMfgTeamDVO.setFnlAcrsReflYn(tbcMdMfgTeamDVO.getFnlAcrsReflYn());
		}		
		if ( tbcMdMfgTeamDVO.getUseYn() != null && !"".equals(tbcMdMfgTeamDVO.getUseYn()) ) {
			tmpTbcMdMfgTeamDVO.setUseYn(tbcMdMfgTeamDVO.getUseYn());
		}		
		if ( tbcMdMfgTeamDVO.getFstRegDt() != null && !"".equals(tbcMdMfgTeamDVO.getFstRegDt()) ) {
			tmpTbcMdMfgTeamDVO.setFstRegDt(tbcMdMfgTeamDVO.getFstRegDt());
		}		
		if ( tbcMdMfgTeamDVO.getFstRegerId() != null && !"".equals(tbcMdMfgTeamDVO.getFstRegerId()) ) {
			tmpTbcMdMfgTeamDVO.setFstRegerId(tbcMdMfgTeamDVO.getFstRegerId());
		}		
		if ( tbcMdMfgTeamDVO.getFnlUpdDt() != null && !"".equals(tbcMdMfgTeamDVO.getFnlUpdDt()) ) {
			tmpTbcMdMfgTeamDVO.setFnlUpdDt(tbcMdMfgTeamDVO.getFnlUpdDt());
		}		
		if ( tbcMdMfgTeamDVO.getFnlUpderId() != null && !"".equals(tbcMdMfgTeamDVO.getFnlUpderId()) ) {
			tmpTbcMdMfgTeamDVO.setFnlUpderId(tbcMdMfgTeamDVO.getFnlUpderId());
		}		
		return updateTbcMdMfgTeam (tmpTbcMdMfgTeamDVO);
	}

/**
* insertBatchTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return int[]
*/
	@LocalName("insertBatchTbcMdMfgTeam")
	public int[] insertBatchTbcMdMfgTeam (final List tbcMdMfgTeamDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.insertBatchTbcMdMfgTeam.001*/  \n");
			sql.append(" TBC_MD_MFG_TEAM (   \n");
			sql.append("        FCT_CODE , \n");
			sql.append("        MFG_TEAM_CODE , \n");
			sql.append("        PID_EMP_NO , \n");
			sql.append("        MFG_TEAM_NM , \n");
			sql.append("        FNL_ACRS_REFL_YN , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgTeamDVO tbcMdMfgTeamDVO = (TbcMdMfgTeamDVO)tbcMdMfgTeamDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getPidEmpNo());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamNm());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdMfgTeamDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return int[]
*/
	@LocalName("updateBatchTbcMdMfgTeam")
	public int[] updateBatchTbcMdMfgTeam (final List tbcMdMfgTeamDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.updateBatchTbcMdMfgTeam.001*/  \n");
			sql.append(" TBC_MD_MFG_TEAM \n");
			sql.append(" SET   \n");
			sql.append("        PID_EMP_NO = ? , \n");
			sql.append("        MFG_TEAM_NM = ? , \n");
			sql.append("        FNL_ACRS_REFL_YN = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE FCT_CODE = ? \n");
			sql.append("   AND MFG_TEAM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgTeamDVO tbcMdMfgTeamDVO = (TbcMdMfgTeamDVO)tbcMdMfgTeamDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdMfgTeamDVO.getPidEmpNo());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamNm());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlAcrsReflYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getUseYn());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
						}
							public int getBatchSize() {
									return tbcMdMfgTeamDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdMfgTeam Method
* 
* @ref_table TBC_MD_MFG_TEAM
* @return int[]
*/
	@LocalName("deleteBatchTbcMdMfgTeam")
	public int[] deleteBatchTbcMdMfgTeam (final List tbcMdMfgTeamDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdMfgTeamDEM.deleteBatchTbcMdMfgTeam.001*/  \n");
			sql.append(" TBC_MD_MFG_TEAM \n");
			sql.append("  WHERE FCT_CODE = ? \n");
			sql.append("    AND MFG_TEAM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdMfgTeamDVO tbcMdMfgTeamDVO = (TbcMdMfgTeamDVO)tbcMdMfgTeamDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdMfgTeamDVO.getFctCode());
							ps.setString(psCount++, tbcMdMfgTeamDVO.getMfgTeamCode());
						}
							public int getBatchSize() {
									return tbcMdMfgTeamDVOList.size();
							}
					}
		);			
	}

	
}