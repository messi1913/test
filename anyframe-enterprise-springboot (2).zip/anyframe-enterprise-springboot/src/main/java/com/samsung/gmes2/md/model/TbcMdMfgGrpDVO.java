package com.samsung.gmes2.md.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 제조그룹 조회를 하기 위한 DVO
 * @stereotype DAOVO
 * @author shim
 */
@LocalName("제조그룹 조회")
public class TbcMdMfgGrpDVO extends AbstractDVO {

	@Length(30) @NotNull
	private String fctCode;

	@Length(30) @NotNull
	private String mfgGrpCode;

	@Length(500) 
	private String mfgGrpNm;

	@Length(30) 
	private String mfgTeamCode;

	@Length(50) 
	private String grpRprsEmpNo;

	@Length(1) 
	private String outsYn;

	@Length(1) 
	private String fnlAcrsReflYn;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getFctCode() {
		this.fctCode = super.getValue("fctCode");
		return this.fctCode;
	}

	public void setFctCode(String fctCode) {
        super.setValue("fctCode", fctCode);
		this.fctCode = fctCode;
	}
	
	public String getMfgGrpCode() {
		this.mfgGrpCode = super.getValue("mfgGrpCode");
		return this.mfgGrpCode;
	}

	public void setMfgGrpCode(String mfgGrpCode) {
        super.setValue("mfgGrpCode", mfgGrpCode);
		this.mfgGrpCode = mfgGrpCode;
	}
	
	public String getMfgGrpNm() {
		this.mfgGrpNm = super.getValue("mfgGrpNm");
		return this.mfgGrpNm;
	}

	public void setMfgGrpNm(String mfgGrpNm) {
        super.setValue("mfgGrpNm", mfgGrpNm);
		this.mfgGrpNm = mfgGrpNm;
	}
	
	public String getMfgTeamCode() {
		this.mfgTeamCode = super.getValue("mfgTeamCode");
		return this.mfgTeamCode;
	}

	public void setMfgTeamCode(String mfgTeamCode) {
        super.setValue("mfgTeamCode", mfgTeamCode);
		this.mfgTeamCode = mfgTeamCode;
	}
	
	public String getGrpRprsEmpNo() {
		this.grpRprsEmpNo = super.getValue("grpRprsEmpNo");
		return this.grpRprsEmpNo;
	}

	public void setGrpRprsEmpNo(String grpRprsEmpNo) {
        super.setValue("grpRprsEmpNo", grpRprsEmpNo);
		this.grpRprsEmpNo = grpRprsEmpNo;
	}
	
	public String getOutsYn() {
		this.outsYn = super.getValue("outsYn");
		return this.outsYn;
	}

	public void setOutsYn(String outsYn) {
        super.setValue("outsYn", outsYn);
		this.outsYn = outsYn;
	}
	
	public String getFnlAcrsReflYn() {
		this.fnlAcrsReflYn = super.getValue("fnlAcrsReflYn");
		return this.fnlAcrsReflYn;
	}

	public void setFnlAcrsReflYn(String fnlAcrsReflYn) {
        super.setValue("fnlAcrsReflYn", fnlAcrsReflYn);
		this.fnlAcrsReflYn = fnlAcrsReflYn;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue("useYn");
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue("useYn", useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue("fstRegDt");
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue("fstRegDt", fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue("fstRegerId");
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue("fstRegerId", fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue("fnlUpdDt");
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue("fnlUpdDt", fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue("fnlUpderId");
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue("fnlUpderId", fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}