package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbmMcStandFrmDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String standFrmCode;

	@Length(50) 
	private String frmCtgrCode;

	@Length(500) 
	private String frmNm;

	@Length(1000) 
	private String frmDesc;


	public String getStandFrmCode() {
		this.standFrmCode = super.getValue("standFrmCode");
		return this.standFrmCode;
	}

	public void setStandFrmCode(String standFrmCode) {
        super.setValue("standFrmCode", standFrmCode);
		this.standFrmCode = standFrmCode;
	}
	
	public String getFrmCtgrCode() {
		this.frmCtgrCode = super.getValue("frmCtgrCode");
		return this.frmCtgrCode;
	}

	public void setFrmCtgrCode(String frmCtgrCode) {
        super.setValue("frmCtgrCode", frmCtgrCode);
		this.frmCtgrCode = frmCtgrCode;
	}
	
	public String getFrmNm() {
		this.frmNm = super.getValue("frmNm");
		return this.frmNm;
	}

	public void setFrmNm(String frmNm) {
        super.setValue("frmNm", frmNm);
		this.frmNm = frmNm;
	}
	
	public String getFrmDesc() {
		this.frmDesc = super.getValue("frmDesc");
		return this.frmDesc;
	}

	public void setFrmDesc(String frmDesc) {
        super.setValue("frmDesc", frmDesc);
		this.frmDesc = frmDesc;
	}
	
}