package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbmMdProcDQM extends AbstractDAO {


/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	UNIT_PROC_CODE, 
* 	PROC_NM, 
* 	BCD_SUMR_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	OPER_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	AUTO_STOP_YN, 
* 	EARLY_ALRM_YN, 
* 	INLINE_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_PROC 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($unitProcCode) 
* AND UNIT_PROC_CODE = :unitProcCode 
* #end 
* #if($procNm) 
* AND PROC_NM = :procNm 
* #end 
* #if($bcdSumrYn) 
* AND BCD_SUMR_YN = :bcdSumrYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($operYn) 
* AND OPER_YN = :operYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($autoStopYn) 
* AND AUTO_STOP_YN = :autoStopYn 
* #end 
* #if($earlyAlrmYn) 
* AND EARLY_ALRM_YN = :earlyAlrmYn 
* #end 
* #if($inlineGubunCode) 
* AND INLINE_GUBUN_CODE = :inlineGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	UNIT_PROC_CODE,  \n");
			sql.append(" 	PROC_NM,  \n");
			sql.append(" 	BCD_SUMR_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OPER_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	AUTO_STOP_YN,  \n");
			sql.append(" 	EARLY_ALRM_YN,  \n");
			sql.append(" 	INLINE_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_PROC  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($unitProcCode)  \n");
			sql.append(" AND UNIT_PROC_CODE = :unitProcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procNm)  \n");
			sql.append(" AND PROC_NM = :procNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($bcdSumrYn)  \n");
			sql.append(" AND BCD_SUMR_YN = :bcdSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operYn)  \n");
			sql.append(" AND OPER_YN = :operYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($autoStopYn)  \n");
			sql.append(" AND AUTO_STOP_YN = :autoStopYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($earlyAlrmYn)  \n");
			sql.append(" AND EARLY_ALRM_YN = :earlyAlrmYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inlineGubunCode)  \n");
			sql.append(" AND INLINE_GUBUN_CODE = :inlineGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdProcDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdProcDVO returnTbmMdProcDVO = new TbmMdProcDVO();
									returnTbmMdProcDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdProcDVO.setProcNm(resultSet.getString("PROC_NM"));
									returnTbmMdProcDVO.setBcdSumrYn(resultSet.getString("BCD_SUMR_YN"));
									returnTbmMdProcDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdProcDVO.setOperYn(resultSet.getString("OPER_YN"));
									returnTbmMdProcDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdProcDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdProcDVO.setAutoStopYn(resultSet.getString("AUTO_STOP_YN"));
									returnTbmMdProcDVO.setEarlyAlrmYn(resultSet.getString("EARLY_ALRM_YN"));
									returnTbmMdProcDVO.setInlineGubunCode(resultSet.getString("INLINE_GUBUN_CODE"));
									returnTbmMdProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdProcDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	UNIT_PROC_CODE, 
* 	PROC_NM, 
* 	BCD_SUMR_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	OPER_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	AUTO_STOP_YN, 
* 	EARLY_ALRM_YN, 
* 	INLINE_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_PROC 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($unitProcCode) 
* AND UNIT_PROC_CODE = :unitProcCode 
* #end 
* #if($procNm) 
* AND PROC_NM = :procNm 
* #end 
* #if($bcdSumrYn) 
* AND BCD_SUMR_YN = :bcdSumrYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($operYn) 
* AND OPER_YN = :operYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($autoStopYn) 
* AND AUTO_STOP_YN = :autoStopYn 
* #end 
* #if($earlyAlrmYn) 
* AND EARLY_ALRM_YN = :earlyAlrmYn 
* #end 
* #if($inlineGubunCode) 
* AND INLINE_GUBUN_CODE = :inlineGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	UNIT_PROC_CODE,  \n");
			sql.append(" 	PROC_NM,  \n");
			sql.append(" 	BCD_SUMR_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OPER_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	AUTO_STOP_YN,  \n");
			sql.append(" 	EARLY_ALRM_YN,  \n");
			sql.append(" 	INLINE_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_PROC  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($unitProcCode)  \n");
			sql.append(" AND UNIT_PROC_CODE = :unitProcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procNm)  \n");
			sql.append(" AND PROC_NM = :procNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($bcdSumrYn)  \n");
			sql.append(" AND BCD_SUMR_YN = :bcdSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operYn)  \n");
			sql.append(" AND OPER_YN = :operYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($autoStopYn)  \n");
			sql.append(" AND AUTO_STOP_YN = :autoStopYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($earlyAlrmYn)  \n");
			sql.append(" AND EARLY_ALRM_YN = :earlyAlrmYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inlineGubunCode)  \n");
			sql.append(" AND INLINE_GUBUN_CODE = :inlineGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdProcDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdProcDVO returnTbmMdProcDVO = new TbmMdProcDVO();
									returnTbmMdProcDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdProcDVO.setProcNm(resultSet.getString("PROC_NM"));
									returnTbmMdProcDVO.setBcdSumrYn(resultSet.getString("BCD_SUMR_YN"));
									returnTbmMdProcDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdProcDVO.setOperYn(resultSet.getString("OPER_YN"));
									returnTbmMdProcDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdProcDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdProcDVO.setAutoStopYn(resultSet.getString("AUTO_STOP_YN"));
									returnTbmMdProcDVO.setEarlyAlrmYn(resultSet.getString("EARLY_ALRM_YN"));
									returnTbmMdProcDVO.setInlineGubunCode(resultSet.getString("INLINE_GUBUN_CODE"));
									returnTbmMdProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdProcDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	UNIT_PROC_CODE, 
* 	PROC_NM, 
* 	BCD_SUMR_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	OPER_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	AUTO_STOP_YN, 
* 	EARLY_ALRM_YN, 
* 	INLINE_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_PROC 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($unitProcCode) 
* AND UNIT_PROC_CODE = :unitProcCode 
* #end 
* #if($procNm) 
* AND PROC_NM = :procNm 
* #end 
* #if($bcdSumrYn) 
* AND BCD_SUMR_YN = :bcdSumrYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($operYn) 
* AND OPER_YN = :operYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($autoStopYn) 
* AND AUTO_STOP_YN = :autoStopYn 
* #end 
* #if($earlyAlrmYn) 
* AND EARLY_ALRM_YN = :earlyAlrmYn 
* #end 
* #if($inlineGubunCode) 
* AND INLINE_GUBUN_CODE = :inlineGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	UNIT_PROC_CODE,  \n");
			sql.append(" 	PROC_NM,  \n");
			sql.append(" 	BCD_SUMR_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OPER_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	AUTO_STOP_YN,  \n");
			sql.append(" 	EARLY_ALRM_YN,  \n");
			sql.append(" 	INLINE_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_PROC  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($unitProcCode)  \n");
			sql.append(" AND UNIT_PROC_CODE = :unitProcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procNm)  \n");
			sql.append(" AND PROC_NM = :procNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($bcdSumrYn)  \n");
			sql.append(" AND BCD_SUMR_YN = :bcdSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operYn)  \n");
			sql.append(" AND OPER_YN = :operYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($autoStopYn)  \n");
			sql.append(" AND AUTO_STOP_YN = :autoStopYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($earlyAlrmYn)  \n");
			sql.append(" AND EARLY_ALRM_YN = :earlyAlrmYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inlineGubunCode)  \n");
			sql.append(" AND INLINE_GUBUN_CODE = :inlineGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdProcDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdProcDVO returnTbmMdProcDVO = new TbmMdProcDVO();
									returnTbmMdProcDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdProcDVO.setProcNm(resultSet.getString("PROC_NM"));
									returnTbmMdProcDVO.setBcdSumrYn(resultSet.getString("BCD_SUMR_YN"));
									returnTbmMdProcDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdProcDVO.setOperYn(resultSet.getString("OPER_YN"));
									returnTbmMdProcDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdProcDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdProcDVO.setAutoStopYn(resultSet.getString("AUTO_STOP_YN"));
									returnTbmMdProcDVO.setEarlyAlrmYn(resultSet.getString("EARLY_ALRM_YN"));
									returnTbmMdProcDVO.setInlineGubunCode(resultSet.getString("INLINE_GUBUN_CODE"));
									returnTbmMdProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdProcDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	FCT_CODE, 
* 	LINE_CODE, 
* 	UNIT_PROC_CODE, 
* 	PROC_NM, 
* 	BCD_SUMR_YN, 
* 	FNL_ACRS_REFL_YN, 
* 	OPER_YN, 
* 	CATV_USE_YN, 
* 	BOARD_USE_YN, 
* 	AUTO_STOP_YN, 
* 	EARLY_ALRM_YN, 
* 	INLINE_GUBUN_CODE, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBM_MD_PROC 
* WHERE 1=1 
* #if($fctCode) 
* AND FCT_CODE = :fctCode 
* #end 
* #if($lineCode) 
* AND LINE_CODE = :lineCode 
* #end 
* #if($unitProcCode) 
* AND UNIT_PROC_CODE = :unitProcCode 
* #end 
* #if($procNm) 
* AND PROC_NM = :procNm 
* #end 
* #if($bcdSumrYn) 
* AND BCD_SUMR_YN = :bcdSumrYn 
* #end 
* #if($fnlAcrsReflYn) 
* AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn 
* #end 
* #if($operYn) 
* AND OPER_YN = :operYn 
* #end 
* #if($catvUseYn) 
* AND CATV_USE_YN = :catvUseYn 
* #end 
* #if($boardUseYn) 
* AND BOARD_USE_YN = :boardUseYn 
* #end 
* #if($autoStopYn) 
* AND AUTO_STOP_YN = :autoStopYn 
* #end 
* #if($earlyAlrmYn) 
* AND EARLY_ALRM_YN = :earlyAlrmYn 
* #end 
* #if($inlineGubunCode) 
* AND INLINE_GUBUN_CODE = :inlineGubunCode 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	FCT_CODE,  \n");
			sql.append(" 	LINE_CODE,  \n");
			sql.append(" 	UNIT_PROC_CODE,  \n");
			sql.append(" 	PROC_NM,  \n");
			sql.append(" 	BCD_SUMR_YN,  \n");
			sql.append(" 	FNL_ACRS_REFL_YN,  \n");
			sql.append(" 	OPER_YN,  \n");
			sql.append(" 	CATV_USE_YN,  \n");
			sql.append(" 	BOARD_USE_YN,  \n");
			sql.append(" 	AUTO_STOP_YN,  \n");
			sql.append(" 	EARLY_ALRM_YN,  \n");
			sql.append(" 	INLINE_GUBUN_CODE,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBM_MD_PROC  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($fctCode)  \n");
			sql.append(" AND FCT_CODE = :fctCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($lineCode)  \n");
			sql.append(" AND LINE_CODE = :lineCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($unitProcCode)  \n");
			sql.append(" AND UNIT_PROC_CODE = :unitProcCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($procNm)  \n");
			sql.append(" AND PROC_NM = :procNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($bcdSumrYn)  \n");
			sql.append(" AND BCD_SUMR_YN = :bcdSumrYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlAcrsReflYn)  \n");
			sql.append(" AND FNL_ACRS_REFL_YN = :fnlAcrsReflYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($operYn)  \n");
			sql.append(" AND OPER_YN = :operYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($catvUseYn)  \n");
			sql.append(" AND CATV_USE_YN = :catvUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($boardUseYn)  \n");
			sql.append(" AND BOARD_USE_YN = :boardUseYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($autoStopYn)  \n");
			sql.append(" AND AUTO_STOP_YN = :autoStopYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($earlyAlrmYn)  \n");
			sql.append(" AND EARLY_ALRM_YN = :earlyAlrmYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inlineGubunCode)  \n");
			sql.append(" AND INLINE_GUBUN_CODE = :inlineGubunCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbmMdProcDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbmMdProcDVO returnTbmMdProcDVO = new TbmMdProcDVO();
									returnTbmMdProcDVO.setFctCode(resultSet.getString("FCT_CODE"));
									returnTbmMdProcDVO.setLineCode(resultSet.getString("LINE_CODE"));
									returnTbmMdProcDVO.setUnitProcCode(resultSet.getString("UNIT_PROC_CODE"));
									returnTbmMdProcDVO.setProcNm(resultSet.getString("PROC_NM"));
									returnTbmMdProcDVO.setBcdSumrYn(resultSet.getString("BCD_SUMR_YN"));
									returnTbmMdProcDVO.setFnlAcrsReflYn(resultSet.getString("FNL_ACRS_REFL_YN"));
									returnTbmMdProcDVO.setOperYn(resultSet.getString("OPER_YN"));
									returnTbmMdProcDVO.setCatvUseYn(resultSet.getString("CATV_USE_YN"));
									returnTbmMdProcDVO.setBoardUseYn(resultSet.getString("BOARD_USE_YN"));
									returnTbmMdProcDVO.setAutoStopYn(resultSet.getString("AUTO_STOP_YN"));
									returnTbmMdProcDVO.setEarlyAlrmYn(resultSet.getString("EARLY_ALRM_YN"));
									returnTbmMdProcDVO.setInlineGubunCode(resultSet.getString("INLINE_GUBUN_CODE"));
									returnTbmMdProcDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbmMdProcDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdProcDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdProcDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdProcDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdProcDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}