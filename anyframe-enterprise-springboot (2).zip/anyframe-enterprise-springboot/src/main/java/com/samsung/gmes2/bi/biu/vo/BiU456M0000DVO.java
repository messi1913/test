package com.samsung.gmes2.bi.biu.vo;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author kwjfresh
 */
@LocalName("수율현황 조회 DVO")
public class BiU456M0000DVO extends AbstractVo {

	@LocalName("조회기간") @Length(8) 
	private String toDate;

	@LocalName("조회기간") @Length(8) 
	private String fromDate;

	@LocalName("설비그룹") @Length(3) 
	private String lineCode;

	@LocalName("조회조건") @Length(2) 
	private String timePoint;

	@LocalName("PO 상태 조건") @Length(1) 
	private String poState;

	@LocalName("조회기간") @Length(4) 
	private String toYear;

	@LocalName("조회기간") @Length(4) 
	private String fromYear;

	@LocalName("조회기간") @Length(2) 
	private String toWeek;

	@LocalName("조회기간") @Length(2) 
	private String fromWeek;

	@LocalName("조회기간") @Length(2) 
	private String toMonth;

	@LocalName("조회기간") @Length(2) 
	private String fromMonth;


	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getToDate() {
		this.toDate = super.getValue(0);
		return this.toDate;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setToDate(String toDate) {
        super.setValue(0, toDate);
		this.toDate = toDate;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getFromDate() {
		this.fromDate = super.getValue(1);
		return this.fromDate;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setFromDate(String fromDate) {
        super.setValue(1, fromDate);
		this.fromDate = fromDate;
	}
	
	/**
	 * 설비그룹 Getter Method
	 * 
	 * @return 설비그룹
	 */
	@LocalName("설비그룹 Getter Method")
	public String getLineCode() {
		this.lineCode = super.getValue(2);
		return this.lineCode;
	}

	/**
	 * 설비그룹 Setter Method
	 * 
	 * @param String 설비그룹
	 */
	@LocalName("설비그룹 Setter Method")
	public void setLineCode(String lineCode) {
        super.setValue(2, lineCode);
		this.lineCode = lineCode;
	}
	
	/**
	 * 조회조건 Getter Method
	 * 
	 * @return 조회조건
	 */
	@LocalName("조회조건 Getter Method")
	public String getTimePoint() {
		this.timePoint = super.getValue(3);
		return this.timePoint;
	}

	/**
	 * 조회조건 Setter Method
	 * 
	 * @param String 조회조건
	 */
	@LocalName("조회조건 Setter Method")
	public void setTimePoint(String timePoint) {
        super.setValue(3, timePoint);
		this.timePoint = timePoint;
	}
	
	/**
	 * PO 상태 조건 Getter Method
	 * 
	 * @return PO 상태 조건
	 */
	@LocalName("PO 상태 조건 Getter Method")
	public String getPoState() {
		this.poState = super.getValue(4);
		return this.poState;
	}

	/**
	 * PO 상태 조건 Setter Method
	 * 
	 * @param String PO 상태 조건
	 */
	@LocalName("PO 상태 조건 Setter Method")
	public void setPoState(String poState) {
        super.setValue(4, poState);
		this.poState = poState;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getToYear() {
		this.toYear = super.getValue(5);
		return this.toYear;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setToYear(String toYear) {
        super.setValue(5, toYear);
		this.toYear = toYear;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getFromYear() {
		this.fromYear = super.getValue(6);
		return this.fromYear;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setFromYear(String fromYear) {
        super.setValue(6, fromYear);
		this.fromYear = fromYear;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getToWeek() {
		this.toWeek = super.getValue(7);
		return this.toWeek;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setToWeek(String toWeek) {
        super.setValue(7, toWeek);
		this.toWeek = toWeek;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getFromWeek() {
		this.fromWeek = super.getValue(8);
		return this.fromWeek;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setFromWeek(String fromWeek) {
        super.setValue(8, fromWeek);
		this.fromWeek = fromWeek;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getToMonth() {
		this.toMonth = super.getValue(9);
		return this.toMonth;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setToMonth(String toMonth) {
        super.setValue(9, toMonth);
		this.toMonth = toMonth;
	}
	
	/**
	 * 조회기간 Getter Method
	 * 
	 * @return 조회기간
	 */
	@LocalName("조회기간 Getter Method")
	public String getFromMonth() {
		this.fromMonth = super.getValue(10);
		return this.fromMonth;
	}

	/**
	 * 조회기간 Setter Method
	 * 
	 * @param String 조회기간
	 */
	@LocalName("조회기간 Setter Method")
	public void setFromMonth(String fromMonth) {
        super.setValue(10, fromMonth);
		this.fromMonth = fromMonth;
	}
	
}