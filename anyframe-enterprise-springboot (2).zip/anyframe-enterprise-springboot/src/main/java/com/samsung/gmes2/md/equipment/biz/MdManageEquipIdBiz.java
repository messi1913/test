package com.samsung.gmes2.md.equipment.biz;

public class MdManageEquipIdBiz {

	/**
	 * 설비운영정보 목록 조회
	 */
	public void listEquipIdInfo(){}

	/**
	 * 설비운영정보 목록 저장
	 */
	public void saveEquipIdInfo(){}

}
