package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author KYJ
 */
public class TbmMdPhoconPjtMapDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(20) 
	private String modelCode;

	@Length(500) 
	private String n2PjtGrpNm;

	@Length(30) 
	private String gscmTypeCode;

	@Length(1) 
	private String pjtMappYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(1);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(1, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getN2PjtGrpNm() {
		this.n2PjtGrpNm = super.getValue(2);
		return this.n2PjtGrpNm;
	}

	public void setN2PjtGrpNm(String n2PjtGrpNm) {
        super.setValue(2, n2PjtGrpNm);
		this.n2PjtGrpNm = n2PjtGrpNm;
	}
	
	public String getGscmTypeCode() {
		this.gscmTypeCode = super.getValue(3);
		return this.gscmTypeCode;
	}

	public void setGscmTypeCode(String gscmTypeCode) {
        super.setValue(3, gscmTypeCode);
		this.gscmTypeCode = gscmTypeCode;
	}
	
	public String getPjtMappYn() {
		this.pjtMappYn = super.getValue(4);
		return this.pjtMappYn;
	}

	public void setPjtMappYn(String pjtMappYn) {
        super.setValue(4, pjtMappYn);
		this.pjtMappYn = pjtMappYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(5);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(5, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(6);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(6, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(7);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(7, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(8);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(8, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
}