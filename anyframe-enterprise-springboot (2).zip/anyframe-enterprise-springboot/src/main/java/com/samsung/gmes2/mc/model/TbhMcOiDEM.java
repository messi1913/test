package com.samsung.gmes2.mc.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBH_MC_OI
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbhMcOiDEM extends AbstractDAO {


/**
* insertTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return int
*/
	@LocalName("insertTbhMcOi")
	public int insertTbhMcOi (final TbhMcOiDVO tbhMcOiDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcOiDEM.insertTbhMcOi.001*/  \n");
			sql.append(" TBH_MC_OI (   \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        OI_CTGR_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
							ps.setString(psCount++, tbhMcOiDVO.getStandFrmCode());
							ps.setString(psCount++, tbhMcOiDVO.getOiCtgrCode());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbhMcOi Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbhMcOi Method")
	public int[][] updateBatchAllTbhMcOi (final List  tbhMcOiDVOList) {
		
		ArrayList updatetbhMcOiDVOList = new ArrayList();
		ArrayList insertttbhMcOiDVOList = new ArrayList();
		ArrayList deletetbhMcOiDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbhMcOiDVOList.size() ; i++) {
		  TbhMcOiDVO tbhMcOiDVO = (TbhMcOiDVO) tbhMcOiDVOList.get(i);
		  
		  if (tbhMcOiDVO.getSqlAction().equals("C"))
		      insertttbhMcOiDVOList.add(tbhMcOiDVO);
		  else if (tbhMcOiDVO.getSqlAction().equals("U"))
		      updatetbhMcOiDVOList.add(tbhMcOiDVO);
		  else if (tbhMcOiDVO.getSqlAction().equals("D"))
		      deletetbhMcOiDVOList.add(tbhMcOiDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbhMcOiDVOList.size() > 0) 
          resultValues[0] = insertBatchTbhMcOi(insertttbhMcOiDVOList);
          
      if (updatetbhMcOiDVOList.size() >0)
          resultValues[1] = updateBatchTbhMcOi(updatetbhMcOiDVOList);
      
      if (deletetbhMcOiDVOList.size() >0)
          resultValues[2] = deleteBatchTbhMcOi(deletetbhMcOiDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return int
*/
	@LocalName("updateTbhMcOi")
	public int updateTbhMcOi (final TbhMcOiDVO tbhMcOiDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcOiDEM.updateTbhMcOi.001*/  \n");
			sql.append(" TBH_MC_OI \n");
			sql.append(" SET   \n");
			sql.append("        STAND_FRM_CODE = ? , \n");
			sql.append("        OI_CTGR_CODE = ? \n");
			sql.append(" WHERE REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiDVO.getStandFrmCode());
							ps.setString(psCount++, tbhMcOiDVO.getOiCtgrCode());

							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
						}
					}
		);			
	}

/**
* deleteTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return int
*/
	@LocalName("deleteTbhMcOi")
	public int deleteTbhMcOi (final TbhMcOiDVO tbhMcOiDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcOiDEM.deleteTbhMcOi.001*/  \n");
			sql.append(" TBH_MC_OI \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
						}
					}
		);			
	}

/**
* selectTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return TbhMcOiDVO 
*/
	@LocalName("selectTbhMcOi")
	public TbhMcOiDVO selectTbhMcOi (final TbhMcOiDVO tbhMcOiDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.mc.model.TbhMcOiDEM.selectTbhMcOi.001*/  \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        OI_CTGR_CODE \n");
			sql.append("   FROM TBH_MC_OI \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return (TbhMcOiDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbhMcOiDVO returnTbhMcOiDVO = new TbhMcOiDVO();
									returnTbhMcOiDVO.setRevNo(resultSet.getString("REV_NO"));
									returnTbhMcOiDVO.setPgmCode(resultSet.getString("PGM_CODE"));
									returnTbhMcOiDVO.setStandFrmCode(resultSet.getString("STAND_FRM_CODE"));
									returnTbhMcOiDVO.setOiCtgrCode(resultSet.getString("OI_CTGR_CODE"));
									return returnTbhMcOiDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbhMcOi Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbhMcOi Method")
	public int mergeTbhMcOi (final TbhMcOiDVO tbhMcOiDVO) {
		
		if ( selectTbhMcOi (tbhMcOiDVO) == null) {
			return insertTbhMcOi(tbhMcOiDVO);
		} else {
			return selectUpdateTbhMcOi (tbhMcOiDVO);
		}
	}

	/**
	 * selectUpdateTbhMcOi Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbhMcOi Method")
	public int selectUpdateTbhMcOi (final TbhMcOiDVO tbhMcOiDVO) {
		
		TbhMcOiDVO tmpTbhMcOiDVO =  selectTbhMcOi (tbhMcOiDVO);
		if ( tbhMcOiDVO.getRevNo() != null && !"".equals(tbhMcOiDVO.getRevNo()) ) {
			tmpTbhMcOiDVO.setRevNo(tbhMcOiDVO.getRevNo());
		}		
		if ( tbhMcOiDVO.getPgmCode() != null && !"".equals(tbhMcOiDVO.getPgmCode()) ) {
			tmpTbhMcOiDVO.setPgmCode(tbhMcOiDVO.getPgmCode());
		}		
		if ( tbhMcOiDVO.getStandFrmCode() != null && !"".equals(tbhMcOiDVO.getStandFrmCode()) ) {
			tmpTbhMcOiDVO.setStandFrmCode(tbhMcOiDVO.getStandFrmCode());
		}		
		if ( tbhMcOiDVO.getOiCtgrCode() != null && !"".equals(tbhMcOiDVO.getOiCtgrCode()) ) {
			tmpTbhMcOiDVO.setOiCtgrCode(tbhMcOiDVO.getOiCtgrCode());
		}		
		return updateTbhMcOi (tmpTbhMcOiDVO);
	}

/**
* insertBatchTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return int[]
*/
	@LocalName("insertBatchTbhMcOi")
	public int[] insertBatchTbhMcOi (final List tbhMcOiDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.mc.model.TbhMcOiDEM.insertBatchTbhMcOi.001*/  \n");
			sql.append(" TBH_MC_OI (   \n");
			sql.append("        REV_NO , \n");
			sql.append("        PGM_CODE , \n");
			sql.append("        STAND_FRM_CODE , \n");
			sql.append("        OI_CTGR_CODE \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcOiDVO tbhMcOiDVO = (TbhMcOiDVO)tbhMcOiDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
							ps.setString(psCount++, tbhMcOiDVO.getStandFrmCode());
							ps.setString(psCount++, tbhMcOiDVO.getOiCtgrCode());

						}
							public int getBatchSize() {
									return tbhMcOiDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return int[]
*/
	@LocalName("updateBatchTbhMcOi")
	public int[] updateBatchTbhMcOi (final List tbhMcOiDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.mc.model.TbhMcOiDEM.updateBatchTbhMcOi.001*/  \n");
			sql.append(" TBH_MC_OI \n");
			sql.append(" SET   \n");
			sql.append("        STAND_FRM_CODE = ? , \n");
			sql.append("        OI_CTGR_CODE = ? \n");
			sql.append(" WHERE REV_NO = ? \n");
			sql.append("   AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcOiDVO tbhMcOiDVO = (TbhMcOiDVO)tbhMcOiDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbhMcOiDVO.getStandFrmCode());
							ps.setString(psCount++, tbhMcOiDVO.getOiCtgrCode());

							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbhMcOiDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbhMcOi Method
* 
* @ref_table TBH_MC_OI
* @return int[]
*/
	@LocalName("deleteBatchTbhMcOi")
	public int[] deleteBatchTbhMcOi (final List tbhMcOiDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.mc.model.TbhMcOiDEM.deleteBatchTbhMcOi.001*/  \n");
			sql.append(" TBH_MC_OI \n");
			sql.append("  WHERE REV_NO = ? \n");
			sql.append("    AND PGM_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbhMcOiDVO tbhMcOiDVO = (TbhMcOiDVO)tbhMcOiDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbhMcOiDVO.getRevNo());
							ps.setString(psCount++, tbhMcOiDVO.getPgmCode());
						}
							public int getBatchSize() {
									return tbhMcOiDVOList.size();
							}
					}
		);			
	}

	
}