package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBM_MD_PHOCON_PJT
* @author KYJ
*/
@Stereotype(Stereotype.Dao)
public class TbmMdPhoconPjtDEM extends AbstractDAO {


/**
* insertTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return int
*/
	@LocalName("insertTbmMdPhoconPjt")
	public int insertTbmMdPhoconPjt (final TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.insertTbmMdPhoconPjt.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        N2_PJT_GRP_NM , \n");
			sql.append("        N1_PJT_GRP_NM , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        PJT_ALIAS_NM , \n");
			sql.append("        PHOCON_PJT_DESC , \n");
			sql.append("        SET_NEED_AMT , \n");
			sql.append("        CONSUM_NEED_AMT , \n");
			sql.append("        TONER_USE_RATE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN1PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtAliasNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPhoconPjtDesc());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getSetNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getConsumNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getTonerUseRate());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbmMdPhoconPjt Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbmMdPhoconPjt Method")
	public int[][] updateBatchAllTbmMdPhoconPjt (final List  tbmMdPhoconPjtDVOList) {
		
		ArrayList updatetbmMdPhoconPjtDVOList = new ArrayList();
		ArrayList insertttbmMdPhoconPjtDVOList = new ArrayList();
		ArrayList deletetbmMdPhoconPjtDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbmMdPhoconPjtDVOList.size() ; i++) {
		  TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO = (TbmMdPhoconPjtDVO) tbmMdPhoconPjtDVOList.get(i);
		  
		  if (tbmMdPhoconPjtDVO.getSqlAction().equals("C"))
		      insertttbmMdPhoconPjtDVOList.add(tbmMdPhoconPjtDVO);
		  else if (tbmMdPhoconPjtDVO.getSqlAction().equals("U"))
		      updatetbmMdPhoconPjtDVOList.add(tbmMdPhoconPjtDVO);
		  else if (tbmMdPhoconPjtDVO.getSqlAction().equals("D"))
		      deletetbmMdPhoconPjtDVOList.add(tbmMdPhoconPjtDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbmMdPhoconPjtDVOList.size() > 0) 
          resultValues[0] = insertBatchTbmMdPhoconPjt(insertttbmMdPhoconPjtDVOList);
          
      if (updatetbmMdPhoconPjtDVOList.size() >0)
          resultValues[1] = updateBatchTbmMdPhoconPjt(updatetbmMdPhoconPjtDVOList);
      
      if (deletetbmMdPhoconPjtDVOList.size() >0)
          resultValues[2] = deleteBatchTbmMdPhoconPjt(deletetbmMdPhoconPjtDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return int
*/
	@LocalName("updateTbmMdPhoconPjt")
	public int updateTbmMdPhoconPjt (final TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.updateTbmMdPhoconPjt.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT \n");
			sql.append(" SET   \n");
			sql.append("        N1_PJT_GRP_NM = ? , \n");
			sql.append("        PJT_CODE = ? , \n");
			sql.append("        PJT_ALIAS_NM = ? , \n");
			sql.append("        PHOCON_PJT_DESC = ? , \n");
			sql.append("        SET_NEED_AMT = ? , \n");
			sql.append("        CONSUM_NEED_AMT = ? , \n");
			sql.append("        TONER_USE_RATE = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND N2_PJT_GRP_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN1PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtAliasNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPhoconPjtDesc());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getSetNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getConsumNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getTonerUseRate());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
						}
					}
		);			
	}

/**
* deleteTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return int
*/
	@LocalName("deleteTbmMdPhoconPjt")
	public int deleteTbmMdPhoconPjt (final TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.deleteTbmMdPhoconPjt.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND N2_PJT_GRP_NM = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
						}
					}
		);			
	}

/**
* selectTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return TbmMdPhoconPjtDVO 
*/
	@LocalName("selectTbmMdPhoconPjt")
	public TbmMdPhoconPjtDVO selectTbmMdPhoconPjt (final TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.selectTbmMdPhoconPjt.001*/  \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        N2_PJT_GRP_NM , \n");
			sql.append("        N1_PJT_GRP_NM , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        PJT_ALIAS_NM , \n");
			sql.append("        PHOCON_PJT_DESC , \n");
			sql.append("        SET_NEED_AMT , \n");
			sql.append("        CONSUM_NEED_AMT , \n");
			sql.append("        TONER_USE_RATE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBM_MD_PHOCON_PJT \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND N2_PJT_GRP_NM = ? \n");

		return (TbmMdPhoconPjtDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbmMdPhoconPjtDVO returnTbmMdPhoconPjtDVO = new TbmMdPhoconPjtDVO();
									returnTbmMdPhoconPjtDVO.setPlantCode(resultSet.getString("PLANT_CODE"));
									returnTbmMdPhoconPjtDVO.setN2PjtGrpNm(resultSet.getString("N2_PJT_GRP_NM"));
									returnTbmMdPhoconPjtDVO.setN1PjtGrpNm(resultSet.getString("N1_PJT_GRP_NM"));
									returnTbmMdPhoconPjtDVO.setPjtCode(resultSet.getString("PJT_CODE"));
									returnTbmMdPhoconPjtDVO.setPjtAliasNm(resultSet.getString("PJT_ALIAS_NM"));
									returnTbmMdPhoconPjtDVO.setPhoconPjtDesc(resultSet.getString("PHOCON_PJT_DESC"));
									returnTbmMdPhoconPjtDVO.setSetNeedAmt(resultSet.getBigDecimal("SET_NEED_AMT"));
									returnTbmMdPhoconPjtDVO.setConsumNeedAmt(resultSet.getBigDecimal("CONSUM_NEED_AMT"));
									returnTbmMdPhoconPjtDVO.setTonerUseRate(resultSet.getBigDecimal("TONER_USE_RATE"));
									returnTbmMdPhoconPjtDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbmMdPhoconPjtDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbmMdPhoconPjtDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbmMdPhoconPjtDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbmMdPhoconPjtDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbmMdPhoconPjt Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbmMdPhoconPjt Method")
	public int mergeTbmMdPhoconPjt (final TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO) {
		
		if ( selectTbmMdPhoconPjt (tbmMdPhoconPjtDVO) == null) {
			return insertTbmMdPhoconPjt(tbmMdPhoconPjtDVO);
		} else {
			return selectUpdateTbmMdPhoconPjt (tbmMdPhoconPjtDVO);
		}
	}

	/**
	 * selectUpdateTbmMdPhoconPjt Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbmMdPhoconPjt Method")
	public int selectUpdateTbmMdPhoconPjt (final TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO) {
		
		TbmMdPhoconPjtDVO tmpTbmMdPhoconPjtDVO =  selectTbmMdPhoconPjt (tbmMdPhoconPjtDVO);
		if ( tbmMdPhoconPjtDVO.getPlantCode() != null && !"".equals(tbmMdPhoconPjtDVO.getPlantCode()) ) {
			tmpTbmMdPhoconPjtDVO.setPlantCode(tbmMdPhoconPjtDVO.getPlantCode());
		}		
		if ( tbmMdPhoconPjtDVO.getN2PjtGrpNm() != null && !"".equals(tbmMdPhoconPjtDVO.getN2PjtGrpNm()) ) {
			tmpTbmMdPhoconPjtDVO.setN2PjtGrpNm(tbmMdPhoconPjtDVO.getN2PjtGrpNm());
		}		
		if ( tbmMdPhoconPjtDVO.getN1PjtGrpNm() != null && !"".equals(tbmMdPhoconPjtDVO.getN1PjtGrpNm()) ) {
			tmpTbmMdPhoconPjtDVO.setN1PjtGrpNm(tbmMdPhoconPjtDVO.getN1PjtGrpNm());
		}		
		if ( tbmMdPhoconPjtDVO.getPjtCode() != null && !"".equals(tbmMdPhoconPjtDVO.getPjtCode()) ) {
			tmpTbmMdPhoconPjtDVO.setPjtCode(tbmMdPhoconPjtDVO.getPjtCode());
		}		
		if ( tbmMdPhoconPjtDVO.getPjtAliasNm() != null && !"".equals(tbmMdPhoconPjtDVO.getPjtAliasNm()) ) {
			tmpTbmMdPhoconPjtDVO.setPjtAliasNm(tbmMdPhoconPjtDVO.getPjtAliasNm());
		}		
		if ( tbmMdPhoconPjtDVO.getPhoconPjtDesc() != null && !"".equals(tbmMdPhoconPjtDVO.getPhoconPjtDesc()) ) {
			tmpTbmMdPhoconPjtDVO.setPhoconPjtDesc(tbmMdPhoconPjtDVO.getPhoconPjtDesc());
		}		
		if ( tbmMdPhoconPjtDVO.getSetNeedAmt() != null && !"".equals(tbmMdPhoconPjtDVO.getSetNeedAmt()) ) {
			tmpTbmMdPhoconPjtDVO.setSetNeedAmt(tbmMdPhoconPjtDVO.getSetNeedAmt());
		}		
		if ( tbmMdPhoconPjtDVO.getConsumNeedAmt() != null && !"".equals(tbmMdPhoconPjtDVO.getConsumNeedAmt()) ) {
			tmpTbmMdPhoconPjtDVO.setConsumNeedAmt(tbmMdPhoconPjtDVO.getConsumNeedAmt());
		}		
		if ( tbmMdPhoconPjtDVO.getTonerUseRate() != null && !"".equals(tbmMdPhoconPjtDVO.getTonerUseRate()) ) {
			tmpTbmMdPhoconPjtDVO.setTonerUseRate(tbmMdPhoconPjtDVO.getTonerUseRate());
		}		
		if ( tbmMdPhoconPjtDVO.getFstRegDt() != null && !"".equals(tbmMdPhoconPjtDVO.getFstRegDt()) ) {
			tmpTbmMdPhoconPjtDVO.setFstRegDt(tbmMdPhoconPjtDVO.getFstRegDt());
		}		
		if ( tbmMdPhoconPjtDVO.getFstRegerId() != null && !"".equals(tbmMdPhoconPjtDVO.getFstRegerId()) ) {
			tmpTbmMdPhoconPjtDVO.setFstRegerId(tbmMdPhoconPjtDVO.getFstRegerId());
		}		
		if ( tbmMdPhoconPjtDVO.getFnlUpdDt() != null && !"".equals(tbmMdPhoconPjtDVO.getFnlUpdDt()) ) {
			tmpTbmMdPhoconPjtDVO.setFnlUpdDt(tbmMdPhoconPjtDVO.getFnlUpdDt());
		}		
		if ( tbmMdPhoconPjtDVO.getFnlUpderId() != null && !"".equals(tbmMdPhoconPjtDVO.getFnlUpderId()) ) {
			tmpTbmMdPhoconPjtDVO.setFnlUpderId(tbmMdPhoconPjtDVO.getFnlUpderId());
		}		
		return updateTbmMdPhoconPjt (tmpTbmMdPhoconPjtDVO);
	}

/**
* insertBatchTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return int[]
*/
	@LocalName("insertBatchTbmMdPhoconPjt")
	public int[] insertBatchTbmMdPhoconPjt (final List tbmMdPhoconPjtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.insertBatchTbmMdPhoconPjt.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT (   \n");
			sql.append("        PLANT_CODE , \n");
			sql.append("        N2_PJT_GRP_NM , \n");
			sql.append("        N1_PJT_GRP_NM , \n");
			sql.append("        PJT_CODE , \n");
			sql.append("        PJT_ALIAS_NM , \n");
			sql.append("        PHOCON_PJT_DESC , \n");
			sql.append("        SET_NEED_AMT , \n");
			sql.append("        CONSUM_NEED_AMT , \n");
			sql.append("        TONER_USE_RATE , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO = (TbmMdPhoconPjtDVO)tbmMdPhoconPjtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN1PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtAliasNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPhoconPjtDesc());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getSetNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getConsumNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getTonerUseRate());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbmMdPhoconPjtDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return int[]
*/
	@LocalName("updateBatchTbmMdPhoconPjt")
	public int[] updateBatchTbmMdPhoconPjt (final List tbmMdPhoconPjtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.updateBatchTbmMdPhoconPjt.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT \n");
			sql.append(" SET   \n");
			sql.append("        N1_PJT_GRP_NM = ? , \n");
			sql.append("        PJT_CODE = ? , \n");
			sql.append("        PJT_ALIAS_NM = ? , \n");
			sql.append("        PHOCON_PJT_DESC = ? , \n");
			sql.append("        SET_NEED_AMT = ? , \n");
			sql.append("        CONSUM_NEED_AMT = ? , \n");
			sql.append("        TONER_USE_RATE = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE PLANT_CODE = ? \n");
			sql.append("   AND N2_PJT_GRP_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO = (TbmMdPhoconPjtDVO)tbmMdPhoconPjtDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN1PjtGrpNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPjtAliasNm());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPhoconPjtDesc());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getSetNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getConsumNeedAmt());
							ps.setBigDecimal(psCount++, tbmMdPhoconPjtDVO.getTonerUseRate());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFstRegerId());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpdDt());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getFnlUpderId());

							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
						}
							public int getBatchSize() {
									return tbmMdPhoconPjtDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbmMdPhoconPjt Method
* 
* @ref_table TBM_MD_PHOCON_PJT
* @return int[]
*/
	@LocalName("deleteBatchTbmMdPhoconPjt")
	public int[] deleteBatchTbmMdPhoconPjt (final List tbmMdPhoconPjtDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbmMdPhoconPjtDEM.deleteBatchTbmMdPhoconPjt.001*/  \n");
			sql.append(" TBM_MD_PHOCON_PJT \n");
			sql.append("  WHERE PLANT_CODE = ? \n");
			sql.append("    AND N2_PJT_GRP_NM = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbmMdPhoconPjtDVO tbmMdPhoconPjtDVO = (TbmMdPhoconPjtDVO)tbmMdPhoconPjtDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbmMdPhoconPjtDVO.getPlantCode());
							ps.setString(psCount++, tbmMdPhoconPjtDVO.getN2PjtGrpNm());
						}
							public int getBatchSize() {
									return tbmMdPhoconPjtDVOList.size();
							}
					}
		);			
	}

	
}