package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_MODEL_GRP
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdModelGrpDEM extends AbstractDAO {


/**
* insertTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return int
*/
	@LocalName("insertTbcMdModelGrp")
	public int insertTbcMdModelGrp (final TbcMdModelGrpDVO tbcMdModelGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.insertTbcMdModelGrp.001*/  \n");
			sql.append(" TBC_MD_MODEL_GRP (   \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        MODEL_GRP_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
							ps.setString(psCount++, tbcMdModelGrpDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpNm());
							ps.setString(psCount++, tbcMdModelGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdModelGrp Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdModelGrp Method")
	public int[][] updateBatchAllTbcMdModelGrp (final List  tbcMdModelGrpDVOList) {
		
		ArrayList updatetbcMdModelGrpDVOList = new ArrayList();
		ArrayList insertttbcMdModelGrpDVOList = new ArrayList();
		ArrayList deletetbcMdModelGrpDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdModelGrpDVOList.size() ; i++) {
		  TbcMdModelGrpDVO tbcMdModelGrpDVO = (TbcMdModelGrpDVO) tbcMdModelGrpDVOList.get(i);
		  
		  if (tbcMdModelGrpDVO.getSqlAction().equals("C"))
		      insertttbcMdModelGrpDVOList.add(tbcMdModelGrpDVO);
		  else if (tbcMdModelGrpDVO.getSqlAction().equals("U"))
		      updatetbcMdModelGrpDVOList.add(tbcMdModelGrpDVO);
		  else if (tbcMdModelGrpDVO.getSqlAction().equals("D"))
		      deletetbcMdModelGrpDVOList.add(tbcMdModelGrpDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdModelGrpDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdModelGrp(insertttbcMdModelGrpDVOList);
          
      if (updatetbcMdModelGrpDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdModelGrp(updatetbcMdModelGrpDVOList);
      
      if (deletetbcMdModelGrpDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdModelGrp(deletetbcMdModelGrpDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return int
*/
	@LocalName("updateTbcMdModelGrp")
	public int updateTbcMdModelGrp (final TbcMdModelGrpDVO tbcMdModelGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.updateTbcMdModelGrp.001*/  \n");
			sql.append(" TBC_MD_MODEL_GRP \n");
			sql.append(" SET   \n");
			sql.append("        PROD_GRP_CODE = ? , \n");
			sql.append("        MODEL_GRP_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_GRP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdModelGrpDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpNm());
							ps.setString(psCount++, tbcMdModelGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
						}
					}
		);			
	}

/**
* deleteTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return int
*/
	@LocalName("deleteTbcMdModelGrp")
	public int deleteTbcMdModelGrp (final TbcMdModelGrpDVO tbcMdModelGrpDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.deleteTbcMdModelGrp.001*/  \n");
			sql.append(" TBC_MD_MODEL_GRP \n");
			sql.append("  WHERE MODEL_GRP_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
						}
					}
		);			
	}

/**
* selectTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return TbcMdModelGrpDVO 
*/
	@LocalName("selectTbcMdModelGrp")
	public TbcMdModelGrpDVO selectTbcMdModelGrp (final TbcMdModelGrpDVO tbcMdModelGrpDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.selectTbcMdModelGrp.001*/  \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        MODEL_GRP_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_MODEL_GRP \n");
			sql.append("  WHERE MODEL_GRP_CODE = ? \n");

		return (TbcMdModelGrpDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdModelGrpDVO returnTbcMdModelGrpDVO = new TbcMdModelGrpDVO();
									returnTbcMdModelGrpDVO.setModelGrpCode(resultSet.getString("MODEL_GRP_CODE"));
									returnTbcMdModelGrpDVO.setProdGrpCode(resultSet.getString("PROD_GRP_CODE"));
									returnTbcMdModelGrpDVO.setModelGrpNm(resultSet.getString("MODEL_GRP_NM"));
									returnTbcMdModelGrpDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdModelGrpDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdModelGrpDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdModelGrpDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdModelGrpDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdModelGrpDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdModelGrp Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdModelGrp Method")
	public int mergeTbcMdModelGrp (final TbcMdModelGrpDVO tbcMdModelGrpDVO) {
		
		if ( selectTbcMdModelGrp (tbcMdModelGrpDVO) == null) {
			return insertTbcMdModelGrp(tbcMdModelGrpDVO);
		} else {
			return selectUpdateTbcMdModelGrp (tbcMdModelGrpDVO);
		}
	}

	/**
	 * selectUpdateTbcMdModelGrp Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdModelGrp Method")
	public int selectUpdateTbcMdModelGrp (final TbcMdModelGrpDVO tbcMdModelGrpDVO) {
		
		TbcMdModelGrpDVO tmpTbcMdModelGrpDVO =  selectTbcMdModelGrp (tbcMdModelGrpDVO);
		if ( tbcMdModelGrpDVO.getModelGrpCode() != null && !"".equals(tbcMdModelGrpDVO.getModelGrpCode()) ) {
			tmpTbcMdModelGrpDVO.setModelGrpCode(tbcMdModelGrpDVO.getModelGrpCode());
		}		
		if ( tbcMdModelGrpDVO.getProdGrpCode() != null && !"".equals(tbcMdModelGrpDVO.getProdGrpCode()) ) {
			tmpTbcMdModelGrpDVO.setProdGrpCode(tbcMdModelGrpDVO.getProdGrpCode());
		}		
		if ( tbcMdModelGrpDVO.getModelGrpNm() != null && !"".equals(tbcMdModelGrpDVO.getModelGrpNm()) ) {
			tmpTbcMdModelGrpDVO.setModelGrpNm(tbcMdModelGrpDVO.getModelGrpNm());
		}		
		if ( tbcMdModelGrpDVO.getUseYn() != null && !"".equals(tbcMdModelGrpDVO.getUseYn()) ) {
			tmpTbcMdModelGrpDVO.setUseYn(tbcMdModelGrpDVO.getUseYn());
		}		
		if ( tbcMdModelGrpDVO.getFstRegDt() != null && !"".equals(tbcMdModelGrpDVO.getFstRegDt()) ) {
			tmpTbcMdModelGrpDVO.setFstRegDt(tbcMdModelGrpDVO.getFstRegDt());
		}		
		if ( tbcMdModelGrpDVO.getFstRegerId() != null && !"".equals(tbcMdModelGrpDVO.getFstRegerId()) ) {
			tmpTbcMdModelGrpDVO.setFstRegerId(tbcMdModelGrpDVO.getFstRegerId());
		}		
		if ( tbcMdModelGrpDVO.getFnlUpdDt() != null && !"".equals(tbcMdModelGrpDVO.getFnlUpdDt()) ) {
			tmpTbcMdModelGrpDVO.setFnlUpdDt(tbcMdModelGrpDVO.getFnlUpdDt());
		}		
		if ( tbcMdModelGrpDVO.getFnlUpderId() != null && !"".equals(tbcMdModelGrpDVO.getFnlUpderId()) ) {
			tmpTbcMdModelGrpDVO.setFnlUpderId(tbcMdModelGrpDVO.getFnlUpderId());
		}		
		return updateTbcMdModelGrp (tmpTbcMdModelGrpDVO);
	}

/**
* insertBatchTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return int[]
*/
	@LocalName("insertBatchTbcMdModelGrp")
	public int[] insertBatchTbcMdModelGrp (final List tbcMdModelGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.insertBatchTbcMdModelGrp.001*/  \n");
			sql.append(" TBC_MD_MODEL_GRP (   \n");
			sql.append("        MODEL_GRP_CODE , \n");
			sql.append("        PROD_GRP_CODE , \n");
			sql.append("        MODEL_GRP_NM , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdModelGrpDVO tbcMdModelGrpDVO = (TbcMdModelGrpDVO)tbcMdModelGrpDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
							ps.setString(psCount++, tbcMdModelGrpDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpNm());
							ps.setString(psCount++, tbcMdModelGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdModelGrpDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return int[]
*/
	@LocalName("updateBatchTbcMdModelGrp")
	public int[] updateBatchTbcMdModelGrp (final List tbcMdModelGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.updateBatchTbcMdModelGrp.001*/  \n");
			sql.append(" TBC_MD_MODEL_GRP \n");
			sql.append(" SET   \n");
			sql.append("        PROD_GRP_CODE = ? , \n");
			sql.append("        MODEL_GRP_NM = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE MODEL_GRP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdModelGrpDVO tbcMdModelGrpDVO = (TbcMdModelGrpDVO)tbcMdModelGrpDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdModelGrpDVO.getProdGrpCode());
							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpNm());
							ps.setString(psCount++, tbcMdModelGrpDVO.getUseYn());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdModelGrpDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
						}
							public int getBatchSize() {
									return tbcMdModelGrpDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdModelGrp Method
* 
* @ref_table TBC_MD_MODEL_GRP
* @return int[]
*/
	@LocalName("deleteBatchTbcMdModelGrp")
	public int[] deleteBatchTbcMdModelGrp (final List tbcMdModelGrpDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdModelGrpDEM.deleteBatchTbcMdModelGrp.001*/  \n");
			sql.append(" TBC_MD_MODEL_GRP \n");
			sql.append("  WHERE MODEL_GRP_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdModelGrpDVO tbcMdModelGrpDVO = (TbcMdModelGrpDVO)tbcMdModelGrpDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdModelGrpDVO.getModelGrpCode());
						}
							public int getBatchSize() {
									return tbcMdModelGrpDVOList.size();
							}
					}
		);			
	}

	
}