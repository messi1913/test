package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.AbstractDAO;

/**
* 
*
* @ref_table TBC_MD_BRDN_ACT
* @author shim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdBrdnActDEM extends AbstractDAO {


/**
* insertTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return int
*/
	@LocalName("insertTbcMdBrdnAct")
	public int insertTbcMdBrdnAct (final TbcMdBrdnActDVO tbcMdBrdnActDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.insertTbcMdBrdnAct.001*/  \n");
			sql.append(" TBC_MD_BRDN_ACT (   \n");
			sql.append("        BRDN_ACT_CODE , \n");
			sql.append("        BRDN_ACT_NM , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActNm());
							ps.setString(psCount++, tbcMdBrdnActDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnActDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpderId());

						}
					}
		);			
	}

	/**
	 * updateBatchAllTbcMdBrdnAct Method 
	 * 
	 * @return	int[][]
	 */
	/*
	@LocalName("updateBatchAllTbcMdBrdnAct Method")
	public int[][] updateBatchAllTbcMdBrdnAct (final List  tbcMdBrdnActDVOList) {
		
		ArrayList updatetbcMdBrdnActDVOList = new ArrayList();
		ArrayList insertttbcMdBrdnActDVOList = new ArrayList();
		ArrayList deletetbcMdBrdnActDVOList = new ArrayList();
		
		for (int i = 0 ; i < tbcMdBrdnActDVOList.size() ; i++) {
		  TbcMdBrdnActDVO tbcMdBrdnActDVO = (TbcMdBrdnActDVO) tbcMdBrdnActDVOList.get(i);
		  
		  if (tbcMdBrdnActDVO.getSqlAction().equals("C"))
		      insertttbcMdBrdnActDVOList.add(tbcMdBrdnActDVO);
		  else if (tbcMdBrdnActDVO.getSqlAction().equals("U"))
		      updatetbcMdBrdnActDVOList.add(tbcMdBrdnActDVO);
		  else if (tbcMdBrdnActDVO.getSqlAction().equals("D"))
		      deletetbcMdBrdnActDVOList.add(tbcMdBrdnActDVO);
		}

 		int [][] resultValues = new int[3][];

      if (insertttbcMdBrdnActDVOList.size() > 0) 
          resultValues[0] = insertBatchTbcMdBrdnAct(insertttbcMdBrdnActDVOList);
          
      if (updatetbcMdBrdnActDVOList.size() >0)
          resultValues[1] = updateBatchTbcMdBrdnAct(updatetbcMdBrdnActDVOList);
      
      if (deletetbcMdBrdnActDVOList.size() >0)
          resultValues[2] = deleteBatchTbcMdBrdnAct(deletetbcMdBrdnActDVOList);
      
      return resultValues;
      
	}
	*/

/**
* updateTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return int
*/
	@LocalName("updateTbcMdBrdnAct")
	public int updateTbcMdBrdnAct (final TbcMdBrdnActDVO tbcMdBrdnActDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.updateTbcMdBrdnAct.001*/  \n");
			sql.append(" TBC_MD_BRDN_ACT \n");
			sql.append(" SET   \n");
			sql.append("        BRDN_ACT_NM = ? , \n");
			sql.append("        EQUIP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_ACT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActNm());
							ps.setString(psCount++, tbcMdBrdnActDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnActDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
						}
					}
		);			
	}

/**
* deleteTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return int
*/
	@LocalName("deleteTbcMdBrdnAct")
	public int deleteTbcMdBrdnAct (final TbcMdBrdnActDVO tbcMdBrdnActDVO) {	

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.deleteTbcMdBrdnAct.001*/  \n");
			sql.append(" TBC_MD_BRDN_ACT \n");
			sql.append("  WHERE BRDN_ACT_CODE = ? \n");

		return update(sql.toString(),
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
						}
					}
		);			
	}

/**
* selectTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return TbcMdBrdnActDVO 
*/
	@LocalName("selectTbcMdBrdnAct")
	public TbcMdBrdnActDVO selectTbcMdBrdnAct (final TbcMdBrdnActDVO tbcMdBrdnActDVO) {

		StringBuffer sql = new StringBuffer();
			sql.append(" SELECT /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.selectTbcMdBrdnAct.001*/  \n");
			sql.append("        BRDN_ACT_CODE , \n");
			sql.append("        BRDN_ACT_NM , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append("   FROM TBC_MD_BRDN_ACT \n");
			sql.append("  WHERE BRDN_ACT_CODE = ? \n");

		return (TbcMdBrdnActDVO)queryForObject(sql.toString(), 
				new PreparedStatementSetter() {
							public void setValues(PreparedStatement ps) throws SQLException {

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
						}
					}
					, new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
									TbcMdBrdnActDVO returnTbcMdBrdnActDVO = new TbcMdBrdnActDVO();
									returnTbcMdBrdnActDVO.setBrdnActCode(resultSet.getString("BRDN_ACT_CODE"));
									returnTbcMdBrdnActDVO.setBrdnActNm(resultSet.getString("BRDN_ACT_NM"));
									returnTbcMdBrdnActDVO.setEquipClsfCode(resultSet.getString("EQUIP_CLSF_CODE"));
									returnTbcMdBrdnActDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdBrdnActDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdBrdnActDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdBrdnActDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdBrdnActDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdBrdnActDVO;
					    	}
					   }
 		);			
	}

	/**
	 * mergeTbcMdBrdnAct Method 
	 * 
	 * @return	int
	 */
	@LocalName("mergeTbcMdBrdnAct Method")
	public int mergeTbcMdBrdnAct (final TbcMdBrdnActDVO tbcMdBrdnActDVO) {
		
		if ( selectTbcMdBrdnAct (tbcMdBrdnActDVO) == null) {
			return insertTbcMdBrdnAct(tbcMdBrdnActDVO);
		} else {
			return selectUpdateTbcMdBrdnAct (tbcMdBrdnActDVO);
		}
	}

	/**
	 * selectUpdateTbcMdBrdnAct Method 
	 * 
	 * @return	int
	 */
	@LocalName("selectUpdateTbcMdBrdnAct Method")
	public int selectUpdateTbcMdBrdnAct (final TbcMdBrdnActDVO tbcMdBrdnActDVO) {
		
		TbcMdBrdnActDVO tmpTbcMdBrdnActDVO =  selectTbcMdBrdnAct (tbcMdBrdnActDVO);
		if ( tbcMdBrdnActDVO.getBrdnActCode() != null && !"".equals(tbcMdBrdnActDVO.getBrdnActCode()) ) {
			tmpTbcMdBrdnActDVO.setBrdnActCode(tbcMdBrdnActDVO.getBrdnActCode());
		}		
		if ( tbcMdBrdnActDVO.getBrdnActNm() != null && !"".equals(tbcMdBrdnActDVO.getBrdnActNm()) ) {
			tmpTbcMdBrdnActDVO.setBrdnActNm(tbcMdBrdnActDVO.getBrdnActNm());
		}		
		if ( tbcMdBrdnActDVO.getEquipClsfCode() != null && !"".equals(tbcMdBrdnActDVO.getEquipClsfCode()) ) {
			tmpTbcMdBrdnActDVO.setEquipClsfCode(tbcMdBrdnActDVO.getEquipClsfCode());
		}		
		if ( tbcMdBrdnActDVO.getUseYn() != null && !"".equals(tbcMdBrdnActDVO.getUseYn()) ) {
			tmpTbcMdBrdnActDVO.setUseYn(tbcMdBrdnActDVO.getUseYn());
		}		
		if ( tbcMdBrdnActDVO.getFstRegDt() != null && !"".equals(tbcMdBrdnActDVO.getFstRegDt()) ) {
			tmpTbcMdBrdnActDVO.setFstRegDt(tbcMdBrdnActDVO.getFstRegDt());
		}		
		if ( tbcMdBrdnActDVO.getFstRegerId() != null && !"".equals(tbcMdBrdnActDVO.getFstRegerId()) ) {
			tmpTbcMdBrdnActDVO.setFstRegerId(tbcMdBrdnActDVO.getFstRegerId());
		}		
		if ( tbcMdBrdnActDVO.getFnlUpdDt() != null && !"".equals(tbcMdBrdnActDVO.getFnlUpdDt()) ) {
			tmpTbcMdBrdnActDVO.setFnlUpdDt(tbcMdBrdnActDVO.getFnlUpdDt());
		}		
		if ( tbcMdBrdnActDVO.getFnlUpderId() != null && !"".equals(tbcMdBrdnActDVO.getFnlUpderId()) ) {
			tmpTbcMdBrdnActDVO.setFnlUpderId(tbcMdBrdnActDVO.getFnlUpderId());
		}		
		return updateTbcMdBrdnAct (tmpTbcMdBrdnActDVO);
	}

/**
* insertBatchTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return int[]
*/
	@LocalName("insertBatchTbcMdBrdnAct")
	public int[] insertBatchTbcMdBrdnAct (final List tbcMdBrdnActDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" INSERT INTO /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.insertBatchTbcMdBrdnAct.001*/  \n");
			sql.append(" TBC_MD_BRDN_ACT (   \n");
			sql.append("        BRDN_ACT_CODE , \n");
			sql.append("        BRDN_ACT_NM , \n");
			sql.append("        EQUIP_CLSF_CODE , \n");
			sql.append("        USE_YN , \n");
			sql.append("        FST_REG_DT , \n");
			sql.append("        FST_REGER_ID , \n");
			sql.append("        FNL_UPD_DT , \n");
			sql.append("        FNL_UPDER_ID \n");
			sql.append(" )  VALUES  (   \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? , \n");
			sql.append("        ? \n");
			sql.append(" ) \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnActDVO tbcMdBrdnActDVO = (TbcMdBrdnActDVO)tbcMdBrdnActDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActNm());
							ps.setString(psCount++, tbcMdBrdnActDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnActDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpderId());

						}
							public int getBatchSize() {
									return tbcMdBrdnActDVOList.size();
							}
					}
		);			
	}

/**
* updateBatchTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return int[]
*/
	@LocalName("updateBatchTbcMdBrdnAct")
	public int[] updateBatchTbcMdBrdnAct (final List tbcMdBrdnActDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" UPDATE /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.updateBatchTbcMdBrdnAct.001*/  \n");
			sql.append(" TBC_MD_BRDN_ACT \n");
			sql.append(" SET   \n");
			sql.append("        BRDN_ACT_NM = ? , \n");
			sql.append("        EQUIP_CLSF_CODE = ? , \n");
			sql.append("        USE_YN = ? , \n");
			sql.append("        FST_REG_DT = ? , \n");
			sql.append("        FST_REGER_ID = ? , \n");
			sql.append("        FNL_UPD_DT = ? , \n");
			sql.append("        FNL_UPDER_ID = ? \n");
			sql.append(" WHERE BRDN_ACT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnActDVO tbcMdBrdnActDVO = (TbcMdBrdnActDVO)tbcMdBrdnActDVOList.get(i);

							int psCount = 1;

							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActNm());
							ps.setString(psCount++, tbcMdBrdnActDVO.getEquipClsfCode());
							ps.setString(psCount++, tbcMdBrdnActDVO.getUseYn());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFstRegerId());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpdDt());
							ps.setString(psCount++, tbcMdBrdnActDVO.getFnlUpderId());

							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnActDVOList.size();
							}
					}
		);			
	}

/**
* deleteBatchTbcMdBrdnAct Method
* 
* @ref_table TBC_MD_BRDN_ACT
* @return int[]
*/
	@LocalName("deleteBatchTbcMdBrdnAct")
	public int[] deleteBatchTbcMdBrdnAct (final List tbcMdBrdnActDVOList) {

		StringBuffer sql = new StringBuffer();
			sql.append(" DELETE FROM /*com.samsung.gmes2.md.model.TbcMdBrdnActDEM.deleteBatchTbcMdBrdnAct.001*/  \n");
			sql.append(" TBC_MD_BRDN_ACT \n");
			sql.append("  WHERE BRDN_ACT_CODE = ? \n");

		return batchUpdate(sql.toString(), 
				new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps, int i) throws SQLException {
							TbcMdBrdnActDVO tbcMdBrdnActDVO = (TbcMdBrdnActDVO)tbcMdBrdnActDVOList.get(i);

							int psCount = 1;


							ps.setString(psCount++, tbcMdBrdnActDVO.getBrdnActCode());
						}
							public int getBatchSize() {
									return tbcMdBrdnActDVOList.size();
							}
					}
		);			
	}

	
}