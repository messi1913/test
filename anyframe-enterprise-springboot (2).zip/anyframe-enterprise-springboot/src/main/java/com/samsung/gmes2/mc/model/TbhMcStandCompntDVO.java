package com.samsung.gmes2.mc.model;

import javax.validation.constraints.NotNull;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.samsung.gmes2.system.vo.AbstractDVO;

/**
 * 
 * @stereotype DAOVO
 * @author shim
 */
public class TbhMcStandCompntDVO extends AbstractDVO {

	@Length(50) @NotNull
	private String revNo;

	@Length(50) @NotNull
	private String standCompntCode;

	@Length(500) 
	private String compntNm;

	@Length(1000) 
	private String compntDesc;


	public String getRevNo() {
		this.revNo = super.getValue("revNo");
		return this.revNo;
	}

	public void setRevNo(String revNo) {
        super.setValue("revNo", revNo);
		this.revNo = revNo;
	}
	
	public String getStandCompntCode() {
		this.standCompntCode = super.getValue("standCompntCode");
		return this.standCompntCode;
	}

	public void setStandCompntCode(String standCompntCode) {
        super.setValue("standCompntCode", standCompntCode);
		this.standCompntCode = standCompntCode;
	}
	
	public String getCompntNm() {
		this.compntNm = super.getValue("compntNm");
		return this.compntNm;
	}

	public void setCompntNm(String compntNm) {
        super.setValue("compntNm", compntNm);
		this.compntNm = compntNm;
	}
	
	public String getCompntDesc() {
		this.compntDesc = super.getValue("compntDesc");
		return this.compntDesc;
	}

	public void setCompntDesc(String compntDesc) {
        super.setValue("compntDesc", compntDesc);
		this.compntDesc = compntDesc;
	}
	
}