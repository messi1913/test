package com.samsung.gmes2.aop;

import java.util.List;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;

import com.anyframe.core.vo.AbstractVo;
import com.anyframe.online.runtime.service.request.RequestContextUtil;
import com.samsung.gmes2.base.Constants;
import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CacheUtil;
import com.samsung.gmes2.base.util.ReflectionUtil;
import com.samsung.gmes2.base.util.ThreadPropertyUtil;
import com.samsung.gmes2.base.vo.DVO;
import com.samsung.gmes2.exception.Gmes2BugException;

public class DaoAdvice extends AbstractAdvice
{
	public Object invoke( ProceedingJoinPoint call ) throws Throwable
	{
		String methodName = call.getSignature( ).getName( );
		String className = call.getTarget( ).getClass( ).getName( );
		Object firstArg = call.getArgs( )[ 0 ];

		boolean update = false;
		boolean select = false;
		boolean insert = false;
		boolean delete = false;
		boolean list = false;
		if ( methodName.startsWith( "update" ) || methodName.startsWith( "selectUpdate" ) || methodName.startsWith( "dUpdate" ) )
		{
			update = true;
		}
		else if ( methodName.startsWith( "select" ) )
		{
			select = true;
		}
		else if ( methodName.startsWith( "list" ) || methodName.startsWith( "dList" ) )
		{
			list = true;
		}
		else if ( methodName.startsWith( "insert" ) )
		{
			insert = true;
		}
		else if ( methodName.startsWith( "delete" ) )
		{
			delete = true;
		}
		boolean dml = ( insert || update || delete ) && !methodName.endsWith( "TbIfDmlLog" );

		if ( select || list || insert )
		{
			boolean selectOne = select && firstArg instanceof AbstractVo;
			if ( selectOne )
			{
				// 단일 객체 select 쿼리인 경우에는 Cache 여부를 확인한다.
				Object obj = getCache( (AbstractVo) firstArg );
				if ( obj != null )
					return obj;
			}
			else if ( insert )
			{
				populate( firstArg, insert );
			}
			Object obj = null;
			try
			{
				if ( dml )
					populateDmlInfo( className, methodName );
				obj = call.proceed( );
			}
			finally
			{
				if ( dml )
					releaseDmlInfo( );
			}
			if ( selectOne && obj instanceof AbstractVo )
				putCache( (AbstractVo) obj );
			return obj;
		}
		else if ( update )
		{
			populate( firstArg, insert );
		}

		increaseStackCounter( );
		try
		{
			if ( dml )
				populateDmlInfo( className, methodName );
			Object obj = call.proceed( );
			// select, list, dList, insert 등의 쿼리가 아닌 경우에는 해제할 Cache를 추가한다.
			addCacheToInvalidate( firstArg );
			return obj;
		}
		catch ( Throwable t )
		{
			throw t;
		}
		finally
		{
			try
			{
				if ( dml )
					releaseDmlInfo( );
			}
			finally
			{
				decreaseStackCounter( );
				if ( isFirstStack( ) )
				{
					if ( CacheUtil.isCacheable( ) )
						invalidateCache( );
					ThreadPropertyUtil.removeAll( );
				}
			}
		}
	}

	private static final String INVALIDMETHODNAME_TB = "Invalid DAO method name: ${className}.${methodName}\r\n(SPM 명명규칙정의서를 확인하세요. - Update 성격의 DAO 메써드는 반드시 'Tb' 문자를 포함해야 합니다.";
	private static void populateDmlInfo( String className, String methodName ) throws Exception
	{
		//				for ( StackTraceElement st : Thread.currentThread( ).getStackTrace( ) )
		//				{
		//					String className = st.getClassName( );
		//					if ( className.startsWith( "com.samsung.gmes2" ) && ( className.endsWith( "App" ) || className.endsWith( "Biz" ) ) )
		//					{
		//						RequestContextUtil.put( Constants.DML_CALL_METHOD, st.getMethodName( ) );
		//						break;
		//					}
		//				}
		RequestContextUtil.put( Constants.DML_CALL_METHOD, new StringBuffer( ).append( className ).append( "." ).append( methodName ).toString( ) );
		if ( methodName.contains( "_" ) )
		{
			String tableName = methodName.substring( methodName.lastIndexOf( "_" ) + 1 );
			if ( !tableName.startsWith( "Tb" ) )
				throw new Gmes2BugException( BaseUtil.completeMessage( INVALIDMETHODNAME_TB, toProperties( "className:" + className, "methodName:" + methodName ) ) );
			tableName = ReflectionUtil.toUnderscoreCase( tableName );
			RequestContextUtil.put( Constants.DML_TABLE_NAME, tableName );
		}
		else
		{
			int tbIndex = methodName.indexOf( "Tb" );
			if ( tbIndex == -1 )
			{
				if ( !methodName.contains( "Aft" ) )
					throw new Gmes2BugException( BaseUtil.completeMessage( INVALIDMETHODNAME_TB, toProperties( "className:" + className, "methodName:" + methodName ) ) );
			}
			else
			{
				String tableName = ReflectionUtil.toUnderscoreCase( methodName.substring( tbIndex ) );
				RequestContextUtil.put( Constants.DML_TABLE_NAME, tableName );
			}
		}
	}

	private static void releaseDmlInfo( ) throws Exception
	{
		Map<Object, Object> all = RequestContextUtil.getAll( );
		all.remove( Constants.DML_CALL_METHOD );
		all.remove( Constants.DML_TABLE_NAME );
	}

	private static void populate( Object firstArg, boolean insert ) throws Exception
	{
		if ( firstArg instanceof AbstractVo )
		{
			populate( (AbstractVo) firstArg, insert );
		}
		else if ( firstArg instanceof List )
		{
			List<?> itemList = (List<?>) firstArg;
			if ( isNotEmpty( itemList ) && itemList.get( 0 ) instanceof AbstractVo )
			{
				for ( Object obj : itemList )
					populate( (AbstractVo) obj, insert );
			}
		}
	}

	private static void populate( AbstractVo obj, boolean insert ) throws Exception
	{
		Map<String, Integer> namedMap = obj.getProxy( ).getVoMeta( ).getNamedMap( );
		if ( insert )
		{
			if ( namedMap.containsKey( DVO.FIELD_FSTREGERID ) && isEmpty( obj.getValue( DVO.FIELD_FSTREGERID ) ) )
				obj.setValue( DVO.FIELD_FSTREGERID, getUsername( ) );
			if ( namedMap.containsKey( DVO.FIELD_FSTREGDT ) )
			{
				String value = (String) obj.getValue( DVO.FIELD_FSTREGDT );
				if ( isEmpty( obj.getValue( DVO.FIELD_FSTREGDT ) ) )
					obj.setValue( DVO.FIELD_FSTREGDT, getDateString( ) );
				else
					BaseUtil.checkDateFormat( DVO.FIELD_FSTREGDT, value, BaseUtil.DATEFORMAT_DATETIMESHORT );
			}
		}
		if ( namedMap.containsKey( DVO.FIELD_FNLUPDERID ) && isEmpty( obj.getValue( DVO.FIELD_FNLUPDERID ) ) )
			obj.setValue( DVO.FIELD_FNLUPDERID, getUsername( ) );
		if ( namedMap.containsKey( DVO.FIELD_FNLUPDDT ) )
		{
			String value = (String) obj.getValue( DVO.FIELD_FNLUPDDT );
			if ( isEmpty( obj.getValue( DVO.FIELD_FNLUPDDT ) ) )
				obj.setValue( DVO.FIELD_FNLUPDDT, getDateString( ) );
			else
				BaseUtil.checkDateFormat( DVO.FIELD_FNLUPDDT, value, BaseUtil.DATEFORMAT_DATETIMESHORT );
		}
		if ( namedMap.containsKey( DVO.FIELD_USEYN ) && isEmpty( obj.getValue( DVO.FIELD_USEYN ) ) )
			obj.setValue( DVO.FIELD_USEYN, "Y" );
		else if ( namedMap.containsKey( DVO.FIELD_DELYN ) && isEmpty( obj.getValue( DVO.FIELD_DELYN ) ) )
			obj.setValue( DVO.FIELD_DELYN, "N" );
	}
}
