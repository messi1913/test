package com.samsung.gmes2.md.model;

import com.anyframe.core.annotation.Scale;
import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;
import java.math.BigDecimal;

/**
 * 
 * @author KYJ
 */
public class TbmMdPlantEquipDVO extends AbstractVo {

	@Length(20) 
	private String plantCode;

	@Length(30) 
	private String equipCode;

	@Length(17) 
	private String histTsp;

	@Length(500) 
	private String equipNm;

	@Length(2000) 
	private String equipSpecCont;

	@Length(30) 
	private String equipGubunCode;

	@Length(30) 
	private String matrGubunCode;

	@Length(30) 
	private String matrTypeCode;

	@Length(30) 
	private String procGubunCode;

	@Length(1) 
	private String automYn;

	@Length(11) @Scale(5) 
	private BigDecimal equipSize;

	@Length(500) 
	private String supplyVendPnNm;

	@Length(500) 
	private String supplyVendNm;

	@Length(50) 
	private String purcNo;

	@Length(30) 
	private String dfGubunCode;

	@Length(11) @Scale(5) 
	private BigDecimal moldNum;

	@Length(11) @Scale(5) 
	private BigDecimal familyNum;

	@Length(11) @Scale(5) 
	private BigDecimal cavityNum;

	@Length(11) @Scale(5) 
	private BigDecimal moldYld;

	@Length(30) 
	private String salModelCode;

	@Length(50) 
	private String revNo;

	@Length(2000) 
	private String localEquipDesc;

	@Length(500) 
	private String alterManm;

	@Length(30) 
	private String alterVendCode;

	@Length(11) @Scale(3) 
	private BigDecimal calibTermHop;

	@Length(1) 
	private String calibYn;

	@Length(1) 
	private String fprfAplyYn;

	@Length(1) 
	private String calibAplyYn;

	@Length(1) 
	private String deftSumrYn;

	@Length(14) 
	private String ifDt;

	@Length(1) 
	private String useYn;

	@Length(14) 
	private String fstRegDt;

	@Length(50) 
	private String fstRegerId;

	@Length(14) 
	private String fnlUpdDt;

	@Length(50) 
	private String fnlUpderId;

	@Length(50) 
	private String evtNm;


	public String getPlantCode() {
		this.plantCode = super.getValue(0);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(0, plantCode);
		this.plantCode = plantCode;
	}
	
	public String getEquipCode() {
		this.equipCode = super.getValue(1);
		return this.equipCode;
	}

	public void setEquipCode(String equipCode) {
        super.setValue(1, equipCode);
		this.equipCode = equipCode;
	}
	
	public String getHistTsp() {
		this.histTsp = super.getValue(2);
		return this.histTsp;
	}

	public void setHistTsp(String histTsp) {
        super.setValue(2, histTsp);
		this.histTsp = histTsp;
	}
	
	public String getEquipNm() {
		this.equipNm = super.getValue(3);
		return this.equipNm;
	}

	public void setEquipNm(String equipNm) {
        super.setValue(3, equipNm);
		this.equipNm = equipNm;
	}
	
	public String getEquipSpecCont() {
		this.equipSpecCont = super.getValue(4);
		return this.equipSpecCont;
	}

	public void setEquipSpecCont(String equipSpecCont) {
        super.setValue(4, equipSpecCont);
		this.equipSpecCont = equipSpecCont;
	}
	
	public String getEquipGubunCode() {
		this.equipGubunCode = super.getValue(5);
		return this.equipGubunCode;
	}

	public void setEquipGubunCode(String equipGubunCode) {
        super.setValue(5, equipGubunCode);
		this.equipGubunCode = equipGubunCode;
	}
	
	public String getMatrGubunCode() {
		this.matrGubunCode = super.getValue(6);
		return this.matrGubunCode;
	}

	public void setMatrGubunCode(String matrGubunCode) {
        super.setValue(6, matrGubunCode);
		this.matrGubunCode = matrGubunCode;
	}
	
	public String getMatrTypeCode() {
		this.matrTypeCode = super.getValue(7);
		return this.matrTypeCode;
	}

	public void setMatrTypeCode(String matrTypeCode) {
        super.setValue(7, matrTypeCode);
		this.matrTypeCode = matrTypeCode;
	}
	
	public String getProcGubunCode() {
		this.procGubunCode = super.getValue(8);
		return this.procGubunCode;
	}

	public void setProcGubunCode(String procGubunCode) {
        super.setValue(8, procGubunCode);
		this.procGubunCode = procGubunCode;
	}
	
	public String getAutomYn() {
		this.automYn = super.getValue(9);
		return this.automYn;
	}

	public void setAutomYn(String automYn) {
        super.setValue(9, automYn);
		this.automYn = automYn;
	}
	
	public BigDecimal getEquipSize() {
		this.equipSize = super.getValue(10);
		return this.equipSize;
	}

	public void setEquipSize(BigDecimal equipSize) {
        super.setValue(10, equipSize);
		this.equipSize = equipSize;
	}
	
	public String getSupplyVendPnNm() {
		this.supplyVendPnNm = super.getValue(11);
		return this.supplyVendPnNm;
	}

	public void setSupplyVendPnNm(String supplyVendPnNm) {
        super.setValue(11, supplyVendPnNm);
		this.supplyVendPnNm = supplyVendPnNm;
	}
	
	public String getSupplyVendNm() {
		this.supplyVendNm = super.getValue(12);
		return this.supplyVendNm;
	}

	public void setSupplyVendNm(String supplyVendNm) {
        super.setValue(12, supplyVendNm);
		this.supplyVendNm = supplyVendNm;
	}
	
	public String getPurcNo() {
		this.purcNo = super.getValue(13);
		return this.purcNo;
	}

	public void setPurcNo(String purcNo) {
        super.setValue(13, purcNo);
		this.purcNo = purcNo;
	}
	
	public String getDfGubunCode() {
		this.dfGubunCode = super.getValue(14);
		return this.dfGubunCode;
	}

	public void setDfGubunCode(String dfGubunCode) {
        super.setValue(14, dfGubunCode);
		this.dfGubunCode = dfGubunCode;
	}
	
	public BigDecimal getMoldNum() {
		this.moldNum = super.getValue(15);
		return this.moldNum;
	}

	public void setMoldNum(BigDecimal moldNum) {
        super.setValue(15, moldNum);
		this.moldNum = moldNum;
	}
	
	public BigDecimal getFamilyNum() {
		this.familyNum = super.getValue(16);
		return this.familyNum;
	}

	public void setFamilyNum(BigDecimal familyNum) {
        super.setValue(16, familyNum);
		this.familyNum = familyNum;
	}
	
	public BigDecimal getCavityNum() {
		this.cavityNum = super.getValue(17);
		return this.cavityNum;
	}

	public void setCavityNum(BigDecimal cavityNum) {
        super.setValue(17, cavityNum);
		this.cavityNum = cavityNum;
	}
	
	public BigDecimal getMoldYld() {
		this.moldYld = super.getValue(18);
		return this.moldYld;
	}

	public void setMoldYld(BigDecimal moldYld) {
        super.setValue(18, moldYld);
		this.moldYld = moldYld;
	}
	
	public String getSalModelCode() {
		this.salModelCode = super.getValue(19);
		return this.salModelCode;
	}

	public void setSalModelCode(String salModelCode) {
        super.setValue(19, salModelCode);
		this.salModelCode = salModelCode;
	}
	
	public String getRevNo() {
		this.revNo = super.getValue(20);
		return this.revNo;
	}

	public void setRevNo(String revNo) {
        super.setValue(20, revNo);
		this.revNo = revNo;
	}
	
	public String getLocalEquipDesc() {
		this.localEquipDesc = super.getValue(21);
		return this.localEquipDesc;
	}

	public void setLocalEquipDesc(String localEquipDesc) {
        super.setValue(21, localEquipDesc);
		this.localEquipDesc = localEquipDesc;
	}
	
	public String getAlterManm() {
		this.alterManm = super.getValue(22);
		return this.alterManm;
	}

	public void setAlterManm(String alterManm) {
        super.setValue(22, alterManm);
		this.alterManm = alterManm;
	}
	
	public String getAlterVendCode() {
		this.alterVendCode = super.getValue(23);
		return this.alterVendCode;
	}

	public void setAlterVendCode(String alterVendCode) {
        super.setValue(23, alterVendCode);
		this.alterVendCode = alterVendCode;
	}
	
	public BigDecimal getCalibTermHop() {
		this.calibTermHop = super.getValue(24);
		return this.calibTermHop;
	}

	public void setCalibTermHop(BigDecimal calibTermHop) {
        super.setValue(24, calibTermHop);
		this.calibTermHop = calibTermHop;
	}
	
	public String getCalibYn() {
		this.calibYn = super.getValue(25);
		return this.calibYn;
	}

	public void setCalibYn(String calibYn) {
        super.setValue(25, calibYn);
		this.calibYn = calibYn;
	}
	
	public String getFprfAplyYn() {
		this.fprfAplyYn = super.getValue(26);
		return this.fprfAplyYn;
	}

	public void setFprfAplyYn(String fprfAplyYn) {
        super.setValue(26, fprfAplyYn);
		this.fprfAplyYn = fprfAplyYn;
	}
	
	public String getCalibAplyYn() {
		this.calibAplyYn = super.getValue(27);
		return this.calibAplyYn;
	}

	public void setCalibAplyYn(String calibAplyYn) {
        super.setValue(27, calibAplyYn);
		this.calibAplyYn = calibAplyYn;
	}
	
	public String getDeftSumrYn() {
		this.deftSumrYn = super.getValue(28);
		return this.deftSumrYn;
	}

	public void setDeftSumrYn(String deftSumrYn) {
        super.setValue(28, deftSumrYn);
		this.deftSumrYn = deftSumrYn;
	}
	
	public String getIfDt() {
		this.ifDt = super.getValue(29);
		return this.ifDt;
	}

	public void setIfDt(String ifDt) {
        super.setValue(29, ifDt);
		this.ifDt = ifDt;
	}
	
	public String getUseYn() {
		this.useYn = super.getValue(30);
		return this.useYn;
	}

	public void setUseYn(String useYn) {
        super.setValue(30, useYn);
		this.useYn = useYn;
	}
	
	public String getFstRegDt() {
		this.fstRegDt = super.getValue(31);
		return this.fstRegDt;
	}

	public void setFstRegDt(String fstRegDt) {
        super.setValue(31, fstRegDt);
		this.fstRegDt = fstRegDt;
	}
	
	public String getFstRegerId() {
		this.fstRegerId = super.getValue(32);
		return this.fstRegerId;
	}

	public void setFstRegerId(String fstRegerId) {
        super.setValue(32, fstRegerId);
		this.fstRegerId = fstRegerId;
	}
	
	public String getFnlUpdDt() {
		this.fnlUpdDt = super.getValue(33);
		return this.fnlUpdDt;
	}

	public void setFnlUpdDt(String fnlUpdDt) {
        super.setValue(33, fnlUpdDt);
		this.fnlUpdDt = fnlUpdDt;
	}
	
	public String getFnlUpderId() {
		this.fnlUpderId = super.getValue(34);
		return this.fnlUpderId;
	}

	public void setFnlUpderId(String fnlUpderId) {
        super.setValue(34, fnlUpderId);
		this.fnlUpderId = fnlUpderId;
	}
	
	public String getEvtNm() {
		this.evtNm = super.getValue(35);
		return this.evtNm;
	}

	public void setEvtNm(String evtNm) {
        super.setValue(35, evtNm);
		this.evtNm = evtNm;
	}
	
}