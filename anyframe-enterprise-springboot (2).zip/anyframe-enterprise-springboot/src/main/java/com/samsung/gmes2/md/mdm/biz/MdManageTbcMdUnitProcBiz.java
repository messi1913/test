/**
 * <PRE>

 * System Name : G-MES 2.0
 * Business Name : 개발템플릿 (MD) – 단위 공정 코드 조회
 * Class Name : MdManageTbcMdUnitProcBiz.java
 * Description : 단위 공정 코드  에 대한 테이블을 조회하는 Biz 클래스
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------     ---------    ---------------------------
 *    2011.07.25      김상민          최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */

package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdBaseProcDVO;
import com.samsung.gmes2.md.model.TbcMdProcTypeDVO;
import com.samsung.gmes2.md.model.TbcMdUnitProcDVO;

/**
 * 한글명 : 단위공정코드 조회 
 * 작성일 : 2011.07.25 
 * 작성자 : 김 상 민 
 * 작업상태 : 완료 
 * 개요 : 단위공정 코드 조회를 위한 조건들을 검색해 해당 조건에 맞는 정보를 보내준다.
 * 
 * @name_ko 단위공정 코드 조회
 */

public class MdManageTbcMdUnitProcBiz {

	/**
	 * Primary Key, Not Null, Foreign Key 등의 필수 항목 값들을 체크하는 메서드
	 * 
	 * @name_ko 모든 필수값 항목을 체크하는 메서드
	 */
	private void checkingAllValidation(TbcMdUnitProcDVO inputDVO)
			throws Exception {
		
		/*--------------------------------------------------
		 * @fd_call_start BaseUtil.checkNotEmpty
		 * @fd_id 0001
		 * 필수 값인 Primary Key, Not Null, Foreign key
		 * 체크 후 없으면 Excpetion
		 --------------------------------------------------*/
		
		BaseUtil.checkNotEmpty(inputDVO);
		
		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/
		
		/*--------------------------------------------------
		 * @fd_do_start 참조DVO 생성하는 메서드
		 * @fd_id 0003
		 * Foreign Key 인 경우, 해당 DATA 와 참조 Table 의 값과
		 * 일치하는 값이 들어와야 함으로, 참조 Table 과 1대 1로 
		 * 매핑되는 DVO 생성
		 --------------------------------------------------*/

		TbcMdProcTypeDVO tbcMdProcTypeDVO = new TbcMdProcTypeDVO();
		TbcMdBaseProcDVO tbcMdBaseProcDVO = new TbcMdBaseProcDVO();


		/*--------------------------------------------------
		 * @fd_do_end 0003
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_call_start BaseUtil.populate
		 * @fd_id 0004
		 * DVO 에 들어온 값들을 참조 테이블 DVO 에 복사하는 메서드
		 * -값들을 복사하여서 참조 태아불 DVO로 해당 DB 에 값이 
		 * 일치하는 지를 알아보기 위하여-
		 --------------------------------------------------*/

		BaseUtil.populate(inputDVO, tbcMdProcTypeDVO, "procGubunCode",
				"procTypeCode");
		BaseUtil.populate(inputDVO, tbcMdBaseProcDVO, "baseProcCode");

		/*--------------------------------------------------
		 * @fd_call_end 0004
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_call_start BaseUtil.checkFound
		 * @fd_id 0005
		 * 참조 테이블 DVO 에 복사된 값이 참조 테이블에 있는 DATA 와
		 * 일치하는지를 확이하는 메세드
		 * 일차하는 항목이 없을 경우 Exception 을 날린다.
		 --------------------------------------------------*/

		BaseUtil.checkFound(tbcMdProcTypeDVO);
		BaseUtil.checkFound(tbcMdBaseProcDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0005
		 --------------------------------------------------*/

	}

	public TbcMdUnitProcDVO createTbcMdUnitProc(TbcMdUnitProcDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * 앞에서 한 메서드 를 통해 값들의 validation 을 체크한다.
		 --------------------------------------------------*/

		checkingAllValidation(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/
		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.create
		 * @fd_id 0002
		 * Primary Key, not Null, FK 등의 필수 입력값 확인후
		 * 이상이 없을시 insert 하는 메서드
		 * 수정일시는 값이 들어오지 않을시 DB 기준 현재시간을 update 한다.
		 * USE_YN 이 "N" 일 경우 update 되지않고 Exception 을 낸다.
		 --------------------------------------------------*/
		return CrudUtil.create(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
	}

	public TbcMdUnitProcDVO updateTbcMdUnitProc(TbcMdUnitProcDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * 앞에서 한 메서드 를 통해 값들의 validation 을 체크한다.
		 --------------------------------------------------*/

		checkingAllValidation(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.update
		 * @fd_id 0002
		 * Primary Key, not Null, FK 등의 필수 입력값 확인후
		 * 이상이 없을시 update 하는 메서드
		 * 수정일시는 값이 들어오지 않을시 DB 기준 현재시간을 insert 하고
		 * USE_YN 칼럼은 Y 로 insert 한다.
		 --------------------------------------------------*/
		return CrudUtil.update(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
	}

	public TbcMdUnitProcDVO deleteTbcMdUnitProc(TbcMdUnitProcDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * Pk 값이 있는 지 없는지를 확인하는 메서드
		 --------------------------------------------------*/

		BaseUtil.checkNotEmpty(inputDVO, "unitProcCode");

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.delete
		 * @fd_id 0002
		 * Primary Key 필수 입력값 확인후
		 * 이상이 없을시 delete 하는 메서드
		 * 실제적 삭제가 아닌 USE_YN 컬럼을 N 으로 업데이트한다.
		 * 수정 일시는 값이 들어오지 않을시 DB 기준 현재시간을 update 한다.
		 --------------------------------------------------*/

		return CrudUtil.delete(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
	}

	public TbcMdUnitProcDVO getTbcMdUnitProc(TbcMdUnitProcDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start Validation 체크 메세지 호출
		 * @fd_id 0001
		 * 앞에서 한 메서드 를 통해 값들의 validation 을 체크한다.
		 --------------------------------------------------*/

		//BaseUtil.checkNotEmpty(inputDVO, "unitProcCode");

		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.get
		 * @fd_id 0002
		 * Primary Key 필수 입력값 확인후
		 * 이상이 없을시 select 하는 메서드
		 * 해당 Primary key 에 대한 Data 를 1Row 로 가져온다.
		 --------------------------------------------------*/

		return CrudUtil.get(inputDVO);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
	}

	public List<TbcMdUnitProcDVO> listTbcMdUnitProc(TbcMdUnitProcDVO inputDVO)
			throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start CodeUtil.list
		 * @fd_id 0002
		 * Primary Key, not Null, FK 등의 필수 입력값 확인 없이
		 * 해당 컬럼중 찾고자 하는 Data 가 들어오면 그 DATA 에 해당하는
		 * 결과값을 List(배열) 로 SELECT 하는 메서드
		 --------------------------------------------------*/

		return CrudUtil.list0(TbcMdUnitProcDVO.class, inputDVO, 0, 0);

		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/
	}
}