package com.samsung.gmes2.md.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.annotation.Stereotype;
import com.anyframe.online.runtime.jdbc.util.DynamicQueryUtil;
import com.anyframe.online.runtime.jdbc.AbstractDAO;


/**
* 
*
* @ref_table  
* @author sangminKim
*/
@Stereotype(Stereotype.Dao)
public class TbcMdInspClsfDQM extends AbstractDAO {


/**
*
* SELECT 
* 	INSP_CLSF_CODE, 
* 	INSP_LAGE_CLSF_CODE, 
* 	INSP_MID_CLSF_CODE, 
* 	INSP_CLSF_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_CLSF 
* WHERE 1=1 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($inspLageClsfCode) 
* AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode 
* #end 
* #if($inspMidClsfCode) 
* AND INSP_MID_CLSF_CODE = :inspMidClsfCode 
* #end 
* #if($inspClsfNm) 
* AND INSP_CLSF_NM = :inspClsfNm 
* #end 
* #if($inspClsfNmLike) 
* AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%' 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage000 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	INSP_LAGE_CLSF_CODE,  \n");
			sql.append(" 	INSP_MID_CLSF_CODE,  \n");
			sql.append(" 	INSP_CLSF_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspLageClsfCode)  \n");
			sql.append(" AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspMidClsfCode)  \n");
			sql.append(" AND INSP_MID_CLSF_CODE = :inspMidClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNm)  \n");
			sql.append(" AND INSP_CLSF_NM = :inspClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNmLike)  \n");
			sql.append(" AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspClsfDQM.dListPage000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspClsfDVO returnTbcMdInspClsfDVO = new TbcMdInspClsfDVO();
									returnTbcMdInspClsfDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspLageClsfCode(resultSet.getString("INSP_LAGE_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspMidClsfCode(resultSet.getString("INSP_MID_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspClsfNm(resultSet.getString("INSP_CLSF_NM"));
									returnTbcMdInspClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	INSP_CLSF_CODE, 
* 	INSP_LAGE_CLSF_CODE, 
* 	INSP_MID_CLSF_CODE, 
* 	INSP_CLSF_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_CLSF 
* WHERE 1=1 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($inspLageClsfCode) 
* AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode 
* #end 
* #if($inspMidClsfCode) 
* AND INSP_MID_CLSF_CODE = :inspMidClsfCode 
* #end 
* #if($inspClsfNm) 
* AND INSP_CLSF_NM = :inspClsfNm 
* #end 
* #if($inspClsfNmLike) 
* AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%' 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return List
*
*/
	public List dListPage001 (final Map inputMap , int firstPage, int pageSize) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	INSP_LAGE_CLSF_CODE,  \n");
			sql.append(" 	INSP_MID_CLSF_CODE,  \n");
			sql.append(" 	INSP_CLSF_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspLageClsfCode)  \n");
			sql.append(" AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspMidClsfCode)  \n");
			sql.append(" AND INSP_MID_CLSF_CODE = :inspMidClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNm)  \n");
			sql.append(" AND INSP_CLSF_NM = :inspClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNmLike)  \n");
			sql.append(" AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspClsfDQM.dListPage001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return query(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspClsfDVO returnTbcMdInspClsfDVO = new TbcMdInspClsfDVO();
									returnTbcMdInspClsfDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspLageClsfCode(resultSet.getString("INSP_LAGE_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspMidClsfCode(resultSet.getString("INSP_MID_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspClsfNm(resultSet.getString("INSP_CLSF_NM"));
									returnTbcMdInspClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize
 		);
	}


/**
*
* SELECT 
* 	INSP_CLSF_CODE, 
* 	INSP_LAGE_CLSF_CODE, 
* 	INSP_MID_CLSF_CODE, 
* 	INSP_CLSF_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_CLSF 
* WHERE 1=1 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($inspLageClsfCode) 
* AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode 
* #end 
* #if($inspMidClsfCode) 
* AND INSP_MID_CLSF_CODE = :inspMidClsfCode 
* #end 
* #if($inspClsfNm) 
* AND INSP_CLSF_NM = :inspClsfNm 
* #end 
* #if($inspClsfNmLike) 
* AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%' 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	INSP_LAGE_CLSF_CODE,  \n");
			sql.append(" 	INSP_MID_CLSF_CODE,  \n");
			sql.append(" 	INSP_CLSF_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspLageClsfCode)  \n");
			sql.append(" AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspMidClsfCode)  \n");
			sql.append(" AND INSP_MID_CLSF_CODE = :inspMidClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNm)  \n");
			sql.append(" AND INSP_CLSF_NM = :inspClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNmLike)  \n");
			sql.append(" AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspClsfDQM.dListPageRowCount000.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspClsfDVO returnTbcMdInspClsfDVO = new TbcMdInspClsfDVO();
									returnTbcMdInspClsfDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspLageClsfCode(resultSet.getString("INSP_LAGE_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspMidClsfCode(resultSet.getString("INSP_MID_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspClsfNm(resultSet.getString("INSP_CLSF_NM"));
									returnTbcMdInspClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount000 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount000 (inputMap,  firstPage,  pageSize, true);
	}

/**
*
* SELECT 
* 	INSP_CLSF_CODE, 
* 	INSP_LAGE_CLSF_CODE, 
* 	INSP_MID_CLSF_CODE, 
* 	INSP_CLSF_NM, 
* 	USE_YN, 
* 	FST_REG_DT, 
* 	FST_REGER_ID, 
* 	FNL_UPD_DT, 
* 	FNL_UPDER_ID 
* FROM TBC_MD_INSP_CLSF 
* WHERE 1=1 
* #if($inspClsfCode) 
* AND INSP_CLSF_CODE = :inspClsfCode 
* #end 
* #if($inspLageClsfCode) 
* AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode 
* #end 
* #if($inspMidClsfCode) 
* AND INSP_MID_CLSF_CODE = :inspMidClsfCode 
* #end 
* #if($inspClsfNm) 
* AND INSP_CLSF_NM = :inspClsfNm 
* #end 
* #if($inspClsfNmLike) 
* AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%' 
* #end 
* #if($useYn) 
* AND USE_YN = :useYn 
* #end 
* #if($fstRegDt) 
* AND FST_REG_DT = :fstRegDt 
* #end 
* #if($fstRegerId) 
* AND FST_REGER_ID = :fstRegerId 
* #end 
* #if($fnlUpdDt) 
* AND FNL_UPD_DT = :fnlUpdDt 
* #end 
* #if($fnlUpderId) 
* AND FNL_UPDER_ID = :fnlUpderId 
* #end 
* 
* @ref_table 
* @return Map
*
*/
	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize, boolean countFlag) {

     	StringBuffer sql = new StringBuffer();

			sql.append(" SELECT  \n");
			sql.append(" 	INSP_CLSF_CODE,  \n");
			sql.append(" 	INSP_LAGE_CLSF_CODE,  \n");
			sql.append(" 	INSP_MID_CLSF_CODE,  \n");
			sql.append(" 	INSP_CLSF_NM,  \n");
			sql.append(" 	USE_YN,  \n");
			sql.append(" 	FST_REG_DT,  \n");
			sql.append(" 	FST_REGER_ID,  \n");
			sql.append(" 	FNL_UPD_DT,  \n");
			sql.append(" 	FNL_UPDER_ID  \n");
			sql.append(" FROM TBC_MD_INSP_CLSF  \n");
			sql.append(" WHERE 1=1  \n");
			sql.append(" #if($inspClsfCode)  \n");
			sql.append(" AND INSP_CLSF_CODE = :inspClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspLageClsfCode)  \n");
			sql.append(" AND INSP_LAGE_CLSF_CODE = :inspLageClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspMidClsfCode)  \n");
			sql.append(" AND INSP_MID_CLSF_CODE = :inspMidClsfCode  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNm)  \n");
			sql.append(" AND INSP_CLSF_NM = :inspClsfNm  \n");
			sql.append(" #end  \n");
			sql.append(" #if($inspClsfNmLike)  \n");
			sql.append(" AND INSP_CLSF_NM like '%' || :inspClsfNmLike || '%'  \n");
			sql.append(" #end  \n");
			sql.append(" #if($useYn)  \n");
			sql.append(" AND USE_YN = :useYn  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegDt)  \n");
			sql.append(" AND FST_REG_DT = :fstRegDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fstRegerId)  \n");
			sql.append(" AND FST_REGER_ID = :fstRegerId  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpdDt)  \n");
			sql.append(" AND FNL_UPD_DT = :fnlUpdDt  \n");
			sql.append(" #end  \n");
			sql.append(" #if($fnlUpderId)  \n");
			sql.append(" AND FNL_UPDER_ID = :fnlUpderId  \n");
			sql.append(" #end  \n");
		sql.append(" /* com.samsung.gmes2.md.model.TbcMdInspClsfDQM.dListPageRowCount001.001 */ \n");

		String dynamicQuery = DynamicQueryUtil.convertDynamicQuery(sql.toString() , inputMap);
		sql.setLength(0);
		sql.append(dynamicQuery);

		return queryWithRowCount(sql.toString() , inputMap ,
						new RowMapper() {
					    	public Object mapRow(ResultSet resultSet, int row)
					    			throws SQLException {
					    			
									TbcMdInspClsfDVO returnTbcMdInspClsfDVO = new TbcMdInspClsfDVO();
									returnTbcMdInspClsfDVO.setInspClsfCode(resultSet.getString("INSP_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspLageClsfCode(resultSet.getString("INSP_LAGE_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspMidClsfCode(resultSet.getString("INSP_MID_CLSF_CODE"));
									returnTbcMdInspClsfDVO.setInspClsfNm(resultSet.getString("INSP_CLSF_NM"));
									returnTbcMdInspClsfDVO.setUseYn(resultSet.getString("USE_YN"));
									returnTbcMdInspClsfDVO.setFstRegDt(resultSet.getString("FST_REG_DT"));
									returnTbcMdInspClsfDVO.setFstRegerId(resultSet.getString("FST_REGER_ID"));
									returnTbcMdInspClsfDVO.setFnlUpdDt(resultSet.getString("FNL_UPD_DT"));
									returnTbcMdInspClsfDVO.setFnlUpderId(resultSet.getString("FNL_UPDER_ID"));
									return returnTbcMdInspClsfDVO;
					    	}
					    	
					   } , firstPage , pageSize , countFlag
 		);
	}

	public Map dListPageRowCount001 (final Map inputMap, int firstPage, int pageSize) {
		return dListPageRowCount001 (inputMap,  firstPage,  pageSize, true);
	}


}