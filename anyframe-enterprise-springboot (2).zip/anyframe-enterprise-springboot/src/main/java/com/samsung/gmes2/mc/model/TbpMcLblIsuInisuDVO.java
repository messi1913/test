package com.samsung.gmes2.mc.model;

import com.anyframe.core.annotation.Length;
import com.anyframe.core.annotation.LocalName;
import com.anyframe.core.vo.AbstractVo;

/**
 * 
 * @author shim
 */
public class TbpMcLblIsuInisuDVO extends AbstractVo {

	@Length(50) 
	private String nmgId;

	@Length(14) 
	private String prtDt;

	@Length(20) 
	private String modelCode;

	@Length(50) 
	private String labelId;

	@Length(50) 
	private String prterId;

	@Length(1) 
	private String rePrtYn;

	@Length(1000) 
	private String rePrtRsn;

	@Length(20) 
	private String plantCode;


	public String getNmgId() {
		this.nmgId = super.getValue(0);
		return this.nmgId;
	}

	public void setNmgId(String nmgId) {
        super.setValue(0, nmgId);
		this.nmgId = nmgId;
	}
	
	public String getPrtDt() {
		this.prtDt = super.getValue(1);
		return this.prtDt;
	}

	public void setPrtDt(String prtDt) {
        super.setValue(1, prtDt);
		this.prtDt = prtDt;
	}
	
	public String getModelCode() {
		this.modelCode = super.getValue(2);
		return this.modelCode;
	}

	public void setModelCode(String modelCode) {
        super.setValue(2, modelCode);
		this.modelCode = modelCode;
	}
	
	public String getLabelId() {
		this.labelId = super.getValue(3);
		return this.labelId;
	}

	public void setLabelId(String labelId) {
        super.setValue(3, labelId);
		this.labelId = labelId;
	}
	
	public String getPrterId() {
		this.prterId = super.getValue(4);
		return this.prterId;
	}

	public void setPrterId(String prterId) {
        super.setValue(4, prterId);
		this.prterId = prterId;
	}
	
	public String getRePrtYn() {
		this.rePrtYn = super.getValue(5);
		return this.rePrtYn;
	}

	public void setRePrtYn(String rePrtYn) {
        super.setValue(5, rePrtYn);
		this.rePrtYn = rePrtYn;
	}
	
	public String getRePrtRsn() {
		this.rePrtRsn = super.getValue(6);
		return this.rePrtRsn;
	}

	public void setRePrtRsn(String rePrtRsn) {
        super.setValue(6, rePrtRsn);
		this.rePrtRsn = rePrtRsn;
	}
	
	public String getPlantCode() {
		this.plantCode = super.getValue(7);
		return this.plantCode;
	}

	public void setPlantCode(String plantCode) {
        super.setValue(7, plantCode);
		this.plantCode = plantCode;
	}
	
}