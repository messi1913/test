/**
 * <PRE>

 * System Name : G-MES 2.0
 * Business Name : 개발템플릿 (MD) – 증상분류 코드 조회
 * Class Name : MdManageTbcMdDeftSyympClsfBiz.java
 * Description : 증상분류에 대한 테이블을 조회하는 Biz 클래스
 * Modification History
 *       수정일             수정자           수정내용
 *    -------------     ---------    ---------------------------
 *    2011.07.25      김상민          최초 생성
 * </PRE>
 * @version 1.0
 * @author Copyright (C) 2011 by SAMSUNG SDS co.,Ltd. All right reserved. 
 */


package com.samsung.gmes2.md.mdm.biz;

import java.util.List;

import com.samsung.gmes2.base.util.BaseUtil;
import com.samsung.gmes2.base.util.CrudUtil;
import com.samsung.gmes2.md.model.TbcMdDeftSympClsfDVO;

/**
 * 한글명 : 증상분류코드 조회 
 * 작성일 : 2011.07.25 
 * 작성자 : 김 상 민 
 * 작업상태 : 완료 
 * 개요 : 증상분류코드 조회를 위한 조건들을 검색해 해당 조건에 맞는 정보를 보내준다.
 * 
 * @name_ko 증상 분류 코드 조회
 */

public class MdManageTbcMdDeftSympClsfBiz {

	/**
	 * 각 필수 입력값을 확인후 , Insert 시키는 메서드
	 * @name_ko 해당 Table Insert 하는 메서드
	 */
	public TbcMdDeftSympClsfDVO createTbcMdDeftSympClsf(
			TbcMdDeftSympClsfDVO inputDVO) throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start BaseUtl.checkNotEmpty 검색
		 * @fd_id 0001
		 * 해당 Table에 Primary Key, Not Null, Foreign Key 
		 * 에 해당하는 컬럼들의 DATA 가 Null 인지 체크
		 * 만약 Null 인경우, Exception 메세지 를 날림
		 * 값들이 들어오면 다음 명령문 수행
		 --------------------------------------------------*/
		BaseUtil.checkNotEmpty(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CrudUtil 코드 호출
		 * @fd_id 0002
		 * CrudUtil을 호출하여 insert 시키는 명령문
		 * 각 Primary 키가 중복이 안되는 지 체크하고
		 * 사용자 Id, 등록일시 가 제대로 들어왔는지 체크 하며
		 * 만약 등록일시가 들어오지 않을 경우 DB 에 현재시간을 Insert 한다.
		 * 또한 사용여부에 대한 정보가 들어오지 않으면 Default 로 "Y" 가 
		 * Insert 된다.
		 --------------------------------------------------*/
		return CrudUtil.create(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0002
		 --------------------------------------------------*/

	}

	/**
	 * 필수 값 확인후, 업데이트 시키는 메서드
	 * @name_ko 해당 Table Update 하는 메서드
	 */
	public TbcMdDeftSympClsfDVO updateTbcMdDeftSympClsf(
			TbcMdDeftSympClsfDVO inputDVO) throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start BaseUtl.checkNotEmpty 검색
		 * @fd_id 0003
		 * 해당 Table에 Primary Key, Not Null, Foreign Key 
		 * 에 해당하는 컬럼들의 DATA 가 Null 인지 체크
		 * 만약 Null 인경우, Exception 메세지 를 날림
		 * 값들이 들어오면 다음 명령문 수행
		 --------------------------------------------------*/
//		BaseUtil.checkNotEmpty(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0003
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CrudUtil 코드 호출
		 * @fd_id 0004
		 * CrudUtil을 호출하여 update 시키는 명령문
		 * 각 Primary 키가 중복이 안되는 지 체크하고
		 * 사용자 Id, 등록일시 가 제대로 들어왔는지 체크 하며
		 * 만약 등록일시가 들어오지 않을 경우 DB 에 현재시간을 Insert 한다.
		 * 또한 사용여부에 대한 정보가 들어오지 않으면 Default 로 "Y" 가 
		 * Insert 된다.
		 --------------------------------------------------*/
		return CrudUtil.update(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0004
		 --------------------------------------------------*/

	}

	/**
	 * @name_ko 해당 Table Delete 하는 메서드
	 */
	public TbcMdDeftSympClsfDVO deleteTbcMdDeftSympClsf(
			TbcMdDeftSympClsfDVO inputDVO) throws Exception {
		
		/*--------------------------------------------------
		 * @fd_call_start BaseUtl.checkNotEmpty 검색
		 * @fd_id 0003
		 * 해당 Table에 Primary Key, Not Null, Foreign Key 
		 * 에 해당하는 컬럼들의 DATA 가 Null 인지 체크
		 * 만약 Null 인경우, Exception 메세지 를 날림
		 * 값들이 들어오면 다음 명령문 수행
		 --------------------------------------------------*/
		BaseUtil.checkNotEmpty(inputDVO);
		
		/*--------------------------------------------------
		 * @fd_call_end 0003
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CrudUtil 코드 호출
		 * @fd_id 0004
		 * CrudUtil을 호출하여 DELETE 시키는 명령문
		 * 각 Primary 키가 중복이 안되는 지 체크하고 삭제를 한다.
		 * 실제로 삭제하는것이 아니고 USE_YN 의 컬럼에 "N" 을 입력하여 업데이트 시킨다.
		 --------------------------------------------------*/
		return CrudUtil.delete(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0004
		 --------------------------------------------------*/

	}

	/**
	 * @name_ko 해당 Table Select 하는 메서드 (조건: PK)
	 */
	public TbcMdDeftSympClsfDVO getTbcMdDeftSympClsf(
			TbcMdDeftSympClsfDVO inputDVO) throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start BaseUtl.checkNotEmpty 검색
		 * @fd_id 0003
		 * 해당 Table에 Primary Key, Not Null, Foreign Key 
		 * 에 해당하는 컬럼들의 DATA 가 Null 인지 체크
		 * 만약 Null 인경우, Exception 메세지 를 날림
		 * 값들이 들어오면 다음 명령문 수행
		 --------------------------------------------------*/
		//BaseUtil.checkNotEmpty(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0003
		 --------------------------------------------------*/

		/*--------------------------------------------------
		 * @fd_call_start CrudUtil 코드 호출
		 * @fd_id 0004
		 * CrudUtil을 호출하여 SELECT 시키는 명령문
		 * 각 Primary 키가 중복이 안되는 지 체크하고
		 * 해당 Primary key 에 대한 정보를 가져온다.
		 --------------------------------------------------*/
		return CrudUtil.get(inputDVO);
		/*--------------------------------------------------
		 * @fd_call_end 0004
		 --------------------------------------------------*/

	}

	/**
	 * 특정 조건에 해당하는 것들을 list 형식으로 보낸다
	 * @name_ko 해당 Table Select 하는 메서드
	 */
	public List<TbcMdDeftSympClsfDVO> listTbcMdDeftSympClsf(
			TbcMdDeftSympClsfDVO inputDVO) throws Exception {
		/*--------------------------------------------------
		 * @fd_call_start CrudUtil.list0 메서드 호출
		 * @fd_id 0001
		 * 이 메서드는 해당 DQM 으로가서 dlistPage000 이라는 메서드를
		 * 찾아서 특정조건에 대한 DATA 를 list 형식으로 보내준다
		 --------------------------------------------------*/
		return CrudUtil.list0(TbcMdDeftSympClsfDVO.class, inputDVO, 0, 0);
		/*--------------------------------------------------
		 * @fd_call_end 0001
		 --------------------------------------------------*/

	}

}
